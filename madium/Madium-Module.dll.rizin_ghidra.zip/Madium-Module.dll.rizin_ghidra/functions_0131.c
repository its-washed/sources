// Chunk 131 - 50 functions

// ============================================================
// Function: FUN_1801c1a20
// Address: 0x1801c1a20
// Size: 192 bytes
// ============================================================
uint64_t fcn.1801c1a20(int64_t arg_38h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1a30;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *(int64_t *)(*in_RCX + 0x18);
    if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) == 0) {
        uVar2 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1a52;
        iVar3 = fcn.1801e3b50(uVar2);
        if (iVar3 == 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1a62;
            iVar3 = fcn.1801e3ab0(uVar2);
            if (iVar3 != 0) {
                *(undefined4 *)((int64_t)&var_20h + iVar4) = *(undefined4 *)(in_RCX + 5);
                *(int64_t *)((int64_t)&var_18h + iVar4) = in_RCX[4];
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1a8a;
                iVar3 = fcn.1801c17a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0x00000068 + iVar4), 
                                      *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                                      *(int64_t *)(&stack0x00000090 + iVar4));
                if (iVar3 == 0) {
                    return 0xffffffff;
                }
                return (uint64_t)(*(int64_t *)in_RCX[4] != 0);
            }
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar4) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar4) = 0xcf;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1ad0;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                  *(int64_t *)(&stack0x00000048 + iVar4));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c1ae0
// Address: 0x1801c1ae0
// Size: 86 bytes
// ============================================================
undefined8 fcn.1801c1ae0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1aec;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(undefined8 *)(param_1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c1afe;
    iVar1 = fcn.1801e3b50(uVar3);
    if (iVar1 != 0) {
        return 1;
    }
    uVar3 = *(undefined8 *)(param_1 + 0xa0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c1b0e;
    uVar3 = func_0x0001801e39c0(uVar3);
    if ((*(uint8_t *)(param_1 + 0x100) & 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c1b1f;
        iVar1 = func_0x0001801e79d0(uVar3);
        if (iVar1 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c1b40
// Address: 0x1801c1b40
// Size: 29 bytes
// ============================================================
undefined8 fcn.1801c1b40(int64_t param_1)
{
    uint32_t uVar1;
    
    fcn.18045a350();
    uVar1 = *(uint32_t *)(*(int64_t *)(param_1 + 0xa0) + 0x5d0) & 7;
    if ((uVar1 != 2) && (1 < uVar1 - 3)) {
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c1b60
// Address: 0x1801c1b60
// Size: 29 bytes
// ============================================================
bool fcn.1801c1b60(int64_t param_1)
{
    fcn.18045a350();
    return ((uint8_t)*(undefined4 *)(*(int64_t *)(param_1 + 0xa0) + 0x5d0) & 7) == 4;
}

// ============================================================
// Function: FUN_1801c1b80
// Address: 0x1801c1b80
// Size: 50 bytes
// ============================================================
int32_t fcn.1801c1b80(int64_t param_1, int64_t param_2)
{
    uint32_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    bool bVar7;
    
    fcn.18045a350();
    uVar5 = *(uint64_t *)(param_1 + 0x10);
    if (uVar5 != *(uint64_t *)(param_2 + 0x10)) {
        return 1;
    }
    puVar3 = *(uint64_t **)(param_1 + 8);
    iVar4 = *(int64_t *)(param_2 + 8) - (int64_t)puVar3;
    if (7 < uVar5) {
        for (; ((uint64_t)puVar3 & 7) != 0; puVar3 = (uint64_t *)((int64_t)puVar3 + 1)) {
            bVar7 = *(uint8_t *)puVar3 < *(uint8_t *)((int64_t)puVar3 + iVar4);
            if (*(uint8_t *)puVar3 != *(uint8_t *)((int64_t)puVar3 + iVar4)) goto code_r0x000180497f73;
            uVar5 = uVar5 - 1;
        }
        if (uVar5 >> 3 != 0) {
            uVar6 = uVar5 >> 5;
            if (uVar6 != 0) {
                do {
                    uVar2 = *puVar3;
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4)) goto code_r0x000180497fe4;
                    uVar2 = puVar3[1];
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 8)) {
code_r0x000180497fe0:
                        puVar3 = puVar3 + 1;
                        goto code_r0x000180497fe4;
                    }
                    uVar2 = puVar3[2];
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 0x10)) {
code_r0x000180497fdc:
                        puVar3 = puVar3 + 1;
                        goto code_r0x000180497fe0;
                    }
                    uVar2 = puVar3[3];
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4 + 0x18)) {
                        puVar3 = puVar3 + 1;
                        goto code_r0x000180497fdc;
                    }
                    puVar3 = puVar3 + 4;
                    uVar6 = uVar6 - 1;
                } while (uVar6 != 0);
                uVar5 = uVar5 & 0x1f;
            }
            uVar6 = uVar5 >> 3;
            if (uVar6 != 0) {
                do {
                    uVar2 = *puVar3;
                    if (uVar2 != *(uint64_t *)((int64_t)puVar3 + iVar4)) {
code_r0x000180497fe4:
                        uVar5 = *(uint64_t *)(iVar4 + (int64_t)puVar3);
                        uVar1 = (uint32_t)
                                ((uVar2 >> 0x38 | (uVar2 & 0xff000000000000) >> 0x28 | (uVar2 & 0xff0000000000) >> 0x18
                                  | (uVar2 & 0xff00000000) >> 8 | (uVar2 & 0xff000000) << 8 | (uVar2 & 0xff0000) << 0x18
                                  | (uVar2 & 0xff00) << 0x28 | uVar2 << 0x38) <
                                (uVar5 >> 0x38 | (uVar5 & 0xff000000000000) >> 0x28 | (uVar5 & 0xff0000000000) >> 0x18 |
                                 (uVar5 & 0xff00000000) >> 8 | (uVar5 & 0xff000000) << 8 | (uVar5 & 0xff0000) << 0x18 |
                                 (uVar5 & 0xff00) << 0x28 | uVar5 << 0x38));
                        return (1 - uVar1) - (uint32_t)(uVar1 != 0);
                    }
                    puVar3 = puVar3 + 1;
                    uVar6 = uVar6 - 1;
                } while (uVar6 != 0);
                uVar5 = uVar5 & 7;
            }
        }
    }
    while( true ) {
        if (uVar5 == 0) {
            return 0;
        }
        bVar7 = *(uint8_t *)puVar3 < *(uint8_t *)((int64_t)puVar3 + iVar4);
        if (*(uint8_t *)puVar3 != *(uint8_t *)((int64_t)puVar3 + iVar4)) break;
        puVar3 = (uint64_t *)((int64_t)puVar3 + 1);
        uVar5 = uVar5 - 1;
    }
code_r0x000180497f73:
    return (1 - (uint32_t)bVar7) - (uint32_t)(bVar7 != 0);
}

// ============================================================
// Function: FUN_1801c1bc0
// Address: 0x1801c1bc0
// Size: 30 bytes
// ============================================================
uint64_t fcn.1801c1bc0(int64_t param_1)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    
    fcn.18045a350();
    uVar3 = 0;
    uVar2 = 0xcbf29ce484222325;
    if (*(uint64_t *)(param_1 + 0x10) != 0) {
        do {
            puVar1 = (uint8_t *)(*(int64_t *)(param_1 + 8) + uVar3);
            uVar3 = uVar3 + 1;
            uVar2 = (uVar2 ^ *puVar1) * 0x100000001b3;
        } while (uVar3 < *(uint64_t *)(param_1 + 0x10));
    }
    return uVar2;
}

// ============================================================
// Function: FUN_1801c1be0
// Address: 0x1801c1be0
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801c1be0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined4 *in_RDX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1bf0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x80) != 0)) {
    // switch table (7 cases) at 0x1801c1ccc
        switch(*(undefined *)(*(int64_t *)(in_RCX + 0x80) + 0x101)) {
        default:
            *in_RDX = 0x16e;
            return 0;
        case 1:
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x78) + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1c45;
            uVar4 = func_0x0001801e39c0(uVar1);
            uVar1 = *(undefined8 *)(in_RCX + 0x80);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1c54;
            iVar2 = func_0x0001801e77c0(uVar4, uVar1);
            if (iVar2 == 0) break;
code_r0x0001801c1c58:
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1c6a;
            iVar2 = func_0x0001801e6210(uVar1, 0);
            if (iVar2 == 0) {
                return 1;
            }
            goto code_r0x0001801c1c7e;
        case 2:
        case 3:
            goto code_r0x0001801c1c58;
        case 4:
code_r0x0001801c1c7e:
            *in_RDX = 0x16d;
            return 0;
        case 5:
        case 6:
            *in_RDX = 0x177;
            return 0;
        }
    }
    *in_RDX = 0xc0103;
    return 0;
}

// ============================================================
// Function: FUN_1801c1cf0
// Address: 0x1801c1cf0
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1801c1cf0(int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1d00;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(uint8_t *)(*in_RCX + 0x100) & 0x20) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1d22;
        iVar2 = fcn.1801e3b50();
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1d36;
            iVar2 = fcn.1801e3ab0();
            if (iVar2 != 0) {
                uVar1 = *(undefined8 *)(*in_RCX + 0xa0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1d4d;
                fcn.1801e39c0(uVar1);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1d58;
                iVar4 = fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar3));
                in_RCX[1] = iVar4;
                if (iVar4 == 0) {
                    uVar1 = *(undefined8 *)(*in_RCX + 0xa0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1d78;
                    fcn.1801e39c0(uVar1);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1d83;
                    iVar3 = fcn.1801e7870(*(int64_t *)(&stack0x00000048 + iVar3));
                    in_RCX[1] = iVar3;
                    return (uint64_t)(iVar3 != 0);
                }
                return 1;
            }
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0;
    *(undefined4 *)((int64_t)&var_18h + iVar3) = 0xcf;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c1dd8;
    fcn.1801c1390(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c1df0
// Address: 0x1801c1df0
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_41h
// WARNING: [rz-ghidra] Detected overlap for variable arg_42h

uint64_t fcn.1801c1df0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c1e05;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    iVar1 = *(int64_t *)(iVar1 + 0x78);
    if ((*(uint8_t *)(iVar1 + 0x100) & 0x20) == 0) {
        uVar2 = *(undefined8 *)(iVar1 + 0xa0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1e32;
        iVar3 = fcn.1801e3b50(uVar2);
        if (iVar3 == 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0xa0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1e46;
            iVar3 = fcn.1801e3ab0(uVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1e5a;
                iVar3 = fcn.1801c1be0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8));
                if (iVar3 != 0) {
                    *(undefined4 *)(in_RCX + 4) = 0xc0103;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1e7a;
                    iVar3 = fcn.1801c21f0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4));
                    if (iVar3 != 0) {
                        *(undefined4 *)((int64_t)&iStackX_20 + iVar4 + -8) = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c1ea6;
                        fcn.1801c12e0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4)
                                      , *(int64_t *)(&stack0x00000030 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar4))
                        ;
                        iVar1 = *(int64_t *)((int64_t)&arg_38h + iVar4);
                        in_RCX[1] = in_RCX[1] + iVar1;
                        in_RCX[2] = in_RCX[2] - iVar1;
                        in_RCX[3] = in_RCX[3] + iVar1;
                        return (uint64_t)(in_RCX[2] == 0);
                    }
                }
            }
        }
    }
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_1801c1ef0
// Address: 0x1801c1ef0
// Size: 551 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable arg_41h
// WARNING: [rz-ghidra] Detected overlap for variable arg_42h

undefined8 fcn.1801c1ef0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *in_RCX;
    uint32_t uVar7;
    int64_t in_RDX;
    int64_t iVar8;
    int64_t in_R8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_30;
    int64_t var_28h;
    int64_t var_8h;
    
    uStack_30 = 0x1801c1f0c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar1 = in_RCX[4];
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = 0;
    iVar8 = in_R8;
    if ((*(uint8_t *)(iVar1 + 0x88) & 4) != 0) {
        if ((((*(uint32_t *)(iVar1 + 0xa8) & 2) == 0) && (*(int64_t *)(iVar1 + 0x90) != in_RDX)) ||
           (in_R8 != *(int64_t *)(iVar1 + 0x98))) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
            *(undefined4 *)((int64_t)&var_8h + iVar5) = 0x7f;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c1f75;
            uVar6 = fcn.1801c1390(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
            return uVar6;
        }
        iVar8 = in_R8 - *(int64_t *)(iVar1 + 0xa0);
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c1f9f;
    iVar4 = fcn.1801c21f0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar5));
    if (iVar4 == 0) {
        puVar2 = *(undefined8 **)((int64_t)&arg_58h + iVar5);
        *(undefined8 *)((int64_t)&iStackX_20 + iVar5 + -0x20) = 0;
        *(undefined4 *)((int64_t)&var_8h + iVar5) = 0xc0103;
        *puVar2 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c1fd7;
        uVar6 = fcn.1801c1390(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
    } else {
        iVar3 = *in_RCX;
        uVar7 = *(uint32_t *)(iVar3 + 0x70);
        while ((uVar7 = uVar7 >> 5 & 3, uVar7 == 0 && (iVar3 = *(int64_t *)(iVar3 + 0x40), iVar3 != 0))) {
            uVar7 = *(uint32_t *)(iVar3 + 0x70);
        }
        *(uint32_t *)((int64_t)&var_8h + iVar5) = (uint32_t)(uVar7 != 2);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1801c2037;
        fcn.1801c12e0(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -0x20), 
                      *(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8));
        iVar3 = *(int64_t *)((int64_t)&arg_38h + iVar5);
        uVar7 = *(uint32_t *)(iVar1 + 0x88) & 4;
        if (iVar3 == iVar8) {
            if (uVar7 == 0) {
                **(int64_t **)((int64_t)&arg_58h + iVar5) = iVar3;
                uVar6 = 1;
            } else {
                **(int64_t **)((int64_t)&arg_58h + iVar5) = *(int64_t *)(iVar1 + 0x98);
                uVar6 = 1;
                *(uint32_t *)(iVar1 + 0x88) = *(uint32_t *)(iVar1 + 0x88) & 0xfffffffb;
                *(undefined8 *)(iVar1 + 0x90) = 0;
                *(undefined8 *)(iVar1 + 0xa0) = 0;
                *(undefined8 *)(iVar1 + 0x98) = 0;
            }
        } else {
            if (uVar7 == 0) {
                if (iVar3 != 0) {
                    *(int64_t *)(iVar1 + 0x90) = in_RDX;
                    *(uint32_t *)(iVar1 + 0x88) = *(uint32_t *)(iVar1 + 0x88) | 4;
                    *(int64_t *)(iVar1 + 0xa0) = iVar3;
                    *(int64_t *)(iVar1 + 0x98) = in_R8;
                }
                **(undefined8 **)((int64_t)&arg_58h + iVar5) = 0;
            } else {
                *(int64_t *)(iVar1 + 0xa0) = *(int64_t *)(iVar1 + 0xa0) + iVar3;
            }
            if (*(int32_t *)((int64_t)in_RCX + 0x34) != 0) {
                if (*(int32_t *)(in_RCX + 5) == 0) {
                    if (in_RCX[3] != 0) {
                        *(undefined4 *)(in_RCX[3] + 0x128) = 3;
                    }
                } else if (in_RCX[4] != 0) {
                    *(undefined4 *)(in_RCX[4] + 0xb8) = 3;
                }
            }
            uVar6 = 0;
        }
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801c2120
// Address: 0x1801c2120
// Size: 57 bytes
// ============================================================
bool fcn.1801c2120(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c212a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c2136;
    iVar1 = fcn.180194f30(*(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if ((iVar1 != 4) && (iVar1 != 7)) {
        return iVar1 == 8;
    }
    return true;
}

// ============================================================
// Function: FUN_1801c2160
// Address: 0x1801c2160
// Size: 138 bytes
// ============================================================
undefined8 fcn.1801c2160(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    uint32_t in_EDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c216a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((in_EDX >> 8 & 1) != 0) {
        return 1;
    }
    in_EDX = in_EDX & 0x87;
    if (in_EDX == 0x80) {
        uVar3 = 0x1a6;
    } else if (in_EDX == 4) {
        uVar3 = 0x1a5;
    } else if (in_EDX == 1) {
        uVar3 = 0x164;
    } else {
        uVar3 = 0x8010c;
        if (in_EDX - 2 < 2) {
            uVar3 = 0x163;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = uVar3;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c21e5;
    uVar2 = fcn.1801c1390(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_1801c21f0
// Address: 0x1801c21f0
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801c21f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c220e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801c2230;
    uVar4 = func_0x0001801dd6c0(uVar1);
    iVar6 = *(int64_t *)(in_RCX + 0x80);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801c2243;
    uVar5 = func_0x0001801dd6c0(iVar6 + 0x80);
    uVar7 = uVar5 - uVar4;
    if (uVar5 < uVar4) {
        uVar7 = 0;
    }
    if (uVar7 < in_R8) {
        in_R8 = uVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801c2261;
    iVar6 = func_0x0001801bc820(uVar1);
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801c226c;
    uVar7 = func_0x0001801e6200(uVar1);
    if ((uVar7 < in_R8) && (iVar6 != 0x600000)) {
        uVar7 = (iVar6 - uVar7) + in_R8;
        if (0x600000 < uVar7) {
            uVar7 = 0x600000;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801c2291;
        iVar2 = func_0x0001801e6770(uVar1, uVar7);
        if (iVar2 == 0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1801c22a6;
    func_0x0001801e5fa0(uVar1, in_RDX, in_R8, in_R9);
    return;
}

// ============================================================
// Function: FUN_1801c22c0
// Address: 0x1801c22c0
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c22c0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint32_t uVar3;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c22d0;
    iVar2 = fcn.18045a350();
    uVar3 = *(uint32_t *)(in_RCX + 0xb0) >> 1 & 1;
    iVar1 = *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x78);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801c22f9;
        func_0x0001801e6fe0(iVar1, uVar3);
    }
    iVar1 = *(int64_t *)(*(int64_t *)(in_RCX + 0x80) + 0x70);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801c2310;
        func_0x0001801e67a0(iVar1, uVar3);
    }
    return;
}

// ============================================================
// Function: FUN_1801c2320
// Address: 0x1801c2320
// Size: 24 bytes
// ============================================================
undefined8 fcn.1801c2320(int64_t arg_30h, int64_t arg_38h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h)
{
    undefined8 uVar1;
    code *pcVar2;
    int64_t iVar3;
    bool bVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint64_t uVar12;
    int64_t in_RCX;
    int64_t iVar13;
    uint64_t uVar14;
    undefined *puVar15;
    undefined8 unaff_RBX;
    char cVar16;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar17;
    undefined8 unaff_RDI;
    undefined4 uVar18;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_18 [3];
    
    auStack_18[2] = 0x1801c232a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar14 = 0x16;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_10h + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_18 + iVar7 + 0x10) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_18 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_18 + iVar7) = 0x1801ca8ba;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar1 = *(undefined8 *)(in_RCX + 0x40);
    bVar4 = true;
    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801ca8d2;
    iVar5 = func_0x0001801c2dc0();
    if (iVar5 != 0) {
        iVar13 = *(int64_t *)(in_RCX + 0x4f0);
        uVar12 = *(uint64_t *)(iVar13 + 0x130);
        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801ca8f0;
        uVar9 = func_0x0001801c2c40(in_RCX);
        if ((uVar9 <= uVar12) &&
           (((cVar16 = (char)uVar14, *(int64_t *)(in_RCX + 0x110) != 0 || (cVar16 != '\x16')) ||
            (*(int64_t *)(in_RCX + 0x108) == *(int64_t *)(iVar13 + 0x140) + 0xc)))) {
            uVar11 = *(undefined8 *)(in_RCX + 0xc80);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0xc70) + 0xa8);
            *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801ca938;
            iVar10 = (*pcVar2)(uVar11);
            iVar13 = *(int64_t *)(in_RCX + 0x108);
            iVar17 = 0;
            *(undefined4 *)(in_RCX + 0x68) = 1;
            if (iVar13 != 0) {
                uVar18 = *(undefined4 *)((int64_t)&arg_38h + iVar8 + iVar7);
                *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar7) = *(undefined8 *)((int64_t)&arg_30h + iVar8 + iVar7);
                do {
                    if ((cVar16 == '\x16') && (uVar12 = *(uint64_t *)(in_RCX + 0x110), uVar12 != 0)) {
                        if (iVar17 == 0) {
                            iVar17 = *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x150);
                        } else {
                            if (uVar12 < 0xd) {
                                return 0xffffffff;
                            }
                            *(uint64_t *)(in_RCX + 0x110) = uVar12 - 0xc;
                            *(int64_t *)(in_RCX + 0x108) = iVar13 + 0xc;
                        }
                    }
                    uVar11 = *(undefined8 *)(in_RCX + 0x58);
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801ca9c2;
                    iVar5 = func_0x000180219d10(uVar11, 0xd, 0, 0);
                    uVar12 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130);
                    uVar9 = uVar12 - (iVar5 + iVar10);
                    if (uVar12 <= (uint64_t)(iVar5 + iVar10)) {
                        uVar9 = 0;
                    }
                    if (uVar9 < 0xd) {
                        uVar11 = *(undefined8 *)(in_RCX + 0x58);
                        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801caa02;
                        uVar11 = func_0x000180219d10(uVar11, 0xb, 0, 0);
                        if ((int32_t)uVar11 < 1) {
                            *(undefined4 *)(in_RCX + 0x68) = 2;
                            return uVar11;
                        }
                        uVar9 = *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130);
                        if (uVar9 <= iVar10 + 0xcU) {
                            return 0xffffffff;
                        }
                        uVar9 = uVar9 - iVar10;
                    }
                    if (*(uint32_t *)(in_RCX + 0x108) <= uVar9) {
                        uVar9 = *(uint64_t *)(in_RCX + 0x108);
                    }
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801caa42;
                    uVar6 = func_0x0001801976c0(in_RCX);
                    if (uVar6 < uVar9) {
                        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801caa51;
                        uVar6 = func_0x0001801976c0(in_RCX);
                        uVar9 = (uint64_t)uVar6;
                    }
                    if (cVar16 == '\x16') {
                        if (uVar9 < 0xc) {
                            return 0xffffffff;
                        }
                        iVar13 = *(int64_t *)(in_RCX + 0x4f0);
                        *(int64_t *)(iVar13 + 0x150) = iVar17;
                        *(uint64_t *)(iVar13 + 0x158) = uVar9 - 0xc;
                        if ((*(int64_t *)(in_RCX + 0x4f8) != 0) && (iVar13 = *(int64_t *)(in_RCX + 0x110), iVar13 != 0))
                        {
                            iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                            uVar18 = *(undefined4 *)(iVar3 + 8 + iVar13);
                            *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar7) = *(undefined8 *)(iVar3 + iVar13);
                        }
                        iVar13 = *(int64_t *)(in_RCX + 0x4f0);
                        puVar15 = (undefined *)
                                  (*(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + *(int64_t *)(in_RCX + 0x110));
                        *puVar15 = *(undefined *)(iVar13 + 0x138);
                        puVar15[1] = *(undefined *)(iVar13 + 0x142);
                        puVar15[2] = *(undefined *)(iVar13 + 0x141);
                        puVar15[3] = *(undefined *)(iVar13 + 0x140);
                        puVar15[4] = *(undefined *)(iVar13 + 0x149);
                        puVar15[5] = *(undefined *)(iVar13 + 0x148);
                        puVar15[6] = *(undefined *)(iVar13 + 0x152);
                        puVar15[7] = *(undefined *)(iVar13 + 0x151);
                        puVar15[8] = *(undefined *)(iVar13 + 0x150);
                        puVar15[9] = *(undefined *)(iVar13 + 0x15a);
                        puVar15[10] = *(undefined *)(iVar13 + 0x159);
                        puVar15[0xb] = *(undefined *)(iVar13 + 0x158);
                    }
                    *(int64_t *)((int64_t)&var_10h + iVar8 + iVar7) = (int64_t)&arg_80h + iVar8 + iVar7;
                    *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cab72;
                    iVar5 = func_0x0001801c8060(in_RCX, uVar14 & 0xff);
                    if (((cVar16 == '\x16') && (*(int64_t *)(in_RCX + 0x4f8) != 0)) &&
                       (iVar13 = *(int64_t *)(in_RCX + 0x110), iVar13 != 0)) {
                        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
                        *(undefined8 *)(iVar3 + iVar13) = *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar7);
                        *(undefined4 *)(iVar3 + 8 + iVar13) = uVar18;
                    }
                    if (iVar5 < 1) {
                        if (!bVar4) {
                            return 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cabc2;
                        uVar11 = func_0x000180193e90(in_RCX);
                        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cabd5;
                        iVar5 = func_0x000180219d10(uVar11, 0x2b, 0, 0);
                        if (iVar5 < 1) {
                            return 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cabe5;
                        uVar12 = func_0x000180193b40(in_RCX);
                        if ((uVar12 >> 0xc & 1) != 0) {
                            return 0xffffffff;
                        }
                        *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cabf8;
                        iVar5 = func_0x0001801c2dc0(in_RCX);
                        if (iVar5 == 0) {
                            return 0xffffffff;
                        }
                        bVar4 = false;
                    } else {
                        uVar12 = *(uint64_t *)((int64_t)&arg_80h + iVar8 + iVar7);
                        if (uVar9 != uVar12) {
                            return 0xffffffff;
                        }
                        if ((cVar16 == '\x16') &&
                           (iVar13 = *(int64_t *)(in_RCX + 0x4f0), *(int32_t *)(iVar13 + 0x1cc) == 0)) {
                            puVar15 = (undefined *)
                                      (*(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + *(int64_t *)(in_RCX + 0x110));
                            if ((iVar17 == 0) && (*(int32_t *)(in_RCX + 0x48) != 0x100)) {
                                *puVar15 = *(undefined *)(iVar13 + 0x138);
                                puVar15[1] = *(undefined *)(iVar13 + 0x142);
                                puVar15[2] = *(undefined *)(iVar13 + 0x141);
                                puVar15[3] = *(undefined *)(iVar13 + 0x140);
                                puVar15[4] = *(undefined *)(iVar13 + 0x149);
                                puVar15[5] = *(undefined *)(iVar13 + 0x148);
                                *(undefined2 *)(puVar15 + 6) = 0;
                                puVar15[8] = 0;
                                puVar15[9] = *(undefined *)(iVar13 + 0x142);
                                puVar15[10] = *(undefined *)(iVar13 + 0x141);
                                puVar15[0xb] = *(undefined *)(iVar13 + 0x140);
                            } else {
                                puVar15 = puVar15 + 0xc;
                            }
                            *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cacef;
                            iVar5 = func_0x0001801dac70(in_RCX, puVar15);
                            if (iVar5 == 0) {
                                return 0xffffffff;
                            }
                            uVar12 = *(uint64_t *)((int64_t)&arg_80h + iVar8 + iVar7);
                        }
                        uVar9 = *(uint64_t *)(in_RCX + 0x108);
                        if (uVar12 == uVar9) {
                            pcVar2 = *(code **)(in_RCX + 0x4f8);
                            if (pcVar2 != (code *)0x0) {
                                iVar13 = *(int64_t *)(in_RCX + 0x110);
                                iVar17 = *(int64_t *)(in_RCX + 0xf8);
                                *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = *(undefined8 *)(in_RCX + 0x500);
                                *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = uVar1;
                                uVar1 = *(undefined8 *)(iVar17 + 8);
                                *(uint64_t *)((int64_t)&var_10h + iVar8 + iVar7) = iVar13 + uVar9;
                                uVar18 = *(undefined4 *)(in_RCX + 0x48);
                                *(undefined8 *)((int64_t)auStack_18 + iVar8 + iVar7) = 0x1801cada6;
                                (*pcVar2)(1, uVar18, uVar14 & 0xff, uVar1);
                            }
                            *(undefined8 *)(in_RCX + 0x110) = 0;
                            *(undefined8 *)(in_RCX + 0x108) = 0;
                            return 1;
                        }
                        *(int64_t *)(in_RCX + 0x110) = *(int64_t *)(in_RCX + 0x110) + uVar12;
                        iVar13 = *(int64_t *)(in_RCX + 0x4f0);
                        *(uint64_t *)(in_RCX + 0x108) = uVar9 - uVar12;
                        iVar17 = iVar17 + (uVar12 - 0xc);
                        *(uint64_t *)((int64_t)&arg_80h + iVar8 + iVar7) = uVar12 - 0xc;
                        *(int64_t *)(iVar13 + 0x150) = iVar17;
                        *(undefined8 *)(iVar13 + 0x158) = 0;
                    }
                    iVar13 = *(int64_t *)(in_RCX + 0x108);
                } while (iVar13 != 0);
            }
            return 0;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801c2340
// Address: 0x1801c2340
// Size: 198 bytes
// ============================================================
undefined8 fcn.1801c2340(int64_t param_1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c234c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = (int32_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x1b8);
    *piVar1 = *piVar1 + 1;
    if (2 < *(uint32_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x1b8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2374;
        uVar4 = func_0x000180193b40();
        if ((uVar4 >> 0xc & 1) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2383;
            uVar5 = func_0x000180193e90(param_1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2396;
            iVar2 = func_0x000180219d10(uVar5, 0x2f, 0, 0);
            if ((uint64_t)(int64_t)iVar2 < *(uint64_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x130)) {
                *(int64_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x130) = (int64_t)iVar2;
            }
        }
    }
    if (0xc < *(uint32_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x1b8)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c23c5;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c23dd;
        func_0x0001802295a0(0x1804b05f8, 0x181, 0x1804b0608);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c23f3;
        func_0x00018019b5e0(param_1, 0xffffffff, 0x138, 0);
        return 0xffffffff;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c2410
// Address: 0x1801c2410
// Size: 73 bytes
// ============================================================
undefined8 fcn.1801c2410(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c241d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (in_RCX != (int32_t *)0x0) {
        piVar11 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar11 = in_RCX;
        }
        if (piVar11 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c2449;
            func_0x0001801c71d0(piVar11 + 0x314);
            iVar1 = *(int64_t *)(piVar11 + 0x13c);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar9) = unaff_RBX;
                uVar2 = *(undefined8 *)(iVar1 + 0x1d0);
                *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
                uVar3 = *(undefined8 *)(iVar1 + 0x118);
                *(undefined8 *)((int64_t)&arg_40h + iVar9) = unaff_R12;
                uVar4 = *(undefined8 *)(iVar1 + 0x128);
                *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R14;
                uVar5 = *(undefined8 *)(iVar1 + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar9) = unaff_R15;
                uVar6 = *(undefined8 *)(iVar1 + 0x130);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c249d;
                func_0x0001801c25a0(piVar11);
                uVar7 = *(undefined8 *)(piVar11 + 0x13c);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24b1;
                func_0x0001804986e0(uVar7, 0, 0x1d8);
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x1d0) = uVar2;
                if (piVar11[0x1e] != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x100) = 0xff;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24e4;
                uVar10 = func_0x000180193b40(in_RCX);
                if ((uVar10 >> 0xc & 1) != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x130) = uVar6;
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x128) = uVar4;
                }
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x118) = uVar3;
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x120) = uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c253f;
            iVar8 = func_0x0001801c37d0(in_RCX);
            if (iVar8 != 0) {
                iVar8 = **(int32_t **)(in_RCX + 6);
                if (iVar8 == 0x1ffff) {
                    piVar11[0x12] = 0xfefd;
                    return 1;
                }
                if (((uint32_t)piVar11[0x26a] >> 0xf & 1) != 0) {
                    iVar8 = 0x100;
                    piVar11[0x273] = 0x100;
                }
                piVar11[0x12] = iVar8;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c2459
// Address: 0x1801c2459
// Size: 113 bytes
// ============================================================
undefined8 fcn.1801c2410(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c241d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (in_RCX != (int32_t *)0x0) {
        piVar11 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar11 = in_RCX;
        }
        if (piVar11 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c2449;
            func_0x0001801c71d0(piVar11 + 0x314);
            iVar1 = *(int64_t *)(piVar11 + 0x13c);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar9) = unaff_RBX;
                uVar2 = *(undefined8 *)(iVar1 + 0x1d0);
                *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
                uVar3 = *(undefined8 *)(iVar1 + 0x118);
                *(undefined8 *)((int64_t)&arg_40h + iVar9) = unaff_R12;
                uVar4 = *(undefined8 *)(iVar1 + 0x128);
                *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R14;
                uVar5 = *(undefined8 *)(iVar1 + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar9) = unaff_R15;
                uVar6 = *(undefined8 *)(iVar1 + 0x130);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c249d;
                func_0x0001801c25a0(piVar11);
                uVar7 = *(undefined8 *)(piVar11 + 0x13c);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24b1;
                func_0x0001804986e0(uVar7, 0, 0x1d8);
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x1d0) = uVar2;
                if (piVar11[0x1e] != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x100) = 0xff;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24e4;
                uVar10 = func_0x000180193b40(in_RCX);
                if ((uVar10 >> 0xc & 1) != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x130) = uVar6;
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x128) = uVar4;
                }
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x118) = uVar3;
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x120) = uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c253f;
            iVar8 = func_0x0001801c37d0(in_RCX);
            if (iVar8 != 0) {
                iVar8 = **(int32_t **)(in_RCX + 6);
                if (iVar8 == 0x1ffff) {
                    piVar11[0x12] = 0xfefd;
                    return 1;
                }
                if (((uint32_t)piVar11[0x26a] >> 0xf & 1) != 0) {
                    iVar8 = 0x100;
                    piVar11[0x273] = 0x100;
                }
                piVar11[0x12] = iVar8;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c24ca
// Address: 0x1801c24ca
// Size: 109 bytes
// ============================================================
undefined8 fcn.1801c2410(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c241d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (in_RCX != (int32_t *)0x0) {
        piVar11 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar11 = in_RCX;
        }
        if (piVar11 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c2449;
            func_0x0001801c71d0(piVar11 + 0x314);
            iVar1 = *(int64_t *)(piVar11 + 0x13c);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar9) = unaff_RBX;
                uVar2 = *(undefined8 *)(iVar1 + 0x1d0);
                *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
                uVar3 = *(undefined8 *)(iVar1 + 0x118);
                *(undefined8 *)((int64_t)&arg_40h + iVar9) = unaff_R12;
                uVar4 = *(undefined8 *)(iVar1 + 0x128);
                *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R14;
                uVar5 = *(undefined8 *)(iVar1 + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar9) = unaff_R15;
                uVar6 = *(undefined8 *)(iVar1 + 0x130);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c249d;
                func_0x0001801c25a0(piVar11);
                uVar7 = *(undefined8 *)(piVar11 + 0x13c);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24b1;
                func_0x0001804986e0(uVar7, 0, 0x1d8);
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x1d0) = uVar2;
                if (piVar11[0x1e] != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x100) = 0xff;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24e4;
                uVar10 = func_0x000180193b40(in_RCX);
                if ((uVar10 >> 0xc & 1) != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x130) = uVar6;
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x128) = uVar4;
                }
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x118) = uVar3;
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x120) = uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c253f;
            iVar8 = func_0x0001801c37d0(in_RCX);
            if (iVar8 != 0) {
                iVar8 = **(int32_t **)(in_RCX + 6);
                if (iVar8 == 0x1ffff) {
                    piVar11[0x12] = 0xfefd;
                    return 1;
                }
                if (((uint32_t)piVar11[0x26a] >> 0xf & 1) != 0) {
                    iVar8 = 0x100;
                    piVar11[0x273] = 0x100;
                }
                piVar11[0x12] = iVar8;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c2537
// Address: 0x1801c2537
// Size: 94 bytes
// ============================================================
undefined8 fcn.1801c2410(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined8 uVar7;
    int32_t iVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int32_t *piVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    undefined8 uStack_18;
    
    uStack_18 = 0x1801c241d;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    if (in_RCX != (int32_t *)0x0) {
        piVar11 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar11 = in_RCX;
        }
        if (piVar11 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c2449;
            func_0x0001801c71d0(piVar11 + 0x314);
            iVar1 = *(int64_t *)(piVar11 + 0x13c);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_30h + iVar9) = unaff_RBX;
                uVar2 = *(undefined8 *)(iVar1 + 0x1d0);
                *(undefined8 *)((int64_t)&arg_38h + iVar9) = unaff_RBP;
                uVar3 = *(undefined8 *)(iVar1 + 0x118);
                *(undefined8 *)((int64_t)&arg_40h + iVar9) = unaff_R12;
                uVar4 = *(undefined8 *)(iVar1 + 0x128);
                *(undefined8 *)((int64_t)&arg_48h + iVar9) = unaff_R14;
                uVar5 = *(undefined8 *)(iVar1 + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar9) = unaff_R15;
                uVar6 = *(undefined8 *)(iVar1 + 0x130);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c249d;
                func_0x0001801c25a0(piVar11);
                uVar7 = *(undefined8 *)(piVar11 + 0x13c);
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24b1;
                func_0x0001804986e0(uVar7, 0, 0x1d8);
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x1d0) = uVar2;
                if (piVar11[0x1e] != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x100) = 0xff;
                }
                *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c24e4;
                uVar10 = func_0x000180193b40(in_RCX);
                if ((uVar10 >> 0xc & 1) != 0) {
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x130) = uVar6;
                    *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x128) = uVar4;
                }
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x118) = uVar3;
                *(undefined8 *)(*(int64_t *)(piVar11 + 0x13c) + 0x120) = uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar9) = 0x1801c253f;
            iVar8 = func_0x0001801c37d0(in_RCX);
            if (iVar8 != 0) {
                iVar8 = **(int32_t **)(in_RCX + 6);
                if (iVar8 == 0x1ffff) {
                    piVar11[0x12] = 0xfefd;
                    return 1;
                }
                if (((uint32_t)piVar11[0x26a] >> 0xf & 1) != 0) {
                    iVar8 = 0x100;
                    piVar11[0x273] = 0x100;
                }
                piVar11[0x12] = iVar8;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c25a0
// Address: 0x1801c25a0
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c25a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c25b0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25c9;
    iVar5 = func_0x0001801a6800(uVar1);
    while (iVar5 != 0) {
        uVar1 = *(undefined8 *)(iVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25da;
        func_0x0001801cae70(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25e2;
        func_0x0001801a65e0(iVar5);
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25f5;
        iVar5 = func_0x0001801a6800(uVar1);
    }
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = uVar7;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x1801c2690;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26a9;
    iVar6 = func_0x0001801a6800(uVar7);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar4) = uVar1;
        do {
            iVar2 = *(int64_t *)(iVar6 + 8);
            if (((*(int32_t *)(iVar2 + 0x28) != 0) && (*(int64_t *)(iVar2 + 0x30) != 0)) &&
               (*(int64_t *)(in_RCX + 0xc80) != *(int64_t *)(iVar2 + 0x38))) {
                pcVar3 = *(code **)(*(int64_t *)(iVar2 + 0x30) + 8);
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26dc;
                (*pcVar3)();
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26e4;
            func_0x0001801cae70(iVar2);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ec;
            func_0x0001801a65e0(iVar6);
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ff;
            iVar6 = func_0x0001801a6800(uVar1);
        } while (iVar6 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801c2610
// Address: 0x1801c2610
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c2610(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2620;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2639;
    iVar3 = func_0x0001801a6800(uVar1);
    while (iVar3 != 0) {
        uVar1 = *(undefined8 *)(iVar3 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c264a;
        func_0x0001801cae70(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2652;
        func_0x0001801a65e0(iVar3);
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2665;
        iVar3 = func_0x0001801a6800(uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_1801c2680
// Address: 0x1801c2680
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c25a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c25b0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25c9;
    iVar5 = func_0x0001801a6800(uVar1);
    while (iVar5 != 0) {
        uVar1 = *(undefined8 *)(iVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25da;
        func_0x0001801cae70(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25e2;
        func_0x0001801a65e0(iVar5);
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25f5;
        iVar5 = func_0x0001801a6800(uVar1);
    }
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = uVar7;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x1801c2690;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26a9;
    iVar6 = func_0x0001801a6800(uVar7);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar4) = uVar1;
        do {
            iVar2 = *(int64_t *)(iVar6 + 8);
            if (((*(int32_t *)(iVar2 + 0x28) != 0) && (*(int64_t *)(iVar2 + 0x30) != 0)) &&
               (*(int64_t *)(in_RCX + 0xc80) != *(int64_t *)(iVar2 + 0x38))) {
                pcVar3 = *(code **)(*(int64_t *)(iVar2 + 0x30) + 8);
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26dc;
                (*pcVar3)();
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26e4;
            func_0x0001801cae70(iVar2);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ec;
            func_0x0001801a65e0(iVar6);
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ff;
            iVar6 = func_0x0001801a6800(uVar1);
        } while (iVar6 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801c26b1
// Address: 0x1801c26b1
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c25a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c25b0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25c9;
    iVar5 = func_0x0001801a6800(uVar1);
    while (iVar5 != 0) {
        uVar1 = *(undefined8 *)(iVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25da;
        func_0x0001801cae70(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25e2;
        func_0x0001801a65e0(iVar5);
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25f5;
        iVar5 = func_0x0001801a6800(uVar1);
    }
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = uVar7;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x1801c2690;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26a9;
    iVar6 = func_0x0001801a6800(uVar7);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar4) = uVar1;
        do {
            iVar2 = *(int64_t *)(iVar6 + 8);
            if (((*(int32_t *)(iVar2 + 0x28) != 0) && (*(int64_t *)(iVar2 + 0x30) != 0)) &&
               (*(int64_t *)(in_RCX + 0xc80) != *(int64_t *)(iVar2 + 0x38))) {
                pcVar3 = *(code **)(*(int64_t *)(iVar2 + 0x30) + 8);
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26dc;
                (*pcVar3)();
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26e4;
            func_0x0001801cae70(iVar2);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ec;
            func_0x0001801a65e0(iVar6);
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ff;
            iVar6 = func_0x0001801a6800(uVar1);
        } while (iVar6 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801c270c
// Address: 0x1801c270c
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c25a0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 uVar7;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c25b0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25c9;
    iVar5 = func_0x0001801a6800(uVar1);
    while (iVar5 != 0) {
        uVar1 = *(undefined8 *)(iVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25da;
        func_0x0001801cae70(uVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25e2;
        func_0x0001801a65e0(iVar5);
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x118);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c25f5;
        iVar5 = func_0x0001801a6800(uVar1);
    }
    uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = uVar7;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x1801c2690;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26a9;
    iVar6 = func_0x0001801a6800(uVar7);
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar4) = uVar1;
        do {
            iVar2 = *(int64_t *)(iVar6 + 8);
            if (((*(int32_t *)(iVar2 + 0x28) != 0) && (*(int64_t *)(iVar2 + 0x30) != 0)) &&
               (*(int64_t *)(in_RCX + 0xc80) != *(int64_t *)(iVar2 + 0x38))) {
                pcVar3 = *(code **)(*(int64_t *)(iVar2 + 0x30) + 8);
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26dc;
                (*pcVar3)();
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26e4;
            func_0x0001801cae70(iVar2);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ec;
            func_0x0001801a65e0(iVar6);
            uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
            *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x1801c26ff;
            iVar6 = func_0x0001801a6800(uVar1);
        } while (iVar6 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801c2720
// Address: 0x1801c2720
// Size: 394 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_47h
// WARNING: [rz-ghidra] Detected overlap for variable arg_46h
// WARNING: [rz-ghidra] Removing arg arg_c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c80h because it doesn't fit into ProtoModel

int32_t * fcn.1801c2720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                       int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                       int64_t arg_78h, int64_t arg_f8h, int64_t arg_108h)
{
    undefined2 uVar1;
    code *pcVar2;
    undefined *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint16_t uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t *piVar14;
    int32_t *in_RCX;
    int16_t iVar15;
    int32_t in_EDX;
    undefined8 uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    undefined8 uVar18;
    undefined8 uVar19;
    int32_t *piVar20;
    int32_t iVar21;
    uint64_t in_R8;
    uint64_t uVar22;
    int64_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iVar23;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2735;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar8 = 0;
    piVar14 = piVar20;
    if (*in_RCX == 0) {
        piVar14 = in_RCX;
    }
    if (piVar14 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar21 = (int32_t)in_R8;
    if (in_EDX == 0x11) {
        if (iVar21 < 0xd0) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar21;
        return (int32_t *)(in_R8 & 0xffffffff);
    }
    if (in_EDX == 0x49) {
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2808;
            uVar11 = func_0x0001802450c0();
            if (*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) < uVar11) {
                iVar8 = -1;
                piVar14 = piVar20;
            } else {
                piVar14 = (int32_t *)(*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) - uVar11);
                if (piVar14 < (int32_t *)0xe4e1c1) {
                    if (piVar14 < (int32_t *)0xe4e1c0) {
                        iVar8 = -1;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            if (0 < iVar8) {
                piVar20 = piVar14;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2851;
            iVar10 = func_0x0001801c30c0(piVar20);
            *in_R9 = iVar10;
            piVar20 = (int32_t *)0x1;
        }
        return piVar20;
    }
    if (in_EDX == 0x4a) {
        uVar19 = *(undefined8 *)((int64_t)&var_18h + iVar10);
        *(undefined8 *)((int64_t)&arg_38h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
        iVar23 = iVar10 + 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar10) = *(undefined8 *)((int64_t)&arg_30h + iVar10);
        *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c2970;
        iVar13 = fcn.18045a350();
        iVar13 = -iVar13;
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2990;
            uVar11 = func_0x0001802450c0();
            iVar12 = *(int64_t *)(piVar14 + 0x13c);
            iVar17 = -1;
            if (*(uint64_t *)(iVar12 + 0x1c0) < uVar11) {
                iVar8 = -1;
                uVar11 = 0;
            } else {
                uVar11 = *(uint64_t *)(iVar12 + 0x1c0) - uVar11;
                if (uVar11 < 0xe4e1c1) {
                    if (uVar11 < 15000000) {
                        iVar8 = -1;
                    } else {
                        iVar8 = 0;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            uVar22 = 0;
            if (0 < iVar8) {
                uVar22 = uVar11;
            }
            if (uVar22 == 0) {
                pcVar2 = *(code **)(iVar12 + 0x1d0);
                if (pcVar2 == (code *)0x0) {
                    *(int32_t *)(iVar12 + 0x1c8) = *(int32_t *)(iVar12 + 0x1c8) * 2;
                    if (60000000 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8)) {
                        *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = 60000000;
                    }
                } else {
                    uVar18 = *(undefined8 *)(piVar14 + 0x10);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c29f7;
                    uVar7 = (*pcVar2)(uVar18);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = uVar7;
                }
                *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) =
                     *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) + 1;
                if (2 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a51;
                    uVar11 = func_0x000180193b40(piVar14);
                    if ((uVar11 >> 0xc & 1) == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a60;
                        uVar18 = func_0x000180193e90(piVar14);
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a73;
                        iVar8 = func_0x000180219d10(uVar18, 0x2f, 0, 0);
                        if ((uint64_t)(int64_t)iVar8 < *(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130)) {
                            *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar8;
                        }
                    }
                }
                iVar12 = *(int64_t *)(piVar14 + 0x13c);
                if (0xc < *(uint32_t *)(iVar12 + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aa2;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aba;
                    func_0x0001802295a0(0x1804b05f8, 0x181, 0x1804b0608);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2acd;
                    func_0x00018019b5e0(piVar14, 0xffffffff, 0x138, 0);
                    return (int32_t *)0xffffffff;
                }
                iVar5 = *(int64_t *)(iVar12 + 0x1c0);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) = uVar19;
                if (iVar5 == 0) {
                    pcVar2 = *(code **)(iVar12 + 0x1d0);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined4 *)(iVar12 + 0x1c8) = 1000000;
                    } else {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b00;
                        uVar7 = (*pcVar2)(piVar14, 0);
                        *(undefined4 *)(iVar12 + 0x1c8) = uVar7;
                    }
                }
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) * 1000;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b2b;
                iVar12 = func_0x0001802450c0();
                if (uVar11 < -iVar12 - 1U || uVar11 - (-iVar12 - 1U) == 0) {
                    iVar17 = iVar12 + uVar11;
                }
                *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) = iVar17;
                iVar17 = *(int64_t *)(piVar14 + 0x13c);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b57;
                uVar18 = func_0x000180193c40(piVar14);
                uVar19 = *(undefined8 *)(iVar17 + 0x1c0);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b66;
                uVar19 = func_0x0001801c30c0(uVar19);
                *(undefined8 *)((int64_t)&arg_48h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b80;
                func_0x000180219d10(uVar18, 0x2d, 0, (int64_t)&arg_48h + iVar13 + iVar10);
                uVar19 = *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_60h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&arg_30h + iVar13 + iVar10) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_28h + iVar13 + iVar10) = unaff_R13;
                *(undefined8 *)((int64_t)&var_20h + iVar13 + iVar10) = unaff_R14;
                *(undefined8 *)((int64_t)&var_18h + iVar13 + iVar10) = unaff_R15;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801cb802;
                iVar10 = fcn.18045a350();
                iVar10 = -iVar10;
                *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18) =
                     *(uint64_t *)0x1806a3940 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18;
                uVar19 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb82a;
                uVar19 = func_0x00018001ed90(uVar19);
                *(undefined8 *)((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb839;
                iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                do {
                    if (iVar17 == 0) {
code_r0x0001801cb9bc:
                        uVar11 = *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9c9;
                        piVar20 = (int32_t *)
                                  func_0x000180459870(uVar11 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18);
                        return piVar20;
                    }
                    iVar17 = *(int64_t *)(iVar17 + 8);
                    *(undefined8 *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18) = 0;
                    iVar15 = *(int16_t *)(iVar17 + 0x10) * 2 - *(int16_t *)(iVar17 + 0x28);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x11) = (char)iVar15;
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x12) = (char)((uint16_t)iVar15 >> 8);
                    uVar19 = *(undefined8 *)(iVar17 + 0x120);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb89b;
                    iVar17 = func_0x0001801a6680(uVar19, (int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18);
                    if (iVar17 == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ec;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba04;
                        func_0x0001802295a0(0x1804b3a00, 0x4bb, 0x1804b3aa0);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba1a;
                        func_0x00018019b5e0(piVar14, 0x50, 0xc0103, 0);
                        goto code_r0x0001801cb9bc;
                    }
                    puVar3 = *(undefined **)(iVar17 + 8);
                    iVar12 = 1;
                    iVar17 = *(int64_t *)(puVar3 + 8);
                    uVar19 = *(undefined8 *)(puVar3 + 0x40);
                    if (*(int32_t *)(puVar3 + 0x28) == 0) {
                        iVar12 = 0xc;
                    }
                    uVar18 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x3e) + 8);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb8d0;
                    func_0x000180498030(uVar18, uVar19, iVar17 + iVar12);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(int64_t *)(piVar14 + 0x42) = *(int64_t *)(puVar3 + 8) + iVar12;
                    uVar1 = *(undefined2 *)(puVar3 + 0x10);
                    uVar19 = *(undefined8 *)(puVar3 + 8);
                    uVar18 = *(undefined8 *)(puVar3 + 0x20);
                    *(undefined *)(iVar17 + 0x138) = *puVar3;
                    *(undefined8 *)(iVar17 + 0x140) = uVar19;
                    *(undefined2 *)(iVar17 + 0x148) = uVar1;
                    *(undefined8 *)(iVar17 + 0x158) = uVar18;
                    *(undefined8 *)(iVar17 + 0x150) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x31c);
                    uVar18 = *(undefined8 *)(piVar14 + 800);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 1;
                    iVar17 = *(int64_t *)(puVar3 + 0x30);
                    uVar16 = *(undefined8 *)(piVar14 + 0x16);
                    *(int64_t *)(piVar14 + 0x31c) = iVar17;
                    uVar4 = *(undefined8 *)(puVar3 + 0x38);
                    *(undefined8 *)(piVar14 + 800) = uVar4;
                    pcVar2 = *(code **)(iVar17 + 0x58);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb959;
                    (*pcVar2)(uVar4, uVar16);
                    uVar16 = 0x16;
                    if (*(int32_t *)(puVar3 + 0x28) != 0) {
                        uVar16 = 0x14;
                    }
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb96e;
                    iVar8 = func_0x0001801ca8a0(piVar14, uVar16);
                    *(undefined8 *)(piVar14 + 0x31c) = uVar19;
                    *(undefined8 *)(piVar14 + 800) = uVar18;
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x16);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9a0;
                    func_0x000180219d10(uVar19, 0xb, 0);
                    if (iVar8 < 1) goto code_r0x0001801cb9bc;
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ae;
                    iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                } while( true );
            }
        }
        return (int32_t *)0x0;
    }
    if (in_EDX == 0x78) {
        if (iVar21 < 0x100) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x128) = (int64_t)iVar21;
        return (int32_t *)0x1;
    }
    if (in_EDX == 0x79) {
        return (int32_t *)0x100;
    }
    uVar19 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
    uVar18 = *(undefined8 *)((int64_t)&var_18h + iVar10);
    *(undefined8 *)((int64_t)&arg_30h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = uVar19;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = uVar18;
    *(undefined8 *)((int64_t)&var_8h + iVar10) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c3a2c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar11 = 0;
    iVar8 = (int32_t)in_R8;
    iVar23 = (int64_t)iVar8;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x0001801c3b04;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3a65;
            piVar14 = (int32_t *)func_0x0001801bda50();
            *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
            if (piVar14 != (int32_t *)0x0) goto code_r0x0001801c3a76;
        }
        goto code_r0x0001801c3b04;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
    piVar14 = in_RCX;
code_r0x0001801c3a76:
    // switch table (141 cases) at 0x1801c43e8
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ada;
            func_0x000180229480();
            uVar19 = 0xdef;
            goto code_r0x0001801c3ae6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b28;
        iVar23 = func_0x0001801bc7c0(in_R9);
        if (iVar23 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b35;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b4d;
            func_0x0001802295a0(0x1804b3080, 0xdf4, 0x1804b3090);
            uVar19 = 0x80005;
            goto code_r0x0001801c3af7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b5f;
        iVar8 = func_0x000180194310(in_RCX, iVar23);
        if (iVar8 != 0) goto code_r0x0001801c3b9f;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b6b;
        func_0x00018022ecc0(iVar23);
        goto code_r0x0001801c3b04;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
            *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
            *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c02;
            piVar20 = (int32_t *)func_0x0001801bc970(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa)
            ;
            return piVar20;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3bb3;
        func_0x000180229480();
        uVar19 = 0xe0b;
code_r0x0001801c3ae6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3af2;
        func_0x0001802295a0(0x1804b3080, uVar19, 0x1804b3090);
        uVar19 = 0xc0102;
        goto code_r0x0001801c3af7;
    case 6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b72;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b8a;
        func_0x0001802295a0(0x1804b3080, 0xe00, 0x1804b3090);
        uVar19 = 0xc0101;
        goto code_r0x0001801c3af7;
    case 10:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        break;
    case 0xb:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        piVar14[0x75] = 0;
        break;
    case 0xc:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x74];
        break;
    case 0xd:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x58];
        break;
    case 0x10:
        *(int64_t **)(piVar14 + 0x140) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x37:
        if (iVar8 == 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c29;
            func_0x000180224990(uVar19, 0x1804b3080, 0xe23);
            *(undefined8 *)(piVar14 + 0x286) = 0;
            if (in_R9 == (int64_t *)0x0) {
                return (int32_t *)0x1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c46;
            iVar23 = func_0x000180498cd0(in_R9);
            if (iVar23 - 1U < 0xff) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c66;
                iVar23 = func_0x0001802231e0(in_R9, 0x1804b3080, 0xe2e);
                *(int64_t *)(piVar14 + 0x286) = iVar23;
                if (iVar23 != 0) {
                    return (int32_t *)0x1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c7b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c93;
                func_0x0001802295a0(0x1804b3080, 0xe2f, 0x1804b3090);
                uVar19 = 0xc0103;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ca2;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cba;
                func_0x0001802295a0(0x1804b3080, 0xe2b, 0x1804b3090);
                uVar19 = 0x13f;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cc9;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ce1;
            func_0x0001802295a0(0x1804b3080, 0xe33, 0x1804b3090);
            uVar19 = 0x140;
        }
code_r0x0001801c3af7:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b04;
        func_0x0001802296d0(0x14, uVar19, 0);
        goto code_r0x0001801c3b04;
    case 0x39:
        *(int64_t **)(piVar14 + 0x284) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x41:
        piVar14[0x288] = iVar8;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x42:
        piVar20 = (int32_t *)0x1;
        *in_R9 = *(int64_t *)(piVar14 + 0x290);
        break;
    case 0x43:
        *(int64_t **)(piVar14 + 0x290) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x44:
        *in_R9 = *(int64_t *)(piVar14 + 0x28e);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x45:
        *(int64_t **)(piVar14 + 0x28e) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x46:
        *in_R9 = 0;
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        piVar20 = (int32_t *)0xffffffff;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d86;
        iVar23 = func_0x000180222340(uVar19, 0);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d98;
            uVar9 = func_0x00018023f2c0(iVar23, (int64_t)&arg_68h + iVar13 + iVar10);
            if (0 < (int32_t)uVar9) {
                uVar19 = *(undefined8 *)(piVar14 + 0x292);
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3db8;
                func_0x000180224990(uVar19, 0x1804b3080, 0xe64);
                *(undefined8 *)(piVar14 + 0x292) = *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10);
                *in_R9 = *(int64_t *)((int64_t)&arg_68h + iVar13 + iVar10);
                piVar20 = (int32_t *)(uint64_t)uVar9;
                *(int64_t *)(piVar14 + 0x294) = (int64_t)(int32_t)uVar9;
            }
        }
        break;
    case 0x47:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3dff;
            func_0x000180224990(iVar23, 0x1804b3080, 0xe75);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e20;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e2f;
        func_0x000180222050(uVar19, 0x18023f230);
        *(undefined8 *)(piVar14 + 0x296) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return (int32_t *)0x1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e48;
        uVar19 = func_0x000180221f60(0, 1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e57;
        iVar23 = func_0x000180222290(uVar19, 0x180196ec0);
        *(int64_t *)(piVar14 + 0x296) = iVar23;
        if (iVar23 != 0) {
            *(int64_t **)((int64_t)&arg_68h + iVar13 + iVar10) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e7b;
            iVar23 = func_0x00018023f280(0, (int64_t)&arg_68h + iVar13 + iVar10, in_R8 & 0xffffffff);
            if (iVar23 == 0) {
                return (int32_t *)0x1;
            }
            uVar19 = *(undefined8 *)(piVar14 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e93;
            func_0x000180222110(uVar19, iVar23);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x58:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f34;
            piVar20 = (int32_t *)func_0x0001801a2320(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f2a;
            piVar20 = (int32_t *)func_0x0001801a2430();
        }
        break;
    case 0x59:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f55;
            piVar20 = (int32_t *)func_0x0001801a17b0(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f4b;
            piVar20 = (int32_t *)func_0x0001801a1880();
        }
        break;
    case 0x5a:
        if (*(int64_t *)(piVar14 + 0x23e) != 0) {
            iVar23 = *(int64_t *)(piVar14 + 0x2a8);
            uVar22 = *(uint64_t *)(piVar14 + 0x2a6);
            if ((in_R9 != (int64_t *)0x0) && (uVar22 != 0)) {
                do {
                    uVar1 = *(undefined2 *)(iVar23 + uVar11 * 2);
                    uVar19 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c402e;
                    iVar17 = func_0x0001801ab700(uVar19, uVar1);
                    if (iVar17 == 0) {
                        uVar9 = *(uint16_t *)(iVar23 + uVar11 * 2) | 0x1000000;
                    } else {
                        uVar1 = *(undefined2 *)(iVar17 + 0x1c);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c403e;
                        uVar9 = func_0x0001801ab6c0(uVar1, 1);
                    }
                    *(uint32_t *)((int64_t)in_R9 + uVar11 * 4) = uVar9;
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar22);
            }
            return (int32_t *)(uVar22 & 0xffffffff);
        }
        goto code_r0x0001801c3b04;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_30h + iVar13 + iVar10) = iVar23;
        *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c409e;
        piVar20 = (int32_t *)func_0x0001801abb30(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa);
        break;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_30h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&arg_28h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2b0;
        uVar19 = *(undefined8 *)(in_RCX + 2);
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2aa;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40ea;
        piVar20 = (int32_t *)func_0x0001801abdc0(uVar19, piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac);
        break;
    case 0x5d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40fa;
        uVar6 = func_0x0001801ac8f0(piVar14, in_R8 & 0xffffffff);
        if (iVar8 == -1) {
            piVar20 = (int32_t *)(uint64_t)uVar6;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c410d;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar6, 1);
        }
        break;
    case 0x61:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c419a;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 0);
        break;
    case 0x62:
        uVar19 = 0;
        goto code_r0x0001801c41a2;
    case 0x65:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41d2;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 1);
        break;
    case 0x66:
        uVar19 = 1;
code_r0x0001801c41a2:
        uVar18 = *(undefined8 *)(piVar14 + 0x21e);
        uVar16 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41b5;
        piVar20 = (int32_t *)func_0x0001801ac780(uVar16, uVar18, in_R9, uVar19);
        break;
    case 0x67:
        if ((piVar14[0x1e] == 0) && (piVar14[0xd0] != 0)) {
            if (in_R9 != (int64_t *)0x0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xd2);
            }
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0xd4];
        }
        goto code_r0x0001801c3b04;
    case 0x68:
        if (piVar14[0x1e] != 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4229;
            piVar20 = (int32_t *)func_0x0001801c5900(uVar19, in_R9, iVar23);
            return piVar20;
        }
        goto code_r0x0001801c3b04;
    case 0x69:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c423b;
        piVar20 = (int32_t *)func_0x0001801a1400(piVar14, 0, in_R8 & 0xffffffff);
        break;
    case 0x6a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4255;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 0, in_R8 & 0xffffffff);
        break;
    case 0x6b:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4272;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 1, in_R8 & 0xffffffff);
        break;
    case 0x6c:
        iVar10 = *(int64_t *)(piVar14 + 0x100);
        goto code_r0x0001801c42d8;
    case 0x6d:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0x138) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4344;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0x138);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x6f:
        if (*(int64_t *)(piVar14 + 0x2a0) != 0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a0);
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0x29e];
        }
        goto code_r0x0001801c3b04;
    case 0x73:
        *in_R9 = *(int64_t *)(**(int64_t **)(piVar14 + 0x21e) + 0x10);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x74:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f86;
        piVar20 = (int32_t *)func_0x0001801a2260(uVar19, in_R9);
        break;
    case 0x75:
        if (iVar8 != 3) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3fed;
            piVar20 = (int32_t *)func_0x0001801a2550(uVar19, in_R8 & 0xffffffff);
            return piVar20;
        }
        if ((piVar14[0x1e] != 0) && (*(int64_t *)(piVar14 + 0xc0) != 0)) {
            if ((*(uint8_t *)(*(int64_t *)(piVar14 + 0xc0) + 0x20) & 0x44) != 0) {
                return (int32_t *)0x2;
            }
            if (*(int64_t *)(piVar14 + 0xf6) != 0) {
                **(int64_t **)(piVar14 + 0x21e) = *(int64_t *)(piVar14 + 0xf6);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x76:
        *(int32_t *)(*(int64_t *)(piVar14 + 0x21e) + 0x18) = iVar8;
code_r0x0001801c3b9f:
        piVar20 = (int32_t *)0x1;
        break;
    case 0x7f:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x288];
        break;
    case 0x84:
        iVar10 = *(int64_t *)(piVar14 + 0xf4);
code_r0x0001801c42d8:
        if (iVar10 != 0) {
            *(undefined4 *)in_R9 = *(undefined4 *)(iVar10 + 0x14);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x85:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0xc2) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4382;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xc2);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x86:
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar14 + 6) + 0x36) + 0x50) & 8) == 0) &&
             (iVar8 = **(int32_t **)(piVar14 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)) &&
           (*(char *)((int64_t)piVar14 + 0x4dd) != '\0')) {
            uVar1 = *(undefined2 *)((int64_t)piVar14 + 0x4de);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4158;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar1, 1);
        } else {
            if (*(int64_t *)(piVar14 + 0x23e) != 0) {
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x23e) + 0x304);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c417e;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar11 & 0xffff, 1);
        }
        break;
    case 0x87:
        if (in_R9 != (int64_t *)0x0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a8);
        }
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x2a6];
        break;
    case 0x89:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4289;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 0);
        break;
    case 0x8a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c42a3;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 1);
        break;
    case 0x8c:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0xf4) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0xf4);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x8d:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0x100) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0x100);
            return (int32_t *)0x1;
        }
code_r0x0001801c3b04:
        piVar20 = (int32_t *)0x0;
        break;
    case 0x8e:
        *in_R9 = *(int64_t *)(piVar14 + 0x296);
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3eb0;
        piVar20 = (int32_t *)func_0x000180222010(uVar19);
        break;
    case 0x8f:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ed5;
            func_0x000180224990(iVar23, 0x1804b3080, 0xe9b);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ef6;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f05;
        func_0x000180222050(uVar19, 0x18023f230);
        *(int64_t **)(piVar14 + 0x296) = in_R9;
        piVar20 = (int32_t *)0x1;
    }
    return piVar20;
}

// ============================================================
// Function: FUN_1801c28b0
// Address: 0x1801c28b0
// Size: 23 bytes
// ============================================================
void fcn.1801c28b0(int64_t arg1, int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    int32_t *piVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801c28c4;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        piVar3 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar3 = (int32_t *)arg1;
        }
        if (piVar3 != (int32_t *)0x0) {
            if (*(int64_t *)(piVar3 + 0x13c) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c28ee;
                fcn.1801c25a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2));
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar3 + 0x13c) + 0x118);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2901;
                fcn.1801a66d0(uVar1);
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar3 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2914;
                fcn.1801a66d0(uVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2920;
            fcn.1801c72a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2928;
            fcn.1801c4f10(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            uVar1 = *(undefined8 *)(piVar3 + 0x13c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2941;
            fcn.180224990(uVar1, 0x1804b05f8, 0xa9);
            *(undefined8 *)(piVar3 + 0x13c) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801c28c7
// Address: 0x1801c28c7
// Size: 143 bytes
// ============================================================
void fcn.1801c28b0(int64_t arg1, int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    int32_t *piVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801c28c4;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        piVar3 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar3 = (int32_t *)arg1;
        }
        if (piVar3 != (int32_t *)0x0) {
            if (*(int64_t *)(piVar3 + 0x13c) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c28ee;
                fcn.1801c25a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2));
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar3 + 0x13c) + 0x118);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2901;
                fcn.1801a66d0(uVar1);
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar3 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2914;
                fcn.1801a66d0(uVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2920;
            fcn.1801c72a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2928;
            fcn.1801c4f10(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            uVar1 = *(undefined8 *)(piVar3 + 0x13c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2941;
            fcn.180224990(uVar1, 0x1804b05f8, 0xa9);
            *(undefined8 *)(piVar3 + 0x13c) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801c2956
// Address: 0x1801c2956
// Size: 1 bytes
// ============================================================
void fcn.1801c28b0(int64_t arg1, int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 unaff_RBX;
    int32_t *piVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801c28c4;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        piVar3 = (int32_t *)0x0;
        if (*(int32_t *)arg1 == 0) {
            piVar3 = (int32_t *)arg1;
        }
        if (piVar3 != (int32_t *)0x0) {
            if (*(int64_t *)(piVar3 + 0x13c) != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c28ee;
                fcn.1801c25a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                              *(int64_t *)(&stack0x00000068 + iVar2));
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar3 + 0x13c) + 0x118);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2901;
                fcn.1801a66d0(uVar1);
                uVar1 = *(undefined8 *)(*(int64_t *)(piVar3 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2914;
                fcn.1801a66d0(uVar1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2920;
            fcn.1801c72a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2928;
            fcn.1801c4f10(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
            uVar1 = *(undefined8 *)(piVar3 + 0x13c);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c2941;
            fcn.180224990(uVar1, 0x1804b05f8, 0xa9);
            *(undefined8 *)(piVar3 + 0x13c) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801c2960
// Address: 0x1801c2960
// Size: 386 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_47h
// WARNING: [rz-ghidra] Detected overlap for variable arg_46h
// WARNING: [rz-ghidra] Removing arg arg_c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c80h because it doesn't fit into ProtoModel

int32_t * fcn.1801c2720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                       int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                       int64_t arg_78h, int64_t arg_f8h, int64_t arg_108h)
{
    undefined2 uVar1;
    code *pcVar2;
    undefined *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint16_t uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t *piVar14;
    int32_t *in_RCX;
    int16_t iVar15;
    int32_t in_EDX;
    undefined8 uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    undefined8 uVar18;
    undefined8 uVar19;
    int32_t *piVar20;
    int32_t iVar21;
    uint64_t in_R8;
    uint64_t uVar22;
    int64_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iVar23;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2735;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar8 = 0;
    piVar14 = piVar20;
    if (*in_RCX == 0) {
        piVar14 = in_RCX;
    }
    if (piVar14 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar21 = (int32_t)in_R8;
    if (in_EDX == 0x11) {
        if (iVar21 < 0xd0) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar21;
        return (int32_t *)(in_R8 & 0xffffffff);
    }
    if (in_EDX == 0x49) {
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2808;
            uVar11 = func_0x0001802450c0();
            if (*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) < uVar11) {
                iVar8 = -1;
                piVar14 = piVar20;
            } else {
                piVar14 = (int32_t *)(*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) - uVar11);
                if (piVar14 < (int32_t *)0xe4e1c1) {
                    if (piVar14 < (int32_t *)0xe4e1c0) {
                        iVar8 = -1;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            if (0 < iVar8) {
                piVar20 = piVar14;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2851;
            iVar10 = func_0x0001801c30c0(piVar20);
            *in_R9 = iVar10;
            piVar20 = (int32_t *)0x1;
        }
        return piVar20;
    }
    if (in_EDX == 0x4a) {
        uVar19 = *(undefined8 *)((int64_t)&var_18h + iVar10);
        *(undefined8 *)((int64_t)&arg_38h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
        iVar23 = iVar10 + 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar10) = *(undefined8 *)((int64_t)&arg_30h + iVar10);
        *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c2970;
        iVar13 = fcn.18045a350();
        iVar13 = -iVar13;
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2990;
            uVar11 = func_0x0001802450c0();
            iVar12 = *(int64_t *)(piVar14 + 0x13c);
            iVar17 = -1;
            if (*(uint64_t *)(iVar12 + 0x1c0) < uVar11) {
                iVar8 = -1;
                uVar11 = 0;
            } else {
                uVar11 = *(uint64_t *)(iVar12 + 0x1c0) - uVar11;
                if (uVar11 < 0xe4e1c1) {
                    if (uVar11 < 15000000) {
                        iVar8 = -1;
                    } else {
                        iVar8 = 0;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            uVar22 = 0;
            if (0 < iVar8) {
                uVar22 = uVar11;
            }
            if (uVar22 == 0) {
                pcVar2 = *(code **)(iVar12 + 0x1d0);
                if (pcVar2 == (code *)0x0) {
                    *(int32_t *)(iVar12 + 0x1c8) = *(int32_t *)(iVar12 + 0x1c8) * 2;
                    if (60000000 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8)) {
                        *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = 60000000;
                    }
                } else {
                    uVar18 = *(undefined8 *)(piVar14 + 0x10);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c29f7;
                    uVar7 = (*pcVar2)(uVar18);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = uVar7;
                }
                *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) =
                     *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) + 1;
                if (2 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a51;
                    uVar11 = func_0x000180193b40(piVar14);
                    if ((uVar11 >> 0xc & 1) == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a60;
                        uVar18 = func_0x000180193e90(piVar14);
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a73;
                        iVar8 = func_0x000180219d10(uVar18, 0x2f, 0, 0);
                        if ((uint64_t)(int64_t)iVar8 < *(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130)) {
                            *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar8;
                        }
                    }
                }
                iVar12 = *(int64_t *)(piVar14 + 0x13c);
                if (0xc < *(uint32_t *)(iVar12 + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aa2;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aba;
                    func_0x0001802295a0(0x1804b05f8, 0x181, 0x1804b0608);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2acd;
                    func_0x00018019b5e0(piVar14, 0xffffffff, 0x138, 0);
                    return (int32_t *)0xffffffff;
                }
                iVar5 = *(int64_t *)(iVar12 + 0x1c0);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) = uVar19;
                if (iVar5 == 0) {
                    pcVar2 = *(code **)(iVar12 + 0x1d0);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined4 *)(iVar12 + 0x1c8) = 1000000;
                    } else {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b00;
                        uVar7 = (*pcVar2)(piVar14, 0);
                        *(undefined4 *)(iVar12 + 0x1c8) = uVar7;
                    }
                }
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) * 1000;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b2b;
                iVar12 = func_0x0001802450c0();
                if (uVar11 < -iVar12 - 1U || uVar11 - (-iVar12 - 1U) == 0) {
                    iVar17 = iVar12 + uVar11;
                }
                *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) = iVar17;
                iVar17 = *(int64_t *)(piVar14 + 0x13c);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b57;
                uVar18 = func_0x000180193c40(piVar14);
                uVar19 = *(undefined8 *)(iVar17 + 0x1c0);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b66;
                uVar19 = func_0x0001801c30c0(uVar19);
                *(undefined8 *)((int64_t)&arg_48h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b80;
                func_0x000180219d10(uVar18, 0x2d, 0, (int64_t)&arg_48h + iVar13 + iVar10);
                uVar19 = *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_60h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&arg_30h + iVar13 + iVar10) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_28h + iVar13 + iVar10) = unaff_R13;
                *(undefined8 *)((int64_t)&var_20h + iVar13 + iVar10) = unaff_R14;
                *(undefined8 *)((int64_t)&var_18h + iVar13 + iVar10) = unaff_R15;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801cb802;
                iVar10 = fcn.18045a350();
                iVar10 = -iVar10;
                *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18) =
                     *(uint64_t *)0x1806a3940 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18;
                uVar19 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb82a;
                uVar19 = func_0x00018001ed90(uVar19);
                *(undefined8 *)((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb839;
                iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                do {
                    if (iVar17 == 0) {
code_r0x0001801cb9bc:
                        uVar11 = *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9c9;
                        piVar20 = (int32_t *)
                                  func_0x000180459870(uVar11 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18);
                        return piVar20;
                    }
                    iVar17 = *(int64_t *)(iVar17 + 8);
                    *(undefined8 *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18) = 0;
                    iVar15 = *(int16_t *)(iVar17 + 0x10) * 2 - *(int16_t *)(iVar17 + 0x28);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x11) = (char)iVar15;
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x12) = (char)((uint16_t)iVar15 >> 8);
                    uVar19 = *(undefined8 *)(iVar17 + 0x120);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb89b;
                    iVar17 = func_0x0001801a6680(uVar19, (int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18);
                    if (iVar17 == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ec;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba04;
                        func_0x0001802295a0(0x1804b3a00, 0x4bb, 0x1804b3aa0);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba1a;
                        func_0x00018019b5e0(piVar14, 0x50, 0xc0103, 0);
                        goto code_r0x0001801cb9bc;
                    }
                    puVar3 = *(undefined **)(iVar17 + 8);
                    iVar12 = 1;
                    iVar17 = *(int64_t *)(puVar3 + 8);
                    uVar19 = *(undefined8 *)(puVar3 + 0x40);
                    if (*(int32_t *)(puVar3 + 0x28) == 0) {
                        iVar12 = 0xc;
                    }
                    uVar18 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x3e) + 8);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb8d0;
                    func_0x000180498030(uVar18, uVar19, iVar17 + iVar12);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(int64_t *)(piVar14 + 0x42) = *(int64_t *)(puVar3 + 8) + iVar12;
                    uVar1 = *(undefined2 *)(puVar3 + 0x10);
                    uVar19 = *(undefined8 *)(puVar3 + 8);
                    uVar18 = *(undefined8 *)(puVar3 + 0x20);
                    *(undefined *)(iVar17 + 0x138) = *puVar3;
                    *(undefined8 *)(iVar17 + 0x140) = uVar19;
                    *(undefined2 *)(iVar17 + 0x148) = uVar1;
                    *(undefined8 *)(iVar17 + 0x158) = uVar18;
                    *(undefined8 *)(iVar17 + 0x150) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x31c);
                    uVar18 = *(undefined8 *)(piVar14 + 800);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 1;
                    iVar17 = *(int64_t *)(puVar3 + 0x30);
                    uVar16 = *(undefined8 *)(piVar14 + 0x16);
                    *(int64_t *)(piVar14 + 0x31c) = iVar17;
                    uVar4 = *(undefined8 *)(puVar3 + 0x38);
                    *(undefined8 *)(piVar14 + 800) = uVar4;
                    pcVar2 = *(code **)(iVar17 + 0x58);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb959;
                    (*pcVar2)(uVar4, uVar16);
                    uVar16 = 0x16;
                    if (*(int32_t *)(puVar3 + 0x28) != 0) {
                        uVar16 = 0x14;
                    }
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb96e;
                    iVar8 = func_0x0001801ca8a0(piVar14, uVar16);
                    *(undefined8 *)(piVar14 + 0x31c) = uVar19;
                    *(undefined8 *)(piVar14 + 800) = uVar18;
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x16);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9a0;
                    func_0x000180219d10(uVar19, 0xb, 0);
                    if (iVar8 < 1) goto code_r0x0001801cb9bc;
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ae;
                    iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                } while( true );
            }
        }
        return (int32_t *)0x0;
    }
    if (in_EDX == 0x78) {
        if (iVar21 < 0x100) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x128) = (int64_t)iVar21;
        return (int32_t *)0x1;
    }
    if (in_EDX == 0x79) {
        return (int32_t *)0x100;
    }
    uVar19 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
    uVar18 = *(undefined8 *)((int64_t)&var_18h + iVar10);
    *(undefined8 *)((int64_t)&arg_30h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = uVar19;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = uVar18;
    *(undefined8 *)((int64_t)&var_8h + iVar10) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c3a2c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar11 = 0;
    iVar8 = (int32_t)in_R8;
    iVar23 = (int64_t)iVar8;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x0001801c3b04;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3a65;
            piVar14 = (int32_t *)func_0x0001801bda50();
            *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
            if (piVar14 != (int32_t *)0x0) goto code_r0x0001801c3a76;
        }
        goto code_r0x0001801c3b04;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
    piVar14 = in_RCX;
code_r0x0001801c3a76:
    // switch table (141 cases) at 0x1801c43e8
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ada;
            func_0x000180229480();
            uVar19 = 0xdef;
            goto code_r0x0001801c3ae6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b28;
        iVar23 = func_0x0001801bc7c0(in_R9);
        if (iVar23 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b35;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b4d;
            func_0x0001802295a0(0x1804b3080, 0xdf4, 0x1804b3090);
            uVar19 = 0x80005;
            goto code_r0x0001801c3af7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b5f;
        iVar8 = func_0x000180194310(in_RCX, iVar23);
        if (iVar8 != 0) goto code_r0x0001801c3b9f;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b6b;
        func_0x00018022ecc0(iVar23);
        goto code_r0x0001801c3b04;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
            *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
            *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c02;
            piVar20 = (int32_t *)func_0x0001801bc970(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa)
            ;
            return piVar20;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3bb3;
        func_0x000180229480();
        uVar19 = 0xe0b;
code_r0x0001801c3ae6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3af2;
        func_0x0001802295a0(0x1804b3080, uVar19, 0x1804b3090);
        uVar19 = 0xc0102;
        goto code_r0x0001801c3af7;
    case 6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b72;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b8a;
        func_0x0001802295a0(0x1804b3080, 0xe00, 0x1804b3090);
        uVar19 = 0xc0101;
        goto code_r0x0001801c3af7;
    case 10:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        break;
    case 0xb:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        piVar14[0x75] = 0;
        break;
    case 0xc:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x74];
        break;
    case 0xd:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x58];
        break;
    case 0x10:
        *(int64_t **)(piVar14 + 0x140) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x37:
        if (iVar8 == 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c29;
            fcn.180224990(uVar19, 0x1804b3080, 0xe23);
            *(undefined8 *)(piVar14 + 0x286) = 0;
            if (in_R9 == (int64_t *)0x0) {
                return (int32_t *)0x1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c46;
            iVar23 = func_0x000180498cd0(in_R9);
            if (iVar23 - 1U < 0xff) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c66;
                iVar23 = func_0x0001802231e0(in_R9, 0x1804b3080, 0xe2e);
                *(int64_t *)(piVar14 + 0x286) = iVar23;
                if (iVar23 != 0) {
                    return (int32_t *)0x1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c7b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c93;
                func_0x0001802295a0(0x1804b3080, 0xe2f, 0x1804b3090);
                uVar19 = 0xc0103;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ca2;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cba;
                func_0x0001802295a0(0x1804b3080, 0xe2b, 0x1804b3090);
                uVar19 = 0x13f;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cc9;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ce1;
            func_0x0001802295a0(0x1804b3080, 0xe33, 0x1804b3090);
            uVar19 = 0x140;
        }
code_r0x0001801c3af7:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b04;
        func_0x0001802296d0(0x14, uVar19, 0);
        goto code_r0x0001801c3b04;
    case 0x39:
        *(int64_t **)(piVar14 + 0x284) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x41:
        piVar14[0x288] = iVar8;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x42:
        piVar20 = (int32_t *)0x1;
        *in_R9 = *(int64_t *)(piVar14 + 0x290);
        break;
    case 0x43:
        *(int64_t **)(piVar14 + 0x290) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x44:
        *in_R9 = *(int64_t *)(piVar14 + 0x28e);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x45:
        *(int64_t **)(piVar14 + 0x28e) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x46:
        *in_R9 = 0;
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        piVar20 = (int32_t *)0xffffffff;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d86;
        iVar23 = func_0x000180222340(uVar19, 0);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d98;
            uVar9 = func_0x00018023f2c0(iVar23, (int64_t)&arg_68h + iVar13 + iVar10);
            if (0 < (int32_t)uVar9) {
                uVar19 = *(undefined8 *)(piVar14 + 0x292);
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3db8;
                fcn.180224990(uVar19, 0x1804b3080, 0xe64);
                *(undefined8 *)(piVar14 + 0x292) = *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10);
                *in_R9 = *(int64_t *)((int64_t)&arg_68h + iVar13 + iVar10);
                piVar20 = (int32_t *)(uint64_t)uVar9;
                *(int64_t *)(piVar14 + 0x294) = (int64_t)(int32_t)uVar9;
            }
        }
        break;
    case 0x47:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3dff;
            fcn.180224990(iVar23, 0x1804b3080, 0xe75);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e20;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e2f;
        func_0x000180222050(uVar19, 0x18023f230);
        *(undefined8 *)(piVar14 + 0x296) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return (int32_t *)0x1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e48;
        uVar19 = func_0x000180221f60(0, 1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e57;
        iVar23 = func_0x000180222290(uVar19, 0x180196ec0);
        *(int64_t *)(piVar14 + 0x296) = iVar23;
        if (iVar23 != 0) {
            *(int64_t **)((int64_t)&arg_68h + iVar13 + iVar10) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e7b;
            iVar23 = func_0x00018023f280(0, (int64_t)&arg_68h + iVar13 + iVar10, in_R8 & 0xffffffff);
            if (iVar23 == 0) {
                return (int32_t *)0x1;
            }
            uVar19 = *(undefined8 *)(piVar14 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e93;
            func_0x000180222110(uVar19, iVar23);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x58:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f34;
            piVar20 = (int32_t *)func_0x0001801a2320(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f2a;
            piVar20 = (int32_t *)func_0x0001801a2430();
        }
        break;
    case 0x59:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f55;
            piVar20 = (int32_t *)func_0x0001801a17b0(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f4b;
            piVar20 = (int32_t *)func_0x0001801a1880();
        }
        break;
    case 0x5a:
        if (*(int64_t *)(piVar14 + 0x23e) != 0) {
            iVar23 = *(int64_t *)(piVar14 + 0x2a8);
            uVar22 = *(uint64_t *)(piVar14 + 0x2a6);
            if ((in_R9 != (int64_t *)0x0) && (uVar22 != 0)) {
                do {
                    uVar1 = *(undefined2 *)(iVar23 + uVar11 * 2);
                    uVar19 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c402e;
                    iVar17 = func_0x0001801ab700(uVar19, uVar1);
                    if (iVar17 == 0) {
                        uVar9 = *(uint16_t *)(iVar23 + uVar11 * 2) | 0x1000000;
                    } else {
                        uVar1 = *(undefined2 *)(iVar17 + 0x1c);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c403e;
                        uVar9 = func_0x0001801ab6c0(uVar1, 1);
                    }
                    *(uint32_t *)((int64_t)in_R9 + uVar11 * 4) = uVar9;
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar22);
            }
            return (int32_t *)(uVar22 & 0xffffffff);
        }
        goto code_r0x0001801c3b04;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_30h + iVar13 + iVar10) = iVar23;
        *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c409e;
        piVar20 = (int32_t *)func_0x0001801abb30(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa);
        break;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_30h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&arg_28h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2b0;
        uVar19 = *(undefined8 *)(in_RCX + 2);
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2aa;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40ea;
        piVar20 = (int32_t *)func_0x0001801abdc0(uVar19, piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac);
        break;
    case 0x5d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40fa;
        uVar6 = func_0x0001801ac8f0(piVar14, in_R8 & 0xffffffff);
        if (iVar8 == -1) {
            piVar20 = (int32_t *)(uint64_t)uVar6;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c410d;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar6, 1);
        }
        break;
    case 0x61:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c419a;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 0);
        break;
    case 0x62:
        uVar19 = 0;
        goto code_r0x0001801c41a2;
    case 0x65:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41d2;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 1);
        break;
    case 0x66:
        uVar19 = 1;
code_r0x0001801c41a2:
        uVar18 = *(undefined8 *)(piVar14 + 0x21e);
        uVar16 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41b5;
        piVar20 = (int32_t *)func_0x0001801ac780(uVar16, uVar18, in_R9, uVar19);
        break;
    case 0x67:
        if ((piVar14[0x1e] == 0) && (piVar14[0xd0] != 0)) {
            if (in_R9 != (int64_t *)0x0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xd2);
            }
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0xd4];
        }
        goto code_r0x0001801c3b04;
    case 0x68:
        if (piVar14[0x1e] != 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4229;
            piVar20 = (int32_t *)func_0x0001801c5900(uVar19, in_R9, iVar23);
            return piVar20;
        }
        goto code_r0x0001801c3b04;
    case 0x69:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c423b;
        piVar20 = (int32_t *)func_0x0001801a1400(piVar14, 0, in_R8 & 0xffffffff);
        break;
    case 0x6a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4255;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 0, in_R8 & 0xffffffff);
        break;
    case 0x6b:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4272;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 1, in_R8 & 0xffffffff);
        break;
    case 0x6c:
        iVar10 = *(int64_t *)(piVar14 + 0x100);
        goto code_r0x0001801c42d8;
    case 0x6d:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0x138) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4344;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0x138);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x6f:
        if (*(int64_t *)(piVar14 + 0x2a0) != 0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a0);
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0x29e];
        }
        goto code_r0x0001801c3b04;
    case 0x73:
        *in_R9 = *(int64_t *)(**(int64_t **)(piVar14 + 0x21e) + 0x10);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x74:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f86;
        piVar20 = (int32_t *)func_0x0001801a2260(uVar19, in_R9);
        break;
    case 0x75:
        if (iVar8 != 3) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3fed;
            piVar20 = (int32_t *)func_0x0001801a2550(uVar19, in_R8 & 0xffffffff);
            return piVar20;
        }
        if ((piVar14[0x1e] != 0) && (*(int64_t *)(piVar14 + 0xc0) != 0)) {
            if ((*(uint8_t *)(*(int64_t *)(piVar14 + 0xc0) + 0x20) & 0x44) != 0) {
                return (int32_t *)0x2;
            }
            if (*(int64_t *)(piVar14 + 0xf6) != 0) {
                **(int64_t **)(piVar14 + 0x21e) = *(int64_t *)(piVar14 + 0xf6);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x76:
        *(int32_t *)(*(int64_t *)(piVar14 + 0x21e) + 0x18) = iVar8;
code_r0x0001801c3b9f:
        piVar20 = (int32_t *)0x1;
        break;
    case 0x7f:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x288];
        break;
    case 0x84:
        iVar10 = *(int64_t *)(piVar14 + 0xf4);
code_r0x0001801c42d8:
        if (iVar10 != 0) {
            *(undefined4 *)in_R9 = *(undefined4 *)(iVar10 + 0x14);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x85:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0xc2) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4382;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xc2);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x86:
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar14 + 6) + 0x36) + 0x50) & 8) == 0) &&
             (iVar8 = **(int32_t **)(piVar14 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)) &&
           (*(char *)((int64_t)piVar14 + 0x4dd) != '\0')) {
            uVar1 = *(undefined2 *)((int64_t)piVar14 + 0x4de);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4158;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar1, 1);
        } else {
            if (*(int64_t *)(piVar14 + 0x23e) != 0) {
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x23e) + 0x304);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c417e;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar11 & 0xffff, 1);
        }
        break;
    case 0x87:
        if (in_R9 != (int64_t *)0x0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a8);
        }
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x2a6];
        break;
    case 0x89:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4289;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 0);
        break;
    case 0x8a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c42a3;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 1);
        break;
    case 0x8c:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0xf4) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0xf4);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x8d:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0x100) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0x100);
            return (int32_t *)0x1;
        }
code_r0x0001801c3b04:
        piVar20 = (int32_t *)0x0;
        break;
    case 0x8e:
        *in_R9 = *(int64_t *)(piVar14 + 0x296);
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3eb0;
        piVar20 = (int32_t *)func_0x000180222010(uVar19);
        break;
    case 0x8f:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ed5;
            fcn.180224990(iVar23, 0x1804b3080, 0xe9b);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ef6;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f05;
        func_0x000180222050(uVar19, 0x18023f230);
        *(int64_t **)(piVar14 + 0x296) = in_R9;
        piVar20 = (int32_t *)0x1;
    }
    return piVar20;
}

// ============================================================
// Function: FUN_1801c2ae2
// Address: 0x1801c2ae2
// Size: 181 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_47h
// WARNING: [rz-ghidra] Detected overlap for variable arg_46h
// WARNING: [rz-ghidra] Removing arg arg_c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c80h because it doesn't fit into ProtoModel

int32_t * fcn.1801c2720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                       int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                       int64_t arg_78h, int64_t arg_f8h, int64_t arg_108h)
{
    undefined2 uVar1;
    code *pcVar2;
    undefined *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint16_t uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t *piVar14;
    int32_t *in_RCX;
    int16_t iVar15;
    int32_t in_EDX;
    undefined8 uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    undefined8 uVar18;
    undefined8 uVar19;
    int32_t *piVar20;
    int32_t iVar21;
    uint64_t in_R8;
    uint64_t uVar22;
    int64_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iVar23;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2735;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar8 = 0;
    piVar14 = piVar20;
    if (*in_RCX == 0) {
        piVar14 = in_RCX;
    }
    if (piVar14 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar21 = (int32_t)in_R8;
    if (in_EDX == 0x11) {
        if (iVar21 < 0xd0) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar21;
        return (int32_t *)(in_R8 & 0xffffffff);
    }
    if (in_EDX == 0x49) {
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2808;
            uVar11 = func_0x0001802450c0();
            if (*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) < uVar11) {
                iVar8 = -1;
                piVar14 = piVar20;
            } else {
                piVar14 = (int32_t *)(*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) - uVar11);
                if (piVar14 < (int32_t *)0xe4e1c1) {
                    if (piVar14 < (int32_t *)0xe4e1c0) {
                        iVar8 = -1;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            if (0 < iVar8) {
                piVar20 = piVar14;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2851;
            iVar10 = func_0x0001801c30c0(piVar20);
            *in_R9 = iVar10;
            piVar20 = (int32_t *)0x1;
        }
        return piVar20;
    }
    if (in_EDX == 0x4a) {
        uVar19 = *(undefined8 *)((int64_t)&var_18h + iVar10);
        *(undefined8 *)((int64_t)&arg_38h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
        iVar23 = iVar10 + 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar10) = *(undefined8 *)((int64_t)&arg_30h + iVar10);
        *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c2970;
        iVar13 = fcn.18045a350();
        iVar13 = -iVar13;
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2990;
            uVar11 = func_0x0001802450c0();
            iVar12 = *(int64_t *)(piVar14 + 0x13c);
            iVar17 = -1;
            if (*(uint64_t *)(iVar12 + 0x1c0) < uVar11) {
                iVar8 = -1;
                uVar11 = 0;
            } else {
                uVar11 = *(uint64_t *)(iVar12 + 0x1c0) - uVar11;
                if (uVar11 < 0xe4e1c1) {
                    if (uVar11 < 15000000) {
                        iVar8 = -1;
                    } else {
                        iVar8 = 0;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            uVar22 = 0;
            if (0 < iVar8) {
                uVar22 = uVar11;
            }
            if (uVar22 == 0) {
                pcVar2 = *(code **)(iVar12 + 0x1d0);
                if (pcVar2 == (code *)0x0) {
                    *(int32_t *)(iVar12 + 0x1c8) = *(int32_t *)(iVar12 + 0x1c8) * 2;
                    if (60000000 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8)) {
                        *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = 60000000;
                    }
                } else {
                    uVar18 = *(undefined8 *)(piVar14 + 0x10);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c29f7;
                    uVar7 = (*pcVar2)(uVar18);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = uVar7;
                }
                *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) =
                     *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) + 1;
                if (2 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a51;
                    uVar11 = func_0x000180193b40(piVar14);
                    if ((uVar11 >> 0xc & 1) == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a60;
                        uVar18 = func_0x000180193e90(piVar14);
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a73;
                        iVar8 = func_0x000180219d10(uVar18, 0x2f, 0, 0);
                        if ((uint64_t)(int64_t)iVar8 < *(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130)) {
                            *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar8;
                        }
                    }
                }
                iVar12 = *(int64_t *)(piVar14 + 0x13c);
                if (0xc < *(uint32_t *)(iVar12 + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aa2;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aba;
                    func_0x0001802295a0(0x1804b05f8, 0x181, 0x1804b0608);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2acd;
                    func_0x00018019b5e0(piVar14, 0xffffffff, 0x138, 0);
                    return (int32_t *)0xffffffff;
                }
                iVar5 = *(int64_t *)(iVar12 + 0x1c0);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) = uVar19;
                if (iVar5 == 0) {
                    pcVar2 = *(code **)(iVar12 + 0x1d0);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined4 *)(iVar12 + 0x1c8) = 1000000;
                    } else {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b00;
                        uVar7 = (*pcVar2)(piVar14, 0);
                        *(undefined4 *)(iVar12 + 0x1c8) = uVar7;
                    }
                }
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) * 1000;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b2b;
                iVar12 = func_0x0001802450c0();
                if (uVar11 < -iVar12 - 1U || uVar11 - (-iVar12 - 1U) == 0) {
                    iVar17 = iVar12 + uVar11;
                }
                *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) = iVar17;
                iVar17 = *(int64_t *)(piVar14 + 0x13c);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b57;
                uVar18 = func_0x000180193c40(piVar14);
                uVar19 = *(undefined8 *)(iVar17 + 0x1c0);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b66;
                uVar19 = func_0x0001801c30c0(uVar19);
                *(undefined8 *)((int64_t)&arg_48h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b80;
                func_0x000180219d10(uVar18, 0x2d, 0, (int64_t)&arg_48h + iVar13 + iVar10);
                uVar19 = *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_60h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&arg_30h + iVar13 + iVar10) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_28h + iVar13 + iVar10) = unaff_R13;
                *(undefined8 *)((int64_t)&var_20h + iVar13 + iVar10) = unaff_R14;
                *(undefined8 *)((int64_t)&var_18h + iVar13 + iVar10) = unaff_R15;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801cb802;
                iVar10 = fcn.18045a350();
                iVar10 = -iVar10;
                *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18) =
                     *(uint64_t *)0x1806a3940 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18;
                uVar19 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb82a;
                uVar19 = func_0x00018001ed90(uVar19);
                *(undefined8 *)((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb839;
                iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                do {
                    if (iVar17 == 0) {
code_r0x0001801cb9bc:
                        uVar11 = *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9c9;
                        piVar20 = (int32_t *)
                                  func_0x000180459870(uVar11 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18);
                        return piVar20;
                    }
                    iVar17 = *(int64_t *)(iVar17 + 8);
                    *(undefined8 *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18) = 0;
                    iVar15 = *(int16_t *)(iVar17 + 0x10) * 2 - *(int16_t *)(iVar17 + 0x28);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x11) = (char)iVar15;
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x12) = (char)((uint16_t)iVar15 >> 8);
                    uVar19 = *(undefined8 *)(iVar17 + 0x120);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb89b;
                    iVar17 = func_0x0001801a6680(uVar19, (int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18);
                    if (iVar17 == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ec;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba04;
                        func_0x0001802295a0(0x1804b3a00, 0x4bb, 0x1804b3aa0);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba1a;
                        func_0x00018019b5e0(piVar14, 0x50, 0xc0103, 0);
                        goto code_r0x0001801cb9bc;
                    }
                    puVar3 = *(undefined **)(iVar17 + 8);
                    iVar12 = 1;
                    iVar17 = *(int64_t *)(puVar3 + 8);
                    uVar19 = *(undefined8 *)(puVar3 + 0x40);
                    if (*(int32_t *)(puVar3 + 0x28) == 0) {
                        iVar12 = 0xc;
                    }
                    uVar18 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x3e) + 8);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb8d0;
                    func_0x000180498030(uVar18, uVar19, iVar17 + iVar12);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(int64_t *)(piVar14 + 0x42) = *(int64_t *)(puVar3 + 8) + iVar12;
                    uVar1 = *(undefined2 *)(puVar3 + 0x10);
                    uVar19 = *(undefined8 *)(puVar3 + 8);
                    uVar18 = *(undefined8 *)(puVar3 + 0x20);
                    *(undefined *)(iVar17 + 0x138) = *puVar3;
                    *(undefined8 *)(iVar17 + 0x140) = uVar19;
                    *(undefined2 *)(iVar17 + 0x148) = uVar1;
                    *(undefined8 *)(iVar17 + 0x158) = uVar18;
                    *(undefined8 *)(iVar17 + 0x150) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x31c);
                    uVar18 = *(undefined8 *)(piVar14 + 800);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 1;
                    iVar17 = *(int64_t *)(puVar3 + 0x30);
                    uVar16 = *(undefined8 *)(piVar14 + 0x16);
                    *(int64_t *)(piVar14 + 0x31c) = iVar17;
                    uVar4 = *(undefined8 *)(puVar3 + 0x38);
                    *(undefined8 *)(piVar14 + 800) = uVar4;
                    pcVar2 = *(code **)(iVar17 + 0x58);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb959;
                    (*pcVar2)(uVar4, uVar16);
                    uVar16 = 0x16;
                    if (*(int32_t *)(puVar3 + 0x28) != 0) {
                        uVar16 = 0x14;
                    }
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb96e;
                    iVar8 = func_0x0001801ca8a0(piVar14, uVar16);
                    *(undefined8 *)(piVar14 + 0x31c) = uVar19;
                    *(undefined8 *)(piVar14 + 800) = uVar18;
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x16);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9a0;
                    func_0x000180219d10(uVar19, 0xb, 0);
                    if (iVar8 < 1) goto code_r0x0001801cb9bc;
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ae;
                    iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                } while( true );
            }
        }
        return (int32_t *)0x0;
    }
    if (in_EDX == 0x78) {
        if (iVar21 < 0x100) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x128) = (int64_t)iVar21;
        return (int32_t *)0x1;
    }
    if (in_EDX == 0x79) {
        return (int32_t *)0x100;
    }
    uVar19 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
    uVar18 = *(undefined8 *)((int64_t)&var_18h + iVar10);
    *(undefined8 *)((int64_t)&arg_30h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = uVar19;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = uVar18;
    *(undefined8 *)((int64_t)&var_8h + iVar10) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c3a2c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar11 = 0;
    iVar8 = (int32_t)in_R8;
    iVar23 = (int64_t)iVar8;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x0001801c3b04;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3a65;
            piVar14 = (int32_t *)func_0x0001801bda50();
            *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
            if (piVar14 != (int32_t *)0x0) goto code_r0x0001801c3a76;
        }
        goto code_r0x0001801c3b04;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
    piVar14 = in_RCX;
code_r0x0001801c3a76:
    // switch table (141 cases) at 0x1801c43e8
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ada;
            func_0x000180229480();
            uVar19 = 0xdef;
            goto code_r0x0001801c3ae6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b28;
        iVar23 = func_0x0001801bc7c0(in_R9);
        if (iVar23 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b35;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b4d;
            func_0x0001802295a0(0x1804b3080, 0xdf4, 0x1804b3090);
            uVar19 = 0x80005;
            goto code_r0x0001801c3af7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b5f;
        iVar8 = func_0x000180194310(in_RCX, iVar23);
        if (iVar8 != 0) goto code_r0x0001801c3b9f;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b6b;
        func_0x00018022ecc0(iVar23);
        goto code_r0x0001801c3b04;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
            *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
            *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c02;
            piVar20 = (int32_t *)func_0x0001801bc970(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa)
            ;
            return piVar20;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3bb3;
        func_0x000180229480();
        uVar19 = 0xe0b;
code_r0x0001801c3ae6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3af2;
        func_0x0001802295a0(0x1804b3080, uVar19, 0x1804b3090);
        uVar19 = 0xc0102;
        goto code_r0x0001801c3af7;
    case 6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b72;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b8a;
        func_0x0001802295a0(0x1804b3080, 0xe00, 0x1804b3090);
        uVar19 = 0xc0101;
        goto code_r0x0001801c3af7;
    case 10:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        break;
    case 0xb:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        piVar14[0x75] = 0;
        break;
    case 0xc:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x74];
        break;
    case 0xd:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x58];
        break;
    case 0x10:
        *(int64_t **)(piVar14 + 0x140) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x37:
        if (iVar8 == 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c29;
            fcn.180224990(uVar19, 0x1804b3080, 0xe23);
            *(undefined8 *)(piVar14 + 0x286) = 0;
            if (in_R9 == (int64_t *)0x0) {
                return (int32_t *)0x1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c46;
            iVar23 = func_0x000180498cd0(in_R9);
            if (iVar23 - 1U < 0xff) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c66;
                iVar23 = func_0x0001802231e0(in_R9, 0x1804b3080, 0xe2e);
                *(int64_t *)(piVar14 + 0x286) = iVar23;
                if (iVar23 != 0) {
                    return (int32_t *)0x1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c7b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c93;
                func_0x0001802295a0(0x1804b3080, 0xe2f, 0x1804b3090);
                uVar19 = 0xc0103;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ca2;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cba;
                func_0x0001802295a0(0x1804b3080, 0xe2b, 0x1804b3090);
                uVar19 = 0x13f;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cc9;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ce1;
            func_0x0001802295a0(0x1804b3080, 0xe33, 0x1804b3090);
            uVar19 = 0x140;
        }
code_r0x0001801c3af7:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b04;
        func_0x0001802296d0(0x14, uVar19, 0);
        goto code_r0x0001801c3b04;
    case 0x39:
        *(int64_t **)(piVar14 + 0x284) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x41:
        piVar14[0x288] = iVar8;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x42:
        piVar20 = (int32_t *)0x1;
        *in_R9 = *(int64_t *)(piVar14 + 0x290);
        break;
    case 0x43:
        *(int64_t **)(piVar14 + 0x290) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x44:
        *in_R9 = *(int64_t *)(piVar14 + 0x28e);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x45:
        *(int64_t **)(piVar14 + 0x28e) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x46:
        *in_R9 = 0;
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        piVar20 = (int32_t *)0xffffffff;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d86;
        iVar23 = func_0x000180222340(uVar19, 0);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d98;
            uVar9 = func_0x00018023f2c0(iVar23, (int64_t)&arg_68h + iVar13 + iVar10);
            if (0 < (int32_t)uVar9) {
                uVar19 = *(undefined8 *)(piVar14 + 0x292);
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3db8;
                fcn.180224990(uVar19, 0x1804b3080, 0xe64);
                *(undefined8 *)(piVar14 + 0x292) = *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10);
                *in_R9 = *(int64_t *)((int64_t)&arg_68h + iVar13 + iVar10);
                piVar20 = (int32_t *)(uint64_t)uVar9;
                *(int64_t *)(piVar14 + 0x294) = (int64_t)(int32_t)uVar9;
            }
        }
        break;
    case 0x47:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3dff;
            fcn.180224990(iVar23, 0x1804b3080, 0xe75);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e20;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e2f;
        func_0x000180222050(uVar19, 0x18023f230);
        *(undefined8 *)(piVar14 + 0x296) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return (int32_t *)0x1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e48;
        uVar19 = func_0x000180221f60(0, 1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e57;
        iVar23 = func_0x000180222290(uVar19, 0x180196ec0);
        *(int64_t *)(piVar14 + 0x296) = iVar23;
        if (iVar23 != 0) {
            *(int64_t **)((int64_t)&arg_68h + iVar13 + iVar10) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e7b;
            iVar23 = func_0x00018023f280(0, (int64_t)&arg_68h + iVar13 + iVar10, in_R8 & 0xffffffff);
            if (iVar23 == 0) {
                return (int32_t *)0x1;
            }
            uVar19 = *(undefined8 *)(piVar14 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e93;
            func_0x000180222110(uVar19, iVar23);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x58:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f34;
            piVar20 = (int32_t *)func_0x0001801a2320(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f2a;
            piVar20 = (int32_t *)func_0x0001801a2430();
        }
        break;
    case 0x59:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f55;
            piVar20 = (int32_t *)func_0x0001801a17b0(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f4b;
            piVar20 = (int32_t *)func_0x0001801a1880();
        }
        break;
    case 0x5a:
        if (*(int64_t *)(piVar14 + 0x23e) != 0) {
            iVar23 = *(int64_t *)(piVar14 + 0x2a8);
            uVar22 = *(uint64_t *)(piVar14 + 0x2a6);
            if ((in_R9 != (int64_t *)0x0) && (uVar22 != 0)) {
                do {
                    uVar1 = *(undefined2 *)(iVar23 + uVar11 * 2);
                    uVar19 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c402e;
                    iVar17 = func_0x0001801ab700(uVar19, uVar1);
                    if (iVar17 == 0) {
                        uVar9 = *(uint16_t *)(iVar23 + uVar11 * 2) | 0x1000000;
                    } else {
                        uVar1 = *(undefined2 *)(iVar17 + 0x1c);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c403e;
                        uVar9 = func_0x0001801ab6c0(uVar1, 1);
                    }
                    *(uint32_t *)((int64_t)in_R9 + uVar11 * 4) = uVar9;
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar22);
            }
            return (int32_t *)(uVar22 & 0xffffffff);
        }
        goto code_r0x0001801c3b04;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_30h + iVar13 + iVar10) = iVar23;
        *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c409e;
        piVar20 = (int32_t *)func_0x0001801abb30(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa);
        break;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_30h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&arg_28h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2b0;
        uVar19 = *(undefined8 *)(in_RCX + 2);
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2aa;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40ea;
        piVar20 = (int32_t *)func_0x0001801abdc0(uVar19, piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac);
        break;
    case 0x5d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40fa;
        uVar6 = func_0x0001801ac8f0(piVar14, in_R8 & 0xffffffff);
        if (iVar8 == -1) {
            piVar20 = (int32_t *)(uint64_t)uVar6;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c410d;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar6, 1);
        }
        break;
    case 0x61:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c419a;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 0);
        break;
    case 0x62:
        uVar19 = 0;
        goto code_r0x0001801c41a2;
    case 0x65:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41d2;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 1);
        break;
    case 0x66:
        uVar19 = 1;
code_r0x0001801c41a2:
        uVar18 = *(undefined8 *)(piVar14 + 0x21e);
        uVar16 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41b5;
        piVar20 = (int32_t *)func_0x0001801ac780(uVar16, uVar18, in_R9, uVar19);
        break;
    case 0x67:
        if ((piVar14[0x1e] == 0) && (piVar14[0xd0] != 0)) {
            if (in_R9 != (int64_t *)0x0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xd2);
            }
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0xd4];
        }
        goto code_r0x0001801c3b04;
    case 0x68:
        if (piVar14[0x1e] != 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4229;
            piVar20 = (int32_t *)func_0x0001801c5900(uVar19, in_R9, iVar23);
            return piVar20;
        }
        goto code_r0x0001801c3b04;
    case 0x69:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c423b;
        piVar20 = (int32_t *)func_0x0001801a1400(piVar14, 0, in_R8 & 0xffffffff);
        break;
    case 0x6a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4255;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 0, in_R8 & 0xffffffff);
        break;
    case 0x6b:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4272;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 1, in_R8 & 0xffffffff);
        break;
    case 0x6c:
        iVar10 = *(int64_t *)(piVar14 + 0x100);
        goto code_r0x0001801c42d8;
    case 0x6d:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0x138) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4344;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0x138);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x6f:
        if (*(int64_t *)(piVar14 + 0x2a0) != 0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a0);
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0x29e];
        }
        goto code_r0x0001801c3b04;
    case 0x73:
        *in_R9 = *(int64_t *)(**(int64_t **)(piVar14 + 0x21e) + 0x10);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x74:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f86;
        piVar20 = (int32_t *)func_0x0001801a2260(uVar19, in_R9);
        break;
    case 0x75:
        if (iVar8 != 3) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3fed;
            piVar20 = (int32_t *)func_0x0001801a2550(uVar19, in_R8 & 0xffffffff);
            return piVar20;
        }
        if ((piVar14[0x1e] != 0) && (*(int64_t *)(piVar14 + 0xc0) != 0)) {
            if ((*(uint8_t *)(*(int64_t *)(piVar14 + 0xc0) + 0x20) & 0x44) != 0) {
                return (int32_t *)0x2;
            }
            if (*(int64_t *)(piVar14 + 0xf6) != 0) {
                **(int64_t **)(piVar14 + 0x21e) = *(int64_t *)(piVar14 + 0xf6);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x76:
        *(int32_t *)(*(int64_t *)(piVar14 + 0x21e) + 0x18) = iVar8;
code_r0x0001801c3b9f:
        piVar20 = (int32_t *)0x1;
        break;
    case 0x7f:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x288];
        break;
    case 0x84:
        iVar10 = *(int64_t *)(piVar14 + 0xf4);
code_r0x0001801c42d8:
        if (iVar10 != 0) {
            *(undefined4 *)in_R9 = *(undefined4 *)(iVar10 + 0x14);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x85:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0xc2) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4382;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xc2);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x86:
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar14 + 6) + 0x36) + 0x50) & 8) == 0) &&
             (iVar8 = **(int32_t **)(piVar14 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)) &&
           (*(char *)((int64_t)piVar14 + 0x4dd) != '\0')) {
            uVar1 = *(undefined2 *)((int64_t)piVar14 + 0x4de);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4158;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar1, 1);
        } else {
            if (*(int64_t *)(piVar14 + 0x23e) != 0) {
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x23e) + 0x304);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c417e;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar11 & 0xffff, 1);
        }
        break;
    case 0x87:
        if (in_R9 != (int64_t *)0x0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a8);
        }
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x2a6];
        break;
    case 0x89:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4289;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 0);
        break;
    case 0x8a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c42a3;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 1);
        break;
    case 0x8c:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0xf4) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0xf4);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x8d:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0x100) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0x100);
            return (int32_t *)0x1;
        }
code_r0x0001801c3b04:
        piVar20 = (int32_t *)0x0;
        break;
    case 0x8e:
        *in_R9 = *(int64_t *)(piVar14 + 0x296);
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3eb0;
        piVar20 = (int32_t *)func_0x000180222010(uVar19);
        break;
    case 0x8f:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ed5;
            fcn.180224990(iVar23, 0x1804b3080, 0xe9b);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ef6;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f05;
        func_0x000180222050(uVar19, 0x18023f230);
        *(int64_t **)(piVar14 + 0x296) = in_R9;
        piVar20 = (int32_t *)0x1;
    }
    return piVar20;
}

// ============================================================
// Function: FUN_1801c2b97
// Address: 0x1801c2b97
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_4f0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_47h
// WARNING: [rz-ghidra] Detected overlap for variable arg_46h
// WARNING: [rz-ghidra] Removing arg arg_c70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c80h because it doesn't fit into ProtoModel

int32_t * fcn.1801c2720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                       int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                       int64_t arg_78h, int64_t arg_f8h, int64_t arg_108h)
{
    undefined2 uVar1;
    code *pcVar2;
    undefined *puVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint16_t uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int32_t *piVar14;
    int32_t *in_RCX;
    int16_t iVar15;
    int32_t in_EDX;
    undefined8 uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    undefined8 uVar18;
    undefined8 uVar19;
    int32_t *piVar20;
    int32_t iVar21;
    uint64_t in_R8;
    uint64_t uVar22;
    int64_t *in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int64_t iVar23;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2735;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar8 = 0;
    piVar14 = piVar20;
    if (*in_RCX == 0) {
        piVar14 = in_RCX;
    }
    if (piVar14 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    iVar21 = (int32_t)in_R8;
    if (in_EDX == 0x11) {
        if (iVar21 < 0xd0) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar21;
        return (int32_t *)(in_R8 & 0xffffffff);
    }
    if (in_EDX == 0x49) {
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2808;
            uVar11 = func_0x0001802450c0();
            if (*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) < uVar11) {
                iVar8 = -1;
                piVar14 = piVar20;
            } else {
                piVar14 = (int32_t *)(*(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) - uVar11);
                if (piVar14 < (int32_t *)0xe4e1c1) {
                    if (piVar14 < (int32_t *)0xe4e1c0) {
                        iVar8 = -1;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            if (0 < iVar8) {
                piVar20 = piVar14;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c2851;
            iVar10 = func_0x0001801c30c0(piVar20);
            *in_R9 = iVar10;
            piVar20 = (int32_t *)0x1;
        }
        return piVar20;
    }
    if (in_EDX == 0x4a) {
        uVar19 = *(undefined8 *)((int64_t)&var_18h + iVar10);
        *(undefined8 *)((int64_t)&arg_38h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
        iVar23 = iVar10 + 0x18;
        *(undefined8 *)((int64_t)&var_18h + iVar10) = *(undefined8 *)((int64_t)&arg_30h + iVar10);
        *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c2970;
        iVar13 = fcn.18045a350();
        iVar13 = -iVar13;
        if (*(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) != 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2990;
            uVar11 = func_0x0001802450c0();
            iVar12 = *(int64_t *)(piVar14 + 0x13c);
            iVar17 = -1;
            if (*(uint64_t *)(iVar12 + 0x1c0) < uVar11) {
                iVar8 = -1;
                uVar11 = 0;
            } else {
                uVar11 = *(uint64_t *)(iVar12 + 0x1c0) - uVar11;
                if (uVar11 < 0xe4e1c1) {
                    if (uVar11 < 15000000) {
                        iVar8 = -1;
                    } else {
                        iVar8 = 0;
                    }
                } else {
                    iVar8 = 1;
                }
            }
            uVar22 = 0;
            if (0 < iVar8) {
                uVar22 = uVar11;
            }
            if (uVar22 == 0) {
                pcVar2 = *(code **)(iVar12 + 0x1d0);
                if (pcVar2 == (code *)0x0) {
                    *(int32_t *)(iVar12 + 0x1c8) = *(int32_t *)(iVar12 + 0x1c8) * 2;
                    if (60000000 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8)) {
                        *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = 60000000;
                    }
                } else {
                    uVar18 = *(undefined8 *)(piVar14 + 0x10);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c29f7;
                    uVar7 = (*pcVar2)(uVar18);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) = uVar7;
                }
                *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) =
                     *(int32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8) + 1;
                if (2 < *(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a51;
                    uVar11 = func_0x000180193b40(piVar14);
                    if ((uVar11 >> 0xc & 1) == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a60;
                        uVar18 = func_0x000180193e90(piVar14);
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2a73;
                        iVar8 = func_0x000180219d10(uVar18, 0x2f, 0, 0);
                        if ((uint64_t)(int64_t)iVar8 < *(uint64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130)) {
                            *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x130) = (int64_t)iVar8;
                        }
                    }
                }
                iVar12 = *(int64_t *)(piVar14 + 0x13c);
                if (0xc < *(uint32_t *)(iVar12 + 0x1b8)) {
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aa2;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2aba;
                    func_0x0001802295a0(0x1804b05f8, 0x181, 0x1804b0608);
                    *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2acd;
                    func_0x00018019b5e0(piVar14, 0xffffffff, 0x138, 0);
                    return (int32_t *)0xffffffff;
                }
                iVar5 = *(int64_t *)(iVar12 + 0x1c0);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) = uVar19;
                if (iVar5 == 0) {
                    pcVar2 = *(code **)(iVar12 + 0x1d0);
                    if (pcVar2 == (code *)0x0) {
                        *(undefined4 *)(iVar12 + 0x1c8) = 1000000;
                    } else {
                        *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b00;
                        uVar7 = (*pcVar2)(piVar14, 0);
                        *(undefined4 *)(iVar12 + 0x1c8) = uVar7;
                    }
                }
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c8) * 1000;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b2b;
                iVar12 = func_0x0001802450c0();
                if (uVar11 < -iVar12 - 1U || uVar11 - (-iVar12 - 1U) == 0) {
                    iVar17 = iVar12 + uVar11;
                }
                *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x1c0) = iVar17;
                iVar17 = *(int64_t *)(piVar14 + 0x13c);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b57;
                uVar18 = func_0x000180193c40(piVar14);
                uVar19 = *(undefined8 *)(iVar17 + 0x1c0);
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b66;
                uVar19 = func_0x0001801c30c0(uVar19);
                *(undefined8 *)((int64_t)&arg_48h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801c2b80;
                func_0x000180219d10(uVar18, 0x2d, 0, (int64_t)&arg_48h + iVar13 + iVar10);
                uVar19 = *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_50h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_58h + iVar13 + iVar10) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_60h + iVar13 + iVar10) =
                     *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10);
                *(undefined8 *)((int64_t)&arg_38h + iVar13 + iVar10) = uVar19;
                *(undefined8 *)((int64_t)&arg_30h + iVar13 + iVar10) = unaff_R12;
                *(undefined8 *)((int64_t)&arg_28h + iVar13 + iVar10) = unaff_R13;
                *(undefined8 *)((int64_t)&var_20h + iVar13 + iVar10) = unaff_R14;
                *(undefined8 *)((int64_t)&var_18h + iVar13 + iVar10) = unaff_R15;
                *(undefined8 *)((int64_t)&var_10h + iVar13 + iVar10) = 0x1801cb802;
                iVar10 = fcn.18045a350();
                iVar10 = -iVar10;
                *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18) =
                     *(uint64_t *)0x1806a3940 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18;
                uVar19 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x13c) + 0x120);
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb82a;
                uVar19 = func_0x00018001ed90(uVar19);
                *(undefined8 *)((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18) = uVar19;
                *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb839;
                iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                do {
                    if (iVar17 == 0) {
code_r0x0001801cb9bc:
                        uVar11 = *(uint64_t *)((int64_t)&arg_48h + iVar10 + iVar13 + iVar23 + -0x18);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9c9;
                        piVar20 = (int32_t *)
                                  func_0x000180459870(uVar11 ^ (int64_t)&var_18h + iVar10 + iVar13 + iVar23 + -0x18);
                        return piVar20;
                    }
                    iVar17 = *(int64_t *)(iVar17 + 8);
                    *(undefined8 *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18) = 0;
                    iVar15 = *(int16_t *)(iVar17 + 0x10) * 2 - *(int16_t *)(iVar17 + 0x28);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x11) = (char)iVar15;
                    *(char *)((int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x12) = (char)((uint16_t)iVar15 >> 8);
                    uVar19 = *(undefined8 *)(iVar17 + 0x120);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb89b;
                    iVar17 = func_0x0001801a6680(uVar19, (int64_t)&arg_40h + iVar10 + iVar13 + iVar23 + -0x18);
                    if (iVar17 == 0) {
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ec;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba04;
                        func_0x0001802295a0(0x1804b3a00, 0x4bb, 0x1804b3aa0);
                        *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cba1a;
                        func_0x00018019b5e0(piVar14, 0x50, 0xc0103, 0);
                        goto code_r0x0001801cb9bc;
                    }
                    puVar3 = *(undefined **)(iVar17 + 8);
                    iVar12 = 1;
                    iVar17 = *(int64_t *)(puVar3 + 8);
                    uVar19 = *(undefined8 *)(puVar3 + 0x40);
                    if (*(int32_t *)(puVar3 + 0x28) == 0) {
                        iVar12 = 0xc;
                    }
                    uVar18 = *(undefined8 *)(*(int64_t *)(piVar14 + 0x3e) + 8);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb8d0;
                    func_0x000180498030(uVar18, uVar19, iVar17 + iVar12);
                    iVar17 = *(int64_t *)(piVar14 + 0x13c);
                    *(int64_t *)(piVar14 + 0x42) = *(int64_t *)(puVar3 + 8) + iVar12;
                    uVar1 = *(undefined2 *)(puVar3 + 0x10);
                    uVar19 = *(undefined8 *)(puVar3 + 8);
                    uVar18 = *(undefined8 *)(puVar3 + 0x20);
                    *(undefined *)(iVar17 + 0x138) = *puVar3;
                    *(undefined8 *)(iVar17 + 0x140) = uVar19;
                    *(undefined2 *)(iVar17 + 0x148) = uVar1;
                    *(undefined8 *)(iVar17 + 0x158) = uVar18;
                    *(undefined8 *)(iVar17 + 0x150) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x31c);
                    uVar18 = *(undefined8 *)(piVar14 + 800);
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 1;
                    iVar17 = *(int64_t *)(puVar3 + 0x30);
                    uVar16 = *(undefined8 *)(piVar14 + 0x16);
                    *(int64_t *)(piVar14 + 0x31c) = iVar17;
                    uVar4 = *(undefined8 *)(puVar3 + 0x38);
                    *(undefined8 *)(piVar14 + 800) = uVar4;
                    pcVar2 = *(code **)(iVar17 + 0x58);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb959;
                    (*pcVar2)(uVar4, uVar16);
                    uVar16 = 0x16;
                    if (*(int32_t *)(puVar3 + 0x28) != 0) {
                        uVar16 = 0x14;
                    }
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb96e;
                    iVar8 = func_0x0001801ca8a0(piVar14, uVar16);
                    *(undefined8 *)(piVar14 + 0x31c) = uVar19;
                    *(undefined8 *)(piVar14 + 800) = uVar18;
                    *(undefined4 *)(*(int64_t *)(piVar14 + 0x13c) + 0x1cc) = 0;
                    uVar19 = *(undefined8 *)(piVar14 + 0x16);
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9a0;
                    func_0x000180219d10(uVar19, 0xb, 0);
                    if (iVar8 < 1) goto code_r0x0001801cb9bc;
                    *(undefined8 *)((int64_t)&var_10h + iVar10 + iVar13 + iVar23 + -0x18) = 0x1801cb9ae;
                    iVar17 = func_0x0001801a67e0((int64_t)&arg_38h + iVar10 + iVar13 + iVar23 + -0x18);
                } while( true );
            }
        }
        return (int32_t *)0x0;
    }
    if (in_EDX == 0x78) {
        if (iVar21 < 0x100) {
            return (int32_t *)0x0;
        }
        *(int64_t *)(*(int64_t *)(piVar14 + 0x13c) + 0x128) = (int64_t)iVar21;
        return (int32_t *)0x1;
    }
    if (in_EDX == 0x79) {
        return (int32_t *)0x100;
    }
    uVar19 = *(undefined8 *)((int64_t)&arg_30h + iVar10);
    uVar18 = *(undefined8 *)((int64_t)&var_18h + iVar10);
    *(undefined8 *)((int64_t)&arg_30h + iVar10) = *(undefined8 *)((int64_t)&arg_28h + iVar10);
    *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = uVar19;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = uVar18;
    *(undefined8 *)((int64_t)&var_8h + iVar10) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar10) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c3a2c;
    iVar13 = fcn.18045a350();
    iVar13 = -iVar13;
    uVar11 = 0;
    iVar8 = (int32_t)in_R8;
    iVar23 = (int64_t)iVar8;
    piVar20 = (int32_t *)0x0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x0001801c3b04;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3a65;
            piVar14 = (int32_t *)func_0x0001801bda50();
            *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
            if (piVar14 != (int32_t *)0x0) goto code_r0x0001801c3a76;
        }
        goto code_r0x0001801c3b04;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10) = 0;
    piVar14 = in_RCX;
code_r0x0001801c3a76:
    // switch table (141 cases) at 0x1801c43e8
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ada;
            func_0x000180229480();
            uVar19 = 0xdef;
            goto code_r0x0001801c3ae6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b28;
        iVar23 = func_0x0001801bc7c0(in_R9);
        if (iVar23 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b35;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b4d;
            func_0x0001802295a0(0x1804b3080, 0xdf4, 0x1804b3090);
            uVar19 = 0x80005;
            goto code_r0x0001801c3af7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b5f;
        iVar8 = func_0x000180194310(in_RCX, iVar23);
        if (iVar8 != 0) goto code_r0x0001801c3b9f;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b6b;
        func_0x00018022ecc0(iVar23);
        goto code_r0x0001801c3b04;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
            *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
            *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c02;
            piVar20 = (int32_t *)func_0x0001801bc970(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa)
            ;
            return piVar20;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3bb3;
        func_0x000180229480();
        uVar19 = 0xe0b;
code_r0x0001801c3ae6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3af2;
        func_0x0001802295a0(0x1804b3080, uVar19, 0x1804b3090);
        uVar19 = 0xc0102;
        goto code_r0x0001801c3af7;
    case 6:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b72;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b8a;
        func_0x0001802295a0(0x1804b3080, 0xe00, 0x1804b3090);
        uVar19 = 0xc0101;
        goto code_r0x0001801c3af7;
    case 10:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        break;
    case 0xb:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x75];
        piVar14[0x75] = 0;
        break;
    case 0xc:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x74];
        break;
    case 0xd:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x58];
        break;
    case 0x10:
        *(int64_t **)(piVar14 + 0x140) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x37:
        if (iVar8 == 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x286);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c29;
            fcn.180224990(uVar19, 0x1804b3080, 0xe23);
            *(undefined8 *)(piVar14 + 0x286) = 0;
            if (in_R9 == (int64_t *)0x0) {
                return (int32_t *)0x1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c46;
            iVar23 = func_0x000180498cd0(in_R9);
            if (iVar23 - 1U < 0xff) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c66;
                iVar23 = func_0x0001802231e0(in_R9, 0x1804b3080, 0xe2e);
                *(int64_t *)(piVar14 + 0x286) = iVar23;
                if (iVar23 != 0) {
                    return (int32_t *)0x1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c7b;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3c93;
                func_0x0001802295a0(0x1804b3080, 0xe2f, 0x1804b3090);
                uVar19 = 0xc0103;
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ca2;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cba;
                func_0x0001802295a0(0x1804b3080, 0xe2b, 0x1804b3090);
                uVar19 = 0x13f;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3cc9;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ce1;
            func_0x0001802295a0(0x1804b3080, 0xe33, 0x1804b3090);
            uVar19 = 0x140;
        }
code_r0x0001801c3af7:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3b04;
        func_0x0001802296d0(0x14, uVar19, 0);
        goto code_r0x0001801c3b04;
    case 0x39:
        *(int64_t **)(piVar14 + 0x284) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x41:
        piVar14[0x288] = iVar8;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x42:
        piVar20 = (int32_t *)0x1;
        *in_R9 = *(int64_t *)(piVar14 + 0x290);
        break;
    case 0x43:
        *(int64_t **)(piVar14 + 0x290) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x44:
        *in_R9 = *(int64_t *)(piVar14 + 0x28e);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x45:
        *(int64_t **)(piVar14 + 0x28e) = in_R9;
        piVar20 = (int32_t *)0x1;
        break;
    case 0x46:
        *in_R9 = 0;
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        piVar20 = (int32_t *)0xffffffff;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d86;
        iVar23 = func_0x000180222340(uVar19, 0);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3d98;
            uVar9 = func_0x00018023f2c0(iVar23, (int64_t)&arg_68h + iVar13 + iVar10);
            if (0 < (int32_t)uVar9) {
                uVar19 = *(undefined8 *)(piVar14 + 0x292);
                *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3db8;
                fcn.180224990(uVar19, 0x1804b3080, 0xe64);
                *(undefined8 *)(piVar14 + 0x292) = *(undefined8 *)((int64_t)&arg_68h + iVar13 + iVar10);
                *in_R9 = *(int64_t *)((int64_t)&arg_68h + iVar13 + iVar10);
                piVar20 = (int32_t *)(uint64_t)uVar9;
                *(int64_t *)(piVar14 + 0x294) = (int64_t)(int32_t)uVar9;
            }
        }
        break;
    case 0x47:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3dff;
            fcn.180224990(iVar23, 0x1804b3080, 0xe75);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e20;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e2f;
        func_0x000180222050(uVar19, 0x18023f230);
        *(undefined8 *)(piVar14 + 0x296) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return (int32_t *)0x1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e48;
        uVar19 = func_0x000180221f60(0, 1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e57;
        iVar23 = func_0x000180222290(uVar19, 0x180196ec0);
        *(int64_t *)(piVar14 + 0x296) = iVar23;
        if (iVar23 != 0) {
            *(int64_t **)((int64_t)&arg_68h + iVar13 + iVar10) = in_R9;
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e7b;
            iVar23 = func_0x00018023f280(0, (int64_t)&arg_68h + iVar13 + iVar10, in_R8 & 0xffffffff);
            if (iVar23 == 0) {
                return (int32_t *)0x1;
            }
            uVar19 = *(undefined8 *)(piVar14 + 0x296);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3e93;
            func_0x000180222110(uVar19, iVar23);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x58:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f34;
            piVar20 = (int32_t *)func_0x0001801a2320(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f2a;
            piVar20 = (int32_t *)func_0x0001801a2430();
        }
        break;
    case 0x59:
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f55;
            piVar20 = (int32_t *)func_0x0001801a17b0(piVar14, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f4b;
            piVar20 = (int32_t *)func_0x0001801a1880();
        }
        break;
    case 0x5a:
        if (*(int64_t *)(piVar14 + 0x23e) != 0) {
            iVar23 = *(int64_t *)(piVar14 + 0x2a8);
            uVar22 = *(uint64_t *)(piVar14 + 0x2a6);
            if ((in_R9 != (int64_t *)0x0) && (uVar22 != 0)) {
                do {
                    uVar1 = *(undefined2 *)(iVar23 + uVar11 * 2);
                    uVar19 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c402e;
                    iVar17 = func_0x0001801ab700(uVar19, uVar1);
                    if (iVar17 == 0) {
                        uVar9 = *(uint16_t *)(iVar23 + uVar11 * 2) | 0x1000000;
                    } else {
                        uVar1 = *(undefined2 *)(iVar17 + 0x1c);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c403e;
                        uVar9 = func_0x0001801ab6c0(uVar1, 1);
                    }
                    *(uint32_t *)((int64_t)in_R9 + uVar11 * 4) = uVar9;
                    uVar11 = uVar11 + 1;
                } while (uVar11 < uVar22);
            }
            return (int32_t *)(uVar22 & 0xffffffff);
        }
        goto code_r0x0001801c3b04;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_30h + iVar13 + iVar10) = iVar23;
        *(int64_t **)((int64_t)&arg_28h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2b0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c409e;
        piVar20 = (int32_t *)func_0x0001801abb30(piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac, piVar14 + 0x2aa);
        break;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_30h + iVar13 + iVar10) = in_R9;
        *(int32_t **)((int64_t)&arg_28h + iVar13 + iVar10) = piVar14 + 0x2ae;
        *(int32_t **)((int64_t)&var_20h + iVar13 + iVar10) = piVar14 + 0x2b0;
        uVar19 = *(undefined8 *)(in_RCX + 2);
        *(int32_t **)((int64_t)&var_18h + iVar13 + iVar10) = piVar14 + 0x2aa;
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40ea;
        piVar20 = (int32_t *)func_0x0001801abdc0(uVar19, piVar14 + 0x2a4, piVar14 + 0x2a2, piVar14 + 0x2ac);
        break;
    case 0x5d:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c40fa;
        uVar6 = func_0x0001801ac8f0(piVar14, in_R8 & 0xffffffff);
        if (iVar8 == -1) {
            piVar20 = (int32_t *)(uint64_t)uVar6;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c410d;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar6, 1);
        }
        break;
    case 0x61:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c419a;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 0);
        break;
    case 0x62:
        uVar19 = 0;
        goto code_r0x0001801c41a2;
    case 0x65:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41d2;
        piVar20 = (int32_t *)func_0x0001801ac640(uVar19, in_R9, iVar23, 1);
        break;
    case 0x66:
        uVar19 = 1;
code_r0x0001801c41a2:
        uVar18 = *(undefined8 *)(piVar14 + 0x21e);
        uVar16 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c41b5;
        piVar20 = (int32_t *)func_0x0001801ac780(uVar16, uVar18, in_R9, uVar19);
        break;
    case 0x67:
        if ((piVar14[0x1e] == 0) && (piVar14[0xd0] != 0)) {
            if (in_R9 != (int64_t *)0x0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xd2);
            }
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0xd4];
        }
        goto code_r0x0001801c3b04;
    case 0x68:
        if (piVar14[0x1e] != 0) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4229;
            piVar20 = (int32_t *)func_0x0001801c5900(uVar19, in_R9, iVar23);
            return piVar20;
        }
        goto code_r0x0001801c3b04;
    case 0x69:
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c423b;
        piVar20 = (int32_t *)func_0x0001801a1400(piVar14, 0, in_R8 & 0xffffffff);
        break;
    case 0x6a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4255;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 0, in_R8 & 0xffffffff);
        break;
    case 0x6b:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4272;
        piVar20 = (int32_t *)func_0x0001801a24c0(uVar19, in_R9, 1, in_R8 & 0xffffffff);
        break;
    case 0x6c:
        iVar10 = *(int64_t *)(piVar14 + 0x100);
        goto code_r0x0001801c42d8;
    case 0x6d:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0x138) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4344;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0x138);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x6f:
        if (*(int64_t *)(piVar14 + 0x2a0) != 0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a0);
            return (int32_t *)(uint64_t)(uint32_t)piVar14[0x29e];
        }
        goto code_r0x0001801c3b04;
    case 0x73:
        *in_R9 = *(int64_t *)(**(int64_t **)(piVar14 + 0x21e) + 0x10);
        piVar20 = (int32_t *)0x1;
        break;
    case 0x74:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f86;
        piVar20 = (int32_t *)func_0x0001801a2260(uVar19, in_R9);
        break;
    case 0x75:
        if (iVar8 != 3) {
            uVar19 = *(undefined8 *)(piVar14 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3fed;
            piVar20 = (int32_t *)func_0x0001801a2550(uVar19, in_R8 & 0xffffffff);
            return piVar20;
        }
        if ((piVar14[0x1e] != 0) && (*(int64_t *)(piVar14 + 0xc0) != 0)) {
            if ((*(uint8_t *)(*(int64_t *)(piVar14 + 0xc0) + 0x20) & 0x44) != 0) {
                return (int32_t *)0x2;
            }
            if (*(int64_t *)(piVar14 + 0xf6) != 0) {
                **(int64_t **)(piVar14 + 0x21e) = *(int64_t *)(piVar14 + 0xf6);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x76:
        *(int32_t *)(*(int64_t *)(piVar14 + 0x21e) + 0x18) = iVar8;
code_r0x0001801c3b9f:
        piVar20 = (int32_t *)0x1;
        break;
    case 0x7f:
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x288];
        break;
    case 0x84:
        iVar10 = *(int64_t *)(piVar14 + 0xf4);
code_r0x0001801c42d8:
        if (iVar10 != 0) {
            *(undefined4 *)in_R9 = *(undefined4 *)(iVar10 + 0x14);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x85:
        if ((*(int64_t *)(piVar14 + 0x23e) != 0) && (*(int64_t *)(piVar14 + 0xc2) != 0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4382;
            iVar8 = func_0x0001802308d0();
            if (iVar8 != 0) {
                *in_R9 = *(int64_t *)(piVar14 + 0xc2);
                return (int32_t *)0x1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x86:
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar14 + 6) + 0x36) + 0x50) & 8) == 0) &&
             (iVar8 = **(int32_t **)(piVar14 + 6), 0x303 < iVar8)) && (iVar8 != 0x10000)) &&
           (*(char *)((int64_t)piVar14 + 0x4dd) != '\0')) {
            uVar1 = *(undefined2 *)((int64_t)piVar14 + 0x4de);
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4158;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar1, 1);
        } else {
            if (*(int64_t *)(piVar14 + 0x23e) != 0) {
                uVar11 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar14 + 0x23e) + 0x304);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c417e;
            piVar20 = (int32_t *)func_0x0001801ab6c0(uVar11 & 0xffff, 1);
        }
        break;
    case 0x87:
        if (in_R9 != (int64_t *)0x0) {
            *in_R9 = *(int64_t *)(piVar14 + 0x2a8);
        }
        piVar20 = (int32_t *)(uint64_t)(uint32_t)piVar14[0x2a6];
        break;
    case 0x89:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c4289;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 0);
        break;
    case 0x8a:
        uVar19 = *(undefined8 *)(piVar14 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c42a3;
        piVar20 = (int32_t *)func_0x0001801a1fc0(uVar19, in_R9, 1);
        break;
    case 0x8c:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0xf4) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0xf4);
            return (int32_t *)0x1;
        }
        goto code_r0x0001801c3b04;
    case 0x8d:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar14 + 0x100) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar14 + 0x100);
            return (int32_t *)0x1;
        }
code_r0x0001801c3b04:
        piVar20 = (int32_t *)0x0;
        break;
    case 0x8e:
        *in_R9 = *(int64_t *)(piVar14 + 0x296);
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3eb0;
        piVar20 = (int32_t *)func_0x000180222010(uVar19);
        break;
    case 0x8f:
        iVar23 = *(int64_t *)(piVar14 + 0x292);
        if (iVar23 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ed5;
            fcn.180224990(iVar23, 0x1804b3080, 0xe9b);
            *(undefined8 *)(piVar14 + 0x292) = 0;
            *(undefined8 *)(piVar14 + 0x294) = 0;
        }
        uVar19 = *(undefined8 *)(piVar14 + 0x296);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3ef6;
        uVar19 = func_0x000180222290(uVar19, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar13 + iVar10) = 0x1801c3f05;
        func_0x000180222050(uVar19, 0x18023f230);
        *(int64_t **)(piVar14 + 0x296) = in_R9;
        piVar20 = (int32_t *)0x1;
    }
    return piVar20;
}

// ============================================================
// Function: FUN_1801c2bb0
// Address: 0x1801c2bb0
// Size: 130 bytes
// ============================================================
undefined8 fcn.1801c2bb0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2bbc;
    iVar2 = fcn.18045a350();
    if (*(int64_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x1c0) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801c2bd8;
        uVar3 = func_0x0001802450c0();
        uVar4 = *(uint64_t *)(*(int64_t *)(param_1 + 0x4f0) + 0x1c0);
        if (uVar4 < uVar3) {
            iVar1 = -1;
            uVar4 = 0;
        } else {
            uVar4 = uVar4 - uVar3;
            if (uVar4 < 0xe4e1c1) {
                if (uVar4 < 15000000) {
                    iVar1 = -1;
                } else {
                    iVar1 = 0;
                }
            } else {
                iVar1 = 1;
            }
        }
        uVar3 = 0;
        if (0 < iVar1) {
            uVar3 = uVar4;
        }
        if (uVar3 == 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c2c40
// Address: 0x1801c2c40
// Size: 52 bytes
// ============================================================
int64_t fcn.1801c2c40(void)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c2c4a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c2c52;
    fcn.180193e90(*(int64_t *)(&stack0x00000038 + iVar2));
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c2c65;
    uVar1 = fcn.180219d10(*(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                          *(int64_t *)(&stack0x00000050 + iVar2));
    return 0x100 - (uint64_t)uVar1;
}

// ============================================================
// Function: FUN_1801c2c80
// Address: 0x1801c2c80
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801c2c80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t *piVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c2c95;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    piVar7 = (int32_t *)0x0;
    if (*in_RCX == 0) {
        piVar7 = in_RCX;
    }
    if (piVar7 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cc3;
    iVar2 = func_0x0001801c73a0(piVar7 + 0x314);
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cd3;
    iVar2 = func_0x0001801c5550(in_RCX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cf7;
        iVar4 = func_0x000180224d60(0x1d8, 0x1804b05f8, 0x4f);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d08;
            uVar5 = func_0x0001801a67b0();
            *(undefined8 *)(iVar4 + 0x118) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d14;
            iVar6 = func_0x0001801a67b0();
            *(int64_t *)(iVar4 + 0x120) = iVar6;
            if (piVar7[0x1e] != 0) {
                *(undefined8 *)(iVar4 + 0x100) = 0xff;
            }
            *(undefined8 *)(iVar4 + 0x128) = 0;
            *(undefined8 *)(iVar4 + 0x130) = 0;
            if ((*(int64_t *)(iVar4 + 0x118) != 0) && (iVar6 != 0)) {
                *(int64_t *)(piVar7 + 0x13c) = iVar4;
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d5e;
                iVar2 = (*pcVar1)(in_RCX);
                return iVar2 != 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d80;
            fcn.1801a66d0();
            uVar5 = *(undefined8 *)(iVar4 + 0x120);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d8c;
            fcn.1801a66d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da1;
            fcn.180224990(iVar4, 0x1804b05f8, 0x61);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da9;
        fcn.1801c4f10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
        return false;
    }
    return false;
}

// ============================================================
// Function: FUN_1801c2ce1
// Address: 0x1801c2ce1
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801c2c80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t *piVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c2c95;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    piVar7 = (int32_t *)0x0;
    if (*in_RCX == 0) {
        piVar7 = in_RCX;
    }
    if (piVar7 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cc3;
    iVar2 = func_0x0001801c73a0(piVar7 + 0x314);
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cd3;
    iVar2 = func_0x0001801c5550(in_RCX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cf7;
        iVar4 = func_0x000180224d60(0x1d8, 0x1804b05f8, 0x4f);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d08;
            uVar5 = func_0x0001801a67b0();
            *(undefined8 *)(iVar4 + 0x118) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d14;
            iVar6 = func_0x0001801a67b0();
            *(int64_t *)(iVar4 + 0x120) = iVar6;
            if (piVar7[0x1e] != 0) {
                *(undefined8 *)(iVar4 + 0x100) = 0xff;
            }
            *(undefined8 *)(iVar4 + 0x128) = 0;
            *(undefined8 *)(iVar4 + 0x130) = 0;
            if ((*(int64_t *)(iVar4 + 0x118) != 0) && (iVar6 != 0)) {
                *(int64_t *)(piVar7 + 0x13c) = iVar4;
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d5e;
                iVar2 = (*pcVar1)(in_RCX);
                return iVar2 != 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d80;
            fcn.1801a66d0();
            uVar5 = *(undefined8 *)(iVar4 + 0x120);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d8c;
            fcn.1801a66d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da1;
            fcn.180224990(iVar4, 0x1804b05f8, 0x61);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da9;
        fcn.1801c4f10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
        return false;
    }
    return false;
}

// ============================================================
// Function: FUN_1801c2d7b
// Address: 0x1801c2d7b
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801c2c80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t *piVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c2c95;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    piVar7 = (int32_t *)0x0;
    if (*in_RCX == 0) {
        piVar7 = in_RCX;
    }
    if (piVar7 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cc3;
    iVar2 = func_0x0001801c73a0(piVar7 + 0x314);
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cd3;
    iVar2 = func_0x0001801c5550(in_RCX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cf7;
        iVar4 = func_0x000180224d60(0x1d8, 0x1804b05f8, 0x4f);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d08;
            uVar5 = func_0x0001801a67b0();
            *(undefined8 *)(iVar4 + 0x118) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d14;
            iVar6 = func_0x0001801a67b0();
            *(int64_t *)(iVar4 + 0x120) = iVar6;
            if (piVar7[0x1e] != 0) {
                *(undefined8 *)(iVar4 + 0x100) = 0xff;
            }
            *(undefined8 *)(iVar4 + 0x128) = 0;
            *(undefined8 *)(iVar4 + 0x130) = 0;
            if ((*(int64_t *)(iVar4 + 0x118) != 0) && (iVar6 != 0)) {
                *(int64_t *)(piVar7 + 0x13c) = iVar4;
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d5e;
                iVar2 = (*pcVar1)(in_RCX);
                return iVar2 != 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d80;
            fcn.1801a66d0();
            uVar5 = *(undefined8 *)(iVar4 + 0x120);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d8c;
            fcn.1801a66d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da1;
            fcn.180224990(iVar4, 0x1804b05f8, 0x61);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da9;
        fcn.1801c4f10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
        return false;
    }
    return false;
}

// ============================================================
// Function: FUN_1801c2dad
// Address: 0x1801c2dad
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1801c2c80(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    int32_t *piVar7;
    undefined8 unaff_RDI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c2c95;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (int32_t *)0x0) {
        return false;
    }
    piVar7 = (int32_t *)0x0;
    if (*in_RCX == 0) {
        piVar7 = in_RCX;
    }
    if (piVar7 == (int32_t *)0x0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cc3;
    iVar2 = func_0x0001801c73a0(piVar7 + 0x314);
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cd3;
    iVar2 = func_0x0001801c5550(in_RCX);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2cf7;
        iVar4 = func_0x000180224d60(0x1d8, 0x1804b05f8, 0x4f);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d08;
            uVar5 = func_0x0001801a67b0();
            *(undefined8 *)(iVar4 + 0x118) = uVar5;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d14;
            iVar6 = func_0x0001801a67b0();
            *(int64_t *)(iVar4 + 0x120) = iVar6;
            if (piVar7[0x1e] != 0) {
                *(undefined8 *)(iVar4 + 0x100) = 0xff;
            }
            *(undefined8 *)(iVar4 + 0x128) = 0;
            *(undefined8 *)(iVar4 + 0x130) = 0;
            if ((*(int64_t *)(iVar4 + 0x118) != 0) && (iVar6 != 0)) {
                *(int64_t *)(piVar7 + 0x13c) = iVar4;
                pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d5e;
                iVar2 = (*pcVar1)(in_RCX);
                return iVar2 != 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d80;
            fcn.1801a66d0();
            uVar5 = *(undefined8 *)(iVar4 + 0x120);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2d8c;
            fcn.1801a66d0(uVar5);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da1;
            fcn.180224990(iVar4, 0x1804b05f8, 0x61);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2da9;
        fcn.1801c4f10(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000058 + iVar3));
        return false;
    }
    return false;
}

// ============================================================
// Function: FUN_1801c2dc0
// Address: 0x1801c2dc0
// Size: 387 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801c2dc0(int64_t arg_28h)
{
    int64_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2dd0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *(int64_t *)(in_RCX + 0x4f0);
    if (*(int64_t *)(iVar1 + 0x128) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2dec;
        fcn.180193e90(*(int64_t *)(&stack0x00000030 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2dff;
        uVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
        *(uint64_t *)(iVar1 + 0x130) = *(int64_t *)(iVar1 + 0x128) - (uint64_t)uVar2;
        *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x128) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2e2c;
    fcn.180193e90(*(int64_t *)(&stack0x00000030 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2e3f;
    uVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
    if (*(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130) < 0x100 - (uint64_t)uVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2e67;
        uVar5 = func_0x000180193b40(in_RCX);
        if ((uVar5 >> 0xc & 1) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2e7a;
        fcn.180193e90(*(int64_t *)(&stack0x00000030 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2e8d;
        iVar3 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
        *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130) = (int64_t)iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2ea6;
        fcn.180193e90(*(int64_t *)(&stack0x00000030 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2eb9;
        uVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar4));
        if (*(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130) < 0x100 - (uint64_t)uVar2) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2ed8;
            fcn.180193e90(*(int64_t *)(&stack0x00000030 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2eeb;
            uVar2 = fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar4));
            *(uint64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x130) = 0x100 - (uint64_t)uVar2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2f13;
            fcn.180193e90(*(int64_t *)(&stack0x00000030 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c2f26;
            fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c2f50
// Address: 0x1801c2f50
// Size: 22 bytes
// ============================================================
uint64_t fcn.1801c2f50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    int32_t *piVar6;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1801c59b5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            if (piVar6[0x20] == 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1801c59e8;
                iVar3 = func_0x00018019b250();
                if (iVar3 == 0) {
                    uVar1 = piVar6[0x21];
                    if ((uVar1 & 1) == 0) {
                        piVar6[0x21] = uVar1 | 1;
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1801c5a13;
                        func_0x0001801c6e50(piVar6, 1, 0);
                        if (0 < piVar6[0x71]) {
                            return 0xffffffff;
                        }
                    } else if (piVar6[0x71] < 1) {
                        if ((uVar1 & 2) == 0) {
                            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x80);
                            *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4) = (int64_t)&arg_70h + iVar5 + iVar4;
                            *(undefined4 *)((int64_t)&arg_48h + iVar5 + iVar4) = 0;
                            *(undefined8 *)((int64_t)&arg_40h + iVar5 + iVar4) = 0;
                            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1801c5a97;
                            (*pcVar2)(in_RCX, 0, 0, 0);
                            if ((*(uint8_t *)(piVar6 + 0x21) & 2) == 0) {
                                return 0xffffffff;
                            }
                        }
                    } else {
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x90);
                        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1801c5a60;
                        iVar3 = (*pcVar2)(in_RCX);
                        if (iVar3 == -1) {
                            return 0xffffffff;
                        }
                    }
                    if (piVar6[0x21] != 3) {
                        return 0;
                    }
                    return (uint64_t)(piVar6[0x71] == 0);
                }
            }
            piVar6[0x21] = 3;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c2f70
// Address: 0x1801c2f70
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801c2f70(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c2f80;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = *(int64_t *)(in_RCX + 0x4f0);
    if (*(int64_t *)(iVar6 + 0x1c0) == 0) {
        pcVar1 = *(code **)(iVar6 + 0x1d0);
        if (pcVar1 == (code *)0x0) {
            *(undefined4 *)(iVar6 + 0x1c8) = 1000000;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2fab;
            uVar2 = (*pcVar1)();
            *(undefined4 *)(iVar6 + 0x1c8) = uVar2;
        }
    }
    uVar7 = (uint64_t)*(uint32_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) * 1000;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c2fd6;
    iVar4 = func_0x0001802450c0();
    iVar6 = -1;
    if (uVar7 < -iVar4 - 1U || uVar7 - (-iVar4 - 1U) == 0) {
        iVar6 = iVar4 + uVar7;
    }
    *(int64_t *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0) = iVar6;
    iVar6 = *(int64_t *)(in_RCX + 0x4f0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c3009;
    func_0x000180193c40(in_RCX);
    uVar5 = *(undefined8 *)(iVar6 + 0x1c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c3018;
    uVar5 = func_0x0001801c30c0(uVar5);
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = uVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c3032;
    fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar3), *(int64_t *)(&stack0x00000040 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801c3040
// Address: 0x1801c3040
// Size: 123 bytes
// ============================================================
void fcn.1801c3040(int64_t arg_28h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t in_RCX;
    undefined8 uVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c304c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1b8) = 0;
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0) = 0;
    *(undefined4 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c8) = 1000000;
    uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x1c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c3093;
    uVar6 = func_0x0001801c30c0(uVar6);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = uVar6;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801c30ae;
    fcn.180219d10(*(int64_t *)(&stack0x00000038 + iVar5), *(int64_t *)(&stack0x00000040 + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    uVar7 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801c2690;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
    *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801c26a9;
    iVar4 = func_0x0001801a6800(uVar6);
    if (iVar4 != 0) {
        *(undefined8 *)(&stack0x00000048 + iVar3 + iVar5) = uVar7;
        do {
            iVar1 = *(int64_t *)(iVar4 + 8);
            if (((*(int32_t *)(iVar1 + 0x28) != 0) && (*(int64_t *)(iVar1 + 0x30) != 0)) &&
               (*(int64_t *)(in_RCX + 0xc80) != *(int64_t *)(iVar1 + 0x38))) {
                pcVar2 = *(code **)(*(int64_t *)(iVar1 + 0x30) + 8);
                *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801c26dc;
                (*pcVar2)();
            }
            *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801c26e4;
            func_0x0001801cae70(iVar1);
            *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801c26ec;
            func_0x0001801a65e0(iVar4);
            uVar6 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x4f0) + 0x120);
            *(undefined8 *)((int64_t)auStackX_10 + iVar3 + iVar5) = 0x1801c26ff;
            iVar4 = func_0x0001801a6800(uVar6);
        } while (iVar4 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_1801c3130
// Address: 0x1801c3130
// Size: 95 bytes
// ============================================================
bool fcn.1801c3130(undefined8 param_1, undefined8 param_2, int32_t param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c313c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_3 == 0x101) {
        return true;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c3167;
    iVar1 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c3178;
        iVar1 = fcn.180244a90(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                             );
        return iVar1 != 0;
    }
    return false;
}

// ============================================================
// Function: FUN_1801c3190
// Address: 0x1801c3190
// Size: 24 bytes
// ============================================================
undefined8
fcn.1801c3190(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_70h, int64_t arg_80h, int64_t arg_88h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint64_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_8 [4];
    
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    uVar12 = 0x16;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar11) = 0x1801aea8e;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    pcVar2 = *(code **)(in_RCX + 0xd0);
    uVar3 = *(undefined8 *)(in_RCX + 0x40);
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar11) = 0;
    if ((((pcVar2 != (code *)0x0) && ((*(uint8_t *)(in_RCX + 0xe8) & 1) == 0)) && ((char)uVar12 == '\x16')) &&
       (uVar4 = *(uint64_t *)(in_RCX + 0x108), 3 < uVar4)) {
        iVar10 = *(int64_t *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&arg_30h + iVar9 + iVar11) = *(undefined8 *)(in_RCX + 0xe0);
        uVar5 = *(undefined8 *)(iVar10 + 8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aeb00;
        iVar8 = (*pcVar2)(uVar5, uVar4, (int64_t)&arg_88h + iVar9 + iVar11, (int64_t)&arg_70h + iVar9 + iVar11);
        if (iVar8 == 0) {
            return 0xffffffff;
        }
        if (*(uint64_t *)((int64_t)&arg_70h + iVar9 + iVar11) < 4) {
            return 0xffffffff;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aeb23;
        iVar10 = func_0x000180226380(uVar5);
        if (iVar10 == 0) {
            return 0xffffffff;
        }
        uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aeb46;
        func_0x000180498030(uVar5, *(undefined8 *)((int64_t)&arg_88h + iVar9 + iVar11), 
                            *(undefined8 *)((int64_t)&arg_70h + iVar9 + iVar11));
        *(undefined8 *)(in_RCX + 0x108) = *(undefined8 *)((int64_t)&arg_70h + iVar9 + iVar11);
        pcVar2 = *(code **)(in_RCX + 0xd8);
        *(int64_t *)(in_RCX + 0x100) = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8) + 4;
        uVar5 = *(undefined8 *)(in_RCX + 0xe0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aeb78;
        (*pcVar2)(uVar5);
        *(uint32_t *)(in_RCX + 0xe8) = *(uint32_t *)(in_RCX + 0xe8) | 1;
    }
    uVar5 = *(undefined8 *)(in_RCX + 0x108);
    iVar10 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
    iVar6 = *(int64_t *)(in_RCX + 0x110);
    *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar11) = (int64_t)&arg_80h + iVar9 + iVar11;
    *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aebae;
    iVar8 = func_0x0001801a4290(in_RCX, uVar12 & 0xff, iVar10 + iVar6, uVar5);
    if (iVar8 < 1) {
        return 0xffffffff;
    }
    if (((char)uVar12 == '\x16') &&
       ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0 ||
         (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) ||
        ((iVar8 == 0x10000 || ((*(int32_t *)(in_RCX + 0xac) != 0x25 && (1 < *(int32_t *)(in_RCX + 0xac) - 0x2eU))))))))
    {
        iVar10 = *(int64_t *)(*(int64_t *)(in_RCX + 0xf8) + 8);
        iVar6 = *(int64_t *)(in_RCX + 0x110);
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aec0f;
        iVar8 = func_0x0001801dac70(in_RCX, iVar10 + iVar6, *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar11));
        if (iVar8 == 0) {
            return 0xffffffff;
        }
    }
    iVar10 = *(int64_t *)(in_RCX + 0x108);
    iVar6 = *(int64_t *)((int64_t)&arg_80h + iVar9 + iVar11);
    if (iVar6 != iVar10) {
        *(int64_t *)(in_RCX + 0x110) = *(int64_t *)(in_RCX + 0x110) + iVar6;
        *(int64_t *)(in_RCX + 0x108) = iVar10 - iVar6;
        return 0;
    }
    *(uint32_t *)(in_RCX + 0xe8) = *(uint32_t *)(in_RCX + 0xe8) & 0xfffffffe;
    pcVar2 = *(code **)(in_RCX + 0x4f8);
    if (pcVar2 != (code *)0x0) {
        iVar6 = *(int64_t *)(in_RCX + 0x110);
        iVar7 = *(int64_t *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar11) = *(undefined8 *)(in_RCX + 0x500);
        *(undefined8 *)((int64_t)&arg_38h + iVar9 + iVar11) = uVar3;
        *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar11) = iVar10 + iVar6;
        uVar3 = *(undefined8 *)(iVar7 + 8);
        uVar1 = *(undefined4 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)auStackX_8 + iVar9 + iVar11) = 0x1801aec71;
        (*pcVar2)(1, uVar1, uVar12 & 0xff, uVar3);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c31b0
// Address: 0x1801c31b0
// Size: 22 bytes
// ============================================================
undefined8 fcn.1801c31b0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2) = 0x1801982fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar2) = 0x180198302;
    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar1 + iVar2), *(int64_t *)(&stack0x00000050 + iVar1 + iVar2));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar2) = 0x18019831a;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar1 + iVar2), *(int64_t *)(&stack0x00000050 + iVar1 + iVar2), 
                  *(int64_t *)(&stack0x00000058 + iVar1 + iVar2), *(int64_t *)(&stack0x00000060 + iVar1 + iVar2), 
                  *(int64_t *)(&stack0x00000078 + iVar1 + iVar2));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1 + iVar2) = 0x18019832c;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar1 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801c31f0
// Address: 0x1801c31f0
// Size: 80 bytes
// ============================================================
int64_t fcn.1801c31f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *in_RCX;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar7;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c31fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX != (int32_t *)0x0) {
        if (*in_RCX == 0) {
code_r0x0001801c321c:
            iVar5 = *(int64_t *)(in_RCX + 0x30e);
            uVar6 = 0x1804b3080;
            uVar7 = 0xdc8;
            *(undefined8 *)((int64_t)&arg_38h + iVar1) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_40h + iVar1) = unaff_RBP;
            *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RDI;
            *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x1802231f5;
            iVar2 = fcn.18045a350(iVar5, 0x1804b3080, 0xdc8);
            iVar2 = -iVar2;
            if (iVar5 == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_50h + iVar2 + iVar1) = unaff_RSI;
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180223222;
            iVar3 = func_0x000180498cd0();
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180223234;
            iVar4 = func_0x0001802248d0(iVar3 + 1, uVar6, uVar7 & 0xffffffff);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x18022324a;
                func_0x000180498030(iVar4, iVar5, iVar3 + 1);
            }
            return iVar4;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c3217;
            in_RCX = (int32_t *)func_0x0001801bda50(in_RCX);
            if (in_RCX != (int32_t *)0x0) goto code_r0x0001801c321c;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c3240
// Address: 0x1801c3240
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801c3240(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int32_t *in_RCX;
    int32_t in_EDX;
    undefined8 uVar2;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c3255;
    iVar1 = fcn.18045a350();
    uVar2 = 0;
    if (in_RCX != (int32_t *)0x0) {
        if (*in_RCX == 0) {
code_r0x0001801c3287:
            if (in_EDX == 6) {
                uVar2 = 1;
                *(undefined8 *)(*(int64_t *)(in_RCX + 0x21e) + 0x10) = in_R8;
            } else {
                if (in_EDX == 0xf) {
                    *(undefined8 *)(in_RCX + 0x13e) = in_R8;
                    return 1;
                }
                if (in_EDX == 0x38) {
                    *(undefined8 *)(in_RCX + 0x282) = in_R8;
                    return 1;
                }
                if (in_EDX == 0x4f) {
                    *(undefined8 *)(in_RCX + 0x312) = in_R8;
                    return 1;
                }
            }
            return uVar2;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x1801c327b;
            in_RCX = (int32_t *)func_0x0001801bda50();
            if (in_RCX != (int32_t *)0x0) goto code_r0x0001801c3287;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c3330
// Address: 0x1801c3330
// Size: 1171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801c3330(int64_t arg_48h, int64_t arg_50h, int64_t arg_60h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t uVar14;
    undefined8 uVar15;
    uint32_t uVar16;
    undefined8 in_R8;
    int64_t iVar18;
    uint64_t uVar19;
    uint64_t uVar20;
    bool bVar21;
    int64_t var_10h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_8h;
    uint64_t uVar17;
    
    uStack_40 = 0x1801c334a;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    iVar11 = *(int64_t *)(in_RCX + 0x878);
    uVar17 = 0;
    *(undefined4 *)((int64_t)&arg_60h + iVar10) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar10) = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar10) = 0;
    uVar20 = 0;
    uVar19 = 0;
    if ((*(uint32_t *)(iVar11 + 0x1c) & 0x30000) == 0) {
        uVar13 = *(uint64_t *)(in_RCX + 0x9a8);
        if ((uVar13 >> 0x16 & 1) == 0) {
            *(undefined8 *)(&stack0x00000000 + iVar10) = in_RDX;
            in_RDX = in_R8;
        } else {
            *(undefined8 *)(&stack0x00000000 + iVar10) = in_R8;
            if ((uVar13 >> 0x15 & 1) != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c33b1;
                iVar8 = func_0x000180222010(in_RDX);
                if (0 < iVar8) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c33bf;
                    iVar11 = func_0x000180222340(in_RDX, 0);
                    if (*(int32_t *)(iVar11 + 0x24) == 0x80000) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c33d0;
                        iVar8 = func_0x000180222010(in_R8);
                        uVar13 = uVar17;
                        if (0 < iVar8) {
                            do {
                                iVar9 = (int32_t)uVar13;
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c33ea;
                                iVar11 = func_0x000180222340(in_R8, uVar13);
                                if (*(int32_t *)(iVar11 + 0x24) == 0x80000) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c34bd;
                                    uVar19 = func_0x000180221f60(0, iVar8);
                                    if (uVar19 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c34d4;
                                        func_0x000180222110(uVar19, iVar11);
                                        while (iVar9 = iVar9 + 1, uVar20 = uVar17, iVar9 < iVar8) {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c34ea;
                                            iVar11 = func_0x000180222340(in_R8, iVar9);
                                            if (*(int32_t *)(iVar11 + 0x24) == 0x80000) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c34fe;
                                                func_0x000180222110(uVar19, iVar11);
                                            }
                                        }
                                        do {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c351a;
                                            iVar11 = func_0x000180222340(in_R8, uVar20);
                                            if (*(int32_t *)(iVar11 + 0x24) != 0x80000) {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c352e;
                                                func_0x000180222110(uVar19, iVar11);
                                            }
                                            uVar16 = (int32_t)uVar20 + 1;
                                            uVar20 = (uint64_t)uVar16;
                                        } while ((int32_t)uVar16 < iVar8);
                                        *(uint64_t *)(&stack0x00000000 + iVar10) = uVar19;
                                    }
                                    break;
                                }
                                uVar13 = (uint64_t)(iVar9 + 1U);
                                uVar19 = uVar17;
                            } while ((int32_t)(iVar9 + 1U) < iVar8);
                            uVar20 = (uint64_t)*(uint32_t *)((int64_t)&arg_48h + iVar10);
                        }
                    }
                }
            }
        }
    } else {
        *(undefined8 *)(&stack0x00000000 + iVar10) = in_R8;
        uVar19 = uVar17;
        uVar20 = uVar17;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar8 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar8)) && (iVar8 != 0x10000)) {
        if (*(int64_t *)(in_RCX + 0x970) != 0) {
            uVar13 = *(uint64_t *)(in_RCX + 0x118);
            uVar14 = uVar17;
            if (uVar13 != 0) {
                do {
                    iVar8 = (int32_t)uVar14;
                    if ((-1 < iVar8) && (iVar8 < *(int32_t *)(in_RCX + 0x118))) {
                        iVar11 = 0x15a0;
                        iVar18 = 0x15a8;
                        if (*(int32_t *)(in_RCX + 0x78) == 0) {
                            iVar11 = 0x1590;
                            iVar18 = 0x1598;
                        }
                        iVar11 = *(int64_t *)(iVar11 + in_RCX);
                        if (iVar11 == 0) {
                            piVar12 = (int64_t *)
                                      (*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + (int64_t)iVar8 * 0x28);
code_r0x0001801c3577:
                            if (*piVar12 == 0) goto code_r0x0001801c3587;
                        } else {
                            uVar15 = *(undefined8 *)(iVar18 + in_RCX);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3559;
                            iVar11 = func_0x000180498a80(iVar11, 2, uVar15);
                            piVar12 = (int64_t *)
                                      (*(int64_t *)(*(int64_t *)(in_RCX + 0x878) + 0x20) + (int64_t)iVar8 * 0x28);
                            if (iVar11 == 0) goto code_r0x0001801c3577;
                        }
                        if (piVar12[1] != 0) goto code_r0x0001801c35ba;
                    }
code_r0x0001801c3587:
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar13);
            }
            *(uint32_t *)((int64_t)&arg_60h + iVar10) = (uint32_t)(uVar14 == uVar13);
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c35b2;
        func_0x0001801aba40(in_RCX);
        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c35ba;
        func_0x000180197e00(in_RCX);
    }
code_r0x0001801c35ba:
    uVar15 = *(undefined8 *)(&stack0x00000000 + iVar10);
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c35ca;
    iVar8 = func_0x000180222010(uVar15);
    uVar13 = uVar17;
    uVar14 = uVar17;
    if (0 < iVar8) {
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c35e1;
            iVar11 = func_0x000180222340(uVar15, uVar17);
            uVar1 = *(undefined4 *)(in_RCX + 0x48);
            bVar21 = (*(uint32_t *)(*(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8) + 0x50) & 8) == 0;
            iVar18 = 0x38;
            if (bVar21) {
                iVar18 = 0x30;
            }
            uVar2 = *(undefined4 *)(iVar18 + iVar11);
            iVar18 = 0x34;
            if (bVar21) {
                iVar18 = 0x2c;
            }
            uVar3 = *(undefined4 *)(iVar18 + iVar11);
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c361f;
            iVar8 = func_0x0001801afd90(in_RCX, uVar1, uVar3);
            if (-1 < iVar8) {
                uVar1 = *(undefined4 *)(in_RCX + 0x48);
                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3635;
                iVar8 = func_0x0001801afd90(in_RCX, uVar1, uVar2);
                if (iVar8 < 1) {
                    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
                        (iVar8 = **(int32_t **)(in_RCX + 0x18), iVar8 < 0x304)) || (iVar8 == 0x10000)) {
                        uVar16 = *(uint32_t *)(in_RCX + 0x410);
                        uVar4 = *(uint32_t *)(iVar11 + 0x1c);
                        uVar20 = (uint64_t)uVar4;
                        uVar5 = *(uint32_t *)(iVar11 + 0x20);
                        uVar6 = *(uint32_t *)(in_RCX + 0x414) | 0x40;
                        if ((*(uint32_t *)(in_RCX + 0xc44) & 0x20) == 0) {
                            uVar6 = *(uint32_t *)(in_RCX + 0x414);
                        }
                        *(uint32_t *)((int64_t)&var_8h + iVar10) = uVar5;
                        uVar7 = uVar16 | 0x20;
                        if ((*(uint32_t *)(in_RCX + 0xc44) & 0x20) == 0) {
                            uVar7 = uVar16;
                        }
                        if (((((uVar4 & 0x1c8) != 0) && (*(int64_t *)(in_RCX + 0x970) == 0)) || ((uVar4 & uVar7) == 0))
                           || ((uVar5 & uVar6) == 0)) goto code_r0x0001801c3780;
                        if ((uVar4 & 4) != 0) {
                            uVar1 = *(undefined4 *)(iVar11 + 0x18);
                            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c36da;
                            iVar8 = func_0x0001801aabd0(in_RCX, uVar1);
                            if (iVar8 == 0) goto code_r0x0001801c3780;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c36ed;
                    iVar8 = func_0x000180221a50(in_RDX, iVar11);
                    if (-1 < iVar8) {
                        uVar1 = *(undefined4 *)(iVar11 + 0x44);
                        *(int64_t *)((int64_t)&var_18h + iVar10) = iVar11;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3710;
                        iVar9 = func_0x0001801a2690(in_RCX, 0x10002, uVar1, 0);
                        if (iVar9 != 0) {
                            if ((((uVar20 & 4) == 0) || ((*(uint8_t *)((int64_t)&var_8h + iVar10) & 8) == 0)) ||
                               (*(char *)(in_RCX + 0x4dc) == '\0')) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3748;
                                uVar13 = func_0x000180222340(in_RDX, iVar8);
                                if (*(int32_t *)((int64_t)&arg_60h + iVar10) == 0) break;
                                uVar1 = *(undefined4 *)(uVar13 + 0x40);
                                uVar15 = *(undefined8 *)(in_RCX + 8);
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3761;
                                iVar11 = func_0x0001801a08e0(uVar15, uVar1);
                                if (iVar11 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3775;
                                    iVar8 = func_0x00018020f860(iVar11, 0x1804b30b0);
                                    if (iVar8 != 0) break;
                                }
                                if (uVar14 == 0) {
                                    uVar14 = uVar13;
                                }
                            } else if (uVar14 == 0) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c3739;
                                uVar14 = func_0x000180222340(in_RDX, iVar8);
                            }
                        }
                    }
                }
            }
code_r0x0001801c3780:
            uVar13 = uVar14;
            uVar15 = *(undefined8 *)(&stack0x00000000 + iVar10);
            uVar16 = (int32_t)uVar17 + 1;
            uVar17 = (uint64_t)uVar16;
            *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c378f;
            iVar8 = func_0x000180222010(uVar15);
            uVar14 = uVar13;
        } while ((int32_t)uVar16 < iVar8);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar10) = 0x1801c37a8;
    func_0x000180221d50(uVar19);
    return uVar13;
}

// ============================================================
// Function: FUN_1801c37d0
// Address: 0x1801c37d0
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801c37d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_RDI;
    int64_t *piVar8;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c37e0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3802;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3820;
    func_0x0001801da740(in_RCX);
    uVar2 = *(undefined8 *)(in_RCX + 0xd2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3839;
    fcn.180224990(uVar2, 0x1804b3080, 0xd8c);
    uVar2 = *(undefined8 *)(in_RCX + 0xd6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c384c;
    func_0x000180222050(uVar2, 0x1802348f0);
    uVar2 = *(undefined8 *)(in_RCX + 0xe8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3865;
    fcn.180224990(uVar2, 0x1804b3080, 0xd8e);
    uVar2 = *(undefined8 *)(in_RCX + 0xee);
    uVar3 = *(undefined8 *)(in_RCX + 0xec);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3885;
    func_0x000180224b90(uVar3, uVar2, 0x1804b3080, 0xd8f);
    uVar2 = *(undefined8 *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c389e;
    fcn.180224990(uVar2, 0x1804b3080, 0xd90);
    uVar2 = *(undefined8 *)(in_RCX + 0xfa);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c38b7;
    fcn.180224990(uVar2, 0x1804b3080, 0xd91);
    uVar2 = *(undefined8 *)(in_RCX + 0x102);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c38d0;
    fcn.180224990(uVar2, 0x1804b3080, 0xd92);
    uVar2 = *(undefined8 *)(in_RCX + 0x138);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c38dc;
    func_0x00018022ecc0(uVar2);
    uVar7 = 0;
    if (*(int64_t *)(in_RCX + 0xce) != 0) {
        piVar8 = (int64_t *)(in_RCX + 0xc4);
        do {
            if (*piVar8 != 0) {
                if (*(int64_t *)(in_RCX + 0xc2) == *piVar8) {
                    *(undefined8 *)(in_RCX + 0xc2) = 0;
                }
                iVar4 = *piVar8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3910;
                func_0x00018022ecc0(iVar4);
                *piVar8 = 0;
            }
            uVar7 = uVar7 + 1;
            piVar8 = piVar8 + 1;
        } while (uVar7 < *(uint64_t *)(in_RCX + 0xce));
    }
    *(undefined8 *)(in_RCX + 0xce) = 0;
    if (*(int64_t *)(in_RCX + 0xc2) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3940;
        func_0x00018022ecc0();
        *(undefined8 *)(in_RCX + 0xc2) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c394f;
    func_0x0001801dada0(in_RCX);
    uVar2 = *(undefined8 *)(in_RCX + 0x12e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3968;
    fcn.180224990(uVar2, 0x1804b3080, 0xda7);
    uVar2 = *(undefined8 *)(in_RCX + 0x132);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3981;
    fcn.180224990(uVar2, 0x1804b3080, 0xda8);
    uVar1 = in_RCX[0x58];
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c39a1;
    func_0x0001804986e0(in_RCX + 0x59, 0, 0x38c);
    in_RCX[0x58] = uVar1 & 0x6000;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c39af;
    iVar5 = func_0x000180197630(in_RCX);
    if (iVar5 == 0) {
        return 0;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x2c0);
    in_RCX[0x12] = 0x300;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c39d8;
    fcn.180224990(uVar2, 0x1804b3080, 0xdb8);
    *(undefined8 *)(in_RCX + 0x2c0) = 0;
    *(undefined8 *)(in_RCX + 0x2c2) = 0;
    return 1;
}

// ============================================================
// Function: FUN_1801c380e
// Address: 0x1801c380e
// Size: 301 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801c37d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t *in_RCX;
    undefined8 unaff_RSI;
    uint64_t uVar7;
    undefined8 unaff_RDI;
    int64_t *piVar8;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c37e0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3802;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3820;
    func_0x0001801da740(in_RCX);
    uVar2 = *(undefined8 *)(in_RCX + 0xd2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3839;
    fcn.180224990(uVar2, 0x1804b3080, 0xd8c);
    uVar2 = *(undefined8 *)(in_RCX + 0xd6);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c384c;
    func_0x000180222050(uVar2, 0x1802348f0);
    uVar2 = *(undefined8 *)(in_RCX + 0xe8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3865;
    fcn.180224990(uVar2, 0x1804b3080, 0xd8e);
    uVar2 = *(undefined8 *)(in_RCX + 0xee);
    uVar3 = *(undefined8 *)(in_RCX + 0xec);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3885;
    func_0x000180224b90(uVar3, uVar2, 0x1804b3080, 0xd8f);
    uVar2 = *(undefined8 *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c389e;
    fcn.180224990(uVar2, 0x1804b3080, 0xd90);
    uVar2 = *(undefined8 *)(in_RCX + 0xfa);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c38b7;
    fcn.180224990(uVar2, 0x1804b3080, 0xd91);
    uVar2 = *(undefined8 *)(in_RCX + 0x102);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c38d0;
    fcn.180224990(uVar2, 0x1804b3080, 0xd92);
    uVar2 = *(undefined8 *)(in_RCX + 0x138);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c38dc;
    func_0x00018022ecc0(uVar2);
    uVar7 = 0;
    if (*(int64_t *)(in_RCX + 0xce) != 0) {
        piVar8 = (int64_t *)(in_RCX + 0xc4);
        do {
            if (*piVar8 != 0) {
                if (*(int64_t *)(in_RCX + 0xc2) == *piVar8) {
                    *(undefined8 *)(in_RCX + 0xc2) = 0;
                }
                iVar4 = *piVar8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3910;
                func_0x00018022ecc0(iVar4);
                *piVar8 = 0;
            }
            uVar7 = uVar7 + 1;
            piVar8 = piVar8 + 1;
        } while (uVar7 < *(uint64_t *)(in_RCX + 0xce));
    }
    *(undefined8 *)(in_RCX + 0xce) = 0;
    if (*(int64_t *)(in_RCX + 0xc2) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3940;
        func_0x00018022ecc0();
        *(undefined8 *)(in_RCX + 0xc2) = 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c394f;
    func_0x0001801dada0(in_RCX);
    uVar2 = *(undefined8 *)(in_RCX + 0x12e);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3968;
    fcn.180224990(uVar2, 0x1804b3080, 0xda7);
    uVar2 = *(undefined8 *)(in_RCX + 0x132);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c3981;
    fcn.180224990(uVar2, 0x1804b3080, 0xda8);
    uVar1 = in_RCX[0x58];
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c39a1;
    func_0x0001804986e0(in_RCX + 0x59, 0, 0x38c);
    in_RCX[0x58] = uVar1 & 0x6000;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c39af;
    iVar5 = func_0x000180197630(in_RCX);
    if (iVar5 == 0) {
        return 0;
    }
    uVar2 = *(undefined8 *)(in_RCX + 0x2c0);
    in_RCX[0x12] = 0x300;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c39d8;
    fcn.180224990(uVar2, 0x1804b3080, 0xdb8);
    *(undefined8 *)(in_RCX + 0x2c0) = 0;
    *(undefined8 *)(in_RCX + 0x2c2) = 0;
    return 1;
}

