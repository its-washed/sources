// Chunk 18 - 50 functions

// ============================================================
// Function: FUN_1800324f0
// Address: 0x1800324f0
// Size: 326 bytes
// ============================================================
void fcn.1800324f0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined *puVar5;
    undefined8 uStack_90;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar5 = auStack_88;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    func_0x00018007ff90();
    func_0x000180080960();
    if (var_48h == 0) {
        func_0x000180086510(arg1);
        puVar5 = auStack_88;
    } else {
        func_0x00018007ff90();
        var_68h = (int64_t)&var_58h;
        if (0xf < (uint64_t)var_40h) {
            var_68h = var_58h;
        }
        var_60h = var_48h;
        func_0x000180080600(var_68h, &var_38h, &var_68h);
        if (var_28h == 0) {
            func_0x000180086510();
        } else {
            piVar4 = &var_38h;
            if (0xf < (uint64_t)var_20h) {
                piVar4 = (int64_t *)var_38h;
            }
            func_0x0001800867f0(arg1, piVar4);
        }
        if (0xf < (uint64_t)var_20h) {
            iVar2 = var_38h;
            puVar5 = auStack_88;
            if ((0xfff < var_20h + 1U) &&
               (iVar2 = *(int64_t *)(var_38h + -8), puVar5 = auStack_88, 0x1f < (var_38h - iVar2) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar2 = (*pcVar1)(5);
                puVar5 = auStack_80;
            }
            *(undefined8 *)(puVar5 + -8) = 0x1800325d8;
            func_0x000180459c3c(iVar2);
        }
    }
    if (0xf < *(uint64_t *)(puVar5 + 0x48)) {
        iVar2 = *(int64_t *)(puVar5 + 0x30);
        iVar3 = iVar2;
        if ((0xfff < *(uint64_t *)(puVar5 + 0x48) + 1) &&
           (iVar3 = *(int64_t *)(iVar2 + -8), 0x1f < (iVar2 - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar5 = puVar5 + 8;
        }
        *(undefined8 *)(puVar5 + -8) = 0x18003261b;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(puVar5 + -8) = 0x18003262d;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x70) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_180032640
// Address: 0x180032640
// Size: 722 bytes
// ============================================================
void fcn.180032640(int64_t arg1, int64_t arg_58h)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined *puVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined4 uVar13;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar10 = auStack_a8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x0001800328fe;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar7 = *piVar5 + 0x18;
    if (iVar7 == 0) {
code_r0x0001800328fe:
        func_0x000180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar5 + 0x14);
    piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar5 = piVar8;
    if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) < 1)) {
        iVar11 = 0x1806222bc;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = func_0x0001800a8360(arg1);
            if (iVar4 == 0) goto code_r0x0001800328ea;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
                piVar8 = *(int64_t **)0x180782430;
            }
        }
        iVar11 = *piVar8 + 0x18;
        if (iVar11 == 0) {
code_r0x0001800328ea:
            func_0x000180088470(arg1, 2, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    func_0x00018007ff90();
    _var_78h = ZEXT816(0);
    var_68h = 0;
    var_60h = 0;
    uVar6 = func_0x000180498cd0(iVar11);
    uVar13 = func_0x000180004830(&var_78h, iVar11, uVar6);
    iVar11 = func_0x000180080d40(uVar13, &var_78h);
    if ((uint64_t)var_60h < 0x10) {
code_r0x000180032808:
        var_68h = 0;
        var_60h = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffff89;
        _var_78h = auVar3 << 8;
        if (iVar11 == 0) {
            func_0x000180088380(arg1, 2, 0x1806222a0);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar13 = func_0x00018007ff90();
        var_88h = iVar7;
        var_80h = (uint64_t)uVar1;
        func_0x000180081030(uVar13, &var_58h, &var_88h, iVar11);
        if (var_48h == 0) {
            func_0x000180086510();
        } else {
            piVar5 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar5 = (int64_t *)var_58h;
            }
            func_0x0001800867f0(arg1, piVar5);
        }
        if ((uint64_t)var_40h < 0x10) goto code_r0x0001800328b7;
        puVar10 = auStack_a8;
        if ((0xfff < var_40h + 1U) &&
           (iVar7 = var_58h - *(int64_t *)(var_58h + -8), var_58h = *(int64_t *)(var_58h + -8), puVar10 = auStack_a8,
           0x1f < iVar7 - 8U)) goto code_r0x0001800328a8;
    } else {
        uVar9 = var_60h + 1;
        iVar12 = var_78h;
        if (uVar9 < 0x1000) {
code_r0x000180032800:
            func_0x000180459c3c(iVar12, uVar9);
            goto code_r0x000180032808;
        }
        if ((var_78h - *(int64_t *)(var_78h + -8)) - 8U < 0x20) {
            uVar9 = var_60h + 0x28;
            iVar12 = *(int64_t *)(var_78h + -8);
            goto code_r0x000180032800;
        }
code_r0x0001800328a8:
        pcVar2 = (code *)swi(0x29);
        var_58h = (*pcVar2)(5);
        puVar10 = auStack_a0;
    }
    *(undefined8 *)(puVar10 + -8) = 0x1800328b7;
    func_0x000180459c3c(var_58h);
code_r0x0001800328b7:
    *(undefined8 *)(puVar10 + -8) = 0x1800328c9;
    func_0x000180459870(*(uint64_t *)(puVar10 + 0x70) ^ (uint64_t)puVar10);
    return;
}

// ============================================================
// Function: FUN_180032920
// Address: 0x180032920
// Size: 1003 bytes
// ============================================================
void fcn.180032920(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined auVar4 [16];
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined *puVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined4 uVar15;
    undefined4 extraout_XMM0_Da;
    undefined auStack_118 [8];
    undefined auStack_110 [24];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_58h;
    
    puVar12 = auStack_118;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x000180032ce3;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar7 = *piVar9 + 0x18;
    if (iVar7 == 0) {
code_r0x000180032ce3:
        func_0x000180088470(arg1, 1, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    iVar5 = *(int32_t *)(*piVar9 + 0x14);
    piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        if (iVar6 == 0) goto code_r0x000180032cf7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar9 + 0x18;
    if (iVar8 == 0) {
code_r0x000180032cf7:
        func_0x000180088470(arg1, 2, 6);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = *(uint32_t *)(*piVar9 + 0x14);
    piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar9 = piVar10;
    if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) < 1)) {
        iVar13 = 0x1806222bc;
    } else {
        if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar10 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar6 = func_0x0001800a8360(arg1);
            if (iVar6 == 0) goto code_r0x000180032ccf;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar10 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            if (*(int64_t **)(arg1 + 0x40) <= piVar10) {
                piVar10 = *(int64_t **)0x180782430;
            }
        }
        iVar13 = *piVar10 + 0x18;
        if (iVar13 == 0) {
code_r0x000180032ccf:
            func_0x000180088470(arg1, 3, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
    }
    func_0x00018007ff90();
    _var_b8h = ZEXT816(0);
    var_a8h = 0;
    var_a0h = 0;
    func_0x000180498cd0(iVar13);
    uVar15 = func_0x000180004830(&var_b8h, iVar13);
    iVar13 = func_0x000180080d40(uVar15, &var_b8h);
    if ((uint64_t)var_a0h < 0x10) {
code_r0x000180032b6e:
        var_a8h = 0;
        var_a0h = 0xf;
        auVar3[15] = 0;
        auVar3._0_15_ = stack0xffffffffffffff49;
        _var_b8h = auVar3 << 8;
        if (iVar13 == 0) {
            func_0x000180088380(arg1, 3, 0x1806222f8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        func_0x00018007ff90();
        if (iVar5 == 0) {
code_r0x000180032bf0:
            var_a8h = 0;
            var_a0h = 0xf;
            stack0xffffffffffffff49 = SUB1615(ZEXT816(0), 1);
            auVar4[15] = 0;
            auVar4._0_15_ = stack0xffffffffffffff49;
            _var_b8h = auVar4 << 8;
        } else {
            var_d8h._0_4_ = 0;
            var_e8h = (int64_t)&var_d8h;
            var_f0h = (int64_t)&var_98h;
            var_f8h = (uint64_t)uVar1;
            iVar7 = func_0x00018021d260(iVar13, iVar7, iVar5, iVar8);
            if (iVar7 == 0) goto code_r0x000180032bf0;
            var_c8h = (int64_t)&var_98h;
            var_c0h = (int64_t)(uint32_t)var_d8h;
            func_0x000180080600(extraout_XMM0_Da, &var_b8h, &var_c8h);
        }
        iVar7 = var_a0h;
        if (var_a8h != 0) {
            piVar9 = &var_b8h;
            if (0xf < (uint64_t)var_a0h) {
                piVar9 = (int64_t *)var_b8h;
            }
            func_0x0001800867f0(arg1, piVar9);
            if ((uint64_t)var_a0h < 0x10) goto code_r0x000180032c95;
            iVar8 = var_b8h;
            puVar12 = auStack_118;
            if ((var_a0h + 1U < 0x1000) ||
               (iVar8 = *(int64_t *)(var_b8h + -8), puVar12 = auStack_118,
               (var_b8h - *(int64_t *)(var_b8h + -8)) - 8U < 0x20)) goto code_r0x000180032c90;
            goto code_r0x000180032c86;
        }
        func_0x000180086510();
        puVar12 = auStack_118;
        if ((uint64_t)iVar7 < 0x10) goto code_r0x000180032c95;
        iVar8 = var_b8h;
        puVar12 = auStack_118;
        if ((0xfff < iVar7 + 1U) &&
           (iVar8 = *(int64_t *)(var_b8h + -8), puVar12 = auStack_118,
           0x1f < (var_b8h - *(int64_t *)(var_b8h + -8)) - 8U)) goto code_r0x000180032c86;
    } else {
        uVar11 = var_a0h + 1;
        iVar14 = var_b8h;
        if (uVar11 < 0x1000) {
code_r0x000180032b66:
            func_0x000180459c3c(iVar14, uVar11);
            goto code_r0x000180032b6e;
        }
        if ((var_b8h - *(int64_t *)(var_b8h + -8)) - 8U < 0x20) {
            uVar11 = var_a0h + 0x28;
            iVar14 = *(int64_t *)(var_b8h + -8);
            goto code_r0x000180032b66;
        }
code_r0x000180032c86:
        pcVar2 = (code *)swi(0x29);
        iVar8 = (*pcVar2)(5);
        puVar12 = auStack_110;
    }
code_r0x000180032c90:
    *(undefined8 *)(puVar12 + -8) = 0x180032c95;
    func_0x000180459c3c(iVar8);
code_r0x000180032c95:
    *(undefined8 *)(puVar12 + -8) = 0x180032ca6;
    func_0x000180459870(var_58h ^ (uint64_t)puVar12);
    return;
}

// ============================================================
// Function: FUN_180032d10
// Address: 0x180032d10
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180032d10(int64_t arg1, int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined *puVar5;
    int64_t var_10h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    puVar5 = auStack_58;
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    iVar2 = func_0x000180088860(arg1, 1);
    if (iVar2 < 0) {
        func_0x000180088380(arg1, 1, 0x180622280);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if (iVar2 < 0x401) {
        func_0x00018007ff90();
        func_0x000180080960();
        if (var_28h == 0) {
            func_0x000180086510();
        } else {
            piVar4 = &var_38h;
            if (0xf < (uint64_t)var_20h) {
                piVar4 = (int64_t *)var_38h;
            }
            func_0x0001800867f0(arg1, piVar4);
        }
        if (0xf < (uint64_t)var_20h) {
            iVar3 = var_38h;
            puVar5 = auStack_58;
            if ((0xfff < var_20h + 1U) &&
               (iVar3 = *(int64_t *)(var_38h + -8), puVar5 = auStack_58, 0x1f < (var_38h - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar5 = auStack_50;
            }
            *(undefined8 *)(puVar5 + -8) = 0x180032dcd;
            func_0x000180459c3c(iVar3);
        }
        *(undefined8 *)(puVar5 + -8) = 0x180032ddf;
        func_0x000180459870(*(uint64_t *)(puVar5 + 0x40) ^ (uint64_t)puVar5);
        return;
    }
    func_0x000180088380(arg1, 1, 0x180622260);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180032e20
// Address: 0x180032e20
// Size: 403 bytes
// ============================================================
void fcn.180032e20(int64_t arg1, int64_t arg_28h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined *puVar6;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar6 = auStack_78;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x000180032f9f;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar4 = *piVar5 + 0x18;
    if (iVar4 != 0) {
        uVar1 = *(undefined4 *)(*piVar5 + 0x14);
        iVar3 = func_0x0001803f4c80(uVar1);
        if (iVar3 < 1) {
            func_0x000180086510(arg1);
            puVar6 = auStack_78;
        } else {
            func_0x0001800106c0(&var_58h, (int64_t)iVar3, 0);
            piVar5 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar5 = (int64_t *)var_58h;
            }
            iVar3 = func_0x0001803f4cb0(iVar4, piVar5, uVar1, iVar3);
            if (iVar3 < 1) {
                func_0x000180086510(arg1);
            } else {
                func_0x00018000b3b0(&var_58h, (int64_t)iVar3, 0);
                piVar5 = &var_58h;
                if (0xf < (uint64_t)var_40h) {
                    piVar5 = (int64_t *)var_58h;
                }
                func_0x0001800867f0(arg1, piVar5, var_48h);
            }
            if (0xf < (uint64_t)var_40h) {
                iVar4 = var_58h;
                puVar6 = auStack_78;
                if ((0xfff < var_40h + 1U) &&
                   (iVar4 = *(int64_t *)(var_58h + -8), puVar6 = auStack_78, 0x1f < (var_58h - iVar4) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar4 = (*pcVar2)(5);
                    puVar6 = auStack_70;
                }
                *(undefined8 *)(puVar6 + -8) = 0x180032f84;
                func_0x000180459c3c(iVar4);
            }
        }
        *(undefined8 *)(puVar6 + -8) = 0x180032f96;
        func_0x000180459870(*(uint64_t *)(puVar6 + 0x40) ^ (uint64_t)puVar6);
        return;
    }
code_r0x000180032f9f:
    func_0x000180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180032fc0
// Address: 0x180032fc0
// Size: 454 bytes
// ============================================================
void fcn.180032fc0(int64_t arg1, int64_t arg_28h)
{
    undefined4 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined *puVar6;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar6 = auStack_78;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x00018003315d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar4 = *piVar5 + 0x18;
    if (iVar4 != 0) {
        uVar1 = *(undefined4 *)(*piVar5 + 0x14);
        iVar3 = func_0x000180088860(arg1, 2);
        if (iVar3 < 1) {
            func_0x000180088380(arg1, 2, 0x1806222c8);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        if (iVar3 < 0x6400001) {
            func_0x0001800106c0(&var_58h, (int64_t)iVar3, 0);
            piVar5 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar5 = (int64_t *)var_58h;
            }
            iVar3 = func_0x0001803f5df0(iVar4, piVar5, uVar1, iVar3);
            if (iVar3 < 0) {
                func_0x000180086510(arg1);
            } else {
                func_0x00018000b3b0(&var_58h, (int64_t)iVar3, 0);
                piVar5 = &var_58h;
                if (0xf < (uint64_t)var_40h) {
                    piVar5 = (int64_t *)var_58h;
                }
                func_0x0001800867f0(arg1, piVar5, var_48h);
            }
            if (0xf < (uint64_t)var_40h) {
                iVar4 = var_58h;
                puVar6 = auStack_78;
                if ((0xfff < var_40h + 1U) &&
                   (iVar4 = *(int64_t *)(var_58h + -8), puVar6 = auStack_78, 0x1f < (var_58h - iVar4) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar4 = (*pcVar2)(5);
                    puVar6 = auStack_70;
                }
                *(undefined8 *)(puVar6 + -8) = 0x18003312d;
                func_0x000180459c3c(iVar4);
            }
            *(undefined8 *)(puVar6 + -8) = 0x18003313f;
            func_0x000180459870(*(uint64_t *)(puVar6 + 0x40) ^ (uint64_t)puVar6);
            return;
        }
        func_0x000180088380(arg1, 2, 0x180622328);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
code_r0x00018003315d:
    func_0x000180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180033190
// Address: 0x180033190
// Size: 1642 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001800331e9: Changing call to branch
// WARNING: Possible PIC construction at 0x00018003327d: Changing call to branch
// WARNING: Possible PIC construction at 0x00018003330e: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033349: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033391: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800333cc: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033439: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800334c6: Changing call to branch
// WARNING: Possible PIC construction at 0x00018003354e: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033589: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800335c4: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800335ff: Changing call to branch
// WARNING: Possible PIC construction at 0x00018003363a: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033675: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800336b0: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800336eb: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033726: Changing call to branch
// WARNING: Possible PIC construction at 0x00018003376e: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800337a9: Changing call to branch
// WARNING: Possible PIC construction at 0x000180033505: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800332c5: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180033773)
// WARNING: Removing unreachable block (ram,0x00018003372b)
// WARNING: Removing unreachable block (ram,0x0001800336f0)
// WARNING: Removing unreachable block (ram,0x0001800336b5)
// WARNING: Removing unreachable block (ram,0x00018003367a)
// WARNING: Removing unreachable block (ram,0x00018003363f)
// WARNING: Removing unreachable block (ram,0x000180033604)
// WARNING: Removing unreachable block (ram,0x0001800335c9)
// WARNING: Removing unreachable block (ram,0x00018003358e)
// WARNING: Removing unreachable block (ram,0x000180033553)
// WARNING: Removing unreachable block (ram,0x0001800334cb)
// WARNING: Removing unreachable block (ram,0x0001800334d0)
// WARNING: Removing unreachable block (ram,0x0001800334f2)
// WARNING: Removing unreachable block (ram,0x0001800334fd)
// WARNING: Removing unreachable block (ram,0x0001800334f7)
// WARNING: Removing unreachable block (ram,0x00018003350a)
// WARNING: Removing unreachable block (ram,0x000180033518)
// WARNING: Removing unreachable block (ram,0x00018003343e)
// WARNING: Removing unreachable block (ram,0x000180033443)
// WARNING: Removing unreachable block (ram,0x000180033465)
// WARNING: Removing unreachable block (ram,0x000180033470)
// WARNING: Removing unreachable block (ram,0x00018003346a)
// WARNING: Removing unreachable block (ram,0x00018003347d)
// WARNING: Removing unreachable block (ram,0x00018003348b)
// WARNING: Removing unreachable block (ram,0x0001800333d1)
// WARNING: Removing unreachable block (ram,0x000180033396)
// WARNING: Removing unreachable block (ram,0x00018003334e)
// WARNING: Removing unreachable block (ram,0x000180033313)
// WARNING: Removing unreachable block (ram,0x000180033282)
// WARNING: Removing unreachable block (ram,0x000180033290)
// WARNING: Removing unreachable block (ram,0x0001800332b2)
// WARNING: Removing unreachable block (ram,0x0001800332bd)
// WARNING: Removing unreachable block (ram,0x0001800332b7)
// WARNING: Removing unreachable block (ram,0x0001800332ca)
// WARNING: Removing unreachable block (ram,0x0001800332d8)
// WARNING: Removing unreachable block (ram,0x0001800331ee)
// WARNING: Removing unreachable block (ram,0x0001800331f3)
// WARNING: Removing unreachable block (ram,0x000180033215)
// WARNING: Removing unreachable block (ram,0x000180033220)
// WARNING: Removing unreachable block (ram,0x00018003321a)
// WARNING: Removing unreachable block (ram,0x00018003322d)
// WARNING: Removing unreachable block (ram,0x00018003323b)
// WARNING: Removing unreachable block (ram,0x0001800337ae)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180033190(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t var_20h;
    undefined auStack_e8 [32];
    undefined8 uStack_c8;
    undefined4 uStack_bc;
    uint64_t uStack_b8;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    func_0x000180018f70();
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, 0x180030e50, 0x180622360, 0);
    uStack_b8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    iVar4 = (int32_t)(iVar1 - iVar2 >> 4);
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = func_0x000180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = func_0x000180498cd0(0x180622360);
    uStack_c8 = func_0x00018009a8e0(arg2, 0x180622360, uVar3);
    uStack_bc = 6;
    func_0x0001800a8680(arg2, uVar5, &uStack_c8, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    func_0x000180459870(uStack_b8 ^ (uint64_t)auStack_e8);
    return;
}

// ============================================================
// Function: FUN_180033800
// Address: 0x180033800
// Size: 365 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180033800(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    int64_t var_8h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (iVar1 = *piVar7, *(char *)(iVar1 + 3) != 'x')) ||
       (iVar1 == -0x10)) {
        func_0x0001800883d0(arg1, 1, 0x180622430);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar5 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x000180033959;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar7 + 0x18 != 0) {
        piVar5 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        piVar8 = piVar5;
        if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
            piVar8 = *(int64_t **)0x180782430;
        }
        if (piVar8 != *(int64_t **)0x180782430) {
            if ((*(int32_t *)((int64_t)piVar8 + 0xc) == 6) || (*(int32_t *)((int64_t)piVar8 + 0xc) == 3)) {
                if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
                    piVar5 = *(int64_t **)0x180782430;
                }
                if (piVar5 == *(int64_t **)0x180782430) {
                    piVar5 = (int64_t *)0x0;
                }
                iVar2 = *piVar5;
                if ((iVar2 != 0) && ((int32_t)iVar2 + *(int32_t *)(iVar2 + 0x10) == -0x4deee947)) {
                    func_0x0001800865e0(arg1, *(undefined4 *)(iVar1 + 0x14));
                    return 1;
                }
            }
        }
        func_0x000180088560(arg1, 0x180622408, *piVar7 + 0x18);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
code_r0x000180033959:
    func_0x000180088470(arg1, 2, 6);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_180033970
// Address: 0x180033970
// Size: 32 bytes
// ============================================================
undefined8 fcn.180033970(undefined8 param_1)
{
    fcn.1800867f0(param_1, 0x180622430, 10);
    return 1;
}

// ============================================================
// Function: FUN_1800339a0
// Address: 0x1800339a0
// Size: 557 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.1800339a0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar5 = (undefined4 *)func_0x000180087f70(arg1, 8, 0x78);
    iVar3 = func_0x0001800885b0(arg1, 0x180622430);
    if (iVar3 != 0) {
        func_0x0001800869f0(arg1, 0x180005d40, 0, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, 0x18062244c);
        func_0x0001800869f0(arg1, fcn.180033800, 0, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, 0x1805aae90);
        func_0x0001800869f0(arg1, fcn.180033970, 0, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, 0x180622440);
        fcn.1800867f0(arg1, 0x180622430, 10);
        func_0x000180087370(arg1, 0xfffffffe, 0x180622470);
        fcn.1800867f0(arg1, 0x180622458, 0x17);
        func_0x000180087370(arg1, 0xfffffffe, 0x1806224a0);
    }
    func_0x000180087650(arg1, 0xfffffffe);
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    uVar6 = func_0x000180094210(arg1, *(undefined *)(arg2 + 6), *(undefined8 *)(arg1 + 0x58), arg2);
    **(undefined8 **)(arg1 + 0x40) = uVar6;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 8;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar7 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar3 = iVar7 * 2;
        if (iVar7 < 1) {
            iVar3 = iVar7 + 1;
        }
        func_0x000180093240(arg1, iVar3);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    uVar4 = (**(code **)0x180782618)(arg1, 0xffffffff);
    *puVar5 = uVar4;
    uVar2 = *(uint32_t *)(arg2 + 0x9c);
    uVar8 = (uVar2 ^ 0x811c9dc5) * 0x1000193;
    if (0 < (int32_t)uVar2) {
        uVar10 = 0;
        do {
            iVar1 = uVar10 * 4;
            uVar9 = (int32_t)uVar10 + 1;
            uVar10 = (uint64_t)uVar9;
            uVar8 = (uVar8 ^ *(uint32_t *)(*(int64_t *)(arg2 + 0x40) + iVar1)) * 0x1000193;
        } while ((int32_t)uVar9 < (int32_t)uVar2);
    }
    puVar5[1] = uVar8;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
    return puVar5;
}

// ============================================================
// Function: FUN_180033bd0
// Address: 0x180033bd0
// Size: 137 bytes
// ============================================================
void fcn.180033bd0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined auStack_178 [32];
    int64_t var_158h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_178;
    iVar2 = fcn.180085f50(arg1, 1, 0);
    if (iVar2 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar2 = fcn.180092a10(arg1, iVar2, 0x180621b1c, &var_158h);
    if (iVar2 != 0) {
        fcn.180459870(var_18h ^ (uint64_t)auStack_178);
        return;
    }
    fcn.180088380(arg1, 1, 0x180621b08);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180033c60
// Address: 0x180033c60
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180033c60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    char cVar4;
    int32_t iVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t var_18h;
    undefined auStack_198 [32];
    int64_t var_178h;
    int64_t var_168h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    uVar8 = arg2 & 0xffffffff;
    if (0 < (int32_t)arg2) {
        var_178h = 0;
        cVar4 = func_0x000180051370(arg1, &var_178h);
        if (cVar4 != '\0') {
            arg1 = var_178h;
        }
        iVar5 = fcn.180092a10(arg1, uVar8, 0x180621b1c, &var_168h);
        while (iVar5 != 0) {
            puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
            puVar6 = puVar9;
            if (puVar9 == *(uint64_t **)0x180782430) {
                puVar6 = (uint64_t *)0x0;
            }
            uVar1 = *puVar6;
            if (uVar1 == 0) {
code_r0x000180033de5:
                *(uint64_t **)(arg1 + 0x40) = puVar9;
                break;
            }
            uVar7 = (((((((uVar1 >> 8 & 0xff ^ (uVar1 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3) * 0x100000001b3 ^
                         uVar1 >> 0x10 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x18 & 0xff) * 0x100000001b3 ^
                       uVar1 >> 0x20 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x28 & 0xff) * 0x100000001b3 ^
                     uVar1 >> 0x30 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x38) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
            iVar2 = *(int64_t *)(*(int64_t *)0x18077af98 + 8 + uVar7 * 0x10);
            if (iVar2 == *(int64_t *)0x18077af88) goto code_r0x000180033de5;
            uVar3 = *(uint64_t *)(iVar2 + 0x10);
            while (uVar1 != uVar3) {
                if (iVar2 == *(int64_t *)(*(int64_t *)0x18077af98 + uVar7 * 0x10)) goto code_r0x000180033de5;
                iVar2 = *(int64_t *)(iVar2 + 8);
                uVar3 = *(uint64_t *)(iVar2 + 0x10);
            }
            *(uint64_t **)(arg1 + 0x40) = puVar9;
            uVar8 = (uint64_t)((int32_t)uVar8 + 1);
            iVar5 = fcn.180092a10(arg1, uVar8, 0x180621b1c, &var_168h);
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_198);
    return;
}

// ============================================================
// Function: FUN_180033c8b
// Address: 0x180033c8b
// Size: 366 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180033c60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    char cVar4;
    int32_t iVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t var_18h;
    undefined auStack_198 [32];
    int64_t var_178h;
    int64_t var_168h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    uVar8 = arg2 & 0xffffffff;
    if (0 < (int32_t)arg2) {
        var_178h = 0;
        cVar4 = func_0x000180051370(arg1, &var_178h);
        if (cVar4 != '\0') {
            arg1 = var_178h;
        }
        iVar5 = fcn.180092a10(arg1, uVar8, 0x180621b1c, &var_168h);
        while (iVar5 != 0) {
            puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
            puVar6 = puVar9;
            if (puVar9 == *(uint64_t **)0x180782430) {
                puVar6 = (uint64_t *)0x0;
            }
            uVar1 = *puVar6;
            if (uVar1 == 0) {
code_r0x000180033de5:
                *(uint64_t **)(arg1 + 0x40) = puVar9;
                break;
            }
            uVar7 = (((((((uVar1 >> 8 & 0xff ^ (uVar1 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3) * 0x100000001b3 ^
                         uVar1 >> 0x10 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x18 & 0xff) * 0x100000001b3 ^
                       uVar1 >> 0x20 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x28 & 0xff) * 0x100000001b3 ^
                     uVar1 >> 0x30 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x38) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
            iVar2 = *(int64_t *)(*(int64_t *)0x18077af98 + 8 + uVar7 * 0x10);
            if (iVar2 == *(int64_t *)0x18077af88) goto code_r0x000180033de5;
            uVar3 = *(uint64_t *)(iVar2 + 0x10);
            while (uVar1 != uVar3) {
                if (iVar2 == *(int64_t *)(*(int64_t *)0x18077af98 + uVar7 * 0x10)) goto code_r0x000180033de5;
                iVar2 = *(int64_t *)(iVar2 + 8);
                uVar3 = *(uint64_t *)(iVar2 + 0x10);
            }
            *(uint64_t **)(arg1 + 0x40) = puVar9;
            uVar8 = (uint64_t)((int32_t)uVar8 + 1);
            iVar5 = fcn.180092a10(arg1, uVar8, 0x180621b1c, &var_168h);
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_198);
    return;
}

// ============================================================
// Function: FUN_180033df9
// Address: 0x180033df9
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180033c60(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    char cVar4;
    int32_t iVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t *puVar9;
    int64_t var_18h;
    undefined auStack_198 [32];
    int64_t var_178h;
    int64_t var_168h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    uVar8 = arg2 & 0xffffffff;
    if (0 < (int32_t)arg2) {
        var_178h = 0;
        cVar4 = func_0x000180051370(arg1, &var_178h);
        if (cVar4 != '\0') {
            arg1 = var_178h;
        }
        iVar5 = fcn.180092a10(arg1, uVar8, 0x180621b1c, &var_168h);
        while (iVar5 != 0) {
            puVar9 = (uint64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
            puVar6 = puVar9;
            if (puVar9 == *(uint64_t **)0x180782430) {
                puVar6 = (uint64_t *)0x0;
            }
            uVar1 = *puVar6;
            if (uVar1 == 0) {
code_r0x000180033de5:
                *(uint64_t **)(arg1 + 0x40) = puVar9;
                break;
            }
            uVar7 = (((((((uVar1 >> 8 & 0xff ^ (uVar1 & 0xff ^ 0xcbf29ce484222325) * 0x100000001b3) * 0x100000001b3 ^
                         uVar1 >> 0x10 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x18 & 0xff) * 0x100000001b3 ^
                       uVar1 >> 0x20 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x28 & 0xff) * 0x100000001b3 ^
                     uVar1 >> 0x30 & 0xff) * 0x100000001b3 ^ uVar1 >> 0x38) * 0x100000001b3 & *(uint64_t *)0x18077afb0;
            iVar2 = *(int64_t *)(*(int64_t *)0x18077af98 + 8 + uVar7 * 0x10);
            if (iVar2 == *(int64_t *)0x18077af88) goto code_r0x000180033de5;
            uVar3 = *(uint64_t *)(iVar2 + 0x10);
            while (uVar1 != uVar3) {
                if (iVar2 == *(int64_t *)(*(int64_t *)0x18077af98 + uVar7 * 0x10)) goto code_r0x000180033de5;
                iVar2 = *(int64_t *)(iVar2 + 8);
                uVar3 = *(uint64_t *)(iVar2 + 0x10);
            }
            *(uint64_t **)(arg1 + 0x40) = puVar9;
            uVar8 = (uint64_t)((int32_t)uVar8 + 1);
            iVar5 = fcn.180092a10(arg1, uVar8, 0x180621b1c, &var_168h);
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_198);
    return;
}

// ============================================================
// Function: FUN_180033e20
// Address: 0x180033e20
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_180033e79
// Address: 0x180033e79
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_180033e99
// Address: 0x180033e99
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_180033f3f
// Address: 0x180033f3f
// Size: 217 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_180034018
// Address: 0x180034018
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_18003402d
// Address: 0x18003402d
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_18003403f
// Address: 0x18003403f
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_18003404f
// Address: 0x18003404f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_180034055
// Address: 0x180034055
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_3h

undefined8 fcn.180033e20(int64_t arg1, int64_t arg_30h, int64_t arg_78h, int64_t arg_a0h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t *piVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar12 + 0xc) != 8)) {
        iVar13 = func_0x000180085d50(arg1, 1);
        if (iVar13 == 0) {
            piVar12 = *(int64_t **)(arg1 + 0x28);
            piVar1 = *(int64_t **)(arg1 + 0x40);
            piVar9 = piVar12;
            if (piVar1 <= piVar12) {
                piVar9 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 2)) {
                piVar9 = piVar12;
                if (piVar1 <= piVar12) {
                    piVar9 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 9) && (*(char *)(*piVar9 + 3) == 'x')) {
                    if (piVar1 <= piVar12) {
                        piVar12 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar12 + 0xc) == 9) && (*(char *)(*piVar12 + 3) == 'x')) {
                        puVar10 = (undefined4 *)(*piVar12 + 0x10);
                    } else {
                        puVar10 = (undefined4 *)0x0;
                    }
                    iVar13 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar10);
                    if (iVar13 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar5 = (code *)swi(3);
                        uVar11 = (*pcVar5)();
                        return uVar11;
                    }
                    goto code_r0x000180033e55;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar5 = (code *)swi(3);
            uVar11 = (*pcVar5)();
            return uVar11;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x000180033e55:
    piVar12 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar12 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    if (piVar12 == *(int64_t **)0x180782430) {
        piVar12 = (int64_t *)0x0;
    }
    if (*(char *)(*piVar12 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    iVar2 = *(int64_t *)(*piVar12 + 0x20);
    func_0x000180086fd0(arg1, *(undefined4 *)(iVar2 + 0xa0), 0);
    iVar13 = 0;
    if (0 < *(int32_t *)(iVar2 + 0xa0)) {
        do {
            fcn.1800339a0(arg1, *(int64_t *)(*(int64_t *)(iVar2 + 0x58) + (int64_t)iVar13 * 8));
            iVar3 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar5 = (code *)swi(3);
                uVar11 = (*pcVar5)();
                return uVar11;
            }
            iVar13 = iVar13 + 1;
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x20), iVar13);
            uVar6 = *(undefined4 *)(iVar3 + -0xc);
            uVar7 = *(undefined4 *)(iVar3 + -8);
            uVar8 = *(undefined4 *)(iVar3 + -4);
            *puVar10 = *(undefined4 *)(iVar3 + -0x10);
            puVar10[1] = uVar6;
            puVar10[2] = uVar7;
            puVar10[3] = uVar8;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar3 = *(int64_t *)(iVar3 + -0x20);
                if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar4 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar4 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                        *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                        *(int64_t *)(iVar4 + 0x18) = iVar3;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        } while (iVar13 < *(int32_t *)(iVar2 + 0xa0));
    }
    return 1;
}

// ============================================================
// Function: FUN_180034070
// Address: 0x180034070
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_1800340af
// Address: 0x1800340af
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_1800340d3
// Address: 0x1800340d3
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_180034179
// Address: 0x180034179
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_180034230
// Address: 0x180034230
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_180034248
// Address: 0x180034248
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_18003425d
// Address: 0x18003425d
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_18003426f
// Address: 0x18003426f
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_18003427f
// Address: 0x18003427f
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034070(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 8)) {
        iVar3 = func_0x000180085d50(arg1, 1);
        if (iVar3 == 0) {
            piVar6 = *(int64_t **)(arg1 + 0x28);
            piVar7 = *(int64_t **)(arg1 + 0x40);
            piVar4 = piVar6;
            if (piVar7 <= piVar6) {
                piVar4 = *(int64_t **)0x180782430;
            }
            if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) || (*(int32_t *)((int64_t)piVar4 + 0xc) == 2)) {
                piVar4 = piVar6;
                if (piVar7 <= piVar6) {
                    piVar4 = *(int64_t **)0x180782430;
                }
                if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 9) && (*(char *)(*piVar4 + 3) == 'x')) {
                    if (piVar7 <= piVar6) {
                        piVar6 = *(int64_t **)0x180782430;
                    }
                    if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'x')) {
                        puVar8 = (undefined4 *)(*piVar6 + 0x10);
                    } else {
                        puVar8 = (undefined4 *)0x0;
                    }
                    iVar3 = func_0x000180086ed0(arg1, 0xffffd8f0, *puVar8);
                    if (iVar3 != 8) {
                        fcn.180088560(arg1, 0x1806224c8);
                        pcVar2 = (code *)swi(3);
                        uVar5 = (*pcVar2)();
                        return uVar5;
                    }
                    goto code_r0x0001800340a5;
                }
            }
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1, 1);
    }
code_r0x0001800340a5:
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
    if (piVar6 == *(int64_t **)0x180782430) {
        piVar6 = (int64_t *)0x0;
    }
    iVar1 = *piVar6;
    if (*(char *)(iVar1 + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar3 = fcn.180085f50(arg1, 2, 0);
    if (iVar3 < 1) {
        fcn.180088380(arg1, 2, 0x180622528);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    iVar1 = *(int64_t *)(iVar1 + 0x20);
    if (*(int32_t *)(iVar1 + 0xa0) <= iVar3 + -1) {
        fcn.180088380(arg1, 2, 0x180622518);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    var_20h = *(int64_t *)(*(int64_t *)(iVar1 + 0x58) + -8 + (int64_t)iVar3 * 8);
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            var_18h._0_4_ = 0;
            var_28h = arg1;
            func_0x000180086fd0(arg1, 0, 0);
            func_0x0001800989f0(arg1, &var_28h, 0x1800342b0);
            return 1;
        }
    }
    fcn.1800339a0(arg1, var_20h);
    return 1;
}

// ============================================================
// Function: FUN_1800342b0
// Address: 0x1800342b0
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800342b0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    
    if (arg3 != 0) {
        uVar4 = 0;
        iVar1 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(iVar1 + 0x20);
        if ((((((~*(uint8_t *)(iVar2 + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) && (*(char *)(arg3 + 2) == '\b')
             ) && (*(char *)(arg3 + 3) == '\0')) &&
           (uVar4 = *(uint64_t *)(arg1 + 8), *(uint64_t *)(arg3 + 0x20) == uVar4)) {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(iVar2 + 0x18);
                *(int64_t *)(iVar2 + 0x18) = iVar1;
            }
            **(int64_t **)(iVar1 + 0x40) = arg3;
            *(uint32_t *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
            if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
                iVar5 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
                iVar3 = iVar5 * 2;
                if (iVar5 < 1) {
                    iVar3 = iVar5 + 1;
                }
                func_0x000180093240(iVar1, iVar3, 0);
            }
            *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + 1;
            uVar4 = func_0x000180087560(iVar1, 0xfffffffe, *(undefined4 *)(arg1 + 0x10));
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800342c7
// Address: 0x1800342c7
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800342b0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    
    if (arg3 != 0) {
        uVar4 = 0;
        iVar1 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(iVar1 + 0x20);
        if ((((((~*(uint8_t *)(iVar2 + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) && (*(char *)(arg3 + 2) == '\b')
             ) && (*(char *)(arg3 + 3) == '\0')) &&
           (uVar4 = *(uint64_t *)(arg1 + 8), *(uint64_t *)(arg3 + 0x20) == uVar4)) {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(iVar2 + 0x18);
                *(int64_t *)(iVar2 + 0x18) = iVar1;
            }
            **(int64_t **)(iVar1 + 0x40) = arg3;
            *(uint32_t *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
            if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
                iVar5 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
                iVar3 = iVar5 * 2;
                if (iVar5 < 1) {
                    iVar3 = iVar5 + 1;
                }
                func_0x000180093240(iVar1, iVar3, 0);
            }
            *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + 1;
            uVar4 = func_0x000180087560(iVar1, 0xfffffffe, *(undefined4 *)(arg1 + 0x10));
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_18003438c
// Address: 0x18003438c
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800342b0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint64_t in_RAX;
    uint64_t uVar4;
    int32_t iVar5;
    int64_t var_8h;
    
    if (arg3 != 0) {
        uVar4 = 0;
        iVar1 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(iVar1 + 0x20);
        if ((((((~*(uint8_t *)(iVar2 + 0x58) & 3 ^ *(uint8_t *)(arg3 + 1)) & 0xb) != 0) && (*(char *)(arg3 + 2) == '\b')
             ) && (*(char *)(arg3 + 3) == '\0')) &&
           (uVar4 = *(uint64_t *)(arg1 + 8), *(uint64_t *)(arg3 + 0x20) == uVar4)) {
            if ((*(uint8_t *)(iVar1 + 1) & 4) != 0) {
                *(uint8_t *)(iVar1 + 1) = *(uint8_t *)(iVar1 + 1) & 0xfb;
                *(undefined8 *)(iVar1 + 0x48) = *(undefined8 *)(iVar2 + 0x18);
                *(int64_t *)(iVar2 + 0x18) = iVar1;
            }
            **(int64_t **)(iVar1 + 0x40) = arg3;
            *(uint32_t *)(*(int64_t *)(iVar1 + 0x40) + 0xc) = (uint32_t)*(uint8_t *)(arg3 + 2);
            if (*(int64_t *)(iVar1 + 0x30) - *(int64_t *)(iVar1 + 0x40) < 0x11) {
                iVar5 = *(int32_t *)(iVar1 + 0x60) - ((int32_t)iVar1 + 0x60);
                iVar3 = iVar5 * 2;
                if (iVar5 < 1) {
                    iVar3 = iVar5 + 1;
                }
                func_0x000180093240(iVar1, iVar3, 0);
            }
            *(int64_t *)(iVar1 + 0x40) = *(int64_t *)(iVar1 + 0x40) + 0x10;
            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + 1;
            uVar4 = func_0x000180087560(iVar1, 0xfffffffe, *(undefined4 *)(arg1 + 0x10));
        }
        return uVar4 & 0xffffffffffffff00;
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800343a0
// Address: 0x1800343a0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800343a0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar18 = arg1;
    if (cVar7 != '\0') {
        iVar18 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    piVar15 = *(int64_t **)(iVar18 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar15 <= *(int64_t **)(iVar18 + 0x78)) || (*(int64_t **)(iVar18 + 0x18) < piVar15)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar15[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(char *)(*(int64_t *)piVar15[1] + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    iVar18 = piVar15[2];
    uVar17 = *piVar15 - iVar18 >> 4;
    iVar9 = func_0x000180085d50(arg1, 2);
    iVar16 = (int32_t)uVar17;
    iVar8 = (int32_t)arg1;
    if (iVar9 == 0) {
        func_0x000180086fd0(arg1, uVar17 & 0xffffffff, 0);
        uVar17 = 0;
        if (0 < iVar16) {
            do {
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                uVar10 = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (**(uint64_t **)(arg1 + 0x18) < uVar10) {
                    **(uint64_t **)(arg1 + 0x18) = uVar10;
                }
                if ((5 < *(int32_t *)(iVar18 + 0xc + uVar17 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + uVar17 * 0x10);
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + 0xc + uVar17 * 0x10);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *(undefined4 **)(arg1 + 0x40) = puVar1 + 4;
                if (*(char *)(*(int64_t *)(puVar1 + -4) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar3 = (code *)swi(3);
                    uVar12 = (*pcVar3)();
                    return uVar12;
                }
                uVar20 = (int32_t)uVar17 + 1;
                uVar17 = (uint64_t)uVar20;
                puVar11 = (undefined4 *)func_0x0001800a1010();
                uVar4 = puVar1[1];
                uVar5 = puVar1[2];
                uVar6 = puVar1[3];
                *puVar11 = *puVar1;
                puVar11[1] = uVar4;
                puVar11[2] = uVar5;
                puVar11[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar19 = *(int64_t *)(puVar1 + -4);
                    if (((*(uint8_t *)(iVar19 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar2 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar2 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar19 + 1) = *(uint8_t *)(iVar19 + 1) & 0xfb;
                            *(undefined8 *)(iVar19 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                            *(int64_t *)(iVar2 + 0x18) = iVar19;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((int32_t)uVar20 < iVar16);
        }
    } else {
        iVar9 = fcn.180085f50(arg1, 2, 0);
        if (iVar9 < 1) {
            fcn.180088380(arg1, 2, 0x180622550);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        if (iVar16 < iVar9) {
            fcn.180088380(arg1, 2, 0x1806225b0);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        iVar19 = (int64_t)iVar9;
        func_0x000180085610(arg1, 1);
        if ((5 < *(int32_t *)(iVar18 + -4 + iVar19 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + -0x10 + iVar19 * 0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + -4 + iVar19 * 0x10);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar9 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar9 * 2;
            if (iVar9 < 1) {
                iVar8 = iVar9 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    return 1;
}

// ============================================================
// Function: FUN_180034422
// Address: 0x180034422
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800343a0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar18 = arg1;
    if (cVar7 != '\0') {
        iVar18 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    piVar15 = *(int64_t **)(iVar18 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar15 <= *(int64_t **)(iVar18 + 0x78)) || (*(int64_t **)(iVar18 + 0x18) < piVar15)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar15[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(char *)(*(int64_t *)piVar15[1] + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    iVar18 = piVar15[2];
    uVar17 = *piVar15 - iVar18 >> 4;
    iVar9 = func_0x000180085d50(arg1, 2);
    iVar16 = (int32_t)uVar17;
    iVar8 = (int32_t)arg1;
    if (iVar9 == 0) {
        func_0x000180086fd0(arg1, uVar17 & 0xffffffff, 0);
        uVar17 = 0;
        if (0 < iVar16) {
            do {
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                uVar10 = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (**(uint64_t **)(arg1 + 0x18) < uVar10) {
                    **(uint64_t **)(arg1 + 0x18) = uVar10;
                }
                if ((5 < *(int32_t *)(iVar18 + 0xc + uVar17 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + uVar17 * 0x10);
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + 0xc + uVar17 * 0x10);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *(undefined4 **)(arg1 + 0x40) = puVar1 + 4;
                if (*(char *)(*(int64_t *)(puVar1 + -4) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar3 = (code *)swi(3);
                    uVar12 = (*pcVar3)();
                    return uVar12;
                }
                uVar20 = (int32_t)uVar17 + 1;
                uVar17 = (uint64_t)uVar20;
                puVar11 = (undefined4 *)func_0x0001800a1010();
                uVar4 = puVar1[1];
                uVar5 = puVar1[2];
                uVar6 = puVar1[3];
                *puVar11 = *puVar1;
                puVar11[1] = uVar4;
                puVar11[2] = uVar5;
                puVar11[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar19 = *(int64_t *)(puVar1 + -4);
                    if (((*(uint8_t *)(iVar19 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar2 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar2 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar19 + 1) = *(uint8_t *)(iVar19 + 1) & 0xfb;
                            *(undefined8 *)(iVar19 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                            *(int64_t *)(iVar2 + 0x18) = iVar19;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((int32_t)uVar20 < iVar16);
        }
    } else {
        iVar9 = fcn.180085f50(arg1, 2, 0);
        if (iVar9 < 1) {
            fcn.180088380(arg1, 2, 0x180622550);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        if (iVar16 < iVar9) {
            fcn.180088380(arg1, 2, 0x1806225b0);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        iVar19 = (int64_t)iVar9;
        func_0x000180085610(arg1, 1);
        if ((5 < *(int32_t *)(iVar18 + -4 + iVar19 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + -0x10 + iVar19 * 0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + -4 + iVar19 * 0x10);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar9 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar9 * 2;
            if (iVar9 < 1) {
                iVar8 = iVar9 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    return 1;
}

// ============================================================
// Function: FUN_18003451a
// Address: 0x18003451a
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800343a0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar18 = arg1;
    if (cVar7 != '\0') {
        iVar18 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    piVar15 = *(int64_t **)(iVar18 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar15 <= *(int64_t **)(iVar18 + 0x78)) || (*(int64_t **)(iVar18 + 0x18) < piVar15)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar15[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(char *)(*(int64_t *)piVar15[1] + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    iVar18 = piVar15[2];
    uVar17 = *piVar15 - iVar18 >> 4;
    iVar9 = func_0x000180085d50(arg1, 2);
    iVar16 = (int32_t)uVar17;
    iVar8 = (int32_t)arg1;
    if (iVar9 == 0) {
        func_0x000180086fd0(arg1, uVar17 & 0xffffffff, 0);
        uVar17 = 0;
        if (0 < iVar16) {
            do {
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                uVar10 = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (**(uint64_t **)(arg1 + 0x18) < uVar10) {
                    **(uint64_t **)(arg1 + 0x18) = uVar10;
                }
                if ((5 < *(int32_t *)(iVar18 + 0xc + uVar17 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + uVar17 * 0x10);
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + 0xc + uVar17 * 0x10);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *(undefined4 **)(arg1 + 0x40) = puVar1 + 4;
                if (*(char *)(*(int64_t *)(puVar1 + -4) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar3 = (code *)swi(3);
                    uVar12 = (*pcVar3)();
                    return uVar12;
                }
                uVar20 = (int32_t)uVar17 + 1;
                uVar17 = (uint64_t)uVar20;
                puVar11 = (undefined4 *)func_0x0001800a1010();
                uVar4 = puVar1[1];
                uVar5 = puVar1[2];
                uVar6 = puVar1[3];
                *puVar11 = *puVar1;
                puVar11[1] = uVar4;
                puVar11[2] = uVar5;
                puVar11[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar19 = *(int64_t *)(puVar1 + -4);
                    if (((*(uint8_t *)(iVar19 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar2 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar2 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar19 + 1) = *(uint8_t *)(iVar19 + 1) & 0xfb;
                            *(undefined8 *)(iVar19 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                            *(int64_t *)(iVar2 + 0x18) = iVar19;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((int32_t)uVar20 < iVar16);
        }
    } else {
        iVar9 = fcn.180085f50(arg1, 2, 0);
        if (iVar9 < 1) {
            fcn.180088380(arg1, 2, 0x180622550);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        if (iVar16 < iVar9) {
            fcn.180088380(arg1, 2, 0x1806225b0);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        iVar19 = (int64_t)iVar9;
        func_0x000180085610(arg1, 1);
        if ((5 < *(int32_t *)(iVar18 + -4 + iVar19 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + -0x10 + iVar19 * 0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + -4 + iVar19 * 0x10);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar9 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar9 * 2;
            if (iVar9 < 1) {
                iVar8 = iVar9 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    return 1;
}

// ============================================================
// Function: FUN_180034665
// Address: 0x180034665
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800343a0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar18 = arg1;
    if (cVar7 != '\0') {
        iVar18 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    piVar15 = *(int64_t **)(iVar18 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar15 <= *(int64_t **)(iVar18 + 0x78)) || (*(int64_t **)(iVar18 + 0x18) < piVar15)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar15[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(char *)(*(int64_t *)piVar15[1] + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    iVar18 = piVar15[2];
    uVar17 = *piVar15 - iVar18 >> 4;
    iVar9 = func_0x000180085d50(arg1, 2);
    iVar16 = (int32_t)uVar17;
    iVar8 = (int32_t)arg1;
    if (iVar9 == 0) {
        func_0x000180086fd0(arg1, uVar17 & 0xffffffff, 0);
        uVar17 = 0;
        if (0 < iVar16) {
            do {
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                uVar10 = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (**(uint64_t **)(arg1 + 0x18) < uVar10) {
                    **(uint64_t **)(arg1 + 0x18) = uVar10;
                }
                if ((5 < *(int32_t *)(iVar18 + 0xc + uVar17 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + uVar17 * 0x10);
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + 0xc + uVar17 * 0x10);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *(undefined4 **)(arg1 + 0x40) = puVar1 + 4;
                if (*(char *)(*(int64_t *)(puVar1 + -4) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar3 = (code *)swi(3);
                    uVar12 = (*pcVar3)();
                    return uVar12;
                }
                uVar20 = (int32_t)uVar17 + 1;
                uVar17 = (uint64_t)uVar20;
                puVar11 = (undefined4 *)func_0x0001800a1010();
                uVar4 = puVar1[1];
                uVar5 = puVar1[2];
                uVar6 = puVar1[3];
                *puVar11 = *puVar1;
                puVar11[1] = uVar4;
                puVar11[2] = uVar5;
                puVar11[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar19 = *(int64_t *)(puVar1 + -4);
                    if (((*(uint8_t *)(iVar19 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar2 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar2 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar19 + 1) = *(uint8_t *)(iVar19 + 1) & 0xfb;
                            *(undefined8 *)(iVar19 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                            *(int64_t *)(iVar2 + 0x18) = iVar19;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((int32_t)uVar20 < iVar16);
        }
    } else {
        iVar9 = fcn.180085f50(arg1, 2, 0);
        if (iVar9 < 1) {
            fcn.180088380(arg1, 2, 0x180622550);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        if (iVar16 < iVar9) {
            fcn.180088380(arg1, 2, 0x1806225b0);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        iVar19 = (int64_t)iVar9;
        func_0x000180085610(arg1, 1);
        if ((5 < *(int32_t *)(iVar18 + -4 + iVar19 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + -0x10 + iVar19 * 0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + -4 + iVar19 * 0x10);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar9 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar9 * 2;
            if (iVar9 < 1) {
                iVar8 = iVar9 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    return 1;
}

// ============================================================
// Function: FUN_1800346b3
// Address: 0x1800346b3
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800343a0(int64_t arg1)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t *piVar15;
    int32_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar18 = arg1;
    if (cVar7 != '\0') {
        iVar18 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    piVar15 = *(int64_t **)(iVar18 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar15 <= *(int64_t **)(iVar18 + 0x78)) || (*(int64_t **)(iVar18 + 0x18) < piVar15)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar15[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    if (*(char *)(*(int64_t *)piVar15[1] + 3) != '\0') {
        fcn.180088380(arg1, 1, 0x1806224f8);
        pcVar3 = (code *)swi(3);
        uVar12 = (*pcVar3)();
        return uVar12;
    }
    iVar18 = piVar15[2];
    uVar17 = *piVar15 - iVar18 >> 4;
    iVar9 = func_0x000180085d50(arg1, 2);
    iVar16 = (int32_t)uVar17;
    iVar8 = (int32_t)arg1;
    if (iVar9 == 0) {
        func_0x000180086fd0(arg1, uVar17 & 0xffffffff, 0);
        uVar17 = 0;
        if (0 < iVar16) {
            do {
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                uVar10 = *(int64_t *)(arg1 + 0x40) + 0x10;
                if (**(uint64_t **)(arg1 + 0x18) < uVar10) {
                    **(uint64_t **)(arg1 + 0x18) = uVar10;
                }
                if ((5 < *(int32_t *)(iVar18 + 0xc + uVar17 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + uVar17 * 0x10);
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + 0xc + uVar17 * 0x10);
                if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
                    iVar13 = *(int32_t *)(arg1 + 0x60) - iVar8;
                    iVar14 = iVar13 + -0x60;
                    iVar9 = iVar14 * 2;
                    if (iVar14 < 1) {
                        iVar9 = iVar13 + -0x5f;
                    }
                    func_0x000180093240(arg1, iVar9, 0);
                }
                puVar1 = *(undefined4 **)(arg1 + 0x40);
                *(undefined4 **)(arg1 + 0x40) = puVar1 + 4;
                if (*(char *)(*(int64_t *)(puVar1 + -4) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar3 = (code *)swi(3);
                    uVar12 = (*pcVar3)();
                    return uVar12;
                }
                uVar20 = (int32_t)uVar17 + 1;
                uVar17 = (uint64_t)uVar20;
                puVar11 = (undefined4 *)func_0x0001800a1010();
                uVar4 = puVar1[1];
                uVar5 = puVar1[2];
                uVar6 = puVar1[3];
                *puVar11 = *puVar1;
                puVar11[1] = uVar4;
                puVar11[2] = uVar5;
                puVar11[3] = uVar6;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar19 = *(int64_t *)(puVar1 + -4);
                    if (((*(uint8_t *)(iVar19 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar2 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar2 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar19 + 1) = *(uint8_t *)(iVar19 + 1) & 0xfb;
                            *(undefined8 *)(iVar19 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                            *(int64_t *)(iVar2 + 0x18) = iVar19;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((int32_t)uVar20 < iVar16);
        }
    } else {
        iVar9 = fcn.180085f50(arg1, 2, 0);
        if (iVar9 < 1) {
            fcn.180088380(arg1, 2, 0x180622550);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        if (iVar16 < iVar9) {
            fcn.180088380(arg1, 2, 0x1806225b0);
            pcVar3 = (code *)swi(3);
            uVar12 = (*pcVar3)();
            return uVar12;
        }
        iVar19 = (int64_t)iVar9;
        func_0x000180085610(arg1, 1);
        if ((5 < *(int32_t *)(iVar18 + -4 + iVar19 * 0x10)) && ((*(uint8_t *)(arg1 + 1) & 4) != 0)) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        **(undefined8 **)(arg1 + 0x40) = *(undefined8 *)(iVar18 + -0x10 + iVar19 * 0x10);
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = *(undefined4 *)(iVar18 + -4 + iVar19 * 0x10);
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar9 = *(int32_t *)(arg1 + 0x60) - (iVar8 + 0x60);
            iVar8 = iVar9 * 2;
            if (iVar9 < 1) {
                iVar8 = iVar9 + 1;
            }
            func_0x000180093240(arg1, iVar8, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    return 1;
}

// ============================================================
// Function: FUN_1800346e0
// Address: 0x1800346e0
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800346e0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar14 = arg1;
    if (cVar7 != '\0') {
        iVar14 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    piVar12 = *(int64_t **)(iVar14 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar12 <= *(int64_t **)(iVar14 + 0x78)) || (*(int64_t **)(iVar14 + 0x18) < piVar12)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar12[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(char *)(*(int64_t *)piVar12[1] + 3) == '\0') {
        iVar1 = piVar12[2];
        iVar2 = *piVar12;
        iVar8 = func_0x000180088860(arg1, 2);
        if (iVar8 < 1) {
            fcn.180088380(arg1, 2, 0x180622590);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        if (iVar8 <= (int32_t)(iVar2 - iVar1 >> 4)) {
            puVar13 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            puVar10 = puVar13;
            if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                puVar10 = *(undefined4 **)0x180782430;
            }
            if (puVar10 == *(undefined4 **)0x180782430) {
                iVar9 = -1;
            } else {
                iVar9 = puVar10[3];
            }
            if (iVar9 == *(int32_t *)(iVar1 + -4 + (int64_t)iVar8 * 0x10)) {
                if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                    puVar13 = *(undefined4 **)0x180782430;
                }
                if (puVar13 == *(undefined4 **)0x180782430) {
                    puVar13 = (undefined4 *)0x0;
                }
                if ((5 < (int32_t)puVar13[3]) && ((*(uint8_t *)(iVar14 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar14 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar14 + 0x20) + 0x18) = iVar14;
                }
                uVar4 = puVar13[1];
                uVar5 = puVar13[2];
                uVar6 = puVar13[3];
                puVar10 = (undefined4 *)(iVar1 + -0x10 + (int64_t)iVar8 * 0x10);
                *puVar10 = *puVar13;
                puVar10[1] = uVar4;
                puVar10[2] = uVar5;
                puVar10[3] = uVar6;
                return 0;
            }
            func_0x000180088470(arg1, 3);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    fcn.180088380(arg1, 1, 0x1806224f8);
    pcVar3 = (code *)swi(3);
    uVar11 = (*pcVar3)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034765
// Address: 0x180034765
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800346e0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar14 = arg1;
    if (cVar7 != '\0') {
        iVar14 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    piVar12 = *(int64_t **)(iVar14 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar12 <= *(int64_t **)(iVar14 + 0x78)) || (*(int64_t **)(iVar14 + 0x18) < piVar12)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar12[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(char *)(*(int64_t *)piVar12[1] + 3) == '\0') {
        iVar1 = piVar12[2];
        iVar2 = *piVar12;
        iVar8 = func_0x000180088860(arg1, 2);
        if (iVar8 < 1) {
            fcn.180088380(arg1, 2, 0x180622590);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        if (iVar8 <= (int32_t)(iVar2 - iVar1 >> 4)) {
            puVar13 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            puVar10 = puVar13;
            if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                puVar10 = *(undefined4 **)0x180782430;
            }
            if (puVar10 == *(undefined4 **)0x180782430) {
                iVar9 = -1;
            } else {
                iVar9 = puVar10[3];
            }
            if (iVar9 == *(int32_t *)(iVar1 + -4 + (int64_t)iVar8 * 0x10)) {
                if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                    puVar13 = *(undefined4 **)0x180782430;
                }
                if (puVar13 == *(undefined4 **)0x180782430) {
                    puVar13 = (undefined4 *)0x0;
                }
                if ((5 < (int32_t)puVar13[3]) && ((*(uint8_t *)(iVar14 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar14 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar14 + 0x20) + 0x18) = iVar14;
                }
                uVar4 = puVar13[1];
                uVar5 = puVar13[2];
                uVar6 = puVar13[3];
                puVar10 = (undefined4 *)(iVar1 + -0x10 + (int64_t)iVar8 * 0x10);
                *puVar10 = *puVar13;
                puVar10[1] = uVar4;
                puVar10[2] = uVar5;
                puVar10[3] = uVar6;
                return 0;
            }
            func_0x000180088470(arg1, 3);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    fcn.180088380(arg1, 1, 0x1806224f8);
    pcVar3 = (code *)swi(3);
    uVar11 = (*pcVar3)();
    return uVar11;
}

// ============================================================
// Function: FUN_18003476e
// Address: 0x18003476e
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800346e0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar14 = arg1;
    if (cVar7 != '\0') {
        iVar14 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    piVar12 = *(int64_t **)(iVar14 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar12 <= *(int64_t **)(iVar14 + 0x78)) || (*(int64_t **)(iVar14 + 0x18) < piVar12)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar12[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(char *)(*(int64_t *)piVar12[1] + 3) == '\0') {
        iVar1 = piVar12[2];
        iVar2 = *piVar12;
        iVar8 = func_0x000180088860(arg1, 2);
        if (iVar8 < 1) {
            fcn.180088380(arg1, 2, 0x180622590);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        if (iVar8 <= (int32_t)(iVar2 - iVar1 >> 4)) {
            puVar13 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            puVar10 = puVar13;
            if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                puVar10 = *(undefined4 **)0x180782430;
            }
            if (puVar10 == *(undefined4 **)0x180782430) {
                iVar9 = -1;
            } else {
                iVar9 = puVar10[3];
            }
            if (iVar9 == *(int32_t *)(iVar1 + -4 + (int64_t)iVar8 * 0x10)) {
                if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                    puVar13 = *(undefined4 **)0x180782430;
                }
                if (puVar13 == *(undefined4 **)0x180782430) {
                    puVar13 = (undefined4 *)0x0;
                }
                if ((5 < (int32_t)puVar13[3]) && ((*(uint8_t *)(iVar14 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar14 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar14 + 0x20) + 0x18) = iVar14;
                }
                uVar4 = puVar13[1];
                uVar5 = puVar13[2];
                uVar6 = puVar13[3];
                puVar10 = (undefined4 *)(iVar1 + -0x10 + (int64_t)iVar8 * 0x10);
                *puVar10 = *puVar13;
                puVar10[1] = uVar4;
                puVar10[2] = uVar5;
                puVar10[3] = uVar6;
                return 0;
            }
            func_0x000180088470(arg1, 3);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    fcn.180088380(arg1, 1, 0x1806224f8);
    pcVar3 = (code *)swi(3);
    uVar11 = (*pcVar3)();
    return uVar11;
}

// ============================================================
// Function: FUN_18003482b
// Address: 0x18003482b
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800346e0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar14 = arg1;
    if (cVar7 != '\0') {
        iVar14 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    piVar12 = *(int64_t **)(iVar14 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar12 <= *(int64_t **)(iVar14 + 0x78)) || (*(int64_t **)(iVar14 + 0x18) < piVar12)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar12[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(char *)(*(int64_t *)piVar12[1] + 3) == '\0') {
        iVar1 = piVar12[2];
        iVar2 = *piVar12;
        iVar8 = func_0x000180088860(arg1, 2);
        if (iVar8 < 1) {
            fcn.180088380(arg1, 2, 0x180622590);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        if (iVar8 <= (int32_t)(iVar2 - iVar1 >> 4)) {
            puVar13 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            puVar10 = puVar13;
            if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                puVar10 = *(undefined4 **)0x180782430;
            }
            if (puVar10 == *(undefined4 **)0x180782430) {
                iVar9 = -1;
            } else {
                iVar9 = puVar10[3];
            }
            if (iVar9 == *(int32_t *)(iVar1 + -4 + (int64_t)iVar8 * 0x10)) {
                if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                    puVar13 = *(undefined4 **)0x180782430;
                }
                if (puVar13 == *(undefined4 **)0x180782430) {
                    puVar13 = (undefined4 *)0x0;
                }
                if ((5 < (int32_t)puVar13[3]) && ((*(uint8_t *)(iVar14 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar14 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar14 + 0x20) + 0x18) = iVar14;
                }
                uVar4 = puVar13[1];
                uVar5 = puVar13[2];
                uVar6 = puVar13[3];
                puVar10 = (undefined4 *)(iVar1 + -0x10 + (int64_t)iVar8 * 0x10);
                *puVar10 = *puVar13;
                puVar10[1] = uVar4;
                puVar10[2] = uVar5;
                puVar10[3] = uVar6;
                return 0;
            }
            func_0x000180088470(arg1, 3);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    fcn.180088380(arg1, 1, 0x1806224f8);
    pcVar3 = (code *)swi(3);
    uVar11 = (*pcVar3)();
    return uVar11;
}

// ============================================================
// Function: FUN_180034879
// Address: 0x180034879
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.1800346e0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    char cVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_10h = 0;
    cVar7 = func_0x000180051370(arg1, &var_10h);
    iVar14 = arg1;
    if (cVar7 != '\0') {
        iVar14 = var_10h;
    }
    iVar8 = func_0x000180088860(arg1, 1);
    if (iVar8 < 0) {
        fcn.180088380(arg1, 1, 0x180621ad8);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    piVar12 = *(int64_t **)(iVar14 + 0x18) + (int64_t)iVar8 * -5;
    if ((piVar12 <= *(int64_t **)(iVar14 + 0x78)) || (*(int64_t **)(iVar14 + 0x18) < piVar12)) {
        fcn.180088380(arg1, 1, 0x180622578);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(int32_t *)((int64_t)(int64_t *)piVar12[1] + 0xc) != 8) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    if (*(char *)(*(int64_t *)piVar12[1] + 3) == '\0') {
        iVar1 = piVar12[2];
        iVar2 = *piVar12;
        iVar8 = func_0x000180088860(arg1, 2);
        if (iVar8 < 1) {
            fcn.180088380(arg1, 2, 0x180622590);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        if (iVar8 <= (int32_t)(iVar2 - iVar1 >> 4)) {
            puVar13 = (undefined4 *)(*(int64_t *)(arg1 + 0x28) + 0x20);
            puVar10 = puVar13;
            if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                puVar10 = *(undefined4 **)0x180782430;
            }
            if (puVar10 == *(undefined4 **)0x180782430) {
                iVar9 = -1;
            } else {
                iVar9 = puVar10[3];
            }
            if (iVar9 == *(int32_t *)(iVar1 + -4 + (int64_t)iVar8 * 0x10)) {
                if (*(undefined4 **)(arg1 + 0x40) <= puVar13) {
                    puVar13 = *(undefined4 **)0x180782430;
                }
                if (puVar13 == *(undefined4 **)0x180782430) {
                    puVar13 = (undefined4 *)0x0;
                }
                if ((5 < (int32_t)puVar13[3]) && ((*(uint8_t *)(iVar14 + 1) & 4) != 0)) {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar14 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(iVar14 + 0x20) + 0x18) = iVar14;
                }
                uVar4 = puVar13[1];
                uVar5 = puVar13[2];
                uVar6 = puVar13[3];
                puVar10 = (undefined4 *)(iVar1 + -0x10 + (int64_t)iVar8 * 0x10);
                *puVar10 = *puVar13;
                puVar10[1] = uVar4;
                puVar10[2] = uVar5;
                puVar10[3] = uVar6;
                return 0;
            }
            func_0x000180088470(arg1, 3);
            pcVar3 = (code *)swi(3);
            uVar11 = (*pcVar3)();
            return uVar11;
        }
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar3 = (code *)swi(3);
        uVar11 = (*pcVar3)();
        return uVar11;
    }
    fcn.180088380(arg1, 1, 0x1806224f8);
    pcVar3 = (code *)swi(3);
    uVar11 = (*pcVar3)();
    return uVar11;
}

// ============================================================
// Function: FUN_1800348c0
// Address: 0x1800348c0
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800348c0(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar11 = func_0x000180085d50(arg1);
        if (iVar11 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
        if (piVar7 == *(int64_t **)0x180782430) {
            piVar7 = (int64_t *)0x0;
        }
        uVar1 = *(uint8_t *)(*piVar7 + 4);
        func_0x000180086fd0(arg1, uVar1, 0);
        iVar11 = 1;
        if (uVar1 != 0) {
            do {
                iVar8 = func_0x000180088160(arg1, 0xfffffffe, iVar11);
                if (iVar8 != 0) {
                    iVar8 = *(int64_t *)(arg1 + 0x40);
                    if (*(char *)(*(int64_t *)(iVar8 + -0x20) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar3 = (code *)swi(3);
                        uVar10 = (*pcVar3)();
                        return uVar10;
                    }
                    puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar8 + -0x20), iVar11);
                    uVar4 = *(undefined4 *)(iVar8 + -0xc);
                    uVar5 = *(undefined4 *)(iVar8 + -8);
                    uVar6 = *(undefined4 *)(iVar8 + -4);
                    *puVar9 = *(undefined4 *)(iVar8 + -0x10);
                    puVar9[1] = uVar4;
                    puVar9[2] = uVar5;
                    puVar9[3] = uVar6;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar8 = *(int64_t *)(iVar8 + -0x20);
                        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar2 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar2 + 0x59) == '\x02') {
                                func_0x000180094420();
                            } else {
                                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                                *(int64_t *)(iVar2 + 0x18) = iVar8;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
                iVar11 = iVar11 + 1;
            } while (iVar11 <= (int32_t)(uint32_t)uVar1);
        }
        return 1;
    }
    fcn.180088380(arg1, 1, 0x1806224b0);
    pcVar3 = (code *)swi(3);
    uVar10 = (*pcVar3)();
    return uVar10;
}

// ============================================================
// Function: FUN_180034938
// Address: 0x180034938
// Size: 222 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800348c0(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar11 = func_0x000180085d50(arg1);
        if (iVar11 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
        if (piVar7 == *(int64_t **)0x180782430) {
            piVar7 = (int64_t *)0x0;
        }
        uVar1 = *(uint8_t *)(*piVar7 + 4);
        func_0x000180086fd0(arg1, uVar1, 0);
        iVar11 = 1;
        if (uVar1 != 0) {
            do {
                iVar8 = func_0x000180088160(arg1, 0xfffffffe, iVar11);
                if (iVar8 != 0) {
                    iVar8 = *(int64_t *)(arg1 + 0x40);
                    if (*(char *)(*(int64_t *)(iVar8 + -0x20) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar3 = (code *)swi(3);
                        uVar10 = (*pcVar3)();
                        return uVar10;
                    }
                    puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar8 + -0x20), iVar11);
                    uVar4 = *(undefined4 *)(iVar8 + -0xc);
                    uVar5 = *(undefined4 *)(iVar8 + -8);
                    uVar6 = *(undefined4 *)(iVar8 + -4);
                    *puVar9 = *(undefined4 *)(iVar8 + -0x10);
                    puVar9[1] = uVar4;
                    puVar9[2] = uVar5;
                    puVar9[3] = uVar6;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar8 = *(int64_t *)(iVar8 + -0x20);
                        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar2 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar2 + 0x59) == '\x02') {
                                func_0x000180094420();
                            } else {
                                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                                *(int64_t *)(iVar2 + 0x18) = iVar8;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
                iVar11 = iVar11 + 1;
            } while (iVar11 <= (int32_t)(uint32_t)uVar1);
        }
        return 1;
    }
    fcn.180088380(arg1, 1, 0x1806224b0);
    pcVar3 = (code *)swi(3);
    uVar10 = (*pcVar3)();
    return uVar10;
}

// ============================================================
// Function: FUN_180034a16
// Address: 0x180034a16
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800348c0(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar11 = func_0x000180085d50(arg1);
        if (iVar11 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
        if (piVar7 == *(int64_t **)0x180782430) {
            piVar7 = (int64_t *)0x0;
        }
        uVar1 = *(uint8_t *)(*piVar7 + 4);
        func_0x000180086fd0(arg1, uVar1, 0);
        iVar11 = 1;
        if (uVar1 != 0) {
            do {
                iVar8 = func_0x000180088160(arg1, 0xfffffffe, iVar11);
                if (iVar8 != 0) {
                    iVar8 = *(int64_t *)(arg1 + 0x40);
                    if (*(char *)(*(int64_t *)(iVar8 + -0x20) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar3 = (code *)swi(3);
                        uVar10 = (*pcVar3)();
                        return uVar10;
                    }
                    puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar8 + -0x20), iVar11);
                    uVar4 = *(undefined4 *)(iVar8 + -0xc);
                    uVar5 = *(undefined4 *)(iVar8 + -8);
                    uVar6 = *(undefined4 *)(iVar8 + -4);
                    *puVar9 = *(undefined4 *)(iVar8 + -0x10);
                    puVar9[1] = uVar4;
                    puVar9[2] = uVar5;
                    puVar9[3] = uVar6;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar8 = *(int64_t *)(iVar8 + -0x20);
                        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar2 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar2 + 0x59) == '\x02') {
                                func_0x000180094420();
                            } else {
                                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                                *(int64_t *)(iVar2 + 0x18) = iVar8;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
                iVar11 = iVar11 + 1;
            } while (iVar11 <= (int32_t)(uint32_t)uVar1);
        }
        return 1;
    }
    fcn.180088380(arg1, 1, 0x1806224b0);
    pcVar3 = (code *)swi(3);
    uVar10 = (*pcVar3)();
    return uVar10;
}

// ============================================================
// Function: FUN_180034a3d
// Address: 0x180034a3d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800348c0(int64_t arg1)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t *piVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 8)) {
        iVar11 = func_0x000180085d50(arg1);
        if (iVar11 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
        if (piVar7 == *(int64_t **)0x180782430) {
            piVar7 = (int64_t *)0x0;
        }
        uVar1 = *(uint8_t *)(*piVar7 + 4);
        func_0x000180086fd0(arg1, uVar1, 0);
        iVar11 = 1;
        if (uVar1 != 0) {
            do {
                iVar8 = func_0x000180088160(arg1, 0xfffffffe, iVar11);
                if (iVar8 != 0) {
                    iVar8 = *(int64_t *)(arg1 + 0x40);
                    if (*(char *)(*(int64_t *)(iVar8 + -0x20) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar3 = (code *)swi(3);
                        uVar10 = (*pcVar3)();
                        return uVar10;
                    }
                    puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar8 + -0x20), iVar11);
                    uVar4 = *(undefined4 *)(iVar8 + -0xc);
                    uVar5 = *(undefined4 *)(iVar8 + -8);
                    uVar6 = *(undefined4 *)(iVar8 + -4);
                    *puVar9 = *(undefined4 *)(iVar8 + -0x10);
                    puVar9[1] = uVar4;
                    puVar9[2] = uVar5;
                    puVar9[3] = uVar6;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar8 = *(int64_t *)(iVar8 + -0x20);
                        if (((*(uint8_t *)(iVar8 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar2 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar2 + 0x59) == '\x02') {
                                func_0x000180094420();
                            } else {
                                *(uint8_t *)(iVar8 + 1) = *(uint8_t *)(iVar8 + 1) & 0xfb;
                                *(undefined8 *)(iVar8 + 0x18) = *(undefined8 *)(iVar2 + 0x18);
                                *(int64_t *)(iVar2 + 0x18) = iVar8;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                }
                iVar11 = iVar11 + 1;
            } while (iVar11 <= (int32_t)(uint32_t)uVar1);
        }
        return 1;
    }
    fcn.180088380(arg1, 1, 0x1806224b0);
    pcVar3 = (code *)swi(3);
    uVar10 = (*pcVar3)();
    return uVar10;
}

// ============================================================
// Function: FUN_180034a50
// Address: 0x180034a50
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180034a50(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t var_8h;
    
    piVar3 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 8)) {
        iVar2 = func_0x000180085d50(arg1);
        if (iVar2 == 0) {
            fcn.180088380(arg1, 1, 0x180622478);
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        fcn.180033bd0(arg1);
    } else {
        func_0x000180085bf0(arg1);
    }
    piVar3 = (int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10);
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 8)) {
        fcn.180088380(arg1, 1, 0x1806224b0);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    if (piVar3 == *(int64_t **)0x180782430) {
        piVar3 = (int64_t *)0x0;
    }
    iVar4 = *piVar3;
    iVar2 = func_0x000180088860(arg1, 2);
    if (iVar2 < 1) {
        fcn.180088380(arg1, 1, 0x180622550);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    if ((int32_t)(uint32_t)*(uint8_t *)(iVar4 + 4) < iVar2) {
        fcn.180088380(arg1, 2, 0x1806225b0);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar4 = func_0x000180088160(arg1, 0xffffffff);
    if (iVar4 != 0) {
        return 1;
    }
    func_0x0001800883d0(arg1, 2, 0x1806225f0);
    pcVar1 = (code *)swi(3);
    uVar5 = (*pcVar1)();
    return uVar5;
}

