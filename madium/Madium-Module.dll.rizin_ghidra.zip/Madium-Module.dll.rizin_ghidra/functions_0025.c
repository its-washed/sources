// Chunk 25 - 50 functions

// ============================================================
// Function: FUN_18004cbd0
// Address: 0x18004cbd0
// Size: 129 bytes
// ============================================================
undefined8 fcn.18004cbd0(int64_t arg1)
{
    int64_t iVar1;
    undefined uVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = (int64_t *)fcn.180008740();
    uVar3 = fcn.180088860(arg1, 1);
    iVar1 = *(int64_t *)(*piVar4 + 8);
    iVar5 = (*(code *)0x69a404)();
    if (iVar5 == iVar1) {
        uVar2 = (*(code *)0x69a41a)(uVar3, 0);
        (*(code *)0x69a452)(0, uVar2, 8, 0);
        (*(code *)0x69a452)(0, uVar2, 10, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004cc60
// Address: 0x18004cc60
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004cc60(int64_t arg1)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = (int64_t *)fcn.180008740();
    uVar2 = fcn.180088860(arg1, 1);
    iVar1 = *(int64_t *)(*piVar3 + 8);
    iVar4 = (*(code *)0x69a404)();
    if (iVar4 == iVar1) {
        uVar2 = (*(code *)0x69a41a)(uVar2, 0);
        (*(code *)0x69a452)(0, uVar2, 10, 0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004ccd0
// Address: 0x18004ccd0
// Size: 989 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018004cd31: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cdbe: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cdf9: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004ce34: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004ce6f: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004ceaa: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cee5: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cf20: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cf5b: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cf96: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004cfd1: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004d018: Changing call to branch
// WARNING: Possible PIC construction at 0x00018004d057: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018004cfd6)
// WARNING: Removing unreachable block (ram,0x00018004cf9b)
// WARNING: Removing unreachable block (ram,0x00018004cf60)
// WARNING: Removing unreachable block (ram,0x00018004cf25)
// WARNING: Removing unreachable block (ram,0x00018004ceea)
// WARNING: Removing unreachable block (ram,0x00018004ceaf)
// WARNING: Removing unreachable block (ram,0x00018004ce74)
// WARNING: Removing unreachable block (ram,0x00018004ce39)
// WARNING: Removing unreachable block (ram,0x00018004cdfe)
// WARNING: Removing unreachable block (ram,0x00018004cdc3)
// WARNING: Removing unreachable block (ram,0x00018004cd36)
// WARNING: Removing unreachable block (ram,0x00018004cd40)
// WARNING: Removing unreachable block (ram,0x00018004cd62)
// WARNING: Removing unreachable block (ram,0x00018004cd6d)
// WARNING: Removing unreachable block (ram,0x00018004cd67)
// WARNING: Removing unreachable block (ram,0x00018004cd7a)
// WARNING: Removing unreachable block (ram,0x00018004cd88)
// WARNING: Removing unreachable block (ram,0x00018004d01d)
// WARNING: Removing unreachable block (ram,0x00018004d022)
// WARNING: Removing unreachable block (ram,0x00018004d044)
// WARNING: Removing unreachable block (ram,0x00018004d04f)
// WARNING: Removing unreachable block (ram,0x00018004d049)
// WARNING: Removing unreachable block (ram,0x00018004d05c)
// WARNING: Removing unreachable block (ram,0x00018004d06a)
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18004ccd0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t var_20h;
    undefined auStack_d8 [32];
    undefined8 uStack_b8;
    undefined4 uStack_ac;
    uint64_t uStack_a8;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    func_0x000180018f70();
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, 0x18004c760, 0x1806239f0, 0);
    uStack_a8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    iVar4 = (int32_t)(iVar1 - iVar2 >> 4);
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = func_0x000180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = func_0x000180498cd0(0x1806239f0);
    uStack_b8 = func_0x00018009a8e0(arg2, 0x1806239f0, uVar3);
    uStack_ac = 6;
    func_0x0001800a8680(arg2, uVar5, &uStack_b8, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    func_0x000180459870(uStack_a8 ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_18004d0b0
// Address: 0x18004d0b0
// Size: 1361 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel

void fcn.18004d0b0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    code *pcVar6;
    double dVar7;
    int32_t iVar8;
    int64_t **ppiVar9;
    int64_t iVar10;
    int64_t *piVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    undefined4 *puVar14;
    int64_t **ppiVar15;
    undefined *puVar16;
    int64_t *unaff_RSI;
    uint64_t uVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    bool bVar20;
    undefined4 uVar21;
    undefined4 extraout_XMM0_Da;
    float fVar22;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    ppiVar9 = *(int64_t ***)(arg1 + 0x28);
    ppiVar15 = ppiVar9;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar9) {
        ppiVar15 = *(int64_t ***)0x180782430;
    }
    puVar16 = auStack_b8;
    if (((*(int32_t *)((int64_t)ppiVar15 + 0xc) == 9) &&
        (puVar16 = auStack_b8, *(uint8_t *)((int64_t)*ppiVar15 + 3) == *(uint32_t *)0x1807823dc)) &&
       (puVar16 = auStack_b8, *ppiVar15 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar9) {
            ppiVar9 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar9 + 0xc) == 9) {
            piVar19 = *ppiVar9 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar9 + 0xc) == 2) {
            piVar19 = *ppiVar9;
        } else {
            piVar19 = (int64_t *)0x0;
        }
        if (piVar19[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar19[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar3 = *piVar19;
        piVar19 = (int64_t *)piVar19[1];
        var_80h = iVar3;
        var_78h = (int64_t)piVar19;
        uVar21 = func_0x00018000b4d0(&var_70h, *(undefined8 *)(*(int64_t *)(iVar3 + 0x18) + 8));
        piVar11 = &var_70h;
        if (0xf < (uint64_t)var_58h) {
            piVar11 = (int64_t *)var_70h;
        }
        if (var_60h == 0xd) {
            iVar8 = func_0x000180497f30(piVar11, 0x180623b08);
            bVar20 = iVar8 == 0;
            uVar21 = extraout_XMM0_Da;
        } else {
            bVar20 = false;
        }
        puVar16 = auStack_b8;
        if (0xf < (uint64_t)var_58h) {
            uVar13 = var_70h;
            puVar16 = auStack_b8;
            if (0xfff < var_58h + 1U) {
                uVar13 = *(uint64_t *)(var_70h + -8);
                uVar17 = (var_70h - uVar13) - 8;
                puVar16 = auStack_b8;
                if (0x1f < uVar17) {
                    pcVar6 = (code *)swi(0x29);
                    (*pcVar6)(5);
                    uVar13 = uVar17;
                    puVar16 = auStack_b0;
                }
            }
            *(undefined8 *)(puVar16 + -8) = 0x18004d1e1;
            uVar21 = func_0x000180459c3c(uVar13);
        }
        unaff_RSI = (int64_t *)var_58h;
        if (!bVar20) goto code_r0x00018004d5d8;
        unaff_RSI = (int64_t *)0x180623ad8;
        *(undefined8 *)(puVar16 + -8) = 0x18004d1fe;
        iVar8 = func_0x000180085d50(arg1, 2);
        if (iVar8 == 0) {
            fVar22 = 0.0;
        } else {
            *(undefined8 *)(puVar16 + -8) = 0x18004d212;
            dVar7 = (double)func_0x000180085ea0(arg1, 2, 0);
            fVar22 = (float)dVar7;
        }
        ppiVar15 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x20);
        ppiVar9 = ppiVar15;
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar15) {
            ppiVar9 = *(int64_t ***)0x180782430;
        }
        if ((ppiVar9 != *(int64_t ***)0x180782430) && (*(int32_t *)((int64_t)ppiVar9 + 0xc) == 6)) {
            if (*(int64_t ***)(arg1 + 0x40) <= ppiVar15) {
                ppiVar15 = *(int64_t ***)0x180782430;
            }
            if (*(int32_t *)((int64_t)ppiVar15 + 0xc) != 6) {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                *(undefined8 *)(puVar16 + -8) = 0x18004d278;
                iVar8 = func_0x0001800a8360(arg1);
                if (iVar8 == 0) {
                    unaff_RSI = (int64_t *)0x0;
                    goto code_r0x00018004d2b4;
                }
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    *(undefined8 *)(puVar16 + -8) = 0x18004d299;
                    (**(code **)0x180782658)(arg1, 1);
                }
                ppiVar15 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x20);
                if (*(int64_t ***)(arg1 + 0x40) <= ppiVar15) {
                    ppiVar15 = *(int64_t ***)0x180782430;
                }
            }
            unaff_RSI = *ppiVar15 + 3;
        }
code_r0x00018004d2b4:
        iVar4 = *(int64_t *)(iVar3 + 0x18);
        *(int64_t **)(puVar16 + 0x30) = unaff_RSI;
        iVar10 = **(int64_t **)0x180782608;
        if (iVar10 == 0) {
            *(undefined8 *)(puVar16 + -8) = 0x18004d2d2;
            iVar10 = (**(code **)0x180782578)();
        }
        *(undefined8 *)(puVar16 + -8) = 0x18004d2e7;
        piVar11 = (int64_t *)(**(code **)0x180782660)(iVar10 + 0x50, puVar16 + 0x30);
        if (piVar11 == (int64_t *)0x0) {
            iVar10 = iVar10 + 0x80;
        } else {
            iVar10 = *piVar11;
        }
        *(int64_t *)(puVar16 + 0x48) = iVar10;
        piVar1 = (int32_t *)(iVar4 + 0x250);
        if (*piVar1 == 0) {
code_r0x00018004d5b0:
            *(undefined8 *)(puVar16 + -8) = 0x18004d5c2;
            func_0x000180088560(arg1, 0x180623ae8, unaff_RSI);
            goto code_r0x00018004d5c3;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18004d318;
        piVar11 = (int64_t *)(**(code **)0x180782580)(piVar1, puVar16 + 0x48);
        if ((piVar11 == (int64_t *)0x0) || (*piVar11 == 0)) goto code_r0x00018004d5b0;
        *(undefined8 *)(puVar16 + 0x20) = 0;
        *(undefined8 *)(puVar16 + -8) = 0x18004d349;
        func_0x0001800869f0(arg1, *(undefined8 *)0x180781ef8, 0, 0);
        *(undefined8 *)(puVar16 + -8) = 0x18004d35d;
        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
        *(undefined8 *)(puVar16 + -8) = 0x18004d372;
        func_0x0001800867f0(arg1, 0x1805aaf20, 10);
        *(undefined8 *)(puVar16 + -8) = 0x18004d385;
        iVar8 = func_0x0001800878a0(arg1, 2, 1);
        if (iVar8 != 0) goto code_r0x00018004d5f8;
        *(undefined8 *)(puVar16 + -8) = 0x18004d3a1;
        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
        *(undefined8 *)(puVar16 + -8) = 0x18004d3b6;
        func_0x0001800867f0(arg1, 0x18061fe68, 7);
        *(undefined8 *)(puVar16 + -8) = 0x18004d3c9;
        iVar8 = func_0x0001800878a0(arg1, 2, 1);
        if (iVar8 != 0) goto code_r0x00018004d5f8;
        *(undefined8 *)(puVar16 + 0x20) = 0;
        *(undefined8 *)(puVar16 + -8) = 0x18004d3ef;
        func_0x0001800869f0(arg1, *(undefined8 *)0x180781ef8, 0, 0);
        *(undefined8 *)(puVar16 + -8) = 0x18004d3fc;
        func_0x000180085bf0(arg1, 0xfffffffe);
        puVar14 = *(undefined4 **)(arg1 + 0x40);
        puVar12 = puVar14 + -8;
        if (puVar12 < puVar14) {
            do {
                puVar12[-4] = *puVar12;
                puVar12[-3] = puVar12[1];
                puVar12[-2] = puVar12[2];
                puVar12[-1] = puVar12[3];
                puVar12 = puVar12 + 4;
                puVar14 = *(undefined4 **)(arg1 + 0x40);
            } while (puVar12 < puVar14);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar14 + -4;
        *(undefined8 *)(puVar16 + -8) = 0x18004d441;
        func_0x0001800867f0(arg1, 0x180623b58, 0xb);
        *(undefined8 *)(puVar16 + -8) = 0x18004d454;
        iVar8 = func_0x0001800878a0(arg1, 2, 1);
        if (iVar8 != 0) goto code_r0x00018004d5f8;
        iVar4 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar4 + -4) == 9) {
            puVar18 = (undefined8 *)(*(int64_t *)(iVar4 + -0x10) + 0x10);
        } else if (*(int32_t *)(iVar4 + -4) == 2) {
            puVar18 = *(undefined8 **)(iVar4 + -0x10);
        } else {
            puVar18 = (undefined8 *)0x0;
        }
        if (puVar18[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(puVar18[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        uVar5 = *puVar18;
        *(undefined8 *)(puVar16 + 0x48) = uVar5;
        piVar11 = (int64_t *)puVar18[1];
        *(int64_t **)(puVar16 + 0x50) = piVar11;
        *(undefined8 *)(puVar16 + -8) = 0x18004d4ac;
        iVar8 = func_0x000180498f10(unaff_RSI, 0x180623ad8);
        if (iVar8 == 0) {
            *(undefined8 *)(puVar16 + -8) = 0x18004d4bf;
            (**(code **)0x180782650)(iVar3, fVar22, uVar5);
code_r0x00018004d52a:
            if (piVar11 != (int64_t *)0x0) {
                LOCK();
                piVar2 = piVar11 + 1;
                iVar8 = *(int32_t *)piVar2;
                *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    pcVar6 = *(code **)*piVar11;
                    *(undefined8 *)(puVar16 + -8) = 0x18004d548;
                    (*pcVar6)(piVar11);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar11 + 0xc);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        pcVar6 = *(code **)(*piVar11 + 8);
                        *(undefined8 *)(puVar16 + -8) = 0x18004d55d;
                        (*pcVar6)(piVar11);
                    }
                }
            }
            if (piVar19 != (int64_t *)0x0) {
                LOCK();
                piVar11 = piVar19 + 1;
                iVar8 = *(int32_t *)piVar11;
                *(int32_t *)piVar11 = *(int32_t *)piVar11 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    pcVar6 = *(code **)*piVar19;
                    *(undefined8 *)(puVar16 + -8) = 0x18004d578;
                    (*pcVar6)(piVar19);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar19 + 0xc);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        pcVar6 = *(code **)(*piVar19 + 8);
                        *(undefined8 *)(puVar16 + -8) = 0x18004d58c;
                        (*pcVar6)(piVar19);
                    }
                }
            }
            *(undefined8 *)(puVar16 + -8) = 0x18004d59b;
            func_0x000180459870(*(uint64_t *)(puVar16 + 0x68) ^ (uint64_t)puVar16);
            return;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18004d4d0;
        iVar8 = func_0x000180498f10(unaff_RSI, 0x180623b68);
        if (iVar8 == 0) {
            *(undefined8 *)(puVar16 + -8) = 0x18004d4e3;
            (**(code **)0x180782548)(iVar3, fVar22, uVar5);
            goto code_r0x00018004d52a;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18004d4f4;
        iVar8 = func_0x000180498f10(unaff_RSI, 0x180623b38);
        if (iVar8 == 0) {
            *(undefined8 *)(puVar16 + -8) = 0x18004d504;
            (**(code **)0x180782560)(iVar3, uVar5);
            goto code_r0x00018004d52a;
        }
        *(undefined8 *)(puVar16 + -8) = 0x18004d515;
        iVar8 = func_0x000180498f10(unaff_RSI, 0x180623b48);
        if (iVar8 == 0) {
            *(undefined8 *)(puVar16 + -8) = 0x18004d529;
            (**(code **)0x180782550)(iVar3, uVar5);
            goto code_r0x00018004d52a;
        }
    } else {
code_r0x00018004d5c3:
        *(undefined8 *)(puVar16 + -8) = 0x18004d5d7;
        uVar21 = func_0x000180088380(arg1, 1, 0x1806217c8);
code_r0x00018004d5d8:
        *(undefined8 *)(puVar16 + -8) = 0x18004d5e4;
        func_0x000180088560(uVar21, 0x180623b18);
    }
    *(undefined8 *)(puVar16 + -8) = 0x18004d5f7;
    func_0x000180088560(arg1, 0x180623ae8, unaff_RSI);
code_r0x00018004d5f8:
    *(undefined8 *)(puVar16 + -8) = 0x18004d600;
    func_0x000180087960(arg1);
    pcVar6 = (code *)swi(3);
    (*pcVar6)();
    return;
}

// ============================================================
// Function: FUN_18004d610
// Address: 0x18004d610
// Size: 425 bytes
// ============================================================
void fcn.18004d610(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t **ppiVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    undefined *puVar10;
    uint64_t uVar11;
    bool bVar12;
    undefined uStack_98;
    int64_t var_97h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    var_40h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&uStack_98;
    ppiVar8 = *(int64_t ***)(arg1 + 0x28);
    ppiVar5 = ppiVar8;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar8) {
        ppiVar5 = *(int64_t ***)0x180782430;
    }
    puVar10 = &uStack_98;
    if (((*(int32_t *)((int64_t)ppiVar5 + 0xc) == 9) &&
        (puVar10 = &uStack_98, *(uint8_t *)((int64_t)*ppiVar5 + 3) == *(uint32_t *)0x1807823dc)) &&
       (puVar10 = &uStack_98, *ppiVar5 != (int64_t *)0xfffffffffffffff0)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar8) {
            ppiVar8 = *(int64_t ***)0x180782430;
        }
        if (*(int32_t *)((int64_t)ppiVar8 + 0xc) == 9) {
            piVar9 = *ppiVar8 + 2;
        } else if (*(int32_t *)((int64_t)ppiVar8 + 0xc) == 2) {
            piVar9 = *ppiVar8;
        } else {
            piVar9 = (int64_t *)0x0;
        }
        if (piVar9[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar9[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar2 = *piVar9;
        piVar9 = (int64_t *)piVar9[1];
        var_70h = iVar2;
        var_68h = (int64_t)piVar9;
        func_0x00018000b4d0(&var_60h, *(undefined8 *)(*(int64_t *)(iVar2 + 0x18) + 8));
        piVar6 = &var_60h;
        if (0xf < (uint64_t)var_48h) {
            piVar6 = (int64_t *)var_60h;
        }
        if (var_50h == 0xf) {
            iVar4 = func_0x000180497f30(piVar6, 0x180623ba0);
            bVar12 = iVar4 == 0;
        } else {
            bVar12 = false;
        }
        puVar10 = &uStack_98;
        if (0xf < (uint64_t)var_48h) {
            uVar7 = var_60h;
            puVar10 = &uStack_98;
            if (0xfff < var_48h + 1U) {
                uVar7 = *(uint64_t *)(var_60h + -8);
                uVar11 = (var_60h - uVar7) - 8;
                puVar10 = &uStack_98;
                if (0x1f < uVar11) {
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    uVar7 = uVar11;
                    puVar10 = (undefined *)((int64_t)&var_97h + 7);
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18004d738;
            func_0x000180459c3c(uVar7);
        }
        if (bVar12) {
            *(undefined8 *)(puVar10 + -8) = 0x18004d746;
            (**(code **)0x180782590)(iVar2);
            if (piVar9 != (int64_t *)0x0) {
                LOCK();
                piVar6 = piVar9 + 1;
                iVar4 = *(int32_t *)piVar6;
                *(int32_t *)piVar6 = *(int32_t *)piVar6 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                    pcVar3 = *(code **)*piVar9;
                    *(undefined8 *)(puVar10 + -8) = 0x18004d765;
                    (*pcVar3)(piVar9);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar9 + 0xc);
                    iVar4 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar4 == 1) {
                        pcVar3 = *(code **)(*piVar9 + 8);
                        *(undefined8 *)(puVar10 + -8) = 0x18004d778;
                        (*pcVar3)(piVar9);
                    }
                }
            }
            *(undefined8 *)(puVar10 + -8) = 0x18004d787;
            func_0x000180459870(*(uint64_t *)(puVar10 + 0x58) ^ (uint64_t)puVar10);
            return;
        }
        *(undefined8 *)(puVar10 + -8) = 0x18004d7a3;
        func_0x000180088560(arg1, 0x180623bb0);
    }
    *(undefined8 *)(puVar10 + -8) = 0x18004d7b8;
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18004d7c0
// Address: 0x18004d7c0
// Size: 847 bytes
// ============================================================
undefined8 fcn.18004d7c0(int64_t arg1, int64_t arg_148h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    undefined8 uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    int64_t *piVar14;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    ppiVar9 = *(int64_t ***)(arg1 + 0x28);
    ppiVar10 = *(int64_t ***)(arg1 + 0x40);
    ppiVar8 = ppiVar9;
    if (ppiVar10 <= ppiVar9) {
        ppiVar8 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar8 + 0xc) == 9) &&
        (*(uint8_t *)((int64_t)*ppiVar8 + 3) == *(uint32_t *)0x1807823dc)) &&
       (*ppiVar8 != (int64_t *)0xfffffffffffffff0)) {
        ppiVar8 = ppiVar9 + 2;
        if (ppiVar10 <= ppiVar9 + 2) {
            ppiVar8 = *(int64_t ***)0x180782430;
        }
        if (((*(int32_t *)((int64_t)ppiVar8 + 0xc) == 9) &&
            (*(uint8_t *)((int64_t)*ppiVar8 + 3) == *(uint32_t *)0x1807823dc)) &&
           (*ppiVar8 != (int64_t *)0xfffffffffffffff0)) {
            ppiVar9 = ppiVar9 + 4;
            ppiVar8 = ppiVar9;
            if (ppiVar10 <= ppiVar9) {
                ppiVar8 = *(int64_t ***)0x180782430;
            }
            if ((ppiVar8 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar8 + 0xc) != 1)) {
                if (ppiVar10 <= ppiVar9) {
                    ppiVar9 = *(int64_t ***)0x180782430;
                }
                if ((ppiVar9 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar9 + 0xc) != 3)) {
                    func_0x0001800883d0(arg1, 3, 0x180623b78);
                    pcVar6 = (code *)swi(3);
                    uVar11 = (*pcVar6)();
                    return uVar11;
                }
                func_0x000180085f50(arg1, 3, 0);
            }
            piVar13 = (int64_t *)0x0;
            ppiVar9 = *(int64_t ***)(arg1 + 0x28);
            if (*(int64_t ***)(arg1 + 0x40) <= *(int64_t ***)(arg1 + 0x28)) {
                ppiVar9 = *(int64_t ***)0x180782430;
            }
            if (*(int32_t *)((int64_t)ppiVar9 + 0xc) == 9) {
                piVar14 = *ppiVar9 + 2;
            } else {
                piVar14 = piVar13;
                if (*(int32_t *)((int64_t)ppiVar9 + 0xc) == 2) {
                    piVar14 = *ppiVar9;
                }
            }
            if (piVar14[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(piVar14[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            ppiVar9 = *(int64_t ***)0x180782430;
            iVar3 = *piVar14;
            piVar14 = (int64_t *)piVar14[1];
            iVar4 = *(int64_t *)(iVar3 + 0x18);
joined_r0x00018004d91c:
            if (iVar4 != 0) {
                piVar12 = *(int64_t **)(iVar4 + 8);
                piVar2 = piVar12 + 2;
                if (0xf < (uint64_t)piVar12[3]) {
                    piVar12 = (int64_t *)*piVar12;
                }
                if ((*piVar2 != 8) || (iVar7 = func_0x000180497f30(piVar12, 0x180623b90, 8), iVar7 != 0))
                goto code_r0x00018004d95b;
                ppiVar10 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
                if (*(int64_t ***)(arg1 + 0x40) <= ppiVar10) {
                    ppiVar10 = ppiVar9;
                }
                if (*(int32_t *)((int64_t)ppiVar10 + 0xc) == 9) {
                    piVar13 = *ppiVar10 + 2;
                } else if (*(int32_t *)((int64_t)ppiVar10 + 0xc) == 2) {
                    piVar13 = *ppiVar10;
                }
                if (piVar13[1] != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(piVar13[1] + 8);
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                }
                iVar4 = *piVar13;
                piVar13 = (int64_t *)piVar13[1];
                for (iVar5 = *(int64_t *)(iVar4 + 0x18); iVar5 != 0; iVar5 = *(int64_t *)(iVar5 + 0x230)) {
                    piVar12 = *(int64_t **)(iVar5 + 8);
                    piVar2 = piVar12 + 2;
                    if (0xf < (uint64_t)piVar12[3]) {
                        piVar12 = (int64_t *)*piVar12;
                    }
                    if ((*piVar2 == 8) && (iVar7 = func_0x000180497f30(piVar12, 0x180623b90, 8), iVar7 == 0)) {
                        iVar3 = *(int64_t *)(iVar3 + 0x148);
                        if ((iVar3 != 0) && ((*(int64_t *)(iVar4 + 0x148) != 0 && (*(int64_t *)(iVar3 + 0x1f0) != 0))))
                        {
                            (**(code **)0x180782628)();
                        }
                        if (piVar13 != (int64_t *)0x0) {
                            LOCK();
                            piVar2 = piVar13 + 1;
                            iVar7 = *(int32_t *)piVar2;
                            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                            UNLOCK();
                            if (iVar7 == 1) {
                                (**(code **)*piVar13)(piVar13);
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar13 + 0xc);
                                iVar7 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar7 == 1) {
                                    (**(code **)(*piVar13 + 8))(piVar13);
                                }
                            }
                        }
                        if (piVar14 != (int64_t *)0x0) {
                            LOCK();
                            piVar13 = piVar14 + 1;
                            iVar7 = *(int32_t *)piVar13;
                            *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
                            UNLOCK();
                            if (iVar7 == 1) {
                                (**(code **)*piVar14)(piVar14);
                                LOCK();
                                piVar1 = (int32_t *)((int64_t)piVar14 + 0xc);
                                iVar7 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar7 == 1) {
                                    (**(code **)(*piVar14 + 8))(piVar14);
                                }
                            }
                        }
                        return 0;
                    }
                }
                goto code_r0x00018004dad0;
            }
            goto code_r0x00018004dabb;
        }
        func_0x000180088380(arg1, 2, 0x1806217c8);
code_r0x00018004dabb:
        func_0x000180088380(arg1, 1, 0x180623be8);
code_r0x00018004dad0:
        func_0x000180088380(arg1, 2, 0x180623be8);
    }
    func_0x000180088380(arg1, 1, 0x1806217c8);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
code_r0x00018004d95b:
    iVar4 = *(int64_t *)(iVar4 + 0x230);
    goto joined_r0x00018004d91c;
}

// ============================================================
// Function: FUN_18004db10
// Address: 0x18004db10
// Size: 1595 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18004db10(int64_t arg1, int64_t arg_38h, int64_t arg_50h)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    undefined4 *puVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    bool bVar10;
    int16_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t **ppiVar15;
    int64_t **ppiVar16;
    int64_t *piVar17;
    int64_t *piVar18;
    undefined8 *puVar19;
    undefined4 *puVar20;
    undefined8 uVar21;
    int64_t **ppiVar22;
    int64_t *piVar23;
    int64_t iVar24;
    int64_t iVar25;
    int64_t iVar26;
    bool bVar27;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    piVar18 = (int64_t *)0x0;
    bVar10 = false;
    ppiVar16 = *(int64_t ***)(arg1 + 0x28);
    ppiVar22 = *(int64_t ***)(arg1 + 0x40);
    ppiVar15 = ppiVar16;
    if (ppiVar22 <= ppiVar16) {
        ppiVar15 = *(int64_t ***)0x180782430;
    }
    if (((*(int32_t *)((int64_t)ppiVar15 + 0xc) != 9) ||
        (*(uint8_t *)((int64_t)*ppiVar15 + 3) != *(uint32_t *)0x1807823dc)) ||
       (*ppiVar15 == (int64_t *)0xfffffffffffffff0)) {
        func_0x000180088380(arg1, 1, 0x1806217c8);
code_r0x00018004e10b:
        func_0x000180099450(arg1, 0x18063d8d0);
        func_0x000180087960(arg1);
code_r0x00018004e123:
        func_0x000180099450(arg1, 0x18063d8d0);
        func_0x000180087960(arg1);
        pcVar7 = (code *)swi(3);
        uVar21 = (*pcVar7)();
        return uVar21;
    }
    ppiVar15 = ppiVar16 + 2;
    if (ppiVar22 <= ppiVar16 + 2) {
        ppiVar15 = *(int64_t ***)0x180782430;
    }
    if ((ppiVar15 == *(int64_t ***)0x180782430) || (*(int32_t *)((int64_t)ppiVar15 + 0xc) != 6)) {
        func_0x000180088470(arg1, 2, 6);
        pcVar7 = (code *)swi(3);
        uVar21 = (*pcVar7)();
        return uVar21;
    }
    if (ppiVar22 <= ppiVar16) {
        ppiVar16 = *(int64_t ***)0x180782430;
    }
    if (*(int32_t *)((int64_t)ppiVar16 + 0xc) == 9) {
        piVar23 = *ppiVar16 + 2;
    } else {
        piVar23 = piVar18;
        if (*(int32_t *)((int64_t)ppiVar16 + 0xc) == 2) {
            piVar23 = *ppiVar16;
        }
    }
    if (piVar23[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar23[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar3 = *piVar23;
    piVar23 = (int64_t *)piVar23[1];
    ppiVar16 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar16) {
        ppiVar16 = *(int64_t ***)0x180782430;
    }
    ppiVar22 = *(int64_t ***)0x180782430;
    if (*(int32_t *)((int64_t)ppiVar16 + 0xc) == 6) {
        piVar4 = *ppiVar16;
        iVar11 = *(int16_t *)((int64_t)piVar4 + 6);
        piVar17 = piVar4 + 3;
        if (iVar11 == -0x8000) {
            pcVar7 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x530);
            if (pcVar7 == (code *)0x0) {
                iVar11 = -1;
            } else {
                iVar11 = (*pcVar7)(arg1, piVar17, *(undefined4 *)((int64_t)piVar4 + 0x14));
            }
            ppiVar22 = *(int64_t ***)0x180782430;
            *(int16_t *)((int64_t)piVar4 + 6) = iVar11;
        }
    } else {
        iVar11 = 0;
        piVar17 = piVar18;
    }
    if (iVar11 < 0) {
code_r0x00018004e13b:
        func_0x000180088560(arg1, 0x180623c00);
        pcVar7 = (code *)swi(3);
        uVar21 = (*pcVar7)();
        return uVar21;
    }
    ppiVar16 = (int64_t **)(*(int64_t *)(arg1 + 0x28) + 0x20);
    ppiVar15 = ppiVar16;
    if (*(int64_t ***)(arg1 + 0x40) <= ppiVar16) {
        ppiVar15 = ppiVar22;
    }
    if ((ppiVar15 != ppiVar22) && (*(int32_t *)((int64_t)ppiVar15 + 0xc) == 1)) {
        if (*(int64_t ***)(arg1 + 0x40) <= ppiVar16) {
            ppiVar16 = ppiVar22;
        }
        if ((*(int32_t *)((int64_t)ppiVar16 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)ppiVar16 + 0xc) != 1 || (*(int32_t *)ppiVar16 != 0)))) {
            bVar10 = true;
        }
    }
    iVar26 = *(int64_t *)(iVar3 + 0x18);
    var_18h = **(int64_t **)0x180782608;
    var_10h = (int64_t)piVar17;
    if (var_18h == 0) {
        var_18h = (**(code **)0x180782578)();
    }
    piVar17 = (int64_t *)(**(code **)0x180782660)(var_18h + 0x50, &var_10h);
    if (piVar17 == (int64_t *)0x0) {
        var_18h = var_18h + 0x80;
    } else {
        var_18h = *piVar17;
    }
    piVar1 = (int32_t *)(iVar26 + 0x250);
    if ((((*piVar1 == 0) || (piVar17 = (int64_t *)(**(code **)0x180782580)(piVar1, &var_18h), piVar17 == (int64_t *)0x0)
         ) || (*(int32_t *)(piVar17 + 1) != 4)) || (iVar26 = *piVar17, iVar26 == 0)) goto code_r0x00018004e13b;
    if (*(char *)(iVar26 + 0x70) != '\0') {
        iVar24 = *(int64_t *)(iVar26 + 0x80) + iVar3;
        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
        iVar26 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar26 + -4) == 9) {
            piVar18 = (int64_t *)(*(int64_t *)(iVar26 + -0x10) + 0x10);
        } else if (*(int32_t *)(iVar26 + -4) == 2) {
            piVar18 = *(int64_t **)(iVar26 + -0x10);
        }
        if (piVar18[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar18[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        piVar17 = (int64_t *)piVar18[1];
        if (iVar3 == *piVar18) {
            iVar24 = iVar24 + -0x1c8;
        }
        if (piVar17 != (int64_t *)0x0) {
            LOCK();
            piVar18 = piVar17 + 1;
            iVar12 = *(int32_t *)piVar18;
            *(int32_t *)piVar18 = *(int32_t *)piVar18 + -1;
            UNLOCK();
            if (iVar12 == 1) {
                (**(code **)*piVar17)(piVar17);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar17 + 0xc);
                iVar12 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar12 == 1) {
                    (**(code **)(*piVar17 + 8))(piVar17);
                }
            }
        }
        uVar5 = *(uint64_t *)(arg1 + 0x40);
        *(uint64_t *)(arg1 + 0x40) = uVar5 - 0x10;
        if (*(int64_t *)(iVar24 + 0x38) == 0) {
            if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < uVar5)) &&
               (iVar12 = func_0x000180085510(arg1, 1), iVar12 == 0)) goto code_r0x00018004e123;
            *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            goto code_r0x00018004de2a;
        }
        if (((*(int64_t *)(iVar24 + 0x18) != 0) &&
            (iVar3 = *(int64_t *)(*(int64_t *)(iVar24 + 0x18) + 0x38), iVar3 != 0)) && (iVar3 != -8)) {
            iVar12 = 8;
            if (bVar10) {
                iVar12 = 0xe;
            }
            iVar26 = *(int64_t *)(iVar3 + 0x20);
            if ((iVar26 == 0) || (*(int32_t *)(iVar26 + 8) == 0)) {
                iVar24 = 0;
                piVar18 = (int64_t *)((uint64_t)var_8h._4_4_ << 0x20);
                iVar26 = iVar24;
            } else {
                iVar25 = 0;
                piVar18 = (int64_t *)0x0;
                iVar14 = *(int32_t *)(iVar26 + 8);
                if (iVar14 == 0) {
code_r0x00018004deb6:
                    iVar24 = 1;
                    iVar26 = *(int64_t *)(iVar25 + 0x28);
                } else {
                    do {
                        LOCK();
                        iVar13 = *(int32_t *)(iVar26 + 8);
                        bVar27 = iVar14 == iVar13;
                        if (bVar27) {
                            *(int32_t *)(iVar26 + 8) = iVar14 + 1;
                            iVar13 = iVar14;
                        }
                        iVar14 = iVar13;
                        UNLOCK();
                        if (bVar27) {
                            iVar25 = *(int64_t *)(iVar3 + 0x18);
                            piVar18 = *(int64_t **)(iVar3 + 0x20);
                            goto code_r0x00018004deb6;
                        }
                    } while (iVar14 != 0);
                    iVar24 = 1;
                    iVar26 = *(int64_t *)0x28;
                }
            }
            if ((iVar24 != 0) && (piVar18 != (int64_t *)0x0)) {
                LOCK();
                piVar17 = piVar18 + 1;
                iVar14 = *(int32_t *)piVar17;
                *(int32_t *)piVar17 = *(int32_t *)piVar17 + -1;
                UNLOCK();
                if (iVar14 == 1) {
                    (**(code **)*piVar18)(piVar18);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar18 + 0xc);
                    iVar14 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar14 == 1) {
                        (**(code **)(*piVar18 + 8))(piVar18);
                    }
                }
            }
            if (iVar26 == 0) {
                if (bVar10) {
                    if (((*(char *)0x180777010 != '\0') &&
                        (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
                       (iVar12 = func_0x000180085510(arg1, 1), iVar12 == 0)) goto code_r0x00018004e123;
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    goto code_r0x00018004e099;
                }
            } else if (*(int64_t *)(*(int64_t *)(iVar26 + 0x20) + 0x1d8) ==
                       *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x1d8)) {
                var_58h = 0;
                iVar26 = *(int64_t *)(iVar3 + 0x20);
                var_50h = 0;
                if (iVar26 != 0) {
                    iVar14 = *(int32_t *)(iVar26 + 8);
                    do {
                        if (iVar14 == 0) goto code_r0x00018004df58;
                        LOCK();
                        iVar13 = *(int32_t *)(iVar26 + 8);
                        bVar27 = iVar14 == iVar13;
                        if (bVar27) {
                            *(int32_t *)(iVar26 + 8) = iVar14 + 1;
                            iVar13 = iVar14;
                        }
                        UNLOCK();
                        iVar14 = iVar13;
                    } while (!bVar27);
                    var_50h = *(int64_t *)(iVar3 + 0x20);
                    var_58h = SUB168(*(undefined (*) [16])(iVar3 + 0x18), 0);
                }
code_r0x00018004df58:
                uVar2 = *(undefined4 *)(var_58h + 0x34);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar14 = func_0x000180085510(arg1, 1), iVar14 != 0)) {
                    puVar19 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
                    puVar20 = (undefined4 *)func_0x0001800a0d50(*puVar19, uVar2);
                    puVar6 = *(undefined4 **)(arg1 + 0x40);
                    uVar2 = puVar20[1];
                    uVar8 = puVar20[2];
                    uVar9 = puVar20[3];
                    *puVar6 = *puVar20;
                    puVar6[1] = uVar2;
                    puVar6[2] = uVar8;
                    puVar6[3] = uVar9;
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                    if ((int64_t *)var_50h != (int64_t *)0x0) {
                        LOCK();
                        piVar18 = (int64_t *)(var_50h + 8);
                        iVar14 = *(int32_t *)piVar18;
                        *(int32_t *)piVar18 = *(int32_t *)piVar18 + -1;
                        UNLOCK();
                        if (iVar14 == 1) {
                            (***(code ***)var_50h)(var_50h);
                            LOCK();
                            piVar1 = (int32_t *)(var_50h + 0xc);
                            iVar14 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar14 == 1) {
                                (**(code **)(*(int64_t *)var_50h + 8))(var_50h);
                            }
                        }
                    }
                    if (!bVar10) {
                        ppiVar16 = (int64_t **)(*(int64_t *)(arg1 + 0x40) - 0x10);
                        iVar14 = -1;
                        if (ppiVar16 != *(int64_t ***)0x180782430) {
                            iVar14 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
                        }
                        if (iVar14 != iVar12) {
                            *(int64_t ***)(arg1 + 0x40) = ppiVar16;
                            func_0x000180086510(arg1);
                        }
                    }
                    goto code_r0x00018004e099;
                }
                goto code_r0x00018004e10b;
            }
            func_0x000180086510(arg1);
code_r0x00018004e099:
            if (piVar23 == (int64_t *)0x0) {
                return 1;
            }
            LOCK();
            piVar18 = piVar23 + 1;
            iVar12 = *(int32_t *)piVar18;
            *(int32_t *)piVar18 = *(int32_t *)piVar18 + -1;
            UNLOCK();
            if (iVar12 != 1) {
                return 1;
            }
            (**(code **)*piVar23)(piVar23);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar23 + 0xc);
            iVar12 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar12 != 1) {
                return 1;
            }
            (**(code **)(*piVar23 + 8))(piVar23);
            return 1;
        }
    }
    func_0x000180086510(arg1);
code_r0x00018004de2a:
    if (piVar23 != (int64_t *)0x0) {
        LOCK();
        piVar18 = piVar23 + 1;
        iVar12 = *(int32_t *)piVar18;
        *(int32_t *)piVar18 = *(int32_t *)piVar18 + -1;
        UNLOCK();
        if (iVar12 == 1) {
            (**(code **)*piVar23)(piVar23);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar23 + 0xc);
            iVar12 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar12 == 1) {
                (**(code **)(*piVar23 + 8))(piVar23);
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_18004e150
// Address: 0x18004e150
// Size: 650 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h

undefined8 fcn.18004e150(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t *piVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_40h._4_4_ = (undefined4)((uint64_t)var_48h >> 0x20);
    if ((*(int64_t **)0x180782128 != (int64_t *)0x0) && (*(int32_t *)(*(int64_t **)0x180782128 + 1) != 0)) {
code_r0x00018004e38c:
        pcVar4 = *(code **)0x180782630;
        if (*(int64_t **)0x180782128 != (int64_t *)0x0) {
            LOCK();
            *(int32_t *)(*(int64_t **)0x180782128 + 1) = *(int32_t *)(*(int64_t **)0x180782128 + 1) + 1;
            UNLOCK();
        }
        var_40h._0_4_ = *(undefined4 *)0x180782128;
        var_48h = *(int64_t *)0x180782120;
        var_40h._4_4_ = *(undefined4 *)0x18078212c;
        (*pcVar4)(arg1, &var_48h);
        return 1;
    }
    func_0x0001800869f0(arg1, *(undefined8 *)0x1807823f0, 0, 0, 0);
    func_0x0001800867f0(arg1, 0x180623bd0, 9);
    func_0x0001800878a0(arg1, 1, 1);
    iVar3 = *(int64_t *)(arg1 + 0x40);
    if (*(int32_t *)(iVar3 + -4) == 9) {
        piVar8 = (int64_t *)(*(int64_t *)(iVar3 + -0x10) + 0x10);
    } else if (*(int32_t *)(iVar3 + -4) == 2) {
        piVar8 = *(int64_t **)(iVar3 + -0x10);
    } else {
        piVar8 = (int64_t *)0x0;
    }
    if (piVar8[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar8[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar3 = *piVar8;
    piVar8 = (int64_t *)piVar8[1];
    var_38h = iVar3;
    var_30h = (int64_t)piVar8;
    (**(code **)0x180782618)(arg1, 0xffffffff);
    func_0x0001800869f0(arg1, *(undefined8 *)0x180781ef8, 0, 0, 0);
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
    func_0x0001800867f0(arg1, 0x1805aaf20, 10);
    var_48h = *(int64_t *)(arg1 + 0x40) + -0x30;
    var_40h._0_4_ = 1;
    iVar6 = func_0x000180094080(arg1, 0x180087890, &var_48h, var_48h - *(int64_t *)(arg1 + 0x38), 0);
    if (iVar6 == 0) {
        func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
        func_0x0001800867f0(arg1, 0x180620c60, 7);
        iVar6 = func_0x0001800878a0(arg1, 2, 1);
        if (iVar6 == 0) {
            func_0x000180087370(arg1, 0xfffffffe, 0x180623bdc);
            func_0x0001800867f0(arg1, 0x180623c30, 8);
            func_0x000180087370(arg1, 0xfffffffe, 0x180622ff4);
            func_0x0001800858c0(arg1, 0);
            if (piVar8 != (int64_t *)0x0) {
                LOCK();
                *(int32_t *)(piVar8 + 1) = *(int32_t *)(piVar8 + 1) + 1;
                UNLOCK();
            }
            piVar2 = *(int64_t **)0x180782128;
            *(int64_t *)0x180782120 = iVar3;
            piVar5 = piVar8;
            if (*(int64_t **)0x180782128 != (int64_t *)0x0) {
                LOCK();
                piVar5 = *(int64_t **)0x180782128 + 1;
                iVar6 = *(int32_t *)piVar5;
                *(int64_t **)0x180782128 = piVar8;
                *(int32_t *)piVar5 = *(int32_t *)piVar5 + -1;
                UNLOCK();
                piVar5 = *(int64_t **)0x180782128;
                if (iVar6 == 1) {
                    (**(code **)*piVar2)(piVar2);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar2 + 0xc);
                    iVar6 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    piVar5 = *(int64_t **)0x180782128;
                    if (iVar6 == 1) {
                        (**(code **)(*piVar2 + 8))(piVar2);
                        piVar5 = *(int64_t **)0x180782128;
                    }
                }
            }
            *(int64_t **)0x180782128 = piVar5;
            if (piVar8 != (int64_t *)0x0) {
                LOCK();
                piVar2 = piVar8 + 1;
                iVar6 = *(int32_t *)piVar2;
                *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                UNLOCK();
                if (iVar6 == 1) {
                    (**(code **)*piVar8)(piVar8);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
                    iVar6 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar6 == 1) {
                        (**(code **)(*piVar8 + 8))(piVar8);
                    }
                }
            }
            goto code_r0x00018004e38c;
        }
    }
    func_0x000180087960(arg1);
    pcVar4 = (code *)swi(3);
    uVar7 = (*pcVar4)();
    return uVar7;
}

// ============================================================
// Function: FUN_18004e3e0
// Address: 0x18004e3e0
// Size: 371 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004e3e0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar13 = 1;
    func_0x000180086fd0(arg1, 0, 0);
    func_0x000180086ba0(arg1, *(undefined8 *)0x180782630, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar9 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
    iVar2 = *(int64_t *)(arg1 + 0x40);
    puVar10 = (undefined4 *)func_0x0001800a0ea0(*puVar9, iVar2 + -0x10);
    uVar5 = puVar10[1];
    uVar6 = puVar10[2];
    uVar7 = puVar10[3];
    *(undefined4 *)(iVar2 + -0x10) = *puVar10;
    *(undefined4 *)(iVar2 + -0xc) = uVar5;
    *(undefined4 *)(iVar2 + -8) = uVar6;
    *(undefined4 *)(iVar2 + -4) = uVar7;
    func_0x000180086510(arg1);
    iVar8 = func_0x000180087970(arg1, 0xfffffffe);
    do {
        if (iVar8 == 0) {
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 1;
        }
        iVar2 = *(int64_t *)(arg1 + 0x40);
        piVar1 = (int64_t *)(iVar2 + -0x10);
        if (*(int32_t *)(iVar2 + -4) == 9) {
            uVar12 = (uint32_t)*(uint8_t *)(*piVar1 + 3);
        } else {
            uVar12 = 0xffffffff;
        }
        if (uVar12 == *(uint32_t *)0x1807823dc) {
            if (*(char *)(*(int64_t *)(iVar2 + -0x40) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar4 = (code *)swi(3);
                uVar11 = (*pcVar4)();
                return uVar11;
            }
            puVar10 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar2 + -0x40), iVar13);
            uVar5 = *(undefined4 *)(iVar2 + -0xc);
            uVar6 = *(undefined4 *)(iVar2 + -8);
            uVar7 = *(undefined4 *)(iVar2 + -4);
            *puVar10 = *(undefined4 *)piVar1;
            puVar10[1] = uVar5;
            puVar10[2] = uVar6;
            puVar10[3] = uVar7;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar2 = *(int64_t *)(iVar2 + -0x40);
                if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar3 + 0x59) == '\x02') {
                        func_0x000180094420();
                        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                        iVar13 = iVar13 + 1;
                        goto code_r0x00018004e519;
                    }
                    *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                    *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar2;
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            iVar13 = iVar13 + 1;
        } else {
            *(int64_t **)(arg1 + 0x40) = piVar1;
        }
code_r0x00018004e519:
        iVar8 = func_0x000180087970(arg1, 0xfffffffe);
    } while( true );
}

// ============================================================
// Function: FUN_18004e560
// Address: 0x18004e560
// Size: 481 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004e560(int64_t arg1)
{
    int64_t **ppiVar1;
    int32_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    undefined4 *puVar13;
    int64_t *piVar14;
    undefined8 uVar15;
    int32_t iVar16;
    uint32_t uVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    func_0x000180086fd0(arg1, 0, 0);
    func_0x000180086ba0(arg1, *(undefined8 *)0x180782630, 0);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar12 = (undefined8 *)func_0x000180085370(arg1, 0xffffd8f0);
    iVar3 = *(int64_t *)(arg1 + 0x40);
    puVar13 = (undefined4 *)func_0x0001800a0ea0(*puVar12, iVar3 + -0x10);
    uVar7 = puVar13[1];
    uVar8 = puVar13[2];
    uVar9 = puVar13[3];
    *(undefined4 *)(iVar3 + -0x10) = *puVar13;
    *(undefined4 *)(iVar3 + -0xc) = uVar7;
    *(undefined4 *)(iVar3 + -8) = uVar8;
    *(undefined4 *)(iVar3 + -4) = uVar9;
    func_0x000180086510(arg1);
    iVar11 = func_0x000180087970(arg1, 0xfffffffe);
    iVar10 = 1;
    do {
        if (iVar11 == 0) {
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            return 1;
        }
        iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4);
        ppiVar1 = (int64_t **)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if (iVar11 == 9) {
            uVar17 = (uint32_t)*(uint8_t *)((int64_t)*ppiVar1 + 3);
        } else {
            uVar17 = 0xffffffff;
        }
        iVar16 = iVar10;
        if (uVar17 == *(uint32_t *)0x1807823dc) {
            if (iVar11 == 9) {
                piVar14 = *ppiVar1 + 2;
            } else if (iVar11 == 2) {
                piVar14 = *ppiVar1;
            } else {
                piVar14 = (int64_t *)0x0;
            }
            if (piVar14[1] != 0) {
                LOCK();
                piVar2 = (int32_t *)(piVar14[1] + 8);
                *piVar2 = *piVar2 + 1;
                UNLOCK();
            }
            piVar4 = (int64_t *)piVar14[1];
            iVar3 = *(int64_t *)(*piVar14 + 0x70);
            if (piVar4 != (int64_t *)0x0) {
                LOCK();
                piVar14 = piVar4 + 1;
                iVar11 = *(int32_t *)piVar14;
                *(int32_t *)piVar14 = *(int32_t *)piVar14 + -1;
                UNLOCK();
                if (iVar11 == 1) {
                    (**(code **)*piVar4)(piVar4);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                    iVar11 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar11 == 1) {
                        (**(code **)(*piVar4 + 8))(piVar4);
                    }
                }
            }
            if (iVar3 == 0) {
                iVar3 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar3 + -0x40) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar6 = (code *)swi(3);
                    uVar15 = (*pcVar6)();
                    return uVar15;
                }
                iVar16 = iVar10 + 1;
                puVar13 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar3 + -0x40), iVar10);
                uVar7 = *(undefined4 *)(iVar3 + -0xc);
                uVar8 = *(undefined4 *)(iVar3 + -8);
                uVar9 = *(undefined4 *)(iVar3 + -4);
                *puVar13 = *(undefined4 *)(iVar3 + -0x10);
                puVar13[1] = uVar7;
                puVar13[2] = uVar8;
                puVar13[3] = uVar9;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar3 = *(int64_t *)(iVar3 + -0x40);
                    if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar5 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar5 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                            *(int64_t *)(iVar5 + 0x18) = iVar3;
                        }
                    }
                }
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar11 = func_0x000180087970(arg1, 0xfffffffe);
        iVar10 = iVar16;
    } while( true );
}

// ============================================================
// Function: FUN_18004e750
// Address: 0x18004e750
// Size: 629 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: [rz-ghidra] Removing arg arg_250h because it doesn't fit into ProtoModel

void fcn.18004e750(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    func_0x000180018f70();
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.18004d0b0, 0x180623c18, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623c18);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.18004d610, 0x180623c68, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623c68);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.18004e3e0, 0x180623c80, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623c80);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.18004e560, 0x180623c40, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623c40);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    func_0x0001800869f0(arg2, fcn.18004d7c0, 0x180623c50, 0, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180623c50);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_38h = 0x180623ca8;
    func_0x0001800869f0(arg2, fcn.18004db10, 0x180623cc0, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180623cc0);
    piVar4 = &var_38h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180623cc0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_30h);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_30h = 0x180623c90;
    func_0x0001800869f0(arg2, fcn.18004e150, 0x180623ca0, 0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180623ca0);
    piVar4 = &var_30h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180623ca0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_28h);
    return;
}

// ============================================================
// Function: FUN_18004e9d0
// Address: 0x18004e9d0
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004e9d0(int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)0x180782128;
    *(undefined8 *)0x180782120 = 0;
    *(undefined8 *)0x180782128 = (int64_t *)0x0;
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004e9f2
// Address: 0x18004e9f2
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004e9d0(int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)0x180782128;
    *(undefined8 *)0x180782120 = 0;
    *(undefined8 *)0x180782128 = (int64_t *)0x0;
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004ea28
// Address: 0x18004ea28
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004e9d0(int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)0x180782128;
    *(undefined8 *)0x180782120 = 0;
    *(undefined8 *)0x180782128 = (int64_t *)0x0;
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004ea30
// Address: 0x18004ea30
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004ea30(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    if (*(uint64_t *)0x18077af38 < 0x10) {
        iVar2 = 0x18077af20;
    } else {
        iVar2 = *(int64_t *)0x18077af20;
        if (*(int64_t *)0x18077af20 == 0) {
            func_0x000180086510();
            goto code_r0x00018004ea77;
        }
    }
    uVar1 = func_0x000180498cd0(iVar2);
    func_0x0001800867f0(arg1, iVar2, uVar1);
code_r0x00018004ea77:
    if (*(uint64_t *)0x18077af18 < 0x10) {
        iVar2 = 0x18077af00;
    } else {
        iVar2 = *(int64_t *)0x18077af00;
        if (*(int64_t *)0x18077af00 == 0) {
            func_0x000180086510(arg1);
            return 2;
        }
    }
    uVar1 = func_0x000180498cd0(iVar2);
    func_0x0001800867f0(arg1, iVar2, uVar1);
    return 2;
}

// ============================================================
// Function: FUN_18004eae0
// Address: 0x18004eae0
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004eae0(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    
    piVar1 = (int64_t *)func_0x0001800829e0();
    puVar3 = (undefined8 *)*piVar1;
    if (0xf < (uint64_t)puVar3[3]) {
        puVar3 = (undefined8 *)*puVar3;
    }
    if (puVar3 == (undefined8 *)0x0) {
        func_0x000180086510(arg1);
        return 1;
    }
    uVar2 = func_0x000180498cd0(puVar3);
    func_0x0001800867f0(arg1, puVar3, uVar2);
    return 1;
}

// ============================================================
// Function: FUN_18004eb50
// Address: 0x18004eb50
// Size: 1003 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_f8h
// WARNING: Variable defined which should be unmapped: var_f0h
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Removing unreachable block (ram,0x00018004edbf)
// WARNING: Removing unreachable block (ram,0x00018004eddd)
// WARNING: Removing unreachable block (ram,0x00018004ee04)
// WARNING: Removing unreachable block (ram,0x00018004ee16)
// WARNING: Removing unreachable block (ram,0x00018004ee24)
// WARNING: Removing unreachable block (ram,0x00018004ee2e)
// WARNING: Removing unreachable block (ram,0x00018004ee39)
// WARNING: Removing unreachable block (ram,0x00018004ee42)
// WARNING: Removing unreachable block (ram,0x00018004ee51)
// WARNING: Removing unreachable block (ram,0x00018004ee68)
// WARNING: Removing unreachable block (ram,0x00018004ee71)
// WARNING: Removing unreachable block (ram,0x00018004ee7f)
// WARNING: Removing unreachable block (ram,0x00018004ee94)
// WARNING: Removing unreachable block (ram,0x00018004eea3)
// WARNING: Removing unreachable block (ram,0x00018004eeba)
// WARNING: Removing unreachable block (ram,0x00018004eec3)
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

undefined8 fcn.18004eb50(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    piVar9 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018004eefd;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar9 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar9 = *(int64_t **)0x180782430;
        }
    }
    iVar7 = *piVar9;
    if (iVar7 + 0x18 != 0) {
        piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
            piVar9 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar9 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar4 = func_0x0001800a8360(arg1);
            if (iVar4 == 0) goto code_r0x00018004ef11;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar9) {
                piVar9 = *(int64_t **)0x180782430;
            }
        }
        iVar1 = *piVar9;
        if (iVar1 + 0x18 == 0) {
code_r0x00018004ef11:
            func_0x000180088470(arg1, 2, 6);
            func_0x00018045f7d4();
            func_0x000180093000(arg1, 0x18063e070);
            pcVar3 = (code *)swi(3);
            uVar8 = (*pcVar3)();
            return uVar8;
        }
        uVar5 = fcn.180088860(arg1, 3);
        func_0x0001800205e0(&var_88h, arg1);
        piVar9 = (int64_t *)fcn.180008740();
        iVar2 = *(int64_t *)(*piVar9 + 0x18);
        func_0x0001800137d0();
        if (var_80h != 0) {
            LOCK();
            *(int32_t *)(var_80h + 8) = *(int32_t *)(var_80h + 8) + 1;
            UNLOCK();
        }
        var_98h = var_88h;
        var_90h = var_80h;
        var_b8h = iVar2;
        var_b0h = iVar7 + 0x18;
        var_a8h = iVar1 + 0x18;
        var_a0h._0_4_ = uVar5;
        iVar6 = func_0x00018045838c();
        uVar5 = (undefined4)var_a0h;
        iVar2 = var_a8h;
        iVar1 = var_b0h;
        iVar7 = var_b8h;
        var_78h = var_b8h;
        var_70h = var_b0h;
        var_68h = var_a8h;
        var_60h._0_4_ = (undefined4)var_a0h;
        if (var_90h != 0) {
            LOCK();
            *(int32_t *)(var_90h + 8) = *(int32_t *)(var_90h + 8) + 1;
            UNLOCK();
        }
        var_48h = iVar6;
        var_d8h = fcn.180459890();
        *(undefined4 *)var_d8h = 1;
        *(undefined4 *)(var_d8h + 4) = 2;
        *(undefined8 *)(var_d8h + 8) = 0;
        *(undefined8 *)(var_d8h + 0x10) = 0;
        *(undefined4 *)(var_d8h + 0x18) = 0;
        piVar9 = (int64_t *)fcn.180459890(0x38);
        *piVar9 = iVar7;
        piVar9[1] = iVar1;
        piVar9[2] = iVar2;
        *(undefined4 *)(piVar9 + 3) = uVar5;
        piVar9[4] = var_98h;
        piVar9[5] = var_90h;
        _var_58h = ZEXT816(0);
        piVar9[6] = iVar6;
        iVar7 = func_0x00018045f6e8(0, 0, 0x180050f90, piVar9, 0, &var_e0h, ZEXT816(0));
        if (iVar7 != 0) {
            func_0x0001804542e8(1);
        }
        func_0x0001804542e8(6);
    }
code_r0x00018004eefd:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    uVar8 = (*pcVar3)();
    return uVar8;
}

// ============================================================
// Function: FUN_18004ef40
// Address: 0x18004ef40
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004ef40(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004ef4f
// Address: 0x18004ef4f
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004ef40(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004ef85
// Address: 0x18004ef85
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18004ef40(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18004ef90
// Address: 0x18004ef90
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004ef90(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        func_0x000180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar6 = (*pcVar2)();
        return uVar6;
    }
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        return 0;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        return 0;
    }
    if (piVar1 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) {
            iVar10 = 0;
            uVar9 = 0;
            goto code_r0x00018004f056;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar8 + 0x14);
    iVar10 = *piVar8 + 0x18;
code_r0x00018004f056:
    iVar3 = (*(code *)0x69a498)(0);
    if (iVar3 == 0) {
        return 0;
    }
    (*(code *)0x69a474)();
    iVar4 = (*(code *)0x699da0)(2, uVar9 + 1);
    if ((iVar4 != 0) && (iVar5 = (*(code *)0x699dae)(iVar4), iVar5 != 0)) {
        func_0x000180498030(iVar5, iVar10, uVar9 + 1);
        (*(code *)0x699dbc)(iVar4);
        (*(code *)0x69a460)(1, iVar4);
    }
    (*(code *)0x69a486)();
    return 0;
}

// ============================================================
// Function: FUN_18004efc8
// Address: 0x18004efc8
// Size: 266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004ef90(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        func_0x000180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar6 = (*pcVar2)();
        return uVar6;
    }
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        return 0;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        return 0;
    }
    if (piVar1 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) {
            iVar10 = 0;
            uVar9 = 0;
            goto code_r0x00018004f056;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar8 + 0x14);
    iVar10 = *piVar8 + 0x18;
code_r0x00018004f056:
    iVar3 = (*(code *)0x69a498)(0);
    if (iVar3 == 0) {
        return 0;
    }
    (*(code *)0x69a474)();
    iVar4 = (*(code *)0x699da0)(2, uVar9 + 1);
    if ((iVar4 != 0) && (iVar5 = (*(code *)0x699dae)(iVar4), iVar5 != 0)) {
        func_0x000180498030(iVar5, iVar10, uVar9 + 1);
        (*(code *)0x699dbc)(iVar4);
        (*(code *)0x69a460)(1, iVar4);
    }
    (*(code *)0x69a486)();
    return 0;
}

// ============================================================
// Function: FUN_18004f0d2
// Address: 0x18004f0d2
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004ef90(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        func_0x000180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar6 = (*pcVar2)();
        return uVar6;
    }
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        return 0;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        return 0;
    }
    if (piVar1 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) {
            iVar10 = 0;
            uVar9 = 0;
            goto code_r0x00018004f056;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar8 + 0x14);
    iVar10 = *piVar8 + 0x18;
code_r0x00018004f056:
    iVar3 = (*(code *)0x69a498)(0);
    if (iVar3 == 0) {
        return 0;
    }
    (*(code *)0x69a474)();
    iVar4 = (*(code *)0x699da0)(2, uVar9 + 1);
    if ((iVar4 != 0) && (iVar5 = (*(code *)0x699dae)(iVar4), iVar5 != 0)) {
        func_0x000180498030(iVar5, iVar10, uVar9 + 1);
        (*(code *)0x699dbc)(iVar4);
        (*(code *)0x69a460)(1, iVar4);
    }
    (*(code *)0x69a486)();
    return 0;
}

// ============================================================
// Function: FUN_18004f0df
// Address: 0x18004f0df
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18004ef90(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) == -1)) {
        func_0x000180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar6 = (*pcVar2)();
        return uVar6;
    }
    piVar7 = piVar8;
    if (piVar1 <= piVar8) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (piVar7 == *(int64_t **)0x180782430) {
        return 0;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        return 0;
    }
    if (piVar1 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) {
            iVar10 = 0;
            uVar9 = 0;
            goto code_r0x00018004f056;
        }
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    uVar9 = (uint64_t)*(uint32_t *)(*piVar8 + 0x14);
    iVar10 = *piVar8 + 0x18;
code_r0x00018004f056:
    iVar3 = (*(code *)0x69a498)(0);
    if (iVar3 == 0) {
        return 0;
    }
    (*(code *)0x69a474)();
    iVar4 = (*(code *)0x699da0)(2, uVar9 + 1);
    if ((iVar4 != 0) && (iVar5 = (*(code *)0x699dae)(iVar4), iVar5 != 0)) {
        func_0x000180498030(iVar5, iVar10, uVar9 + 1);
        (*(code *)0x699dbc)(iVar4);
        (*(code *)0x69a460)(1, iVar4);
    }
    (*(code *)0x69a486)();
    return 0;
}

// ============================================================
// Function: FUN_18004f100
// Address: 0x18004f100
// Size: 79 bytes
// ============================================================
undefined8 fcn.18004f100(void)
{
    double dVar1;
    
    dVar1 = *(double *)(**(int64_t **)0x1807825a8 + 0xb0);
    if (0.0 < dVar1) {
        dVar1 = 1.0 / dVar1;
        fcn.1800865e0(dVar1, CONCAT44((int32_t)((uint64_t)**(int64_t **)0x1807825a8 >> 0x20), (int32_t)dVar1));
        return 1;
    }
    fcn.1800865e0(0, 0);
    return 1;
}

// ============================================================
// Function: FUN_18004f150
// Address: 0x18004f150
// Size: 111 bytes
// ============================================================
undefined8 fcn.18004f150(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    int64_t var_10h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (dVar3 == 0.0) {
        dVar3 = 2147483647.0;
    }
    *(double *)(**(int64_t **)0x1807825a8 + 0xb0) = 1.0 / dVar3;
    return 0;
}

// ============================================================
// Function: FUN_18004f1c0
// Address: 0x18004f1c0
// Size: 1326 bytes
// ============================================================
void fcn.18004f1c0(int64_t arg1)
{
    uint64_t uVar1;
    uint32_t uVar2;
    undefined4 *puVar3;
    code *pcVar4;
    undefined auVar5 [16];
    int32_t iVar6;
    uint64_t *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t iVar14;
    undefined *puVar15;
    undefined *puVar16;
    undefined *puVar17;
    undefined *puVar18;
    uint64_t uVar19;
    int64_t iVar20;
    uint64_t unaff_R14;
    uint64_t uVar21;
    undefined4 uVar22;
    undefined8 uStack_e0;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    undefined8 uStack_b0;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined8 uStack_90;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_50h;
    
    puVar15 = auStack_d8;
    puVar16 = auStack_d8;
    puVar17 = auStack_d8;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    piVar12 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar12 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar12 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar6 = func_0x0001800a8360(arg1);
        puVar18 = auStack_d8;
        if (iVar6 == 0) goto code_r0x00018004f6ce;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar12 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar12 = *(int64_t **)0x180782430;
        }
    }
    uVar9 = *piVar12 + 0x18;
    puVar18 = auStack_d8;
    if (uVar9 == 0) goto code_r0x00018004f6ce;
    uVar2 = *(uint32_t *)(*piVar12 + 0x14);
    arg1 = (int64_t)uVar2;
    func_0x000180012f50();
    _var_b8h = ZEXT816(0);
    uVar21 = 0;
    var_a8h = 0;
    var_a0h = 0;
    if ((uint64_t)arg1 < 0x10) {
        var_a0h = 0xf;
        var_a8h = arg1;
        uVar22 = fcn.180498030(&var_b8h, uVar9, uVar2);
        *(undefined *)((int64_t)&var_b8h + arg1) = 0;
        uVar19 = (uint64_t)uVar2 | 0xf;
        puVar17 = auStack_d8;
    } else {
        uVar19 = arg1 | 0xf;
        unaff_R14 = uVar19;
        if (uVar19 < 0x16) {
            unaff_R14 = 0x16;
        }
        if (unaff_R14 + 1 < 0x1000) {
            uVar13 = fcn.180459890();
        } else {
            if (unaff_R14 + 0x28 <= unaff_R14 + 1) {
                fcn.180004720();
                goto code_r0x00018004f6e8;
            }
            iVar8 = fcn.180459890(unaff_R14 + 0x28);
            if (iVar8 == 0) {
                pcVar4 = (code *)swi(0x29);
                iVar8 = (*pcVar4)(5);
                puVar15 = auStack_d0;
            }
            uVar13 = iVar8 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar13 - 8) = iVar8;
            puVar16 = puVar15;
        }
        var_b8h = uVar13;
        *(undefined8 *)(puVar16 + -8) = 0x18004f323;
        var_a8h = arg1;
        var_a0h = unaff_R14;
        uVar22 = fcn.180498030(uVar13, uVar9, arg1);
        *(undefined *)(arg1 + uVar13) = 0;
        puVar17 = puVar16;
    }
    *(undefined8 *)(puVar17 + -8) = 0x18004f334;
    func_0x0001800130c0(uVar22, &var_78h, &var_b8h);
    if ((uint64_t)var_a0h < 0x10) {
code_r0x00018004f372:
        var_a8h = 0;
        var_a0h = 0xf;
        auVar5[15] = 0;
        auVar5._0_15_ = stack0xffffffffffffff49;
        _var_b8h = auVar5 << 8;
        puVar18 = puVar17;
        if ((char)var_78h == '\0') goto code_r0x00018004f697;
        *(undefined8 *)(puVar17 + -8) = 0x18004f391;
        puVar7 = (uint64_t *)func_0x0001800137d0();
        unaff_R14 = *puVar7;
        _var_98h = ZEXT816(0);
        var_88h = 0;
        var_80h = 0;
        if (0xf < (uint64_t)arg1) {
            if (uVar19 < 0x16) {
                uVar19 = 0x16;
            }
            if (0xfff < uVar19 + 1) {
                if (uVar19 + 0x28 <= uVar19 + 1) {
code_r0x00018004f6e8:
                    *(undefined8 *)(puVar17 + -8) = 0x18004f6ed;
                    fcn.180004720();
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                *(undefined8 *)(puVar17 + -8) = 0x18004f3f5;
                iVar8 = fcn.180459890(uVar19 + 0x28);
                if (iVar8 == 0) goto code_r0x00018004f3fa;
                goto code_r0x00018004f401;
            }
            *(undefined8 *)(puVar17 + -8) = 0x18004f414;
            uVar13 = fcn.180459890();
            goto code_r0x00018004f417;
        }
        var_80h = 0xf;
        *(undefined8 *)(puVar17 + -8) = 0x18004f3c4;
        var_88h = arg1;
        fcn.180498030(&var_98h, uVar9, arg1);
        *(undefined *)((int64_t)&var_98h + arg1) = 0;
    } else {
        uVar13 = var_a0h + 1;
        iVar8 = var_b8h;
        if (uVar13 < 0x1000) {
code_r0x00018004f36d:
            *(undefined8 *)(puVar17 + -8) = 0x18004f372;
            func_0x000180459c3c(iVar8, uVar13);
            goto code_r0x00018004f372;
        }
        if ((var_b8h - *(int64_t *)(var_b8h + -8)) - 8U < 0x20) {
            uVar13 = var_a0h + 0x28;
            iVar8 = *(int64_t *)(var_b8h + -8);
            goto code_r0x00018004f36d;
        }
code_r0x00018004f3fa:
        pcVar4 = (code *)swi(0x29);
        iVar8 = (*pcVar4)(5);
        puVar17 = puVar17 + 8;
code_r0x00018004f401:
        uVar13 = iVar8 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar13 - 8) = iVar8;
code_r0x00018004f417:
        var_98h = uVar13;
        *(undefined8 *)(puVar17 + -8) = 0x18004f431;
        var_88h = arg1;
        var_80h = uVar19;
        fcn.180498030(uVar13, uVar9, arg1);
        *(undefined *)(arg1 + uVar13) = 0;
        puVar18 = puVar17;
    }
    uVar19 = *(uint64_t *)(unaff_R14 + 0xd0);
    if (uVar19 <= *(int64_t *)(unaff_R14 + 0xe0) + 1U) {
        uVar13 = 1;
        if (uVar19 != 0) {
            uVar13 = uVar19;
        }
code_r0x00018004f470:
        if ((uVar13 == uVar19) || (uVar13 < 8)) {
            if (uVar13 <= 0x7ffffffffffffff - uVar13) goto code_r0x00018004f491;
        } else {
            uVar19 = *(uint64_t *)(unaff_R14 + 0xd8);
            if (uVar13 < 0x2000000000000000) {
                uVar1 = uVar13 * 8;
                if (uVar1 != 0) {
                    if (uVar1 < 0x1000) {
                        *(undefined8 *)(puVar18 + -8) = 0x18004f4fc;
                        uVar21 = fcn.180459890();
                    } else {
                        if (uVar1 + 0x27 <= uVar1) goto code_r0x00018004f6c2;
                        *(undefined8 *)(puVar18 + -8) = 0x18004f4e0;
                        iVar8 = fcn.180459890(uVar1 + 0x27);
                        if (iVar8 == 0) goto code_r0x00018004f5f9;
                        uVar21 = iVar8 + 0x27U & 0xffffffffffffffe0;
                        *(int64_t *)(uVar21 - 8) = iVar8;
                    }
                }
                iVar8 = uVar19 * 8;
                uVar9 = uVar13 >> 1;
                for (; uVar13 <= uVar9; uVar13 = uVar13 * 2) {
                }
                uVar13 = uVar13 - *(int64_t *)(unaff_R14 + 0xd0);
                iVar11 = iVar8 + *(int64_t *)(unaff_R14 + 200);
                iVar14 = (*(int64_t *)(unaff_R14 + 0xd0) * 8 - iVar11) + *(int64_t *)(unaff_R14 + 200);
                *(undefined8 *)(puVar18 + -8) = 0x18004f54c;
                fcn.180498030(iVar8 + uVar21, iVar11, iVar14);
                iVar14 = iVar14 + iVar8 + uVar21;
                uVar10 = *(undefined8 *)(unaff_R14 + 200);
                if (uVar13 < uVar19) {
                    iVar20 = uVar13 * 8;
                    *(undefined8 *)(puVar18 + -8) = 0x18004f593;
                    fcn.180498030(iVar14, uVar10, iVar20);
                    iVar11 = iVar20 + *(int64_t *)(unaff_R14 + 200);
                    iVar8 = (iVar8 - iVar11) + *(int64_t *)(unaff_R14 + 200);
                    *(undefined8 *)(puVar18 + -8) = 0x18004f5b0;
                    fcn.180498030(uVar21, iVar11, iVar8);
                    uVar9 = iVar8 + uVar21;
                } else {
                    *(undefined8 *)(puVar18 + -8) = 0x18004f566;
                    fcn.180498030(iVar14, uVar10, iVar8);
                    *(undefined8 *)(puVar18 + -8) = 0x18004f57b;
                    func_0x0001804986e0(iVar8 + iVar14, 0, (uVar13 - uVar19) * 8);
                    uVar9 = uVar21;
                    iVar20 = iVar8;
                }
                *(undefined8 *)(puVar18 + -8) = 0x18004f5be;
                func_0x0001804986e0(uVar9, 0, iVar20);
                iVar8 = *(int64_t *)(unaff_R14 + 200);
                if (iVar8 != 0) {
                    iVar11 = iVar8;
                    if ((0xfff < (uint64_t)(*(int64_t *)(unaff_R14 + 0xd0) * 8)) &&
                       (iVar11 = *(int64_t *)(iVar8 + -8), uVar9 = uVar21, 0x1f < (iVar8 - iVar11) - 8U)) {
code_r0x00018004f5f9:
                        iVar11 = 5;
                        pcVar4 = (code *)swi(0x29);
                        (*pcVar4)(5);
                        puVar18 = puVar18 + 8;
                        uVar21 = uVar9;
                    }
                    *(undefined8 *)(puVar18 + -8) = 0x18004f60b;
                    func_0x000180459c3c(iVar11);
                }
                *(uint64_t *)(unaff_R14 + 200) = uVar21;
                *(int64_t *)(unaff_R14 + 0xd0) = *(int64_t *)(unaff_R14 + 0xd0) + uVar13;
                uVar19 = *(uint64_t *)(unaff_R14 + 0xd0);
                goto code_r0x00018004f620;
            }
code_r0x00018004f6c2:
            *(undefined8 *)(puVar18 + -8) = 0x18004f6c7;
            fcn.180004720();
        }
        *(undefined8 *)(puVar18 + -8) = 0x18004f6cd;
        func_0x000180010270();
code_r0x00018004f6ce:
        *(undefined8 *)(puVar18 + -8) = 0x18004f6e1;
        fcn.180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
code_r0x00018004f620:
    *(uint64_t *)(unaff_R14 + 0xd8) = *(uint64_t *)(unaff_R14 + 0xd8) & uVar19 - 1;
    uVar9 = *(int64_t *)(unaff_R14 + 0xe0) + *(int64_t *)(unaff_R14 + 0xd8);
    iVar8 = (uVar9 & uVar19 - 1) * 8;
    if (*(int64_t *)(iVar8 + *(int64_t *)(unaff_R14 + 200)) == 0) {
        *(undefined8 *)(puVar18 + -8) = 0x18004f65e;
        uVar10 = fcn.180459890(0x20);
        *(undefined8 *)(iVar8 + *(int64_t *)(unaff_R14 + 200)) = uVar10;
    }
    puVar3 = *(undefined4 **)(*(int64_t *)(unaff_R14 + 200) + (*(int64_t *)(unaff_R14 + 0xd0) - 1U & uVar9) * 8);
    *puVar3 = (undefined4)var_98h;
    puVar3[1] = var_98h._4_4_;
    puVar3[2] = (undefined4)uStack_90;
    puVar3[3] = uStack_90._4_4_;
    puVar3[4] = (undefined4)var_88h;
    puVar3[5] = var_88h._4_4_;
    puVar3[6] = (undefined4)var_80h;
    puVar3[7] = var_80h._4_4_;
    *(int64_t *)(unaff_R14 + 0xe0) = *(int64_t *)(unaff_R14 + 0xe0) + 1;
code_r0x00018004f697:
    *(undefined8 *)(puVar18 + -8) = 0x18004f6a0;
    func_0x000180004e40(&var_70h);
    *(undefined8 *)(puVar18 + -8) = 0x18004f6ae;
    fcn.180459870(var_50h ^ (uint64_t)puVar18);
    return;
code_r0x00018004f491:
    uVar13 = uVar13 * 2;
    goto code_r0x00018004f470;
}

// ============================================================
// Function: FUN_18004f6f0
// Address: 0x18004f6f0
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004f6f0(int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar4 = (int64_t *)func_0x0001800137d0();
    iVar2 = *piVar4;
    iVar3 = *(int64_t *)(iVar2 + 0xe0);
    while (iVar3 != 0) {
        func_0x000180004e40(*(undefined8 *)
                             (*(int64_t *)(iVar2 + 200) +
                             (*(int64_t *)(iVar2 + 0xd0) - 1U & *(uint64_t *)(iVar2 + 0xd8)) * 8));
        piVar1 = (int64_t *)(iVar2 + 0xe0);
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
            *(undefined8 *)(iVar2 + 0xd8) = 0;
        } else {
            *(int64_t *)(iVar2 + 0xd8) = *(int64_t *)(iVar2 + 0xd8) + 1;
        }
        iVar2 = *piVar4;
        iVar3 = *(int64_t *)(iVar2 + 0xe0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004f70f
// Address: 0x18004f70f
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004f6f0(int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar4 = (int64_t *)func_0x0001800137d0();
    iVar2 = *piVar4;
    iVar3 = *(int64_t *)(iVar2 + 0xe0);
    while (iVar3 != 0) {
        func_0x000180004e40(*(undefined8 *)
                             (*(int64_t *)(iVar2 + 200) +
                             (*(int64_t *)(iVar2 + 0xd0) - 1U & *(uint64_t *)(iVar2 + 0xd8)) * 8));
        piVar1 = (int64_t *)(iVar2 + 0xe0);
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
            *(undefined8 *)(iVar2 + 0xd8) = 0;
        } else {
            *(int64_t *)(iVar2 + 0xd8) = *(int64_t *)(iVar2 + 0xd8) + 1;
        }
        iVar2 = *piVar4;
        iVar3 = *(int64_t *)(iVar2 + 0xe0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004f76c
// Address: 0x18004f76c
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18004f6f0(int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_18h;
    
    piVar4 = (int64_t *)func_0x0001800137d0();
    iVar2 = *piVar4;
    iVar3 = *(int64_t *)(iVar2 + 0xe0);
    while (iVar3 != 0) {
        func_0x000180004e40(*(undefined8 *)
                             (*(int64_t *)(iVar2 + 200) +
                             (*(int64_t *)(iVar2 + 0xd0) - 1U & *(uint64_t *)(iVar2 + 0xd8)) * 8));
        piVar1 = (int64_t *)(iVar2 + 0xe0);
        *piVar1 = *piVar1 + -1;
        if (*piVar1 == 0) {
            *(undefined8 *)(iVar2 + 0xd8) = 0;
        } else {
            *(int64_t *)(iVar2 + 0xd8) = *(int64_t *)(iVar2 + 0xd8) + 1;
        }
        iVar2 = *piVar4;
        iVar3 = *(int64_t *)(iVar2 + 0xe0);
    }
    return 0;
}

// ============================================================
// Function: FUN_18004f780
// Address: 0x18004f780
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18004f780(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint8_t *puVar10;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    if ((*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
         *(int32_t *)0x1807828b0) && (fcn.180459d18(0x1807828b0), *(int32_t *)0x1807828b0 == -1)) {
        *(int64_t *)0x1807828a8 = **(int64_t **)0x1807825b8;
        fcn.180459cac(0x1807828b0);
    }
    if ((((*(int64_t *)0x1807828a8 != 0) && (*(int64_t *)(*(int64_t *)0x1807828a8 + 8) != 0)) &&
        (iVar1 = *(int64_t *)(*(int64_t *)0x1807828a8 + 0x18), iVar1 != 0)) &&
       (*(uint64_t *)(*(int64_t *)0x1807828a8 + 0x30) != 0)) {
        uVar2 = *(uint64_t *)(arg2 + 0x18);
        uVar5 = 0xcbf29ce484222325;
        puVar7 = (uint8_t *)arg2;
        if (0xf < uVar2) {
            puVar7 = *(uint8_t **)arg2;
        }
        iVar3 = *(int64_t *)(arg2 + 0x10);
        puVar10 = puVar7 + iVar3;
        for (; puVar7 != puVar10; puVar7 = puVar7 + 1) {
            uVar5 = (uVar5 ^ *puVar7) * 0x100000001b3;
        }
        uVar5 = uVar5 & *(uint64_t *)(*(int64_t *)0x1807828a8 + 0x30);
        iVar9 = *(int64_t *)(iVar1 + uVar5 * 0x10);
        if (iVar9 != *(int64_t *)(*(int64_t *)0x1807828a8 + 8)) {
            iVar1 = *(int64_t *)(iVar1 + 8 + uVar5 * 0x10);
            while( true ) {
                if (*(int64_t *)(iVar9 + 0x20) == iVar3) {
                    piVar6 = (int64_t *)(iVar9 + 0x10);
                    if (0xf < *(uint64_t *)(iVar9 + 0x28)) {
                        piVar6 = (int64_t *)*piVar6;
                    }
                    iVar8 = arg2;
                    if (0xf < uVar2) {
                        iVar8 = *(int64_t *)arg2;
                    }
                    iVar4 = fcn.180497f30(piVar6, iVar8, iVar3);
                    if (iVar4 == 0) {
                        *(int64_t *)arg1 = iVar9;
                        *(undefined *)(arg1 + 8) = 1;
                        return arg1;
                    }
                }
                if (iVar9 == iVar1) break;
                iVar9 = *(int64_t *)(iVar9 + 8);
            }
        }
    }
    *(undefined *)(arg1 + 8) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18004f7bd
// Address: 0x18004f7bd
// Size: 273 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18004f780(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint8_t *puVar10;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    if ((*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
         *(int32_t *)0x1807828b0) && (fcn.180459d18(0x1807828b0), *(int32_t *)0x1807828b0 == -1)) {
        *(int64_t *)0x1807828a8 = **(int64_t **)0x1807825b8;
        fcn.180459cac(0x1807828b0);
    }
    if ((((*(int64_t *)0x1807828a8 != 0) && (*(int64_t *)(*(int64_t *)0x1807828a8 + 8) != 0)) &&
        (iVar1 = *(int64_t *)(*(int64_t *)0x1807828a8 + 0x18), iVar1 != 0)) &&
       (*(uint64_t *)(*(int64_t *)0x1807828a8 + 0x30) != 0)) {
        uVar2 = *(uint64_t *)(arg2 + 0x18);
        uVar5 = 0xcbf29ce484222325;
        puVar7 = (uint8_t *)arg2;
        if (0xf < uVar2) {
            puVar7 = *(uint8_t **)arg2;
        }
        iVar3 = *(int64_t *)(arg2 + 0x10);
        puVar10 = puVar7 + iVar3;
        for (; puVar7 != puVar10; puVar7 = puVar7 + 1) {
            uVar5 = (uVar5 ^ *puVar7) * 0x100000001b3;
        }
        uVar5 = uVar5 & *(uint64_t *)(*(int64_t *)0x1807828a8 + 0x30);
        iVar9 = *(int64_t *)(iVar1 + uVar5 * 0x10);
        if (iVar9 != *(int64_t *)(*(int64_t *)0x1807828a8 + 8)) {
            iVar1 = *(int64_t *)(iVar1 + 8 + uVar5 * 0x10);
            while( true ) {
                if (*(int64_t *)(iVar9 + 0x20) == iVar3) {
                    piVar6 = (int64_t *)(iVar9 + 0x10);
                    if (0xf < *(uint64_t *)(iVar9 + 0x28)) {
                        piVar6 = (int64_t *)*piVar6;
                    }
                    iVar8 = arg2;
                    if (0xf < uVar2) {
                        iVar8 = *(int64_t *)arg2;
                    }
                    iVar4 = fcn.180497f30(piVar6, iVar8, iVar3);
                    if (iVar4 == 0) {
                        *(int64_t *)arg1 = iVar9;
                        *(undefined *)(arg1 + 8) = 1;
                        return arg1;
                    }
                }
                if (iVar9 == iVar1) break;
                iVar9 = *(int64_t *)(iVar9 + 8);
            }
        }
    }
    *(undefined *)(arg1 + 8) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18004f8ce
// Address: 0x18004f8ce
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18004f780(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    uint8_t *puVar10;
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    
    if ((*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
         *(int32_t *)0x1807828b0) && (fcn.180459d18(0x1807828b0), *(int32_t *)0x1807828b0 == -1)) {
        *(int64_t *)0x1807828a8 = **(int64_t **)0x1807825b8;
        fcn.180459cac(0x1807828b0);
    }
    if ((((*(int64_t *)0x1807828a8 != 0) && (*(int64_t *)(*(int64_t *)0x1807828a8 + 8) != 0)) &&
        (iVar1 = *(int64_t *)(*(int64_t *)0x1807828a8 + 0x18), iVar1 != 0)) &&
       (*(uint64_t *)(*(int64_t *)0x1807828a8 + 0x30) != 0)) {
        uVar2 = *(uint64_t *)(arg2 + 0x18);
        uVar5 = 0xcbf29ce484222325;
        puVar7 = (uint8_t *)arg2;
        if (0xf < uVar2) {
            puVar7 = *(uint8_t **)arg2;
        }
        iVar3 = *(int64_t *)(arg2 + 0x10);
        puVar10 = puVar7 + iVar3;
        for (; puVar7 != puVar10; puVar7 = puVar7 + 1) {
            uVar5 = (uVar5 ^ *puVar7) * 0x100000001b3;
        }
        uVar5 = uVar5 & *(uint64_t *)(*(int64_t *)0x1807828a8 + 0x30);
        iVar9 = *(int64_t *)(iVar1 + uVar5 * 0x10);
        if (iVar9 != *(int64_t *)(*(int64_t *)0x1807828a8 + 8)) {
            iVar1 = *(int64_t *)(iVar1 + 8 + uVar5 * 0x10);
            while( true ) {
                if (*(int64_t *)(iVar9 + 0x20) == iVar3) {
                    piVar6 = (int64_t *)(iVar9 + 0x10);
                    if (0xf < *(uint64_t *)(iVar9 + 0x28)) {
                        piVar6 = (int64_t *)*piVar6;
                    }
                    iVar8 = arg2;
                    if (0xf < uVar2) {
                        iVar8 = *(int64_t *)arg2;
                    }
                    iVar4 = fcn.180497f30(piVar6, iVar8, iVar3);
                    if (iVar4 == 0) {
                        *(int64_t *)arg1 = iVar9;
                        *(undefined *)(arg1 + 8) = 1;
                        return arg1;
                    }
                }
                if (iVar9 == iVar1) break;
                iVar9 = *(int64_t *)(iVar9 + 8);
            }
        }
    }
    *(undefined *)(arg1 + 8) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18004f910
// Address: 0x18004f910
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004f931
// Address: 0x18004f931
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004f9ed
// Address: 0x18004f9ed
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004fa03
// Address: 0x18004fa03
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004fa1f
// Address: 0x18004fa1f
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004fa30
// Address: 0x18004fa30
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004fa67
// Address: 0x18004fa67
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18004f910(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = *(int64_t **)(arg1 + 0x30);
    if (*piVar6 == *(int64_t *)0x1807825d8) {
        return 0;
    }
    piVar2 = (int64_t *)piVar6[0x18];
    iVar3 = *(int32_t *)((int64_t)piVar6 + 0xb4);
    if (iVar3 == 2) {
        puVar1 = (uint64_t *)(arg2 + 0x10);
        if (*(uint64_t *)(arg2 + 0x10) < 0x11) {
            piVar6 = (int64_t *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                piVar6 = *(int64_t **)arg2;
            }
            *piVar2 = *piVar6;
            if (8 < *puVar1) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                piVar2[1] = *(int64_t *)(arg2 + 8);
            }
        } else {
            iVar5 = fcn.180459e5c(*(uint64_t *)(arg2 + 0x10) + 1);
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180498030(iVar5, arg2, *puVar1);
            *(undefined *)(iVar5 + *puVar1) = 0;
            *piVar2 = iVar5;
        }
        piVar2[3] = *puVar1;
        return 1;
    }
    if (iVar3 == 3) {
        uVar4 = fcn.180013c20(arg2);
        *(undefined4 *)piVar2 = uVar4;
        return 1;
    }
    if (iVar3 == 4) {
        iVar5 = *(int64_t *)(arg2 + 0x10);
        iVar7 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar7 = *(int64_t *)arg2;
        }
        if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x1805ab294, 4), iVar3 != 0)) {
            iVar7 = arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                iVar7 = *(int64_t *)arg2;
            }
            if ((iVar5 != 4) || (iVar3 = fcn.180497f30(iVar7, 0x180623d2c, 4), iVar3 != 0)) {
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    arg2 = *(int64_t *)arg2;
                }
                if ((iVar5 != 1) || (iVar3 = fcn.180497f30(arg2, 0x180623d34, 1), iVar3 != 0)) {
                    *(undefined *)piVar2 = 0;
                    return 1;
                }
            }
        }
        *(undefined *)piVar2 = 1;
        return 1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18004fab0
// Address: 0x18004fab0
// Size: 892 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.18004fab0(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    int32_t iVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    char **ppcVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    uint64_t uVar16;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_a0;
    undefined auStack_98 [8];
    undefined auStack_90 [32];
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    undefined8 uStack_48;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar13 = auStack_98;
    puVar14 = auStack_98;
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_98;
    piVar10 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018004fe12;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar10 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar10 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar10 + 0x18;
    if (iVar8 == 0) goto code_r0x00018004fe12;
    uVar1 = *(uint32_t *)(*piVar10 + 0x14);
    uVar11 = (uint64_t)uVar1;
    _var_50h = ZEXT816(0);
    var_40h = 0;
    var_38h = 0;
    if (uVar11 < 0x10) {
        var_38h = 0xf;
        var_40h = uVar11;
        fcn.180498030(&var_50h, iVar8, uVar1);
        *(undefined *)((int64_t)&var_50h + uVar11) = 0;
code_r0x00018004fc05:
        fcn.18004f780((int64_t)&var_70h, (int64_t)&var_50h);
        if ((char)var_68h == '\0') {
            uVar12 = func_0x00018000b450(&var_50h);
            fcn.180088560(arg1, 0x180623cf0, uVar12);
code_r0x00018004fe12:
            fcn.180088470(arg1, 1, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        piVar10 = *(int64_t **)(var_70h + 0x30);
        if (((*piVar10 == *(int64_t *)0x1807825d8) || (ppcVar9 = (char **)piVar10[0x18], ppcVar9 == (char **)0x65757254)
            ) || (ppcVar9 == (char **)0x31303031)) {
            var_60h = 0;
            var_58h = 0xf;
            stack0xffffffffffffff91 = SUB1615(ZEXT816(0), 1);
            auVar3[15] = 0;
            auVar3._0_15_ = stack0xffffffffffffff91;
            _var_70h = auVar3 << 8;
        } else {
            iVar4 = *(int32_t *)((int64_t)piVar10 + 0xb4);
            if (iVar4 == 2) {
                if ((char *)0xf < ppcVar9[3]) {
                    ppcVar9 = (char **)*ppcVar9;
                }
                _var_70h = ZEXT816(0);
                var_60h = 0;
                var_58h = 0;
                func_0x000180004830(&var_70h, ppcVar9);
            } else if (iVar4 == 3) {
                func_0x000180016b80(&var_70h, *(undefined4 *)ppcVar9);
            } else {
                _var_70h = ZEXT816(0);
                if (iVar4 == 4) {
                    uVar12 = 0x1805ab28c;
                    if (*(char *)ppcVar9 != '\0') {
                        uVar12 = 0x1805ab294;
                    }
                    var_60h = 0;
                    var_58h = 0;
                    uVar7 = fcn.180498cd0(uVar12);
                    func_0x000180004830(&var_70h, uVar12, uVar7);
                } else {
                    puVar6 = (undefined4 *)fcn.180459890(0x20);
                    var_70h = (int64_t)puVar6;
                    var_60h = 0x14;
                    var_58h = 0x1f;
                    *puVar6 = 0x62616e55;
                    puVar6[1] = 0x7420656c;
                    puVar6[2] = 0x6567206f;
                    puVar6[3] = 0x61562074;
                    puVar6[4] = 0x2e65756c;
                    *(undefined *)(puVar6 + 5) = 0;
                }
            }
        }
        piVar10 = &var_70h;
        if (0xf < (uint64_t)var_58h) {
            piVar10 = (int64_t *)var_70h;
        }
        func_0x0001800867f0(arg1, piVar10, var_60h);
        if (0xf < (uint64_t)var_58h) {
            iVar8 = var_70h;
            puVar14 = auStack_98;
            if ((0xfff < var_58h + 1U) &&
               (iVar8 = *(int64_t *)(var_70h + -8), puVar14 = auStack_98, 0x1f < (var_70h - iVar8) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar8 = (*pcVar2)(5);
                puVar14 = auStack_90;
            }
            *(undefined8 *)(puVar14 + -8) = 0x18004fd8b;
            func_0x000180459c3c(iVar8);
        }
        if ((uint64_t)var_38h < 0x10) goto code_r0x00018004fdcc;
        iVar8 = var_50h;
        if ((0xfff < var_38h + 1U) &&
           (iVar8 = *(int64_t *)(var_50h + -8), puVar13 = puVar14, 0x1f < (var_50h - iVar8) - 8U))
        goto code_r0x00018004fdbd;
    } else {
        uVar15 = uVar11 | 0xf;
        if (uVar15 < 0x16) {
            uVar15 = 0x16;
        }
        if (uVar15 + 1 < 0x1000) {
            uVar16 = fcn.180459890();
code_r0x00018004fbe7:
            var_50h = uVar16;
            var_40h = uVar11;
            var_38h = uVar15;
            fcn.180498030(uVar16, iVar8, uVar11);
            *(undefined *)(uVar16 + uVar11) = 0;
            goto code_r0x00018004fc05;
        }
        if (uVar15 + 0x28 <= uVar15 + 1) {
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar5 = fcn.180459890(uVar15 + 0x28);
        if (iVar5 != 0) {
            uVar16 = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar16 - 8) = iVar5;
            goto code_r0x00018004fbe7;
        }
code_r0x00018004fdbd:
        pcVar2 = (code *)swi(0x29);
        iVar8 = (*pcVar2)(5);
        puVar14 = puVar13 + 8;
    }
    *(undefined8 *)(puVar14 + -8) = 0x18004fdcc;
    func_0x000180459c3c(iVar8);
code_r0x00018004fdcc:
    *(undefined8 *)(puVar14 + -8) = 0x18004fddd;
    fcn.180459870(var_30h ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_18004fe30
// Address: 0x18004fe30
// Size: 1409 bytes
// ============================================================
void fcn.18004fe30(int64_t arg1)
{
    uint32_t uVar1;
    int64_t *piVar2;
    code *pcVar3;
    undefined auVar4 [16];
    bool bVar5;
    undefined auVar6 [16];
    int32_t iVar7;
    undefined4 uVar8;
    int64_t iVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    undefined (*pauVar14) [16];
    int64_t iVar15;
    int64_t *piVar16;
    uint64_t uVar17;
    undefined8 uVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    uint64_t uVar22;
    int64_t *piVar23;
    undefined8 uStack_e0;
    undefined auStack_d8 [8];
    undefined auStack_d0 [24];
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined8 uStack_70;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar21 = auStack_d8;
    puVar19 = auStack_d8;
    puVar20 = auStack_d8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    piVar16 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar16 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar16 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x00018005039d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar16 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar16 = *(int64_t **)0x180782430;
        }
    }
    piVar23 = *(int64_t **)0x180782430;
    iVar15 = *piVar16 + 0x18;
    if (iVar15 == 0) goto code_r0x00018005039d;
    uVar1 = *(uint32_t *)(*piVar16 + 0x14);
    uVar22 = (uint64_t)uVar1;
    _var_78h = ZEXT816(0);
    uVar17 = 0;
    var_68h = 0;
    var_60h = 0;
    if (uVar22 < 0x10) {
        var_60h = 0xf;
        var_68h = uVar22;
        fcn.180498030(&var_78h, iVar15, uVar1);
        *(undefined *)((int64_t)&var_78h + uVar22) = 0;
code_r0x00018004ff93:
        var_a8h = 0;
        var_a0h = 0xf;
        stack0xffffffffffffff49 = SUB1615(ZEXT816(0), 1);
        auVar4[15] = 0;
        auVar4._0_15_ = stack0xffffffffffffff49;
        _var_b8h = auVar4 << 8;
        iVar15 = *(int64_t *)(arg1 + 0x28);
        piVar16 = (int64_t *)(iVar15 + 0x10);
        piVar2 = *(int64_t **)(arg1 + 0x40);
        piVar10 = piVar16;
        if (piVar2 <= piVar16) {
            piVar10 = piVar23;
        }
        if ((piVar10 == piVar23) ||
           ((*(int32_t *)((int64_t)piVar10 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar10 + 0xc) != 3)))) {
            piVar16 = (int64_t *)(iVar15 + 0x10U);
            if (piVar2 <= (int64_t *)(iVar15 + 0x10U)) {
                piVar16 = piVar23;
            }
            if ((piVar16 == piVar23) || (*(int32_t *)((int64_t)piVar16 + 0xc) != 1)) {
                iVar7 = func_0x000180085d50(arg1, 2);
                if (iVar7 == 0) goto code_r0x000180050390;
                uVar8 = func_0x000180085f50(arg1, 2, 0);
                pauVar14 = (undefined (*) [16])func_0x000180016b80(&var_98h, uVar8);
                if ((undefined (*) [16])&var_b8h != pauVar14) {
                    if ((uint64_t)var_a0h < 0x10) {
code_r0x000180050243:
                        _var_b8h = *pauVar14;
                        var_a8h = *(int64_t *)pauVar14[1];
                        var_a0h = *(int64_t *)(pauVar14[1] + 8);
                        *(undefined8 *)pauVar14[1] = 0;
                        *(undefined8 *)(pauVar14[1] + 8) = 0xf;
                        (*pauVar14)[0] = 0;
                        goto code_r0x000180050271;
                    }
                    uVar17 = var_a0h + 1;
                    iVar15 = var_b8h;
                    if (uVar17 < 0x1000) {
code_r0x00018005023b:
                        func_0x000180459c3c(iVar15, uVar17);
                        goto code_r0x000180050243;
                    }
                    if ((var_b8h - *(int64_t *)(var_b8h + -8)) - 8U < 0x20) {
                        uVar17 = var_a0h + 0x28;
                        iVar15 = *(int64_t *)(var_b8h + -8);
                        goto code_r0x00018005023b;
                    }
                    goto code_r0x0001800502a2;
                }
code_r0x000180050271:
                if ((uint64_t)var_80h < 0x10) goto code_r0x0001800502b1;
                iVar15 = var_98h;
                if ((0xfff < var_80h + 1U) &&
                   (iVar15 = *(int64_t *)(var_98h + -8), puVar19 = auStack_d8,
                   0x1f < (var_98h - *(int64_t *)(var_98h + -8)) - 8U)) goto code_r0x0001800502a2;
                goto code_r0x0001800502ac;
            }
            piVar16 = (int64_t *)(iVar15 + 0x10U);
            if (piVar2 <= (int64_t *)(iVar15 + 0x10U)) {
                piVar16 = piVar23;
            }
            if ((*(int32_t *)((int64_t)piVar16 + 0xc) == 0) ||
               ((*(int32_t *)((int64_t)piVar16 + 0xc) == 1 && (*(int32_t *)piVar16 == 0)))) {
                bVar5 = false;
            } else {
                bVar5 = true;
            }
            uVar18 = 0x1805ab28c;
            if (bVar5) {
                uVar18 = 0x1805ab294;
            }
            uVar13 = fcn.180498cd0(uVar18);
            func_0x00018000f180(&var_b8h, uVar18, uVar13);
            puVar20 = auStack_d8;
        } else {
            if (piVar2 <= piVar16) {
                piVar16 = piVar23;
            }
            if (*(int32_t *)((int64_t)piVar16 + 0xc) == 6) {
code_r0x000180050045:
                uVar17 = (uint64_t)*(uint32_t *)(*piVar16 + 0x14);
                uVar22 = *piVar16 + 0x18;
            } else {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                iVar7 = func_0x0001800a8360(arg1);
                uVar22 = uVar17;
                if (iVar7 != 0) {
                    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                        (**(code **)0x180782658)(arg1, 1);
                    }
                    piVar16 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
                        piVar16 = *(int64_t **)0x180782430;
                    }
                    goto code_r0x000180050045;
                }
            }
            _var_98h = ZEXT816(0);
            if (uVar17 < 0x10) {
                var_80h = 0xf;
                var_88h = uVar17;
                fcn.180498030(&var_98h, uVar22, uVar17);
                *(undefined *)((int64_t)&var_98h + uVar17) = 0;
code_r0x00018005010d:
                if (0xf < (uint64_t)var_a0h) {
                    uVar17 = var_a0h + 1;
                    iVar15 = var_b8h;
                    if (0xfff < uVar17) {
                        if (0x1f < (var_b8h - *(int64_t *)(var_b8h + -8)) - 8U) goto code_r0x0001800502a2;
                        uVar17 = var_a0h + 0x28;
                        iVar15 = *(int64_t *)(var_b8h + -8);
                    }
                    func_0x000180459c3c(iVar15, uVar17);
                }
                _var_b8h = _var_98h;
                var_a8h = var_88h;
                var_a0h = var_80h;
                puVar20 = auStack_d8;
            } else {
                uVar11 = uVar17 | 0xf;
                if (uVar11 < 0x8000000000000000) {
                    if (uVar11 < 0x16) {
                        uVar11 = 0x16;
                    }
                    if (0xfff < uVar11 + 1) {
                        uVar12 = uVar11 + 0x28;
                        arg1 = uVar17;
                        if (uVar12 <= uVar11 + 1) goto code_r0x00018005038a;
                        goto code_r0x0001800500a1;
                    }
                    uVar12 = fcn.180459890();
code_r0x0001800500ef:
                    var_98h = uVar12;
                    var_88h = uVar17;
                    var_80h = uVar11;
                    fcn.180498030(uVar12, uVar22, uVar17);
                    *(undefined *)(uVar12 + uVar17) = 0;
                    goto code_r0x00018005010d;
                }
                uVar12 = 0x8000000000000027;
                uVar11 = 0x7fffffffffffffff;
code_r0x0001800500a1:
                iVar15 = fcn.180459890(uVar12);
                if (iVar15 != 0) {
                    uVar12 = iVar15 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar12 - 8) = iVar15;
                    goto code_r0x0001800500ef;
                }
code_r0x0001800502a2:
                pcVar3 = (code *)swi(0x29);
                iVar15 = (*pcVar3)(5);
                puVar19 = auStack_d0;
code_r0x0001800502ac:
                *(undefined8 *)(puVar19 + -8) = 0x1800502b1;
                func_0x000180459c3c(iVar15);
                puVar20 = puVar19;
            }
        }
code_r0x0001800502b1:
        *(undefined8 *)(puVar20 + -8) = 0x1800502be;
        fcn.18004f780((int64_t)&var_98h, (int64_t)&var_78h);
        if ((char)var_90h != '\0') {
            *(undefined8 *)(puVar20 + -8) = 0x1800502d1;
            fcn.18004f910(var_98h, (int64_t)&var_b8h);
        }
        if (0xf < (uint64_t)var_a0h) {
            iVar15 = var_b8h;
            if ((0xfff < var_a0h + 1U) && (iVar15 = *(int64_t *)(var_b8h + -8), 0x1f < (var_b8h - iVar15) - 8U)) {
                pcVar3 = (code *)swi(0x29);
                iVar15 = (*pcVar3)(5);
                puVar20 = puVar20 + 8;
            }
            *(undefined8 *)(puVar20 + -8) = 0x180050312;
            func_0x000180459c3c(iVar15);
        }
        var_a8h = 0;
        var_a0h = 0xf;
        auVar6[15] = 0;
        auVar6._0_15_ = stack0xffffffffffffff49;
        _var_b8h = auVar6 << 8;
        if ((uint64_t)var_60h < 0x10) goto code_r0x000180050362;
        iVar15 = var_78h;
        if ((0xfff < var_60h + 1U) &&
           (iVar15 = *(int64_t *)(var_78h + -8), puVar21 = puVar20, 0x1f < (var_78h - iVar15) - 8U))
        goto code_r0x000180050353;
    } else {
        uVar11 = uVar22 | 0xf;
        if (uVar11 < 0x16) {
            uVar11 = 0x16;
        }
        if (uVar11 + 1 < 0x1000) {
            uVar12 = fcn.180459890();
code_r0x00018004ff6e:
            var_78h = uVar12;
            var_68h = uVar22;
            var_60h = uVar11;
            fcn.180498030(uVar12, iVar15, uVar22);
            *(undefined *)(uVar22 + uVar12) = 0;
            piVar23 = *(int64_t **)0x180782430;
            goto code_r0x00018004ff93;
        }
        if (uVar11 + 0x28 <= uVar11 + 1) {
            fcn.180004720();
code_r0x00018005038a:
            fcn.180004720();
code_r0x000180050390:
            fcn.1800883d0();
code_r0x00018005039d:
            fcn.180088470(arg1, 1, 6);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        iVar9 = fcn.180459890(uVar11 + 0x28);
        if (iVar9 != 0) {
            uVar12 = iVar9 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar12 - 8) = iVar9;
            goto code_r0x00018004ff6e;
        }
code_r0x000180050353:
        pcVar3 = (code *)swi(0x29);
        iVar15 = (*pcVar3)(5);
        puVar20 = puVar21 + 8;
    }
    *(undefined8 *)(puVar20 + -8) = 0x180050362;
    func_0x000180459c3c(iVar15);
code_r0x000180050362:
    *(undefined8 *)(puVar20 + -8) = 0x180050370;
    fcn.180459870(var_58h ^ (uint64_t)puVar20);
    return;
}

// ============================================================
// Function: FUN_1800503c0
// Address: 0x1800503c0
// Size: 475 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

undefined8 fcn.1800503c0(void)
{
    uint32_t *puVar1;
    uint32_t uVar2;
    undefined *puVar3;
    code *pcVar4;
    char cVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    int32_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t var_10h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar9 = (undefined8 *)fcn.180008740();
    puVar3 = (undefined *)*puVar9;
    piVar10 = (int64_t *)func_0x0001800137d0();
    iVar11 = *piVar10;
    iVar8 = func_0x000180456008(iVar11 + 0x28);
    if (iVar8 == 0) {
        if (*(int32_t *)(iVar11 + 0x74) == 0x7fffffff) {
            *(undefined4 *)(iVar11 + 0x74) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar4 = (code *)swi(3);
            uVar12 = (*pcVar4)();
            return uVar12;
        }
        if (*(int64_t *)(iVar11 + 0x20) != 0) {
            while( true ) {
                func_0x00018000d070(*(undefined8 *)
                                     (*(int64_t *)(iVar11 + 8) +
                                     (*(int64_t *)(iVar11 + 0x10) - 1U & *(uint64_t *)(iVar11 + 0x18)) * 8));
                piVar10 = (int64_t *)(iVar11 + 0x20);
                *piVar10 = *piVar10 + -1;
                if (*piVar10 == 0) break;
                *(int64_t *)(iVar11 + 0x18) = *(int64_t *)(iVar11 + 0x18) + 1;
            }
            *(undefined8 *)(iVar11 + 0x18) = 0;
        }
        func_0x000180456010(iVar11 + 0x28);
        func_0x00018000adc0(0x18077af40);
        LOCK();
        *puVar3 = 0;
        cVar5 = *(char *)0x180781ed8;
        UNLOCK();
        LOCK();
        *(char *)0x180781ed8 = '\x01';
        UNLOCK();
        if (cVar5 != '\0') {
            *(undefined *)0x180781ed8 = 1;
            return 0;
        }
        _var_48h = ZEXT816(0);
        var_38h = fcn.180459890();
        *(undefined4 *)var_38h = 1;
        *(undefined4 *)(var_38h + 4) = 2;
        *(undefined8 *)(var_38h + 8) = 0;
        *(undefined8 *)(var_38h + 0x10) = 0;
        *(undefined4 *)(var_38h + 0x18) = 0;
        puVar9 = (undefined8 *)fcn.180459890(8);
        *puVar9 = puVar3;
        iVar11 = func_0x00018045f6e8(0, 0, 0x18000eaf0, puVar9, 0, &var_40h);
        auVar6 = _var_48h;
        var_48h = iVar11;
        auVar7 = _var_48h;
        var_40h._4_4_ = auVar6._12_4_;
        if (iVar11 != 0) {
            var_40h._0_4_ = auVar6._8_4_;
            if ((int32_t)var_40h != 0) {
                var_50h._0_4_ = (int32_t)var_40h;
                var_58h = iVar11;
                var_50h._4_4_ = var_40h._4_4_;
                _var_48h = auVar7;
                iVar8 = func_0x000180454a0c(&var_58h);
                auVar7 = _var_48h;
                if (iVar8 == 0) {
                    _var_58h = ZEXT816(0);
                    _var_48h = ZEXT812(0);
                    var_40h._4_4_ = 0;
                    if (var_38h != 0) {
                        LOCK();
                        puVar1 = (uint32_t *)(var_38h + 4);
                        uVar2 = *puVar1;
                        *puVar1 = *puVar1 - 2;
                        UNLOCK();
                        if ((uVar2 & 0xfffffffe) == 2) {
                            LOCK();
                            iVar8 = *(int32_t *)var_38h;
                            *(int32_t *)var_38h = *(int32_t *)var_38h + -1;
                            UNLOCK();
                            if (iVar8 == 1) {
                                func_0x000180459c3c(var_38h, 0x20);
                            }
                        }
                    }
                    if ((int32_t)var_40h == 0) {
                        return 0;
                    }
                    func_0x00018045f7d4();
                    auVar7 = _var_48h;
                }
            }
            _var_48h = auVar7;
            func_0x0001804542e8(1);
            pcVar4 = (code *)swi(3);
            uVar12 = (*pcVar4)();
            return uVar12;
        }
        _var_48h = ZEXT812(0);
        func_0x0001804542e8(6);
    }
    func_0x0001804542e8(5);
    pcVar4 = (code *)swi(3);
    uVar12 = (*pcVar4)();
    return uVar12;
}

// ============================================================
// Function: FUN_1800505a0
// Address: 0x1800505a0
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800505a0(int64_t arg1)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar10 = uVar1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    uVar10 = uVar1 + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1 + 0x10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar10 + 0xc) == 6)) {
        func_0x000180086cc0(arg1, 1, 0x1805aaf20);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800867f0(arg1, 0x180621618, 0xd);
        var_18h = *(int64_t *)(arg1 + 0x40) + -0x30;
        var_10h._0_4_ = 1;
        iVar9 = func_0x000180094080(arg1, 0x180087890, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (iVar9 != 0) {
            fcn.180088560(arg1, 0x180623d60);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180086cc0(arg1, 0xffffffff, 0x180623d80);
        if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
           (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                *puVar2 = puVar2[-8];
                puVar2[1] = puVar2[-7];
                puVar2[2] = puVar2[-6];
                puVar2[3] = puVar2[-5];
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180085bf0(arg1, 2);
                iVar9 = func_0x0001800878a0(arg1, 2, 1);
                if (iVar9 != 0) {
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                }
                func_0x000180086fd0(arg1, 0, 0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *puVar2 = puVar2[-8];
                    puVar2[1] = puVar2[-7];
                    puVar2[2] = puVar2[-6];
                    puVar2[3] = puVar2[-5];
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
                    if (*(char *)(*(int64_t *)(puVar2 + -4) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(puVar2 + -4), 1);
                    uVar6 = puVar2[1];
                    uVar7 = puVar2[2];
                    uVar8 = puVar2[3];
                    *puVar11 = *puVar2;
                    puVar11[1] = uVar6;
                    puVar11[2] = uVar7;
                    puVar11[3] = uVar8;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar3 = *(int64_t *)(puVar2 + -4);
                        if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar4 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar4 + 0x59) == '\x02') {
                                func_0x000180094420(iVar4);
                            } else {
                                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                                *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                                *(int64_t *)(iVar4 + 0x18) = iVar3;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    return 1;
                }
            }
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        fcn.180088560(arg1, 0x180623d38);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    fcn.180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_18005069e
// Address: 0x18005069e
// Size: 399 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800505a0(int64_t arg1)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar10 = uVar1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    uVar10 = uVar1 + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1 + 0x10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar10 + 0xc) == 6)) {
        func_0x000180086cc0(arg1, 1, 0x1805aaf20);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800867f0(arg1, 0x180621618, 0xd);
        var_18h = *(int64_t *)(arg1 + 0x40) + -0x30;
        var_10h._0_4_ = 1;
        iVar9 = func_0x000180094080(arg1, 0x180087890, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (iVar9 != 0) {
            fcn.180088560(arg1, 0x180623d60);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180086cc0(arg1, 0xffffffff, 0x180623d80);
        if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
           (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                *puVar2 = puVar2[-8];
                puVar2[1] = puVar2[-7];
                puVar2[2] = puVar2[-6];
                puVar2[3] = puVar2[-5];
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180085bf0(arg1, 2);
                iVar9 = func_0x0001800878a0(arg1, 2, 1);
                if (iVar9 != 0) {
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                }
                func_0x000180086fd0(arg1, 0, 0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *puVar2 = puVar2[-8];
                    puVar2[1] = puVar2[-7];
                    puVar2[2] = puVar2[-6];
                    puVar2[3] = puVar2[-5];
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
                    if (*(char *)(*(int64_t *)(puVar2 + -4) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(puVar2 + -4), 1);
                    uVar6 = puVar2[1];
                    uVar7 = puVar2[2];
                    uVar8 = puVar2[3];
                    *puVar11 = *puVar2;
                    puVar11[1] = uVar6;
                    puVar11[2] = uVar7;
                    puVar11[3] = uVar8;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar3 = *(int64_t *)(puVar2 + -4);
                        if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar4 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar4 + 0x59) == '\x02') {
                                func_0x000180094420(iVar4);
                            } else {
                                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                                *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                                *(int64_t *)(iVar4 + 0x18) = iVar3;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    return 1;
                }
            }
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        fcn.180088560(arg1, 0x180623d38);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    fcn.180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_18005082d
// Address: 0x18005082d
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800505a0(int64_t arg1)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar10 = uVar1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    uVar10 = uVar1 + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1 + 0x10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar10 + 0xc) == 6)) {
        func_0x000180086cc0(arg1, 1, 0x1805aaf20);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800867f0(arg1, 0x180621618, 0xd);
        var_18h = *(int64_t *)(arg1 + 0x40) + -0x30;
        var_10h._0_4_ = 1;
        iVar9 = func_0x000180094080(arg1, 0x180087890, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (iVar9 != 0) {
            fcn.180088560(arg1, 0x180623d60);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180086cc0(arg1, 0xffffffff, 0x180623d80);
        if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
           (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                *puVar2 = puVar2[-8];
                puVar2[1] = puVar2[-7];
                puVar2[2] = puVar2[-6];
                puVar2[3] = puVar2[-5];
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180085bf0(arg1, 2);
                iVar9 = func_0x0001800878a0(arg1, 2, 1);
                if (iVar9 != 0) {
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                }
                func_0x000180086fd0(arg1, 0, 0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *puVar2 = puVar2[-8];
                    puVar2[1] = puVar2[-7];
                    puVar2[2] = puVar2[-6];
                    puVar2[3] = puVar2[-5];
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
                    if (*(char *)(*(int64_t *)(puVar2 + -4) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(puVar2 + -4), 1);
                    uVar6 = puVar2[1];
                    uVar7 = puVar2[2];
                    uVar8 = puVar2[3];
                    *puVar11 = *puVar2;
                    puVar11[1] = uVar6;
                    puVar11[2] = uVar7;
                    puVar11[3] = uVar8;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar3 = *(int64_t *)(puVar2 + -4);
                        if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar4 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar4 + 0x59) == '\x02') {
                                func_0x000180094420(iVar4);
                            } else {
                                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                                *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                                *(int64_t *)(iVar4 + 0x18) = iVar3;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    return 1;
                }
            }
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        fcn.180088560(arg1, 0x180623d38);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    fcn.180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_18005084e
// Address: 0x18005084e
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800505a0(int64_t arg1)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar10 = uVar1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    uVar10 = uVar1 + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1 + 0x10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar10 + 0xc) == 6)) {
        func_0x000180086cc0(arg1, 1, 0x1805aaf20);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800867f0(arg1, 0x180621618, 0xd);
        var_18h = *(int64_t *)(arg1 + 0x40) + -0x30;
        var_10h._0_4_ = 1;
        iVar9 = func_0x000180094080(arg1, 0x180087890, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (iVar9 != 0) {
            fcn.180088560(arg1, 0x180623d60);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180086cc0(arg1, 0xffffffff, 0x180623d80);
        if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
           (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                *puVar2 = puVar2[-8];
                puVar2[1] = puVar2[-7];
                puVar2[2] = puVar2[-6];
                puVar2[3] = puVar2[-5];
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180085bf0(arg1, 2);
                iVar9 = func_0x0001800878a0(arg1, 2, 1);
                if (iVar9 != 0) {
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                }
                func_0x000180086fd0(arg1, 0, 0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *puVar2 = puVar2[-8];
                    puVar2[1] = puVar2[-7];
                    puVar2[2] = puVar2[-6];
                    puVar2[3] = puVar2[-5];
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
                    if (*(char *)(*(int64_t *)(puVar2 + -4) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(puVar2 + -4), 1);
                    uVar6 = puVar2[1];
                    uVar7 = puVar2[2];
                    uVar8 = puVar2[3];
                    *puVar11 = *puVar2;
                    puVar11[1] = uVar6;
                    puVar11[2] = uVar7;
                    puVar11[3] = uVar8;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar3 = *(int64_t *)(puVar2 + -4);
                        if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar4 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar4 + 0x59) == '\x02') {
                                func_0x000180094420(iVar4);
                            } else {
                                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                                *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                                *(int64_t *)(iVar4 + 0x18) = iVar3;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    return 1;
                }
            }
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        fcn.180088560(arg1, 0x180623d38);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    fcn.180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_18005086c
// Address: 0x18005086c
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800505a0(int64_t arg1)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    uint64_t uVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x28);
    uVar10 = uVar1;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    uVar10 = uVar1 + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar1 + 0x10) {
        uVar10 = *(uint64_t *)0x180782430;
    }
    if ((uVar10 != *(uint64_t *)0x180782430) && (*(int32_t *)(uVar10 + 0xc) == 6)) {
        func_0x000180086cc0(arg1, 1, 0x1805aaf20);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800867f0(arg1, 0x180621618, 0xd);
        var_18h = *(int64_t *)(arg1 + 0x40) + -0x30;
        var_10h._0_4_ = 1;
        iVar9 = func_0x000180094080(arg1, 0x180087890, &var_18h, var_18h - *(int64_t *)(arg1 + 0x38), 0);
        if (iVar9 != 0) {
            fcn.180088560(arg1, 0x180623d60);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        func_0x000180086cc0(arg1, 0xffffffff, 0x180623d80);
        if ((*(int64_t *)(arg1 + 0x40) - 0x10U != *(uint64_t *)0x180782430) &&
           (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 8)) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18)))
               || (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                puVar2 = *(undefined4 **)(arg1 + 0x40);
                *puVar2 = puVar2[-8];
                puVar2[1] = puVar2[-7];
                puVar2[2] = puVar2[-6];
                puVar2[3] = puVar2[-5];
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
                func_0x000180085bf0(arg1, 2);
                iVar9 = func_0x0001800878a0(arg1, 2, 1);
                if (iVar9 != 0) {
                    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
                }
                func_0x000180086fd0(arg1, 0, 0);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                if (((*(char *)0x180777010 == '\0') ||
                    (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
                   (iVar9 = fcn.180085510(CONCAT44(var_10h._4_4_, (undefined4)var_10h)), iVar9 != 0)) {
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *puVar2 = puVar2[-8];
                    puVar2[1] = puVar2[-7];
                    puVar2[2] = puVar2[-6];
                    puVar2[3] = puVar2[-5];
                    puVar2 = *(undefined4 **)(arg1 + 0x40);
                    *(undefined4 **)(arg1 + 0x40) = puVar2 + 4;
                    if (*(char *)(*(int64_t *)(puVar2 + -4) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar5 = (code *)swi(3);
                        uVar12 = (*pcVar5)();
                        return uVar12;
                    }
                    puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(puVar2 + -4), 1);
                    uVar6 = puVar2[1];
                    uVar7 = puVar2[2];
                    uVar8 = puVar2[3];
                    *puVar11 = *puVar2;
                    puVar11[1] = uVar6;
                    puVar11[2] = uVar7;
                    puVar11[3] = uVar8;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar3 = *(int64_t *)(puVar2 + -4);
                        if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar4 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar4 + 0x59) == '\x02') {
                                func_0x000180094420(iVar4);
                            } else {
                                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                                *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar4 + 0x18);
                                *(int64_t *)(iVar4 + 0x18) = iVar3;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    return 1;
                }
            }
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        fcn.180088560(arg1, 0x180623d38);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    fcn.180088470(arg1, 2, 6);
    pcVar5 = (code *)swi(3);
    uVar12 = (*pcVar5)();
    return uVar12;
}

// ============================================================
// Function: FUN_180050890
// Address: 0x180050890
// Size: 205 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 fcn.180050890(int64_t arg1)
{
    undefined uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)(arg1 + 0x50);
    fcn.180013530();
    iVar3 = *(int64_t *)(arg1 + 0x50);
    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) | 0x40;
    *(undefined4 *)(iVar3 + 0x88) = 2;
    *(undefined8 *)(iVar3 + 0x78) = 0x103fffffffffff00;
    puVar6 = (undefined4 *)(**(code **)0x180782558)(**(undefined8 **)0x180782610);
    if (puVar6 != (undefined4 *)0x0) {
        uVar4 = *(uint64_t *)(iVar3 + 0x78);
        *puVar6 = 2;
        *(uint64_t *)(puVar6 + 10) = uVar4 & 0xffffffffffffffc0;
        *(int64_t *)(puVar6 + 6) = arg1;
    }
    iVar2 = *(int64_t *)(iVar2 + 0x98);
    uVar1 = *(undefined *)(iVar2 + 0x828);
    *(undefined *)(iVar2 + 0x828) = 1;
    uVar5 = (**(code **)0x180782130)(arg1);
    *(undefined *)(iVar2 + 0x828) = uVar1;
    fcn.180013530();
    fcn.180013740();
    return uVar5;
}

// ============================================================
// Function: FUN_180050960
// Address: 0x180050960
// Size: 1582 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_43h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch

void fcn.180050960(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    if (*(int64_t *)0x180782130 == 0) {
        func_0x000180086cc0(arg2, 0xffffd8ee, 0x180623d58);
        piVar6 = (int64_t *)(*(int64_t *)(arg2 + 0x40) + -0x10);
        piVar5 = piVar6;
        if (piVar6 == *(int64_t **)0x180782430) {
            piVar5 = (int64_t *)0x0;
        }
        *(int64_t *)0x180782130 = *(int64_t *)(*piVar5 + 0x20);
        *(int64_t **)(arg2 + 0x40) = piVar6;
    }
    var_40h = 0;
    puVar3 = (undefined4 *)fcn.180459890(0x20);
    var_48h = (int64_t)puVar3;
    var_38h = 0x16;
    var_30h = 0x1f;
    *puVar3 = 0x6f636552;
    puVar3[1] = 0x6e456472;
    puVar3[2] = 0x656e6967;
    puVar3[3] = 0x4d697041;
    *(undefined8 *)((int64_t)puVar3 + 0xe) = 0x7363697274654d69;
    *(undefined *)((int64_t)puVar3 + 0x16) = 0;
    fcn.18004f780((int64_t)&var_58h, (int64_t)&var_48h);
    if ((uint64_t)var_30h < 0x10) {
code_r0x000180050a5a:
        puVar8 = auStack_b8;
        if ((char)var_50h == '\0') goto code_r0x000180050adc;
        var_38h = 5;
        var_30h = 0xf;
        stack0xffffffffffffffbe = SUB1610(ZEXT816(0), 6);
        var_48h._0_6_ = 0x65736c6166;
        fcn.18004f910(var_58h, (int64_t)&var_48h);
        puVar8 = auStack_b8;
        if ((uint64_t)var_30h < 0x10) goto code_r0x000180050adc;
        iVar4 = var_48h;
        puVar8 = auStack_b8;
        if ((0xfff < var_30h + 1U) &&
           (iVar4 = *(int64_t *)(var_48h + -8), puVar8 = auStack_b8, 0x1f < (var_48h - *(int64_t *)(var_48h + -8)) - 8U)
           ) goto code_r0x000180050acd;
    } else {
        uVar7 = var_30h + 1;
        iVar4 = var_48h;
        if (uVar7 < 0x1000) {
code_r0x000180050a55:
            func_0x000180459c3c(iVar4, uVar7);
            goto code_r0x000180050a5a;
        }
        if ((var_48h - *(int64_t *)(var_48h + -8)) - 8U < 0x20) {
            uVar7 = var_30h + 0x28;
            iVar4 = *(int64_t *)(var_48h + -8);
            goto code_r0x000180050a55;
        }
code_r0x000180050acd:
        pcVar2 = (code *)swi(0x29);
        iVar4 = (*pcVar2)(5);
        puVar8 = auStack_b0;
    }
    *(undefined8 *)(puVar8 + -8) = 0x180050adc;
    func_0x000180459c3c(iVar4);
code_r0x000180050adc:
    var_88h = 0x180623dd0;
    *(undefined8 *)(puVar8 + -8) = 0x180050aec;
    func_0x000180018f70();
    uVar7 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050b16;
    func_0x0001800869f0(arg2, fcn.18004ea30, 0x180623d90, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050b27;
    func_0x000180087370(arg2, uVar7 & 0xffffffff, 0x180623d90);
    piVar5 = &var_88h;
    do {
        *(undefined8 *)(puVar8 + -8) = 0x180050b41;
        func_0x000180086cc0(arg2, uVar7 & 0xffffffff, 0x180623d90);
        iVar4 = *(int64_t *)(arg2 + 0x40);
        if (((int64_t *)(iVar4 + -0x10) == *(int64_t **)0x180782430) || (*(int32_t *)(iVar4 + -4) != 0)) {
            iVar4 = *piVar5;
            *(undefined8 *)(puVar8 + -8) = 0x180050b6f;
            func_0x000180087370(arg2, uVar7 & 0xffffffff, iVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar4 + -0x10;
        }
        piVar5 = piVar5 + 1;
    } while (piVar5 != &var_80h);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050ba6;
    func_0x0001800869f0(arg2, fcn.18004eb50, 0x180623da8, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050bb7;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623da8);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050be1;
    func_0x0001800869f0(arg2, fcn.18004eae0, 0x180623e00, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050bf2;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623e00);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050c1c;
    func_0x0001800869f0(arg2, fcn.18004f100, 0x180623e08, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050c2d;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623e08);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050c57;
    func_0x0001800869f0(arg2, fcn.18004f150, 0x180623de0, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050c68;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623de0);
    var_78h = 0x180623df0;
    var_70h = 0x180623e40;
    uVar7 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050ca8;
    func_0x0001800869f0(arg2, fcn.18004ef90, 0x180623e50, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050cb9;
    func_0x000180087370(arg2, uVar7 & 0xffffffff, 0x180623e50);
    piVar5 = &var_78h;
    do {
        *(undefined8 *)(puVar8 + -8) = 0x180050cd1;
        func_0x000180086cc0(arg2, uVar7 & 0xffffffff, 0x180623e50);
        iVar4 = *(int64_t *)(arg2 + 0x40);
        if (((int64_t *)(iVar4 + -0x10) == *(int64_t **)0x180782430) || (*(int32_t *)(iVar4 + -4) != 0)) {
            iVar4 = *piVar5;
            *(undefined8 *)(puVar8 + -8) = 0x180050cff;
            func_0x000180087370(arg2, uVar7 & 0xffffffff, iVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar4 + -0x10;
        }
        piVar5 = piVar5 + 1;
    } while (piVar5 != &var_68h);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050d36;
    func_0x0001800869f0(arg2, fcn.18004f150, 0x180623de0, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050d47;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623de0);
    var_80h = 0x180623e18;
    uVar7 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050d7c;
    func_0x0001800869f0(arg2, fcn.18004f1c0, 0x180623e30, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050d8d;
    func_0x000180087370(arg2, uVar7 & 0xffffffff, 0x180623e30);
    piVar5 = &var_80h;
    do {
        *(undefined8 *)(puVar8 + -8) = 0x180050da2;
        func_0x000180086cc0(arg2, uVar7 & 0xffffffff, 0x180623e30);
        iVar4 = *(int64_t *)(arg2 + 0x40);
        if (((int64_t *)(iVar4 + -0x10) == *(int64_t **)0x180782430) || (*(int32_t *)(iVar4 + -4) != 0)) {
            iVar4 = *piVar5;
            *(undefined8 *)(puVar8 + -8) = 0x180050dd0;
            func_0x000180087370(arg2, uVar7 & 0xffffffff, iVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar4 + -0x10;
        }
        piVar5 = piVar5 + 1;
    } while (piVar5 != &var_78h);
    var_68h = 0x180623e88;
    var_60h = 0x180623ea0;
    uVar7 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050e1d;
    func_0x0001800869f0(arg2, fcn.18004f6f0, 0x180623e60, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050e2e;
    func_0x000180087370(arg2, uVar7 & 0xffffffff, 0x180623e60);
    piVar5 = &var_68h;
    do {
        *(undefined8 *)(puVar8 + -8) = 0x180050e43;
        func_0x000180086cc0(arg2, uVar7 & 0xffffffff, 0x180623e60);
        iVar4 = *(int64_t *)(arg2 + 0x40);
        if (((int64_t *)(iVar4 + -0x10) == *(int64_t **)0x180782430) || (*(int32_t *)(iVar4 + -4) != 0)) {
            iVar4 = *piVar5;
            *(undefined8 *)(puVar8 + -8) = 0x180050e71;
            func_0x000180087370(arg2, uVar7 & 0xffffffff, iVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar4 + -0x10;
        }
        piVar5 = piVar5 + 1;
    } while (piVar5 != &var_58h);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050ea8;
    func_0x0001800869f0(arg2, fcn.18004fab0, 0x180623e78, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050eb9;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623e78);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050ee3;
    func_0x0001800869f0(arg2, fcn.18004fe30, 0x180623eb8, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050ef4;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623eb8);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050f1e;
    func_0x0001800869f0(arg2, fcn.1800503c0, 0x180623ec8, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050f2f;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623ec8);
    iVar4 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    *(undefined8 *)(puVar8 + 0x20) = 0;
    *(undefined8 *)(puVar8 + -8) = 0x180050f59;
    func_0x0001800869f0(arg2, fcn.180050890, 0x180623d58, 0);
    *(undefined8 *)(puVar8 + -8) = 0x180050f6a;
    func_0x000180087370(arg2, iVar4 - iVar1 >> 4 & 0xffffffff, 0x180623d58);
    *(undefined8 *)(puVar8 + -8) = 0x180050f76;
    fcn.180459870(var_28h ^ (uint64_t)puVar8);
    return;
}

