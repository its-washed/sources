// Chunk 116 - 50 functions

// ============================================================
// Function: FUN_180192e6f
// Address: 0x180192e6f
// Size: 141 bytes
// ============================================================
undefined8 fcn.180192e6f(int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t in_RAX;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    
    iVar1 = (**(code **)(in_RAX + 0xc0))();
    if (iVar1 < 1) {
        return 1;
    }
    iVar3 = 0;
    iVar4 = 0;
    iVar1 = func_0x000180222010();
    if (0 < iVar1) {
        do {
            iVar2 = func_0x000180222340();
            iVar1 = iVar3 + 1;
            if (0x303 < *(int32_t *)(iVar2 + 0x2c)) {
                iVar1 = iVar3;
            }
            iVar3 = iVar1;
            iVar4 = iVar4 + 1;
            iVar1 = func_0x000180222010();
        } while (iVar4 < iVar1);
        if (iVar3 != 0) {
            return 1;
        }
    }
    func_0x000180229480();
    func_0x0001802295a0(0x1804a94a0, 0xd58, 0x1804a95d8);
    func_0x0001802296d0(0x14, 0xb9, 0);
    return 0;
}

// ============================================================
// Function: FUN_180192efc
// Address: 0x180192efc
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_40h

undefined8 fcn.180192e6f(int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t in_RAX;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    
    iVar1 = (**(code **)(in_RAX + 0xc0))();
    if (iVar1 < 1) {
        return 1;
    }
    iVar3 = 0;
    iVar4 = 0;
    iVar1 = func_0x000180222010();
    if (0 < iVar1) {
        do {
            iVar2 = func_0x000180222340();
            iVar1 = iVar3 + 1;
            if (0x303 < *(int32_t *)(iVar2 + 0x2c)) {
                iVar1 = iVar3;
            }
            iVar3 = iVar1;
            iVar4 = iVar4 + 1;
            iVar1 = func_0x000180222010();
        } while (iVar4 < iVar1);
        if (iVar3 != 0) {
            return 1;
        }
    }
    func_0x000180229480();
    func_0x0001802295a0(0x1804a94a0, 0xd58, 0x1804a95d8);
    func_0x0001802296d0(0x14, 0xb9, 0);
    return 0;
}

// ============================================================
// Function: FUN_180192f40
// Address: 0x180192f40
// Size: 36 bytes
// ============================================================
undefined8
fcn.180192f40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_a0h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    undefined8 uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = in_RCX[0x8c];
    uVar5 = *in_RCX;
    uVar1 = in_RCX[5];
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180233ac5;
    iVar3 = fcn.18045a350(uVar1);
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233ad6;
    fcn.180232b70();
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233ae1;
    iVar4 = fcn.18021f130(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&arg_50h + iVar3 + iVar2) = uVar6;
        *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = uVar5;
        *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b13;
        fcn.18021eaa0(iVar4, 1, 0, 3);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b18;
        fcn.180232660();
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b23;
        iVar4 = fcn.18021f130(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2));
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b47;
            fcn.18021ea30(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000088 + iVar3 + iVar2));
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b4c;
            fcn.1802336b0();
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b57;
            iVar4 = fcn.18021f130(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2));
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&arg_50h + iVar3 + iVar2) = uVar6;
                *(undefined8 *)((int64_t)&arg_48h + iVar3 + iVar2) = uVar5;
                *(undefined8 *)((int64_t)&arg_40h + iVar3 + iVar2) = 0;
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b82;
                fcn.18021eaa0(iVar4, 3, 0, 0);
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180233b87;
                fcn.1802203d0(*(int64_t *)((int64_t)&arg_40h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), 
                              *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                              *(int64_t *)((int64_t)&arg_70h + iVar3 + iVar2));
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180192fd0
// Address: 0x180192fd0
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180192fd0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t in_RCX;
    uint64_t in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180192fe0;
    iVar1 = fcn.18045a350();
    if (0x200 < in_R8) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180193008;
    fcn.180498030(in_RCX + 0x50);
    *(uint64_t *)(in_RCX + 8) = in_R8;
    return 1;
}

// ============================================================
// Function: FUN_180193020
// Address: 0x180193020
// Size: 88 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel

uint64_t fcn.180193020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a8h,
                      int64_t arg_b8h, int64_t arg_d0h, int64_t arg_120h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019302c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019304f;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193069. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x40))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x40));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 1;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019309e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801930b6;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)((int64_t)&arg_78h + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, (int64_t)&arg_90h + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            *(undefined8 *)((int64_t)&arg_d0h + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)((int64_t)&arg_b8h + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                iVar2 = *(int64_t *)((int64_t)&arg_a8h + iVar9 + iVar7 + iVar5);
                if (iVar2 != 0) {
                    *(undefined4 *)(iVar2 + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)((int64_t)&arg_38h + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, (int64_t)&arg_38h + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        func_0x0001802295a0(0x1804a94a0, 0x1384, 0x1804a9638);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        func_0x0001802296d0(0x14, 0x90, 0);
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180193078
// Address: 0x180193078
// Size: 67 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel

uint64_t fcn.180193020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a8h,
                      int64_t arg_b8h, int64_t arg_d0h, int64_t arg_120h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019302c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019304f;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193069. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x40))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x40));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 1;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019309e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801930b6;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)((int64_t)&arg_78h + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, (int64_t)&arg_90h + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            *(undefined8 *)((int64_t)&arg_d0h + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)((int64_t)&arg_b8h + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                iVar2 = *(int64_t *)((int64_t)&arg_a8h + iVar9 + iVar7 + iVar5);
                if (iVar2 != 0) {
                    *(undefined4 *)(iVar2 + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)((int64_t)&arg_38h + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, (int64_t)&arg_38h + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        func_0x0001802295a0(0x1804a94a0, 0x1384, 0x1804a9638);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        func_0x0001802296d0(0x14, 0x90, 0);
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801930bb
// Address: 0x1801930bb
// Size: 21 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel

uint64_t fcn.180193020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a8h,
                      int64_t arg_b8h, int64_t arg_d0h, int64_t arg_120h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019302c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019304f;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193069. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x40))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x40));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 1;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019309e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801930b6;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)((int64_t)&arg_78h + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, (int64_t)&arg_90h + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            *(undefined8 *)((int64_t)&arg_d0h + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)((int64_t)&arg_b8h + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                iVar2 = *(int64_t *)((int64_t)&arg_a8h + iVar9 + iVar7 + iVar5);
                if (iVar2 != 0) {
                    *(undefined4 *)(iVar2 + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)((int64_t)&arg_38h + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, (int64_t)&arg_38h + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        func_0x000180229480();
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        func_0x0001802295a0(0x1804a94a0, 0x1384, 0x1804a9638);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        func_0x0001802296d0(0x14, 0x90, 0);
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1801930d0
// Address: 0x1801930d0
// Size: 87 bytes
// ============================================================
undefined8 fcn.1801930d0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801930da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(int64_t *)(param_1 + 0x18) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801930eb;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180193103;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180193115;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180193124. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*(int64_t *)(param_1 + 0x18) + 0x20))();
    return uVar2;
}

// ============================================================
// Function: FUN_180193130
// Address: 0x180193130
// Size: 292 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.180193130(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_98h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t *piVar6;
    undefined8 uVar7;
    undefined4 *puVar8;
    int32_t *in_RCX;
    uint64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180193145;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019316b;
                piVar6 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar6 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193182;
            uVar7 = func_0x0001801be340(in_RCX, in_RDX);
            return uVar7;
        }
        if (piVar6 != (int32_t *)0x0) {
            *(uint64_t *)(piVar6 + 0x26a) = *(uint64_t *)(piVar6 + 0x26a) & ~in_RDX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801931b2;
            puVar8 = (undefined4 *)func_0x000180229cc0((int64_t)&var_18h + iVar5, 0x1804a9710, piVar6 + 0x26a);
            uVar2 = puVar8[1];
            uVar3 = puVar8[2];
            uVar4 = puVar8[3];
            *(undefined4 *)((int64_t)&arg_48h + iVar5) = *puVar8;
            *(undefined4 *)((int64_t)&arg_48h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000050 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000054 + iVar5) = uVar4;
            uVar2 = puVar8[5];
            uVar3 = puVar8[6];
            uVar4 = puVar8[7];
            *(undefined4 *)((int64_t)&arg_58h + iVar5) = puVar8[4];
            *(undefined4 *)((int64_t)&arg_58h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000060 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x00000064 + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_68h + iVar5) = *(undefined8 *)(puVar8 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801931d8;
            puVar8 = (undefined4 *)func_0x000180229ba0((int64_t)&var_18h + iVar5);
            uVar2 = puVar8[1];
            uVar3 = puVar8[2];
            uVar4 = puVar8[3];
            *(undefined4 *)((int64_t)&arg_70h + iVar5) = *puVar8;
            *(undefined4 *)((int64_t)&arg_70h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000078 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000007c + iVar5) = uVar4;
            uVar2 = puVar8[5];
            uVar3 = puVar8[6];
            uVar4 = puVar8[7];
            *(undefined4 *)((int64_t)&arg_80h + iVar5) = puVar8[4];
            *(undefined4 *)((int64_t)&arg_80h + iVar5 + 4) = uVar2;
            *(undefined4 *)(&stack0x00000088 + iVar5) = uVar3;
            *(undefined4 *)(&stack0x0000008c + iVar5) = uVar4;
            *(undefined8 *)((int64_t)&arg_90h + iVar5) = *(undefined8 *)(puVar8 + 8);
            pcVar1 = *(code **)(*(int64_t *)(piVar6 + 0x31a) + 0x90);
            uVar7 = *(undefined8 *)(piVar6 + 0x31e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193217;
            (*pcVar1)(uVar7, (int64_t)&arg_48h + iVar5);
            pcVar1 = *(code **)(*(int64_t *)(piVar6 + 0x31c) + 0x90);
            uVar7 = *(undefined8 *)(piVar6 + 800);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193234;
            (*pcVar1)(uVar7, (int64_t)&arg_48h + iVar5);
            return *(undefined8 *)(piVar6 + 0x26a);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193260
// Address: 0x180193260
// Size: 99 bytes
// ============================================================
int32_t fcn.180193260(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019326c;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar2 = param_1;
        if (*param_1 == 0) goto code_r0x00018019328f;
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18019328b;
            piVar2 = (int32_t *)func_0x0001801bda50();
            goto code_r0x00018019328f;
        }
    }
    piVar2 = (int32_t *)0x0;
code_r0x00018019328f:
    if ((*param_1 != 0x80) && (*param_1 != 0x81)) {
        if (piVar2 != (int32_t *)0x0) {
            return piVar2[0x273];
        }
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801932d0
// Address: 0x1801932d0
// Size: 88 bytes
// ============================================================
uint64_t fcn.1801932d0(int64_t arg_28h, int64_t arg_50h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801932dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801932ff;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193319. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x48))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x48));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 0;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019334e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193366;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)(&stack0x00000078 + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, &stack0x00000090 + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)(&stack0x00000090 + iVar9 + iVar7 + iVar5);
            *(undefined8 *)(&stack0x000000d0 + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)(&stack0x000000b8 + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                if (*(int64_t *)(&stack0x000000a8 + iVar9 + iVar7 + iVar5) != 0) {
                    *(undefined4 *)(*(int64_t *)(&stack0x000000a8 + iVar9 + iVar7 + iVar5) + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0(&stack0x00000090 + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)(&stack0x00000090 + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)(&stack0x00000038 + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])(&stack0x00000040 + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, &stack0x00000038 + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar7 + iVar5), *(int64_t *)(&stack0x00000040 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar7 + iVar5), *(int64_t *)(&stack0x00000040 + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar7 + iVar5));
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180193328
// Address: 0x180193328
// Size: 67 bytes
// ============================================================
uint64_t fcn.1801932d0(int64_t arg_28h, int64_t arg_50h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801932dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801932ff;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193319. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x48))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x48));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 0;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019334e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193366;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)(&stack0x00000078 + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, &stack0x00000090 + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)(&stack0x00000090 + iVar9 + iVar7 + iVar5);
            *(undefined8 *)(&stack0x000000d0 + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)(&stack0x000000b8 + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                if (*(int64_t *)(&stack0x000000a8 + iVar9 + iVar7 + iVar5) != 0) {
                    *(undefined4 *)(*(int64_t *)(&stack0x000000a8 + iVar9 + iVar7 + iVar5) + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0(&stack0x00000090 + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)(&stack0x00000090 + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)(&stack0x00000038 + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])(&stack0x00000040 + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, &stack0x00000038 + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar7 + iVar5), *(int64_t *)(&stack0x00000040 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar7 + iVar5), *(int64_t *)(&stack0x00000040 + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar7 + iVar5));
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18019336b
// Address: 0x18019336b
// Size: 21 bytes
// ============================================================
uint64_t fcn.1801932d0(int64_t arg_28h, int64_t arg_50h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801932dc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801932ff;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193319. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x48))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x48));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 0;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019334e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193366;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000030 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)(&stack0x00000078 + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, &stack0x00000090 + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)(&stack0x00000090 + iVar9 + iVar7 + iVar5);
            *(undefined8 *)(&stack0x000000d0 + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)(&stack0x000000b8 + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                if (*(int64_t *)(&stack0x000000a8 + iVar9 + iVar7 + iVar5) != 0) {
                    *(undefined4 *)(*(int64_t *)(&stack0x000000a8 + iVar9 + iVar7 + iVar5) + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0(&stack0x00000090 + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)(&stack0x00000090 + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)(&stack0x00000038 + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])(&stack0x00000040 + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, &stack0x00000038 + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        fcn.180229480(*(int64_t *)(&stack0x00000038 + iVar7 + iVar5), *(int64_t *)(&stack0x00000040 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        fcn.1802295a0(*(int64_t *)(&stack0x00000038 + iVar7 + iVar5), *(int64_t *)(&stack0x00000040 + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar7 + iVar5));
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180193380
// Address: 0x180193380
// Size: 31 bytes
// ============================================================
void fcn.180193380(void)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019338a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019339a;
    fcn.1801957d0(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1), 
                  *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000088 + iVar1), 
                  *(int64_t *)(&stack0x00000090 + iVar1), *(int64_t *)(&stack0x000000d0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801933a0
// Address: 0x1801933a0
// Size: 339 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_c4h because it doesn't fit into ProtoModel

uint64_t fcn.180193020(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_78h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a8h,
                      int64_t arg_b8h, int64_t arg_d0h, int64_t arg_120h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 uVar10;
    undefined4 extraout_XMM0_Da;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x18019302c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar8 = in_RCX;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019304f;
            piVar8 = (int32_t *)func_0x0001801bda50();
        } else {
            piVar8 = (int32_t *)0x0;
        }
    }
    iVar3 = *in_RCX;
    if ((char)iVar3 < '\0') {
    // WARNING: Could not recover jumptable at 0x000180193069. Too many branches
    // WARNING: Treating indirect jump as call
        uVar6 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x40))(in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x40));
        return uVar6;
    }
    if (piVar8 == (int32_t *)0x0) {
        return 0;
    }
    if (*(int64_t *)(piVar8 + 0x1c) == 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
        piVar8 = (int32_t *)0x0;
        if (iVar3 == 0) {
            piVar8 = in_RCX;
        }
        piVar8[0x1e] = 1;
        piVar8[0x21] = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019309e;
        func_0x00018019b4f0(piVar8);
        *(undefined8 *)(piVar8 + 0x1c) = *(undefined8 *)(*(int64_t *)(in_RCX + 6) + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801930b6;
        func_0x0001801a2fd0(piVar8 + 0x314);
        unaff_RBX = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    }
    uVar10 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = uVar10;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5) = 0x1801933b5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (in_RCX != (int32_t *)0x0) {
        piVar8 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801933d9;
                piVar8 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar8 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar10 = *(undefined8 *)((int64_t)&arg_78h + iVar7 + iVar5);
            *(undefined8 *)(&stack0x00000068 + iVar7 + iVar5) = 0x1801bedca;
            iVar9 = fcn.18045a350(in_RCX);
            iVar9 = -iVar9;
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801beddd;
            uVar6 = func_0x0001801bdce0(extraout_XMM0_Da, (int64_t)&arg_90h + iVar9 + iVar7 + iVar5, 3);
            if ((int32_t)uVar6 == 0) {
                return uVar6;
            }
            iVar2 = *(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            *(undefined8 *)((int64_t)&arg_d0h + iVar9 + iVar7 + iVar5) = uVar10;
            uVar10 = *(undefined8 *)(iVar2 + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bedf9;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee01;
            func_0x00018026d890(uVar10);
            iVar3 = *(int32_t *)((int64_t)&arg_b8h + iVar9 + iVar7 + iVar5);
            *(undefined4 *)(&stack0x000000c4 + iVar9 + iVar7 + iVar5) = 1;
            if (iVar3 == 0) {
                iVar2 = *(int64_t *)((int64_t)&arg_a8h + iVar9 + iVar7 + iVar5);
                if (iVar2 != 0) {
                    *(undefined4 *)(iVar2 + 0x128) = 0;
                }
            } else if (*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) != 0) {
                *(undefined4 *)(*(int64_t *)(&stack0x000000b0 + iVar9 + iVar7 + iVar5) + 0xb8) = 0;
            }
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee44;
            uVar4 = func_0x0001801c0be0((int64_t)&arg_90h + iVar9 + iVar7 + iVar5);
            uVar10 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_90h + iVar9 + iVar7 + iVar5) + 0x58);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee54;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)(&stack0x00000068 + iVar9 + iVar7 + iVar5) = 0x1801bee5c;
            func_0x00018026d900(uVar10);
            return (uint64_t)uVar4;
        }
        if (piVar8 == (int32_t *)0x0) {
            return 0xffffffff;
        }
        if (*(int64_t *)(piVar8 + 0x1c) != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193459;
            iVar3 = func_0x00018019b3c0(piVar8, 0xffffffff);
            if (iVar3 == 0) {
                return 0xffffffff;
            }
            pcVar1 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x78);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019346d;
            (*pcVar1)(in_RCX, 0);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193475;
            iVar3 = func_0x00018019b2a0(in_RCX);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193481;
                iVar3 = func_0x00018019b250(in_RCX);
                if (iVar3 == 0) {
                    return 1;
                }
            }
            if ((piVar8[0x26c] & 0x100U) != 0) {
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193496;
                iVar9 = func_0x0001802395d0();
                if (iVar9 == 0) {
                    *(int32_t **)((int64_t)&arg_38h + iVar7 + iVar5) = in_RCX;
                    *(undefined (*) [16])((int64_t)&arg_40h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined (*) [16])((int64_t)&arg_50h + iVar7 + iVar5) = ZEXT816(0);
                    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934c6;
                    uVar6 = func_0x000180198150(in_RCX, (int64_t)&arg_38h + iVar7 + iVar5, 0x180197370);
                    return uVar6;
                }
            }
            pcVar1 = *(code **)(piVar8 + 0x1c);
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x1801934df;
            uVar4 = (*pcVar1)(in_RCX);
            return (uint64_t)uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x18019340d;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193425;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_40h + iVar7 + iVar5), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar5), *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar5), 
                      *(int64_t *)(&stack0x00000068 + iVar7 + iVar5));
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar5) = 0x180193437;
        fcn.1802296d0(*(int64_t *)(&stack0x00000058 + iVar7 + iVar5));
        return 0xffffffff;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180193500
// Address: 0x180193500
// Size: 111 bytes
// ============================================================
void fcn.180193500(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180193510;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            if (*(int64_t *)(arg1 + 0x18) != 0) {
                pcVar3 = *(code **)(*(int64_t *)(arg1 + 0x18) + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193534;
                (*pcVar3)();
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193542;
            fcn.180223fb0(*(int64_t *)(&stack0x00000098 + iVar5), *(int64_t *)(&stack0x00000100 + iVar5));
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019354b;
            fcn.180191f00(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5));
            uVar4 = *(undefined8 *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193554;
            fcn.1802227d0(uVar4);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193569;
            fcn.180224990(arg1, 0x1804a94a0, 0x5aa);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180193570
// Address: 0x180193570
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180193570(int64_t arg_28h)
{
    int64_t iVar1;
    int32_t *in_RCX;
    int64_t *in_RDX;
    int32_t *in_R8;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180193580;
    iVar1 = fcn.18045a350();
    if (in_RCX != (int32_t *)0x0) {
        if (*in_RCX == 0) {
code_r0x0001801935a5:
            iVar1 = *(int64_t *)(in_RCX + 0x12e);
            *in_RDX = iVar1;
            if (iVar1 == 0) {
                *in_R8 = 0;
                return;
            }
            *in_R8 = in_RCX[0x130];
            return;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18019359d;
            in_RCX = (int32_t *)func_0x0001801bda50();
            if (in_RCX != (int32_t *)0x0) goto code_r0x0001801935a5;
        }
    }
    *in_RDX = 0;
    *in_R8 = 0;
    return;
}

// ============================================================
// Function: FUN_1801935f0
// Address: 0x1801935f0
// Size: 66 bytes
// ============================================================
undefined8 fcn.1801935f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801935fc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019361e;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    iVar2 = in_RCX[0x2e0];
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
    if (iVar2 == 0) {
        if (*(int64_t *)(in_RCX + 0x28a) == 0) {
code_r0x0001801936a5:
            iVar7 = 0;
            iVar2 = 0;
            if (*(int64_t *)(in_RCX + 0x296) != 0) {
                iVar9 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936c2;
                iVar3 = func_0x000180222010();
                iVar2 = 0;
                iVar4 = 0;
                if (0 < iVar3) {
                    do {
                        iVar2 = iVar4;
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936df;
                        iVar7 = func_0x000180222340(uVar6, iVar9);
                        if (iVar7 == 0) {
                            iVar7 = 0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936f0;
                        iVar7 = func_0x00018023f020(iVar7);
                        if (iVar7 == 0) break;
                        iVar3 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193706;
                        iVar4 = func_0x00018023eea0(iVar7);
                        if (0 < iVar4) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019371a;
                                iVar8 = func_0x00018023eff0(iVar7, iVar3);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193732;
                                    iVar8 = func_0x0001802393e0(iVar8, 0x3ba, 0, 0);
                                    if (iVar8 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019374f;
                                        iVar4 = func_0x000180195140(in_RCX + 0x2de, iVar8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193759;
                                        func_0x00018023a130(iVar8);
                                        if (-1 < iVar4) {
                                            iVar2 = iVar2 + iVar4;
                                            goto code_r0x000180193760;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019379a;
                                    func_0x00018023f190(iVar7);
                                    goto code_r0x00018019379a;
                                }
code_r0x000180193760:
                                iVar3 = iVar3 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019376a;
                                iVar4 = func_0x00018023eea0(iVar7);
                            } while (iVar3 < iVar4);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193776;
                        func_0x00018023f190(iVar7);
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        iVar7 = 0;
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193787;
                        iVar3 = func_0x000180222010(uVar6);
                        iVar4 = iVar2;
                    } while (iVar9 < iVar3);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937cb;
            func_0x00018023f190(iVar7);
            if (-1 < iVar2) {
                if ((*(int64_t *)(in_RCX + 0x23e) != 0) &&
                   (iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x23e) + 0x2c0), iVar7 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937f8;
                    uVar6 = func_0x0001802394c0(iVar7, 0x3b7, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193810;
                    iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019381a;
                    func_0x00018023a130(uVar6);
                    if (iVar2 < 0) goto code_r0x00018019379a;
                }
                in_RCX[0x2e0] = 1;
                goto code_r0x00018019382d;
            }
        } else {
            uVar1 = *(undefined2 *)(in_RCX + 0x28c);
            *(int64_t *)((int64_t)&arg_48h + iVar5) = *(int64_t *)(in_RCX + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019367b;
            uVar6 = func_0x00018023af80(0, (int64_t)&arg_48h + iVar5, uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193693;
            iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019369d;
            func_0x00018023a130(uVar6);
            if (-1 < iVar2) goto code_r0x0001801936a5;
        }
code_r0x00018019379a:
        uVar6 = 0;
    } else {
code_r0x00018019382d:
        uVar6 = *(undefined8 *)(in_RCX + 0x2de);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180193632
// Address: 0x180193632
// Size: 399 bytes
// ============================================================
undefined8 fcn.1801935f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801935fc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019361e;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    iVar2 = in_RCX[0x2e0];
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
    if (iVar2 == 0) {
        if (*(int64_t *)(in_RCX + 0x28a) == 0) {
code_r0x0001801936a5:
            iVar7 = 0;
            iVar2 = 0;
            if (*(int64_t *)(in_RCX + 0x296) != 0) {
                iVar9 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936c2;
                iVar3 = func_0x000180222010();
                iVar2 = 0;
                iVar4 = 0;
                if (0 < iVar3) {
                    do {
                        iVar2 = iVar4;
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936df;
                        iVar7 = func_0x000180222340(uVar6, iVar9);
                        if (iVar7 == 0) {
                            iVar7 = 0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936f0;
                        iVar7 = func_0x00018023f020(iVar7);
                        if (iVar7 == 0) break;
                        iVar3 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193706;
                        iVar4 = func_0x00018023eea0(iVar7);
                        if (0 < iVar4) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019371a;
                                iVar8 = func_0x00018023eff0(iVar7, iVar3);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193732;
                                    iVar8 = func_0x0001802393e0(iVar8, 0x3ba, 0, 0);
                                    if (iVar8 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019374f;
                                        iVar4 = func_0x000180195140(in_RCX + 0x2de, iVar8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193759;
                                        func_0x00018023a130(iVar8);
                                        if (-1 < iVar4) {
                                            iVar2 = iVar2 + iVar4;
                                            goto code_r0x000180193760;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019379a;
                                    func_0x00018023f190(iVar7);
                                    goto code_r0x00018019379a;
                                }
code_r0x000180193760:
                                iVar3 = iVar3 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019376a;
                                iVar4 = func_0x00018023eea0(iVar7);
                            } while (iVar3 < iVar4);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193776;
                        func_0x00018023f190(iVar7);
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        iVar7 = 0;
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193787;
                        iVar3 = func_0x000180222010(uVar6);
                        iVar4 = iVar2;
                    } while (iVar9 < iVar3);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937cb;
            func_0x00018023f190(iVar7);
            if (-1 < iVar2) {
                if ((*(int64_t *)(in_RCX + 0x23e) != 0) &&
                   (iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x23e) + 0x2c0), iVar7 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937f8;
                    uVar6 = func_0x0001802394c0(iVar7, 0x3b7, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193810;
                    iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019381a;
                    func_0x00018023a130(uVar6);
                    if (iVar2 < 0) goto code_r0x00018019379a;
                }
                in_RCX[0x2e0] = 1;
                goto code_r0x00018019382d;
            }
        } else {
            uVar1 = *(undefined2 *)(in_RCX + 0x28c);
            *(int64_t *)((int64_t)&arg_48h + iVar5) = *(int64_t *)(in_RCX + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019367b;
            uVar6 = func_0x00018023af80(0, (int64_t)&arg_48h + iVar5, uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193693;
            iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019369d;
            func_0x00018023a130(uVar6);
            if (-1 < iVar2) goto code_r0x0001801936a5;
        }
code_r0x00018019379a:
        uVar6 = 0;
    } else {
code_r0x00018019382d:
        uVar6 = *(undefined8 *)(in_RCX + 0x2de);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_1801937c1
// Address: 0x1801937c1
// Size: 120 bytes
// ============================================================
undefined8 fcn.1801935f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801935fc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019361e;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    iVar2 = in_RCX[0x2e0];
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
    if (iVar2 == 0) {
        if (*(int64_t *)(in_RCX + 0x28a) == 0) {
code_r0x0001801936a5:
            iVar7 = 0;
            iVar2 = 0;
            if (*(int64_t *)(in_RCX + 0x296) != 0) {
                iVar9 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936c2;
                iVar3 = func_0x000180222010();
                iVar2 = 0;
                iVar4 = 0;
                if (0 < iVar3) {
                    do {
                        iVar2 = iVar4;
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936df;
                        iVar7 = func_0x000180222340(uVar6, iVar9);
                        if (iVar7 == 0) {
                            iVar7 = 0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936f0;
                        iVar7 = func_0x00018023f020(iVar7);
                        if (iVar7 == 0) break;
                        iVar3 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193706;
                        iVar4 = func_0x00018023eea0(iVar7);
                        if (0 < iVar4) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019371a;
                                iVar8 = func_0x00018023eff0(iVar7, iVar3);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193732;
                                    iVar8 = func_0x0001802393e0(iVar8, 0x3ba, 0, 0);
                                    if (iVar8 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019374f;
                                        iVar4 = func_0x000180195140(in_RCX + 0x2de, iVar8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193759;
                                        func_0x00018023a130(iVar8);
                                        if (-1 < iVar4) {
                                            iVar2 = iVar2 + iVar4;
                                            goto code_r0x000180193760;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019379a;
                                    func_0x00018023f190(iVar7);
                                    goto code_r0x00018019379a;
                                }
code_r0x000180193760:
                                iVar3 = iVar3 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019376a;
                                iVar4 = func_0x00018023eea0(iVar7);
                            } while (iVar3 < iVar4);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193776;
                        func_0x00018023f190(iVar7);
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        iVar7 = 0;
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193787;
                        iVar3 = func_0x000180222010(uVar6);
                        iVar4 = iVar2;
                    } while (iVar9 < iVar3);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937cb;
            func_0x00018023f190(iVar7);
            if (-1 < iVar2) {
                if ((*(int64_t *)(in_RCX + 0x23e) != 0) &&
                   (iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x23e) + 0x2c0), iVar7 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937f8;
                    uVar6 = func_0x0001802394c0(iVar7, 0x3b7, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193810;
                    iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019381a;
                    func_0x00018023a130(uVar6);
                    if (iVar2 < 0) goto code_r0x00018019379a;
                }
                in_RCX[0x2e0] = 1;
                goto code_r0x00018019382d;
            }
        } else {
            uVar1 = *(undefined2 *)(in_RCX + 0x28c);
            *(int64_t *)((int64_t)&arg_48h + iVar5) = *(int64_t *)(in_RCX + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019367b;
            uVar6 = func_0x00018023af80(0, (int64_t)&arg_48h + iVar5, uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193693;
            iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019369d;
            func_0x00018023a130(uVar6);
            if (-1 < iVar2) goto code_r0x0001801936a5;
        }
code_r0x00018019379a:
        uVar6 = 0;
    } else {
code_r0x00018019382d:
        uVar6 = *(undefined8 *)(in_RCX + 0x2de);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180193839
// Address: 0x180193839
// Size: 9 bytes
// ============================================================
undefined8 fcn.1801935f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar9;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801935fc;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019361e;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    iVar2 = in_RCX[0x2e0];
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)&var_20h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&var_18h + iVar5) = unaff_R15;
    if (iVar2 == 0) {
        if (*(int64_t *)(in_RCX + 0x28a) == 0) {
code_r0x0001801936a5:
            iVar7 = 0;
            iVar2 = 0;
            if (*(int64_t *)(in_RCX + 0x296) != 0) {
                iVar9 = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936c2;
                iVar3 = func_0x000180222010();
                iVar2 = 0;
                iVar4 = 0;
                if (0 < iVar3) {
                    do {
                        iVar2 = iVar4;
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936df;
                        iVar7 = func_0x000180222340(uVar6, iVar9);
                        if (iVar7 == 0) {
                            iVar7 = 0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801936f0;
                        iVar7 = func_0x00018023f020(iVar7);
                        if (iVar7 == 0) break;
                        iVar3 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193706;
                        iVar4 = func_0x00018023eea0(iVar7);
                        if (0 < iVar4) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019371a;
                                iVar8 = func_0x00018023eff0(iVar7, iVar3);
                                if (iVar8 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193732;
                                    iVar8 = func_0x0001802393e0(iVar8, 0x3ba, 0, 0);
                                    if (iVar8 != 0) {
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019374f;
                                        iVar4 = func_0x000180195140(in_RCX + 0x2de, iVar8);
                                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193759;
                                        func_0x00018023a130(iVar8);
                                        if (-1 < iVar4) {
                                            iVar2 = iVar2 + iVar4;
                                            goto code_r0x000180193760;
                                        }
                                    }
                                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019379a;
                                    func_0x00018023f190(iVar7);
                                    goto code_r0x00018019379a;
                                }
code_r0x000180193760:
                                iVar3 = iVar3 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019376a;
                                iVar4 = func_0x00018023eea0(iVar7);
                            } while (iVar3 < iVar4);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193776;
                        func_0x00018023f190(iVar7);
                        uVar6 = *(undefined8 *)(in_RCX + 0x296);
                        iVar7 = 0;
                        iVar9 = iVar9 + 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193787;
                        iVar3 = func_0x000180222010(uVar6);
                        iVar4 = iVar2;
                    } while (iVar9 < iVar3);
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937cb;
            func_0x00018023f190(iVar7);
            if (-1 < iVar2) {
                if ((*(int64_t *)(in_RCX + 0x23e) != 0) &&
                   (iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 0x23e) + 0x2c0), iVar7 != 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801937f8;
                    uVar6 = func_0x0001802394c0(iVar7, 0x3b7, 0, 0);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193810;
                    iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 2);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019381a;
                    func_0x00018023a130(uVar6);
                    if (iVar2 < 0) goto code_r0x00018019379a;
                }
                in_RCX[0x2e0] = 1;
                goto code_r0x00018019382d;
            }
        } else {
            uVar1 = *(undefined2 *)(in_RCX + 0x28c);
            *(int64_t *)((int64_t)&arg_48h + iVar5) = *(int64_t *)(in_RCX + 0x28a);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019367b;
            uVar6 = func_0x00018023af80(0, (int64_t)&arg_48h + iVar5, uVar1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180193693;
            iVar2 = func_0x000180195140(in_RCX + 0x2de, uVar6, 1);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18019369d;
            func_0x00018023a130(uVar6);
            if (-1 < iVar2) goto code_r0x0001801936a5;
        }
code_r0x00018019379a:
        uVar6 = 0;
    } else {
code_r0x00018019382d:
        uVar6 = *(undefined8 *)(in_RCX + 0x2de);
    }
    return uVar6;
}

// ============================================================
// Function: FUN_180193850
// Address: 0x180193850
// Size: 101 bytes
// ============================================================
int64_t fcn.180193850(int32_t *param_1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x18019385c;
    iVar3 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180193879;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(int64_t *)(param_1 + 0x23e) == 0) {
        return 0;
    }
    iVar1 = *(int64_t *)(*(int64_t *)(param_1 + 0x23e) + 0x2c0);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18019389e;
        iVar2 = func_0x0001802375f0(iVar1);
        if (iVar2 == 0) {
            return 0;
        }
        return iVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801938c0
// Address: 0x1801938c0
// Size: 307 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801938c0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    int64_t iVar7;
    uint32_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    uint64_t uVar9;
    
    uStack_10 = 0x1801938e0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar6 = 0;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    piVar3 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193909;
        piVar3 = (int32_t *)func_0x0001801bda50();
        if (piVar3 == (int32_t *)0x0) {
            return 0;
        }
    }
    piVar4 = in_RCX;
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193930;
        piVar4 = (int32_t *)func_0x0001801bda50(in_RCX);
        if (piVar4 == (int32_t *)0x0) {
            return 0;
        }
    }
    iVar7 = *(int64_t *)(piVar4 + 0x156);
    if ((iVar7 != 0) ||
       ((*(int64_t *)(in_RCX + 2) != 0 && (iVar7 = *(int64_t *)(*(int64_t *)(in_RCX + 2) + 0x10), iVar7 != 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193963;
        iVar1 = func_0x0001801a9160(piVar3);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193971;
            iVar1 = func_0x000180222010(iVar7);
            uVar9 = uVar6;
            if (iVar1 < 1) {
                return 0;
            }
            do {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18019397f;
                uVar5 = func_0x000180222340(iVar7, uVar9);
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193996;
                iVar1 = func_0x0001801a85b0(piVar3, uVar5, 0x10001, 0);
                if (iVar1 == 0) {
                    if (uVar6 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801939a4;
                        uVar6 = func_0x000180221f20();
                        if (uVar6 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801939b7;
                    iVar1 = func_0x000180222110(uVar6, uVar5);
                    if (iVar1 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801939d6;
                        func_0x000180221d50(uVar6);
                        return 0;
                    }
                }
                uVar8 = (int32_t)uVar9 + 1;
                uVar9 = (uint64_t)uVar8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801939c5;
                iVar1 = func_0x000180222010(iVar7);
                if (iVar1 <= (int32_t)uVar8) {
                    return uVar6;
                }
            } while( true );
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193a00
// Address: 0x180193a00
// Size: 74 bytes
// ============================================================
undefined8 fcn.180193a00(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180193a0a;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180193a27;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(undefined8 **)(param_1 + 0x21e) == (undefined8 *)0x0) {
        return 0;
    }
    return *(undefined8 *)**(undefined8 **)(param_1 + 0x21e);
}

// ============================================================
// Function: FUN_180193a50
// Address: 0x180193a50
// Size: 87 bytes
// ============================================================
int64_t fcn.180193a50(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180193a5c;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    piVar2 = param_1;
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180193a7b;
        piVar2 = (int32_t *)func_0x0001801bda50();
        if (piVar2 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(int64_t *)(piVar2 + 0x156) != 0) {
        return *(int64_t *)(piVar2 + 0x156);
    }
    if (*(int64_t *)(param_1 + 2) == 0) {
        return 0;
    }
    return *(int64_t *)(*(int64_t *)(param_1 + 2) + 0x10);
}

// ============================================================
// Function: FUN_180193ab0
// Address: 0x180193ab0
// Size: 75 bytes
// ============================================================
undefined8 fcn.180193ab0(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180193aba;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180193ad7;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(int64_t *)(param_1 + 0x23e) == 0) {
        return 0;
    }
    return *(undefined8 *)(*(int64_t *)(param_1 + 0x23e) + 0x2f8);
}

// ============================================================
// Function: FUN_180193b00
// Address: 0x180193b00
// Size: 28 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling

uint64_t fcn.180193b00(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                      int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    uint64_t uVar6;
    undefined8 uVar7;
    int32_t *piVar8;
    int32_t *in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar2 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180196bd0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
code_r0x000180196bfb:
        piVar5 = (int32_t *)0x0;
    } else {
        piVar5 = in_RCX;
        if (*in_RCX != 0) {
            if (-1 < (char)*in_RCX) goto code_r0x000180196bfb;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196bf6;
            piVar5 = (int32_t *)func_0x0001801bda50();
        }
    }
    if (0 < in_EDX) {
        return 0;
    }
    if ((in_RCX != (int32_t *)0x0) && ((*(uint8_t *)in_RCX & 0x80) != 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196c1a;
        uVar6 = func_0x0001801bf220(in_RCX, in_EDX);
        if ((int32_t)uVar6 != 0) {
            return uVar6;
        }
    }
    if (piVar5 == (int32_t *)0x0) {
        return 1;
    }
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196c2d;
        uVar1 = func_0x000180220920();
        if (uVar1 != 0) {
            if ((int32_t)uVar1 < 0) {
                return 5;
            }
            if ((uVar1 & 0x7f800000) == 0x1000000) {
                return 5;
            }
            return 1;
        }
    }
    if (in_RCX == (int32_t *)0x0) {
code_r0x000180196cda:
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196ce2;
        iVar2 = func_0x000180194f30(in_RCX);
        if (iVar2 == 2) {
            uVar7 = *(undefined8 *)(piVar5 + 0x16);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196cf5;
            iVar2 = func_0x00018021b270(uVar7, 2);
            if (iVar2 != 0) {
                return 3;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196d10;
            iVar2 = func_0x00018021b270(uVar7, 1);
            if (iVar2 != 0) {
                return 2;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196d2b;
            iVar2 = func_0x00018021b270(uVar7, 4);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196d37;
                iVar2 = func_0x000180182b10(uVar7);
joined_r0x000180196d3a:
                if (iVar2 == 2) {
                    return 7;
                }
                if (iVar2 != 3) {
                    return 5;
                }
                return 8;
            }
        }
        if (in_RCX == (int32_t *)0x0) goto code_r0x000180196d95;
    } else if (-1 < (char)*in_RCX) {
        if ((*in_RCX == 0) && (in_RCX[0x1a] == 3)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196c88;
            uVar7 = func_0x000180193c40(in_RCX);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196c98;
            iVar2 = func_0x00018021b270(uVar7, 1);
            if (iVar2 != 0) {
                return 2;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196ca9;
            iVar2 = func_0x00018021b270(uVar7, 2);
            if (iVar2 != 0) {
                return 3;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196cba;
            iVar2 = func_0x00018021b270(uVar7, 4);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196cc6;
                iVar2 = func_0x000180182b10(uVar7);
                goto joined_r0x000180196d3a;
            }
        }
        goto code_r0x000180196cda;
    }
    piVar8 = in_RCX;
    if ((*in_RCX != 0) && (piVar8 = (int32_t *)0x0, (char)*in_RCX < '\0')) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196d71;
        piVar8 = (int32_t *)func_0x0001801bda50(in_RCX);
    }
    if ((*(uint8_t *)in_RCX & 0x80) == 0) {
        if (piVar8 == (int32_t *)0x0) goto code_r0x000180196d95;
        uVar6 = (uint64_t)(uint32_t)piVar8[0x1a];
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196d81;
        uVar6 = func_0x0001801bff00(in_RCX);
    }
    if ((int32_t)uVar6 == 4) {
        return uVar6;
    }
code_r0x000180196d95:
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196d9d;
    iVar2 = func_0x000180194f30(in_RCX);
    if (iVar2 == 8) {
        return 0xc;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196db4;
    iVar2 = func_0x000180194f30(in_RCX);
    if (iVar2 == 5) {
        return 9;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196dcb;
    iVar2 = func_0x000180194f30(in_RCX);
    if (iVar2 == 6) {
        return 10;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180196de2;
    iVar2 = func_0x000180194f30(in_RCX);
    if (iVar2 != 7) {
        if ((*(uint8_t *)(piVar5 + 0x21) & 2) == 0) {
            return 5;
        }
        return (uint64_t)(6 - (piVar5[0x6f] != 0));
    }
    return 0xb;
}

// ============================================================
// Function: FUN_180193b20
// Address: 0x180193b20
// Size: 26 bytes
// ============================================================
undefined8 fcn.180193b20(int64_t arg_30h, int64_t arg_50h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    in_RCX = in_RCX + 0x30;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802241e0;
    iVar4 = fcn.18045a350();
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + (iVar3 - iVar4)) = 0x1802241f6;
        iVar2 = fcn.180222010();
        if (in_EDX < iVar2) {
            piVar1 = *(int32_t **)(in_RCX + 8);
            if (((piVar1 != (int32_t *)0x0) && (-1 < in_EDX)) && (in_EDX < *piVar1)) {
                return *(undefined8 *)(*(int64_t *)(piVar1 + 2) + (int64_t)in_EDX * 8);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193b40
// Address: 0x180193b40
// Size: 91 bytes
// ============================================================
undefined8
fcn.180193b40(int64_t arg_60h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_b0h, int64_t arg_b8h,
             int64_t arg_c0h, int64_t arg_e8h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int32_t *in_RCX;
    uint64_t uVar7;
    undefined8 uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar9;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180193b4c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180193b6b;
                piVar4 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar4 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            uVar8 = *(undefined8 *)((int64_t)auStackX_18 + iVar3);
            *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801bf2da;
            iVar5 = fcn.18045a350(in_RCX);
            iVar5 = -iVar5;
            iVar1 = iVar5 + iVar3 + 0x18;
            uVar9 = 0;
            uVar7 = 0;
            *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar3) = unaff_RSI;
            *(undefined8 *)(&stack0x00000040 + iVar5 + iVar3 + 0x18 + -0x18) = unaff_RDI;
            *(undefined8 *)(&stack0x00000038 + iVar5 + iVar3) = 0x1801c1130;
            iVar3 = fcn.18045a350();
            iVar3 = -iVar3;
            *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c1149;
            iVar2 = func_0x0001801bdce0();
            if (iVar2 != 0) {
                iVar5 = *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar1 + -0x18);
                *(undefined8 *)((int64_t)&arg_b0h + iVar3 + iVar1 + -0x18) = uVar8;
                uVar8 = *(undefined8 *)(iVar5 + 0x58);
                *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c1170;
                uVar8 = func_0x0001801dd6c0(uVar8);
                *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c1178;
                func_0x00018026d890(uVar8);
                if (*(int32_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x18) == 0) {
                    *(undefined8 *)((int64_t)&arg_b8h + iVar3 + iVar1 + -0x18) = unaff_RBP;
                    *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c11a8;
                    fcn.180193130(*(int64_t *)((int64_t)&arg_80h + iVar3 + iVar1 + -0x18), 
                                  *(int64_t *)(&stack0x00000090 + iVar3 + iVar1 + -0x18), 
                                  *(int64_t *)(&stack0x000000a0 + iVar3 + iVar1 + -0x18), 
                                  *(int64_t *)(&stack0x000000a8 + iVar3 + iVar1 + -0x18), 
                                  *(int64_t *)((int64_t)&arg_b8h + iVar3 + iVar1 + -0x18), 
                                  *(int64_t *)(&stack0x000000c8 + iVar3 + iVar1 + -0x18), 
                                  *(int64_t *)(&stack0x000000d0 + iVar3 + iVar1 + -0x18));
                    uVar8 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_78h + iVar3 + iVar1 + -0x18) + 0x78);
                    *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c11bc;
                    func_0x000180194b20(uVar8, uVar9 & 0x3df6ffb85);
                    iVar5 = *(int64_t *)((int64_t)&arg_78h + iVar3 + iVar1 + -0x18);
                    *(uint64_t *)(iVar5 + 0x110) = (*(uint64_t *)(iVar5 + 0x110) & ~uVar7 | uVar9) & 0x3df6ffb87;
                }
                uVar8 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_78h + iVar3 + iVar1 + -0x18) + 0x110);
                iVar5 = *(int64_t *)((int64_t)&arg_80h + iVar3 + iVar1 + -0x18);
                if (iVar5 != 0) {
                    *(uint64_t *)(iVar5 + 0xb0) = ((uint32_t)~uVar7 & *(uint32_t *)(iVar5 + 0xb0) | uVar9) & 0xde0fa987;
                    uVar6 = *(undefined8 *)((int64_t)&arg_80h + iVar3 + iVar1 + -0x18);
                    *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c121f;
                    func_0x0001801c22c0(uVar6);
                    if (*(int32_t *)((int64_t)&arg_88h + iVar3 + iVar1 + -0x18) != 0) {
                        uVar8 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_80h + iVar3 + iVar1 + -0x18) + 0xb0);
                    }
                }
                uVar6 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_60h + iVar3 + iVar1 + -0x18) + 0x58);
                *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c1240;
                uVar6 = func_0x0001801dd6c0(uVar6);
                *(undefined8 *)(&stack0x00000038 + iVar3 + iVar1 + -0x18) = 0x1801c1248;
                func_0x00018026d900(uVar6);
                return uVar8;
            }
            return 0;
        }
        if (piVar4 != (int32_t *)0x0) {
            return *(undefined8 *)(piVar4 + 0x26a);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193ba0
// Address: 0x180193ba0
// Size: 75 bytes
// ============================================================
undefined8 fcn.180193ba0(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180193baa;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180193bc7;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(int64_t *)(param_1 + 0x23e) == 0) {
        return 0;
    }
    return *(undefined8 *)(*(int64_t *)(param_1 + 0x23e) + 0x2c8);
}

// ============================================================
// Function: FUN_180193bf0
// Address: 0x180193bf0
// Size: 75 bytes
// ============================================================
undefined8 fcn.180193bf0(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180193bfa;
    iVar1 = fcn.18045a350();
    if (param_1 == (int32_t *)0x0) {
        return 0;
    }
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180193c17;
        param_1 = (int32_t *)func_0x0001801bda50(param_1);
        if (param_1 == (int32_t *)0x0) {
            return 0;
        }
    }
    if (*(int64_t **)(param_1 + 0x21e) == (int64_t *)0x0) {
        return 0;
    }
    return *(undefined8 *)(**(int64_t **)(param_1 + 0x21e) + 8);
}

// ============================================================
// Function: FUN_180193c40
// Address: 0x180193c40
// Size: 88 bytes
// ============================================================
undefined8 fcn.180193c40(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t *in_RCX;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180193c4c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193c6b;
                piVar3 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar3 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1801be36a;
            iVar4 = fcn.18045a350(in_RCX);
            iVar4 = -iVar4;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x1801be37d;
            iVar1 = func_0x0001801bdce0();
            if (iVar1 != 0) {
                uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar2) + 0x60);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x1801be396;
                uVar5 = func_0x0001801e3990(uVar5);
                return uVar5;
            }
            return 0;
        }
        if (piVar3 != (int32_t *)0x0) {
            return *(undefined8 *)(piVar3 + 0x14);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193ca0
// Address: 0x180193ca0
// Size: 66 bytes
// ============================================================
undefined4 fcn.180193ca0(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180193caa;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 0) {
code_r0x000180193cc9:
            return *(undefined4 *)(*(int64_t *)(param_1 + 0x21e) + 0x98);
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180193cc1;
            param_1 = (int32_t *)func_0x0001801bda50();
            if (param_1 != (int32_t *)0x0) goto code_r0x000180193cc9;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193cf0
// Address: 0x180193cf0
// Size: 64 bytes
// ============================================================
uint64_t fcn.180193cf0(int64_t arg_40h, int64_t arg_58h, int64_t arg_c8h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    int32_t *piVar6;
    uint32_t uVar7;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RBX;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1801bf44c;
            iVar4 = fcn.18045a350();
            iVar4 = -iVar4;
            uVar7 = 0;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801bf461;
            uVar5 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
            if ((int32_t)uVar5 == 0) {
                return uVar5;
            }
            uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0xa0);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801bf47c;
            iVar2 = fcn.1801e3b50(uVar1);
            if (iVar2 != 0) {
                uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3) + 0xa0);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1801bf496;
                iVar2 = fcn.1801e3ad0(uVar1);
                uVar7 = 1;
                if (iVar2 == 0) {
                    uVar7 = 3;
                }
            }
            return (uint64_t)uVar7;
        }
        if (piVar6 != (int32_t *)0x0) {
            return (uint64_t)(uint32_t)piVar6[0x21];
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193d30
// Address: 0x180193d30
// Size: 59 bytes
// ============================================================
int32_t fcn.180193d30(int32_t *param_1)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180193d3a;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 == 0) {
code_r0x000180193d59:
            return param_1[0x264];
        }
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180193d51;
            param_1 = (int32_t *)func_0x0001801bda50();
            if (param_1 != (int32_t *)0x0) goto code_r0x000180193d59;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193d70
// Address: 0x180193d70
// Size: 274 bytes
// ============================================================
undefined8 fcn.180193d70(int32_t *param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x180193d7c;
    iVar2 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar3 = param_1;
        if (*param_1 == 0) goto code_r0x000180193d9f;
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x180193d9b;
            piVar3 = (int32_t *)func_0x0001801bda50();
            goto code_r0x000180193d9f;
        }
    }
    piVar3 = (int32_t *)0x0;
code_r0x000180193d9f:
    if ((*param_1 == 0x80) || (*param_1 == 0x81)) {
        return 0x1804a96d4;
    }
    if (piVar3 == (int32_t *)0x0) {
        return 0;
    }
    iVar1 = piVar3[0x12];
    if (iVar1 < 0x304) {
        if (iVar1 == 0x303) {
            return 0x1804a9690;
        }
        if (iVar1 == 0x100) {
            return 0x1804a96b0;
        }
        if (iVar1 == 0x300) {
            return 0x1804a96a8;
        }
        if (iVar1 == 0x301) {
            return 0x1804a96a0;
        }
        if (iVar1 == 0x302) {
            return 0x1804a9698;
        }
    } else {
        if (iVar1 == 0x304) {
            return 0x1804a9688;
        }
        if (iVar1 == 0xfefd) {
            return 0x1804a96c8;
        }
        if (iVar1 == 0xfeff) {
            return 0x1804a96bc;
        }
    }
    return 0x1806414d0;
}

// ============================================================
// Function: FUN_180193e90
// Address: 0x180193e90
// Size: 107 bytes
// ============================================================
undefined8 fcn.180193e90(int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t *in_RCX;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180193e9c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = in_RCX;
        if (*in_RCX != 0) {
            if ((char)*in_RCX < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180193ebb;
                piVar3 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar3 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)in_RCX & 0x80) != 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x1801be3aa;
            iVar4 = fcn.18045a350(in_RCX);
            iVar4 = -iVar4;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x1801be3bd;
            iVar1 = fcn.1801bdce0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar2), 
                                  *(int64_t *)(&stack0x00000068 + iVar4 + iVar2));
            if (iVar1 != 0) {
                uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar2) + 0x60);
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar2) = 0x1801be3d6;
                uVar5 = func_0x0001801e8e30(uVar5);
                return uVar5;
            }
            return 0;
        }
        if (piVar3 != (int32_t *)0x0) {
            iVar2 = *(int64_t *)(piVar3 + 0x18);
            if (iVar2 == 0) {
                return *(undefined8 *)(piVar3 + 0x16);
            }
            if (iVar2 != 0) {
                return *(undefined8 *)(iVar2 + 0x48);
            }
            return 0;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180193f00
// Address: 0x180193f00
// Size: 224 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_3a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_258h because it doesn't fit into ProtoModel

void fcn.180193f00(int32_t *param_1, undefined8 param_2, uint64_t param_3)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t var_8h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180193f0e;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x000003a8 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    if (param_1 == (int32_t *)0x0) goto code_r0x000180193fc5;
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) goto code_r0x000180193fc5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180193f48;
        param_1 = (int32_t *)func_0x0001801bda50();
        if (param_1 == (int32_t *)0x0) goto code_r0x000180193fc5;
    }
    if ((uint32_t)param_3 < 0x21) {
        *(int32_t *)((int64_t)&var_8h + iVar3) = param_1[0x12];
        *(uint64_t *)(&stack0x00000258 + iVar3) = param_3 & 0xffffffff;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180193f77;
        fcn.180498030(&stack0x00000260 + iVar3, param_2, param_3 & 0xffffffff);
        uVar1 = *(undefined8 *)(*(int64_t *)(param_1 + 0x2e2) + 0x3e0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180193f8a;
        iVar2 = func_0x000180222850(uVar1);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(*(int64_t *)(param_1 + 0x2e2) + 0x30);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180193fa3;
            func_0x000180229240(uVar1, (int64_t)&var_8h + iVar3);
            uVar1 = *(undefined8 *)(*(int64_t *)(param_1 + 0x2e2) + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180193fb9;
            func_0x000180222910(uVar1);
        }
    }
code_r0x000180193fc5:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180193fd5;
    func_0x000180459870(*(uint64_t *)(&stack0x000003a8 + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180193fe0
// Address: 0x180193fe0
// Size: 104 bytes
// ============================================================
uint32_t fcn.180193fe0(int32_t *param_1)
{
    int64_t iVar1;
    int32_t *piVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180193fec;
    iVar1 = fcn.18045a350();
    if (param_1 != (int32_t *)0x0) {
        piVar2 = param_1;
        if (*param_1 == 0) goto code_r0x00018019400f;
        if ((char)*param_1 < '\0') {
            *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x18019400b;
            piVar2 = (int32_t *)func_0x0001801bda50();
            goto code_r0x00018019400f;
        }
    }
    piVar2 = (int32_t *)0x0;
code_r0x00018019400f:
    if (((*param_1 != 0x80) && (*param_1 != 0x81)) && (piVar2 != (int32_t *)0x0)) {
        return *(uint32_t *)(*(int64_t *)(*(int64_t *)(piVar2 + 6) + 0xd8) + 0x50) >> 3 & 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180194050
// Address: 0x180194050
// Size: 146 bytes
// ============================================================
undefined8 fcn.180194050(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019405a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180194067;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18019407f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180194091;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    if (*(int64_t *)(param_1 + 8) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801940a6;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801940be;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801940d0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x0001801940df. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*(int64_t *)(param_1 + 8) + 0x10))();
    return uVar2;
}

// ============================================================
// Function: FUN_1801940f0
// Address: 0x1801940f0
// Size: 44 bytes
// ============================================================
uint64_t fcn.1801940f0(int64_t param_1)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801940fa;
    iVar2 = fcn.18045a350();
    pcVar1 = *(code **)(*(int64_t *)(param_1 + 0x18) + 0xb8);
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x18019410a;
    uVar3 = (*pcVar1)();
    uVar4 = 0x7fffffff;
    if (uVar3 < 0x7fffffff) {
        uVar4 = uVar3 & 0xffffffff;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180194120
// Address: 0x180194120
// Size: 100 bytes
// ============================================================
int32_t fcn.180194120(int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t in_R8D;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18019412a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_R8D < 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194137;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18019414f;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194161;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return -1;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180194178;
    iVar1 = fcn.180197bb0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                          *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000050 + iVar2), 
                          *(int64_t *)(&stack0x00000058 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2), 
                          *(int64_t *)(&stack0x00000068 + iVar2));
    if (0 < iVar1) {
        iVar1 = *(int32_t *)((int64_t)&arg_48h + iVar2);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_180194190
// Address: 0x180194190
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180194190(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t *in_RCX;
    int32_t *piVar4;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801941a0;
    iVar2 = fcn.18045a350();
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar4 = in_RCX;
        }
        if (piVar4 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1801941c0;
            iVar1 = func_0x000180195000(piVar4);
            if (iVar1 != 0) {
                piVar4[0x2e8] = 1;
                piVar4[0x1f] = 1;
    // WARNING: Could not recover jumptable at 0x0001801941ea. Too many branches
    // WARNING: Treating indirect jump as call
                uVar3 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x70))
                                  (in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x70));
                return uVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180194200
// Address: 0x180194200
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180194200(int64_t arg_28h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t *in_RCX;
    int32_t *piVar4;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194210;
    iVar2 = fcn.18045a350();
    if (in_RCX != (int32_t *)0x0) {
        piVar4 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar4 = in_RCX;
        }
        if (piVar4 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x180194230;
            iVar1 = func_0x000180195000(piVar4);
            if (iVar1 != 0) {
                piVar4[0x2e8] = 1;
                piVar4[0x1f] = 0;
    // WARNING: Could not recover jumptable at 0x00018019425a. Too many branches
    // WARNING: Treating indirect jump as call
                uVar3 = (**(code **)(*(int64_t *)(in_RCX + 6) + 0x70))
                                  (in_RCX, *(code **)(*(int64_t *)(in_RCX + 6) + 0x70));
                return uVar3;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180194270
// Address: 0x180194270
// Size: 33 bytes
// ============================================================
void fcn.180194270(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a8h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180194289;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar3 = *(int32_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        piVar5 = (int32_t *)arg1;
        if (iVar3 != 0) {
            if ((char)iVar3 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942ab;
                piVar5 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar5 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)arg1 & 0x80) != 0) {
            uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
            uVar8 = *(undefined8 *)((int64_t)&var_18h + iVar4);
            *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            *(undefined8 *)(&stack0x00000010 + iVar4) = 0x1801be3ec;
            iVar6 = fcn.18045a350(arg1);
            iVar6 = -iVar6;
            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be402;
            iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000048 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar4) = uVar8;
                *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar4) = uVar1;
                uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4) + 0x60);
                *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be421;
                iVar7 = func_0x0001801e3990(uVar1);
                if (iVar7 != in_RDX) {
                    *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be434;
                    iVar3 = func_0x0001801e9050(uVar1, in_RDX);
                    if (iVar3 != 0) {
                        *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be440;
                        func_0x00018021a070(iVar7);
                        if (in_RDX != 0) {
                            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be45b;
                            func_0x000180219d10(in_RDX, 0x66, 1, 0);
                        }
                    }
                }
            }
            return;
        }
        if (piVar5 != (int32_t *)0x0) {
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942df;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x31e);
            *(int64_t *)(piVar5 + 0x14) = in_RDX;
            pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31a) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942fb;
            (*pcVar2)(uVar1, in_RDX);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180194291
// Address: 0x180194291
// Size: 64 bytes
// ============================================================
void fcn.180194270(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a8h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180194289;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar3 = *(int32_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        piVar5 = (int32_t *)arg1;
        if (iVar3 != 0) {
            if ((char)iVar3 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942ab;
                piVar5 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar5 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)arg1 & 0x80) != 0) {
            uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
            uVar8 = *(undefined8 *)((int64_t)&var_18h + iVar4);
            *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            *(undefined8 *)(&stack0x00000010 + iVar4) = 0x1801be3ec;
            iVar6 = fcn.18045a350(arg1);
            iVar6 = -iVar6;
            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be402;
            iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000048 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar4) = uVar8;
                *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar4) = uVar1;
                uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4) + 0x60);
                *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be421;
                iVar7 = func_0x0001801e3990(uVar1);
                if (iVar7 != in_RDX) {
                    *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be434;
                    iVar3 = func_0x0001801e9050(uVar1, in_RDX);
                    if (iVar3 != 0) {
                        *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be440;
                        func_0x00018021a070(iVar7);
                        if (in_RDX != 0) {
                            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be45b;
                            func_0x000180219d10(in_RDX, 0x66, 1, 0);
                        }
                    }
                }
            }
            return;
        }
        if (piVar5 != (int32_t *)0x0) {
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942df;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x31e);
            *(int64_t *)(piVar5 + 0x14) = in_RDX;
            pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31a) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942fb;
            (*pcVar2)(uVar1, in_RDX);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801942d1
// Address: 0x1801942d1
// Size: 57 bytes
// ============================================================
void fcn.180194270(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a8h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180194289;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar3 = *(int32_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        piVar5 = (int32_t *)arg1;
        if (iVar3 != 0) {
            if ((char)iVar3 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942ab;
                piVar5 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar5 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)arg1 & 0x80) != 0) {
            uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
            uVar8 = *(undefined8 *)((int64_t)&var_18h + iVar4);
            *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            *(undefined8 *)(&stack0x00000010 + iVar4) = 0x1801be3ec;
            iVar6 = fcn.18045a350(arg1);
            iVar6 = -iVar6;
            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be402;
            iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000048 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar4) = uVar8;
                *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar4) = uVar1;
                uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4) + 0x60);
                *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be421;
                iVar7 = func_0x0001801e3990(uVar1);
                if (iVar7 != in_RDX) {
                    *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be434;
                    iVar3 = func_0x0001801e9050(uVar1, in_RDX);
                    if (iVar3 != 0) {
                        *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be440;
                        func_0x00018021a070(iVar7);
                        if (in_RDX != 0) {
                            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be45b;
                            func_0x000180219d10(in_RDX, 0x66, 1, 0);
                        }
                    }
                }
            }
            return;
        }
        if (piVar5 != (int32_t *)0x0) {
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942df;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x31e);
            *(int64_t *)(piVar5 + 0x14) = in_RDX;
            pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31a) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942fb;
            (*pcVar2)(uVar1, in_RDX);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18019430a
// Address: 0x18019430a
// Size: 1 bytes
// ============================================================
void fcn.180194270(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a8h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    undefined8 uVar8;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180194289;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        iVar3 = *(int32_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
        piVar5 = (int32_t *)arg1;
        if (iVar3 != 0) {
            if ((char)iVar3 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942ab;
                piVar5 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar5 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)arg1 & 0x80) != 0) {
            uVar1 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
            uVar8 = *(undefined8 *)((int64_t)&var_18h + iVar4);
            *(undefined8 *)((int64_t)&var_18h + iVar4) = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            *(undefined8 *)(&stack0x00000010 + iVar4) = 0x1801be3ec;
            iVar6 = fcn.18045a350(arg1);
            iVar6 = -iVar6;
            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be402;
            iVar3 = fcn.1801bdce0(*(int64_t *)(&stack0x00000048 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar4));
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar4) = uVar8;
                *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar4) = uVar1;
                uVar1 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar4) + 0x60);
                *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be421;
                iVar7 = func_0x0001801e3990(uVar1);
                if (iVar7 != in_RDX) {
                    *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be434;
                    iVar3 = func_0x0001801e9050(uVar1, in_RDX);
                    if (iVar3 != 0) {
                        *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be440;
                        func_0x00018021a070(iVar7);
                        if (in_RDX != 0) {
                            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar4) = 0x1801be45b;
                            func_0x000180219d10(in_RDX, 0x66, 1, 0);
                        }
                    }
                }
            }
            return;
        }
        if (piVar5 != (int32_t *)0x0) {
            uVar1 = *(undefined8 *)(piVar5 + 0x14);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942df;
            func_0x00018021a070(uVar1);
            uVar1 = *(undefined8 *)(piVar5 + 0x31e);
            *(int64_t *)(piVar5 + 0x14) = in_RDX;
            pcVar2 = *(code **)(*(int64_t *)(piVar5 + 0x31a) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801942fb;
            (*pcVar2)(uVar1, in_RDX);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180194310
// Address: 0x180194310
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180194310(int64_t arg_38h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180194320;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (*in_RCX != 0) {
        if (-1 < (char)*in_RCX) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019433d;
        in_RCX = (int32_t *)func_0x0001801bda50();
        if (in_RCX == (int32_t *)0x0) {
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019434d;
    uVar2 = func_0x00018022fb60(in_RDX);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar4 + -8) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180194365;
    iVar3 = func_0x0001801a2690(in_RCX, 0x40007, uVar2, 0);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18019436e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180194386;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180194398;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x21e) + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801943b5;
    func_0x00018022ecc0(uVar1);
    *(undefined8 *)(*(int64_t *)(in_RCX + 0x21e) + 8) = in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_1801943d0
// Address: 0x1801943d0
// Size: 33 bytes
// ============================================================
void fcn.1801943d0(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_88h, int64_t arg_90h,
                  int64_t arg_a8h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 uVar8;
    int64_t var_18h;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801943e9;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        iVar2 = *(int32_t *)arg1;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        piVar4 = (int32_t *)arg1;
        if (iVar2 != 0) {
            if ((char)iVar2 < '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18019440b;
                piVar4 = (int32_t *)func_0x0001801bda50();
            } else {
                piVar4 = (int32_t *)0x0;
            }
        }
        if ((*(uint8_t *)arg1 & 0x80) != 0) {
            uVar5 = *(undefined8 *)((int64_t)&arg_30h + iVar3);
            uVar8 = *(undefined8 *)((int64_t)&var_18h + iVar3);
            *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&arg_28h + iVar3);
            *(undefined8 *)(&stack0x00000010 + iVar3) = 0x1801be47c;
            iVar6 = fcn.18045a350(arg1);
            iVar6 = -iVar6;
            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar3) = 0x1801be492;
            iVar2 = fcn.1801bdce0(*(int64_t *)(&stack0x00000048 + iVar6 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar6 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar3));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_88h + iVar6 + iVar3) = uVar5;
                *(undefined8 *)((int64_t)&arg_90h + iVar6 + iVar3) = uVar8;
                uVar5 = *(undefined8 *)(*(int64_t *)((int64_t)&arg_38h + iVar6 + iVar3) + 0x60);
                *(undefined8 *)(&stack0x00000010 + iVar6 + iVar3) = 0x1801be4b1;
                iVar7 = func_0x0001801e8e30(uVar5);
                if (iVar7 != in_RDX) {
                    *(undefined8 *)(&stack0x00000010 + iVar6 + iVar3) = 0x1801be4c4;
                    iVar2 = func_0x0001801e9120(uVar5, in_RDX);
                    if (iVar2 != 0) {
                        *(undefined8 *)(&stack0x00000010 + iVar6 + iVar3) = 0x1801be4d0;
                        func_0x00018021a070(iVar7);
                        if (in_RDX != 0) {
                            *(undefined8 *)(&stack0x00000010 + iVar6 + iVar3) = 0x1801be4eb;
                            func_0x000180219d10(in_RDX, 0x66, 1, 0);
                        }
                    }
                }
            }
            return;
        }
        if (piVar4 != (int32_t *)0x0) {
            if (*(int64_t *)(piVar4 + 0x18) != 0) {
                uVar5 = *(undefined8 *)(piVar4 + 0x16);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180194446;
                uVar5 = func_0x00018021a8e0(uVar5);
                *(undefined8 *)(piVar4 + 0x16) = uVar5;
            }
            uVar5 = *(undefined8 *)(piVar4 + 0x16);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180194453;
            func_0x00018021a070(uVar5);
            iVar6 = *(int64_t *)(piVar4 + 0x18);
            *(int64_t *)(piVar4 + 0x16) = in_RDX;
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180194468;
                in_RDX = func_0x00018021a960(iVar6, in_RDX);
                *(int64_t *)(piVar4 + 0x16) = in_RDX;
            }
            uVar5 = *(undefined8 *)(piVar4 + 800);
            pcVar1 = *(code **)(*(int64_t *)(piVar4 + 0x31c) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180194487;
            (*pcVar1)(uVar5, in_RDX);
        }
    }
    return;
}

