// Chunk 16 - 50 functions

// ============================================================
// Function: FUN_18002bdb0
// Address: 0x18002bdb0
// Size: 22 bytes
// ============================================================
void fcn.18002bdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t unaff_RDI;
    int64_t unaff_R14;
    bool bVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg2 != arg3) {
        do {
            if (arg2 == 0) {
                return;
            }
            iVar2 = arg4;
    // switch table (13 cases) at 0x18002bf34
            switch(*(undefined4 *)(arg2 + 8)) {
            case 7:
                if (arg4 != 0) {
                    if (((*(int64_t *)(arg2 + 0x20) == 0) ||
                        ((((*(int64_t *)(arg2 + 0x28) == 0 && (*(int64_t *)(arg2 + 0x30) == 0)) &&
                          (*(int64_t *)(arg2 + 0x38) == 0)) &&
                         ((*(int16_t *)(arg2 + 0x40) == 0 && (*(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) == 0))))))
                       && (*(int64_t *)(arg2 + 0x48) == 0)) {
                        if ((*(uint32_t *)(arg1 + 0x68) & 0x800) == 0) break;
                        if (*(int64_t *)(arg2 + 0x38) == 0) {
                            bVar3 = (*(uint8_t *)(arg2 + 0xc) & 1) == 0;
                            goto code_r0x00018002bf02;
                        }
                    }
code_r0x00018002bf04:
                    *(undefined4 *)(arg4 + 0x34) = 0;
                }
                break;
            case 8:
            case 0xd:
                bVar3 = arg4 == 0;
code_r0x00018002bf02:
                if (!bVar3) goto code_r0x00018002bf04;
                break;
            case 10:
            case 0xb:
                fcn.18002bdb0(arg1, *(int64_t *)(arg2 + 0x20), 0, 0, unaff_R14, unaff_RDI);
                break;
            case 0x10:
                if (arg4 != 0) {
                    *(undefined4 *)(arg4 + 0x34) = 0;
                }
                for (iVar1 = *(int64_t *)(arg2 + 0x28); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 0x28)) {
                    fcn.18002bdb0(arg1, *(int64_t *)(iVar1 + 0x10), *(int64_t *)(iVar1 + 0x20), arg4, unaff_R14, 
                                  unaff_RDI);
                }
                break;
            case 0x12:
                iVar2 = arg2;
                if (arg4 != 0) {
                    *(undefined4 *)(arg4 + 0x34) = 0;
                    if (*(uint32_t *)(arg4 + 0x24) < 2) {
                        fcn.18002bdb0(arg1, *(int64_t *)(arg2 + 0x10), *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x10), 
                                      arg2, unaff_R14, unaff_RDI);
                        arg2 = *(int64_t *)(arg2 + 0x28);
                        iVar2 = arg4;
                    } else {
                        *(undefined4 *)(arg2 + 0x34) = 0;
                        iVar2 = arg4;
                    }
                }
                break;
            case 0x13:
                if ((arg4 == *(int64_t *)(arg2 + 0x20)) && (iVar2 = 0, *(int32_t *)(arg4 + 0x34) == -1)) {
                    *(undefined4 *)(arg4 + 0x34) = 1;
                }
            }
            arg2 = *(int64_t *)(arg2 + 0x10);
            arg4 = iVar2;
        } while (arg2 != arg3);
    }
    return;
}

// ============================================================
// Function: FUN_18002bdc6
// Address: 0x18002bdc6
// Size: 363 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18002bdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t unaff_RDI;
    int64_t unaff_R14;
    bool bVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg2 != arg3) {
        do {
            if (arg2 == 0) {
                return;
            }
            iVar2 = arg4;
    // switch table (13 cases) at 0x18002bf34
            switch(*(undefined4 *)(arg2 + 8)) {
            case 7:
                if (arg4 != 0) {
                    if (((*(int64_t *)(arg2 + 0x20) == 0) ||
                        ((((*(int64_t *)(arg2 + 0x28) == 0 && (*(int64_t *)(arg2 + 0x30) == 0)) &&
                          (*(int64_t *)(arg2 + 0x38) == 0)) &&
                         ((*(int16_t *)(arg2 + 0x40) == 0 && (*(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) == 0))))))
                       && (*(int64_t *)(arg2 + 0x48) == 0)) {
                        if ((*(uint32_t *)(arg1 + 0x68) & 0x800) == 0) break;
                        if (*(int64_t *)(arg2 + 0x38) == 0) {
                            bVar3 = (*(uint8_t *)(arg2 + 0xc) & 1) == 0;
                            goto code_r0x00018002bf02;
                        }
                    }
code_r0x00018002bf04:
                    *(undefined4 *)(arg4 + 0x34) = 0;
                }
                break;
            case 8:
            case 0xd:
                bVar3 = arg4 == 0;
code_r0x00018002bf02:
                if (!bVar3) goto code_r0x00018002bf04;
                break;
            case 10:
            case 0xb:
                fcn.18002bdb0(arg1, *(int64_t *)(arg2 + 0x20), 0, 0, unaff_R14, unaff_RDI);
                break;
            case 0x10:
                if (arg4 != 0) {
                    *(undefined4 *)(arg4 + 0x34) = 0;
                }
                for (iVar1 = *(int64_t *)(arg2 + 0x28); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 0x28)) {
                    fcn.18002bdb0(arg1, *(int64_t *)(iVar1 + 0x10), *(int64_t *)(iVar1 + 0x20), arg4, unaff_R14, 
                                  unaff_RDI);
                }
                break;
            case 0x12:
                iVar2 = arg2;
                if (arg4 != 0) {
                    *(undefined4 *)(arg4 + 0x34) = 0;
                    if (*(uint32_t *)(arg4 + 0x24) < 2) {
                        fcn.18002bdb0(arg1, *(int64_t *)(arg2 + 0x10), *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x10), 
                                      arg2, unaff_R14, unaff_RDI);
                        arg2 = *(int64_t *)(arg2 + 0x28);
                        iVar2 = arg4;
                    } else {
                        *(undefined4 *)(arg2 + 0x34) = 0;
                        iVar2 = arg4;
                    }
                }
                break;
            case 0x13:
                if ((arg4 == *(int64_t *)(arg2 + 0x20)) && (iVar2 = 0, *(int32_t *)(arg4 + 0x34) == -1)) {
                    *(undefined4 *)(arg4 + 0x34) = 1;
                }
            }
            arg2 = *(int64_t *)(arg2 + 0x10);
            arg4 = iVar2;
        } while (arg2 != arg3);
    }
    return;
}

// ============================================================
// Function: FUN_18002bf31
// Address: 0x18002bf31
// Size: 55 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18002bdb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t unaff_RDI;
    int64_t unaff_R14;
    bool bVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (arg2 != arg3) {
        do {
            if (arg2 == 0) {
                return;
            }
            iVar2 = arg4;
    // switch table (13 cases) at 0x18002bf34
            switch(*(undefined4 *)(arg2 + 8)) {
            case 7:
                if (arg4 != 0) {
                    if (((*(int64_t *)(arg2 + 0x20) == 0) ||
                        ((((*(int64_t *)(arg2 + 0x28) == 0 && (*(int64_t *)(arg2 + 0x30) == 0)) &&
                          (*(int64_t *)(arg2 + 0x38) == 0)) &&
                         ((*(int16_t *)(arg2 + 0x40) == 0 && (*(int64_t *)(*(int64_t *)(arg2 + 0x20) + 0x18) == 0))))))
                       && (*(int64_t *)(arg2 + 0x48) == 0)) {
                        if ((*(uint32_t *)(arg1 + 0x68) & 0x800) == 0) break;
                        if (*(int64_t *)(arg2 + 0x38) == 0) {
                            bVar3 = (*(uint8_t *)(arg2 + 0xc) & 1) == 0;
                            goto code_r0x00018002bf02;
                        }
                    }
code_r0x00018002bf04:
                    *(undefined4 *)(arg4 + 0x34) = 0;
                }
                break;
            case 8:
            case 0xd:
                bVar3 = arg4 == 0;
code_r0x00018002bf02:
                if (!bVar3) goto code_r0x00018002bf04;
                break;
            case 10:
            case 0xb:
                fcn.18002bdb0(arg1, *(int64_t *)(arg2 + 0x20), 0, 0, unaff_R14, unaff_RDI);
                break;
            case 0x10:
                if (arg4 != 0) {
                    *(undefined4 *)(arg4 + 0x34) = 0;
                }
                for (iVar1 = *(int64_t *)(arg2 + 0x28); iVar1 != 0; iVar1 = *(int64_t *)(iVar1 + 0x28)) {
                    fcn.18002bdb0(arg1, *(int64_t *)(iVar1 + 0x10), *(int64_t *)(iVar1 + 0x20), arg4, unaff_R14, 
                                  unaff_RDI);
                }
                break;
            case 0x12:
                iVar2 = arg2;
                if (arg4 != 0) {
                    *(undefined4 *)(arg4 + 0x34) = 0;
                    if (*(uint32_t *)(arg4 + 0x24) < 2) {
                        fcn.18002bdb0(arg1, *(int64_t *)(arg2 + 0x10), *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x10), 
                                      arg2, unaff_R14, unaff_RDI);
                        arg2 = *(int64_t *)(arg2 + 0x28);
                        iVar2 = arg4;
                    } else {
                        *(undefined4 *)(arg2 + 0x34) = 0;
                        iVar2 = arg4;
                    }
                }
                break;
            case 0x13:
                if ((arg4 == *(int64_t *)(arg2 + 0x20)) && (iVar2 = 0, *(int32_t *)(arg4 + 0x34) == -1)) {
                    *(undefined4 *)(arg4 + 0x34) = 1;
                }
            }
            arg2 = *(int64_t *)(arg2 + 0x10);
            arg4 = iVar2;
        } while (arg2 != arg3);
    }
    return;
}

// ============================================================
// Function: FUN_18002bf70
// Address: 0x18002bf70
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18002bf70(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(int32_t *)(arg2 + 8) == 8) {
        uVar3 = 9;
    } else {
        uVar3 = 0xc;
        if (1 < *(int32_t *)(arg2 + 8) - 10U) {
            uVar3 = 0xe;
        }
    }
    puVar2 = (undefined8 *)func_0x000180459890();
    *(undefined4 *)((int64_t)puVar2 + 0xc) = 0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    *puVar2 = 0x1806220a8;
    *(undefined4 *)(puVar2 + 1) = uVar3;
    puVar2[4] = arg2;
    puVar2[3] = *(undefined8 *)(arg1 + 8);
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x10);
    if (iVar1 != 0) {
        puVar2[2] = iVar1;
        *(undefined8 **)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x10) + 0x18) = puVar2;
    }
    *(undefined8 **)(*(int64_t *)(arg1 + 8) + 0x10) = puVar2;
    *(undefined8 **)(arg1 + 8) = puVar2;
    return puVar2;
}

// ============================================================
// Function: FUN_18002bff0
// Address: 0x18002bff0
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002bff0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    if (puVar1 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar1;
        while (puVar3 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)puVar3[2];
            puVar3[2] = 0;
            (**(code **)*puVar3)(puVar3, 1);
            puVar3 = puVar2;
        }
        *puVar1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002bffe
// Address: 0x18002bffe
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002bff0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    if (puVar1 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar1;
        while (puVar3 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)puVar3[2];
            puVar3[2] = 0;
            (**(code **)*puVar3)(puVar3, 1);
            puVar3 = puVar2;
        }
        *puVar1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002c049
// Address: 0x18002c049
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002bff0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)arg1;
    if (puVar1 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar1;
        while (puVar3 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)puVar3[2];
            puVar3[2] = 0;
            (**(code **)*puVar3)(puVar3, 1);
            puVar3 = puVar2;
        }
        *puVar1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002c050
// Address: 0x18002c050
// Size: 114 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002c050(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t unaff_RDI;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    pauVar3 = *(undefined (**) [16])(arg1 + 0x18);
    uVar6 = arg2 & 0xffffffff;
    iVar5 = *(int64_t *)(arg1 + 0x10);
    iVar8 = (int64_t)pauVar3 - iVar5 >> 3;
    if (uVar6 < (uint64_t)(iVar8 * -0x5555555555555555)) {
        *(uint64_t *)(arg1 + 0x18) = iVar5 + uVar6 * 0x18;
        return;
    }
    if (uVar6 <= (uint64_t)(iVar8 * -0x5555555555555555)) {
        return;
    }
    uVar4 = (*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * -0x5555555555555555;
    if (uVar6 <= uVar4) {
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        *(undefined (**) [16])(arg1 + 0x18) = pauVar3;
        return;
    }
    uVar2 = 0xaaaaaaaaaaaaaaa - (uVar4 >> 1);
    if ((uVar2 <= uVar4 && uVar4 - uVar2 != 0) ||
       ((uVar4 = uVar4 + (uVar4 >> 1), uVar2 = uVar6, uVar6 <= uVar4 && (uVar2 = uVar4, 0xaaaaaaaaaaaaaaa < uVar4)))) {
code_r0x00018002c248:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = uVar2 * 0x18;
    if (uVar2 == 0) {
        unaff_RDI = 0;
code_r0x00018002c151:
        pauVar3 = (undefined (*) [16])(unaff_RDI + iVar8 * 8);
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        fcn.180498030(unaff_RDI, *(int64_t *)(arg1 + 0x10), *(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x10));
        iVar5 = *(int64_t *)(arg1 + 0x10);
        if (iVar5 == 0) goto code_r0x00018002c1e1;
        iVar8 = iVar5;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_38, 0x1f < (iVar5 - iVar8) - 8U))
        goto code_r0x00018002c1cf;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar2);
            goto code_r0x00018002c151;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018002c248;
        iVar5 = fcn.180459890();
        if (iVar5 != 0) {
            unaff_RDI = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar5;
            goto code_r0x00018002c151;
        }
code_r0x00018002c1cf:
        iVar8 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18002c1e1;
    fcn.180459c3c(iVar8);
code_r0x00018002c1e1:
    *(uint64_t *)(arg1 + 0x10) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x18) = unaff_RDI + uVar6 * 0x18;
    *(uint64_t *)(arg1 + 0x20) = uVar2 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18002c0c2
// Address: 0x18002c0c2
// Size: 321 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002c050(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t unaff_RDI;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    pauVar3 = *(undefined (**) [16])(arg1 + 0x18);
    uVar6 = arg2 & 0xffffffff;
    iVar5 = *(int64_t *)(arg1 + 0x10);
    iVar8 = (int64_t)pauVar3 - iVar5 >> 3;
    if (uVar6 < (uint64_t)(iVar8 * -0x5555555555555555)) {
        *(uint64_t *)(arg1 + 0x18) = iVar5 + uVar6 * 0x18;
        return;
    }
    if (uVar6 <= (uint64_t)(iVar8 * -0x5555555555555555)) {
        return;
    }
    uVar4 = (*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * -0x5555555555555555;
    if (uVar6 <= uVar4) {
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        *(undefined (**) [16])(arg1 + 0x18) = pauVar3;
        return;
    }
    uVar2 = 0xaaaaaaaaaaaaaaa - (uVar4 >> 1);
    if ((uVar2 <= uVar4 && uVar4 - uVar2 != 0) ||
       ((uVar4 = uVar4 + (uVar4 >> 1), uVar2 = uVar6, uVar6 <= uVar4 && (uVar2 = uVar4, 0xaaaaaaaaaaaaaaa < uVar4)))) {
code_r0x00018002c248:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = uVar2 * 0x18;
    if (uVar2 == 0) {
        unaff_RDI = 0;
code_r0x00018002c151:
        pauVar3 = (undefined (*) [16])(unaff_RDI + iVar8 * 8);
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        fcn.180498030(unaff_RDI, *(int64_t *)(arg1 + 0x10), *(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x10));
        iVar5 = *(int64_t *)(arg1 + 0x10);
        if (iVar5 == 0) goto code_r0x00018002c1e1;
        iVar8 = iVar5;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_38, 0x1f < (iVar5 - iVar8) - 8U))
        goto code_r0x00018002c1cf;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar2);
            goto code_r0x00018002c151;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018002c248;
        iVar5 = fcn.180459890();
        if (iVar5 != 0) {
            unaff_RDI = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar5;
            goto code_r0x00018002c151;
        }
code_r0x00018002c1cf:
        iVar8 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18002c1e1;
    fcn.180459c3c(iVar8);
code_r0x00018002c1e1:
    *(uint64_t *)(arg1 + 0x10) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x18) = unaff_RDI + uVar6 * 0x18;
    *(uint64_t *)(arg1 + 0x20) = uVar2 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18002c203
// Address: 0x18002c203
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002c050(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t unaff_RDI;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    pauVar3 = *(undefined (**) [16])(arg1 + 0x18);
    uVar6 = arg2 & 0xffffffff;
    iVar5 = *(int64_t *)(arg1 + 0x10);
    iVar8 = (int64_t)pauVar3 - iVar5 >> 3;
    if (uVar6 < (uint64_t)(iVar8 * -0x5555555555555555)) {
        *(uint64_t *)(arg1 + 0x18) = iVar5 + uVar6 * 0x18;
        return;
    }
    if (uVar6 <= (uint64_t)(iVar8 * -0x5555555555555555)) {
        return;
    }
    uVar4 = (*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * -0x5555555555555555;
    if (uVar6 <= uVar4) {
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        *(undefined (**) [16])(arg1 + 0x18) = pauVar3;
        return;
    }
    uVar2 = 0xaaaaaaaaaaaaaaa - (uVar4 >> 1);
    if ((uVar2 <= uVar4 && uVar4 - uVar2 != 0) ||
       ((uVar4 = uVar4 + (uVar4 >> 1), uVar2 = uVar6, uVar6 <= uVar4 && (uVar2 = uVar4, 0xaaaaaaaaaaaaaaa < uVar4)))) {
code_r0x00018002c248:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = uVar2 * 0x18;
    if (uVar2 == 0) {
        unaff_RDI = 0;
code_r0x00018002c151:
        pauVar3 = (undefined (*) [16])(unaff_RDI + iVar8 * 8);
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        fcn.180498030(unaff_RDI, *(int64_t *)(arg1 + 0x10), *(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x10));
        iVar5 = *(int64_t *)(arg1 + 0x10);
        if (iVar5 == 0) goto code_r0x00018002c1e1;
        iVar8 = iVar5;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_38, 0x1f < (iVar5 - iVar8) - 8U))
        goto code_r0x00018002c1cf;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar2);
            goto code_r0x00018002c151;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018002c248;
        iVar5 = fcn.180459890();
        if (iVar5 != 0) {
            unaff_RDI = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar5;
            goto code_r0x00018002c151;
        }
code_r0x00018002c1cf:
        iVar8 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18002c1e1;
    fcn.180459c3c(iVar8);
code_r0x00018002c1e1:
    *(uint64_t *)(arg1 + 0x10) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x18) = unaff_RDI + uVar6 * 0x18;
    *(uint64_t *)(arg1 + 0x20) = uVar2 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18002c248
// Address: 0x18002c248
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002c050(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t unaff_RDI;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    pauVar3 = *(undefined (**) [16])(arg1 + 0x18);
    uVar6 = arg2 & 0xffffffff;
    iVar5 = *(int64_t *)(arg1 + 0x10);
    iVar8 = (int64_t)pauVar3 - iVar5 >> 3;
    if (uVar6 < (uint64_t)(iVar8 * -0x5555555555555555)) {
        *(uint64_t *)(arg1 + 0x18) = iVar5 + uVar6 * 0x18;
        return;
    }
    if (uVar6 <= (uint64_t)(iVar8 * -0x5555555555555555)) {
        return;
    }
    uVar4 = (*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * -0x5555555555555555;
    if (uVar6 <= uVar4) {
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        *(undefined (**) [16])(arg1 + 0x18) = pauVar3;
        return;
    }
    uVar2 = 0xaaaaaaaaaaaaaaa - (uVar4 >> 1);
    if ((uVar2 <= uVar4 && uVar4 - uVar2 != 0) ||
       ((uVar4 = uVar4 + (uVar4 >> 1), uVar2 = uVar6, uVar6 <= uVar4 && (uVar2 = uVar4, 0xaaaaaaaaaaaaaaa < uVar4)))) {
code_r0x00018002c248:
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = uVar2 * 0x18;
    if (uVar2 == 0) {
        unaff_RDI = 0;
code_r0x00018002c151:
        pauVar3 = (undefined (*) [16])(unaff_RDI + iVar8 * 8);
        for (iVar5 = uVar6 + iVar8 * 0x5555555555555555; iVar5 != 0; iVar5 = iVar5 + -1) {
            *pauVar3 = ZEXT816(0);
            *(undefined8 *)pauVar3[1] = 0;
            pauVar3 = (undefined (*) [16])(pauVar3[1] + 8);
        }
        fcn.180498030(unaff_RDI, *(int64_t *)(arg1 + 0x10), *(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x10));
        iVar5 = *(int64_t *)(arg1 + 0x10);
        if (iVar5 == 0) goto code_r0x00018002c1e1;
        iVar8 = iVar5;
        puVar7 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x20) - iVar5 >> 3) * 8)) &&
           (iVar8 = *(int64_t *)(iVar5 + -8), puVar7 = auStack_38, 0x1f < (iVar5 - iVar8) - 8U))
        goto code_r0x00018002c1cf;
    } else {
        if (uVar2 < 0x1000) {
            unaff_RDI = fcn.180459890(uVar2);
            goto code_r0x00018002c151;
        }
        if (uVar2 + 0x27 <= uVar2) goto code_r0x00018002c248;
        iVar5 = fcn.180459890();
        if (iVar5 != 0) {
            unaff_RDI = iVar5 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar5;
            goto code_r0x00018002c151;
        }
code_r0x00018002c1cf:
        iVar8 = 5;
        pcVar1 = (code *)swi(0x29);
        (*pcVar1)(5);
        puVar7 = auStack_30;
    }
    *(undefined8 *)(puVar7 + -8) = 0x18002c1e1;
    fcn.180459c3c(iVar8);
code_r0x00018002c1e1:
    *(uint64_t *)(arg1 + 0x10) = unaff_RDI;
    *(uint64_t *)(arg1 + 0x18) = unaff_RDI + uVar6 * 0x18;
    *(uint64_t *)(arg1 + 0x20) = uVar2 + unaff_RDI;
    return;
}

// ============================================================
// Function: FUN_18002c250
// Address: 0x18002c250
// Size: 813 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002c250(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t *puVar2;
    int64_t iVar3;
    code *pcVar4;
    uint64_t uVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    uint32_t uStack_10;
    undefined4 uStack_c;
    
    uVar5 = *(uint64_t *)(arg1 + 0x18);
    if (uVar5 < (uint64_t)arg2) {
        arg2 = arg2 - uVar5;
        if (((int64_t)uVar5 < 0) && (uVar5 != 0)) {
            var_48h = -((~uVar5 >> 5) * 4 + 4);
        } else {
            var_48h = (uVar5 >> 5) * 4;
        }
        var_48h = *(int64_t *)arg1 + var_48h;
        var_40h = uVar5 & 0x1f;
        uVar5 = func_0x00018002eec0(arg1, &var_48h, arg2);
        if (((int64_t)uVar5 < 0) && (uVar5 != 0)) {
            var_38h = -((~uVar5 >> 5) * 4 + 4);
        } else {
            var_38h = (uVar5 >> 5) * 4;
        }
        var_38h = *(int64_t *)arg1 + var_38h;
        if (arg2 != 0) {
            uVar6 = (uint32_t)uVar5 & 0x1f;
            var_30h = (int64_t)uVar6;
            if ((arg2 < 0) && ((uint64_t)var_30h < (uint64_t)-arg2)) {
                var_48h = -(((uint64_t)~(arg2 + var_30h) >> 5) * 4 + 4);
            } else {
                var_48h = ((uint64_t)(arg2 + var_30h) >> 5) * 4;
            }
            var_48h = var_38h + var_48h;
            var_40h = (int64_t)((int32_t)arg2 + uVar6 & 0x1f);
            func_0x00018002f060(&var_38h, &var_48h, 0);
            return;
        }
    } else if ((uint64_t)arg2 < uVar5) {
        var_38h = *(int64_t *)arg1;
        if (((int64_t)uVar5 < 0) && (uVar5 != 0)) {
            iVar3 = -((~uVar5 >> 5) * 4 + 4);
        } else {
            iVar3 = (uVar5 >> 5) * 4;
        }
        if ((arg2 < 0) && (arg2 != 0)) {
            iVar1 = -(((uint64_t)~arg2 >> 5) * 4 + 4);
        } else {
            iVar1 = ((uint64_t)arg2 >> 5) * 4;
        }
        if (uVar5 != 0) {
            var_30h = uVar5 & 0x1f;
            uVar7 = (iVar1 >> 2) * 0x20 + (arg2 & 0x1fU);
            if (((int64_t)uVar7 < 0) && (uVar7 != 0)) {
                var_18h = -((~uVar7 >> 5) * 4 + 4);
            } else {
                var_18h = (uVar7 >> 5) * 4;
            }
            var_18h = var_38h + var_18h;
            uStack_10 = (uint32_t)uVar7 & 0x1f;
            uVar7 = (iVar3 >> 2) * 0x20 + var_30h;
            if (((int64_t)uVar7 < 0) && (uVar7 != 0)) {
                var_48h = -((~uVar7 >> 5) * 4 + 4);
            } else {
                var_48h = (uVar7 >> 5) * 4;
            }
            var_48h = var_38h + var_48h;
            var_40h = (int64_t)((uint32_t)uVar7 & 0x1f);
            if ((var_18h != var_48h) || ((uint64_t)uStack_10 != var_40h)) {
                if (((int64_t)uVar5 < 0) && (uVar5 != 0)) {
                    iVar3 = -((~uVar5 >> 5) * 4 + 4);
                } else {
                    iVar3 = (uVar5 >> 5) * 4;
                }
                var_38h = var_38h + iVar3;
                uStack_c = 0;
                func_0x00018002f9c0(&var_28h, &var_48h, &var_38h, &var_18h);
                iVar3 = *(int64_t *)arg1;
                uVar5 = (var_28h - iVar3 >> 2) * 0x20 + var_20h;
                if (0x7fffffffffffffff < uVar5) {
                    func_0x00018002f9a0();
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                uVar7 = uVar5 + 0x1f >> 5;
                if ((uVar7 < (uint64_t)(*(int64_t *)(arg1 + 8) - iVar3 >> 2)) &&
                   (iVar1 = iVar3 + uVar7 * 4, iVar1 != *(int64_t *)(arg1 + 8))) {
                    *(int64_t *)(arg1 + 8) = iVar1;
                }
                *(uint64_t *)(arg1 + 0x18) = uVar5;
                if ((uVar5 & 0x1f) != 0) {
                    puVar2 = (uint32_t *)(iVar3 + -4 + uVar7 * 4);
                    *puVar2 = *puVar2 & (1 << ((uint8_t)uVar5 & 0x1f)) - 1U;
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18002c580
// Address: 0x18002c580
// Size: 250 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18002c580(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    
    puVar7 = auStack_58;
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    func_0x00018002e250(arg1 + 8, arg2 + 8);
    puVar1 = (uint64_t *)(arg1 + 0x28);
    if (puVar1 != (uint64_t *)(arg2 + 0x28)) {
        uVar5 = *(uint64_t *)(arg2 + 0x28);
        uVar6 = *puVar1;
        uVar8 = (int64_t)(*(int64_t *)(arg2 + 0x30) - uVar5) >> 4;
        uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x38) - uVar6) >> 4;
        if (uVar4 < uVar8) {
            if (0xfffffffffffffff < uVar8) {
                func_0x000180010010();
                pcVar2 = (code *)swi(3);
                iVar3 = (*pcVar2)();
                return iVar3;
            }
            uVar9 = 0xfffffffffffffff;
            if ((uVar4 <= 0xfffffffffffffff - (uVar4 >> 1)) && (uVar9 = uVar4 + (uVar4 >> 1), uVar9 < uVar8)) {
                uVar9 = uVar8;
            }
            if (uVar6 != 0) {
                uVar4 = uVar6;
                puVar7 = auStack_58;
                if (0xfff < (*(int64_t *)(arg1 + 0x38) - uVar6 & 0xfffffffffffffff0)) {
                    uVar4 = *(uint64_t *)(uVar6 - 8);
                    uVar6 = (uVar6 - uVar4) - 8;
                    puVar7 = auStack_58;
                    if (0x1f < uVar6) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        uVar4 = uVar6;
                        puVar7 = auStack_50;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002c647;
                fcn.180459c3c(uVar4);
                *puVar1 = 0;
                *(undefined8 *)(arg1 + 0x30) = 0;
                *(undefined8 *)(arg1 + 0x38) = 0;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18002c65f;
            func_0x0001800307b0(puVar1, uVar9);
            uVar6 = *puVar1;
            *(undefined8 *)(puVar7 + -8) = 0x18002c674;
            fcn.180498030(uVar6, uVar5, uVar8 * 0x10);
            iVar3 = uVar6 + uVar8 * 0x10;
        } else {
            uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x30) - uVar6) >> 4;
            if (uVar4 < uVar8) {
                fcn.180498030(uVar6, uVar5, uVar4 * 0x10);
                uVar6 = *(uint64_t *)(arg1 + 0x30);
                uVar5 = uVar5 + uVar4 * 0x10;
                uVar8 = uVar8 - uVar4;
            }
            fcn.180498030(uVar6, uVar5, uVar8 * 0x10);
            iVar3 = uVar8 * 0x10 + uVar6;
        }
        *(int64_t *)(arg1 + 0x30) = iVar3;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002c67a
// Address: 0x18002c67a
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18002c580(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    
    puVar7 = auStack_58;
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    func_0x00018002e250(arg1 + 8, arg2 + 8);
    puVar1 = (uint64_t *)(arg1 + 0x28);
    if (puVar1 != (uint64_t *)(arg2 + 0x28)) {
        uVar5 = *(uint64_t *)(arg2 + 0x28);
        uVar6 = *puVar1;
        uVar8 = (int64_t)(*(int64_t *)(arg2 + 0x30) - uVar5) >> 4;
        uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x38) - uVar6) >> 4;
        if (uVar4 < uVar8) {
            if (0xfffffffffffffff < uVar8) {
                func_0x000180010010();
                pcVar2 = (code *)swi(3);
                iVar3 = (*pcVar2)();
                return iVar3;
            }
            uVar9 = 0xfffffffffffffff;
            if ((uVar4 <= 0xfffffffffffffff - (uVar4 >> 1)) && (uVar9 = uVar4 + (uVar4 >> 1), uVar9 < uVar8)) {
                uVar9 = uVar8;
            }
            if (uVar6 != 0) {
                uVar4 = uVar6;
                puVar7 = auStack_58;
                if (0xfff < (*(int64_t *)(arg1 + 0x38) - uVar6 & 0xfffffffffffffff0)) {
                    uVar4 = *(uint64_t *)(uVar6 - 8);
                    uVar6 = (uVar6 - uVar4) - 8;
                    puVar7 = auStack_58;
                    if (0x1f < uVar6) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        uVar4 = uVar6;
                        puVar7 = auStack_50;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002c647;
                fcn.180459c3c(uVar4);
                *puVar1 = 0;
                *(undefined8 *)(arg1 + 0x30) = 0;
                *(undefined8 *)(arg1 + 0x38) = 0;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18002c65f;
            func_0x0001800307b0(puVar1, uVar9);
            uVar6 = *puVar1;
            *(undefined8 *)(puVar7 + -8) = 0x18002c674;
            fcn.180498030(uVar6, uVar5, uVar8 * 0x10);
            iVar3 = uVar6 + uVar8 * 0x10;
        } else {
            uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x30) - uVar6) >> 4;
            if (uVar4 < uVar8) {
                fcn.180498030(uVar6, uVar5, uVar4 * 0x10);
                uVar6 = *(uint64_t *)(arg1 + 0x30);
                uVar5 = uVar5 + uVar4 * 0x10;
                uVar8 = uVar8 - uVar4;
            }
            fcn.180498030(uVar6, uVar5, uVar8 * 0x10);
            iVar3 = uVar8 * 0x10 + uVar6;
        }
        *(int64_t *)(arg1 + 0x30) = iVar3;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002c6c7
// Address: 0x18002c6c7
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18002c580(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    undefined auStack_58 [8];
    undefined auStack_50 [32];
    
    puVar7 = auStack_58;
    *(undefined8 *)arg1 = *(undefined8 *)arg2;
    func_0x00018002e250(arg1 + 8, arg2 + 8);
    puVar1 = (uint64_t *)(arg1 + 0x28);
    if (puVar1 != (uint64_t *)(arg2 + 0x28)) {
        uVar5 = *(uint64_t *)(arg2 + 0x28);
        uVar6 = *puVar1;
        uVar8 = (int64_t)(*(int64_t *)(arg2 + 0x30) - uVar5) >> 4;
        uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x38) - uVar6) >> 4;
        if (uVar4 < uVar8) {
            if (0xfffffffffffffff < uVar8) {
                func_0x000180010010();
                pcVar2 = (code *)swi(3);
                iVar3 = (*pcVar2)();
                return iVar3;
            }
            uVar9 = 0xfffffffffffffff;
            if ((uVar4 <= 0xfffffffffffffff - (uVar4 >> 1)) && (uVar9 = uVar4 + (uVar4 >> 1), uVar9 < uVar8)) {
                uVar9 = uVar8;
            }
            if (uVar6 != 0) {
                uVar4 = uVar6;
                puVar7 = auStack_58;
                if (0xfff < (*(int64_t *)(arg1 + 0x38) - uVar6 & 0xfffffffffffffff0)) {
                    uVar4 = *(uint64_t *)(uVar6 - 8);
                    uVar6 = (uVar6 - uVar4) - 8;
                    puVar7 = auStack_58;
                    if (0x1f < uVar6) {
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        uVar4 = uVar6;
                        puVar7 = auStack_50;
                    }
                }
                *(undefined8 *)(puVar7 + -8) = 0x18002c647;
                fcn.180459c3c(uVar4);
                *puVar1 = 0;
                *(undefined8 *)(arg1 + 0x30) = 0;
                *(undefined8 *)(arg1 + 0x38) = 0;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18002c65f;
            func_0x0001800307b0(puVar1, uVar9);
            uVar6 = *puVar1;
            *(undefined8 *)(puVar7 + -8) = 0x18002c674;
            fcn.180498030(uVar6, uVar5, uVar8 * 0x10);
            iVar3 = uVar6 + uVar8 * 0x10;
        } else {
            uVar4 = (int64_t)(*(int64_t *)(arg1 + 0x30) - uVar6) >> 4;
            if (uVar4 < uVar8) {
                fcn.180498030(uVar6, uVar5, uVar4 * 0x10);
                uVar6 = *(uint64_t *)(arg1 + 0x30);
                uVar5 = uVar5 + uVar4 * 0x10;
                uVar8 = uVar8 - uVar4;
            }
            fcn.180498030(uVar6, uVar5, uVar8 * 0x10);
            iVar3 = uVar8 * 0x10 + uVar6;
        }
        *(int64_t *)(arg1 + 0x30) = iVar3;
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002c6f0
// Address: 0x18002c6f0
// Size: 251 bytes
// ============================================================
int64_t fcn.18002c6f0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    
    *(undefined8 *)arg1 = 0x1806220b0;
    iVar2 = *(int64_t *)(arg1 + 0x20);
    while (iVar2 != 0) {
        iVar1 = *(int64_t *)(iVar2 + 0x18);
        func_0x000180460d90(*(undefined8 *)(iVar2 + 0x10));
        fcn.180459c3c(iVar2, 0x20);
        iVar2 = iVar1;
    }
    fcn.180459c3c(*(undefined8 *)(arg1 + 0x28), 0x20);
    iVar2 = *(int64_t *)(arg1 + 0x30);
    if (iVar2 != 0) {
        func_0x000180460d90(*(undefined8 *)(iVar2 + 8));
        fcn.180459c3c(iVar2, 0x10);
    }
    iVar2 = *(int64_t *)(arg1 + 0x38);
    if (iVar2 != 0) {
        func_0x000180460d90(*(undefined8 *)(iVar2 + 8));
        fcn.180459c3c(iVar2, 0x10);
    }
    iVar2 = *(int64_t *)(arg1 + 0x48);
    while (iVar2 != 0) {
        iVar1 = *(int64_t *)(iVar2 + 0x18);
        func_0x000180460d90(*(undefined8 *)(iVar2 + 0x10));
        fcn.180459c3c(iVar2, 0x20);
        iVar2 = iVar1;
    }
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x50);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002c7f0
// Address: 0x18002c7f0
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint16_t fcn.18002c7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined *puVar5;
    char in_R9B;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar6 = 0;
    do {
        if (arg3 - arg2 == (uint64_t)*(uint32_t *)(uVar6 * 0x18 + 0x180621f30)) {
            puVar5 = (undefined *)arg2;
            if (arg2 == arg3) break;
            while( true ) {
                cVar1 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))(*(int64_t **)(arg1 + 8), *puVar5);
                cVar2 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))();
                if (cVar1 != cVar2) break;
                puVar5 = puVar5 + 1;
                if (puVar5 == (undefined *)arg3) goto code_r0x00018002c8aa;
            }
        }
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
    } while (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0);
code_r0x00018002c8aa:
    uVar4 = 0;
    if (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0) {
        uVar4 = *(uint16_t *)(uVar6 * 0x18 + 0x180621f34);
    }
    uVar3 = uVar4;
    if ((in_R9B != '\0') && (uVar3 = uVar4 | 3, (uVar4 & 3) == 0)) {
        uVar3 = uVar4;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18002c7fb
// Address: 0x18002c7fb
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint16_t fcn.18002c7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined *puVar5;
    char in_R9B;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar6 = 0;
    do {
        if (arg3 - arg2 == (uint64_t)*(uint32_t *)(uVar6 * 0x18 + 0x180621f30)) {
            puVar5 = (undefined *)arg2;
            if (arg2 == arg3) break;
            while( true ) {
                cVar1 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))(*(int64_t **)(arg1 + 8), *puVar5);
                cVar2 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))();
                if (cVar1 != cVar2) break;
                puVar5 = puVar5 + 1;
                if (puVar5 == (undefined *)arg3) goto code_r0x00018002c8aa;
            }
        }
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
    } while (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0);
code_r0x00018002c8aa:
    uVar4 = 0;
    if (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0) {
        uVar4 = *(uint16_t *)(uVar6 * 0x18 + 0x180621f34);
    }
    uVar3 = uVar4;
    if ((in_R9B != '\0') && (uVar3 = uVar4 | 3, (uVar4 & 3) == 0)) {
        uVar3 = uVar4;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18002c82b
// Address: 0x18002c82b
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint16_t fcn.18002c7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined *puVar5;
    char in_R9B;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar6 = 0;
    do {
        if (arg3 - arg2 == (uint64_t)*(uint32_t *)(uVar6 * 0x18 + 0x180621f30)) {
            puVar5 = (undefined *)arg2;
            if (arg2 == arg3) break;
            while( true ) {
                cVar1 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))(*(int64_t **)(arg1 + 8), *puVar5);
                cVar2 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))();
                if (cVar1 != cVar2) break;
                puVar5 = puVar5 + 1;
                if (puVar5 == (undefined *)arg3) goto code_r0x00018002c8aa;
            }
        }
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
    } while (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0);
code_r0x00018002c8aa:
    uVar4 = 0;
    if (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0) {
        uVar4 = *(uint16_t *)(uVar6 * 0x18 + 0x180621f34);
    }
    uVar3 = uVar4;
    if ((in_R9B != '\0') && (uVar3 = uVar4 | 3, (uVar4 & 3) == 0)) {
        uVar3 = uVar4;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18002c8c4
// Address: 0x18002c8c4
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint16_t fcn.18002c7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined *puVar5;
    char in_R9B;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar6 = 0;
    do {
        if (arg3 - arg2 == (uint64_t)*(uint32_t *)(uVar6 * 0x18 + 0x180621f30)) {
            puVar5 = (undefined *)arg2;
            if (arg2 == arg3) break;
            while( true ) {
                cVar1 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))(*(int64_t **)(arg1 + 8), *puVar5);
                cVar2 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))();
                if (cVar1 != cVar2) break;
                puVar5 = puVar5 + 1;
                if (puVar5 == (undefined *)arg3) goto code_r0x00018002c8aa;
            }
        }
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
    } while (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0);
code_r0x00018002c8aa:
    uVar4 = 0;
    if (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0) {
        uVar4 = *(uint16_t *)(uVar6 * 0x18 + 0x180621f34);
    }
    uVar3 = uVar4;
    if ((in_R9B != '\0') && (uVar3 = uVar4 | 3, (uVar4 & 3) == 0)) {
        uVar3 = uVar4;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18002c8e4
// Address: 0x18002c8e4
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint16_t fcn.18002c7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined *puVar5;
    char in_R9B;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar6 = 0;
    do {
        if (arg3 - arg2 == (uint64_t)*(uint32_t *)(uVar6 * 0x18 + 0x180621f30)) {
            puVar5 = (undefined *)arg2;
            if (arg2 == arg3) break;
            while( true ) {
                cVar1 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))(*(int64_t **)(arg1 + 8), *puVar5);
                cVar2 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))();
                if (cVar1 != cVar2) break;
                puVar5 = puVar5 + 1;
                if (puVar5 == (undefined *)arg3) goto code_r0x00018002c8aa;
            }
        }
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
    } while (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0);
code_r0x00018002c8aa:
    uVar4 = 0;
    if (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0) {
        uVar4 = *(uint16_t *)(uVar6 * 0x18 + 0x180621f34);
    }
    uVar3 = uVar4;
    if ((in_R9B != '\0') && (uVar3 = uVar4 | 3, (uVar4 & 3) == 0)) {
        uVar3 = uVar4;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18002c902
// Address: 0x18002c902
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint16_t fcn.18002c7f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    char cVar2;
    uint16_t uVar3;
    uint16_t uVar4;
    undefined *puVar5;
    char in_R9B;
    uint64_t uVar6;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    
    uVar6 = 0;
    do {
        if (arg3 - arg2 == (uint64_t)*(uint32_t *)(uVar6 * 0x18 + 0x180621f30)) {
            puVar5 = (undefined *)arg2;
            if (arg2 == arg3) break;
            while( true ) {
                cVar1 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))(*(int64_t **)(arg1 + 8), *puVar5);
                cVar2 = (**(code **)(**(int64_t **)(arg1 + 8) + 0x20))();
                if (cVar1 != cVar2) break;
                puVar5 = puVar5 + 1;
                if (puVar5 == (undefined *)arg3) goto code_r0x00018002c8aa;
            }
        }
        uVar6 = (uint64_t)((int32_t)uVar6 + 1);
    } while (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0);
code_r0x00018002c8aa:
    uVar4 = 0;
    if (*(int64_t *)(uVar6 * 0x18 + 0x180621f20) != 0) {
        uVar4 = *(uint16_t *)(uVar6 * 0x18 + 0x180621f34);
    }
    uVar3 = uVar4;
    if ((in_R9B != '\0') && (uVar3 = uVar4 | 3, (uVar4 & 3) == 0)) {
        uVar3 = uVar4;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_18002c930
// Address: 0x18002c930
// Size: 1037 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

char fcn.18002c930(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_80h)
{
    int64_t iVar1;
    uint32_t *puVar2;
    undefined4 uVar3;
    int64_t iVar4;
    char cVar5;
    char cVar6;
    int64_t iVar7;
    bool bVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int32_t iVar12;
    uint32_t *puVar13;
    int64_t *piVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    iVar12 = (int32_t)arg4;
    piVar14 = (int64_t *)((uint64_t)*(uint32_t *)(arg2 + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80));
    iVar4 = *piVar14;
    uVar3 = *(undefined4 *)(piVar14 + 1);
    iVar7 = func_0x00018002e990();
    if ((iVar12 == 0) || (*(int64_t *)(iVar4 * 0x40 + *(int64_t *)(arg1 + 0x98)) != *(int64_t *)arg1)) {
        bVar8 = true;
    } else {
        bVar8 = false;
    }
    if (iVar12 < *(int32_t *)(arg2 + 0x20)) {
        *piVar14 = iVar7;
        if (bVar8) {
            iVar12 = iVar12 + 1;
        } else {
            iVar12 = *(int32_t *)(arg2 + 0x20);
        }
        *(int32_t *)(piVar14 + 1) = iVar12;
        uVar11 = *(uint64_t *)(arg1 + 0x20);
        if (((int64_t)uVar11 < 0) && (uVar11 != 0)) {
            iVar1 = -((~uVar11 >> 5) * 4 + 4);
        } else {
            iVar1 = (uVar11 >> 5) * 4;
        }
        puVar13 = (uint32_t *)(*(int64_t *)(arg1 + 8) + iVar1);
        uVar11 = uVar11 & 0x1f;
        uVar9 = *(uint32_t *)((int64_t)piVar14 + 0xc) & 0x1f;
        puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 8) + (uint64_t)(*(uint32_t *)((int64_t)piVar14 + 0xc) >> 5) * 4);
        if ((puVar2 != puVar13) || (uVar9 != uVar11)) {
            uVar9 = ~(-1 << (int8_t)uVar9);
            if (puVar2 == puVar13) {
                *puVar2 = (~(0xffffffffU >> (0x20U - (char)uVar11 & 0x1f)) | uVar9) & *puVar2;
            } else {
                *puVar2 = *puVar2 & uVar9;
                func_0x0001804986e0(puVar2 + 1, 0, (int64_t)puVar13 - (int64_t)(puVar2 + 1));
                if (uVar11 != 0) {
                    *puVar13 = *puVar13 & ~(0xffffffffU >> (0x20U - (char)uVar11 & 0x1f));
                }
            }
        }
        cVar5 = func_0x00018002aab0(arg1, *(undefined8 *)(arg2 + 0x10));
        goto code_r0x00018002caa5;
    }
    if ((iVar12 == *(int32_t *)(arg2 + 0x20)) || (bVar8)) {
        if ((-1 < *(int32_t *)(arg2 + 0x24)) && (*(int32_t *)(arg2 + 0x24) <= iVar12)) goto code_r0x00018002ca8e;
        if (*(char *)(arg1 + 0xe0) != '\0') {
            cVar5 = func_0x00018002aab0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
            fcn.18002c580(arg1, iVar7 * 0x40 + *(int64_t *)(arg1 + 0x98));
            *piVar14 = iVar7;
            *(int32_t *)(piVar14 + 1) = iVar12 + 1;
            cVar6 = func_0x00018002aab0(arg1, *(undefined8 *)(arg2 + 0x10));
            if (cVar6 != '\0') {
                cVar5 = '\x01';
            }
            goto code_r0x00018002caa5;
        }
        if ((char)placeholder_2 != '\0') {
            *piVar14 = iVar7;
            *(int32_t *)(piVar14 + 1) = iVar12 + 1;
            uVar11 = *(uint64_t *)(arg1 + 0x20);
            if (((int64_t)uVar11 < 0) && (uVar11 != 0)) {
                iVar1 = -((~uVar11 >> 5) * 4 + 4);
            } else {
                iVar1 = (uVar11 >> 5) * 4;
            }
            puVar13 = (uint32_t *)(*(int64_t *)(arg1 + 8) + iVar1);
            uVar11 = uVar11 & 0x1f;
            uVar9 = *(uint32_t *)((int64_t)piVar14 + 0xc) & 0x1f;
            puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 8) + (uint64_t)(*(uint32_t *)((int64_t)piVar14 + 0xc) >> 5) * 4);
            if ((puVar2 != puVar13) || (uVar9 != uVar11)) {
                uVar9 = ~(-1 << (int8_t)uVar9);
                if (puVar2 == puVar13) {
                    *puVar2 = (~(0xffffffffU >> (0x20U - (char)uVar11 & 0x1f)) | uVar9) & *puVar2;
                } else {
                    *puVar2 = *puVar2 & uVar9;
                    func_0x0001804986e0(puVar2 + 1, 0, (int64_t)puVar13 - (int64_t)(puVar2 + 1));
                    if (uVar11 != 0) {
                        *puVar13 = *puVar13 & ~(0xffffffffU >> (0x20U - (char)uVar11 & 0x1f));
                    }
                }
            }
            cVar5 = func_0x00018002aab0(arg1, *(undefined8 *)(arg2 + 0x10));
            if (cVar5 == '\0') {
                *(undefined4 *)(piVar14 + 1) = uVar3;
                *piVar14 = iVar4;
                fcn.18002c580(arg1, iVar7 * 0x40 + *(int64_t *)(arg1 + 0x98));
                cVar5 = func_0x00018002aab0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
            }
            goto code_r0x00018002caa5;
        }
        cVar5 = func_0x00018002aab0(arg1, *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10));
        if (cVar5 != '\0') goto code_r0x00018002caa5;
        fcn.18002c580(arg1, iVar7 * 0x40 + *(int64_t *)(arg1 + 0x98));
        *piVar14 = iVar7;
        *(int32_t *)(piVar14 + 1) = iVar12 + 1;
        uVar11 = *(uint64_t *)(arg1 + 0x20);
        if (((int64_t)uVar11 < 0) && (uVar11 != 0)) {
            iVar1 = -((~uVar11 >> 5) * 4 + 4);
        } else {
            iVar1 = (uVar11 >> 5) * 4;
        }
        puVar13 = (uint32_t *)(*(int64_t *)(arg1 + 8) + iVar1);
        uVar11 = uVar11 & 0x1f;
        uVar9 = *(uint32_t *)((int64_t)piVar14 + 0xc) & 0x1f;
        puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 8) + (uint64_t)(*(uint32_t *)((int64_t)piVar14 + 0xc) >> 5) * 4);
        if ((puVar2 == puVar13) && (uVar9 == uVar11)) {
code_r0x00018002cc2a:
            uVar10 = *(undefined8 *)(arg2 + 0x10);
        } else {
            uVar9 = ~(-1 << (int8_t)uVar9);
            if (puVar2 != puVar13) {
                *puVar2 = *puVar2 & uVar9;
                func_0x0001804986e0(puVar2 + 1, 0, (int64_t)puVar13 - (int64_t)(puVar2 + 1));
                if (uVar11 != 0) {
                    *puVar13 = *puVar13 & ~(0xffffffffU >> (0x20U - (char)uVar11 & 0x1f));
                }
                goto code_r0x00018002cc2a;
            }
            *puVar2 = (~(0xffffffffU >> (0x20U - (char)uVar11 & 0x1f)) | uVar9) & *puVar2;
            uVar10 = *(undefined8 *)(arg2 + 0x10);
        }
    } else {
        cVar5 = '\0';
        if ((iVar12 != 1) || ((*(uint8_t *)(arg1 + 0xd0) & 0x3e) == 0)) goto code_r0x00018002caa5;
code_r0x00018002ca8e:
        uVar10 = *(undefined8 *)(*(int64_t *)(arg2 + 0x28) + 0x10);
    }
    cVar5 = func_0x00018002aab0(arg1, uVar10);
code_r0x00018002caa5:
    *(undefined4 *)(piVar14 + 1) = uVar3;
    *piVar14 = iVar4;
    *(int64_t *)(arg1 + 0xb0) = iVar7;
    return cVar5;
}

// ============================================================
// Function: FUN_18002cdd0
// Address: 0x18002cdd0
// Size: 5180 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018002d744)
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_d4h
// WARNING: Removing unreachable block (ram,0x00018002d773)
// WARNING: [rz-ghidra] Detected overlap for variable var_dfh
// WARNING: [rz-ghidra] Detected overlap for variable var_e7h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_d7h

void fcn.18002cdd0(int64_t arg1)
{
    uint32_t *puVar1;
    undefined uVar2;
    int64_t **ppiVar3;
    undefined8 uVar4;
    code *pcVar5;
    bool bVar6;
    int64_t iVar7;
    uint8_t uVar8;
    char cVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined8 *puVar12;
    undefined (*pauVar13) [16];
    int64_t iVar14;
    undefined8 *puVar15;
    undefined8 *puVar16;
    undefined8 *puVar17;
    undefined8 *puVar18;
    char *pcVar19;
    int64_t *piVar20;
    int64_t *piVar21;
    int64_t iVar22;
    uint64_t uVar23;
    uint8_t *puVar24;
    undefined *puVar25;
    undefined *puVar26;
    undefined *puVar27;
    uint32_t uVar28;
    uint64_t uVar29;
    int64_t iVar30;
    uint64_t uVar31;
    int64_t iVar32;
    int64_t iVar33;
    uint32_t uVar34;
    int32_t iVar35;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    undefined4 extraout_XMM0_Da_03;
    undefined4 extraout_XMM0_Da_04;
    undefined4 uVar36;
    undefined4 extraout_XMM0_Da_05;
    undefined8 uStackY_110;
    undefined auStackY_108 [8];
    undefined auStackY_100 [24];
    int64_t var_e8h;
    int64_t var_e0h;
    undefined4 var_d8h;
    int64_t var_d4h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar25 = auStackY_108;
    puVar26 = auStackY_108;
    puVar27 = auStackY_108;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_108;
    var_d4h._0_4_ = 0;
    bVar6 = false;
    iVar10 = *(int32_t *)(arg1 + 0x70);
    while ((iVar10 != -1 && (iVar10 != 0x7c))) {
        if (iVar10 == 0x29) {
            if (*(int32_t *)(arg1 + 0x14) != 0) break;
            if ((*(uint32_t *)(arg1 + 0x60) >> 0x1b & 1) == 0) {
                fcn.18002ed40(0x29, 5);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
code_r0x00018002ce55:
            if (iVar10 == 0x24) {
                puVar12 = (undefined8 *)fcn.180459890(0x20);
                *puVar12 = 0x1806220a0;
                puVar12[1] = 3;
                puVar12[2] = 0;
                puVar12[3] = 0;
                fcn.18002e210(arg1 + 0x38);
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
                goto code_r0x00018002e0dd;
            }
            if (iVar10 == 0x2a) {
                if (((*(uint32_t *)(arg1 + 0x60) >> 0x19 & 1) == 0) || (bVar6)) goto code_r0x00018002e146;
code_r0x00018002dba7:
                if ((iVar10 == 0x5d) && ((*(uint32_t *)(arg1 + 0x60) >> 0x1c & 1) == 0)) {
                    fcn.18002ed40(0x5d, 4);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
            } else {
code_r0x00018002dc3a:
                if (((iVar10 == 0x2b) || (iVar10 == 0x3f)) || (iVar10 == 0x7b)) {
code_r0x00018002e146:
                    fcn.18002ed40(iVar10, 10);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                if (iVar10 != 0x7d) goto code_r0x00018002dba7;
                if ((*(uint32_t *)(arg1 + 0x60) >> 0x1b & 1) == 0) {
                    fcn.18002ed40(0x7d, 6);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
            }
code_r0x00018002dbba:
            fcn.18002ed50(arg1 + 0x38, *(undefined *)(arg1 + 0x75));
            pcVar19 = *(char **)arg1;
            if (pcVar19 != *(char **)(arg1 + 8)) {
                if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
code_r0x00018002dc0a:
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
code_r0x00018002dc0d:
            fcn.18002b970(arg1);
code_r0x00018002dc15:
            iVar11 = 0;
            iVar35 = -1;
            iVar10 = *(int32_t *)(arg1 + 0x70);
            if (iVar10 != 0x2a) {
                if (iVar10 == 0x2b) {
                    iVar11 = 1;
                } else if (iVar10 == 0x3f) {
                    iVar35 = 1;
                } else {
                    if (iVar10 != 0x7b) goto code_r0x00018002e0dd;
                    pcVar19 = *(char **)arg1;
                    if (pcVar19 != *(char **)(arg1 + 8)) {
                        if (((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                           ((pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8) &&
                            ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                             (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))))) {
                            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                        }
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    fcn.18002b970(arg1);
                    cVar9 = fcn.18002f160(arg1, 7, 0);
                    uVar36 = extraout_XMM0_Da_04;
                    if (cVar9 == '\0') {
code_r0x00018002e125:
                        *(undefined8 *)(puVar27 + -8) = 0x18002e12f;
                        fcn.18002ed40(uVar36, 7);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                    iVar11 = *(int32_t *)(arg1 + 0x6c);
                    iVar35 = iVar11;
                    if (*(int32_t *)(arg1 + 0x70) == 0x2c) {
                        pcVar19 = *(char **)arg1;
                        if (pcVar19 != *(char **)(arg1 + 8)) {
                            if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                                (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                               ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                                (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                            }
                            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                        }
                        uVar36 = fcn.18002b970(arg1);
                        iVar35 = -1;
                        if (*(int32_t *)(arg1 + 0x70) != 0x7d) {
                            cVar9 = fcn.18002f160(arg1, 7, 0);
                            if (cVar9 == '\0') {
                                fcn.18002ed40(extraout_XMM0_Da_05, 7);
                                pcVar5 = (code *)swi(3);
                                (*pcVar5)();
                                return;
                            }
                            uVar36 = extraout_XMM0_Da_05;
                            iVar35 = *(int32_t *)(arg1 + 0x6c);
                            goto code_r0x00018002dd6f;
                        }
                    } else {
code_r0x00018002dd6f:
                        if (*(int32_t *)(arg1 + 0x70) != 0x7d) goto code_r0x00018002e201;
                    }
                    if ((iVar35 != -1) && (iVar35 < iVar11)) {
code_r0x00018002e201:
                        fcn.18002ed40(uVar36, 7);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                }
            }
            pcVar19 = *(char **)arg1;
            if (pcVar19 != *(char **)(arg1 + 8)) {
                if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            fcn.18002b970(arg1);
            uVar29 = *(uint64_t *)(arg1 + 0x60);
            if (((uVar29 >> 9 & 1) == 0) || (*(int32_t *)(arg1 + 0x70) != 0x3f)) {
                uVar8 = 1;
                var_e8h._0_1_ = 1;
            } else {
                uVar8 = 0;
                var_e8h._0_1_ = 0;
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((uVar29 & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((uVar29 & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
            }
            iVar14 = *(int64_t *)(arg1 + 0x40);
            if ((*(int32_t *)(iVar14 + 8) == 6) && (*(int32_t *)(iVar14 + 0x24) != 1)) {
                puVar12 = (undefined8 *)fcn.180459890(0x30);
                puVar12[1] = 6;
                puVar12[2] = 0;
                puVar12[3] = 0;
                *puVar12 = 0x1806221d8;
                puVar12[4] = 0;
                puVar12[5] = 0;
                fcn.18002e210(arg1 + 0x38, puVar12);
                *(int32_t *)(iVar14 + 0x24) = *(int32_t *)(iVar14 + 0x24) + -1;
                fcn.18002ed50(arg1 + 0x38, 
                              *(undefined *)(*(int64_t *)(iVar14 + 0x28) + (uint64_t)*(uint32_t *)(iVar14 + 0x24)));
            }
            iVar14 = *(int64_t *)(arg1 + 0x40);
            if ((*(int32_t *)(iVar14 + 8) == 9) || (*(int32_t *)(iVar14 + 8) == 0xe)) {
                iVar14 = *(int64_t *)(iVar14 + 0x20);
            } else if ((iVar11 == 0) && (iVar35 == 1)) {
                puVar12 = (undefined8 *)fcn.180459890(0x20);
                puVar12[1] = 0x11;
                puVar12[2] = 0;
                puVar12[3] = 0;
                *puVar12 = 0x1806220a0;
                puVar15 = (undefined8 *)fcn.180459890(0x30);
                puVar15[1] = 0x10;
                puVar15[2] = 0;
                puVar15[3] = 0;
                *puVar15 = 0x1806220b8;
                puVar15[4] = puVar12;
                puVar15[5] = 0;
                puVar16 = (undefined8 *)fcn.180459890(0x30);
                puVar16[1] = 0x10;
                puVar16[2] = 0;
                puVar16[3] = 0;
                *puVar16 = 0x1806220b8;
                puVar16[4] = puVar12;
                puVar16[5] = 0;
                puVar17 = (undefined8 *)fcn.180459890(0x20);
                *puVar17 = 0x1806220a0;
                puVar17[1] = 8;
                puVar17[2] = 0;
                puVar17[3] = 0;
                puVar18 = (undefined8 *)fcn.180459890(0x28);
                puVar18[1] = 9;
                *puVar18 = 0x1806220a8;
                puVar18[4] = puVar17;
                puVar16[2] = puVar17;
                puVar17[3] = puVar16;
                puVar17[2] = puVar18;
                puVar18[3] = puVar17;
                puVar18[2] = puVar12;
                puVar15[5] = puVar16;
                fcn.18002e210(arg1 + 0x38);
                *(undefined8 **)(*(int64_t *)(iVar14 + 0x18) + 0x10) = puVar15;
                puVar15[3] = *(undefined8 *)(iVar14 + 0x18);
                *(undefined8 **)(iVar14 + 0x18) = puVar15;
                puVar15[2] = iVar14;
                if ((uint8_t)var_e8h == 0) {
                    iVar22 = puVar16[2];
                    uVar4 = *(undefined8 *)(iVar14 + 0x18);
                    *(undefined8 *)(iVar14 + 0x18) = *(undefined8 *)(iVar22 + 0x18);
                    *(undefined8 *)(iVar22 + 0x18) = uVar4;
                    uVar4 = puVar15[2];
                    puVar15[2] = puVar16[2];
                    puVar16[2] = uVar4;
                }
                goto code_r0x00018002e0dd;
            }
            puVar12 = (undefined8 *)fcn.180459890(0x28);
            *(undefined4 *)(puVar12 + 1) = 0x13;
            *(undefined4 *)((int64_t)puVar12 + 0xc) = 0;
            puVar12[2] = 0;
            puVar12[3] = 0;
            *puVar12 = 0x1806220a8;
            puVar12[4] = 0;
            puVar15 = (undefined8 *)fcn.180459890(0x38);
            iVar10 = *(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x24);
            *(int32_t *)(*(int64_t *)(arg1 + 0x38) + 0x24) = iVar10 + 1;
            *(undefined4 *)(puVar15 + 1) = 0x12;
            *(uint32_t *)((int64_t)puVar15 + 0xc) = (uint32_t)uVar8 * 2;
            puVar15[2] = 0;
            puVar15[3] = 0;
            *puVar15 = 0x180621f10;
            *(int32_t *)(puVar15 + 4) = iVar11;
            *(int32_t *)((int64_t)puVar15 + 0x24) = iVar35;
            puVar15[5] = puVar12;
            *(int32_t *)(puVar15 + 6) = iVar10;
            *(undefined4 *)((int64_t)puVar15 + 0x34) = 0xffffffff;
            puVar12[4] = puVar15;
            fcn.18002e210(arg1 + 0x38);
            *(undefined8 **)(*(int64_t *)(iVar14 + 0x18) + 0x10) = puVar15;
            puVar15[3] = *(undefined8 *)(iVar14 + 0x18);
            *(undefined8 **)(iVar14 + 0x18) = puVar15;
            puVar15[2] = iVar14;
        } else {
            if (iVar10 == 0x2e) {
                puVar12 = (undefined8 *)fcn.180459890(0x20);
                *puVar12 = 0x1806220a0;
                puVar12[1] = 5;
                puVar12[2] = 0;
                puVar12[3] = 0;
                fcn.18002e210(arg1 + 0x38);
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(char **)arg1 = pcVar19;
                    }
                    goto code_r0x00018002dc0a;
                }
                goto code_r0x00018002dc0d;
            }
            if (iVar10 == 0x5c) {
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(char **)arg1 = pcVar19;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
                if ((*(uint64_t *)(arg1 + 0x60) & 0x40) != 0) {
                    if (*(char *)(arg1 + 0x75) == 'b') {
                        puVar12 = (undefined8 *)fcn.180459890(0x20);
                        *puVar12 = 0x1806220a0;
                        puVar12[1] = 4;
                        puVar12[2] = 0;
                        puVar12[3] = 0;
                        fcn.18002e210(arg1 + 0x38);
                        pcVar19 = *(char **)arg1;
                        if (pcVar19 != *(char **)(arg1 + 8)) {
                            if (((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                               ((pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8) &&
                                ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                                 (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))))) {
                                *(char **)arg1 = pcVar19;
                            }
                            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                        }
                        fcn.18002b970(arg1);
                    } else {
                        if (*(char *)(arg1 + 0x75) != 'B') goto code_r0x00018002d0da;
                        puVar12 = (undefined8 *)fcn.180459890(0x20);
                        *puVar12 = 0x1806220a0;
                        puVar12[1] = 4;
                        puVar12[2] = 0;
                        puVar12[3] = 0;
                        fcn.18002e210(arg1 + 0x38);
                        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc);
                        *puVar1 = *puVar1 ^ 1;
                        pcVar19 = *(char **)arg1;
                        if (pcVar19 != *(char **)(arg1 + 8)) {
                            if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                                (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                               ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                                (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                            }
                            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                        }
                        fcn.18002b970(arg1);
                    }
                    goto code_r0x00018002e0dd;
                }
code_r0x00018002d0da:
                if ((*(uint64_t *)(arg1 + 0x60) & 0x80080) != 0) {
                    if ((uint8_t)(*(char *)(arg1 + 0x75) - 0x30U) < 10) {
                        iVar10 = *(char *)(arg1 + 0x75) + -0x30;
                        *(int32_t *)(arg1 + 0x6c) = iVar10;
                        if (iVar10 != -1) {
                            pcVar19 = *(char **)arg1;
                            if (pcVar19 != *(char **)(arg1 + 8)) {
                                if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                                    (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0))))))
                                {
                                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                                }
                                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                            }
                            uVar36 = fcn.18002b970(arg1);
                            uVar29 = *(uint64_t *)(arg1 + 0x60);
                            if (((uVar29 >> 0x13 & 1) == 0) || (*(int32_t *)(arg1 + 0x6c) != 0)) {
                                if ((char)uVar29 < '\0') {
                                    if ((uVar29 >> 8 & 1) == 0) {
                                        uVar36 = fcn.18002f160(arg1, 3, *(undefined4 *)(arg1 + 0x6c));
                                    }
                                    iVar10 = *(int32_t *)(arg1 + 0x6c);
                                    uVar29 = (uint64_t)iVar10;
                                    if (iVar10 == 0) {
                                        fcn.18002ed40(uVar36, 2);
                                        pcVar5 = (code *)swi(3);
                                        (*pcVar5)();
                                        return;
                                    }
                                    if (((*(uint32_t *)(arg1 + 0x10) < uVar29) || (*(uint64_t *)(arg1 + 0x30) <= uVar29)
                                        ) || (uVar31 = uVar29 >> 5, uVar8 = (uint8_t)iVar10 & 0x1f,
                                             uVar29 = (uint64_t)uVar8,
                                             (*(uint32_t *)(*(int64_t *)(arg1 + 0x18) + uVar31 * 4) >> uVar8 & 1) == 0))
                                    {
                                        fcn.18002ed40(uVar29, 3);
                                        pcVar5 = (code *)swi(3);
                                        (*pcVar5)();
                                        return;
                                    }
                                    puVar12 = (undefined8 *)fcn.180459890(0x28);
                                    puVar12[1] = 0xf;
                                    puVar12[2] = 0;
                                    puVar12[3] = 0;
                                    *puVar12 = 0x1806220a8;
                                    *(int32_t *)(puVar12 + 4) = iVar10;
                                    fcn.18002e210(arg1 + 0x38);
                                }
                            } else {
                                cVar9 = *(char *)(arg1 + 0x75);
                                if (((uint8_t)(cVar9 - 0x30U) < 10) && (cVar9 != '/')) {
                                    fcn.18002ed40(cVar9, 2);
                                    pcVar5 = (code *)swi(3);
                                    (*pcVar5)();
                                    return;
                                }
                                fcn.18002ed50(arg1 + 0x38);
                            }
                            goto code_r0x00018002dc15;
                        }
                    } else {
                        *(undefined4 *)(arg1 + 0x6c) = 0xffffffff;
                    }
                }
                cVar9 = fcn.18002f320(arg1, 0);
                if (cVar9 == '\0') {
                    uVar36 = extraout_XMM0_Da;
                    if (((*(uint32_t *)(arg1 + 0x60) >> 0x10 & 1) == 0) ||
                       (cVar9 = fcn.18002f250(arg1), uVar36 = extraout_XMM0_Da_00, cVar9 == '\0')) {
                        fcn.18002ed40(uVar36, 2);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                } else {
                    fcn.18002ed50(arg1 + 0x38);
                }
                goto code_r0x00018002dc15;
            }
            if (iVar10 == 0x5b) {
                *(undefined *)(arg1 + 0x74) = 1;
                if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
                puVar12 = (undefined8 *)fcn.180459890(0x50);
                puVar12[1] = 7;
                puVar12[2] = 0;
                puVar12[3] = 0;
                *puVar12 = 0x1806220b0;
                puVar12[4] = 0;
                puVar12[5] = 0;
                puVar12[6] = 0;
                puVar12[7] = 0;
                *(undefined2 *)(puVar12 + 8) = 0;
                puVar12[9] = 0;
                fcn.18002e210(arg1 + 0x38, puVar12);
                if (*(int32_t *)(arg1 + 0x70) == 0x5e) {
                    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc);
                    *puVar1 = *puVar1 ^ 1;
                    pcVar19 = *(char **)arg1;
                    if (pcVar19 != *(char **)(arg1 + 8)) {
                        if (((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                           ((pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8) &&
                            ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                             (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))))) {
                            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                        }
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    fcn.18002b970(arg1);
                }
                iVar10 = fcn.180030040(arg1, 1);
                uVar36 = extraout_XMM0_Da_01;
                while (iVar10 != 0) {
                    if (((iVar10 == 1) && ((*(uint32_t *)(arg1 + 0x60) >> 0x13 & 1) == 0)) &&
                       (*(char *)(arg1 + 0x76) == '\0')) {
                        fcn.18002ed40(uVar36, 2);
code_r0x00018002e188:
                        fcn.18045471c(8);
code_r0x00018002e193:
                        fcn.18045471c(8);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                    if (*(int32_t *)(arg1 + 0x70) == 0x2d) {
                        uVar29 = (uint64_t)*(uint8_t *)(arg1 + 0x76);
                        uVar2 = *(undefined *)(arg1 + 0x75);
                        pcVar19 = *(char **)arg1;
                        if (pcVar19 != *(char **)(arg1 + 8)) {
                            if (((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                               ((pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8) &&
                                ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                                 (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))))) {
                                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                            }
                            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                        }
                        fcn.18002b970(arg1);
                        iVar11 = fcn.180030040(arg1, 0);
                        if (iVar11 == 0) {
                            if (iVar10 != 2) {
                                fcn.180030670(arg1 + 0x38, uVar29);
                            }
                            uVar36 = fcn.180030670(arg1 + 0x38, uVar2);
                            break;
                        }
                        if ((iVar10 == 2) || (iVar11 == 2)) {
                            fcn.18002ed40(extraout_XMM0_Da_02, 8);
                            pcVar5 = (code *)swi(3);
                            (*pcVar5)();
                            return;
                        }
                        uVar34 = (uint32_t)*(uint8_t *)(arg1 + 0x76);
                        if ((*(uint32_t *)(arg1 + 0x68) & 0x100) != 0) {
                            piVar21 = *(int64_t **)(*(int64_t *)(arg1 + 0x58) + 8);
                            uVar8 = (**(code **)(*piVar21 + 0x20))(piVar21, uVar29);
                            uVar29 = (uint64_t)uVar8;
                            piVar21 = *(int64_t **)(*(int64_t *)(arg1 + 0x58) + 8);
                            uVar8 = (**(code **)(*piVar21 + 0x20))(piVar21, uVar34);
                            uVar34 = (uint32_t)uVar8;
                        }
                        var_e8h._0_1_ = (uint8_t)uVar34;
                        var_e0h._0_1_ = (uint8_t)uVar29;
                        iVar14 = *(int64_t *)(arg1 + 0x40);
                        if ((*(uint32_t *)(arg1 + 0x48) & 0x800) == 0) {
                            if ((uint8_t)var_e8h < (uint8_t)var_e0h) goto code_r0x00018002e193;
                            if (*(int64_t *)(iVar14 + 0x28) == 0) {
                                pauVar13 = (undefined (*) [16])fcn.180459890(0x20);
                                *pauVar13 = ZEXT816(0);
                                pauVar13[1] = ZEXT816(0);
                                *(undefined (**) [16])(iVar14 + 0x28) = pauVar13;
                                uVar34 = (uint32_t)(uint8_t)var_e8h;
                            }
                            uVar28 = (uint32_t)uVar29;
                            while (uVar28 <= uVar34) {
                                puVar24 = (uint8_t *)((uVar29 >> 3) + *(int64_t *)(iVar14 + 0x28));
                                *puVar24 = *puVar24 | (uint8_t)(1 << ((uint32_t)uVar29 & 7));
                                uVar28 = (uint32_t)uVar29 + 1;
                                uVar29 = (uint64_t)uVar28;
                            }
                            goto code_r0x00018002d7cc;
                        }
                        fcn.1800309b0(CONCAT44((uint32_t)var_d4h, var_d8h));
                        fcn.18002e800(CONCAT44((uint32_t)var_d4h, var_d8h));
                        iVar7 = var_a0h;
                        iVar30 = var_c0h;
                        iVar22 = (int64_t)&var_d4h + 4;
                        if (0xf < (uint64_t)var_b8h) {
                            iVar22 = CONCAT71(stack0xffffffffffffff31, var_d4h._4_1_);
                        }
                        piVar21 = &var_b0h;
                        if (0xf < (uint64_t)var_98h) {
                            piVar21 = (int64_t *)var_b0h;
                        }
                        iVar32 = var_a0h;
                        if ((uint64_t)var_c0h < (uint64_t)var_a0h) {
                            iVar32 = var_c0h;
                        }
                        iVar10 = fcn.180497f30(piVar21, iVar22, iVar32);
                        if (iVar10 == 0) {
                            if ((uint64_t)iVar7 < (uint64_t)iVar30) {
                                cVar9 = -1;
                                goto code_r0x00018002d4aa;
                            }
                            if ((uint64_t)iVar30 < (uint64_t)iVar7) goto code_r0x00018002d4a8;
                        } else {
                            if (iVar10 < 0) {
                                cVar9 = -1;
                            } else {
code_r0x00018002d4a8:
                                cVar9 = '\x01';
                            }
code_r0x00018002d4aa:
                            if ('\0' < cVar9) goto code_r0x00018002e188;
                        }
                        uVar29 = 0;
                        do {
                            var_d8h = CONCAT31(var_d8h._1_3_, (char)uVar29);
                            ppiVar3 = *(int64_t ***)(arg1 + 0x50);
                            fcn.180014b30(&var_90h, &var_d8h, (int64_t)&var_d8h + 1, (int64_t)&var_d8h + 1);
                            piVar21 = &var_90h;
                            if (0xf < (uint64_t)var_78h) {
                                piVar21 = (int64_t *)var_90h;
                            }
                            piVar20 = &var_90h;
                            if (0xf < (uint64_t)var_78h) {
                                piVar20 = (int64_t *)var_90h;
                            }
                            (**(code **)(**ppiVar3 + 0x20))(*ppiVar3, &var_70h, piVar20, (int64_t)piVar21 + var_80h);
                            if (0xf < (uint64_t)var_78h) {
                                uVar31 = var_78h + 1;
                                iVar22 = var_90h;
                                if (uVar31 < 0x1000) {
code_r0x00018002d542:
                                    fcn.180459c3c(iVar22, uVar31);
                                    goto code_r0x00018002d548;
                                }
                                iVar22 = *(int64_t *)(var_90h + -8);
                                if ((var_90h - iVar22) - 8U < 0x20) {
                                    uVar31 = var_78h + 0x28;
                                    goto code_r0x00018002d542;
                                }
code_r0x00018002e110:
                                pcVar5 = (code *)swi(0x29);
                                (*pcVar5)(5);
                                puVar25 = auStackY_100;
                                goto code_r0x00018002e117;
                            }
code_r0x00018002d548:
                            uVar31 = var_58h;
                            iVar7 = var_60h;
                            iVar30 = var_70h;
                            iVar22 = var_a0h;
                            piVar21 = &var_70h;
                            if (0xf < (uint64_t)var_58h) {
                                piVar21 = (int64_t *)var_70h;
                            }
                            piVar20 = &var_b0h;
                            if (0xf < (uint64_t)var_98h) {
                                piVar20 = (int64_t *)var_b0h;
                            }
                            iVar32 = var_a0h;
                            if ((uint64_t)var_60h < (uint64_t)var_a0h) {
                                iVar32 = var_60h;
                            }
                            iVar10 = fcn.180497f30(piVar20, piVar21, iVar32);
                            iVar32 = var_c0h;
                            if (iVar10 == 0) {
                                if ((uint64_t)iVar22 < (uint64_t)iVar7) {
                                    cVar9 = -1;
                                    goto code_r0x00018002d598;
                                }
                                if ((uint64_t)iVar7 < (uint64_t)iVar22) goto code_r0x00018002d596;
code_r0x00018002d5a0:
                                iVar22 = (int64_t)&var_d4h + 4;
                                if (0xf < (uint64_t)var_b8h) {
                                    iVar22 = CONCAT71(stack0xffffffffffffff31, var_d4h._4_1_);
                                }
                                piVar21 = &var_70h;
                                if (0xf < uVar31) {
                                    piVar21 = (int64_t *)iVar30;
                                }
                                iVar33 = iVar7;
                                if ((uint64_t)var_c0h < (uint64_t)iVar7) {
                                    iVar33 = var_c0h;
                                }
                                iVar10 = fcn.180497f30(piVar21, iVar22, iVar33);
                                if (iVar10 == 0) {
                                    if ((uint64_t)iVar7 < (uint64_t)iVar32) {
                                        cVar9 = -1;
                                        goto code_r0x00018002d5e4;
                                    }
                                    if ((uint64_t)iVar32 < (uint64_t)iVar7) goto code_r0x00018002d5e2;
                                } else {
                                    if (iVar10 < 0) {
                                        cVar9 = -1;
                                    } else {
code_r0x00018002d5e2:
                                        cVar9 = '\x01';
                                    }
code_r0x00018002d5e4:
                                    if ('\0' < cVar9) goto code_r0x00018002d62c;
                                }
                                pauVar13 = *(undefined (**) [16])(iVar14 + 0x28);
                                if (pauVar13 == (undefined (*) [16])0x0) {
                                    pauVar13 = (undefined (*) [16])fcn.180459890(0x20);
                                    *pauVar13 = ZEXT816(0);
                                    pauVar13[1] = ZEXT816(0);
                                    *(undefined (**) [16])(iVar14 + 0x28) = pauVar13;
                                }
                                (*pauVar13)[uVar29 >> 3] =
                                     (*pauVar13)[uVar29 >> 3] | (uint8_t)(1 << ((uint32_t)uVar29 & 7));
                                iVar30 = var_70h;
                                uVar31 = var_58h;
                            } else {
                                if (iVar10 < 0) {
                                    cVar9 = -1;
                                } else {
code_r0x00018002d596:
                                    cVar9 = '\x01';
                                }
code_r0x00018002d598:
                                if (cVar9 < '\x01') goto code_r0x00018002d5a0;
                            }
code_r0x00018002d62c:
                            if (0xf < uVar31) {
                                uVar23 = uVar31 + 1;
                                iVar22 = iVar30;
                                if (0xfff < uVar23) {
                                    iVar22 = *(int64_t *)(iVar30 + -8);
                                    if (0x1f < (iVar30 - iVar22) - 8U) goto code_r0x00018002e110;
                                    uVar23 = uVar31 + 0x28;
                                }
                                fcn.180459c3c(iVar22, uVar23);
                            }
                            var_d4h._0_4_ = (uint32_t)var_d4h | 3;
                            uVar34 = (uint32_t)uVar29 + 1;
                            uVar29 = (uint64_t)uVar34;
                        } while (uVar34 < 0x100);
                        if (0xf < (uint64_t)var_b8h) {
                            uVar29 = var_b8h + 1;
                            iVar30 = CONCAT71(stack0xffffffffffffff31, var_d4h._4_1_);
                            iVar22 = iVar30;
                            if (uVar29 < 0x1000) {
code_r0x00018002d6ad:
                                fcn.180459c3c(iVar22, uVar29);
                                goto code_r0x00018002d6b2;
                            }
                            iVar22 = *(int64_t *)(iVar30 + -8);
                            if ((iVar30 - iVar22) - 8U < 0x20) {
                                uVar29 = var_b8h + 0x28;
                                goto code_r0x00018002d6ad;
                            }
code_r0x00018002e117:
                            pcVar5 = (code *)swi(0x29);
                            (*pcVar5)(5);
                            puVar26 = puVar25 + 8;
code_r0x00018002e11e:
                            pcVar5 = (code *)swi(0x29);
                            uVar36 = (*pcVar5)(5);
                            puVar27 = puVar26 + 8;
                            goto code_r0x00018002e125;
                        }
code_r0x00018002d6b2:
                        var_c0h = 0;
                        var_b8h = 0xf;
                        var_d4h._4_1_ = 0;
                        if (0xf < (uint64_t)var_98h) {
                            uVar29 = var_98h + 1;
                            iVar22 = var_b0h;
                            if (0xfff < uVar29) {
                                iVar22 = *(int64_t *)(var_b0h + -8);
                                if (0x1f < (var_b0h - iVar22) - 8U) goto code_r0x00018002e11e;
                                uVar29 = var_98h + 0x28;
                            }
                            fcn.180459c3c(iVar22, uVar29);
                        }
                        puVar12 = *(undefined8 **)(iVar14 + 0x38);
                        if (puVar12 == (undefined8 *)0x0) {
                            puVar12 = (undefined8 *)fcn.180459890(0x10);
                            *puVar12 = 0;
                            puVar12[1] = 0;
                            *(undefined8 **)(iVar14 + 0x38) = puVar12;
                        }
                        fcn.18002f910(puVar12, (uint8_t)var_e0h);
                        fcn.18002f910(*(undefined8 *)(iVar14 + 0x38), (uint8_t)var_e8h);
                    } else if (iVar10 == 1) {
                        fcn.180030670(arg1 + 0x38, *(undefined *)(arg1 + 0x76));
                    }
code_r0x00018002d7cc:
                    iVar10 = fcn.180030040(arg1, 0);
                    uVar36 = extraout_XMM0_Da_03;
                }
                *(undefined *)(arg1 + 0x74) = 0;
                if (*(int32_t *)(arg1 + 0x70) != 0x5d) {
                    fcn.18002ed40(uVar36, 4);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if (((*pcVar19 == '\\') && (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
                goto code_r0x00018002dc15;
            }
            if (iVar10 != 0x28) {
                if (iVar10 != 0x5e) goto code_r0x00018002ce55;
                if (((*(uint32_t *)(arg1 + 0x60) >> 0x18 & 1) != 0) && (bVar6)) goto code_r0x00018002dc3a;
                puVar12 = (undefined8 *)fcn.180459890(0x20);
                *puVar12 = 0x1806220a0;
                puVar12[1] = 2;
                puVar12[2] = 0;
                puVar12[3] = 0;
                fcn.18002e210(arg1 + 0x38, puVar12);
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
                if ((((*(uint32_t *)(arg1 + 0x60) >> 0x19 & 1) == 0) || (*(int32_t *)(arg1 + 0x70) != 0x2a)) || (bVar6))
                goto code_r0x00018002e0dd;
                goto code_r0x00018002dbba;
            }
            pcVar19 = *(char **)arg1;
            if (pcVar19 != *(char **)(arg1 + 8)) {
                if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            uVar36 = fcn.18002b970(arg1);
            *(int32_t *)(arg1 + 0x14) = *(int32_t *)(arg1 + 0x14) + 1;
            if (999 < *(int32_t *)(arg1 + 0x14)) {
                fcn.18002ed40(uVar36, 0xc);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            uVar29 = *(uint64_t *)(arg1 + 0x60);
            if (((uVar29 >> 0x1a & 1) == 0) && (*(int32_t *)(arg1 + 0x70) == 0x29)) {
                fcn.18002ed40(uVar36, 5);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            if (((uVar29 & 0x20) == 0) || (*(int32_t *)(arg1 + 0x70) != 0x3f)) {
                if ((*(uint32_t *)(arg1 + 0x68) & 0x200) != 0) goto code_r0x00018002d9d0;
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + 1;
                uVar34 = *(uint32_t *)(arg1 + 0x10);
                if (999 < uVar34) {
                    fcn.18045471c(0xc);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                puVar12 = (undefined8 *)fcn.180459890(0x28);
                puVar12[1] = 0xd;
                puVar12[2] = 0;
                puVar12[3] = 0;
                *puVar12 = 0x1806220a8;
                *(uint32_t *)(puVar12 + 4) = uVar34;
                iVar14 = fcn.18002e210(arg1 + 0x38, puVar12);
                fcn.18002bb90(var_b8h);
                fcn.18002bf70(arg1 + 0x38, iVar14);
                uVar36 = fcn.18002c250(arg1 + 0x18, (uint64_t)(*(int32_t *)(arg1 + 0x10) + 1));
                puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + (uint64_t)(*(uint32_t *)(iVar14 + 0x20) >> 5) * 4);
                *puVar1 = *puVar1 | 1 << (*(uint32_t *)(iVar14 + 0x20) & 0x1f);
code_r0x00018002da66:
                *(int32_t *)(arg1 + 0x14) = *(int32_t *)(arg1 + 0x14) + -1;
                bVar6 = true;
            } else {
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                       ((((uVar29 & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                        (((*(uint8_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                fcn.18002b970(arg1);
                iVar10 = *(int32_t *)(arg1 + 0x70);
                pcVar19 = *(char **)arg1;
                if (pcVar19 != *(char **)(arg1 + 8)) {
                    if (((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                       ((pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8) &&
                        ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                         (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                uVar36 = fcn.18002b970(arg1);
                if (iVar10 == 0x3a) {
code_r0x00018002d9d0:
                    uVar36 = fcn.18002f780(arg1);
                    goto code_r0x00018002da66;
                }
                if (iVar10 == 0x21) {
                    uVar36 = fcn.18002f7f0(arg1, 1);
                    *(int32_t *)(arg1 + 0x14) = *(int32_t *)(arg1 + 0x14) + -1;
                    bVar6 = false;
                } else {
                    if (iVar10 != 0x3d) {
                        fcn.18002ed40(uVar36, 10);
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                    uVar36 = fcn.18002f7f0(arg1, 0);
                    *(int32_t *)(arg1 + 0x14) = *(int32_t *)(arg1 + 0x14) + -1;
                    bVar6 = false;
                }
            }
            if (*(int32_t *)(arg1 + 0x70) != 0x29) {
                fcn.18002ed40(uVar36, 5);
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            pcVar19 = *(char **)arg1;
            if (pcVar19 != *(char **)(arg1 + 8)) {
                if ((((*pcVar19 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar19 = pcVar19 + 1, pcVar19 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar19 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar19 + 0x85U & 0xfd) == 0)))))) {
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            fcn.18002b970(arg1);
            if (bVar6) goto code_r0x00018002dc15;
        }
code_r0x00018002e0dd:
        bVar6 = true;
        iVar10 = *(int32_t *)(arg1 + 0x70);
    }
    fcn.180459870(var_50h ^ (uint64_t)auStackY_108);
    return;
}

// ============================================================
// Function: FUN_18002e250
// Address: 0x18002e250
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e26b
// Address: 0x18002e26b
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e2ba
// Address: 0x18002e2ba
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e2d5
// Address: 0x18002e2d5
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e30f
// Address: 0x18002e30f
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e324
// Address: 0x18002e324
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e343
// Address: 0x18002e343
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e250(int64_t arg1, int64_t arg2, int64_t arg_58h)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        iVar5 = *(int64_t *)arg1;
        iVar1 = *(int64_t *)arg2;
        uVar2 = *(int64_t *)(arg2 + 8) - iVar1 >> 2;
        if ((uint64_t)(*(int64_t *)(arg1 + 0x10) - iVar5 >> 2) < uVar2) {
            func_0x000180030840(arg1, uVar2);
            iVar5 = *(int64_t *)arg1;
            iVar3 = uVar2 * 4;
            fcn.180498030(iVar5, iVar1, iVar3);
        } else {
            uVar4 = *(int64_t *)(arg1 + 8) - iVar5 >> 2;
            if (uVar4 < uVar2) {
                fcn.180498030(iVar5, iVar1, uVar4 * 4);
                iVar5 = *(int64_t *)(arg1 + 8);
                iVar3 = (uVar2 - uVar4) * 4;
                fcn.180498030(iVar5, uVar4 * 4 + iVar1, iVar3);
            } else {
                iVar3 = uVar2 * 4;
                fcn.180498030(iVar5, iVar1, iVar3);
            }
        }
        *(int64_t *)(arg1 + 8) = iVar3 + iVar5;
        *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e350
// Address: 0x18002e350
// Size: 194 bytes
// ============================================================
void fcn.18002e350(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined auStack_58 [40];
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    func_0x00018002e420(placeholder_0, &var_30h, arg2, arg3);
    uVar2 = 0;
    if (var_20h != 0) {
        do {
            uVar2 = uVar2 + 1;
        } while (uVar2 < (uint64_t)var_20h);
    }
    if (0xf < (uint64_t)var_18h) {
        uVar2 = var_18h + 1;
        iVar3 = var_30h;
        if (0xfff < uVar2) {
            iVar3 = *(int64_t *)(var_30h + -8);
            if (0x1f < (var_30h - iVar3) - 8U) {
                pcVar1 = (code *)swi(0x29);
                (*pcVar1)(5);
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            uVar2 = var_18h + 0x28;
        }
        fcn.180459c3c(iVar3, uVar2);
    }
    fcn.180459870(var_10h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_18002e420
// Address: 0x18002e420
// Size: 326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18002e420(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    uVar3 = arg4 - arg3;
    if (uVar3 != 0) {
        uVar2 = 0;
        do {
            if (uVar2 < uVar3) {
                uVar5 = uVar3 - uVar2;
                if (*(uint64_t *)(arg2 + 0x18) - uVar2 < uVar5) {
                    var_48h = var_48h & 0xffffffffffffff00;
                    func_0x00018000f2f0(arg2, uVar5, arg2 & 0xff, uVar5, var_48h);
                } else {
                    *(uint64_t *)(arg2 + 0x10) = uVar3;
                    iVar1 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar1 = *(int64_t *)arg2;
                    }
                    func_0x0001804986e0(iVar1 + uVar2, 0, uVar5);
                    *(undefined *)(iVar1 + uVar2 + uVar5) = 0;
                }
            } else {
                *(uint64_t *)(arg2 + 0x10) = uVar3;
                iVar1 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar1 = *(int64_t *)arg2;
                }
                *(undefined *)(iVar1 + uVar3) = 0;
            }
            if (*(uint64_t *)(arg2 + 0x18) < 0x10) {
                iVar4 = *(int64_t *)(arg2 + 0x10) + arg2;
                iVar1 = arg2;
            } else {
                iVar4 = *(int64_t *)arg2 + *(int64_t *)(arg2 + 0x10);
                iVar1 = *(int64_t *)arg2;
            }
            uVar3 = func_0x000180458454(iVar1, iVar4, arg3, arg4, arg1 + 0x10);
            if (uVar3 == 0xffffffffffffffff) {
                uVar3 = 0;
                break;
            }
            uVar2 = *(uint64_t *)(arg2 + 0x10);
            var_48h = arg1 + 0x10;
        } while (uVar2 < uVar3);
    }
    func_0x00018000b3b0(arg2, uVar3, 0);
    return arg2;
}

// ============================================================
// Function: FUN_18002e570
// Address: 0x18002e570
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18002e570(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int32_t iVar1;
    int64_t var_18h;
    
    iVar1 = fcn.18045858c(arg1 + 0x10);
    if (iVar1 < 0) {
        return 0xffffffff;
    }
    return (uint64_t)(iVar1 != 0);
}

// ============================================================
// Function: FUN_18002e5c0
// Address: 0x18002e5c0
// Size: 489 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18002e5c0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    var_c8h._0_4_ = 0;
    puVar9 = auStack_e8;
    if ((arg1 != 0) && (puVar9 = auStack_e8, *(int64_t *)arg1 == 0)) {
        puVar5 = (undefined8 *)fcn.180459890(0x20);
        var_58h = (int64_t)puVar5;
        puVar6 = (undefined8 *)func_0x000180023bb0(arg2, &var_48h);
        var_c8h._0_4_ = 1;
        if (0xf < (uint64_t)puVar6[3]) {
            puVar6 = (undefined8 *)*puVar6;
        }
        func_0x000180455714(&var_c0h, 0);
        var_b8h = 0;
        var_b0h._0_1_ = 0;
        var_a8h = 0;
        var_a0h._0_1_ = 0;
        var_98h = 0;
        var_90h._0_2_ = 0;
        var_88h = 0;
        var_80h._0_2_ = 0;
        var_78h = 0;
        var_70h._0_1_ = 0;
        var_68h = 0;
        var_60h._0_1_ = 0;
        if (puVar6 == (undefined8 *)0x0) {
            func_0x000180454740(0x1805aadd8);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        func_0x000180455a00(&var_c0h, puVar6);
        *(undefined4 *)(puVar5 + 1) = 0;
        *puVar5 = 0x1805a0968;
        puVar7 = (undefined4 *)func_0x000180458558(&var_58h);
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)(puVar5 + 2) = *puVar7;
        *(undefined4 *)((int64_t)puVar5 + 0x14) = uVar2;
        *(undefined4 *)(puVar5 + 3) = uVar3;
        *(undefined4 *)((int64_t)puVar5 + 0x1c) = uVar4;
        *(undefined8 **)arg1 = puVar5;
        var_c8h._0_4_ = 1;
        func_0x000180455a6c(&var_c0h);
        if (var_68h != 0) {
            func_0x000180460d90();
        }
        var_68h = 0;
        if (var_78h != 0) {
            func_0x000180460d90();
        }
        var_78h = 0;
        if (var_88h != 0) {
            func_0x000180460d90();
        }
        var_88h = 0;
        if (var_98h != 0) {
            func_0x000180460d90();
        }
        var_98h = 0;
        if (var_a8h != 0) {
            func_0x000180460d90();
        }
        var_a8h = 0;
        if (var_b8h != 0) {
            func_0x000180460d90();
        }
        var_b8h = 0;
        func_0x00018045578c(&var_c0h);
        puVar9 = auStack_e8;
        if (0xf < (uint64_t)var_30h) {
            iVar8 = var_48h;
            puVar9 = auStack_e8;
            if ((0xfff < var_30h + 1U) &&
               (iVar8 = *(int64_t *)(var_48h + -8), puVar9 = auStack_e8, 0x1f < (var_48h - iVar8) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar8 = (*pcVar1)(5);
                puVar9 = auStack_e0;
            }
            *(undefined8 *)(puVar9 + -8) = 0x18002e773;
            fcn.180459c3c(iVar8);
        }
    }
    *(undefined8 *)(puVar9 + -8) = 0x18002e784;
    fcn.180459870(var_28h ^ (uint64_t)puVar9);
    return;
}

// ============================================================
// Function: FUN_18002e7b0
// Address: 0x18002e7b0
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18002e7b0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1805a0968;
    fcn.180460d90(*(undefined8 *)(arg1 + 0x18));
    *(undefined8 *)arg1 = 0x1804a5438;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x20);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18002e800
// Address: 0x18002e800
// Size: 248 bytes
// ============================================================
void fcn.18002e800(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h)
{
    code *pcVar1;
    undefined auVar2 [16];
    int64_t iVar3;
    undefined *puVar4;
    int64_t *piVar5;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar4 = auStack_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    _var_48h = ZEXT816(0);
    var_38h = 0;
    var_30h = 0;
    var_50h = arg2;
    if (arg3 == arg4) {
        var_38h = 0;
        var_30h = 0xf;
        auVar2[15] = 0;
        auVar2._0_15_ = stack0xffffffffffffffb9;
        _var_48h = auVar2 << 8;
    } else {
        func_0x000180004830(&var_48h, arg3, arg4 - arg3);
    }
    if ((uint64_t)var_30h < 0x10) {
        piVar5 = &var_48h;
    } else {
        piVar5 = (int64_t *)var_48h;
    }
    (**(code **)(**(int64_t **)arg1 + 0x20))(*(int64_t **)arg1, arg2, piVar5, var_38h + (int64_t)piVar5);
    if (0xf < (uint64_t)var_30h) {
        iVar3 = var_48h;
        puVar4 = auStack_78;
        if ((0xfff < var_30h + 1U) &&
           (iVar3 = *(int64_t *)(var_48h + -8), puVar4 = auStack_78, 0x1f < (var_48h - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar4 = auStack_70;
        }
        *(undefined8 *)(puVar4 + -8) = 0x18002e8e1;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(puVar4 + -8) = 0x18002e8f1;
    fcn.180459870(*(uint64_t *)(puVar4 + 0x50) ^ (uint64_t)puVar4);
    return;
}

// ============================================================
// Function: FUN_18002e900
// Address: 0x18002e900
// Size: 133 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018002e951)
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18002e900(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    
    uVar4 = *(uint64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    uVar1 = *(uint64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    uVar3 = uVar1;
    if (uVar4 < uVar1) {
        uVar3 = uVar4;
    }
    uVar3 = fcn.180497f30(arg1, arg2, uVar3);
    iVar2 = (int32_t)uVar3;
    if (iVar2 == 0) {
        if (uVar1 < uVar4) {
            return 0xff;
        }
        if (uVar1 <= uVar4) {
            return uVar3 & 0xffffffffffffff00;
        }
        iVar2 = 1;
    }
    uVar4 = 0xff;
    if (-1 < iVar2) {
        uVar4 = 1;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18002e990
// Address: 0x18002e990
// Size: 533 bytes
// ============================================================
void fcn.18002e990(int64_t arg1, int64_t arg_b0h)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    undefined *puVar10;
    undefined *puVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    undefined8 uStack_a0;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar10 = auStack_98;
    puVar11 = auStack_98;
    puVar2 = (uint64_t *)(arg1 + 0x98);
    uVar9 = *(uint64_t *)(arg1 + 0xa0);
    uVar5 = *puVar2;
    uVar8 = (int64_t)(uVar9 - uVar5) >> 6;
    if (*(uint64_t *)(arg1 + 0xb0) < uVar8) {
        fcn.18002c580(*(uint64_t *)(arg1 + 0xb0) * 0x40 + uVar5, arg1);
        goto code_r0x00018002eb76;
    }
    uVar6 = *(uint64_t *)(arg1 + 0xa8);
    if (uVar9 != uVar6) {
        func_0x000180030b10(uVar6, uVar9, arg1);
        *(int64_t *)(arg1 + 0xa0) = *(int64_t *)(arg1 + 0xa0) + 0x40;
        goto code_r0x00018002eb76;
    }
    uVar13 = 0x3ffffffffffffff;
    if (uVar8 == 0x3ffffffffffffff) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar1 = uVar8 + 1;
    uVar5 = (int64_t)(uVar6 - uVar5) >> 6;
    if (0x3ffffffffffffff - (uVar5 >> 1) < uVar5) {
        uVar6 = 0xffffffffffffffe7;
        uVar5 = 0xffffffffffffffc0;
code_r0x00018002ea69:
        iVar4 = fcn.180459890(uVar6);
        if (iVar4 == 0) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar10 = auStack_90;
        }
        uVar6 = iVar4 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar6 - 8) = iVar4;
        puVar11 = puVar10;
    } else {
        uVar5 = (uVar5 >> 1) + uVar5;
        uVar13 = uVar1;
        if (uVar1 <= uVar5) {
            uVar13 = uVar5;
        }
        if (0x3ffffffffffffff < uVar13) {
code_r0x00018002eb99:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = uVar13 * 0x40;
        if (uVar5 == 0) {
            uVar6 = 0;
            puVar11 = auStack_98;
        } else {
            if (0xfff < uVar5) {
                uVar6 = uVar5 + 0x27;
                if (uVar6 <= uVar5) goto code_r0x00018002eb99;
                goto code_r0x00018002ea69;
            }
            uVar6 = fcn.180459890(uVar5);
        }
    }
    uVar8 = uVar8 * 0x40 + uVar6 + 0x40;
    *(uint64_t **)(puVar11 + 0x20) = puVar2;
    *(uint64_t *)(puVar11 + 0x28) = uVar6;
    *(uint64_t *)(puVar11 + 0x30) = uVar13;
    *(uint64_t *)(puVar11 + 0x38) = uVar8;
    *(uint64_t *)(puVar11 + 0x40) = uVar8;
    *(undefined8 *)(puVar11 + -8) = 0x18002eac0;
    func_0x000180030b10();
    uVar13 = *(uint64_t *)(arg1 + 0xa0);
    uVar7 = *puVar2;
    uVar12 = uVar6;
    if (uVar9 != uVar13) {
        *(undefined8 *)(puVar11 + -8) = 0x18002ead7;
        func_0x000180030bc0(uVar7, uVar9, uVar6);
        uVar13 = *(uint64_t *)(arg1 + 0xa0);
        uVar7 = uVar9;
        uVar12 = uVar8;
    }
    *(undefined8 *)(puVar11 + -8) = 0x18002eae6;
    func_0x000180030bc0(uVar7, uVar13, uVar12);
    uVar9 = *puVar2;
    if (uVar9 != 0) {
        uVar8 = *(uint64_t *)(arg1 + 0xa0);
        for (; uVar9 != uVar8; uVar9 = uVar9 + 0x40) {
            *(undefined8 *)(puVar11 + -8) = 0x18002eb00;
            func_0x00018002a260(uVar9 + 0x28);
            *(undefined8 *)(puVar11 + -8) = 0x18002eb09;
            func_0x00018002ee50(uVar9 + 8);
        }
        uVar9 = *puVar2;
        uVar8 = uVar9;
        if ((0xfff < (*(int64_t *)(arg1 + 0xa8) - uVar9 & 0xffffffffffffffc0)) &&
           (uVar8 = *(uint64_t *)(uVar9 - 8), 0x1f < (uVar9 - uVar8) - 8)) {
            pcVar3 = (code *)swi(0x29);
            uVar8 = (*pcVar3)(5);
            puVar11 = puVar11 + 8;
        }
        *(undefined8 *)(puVar11 + -8) = 0x18002eb4f;
        fcn.180459c3c(uVar8);
    }
    *puVar2 = uVar6;
    *(uint64_t *)(arg1 + 0xa0) = uVar1 * 0x40 + uVar6;
    *(uint64_t *)(arg1 + 0xa8) = uVar5 + uVar6;
code_r0x00018002eb76:
    *(int64_t *)(arg1 + 0xb0) = *(int64_t *)(arg1 + 0xb0) + 1;
    return;
}

// ============================================================
// Function: FUN_18002ebb0
// Address: 0x18002ebb0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.18002ebb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    int64_t unaff_RBX;
    int64_t iVar6;
    uint8_t uVar7;
    uint8_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((0 < *(int32_t *)(arg1 + 0xf8)) &&
       (iVar3 = *(int32_t *)(arg1 + 0xf8) + -1, *(int32_t *)(arg1 + 0xf8) = iVar3, iVar3 < 1)) {
        fcn.18045471c(0xc);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    uVar7 = 0;
    uVar8 = 0;
    if (arg2 == 0) {
code_r0x00018002ecdf:
        if (0 < *(int32_t *)(arg1 + 0xf8)) {
            *(int32_t *)(arg1 + 0xf8) = *(int32_t *)(arg1 + 0xf8) + 1;
        }
        return (uint64_t)uVar8;
    }
    do {
        iVar6 = arg2;
    // switch table (6 cases) at 0x18002ed10
        switch(*(undefined4 *)(arg2 + 8)) {
        default:
            goto code_r0x00018002ecdf;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xe:
        case 0xf:
        case 0x14:
            break;
        case 10:
        case 0xb:
            cVar2 = fcn.18002ebb0(arg1, arg2, arg3, unaff_RBX);
            uVar8 = uVar7;
            if (cVar2 != '\0') {
                uVar8 = 1;
            }
            iVar6 = 0;
            uVar7 = uVar8;
            if (cVar2 == '\0') {
                iVar6 = arg2;
            }
            break;
        case 0xd:
            uVar4 = *(undefined4 *)(arg2 + 0x20);
code_r0x00018002ecc9:
            *(undefined4 *)(arg3 + 0xc) = uVar4;
code_r0x00018002eccc:
            uVar8 = 1;
            goto code_r0x00018002ecdf;
        case 0x10:
            do {
                cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(iVar6 + 0x10), arg3, unaff_RBX);
                if (cVar2 != '\0') goto code_r0x00018002eccc;
                iVar6 = *(int64_t *)(iVar6 + 0x28);
            } while (iVar6 != 0);
            iVar6 = *(int64_t *)(arg2 + 0x20);
            break;
        case 0x12:
            iVar6 = (uint64_t)*(uint32_t *)(arg2 + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80);
            cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(arg2 + 0x10), iVar6, unaff_RBX);
            if (cVar2 != '\0') {
                uVar4 = *(undefined4 *)(iVar6 + 0xc);
                goto code_r0x00018002ecc9;
            }
            *(undefined4 *)(iVar6 + 0xc) = *(undefined4 *)(arg1 + 0x20);
            iVar6 = *(int64_t *)(arg2 + 0x28);
        }
        if ((iVar6 == 0) || (arg2 = *(int64_t *)(iVar6 + 0x10), arg2 == 0)) goto code_r0x00018002ecdf;
    } while( true );
}

// ============================================================
// Function: FUN_18002ebdb
// Address: 0x18002ebdb
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.18002ebb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    int64_t unaff_RBX;
    int64_t iVar6;
    uint8_t uVar7;
    uint8_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((0 < *(int32_t *)(arg1 + 0xf8)) &&
       (iVar3 = *(int32_t *)(arg1 + 0xf8) + -1, *(int32_t *)(arg1 + 0xf8) = iVar3, iVar3 < 1)) {
        fcn.18045471c(0xc);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    uVar7 = 0;
    uVar8 = 0;
    if (arg2 == 0) {
code_r0x00018002ecdf:
        if (0 < *(int32_t *)(arg1 + 0xf8)) {
            *(int32_t *)(arg1 + 0xf8) = *(int32_t *)(arg1 + 0xf8) + 1;
        }
        return (uint64_t)uVar8;
    }
    do {
        iVar6 = arg2;
    // switch table (6 cases) at 0x18002ed10
        switch(*(undefined4 *)(arg2 + 8)) {
        default:
            goto code_r0x00018002ecdf;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xe:
        case 0xf:
        case 0x14:
            break;
        case 10:
        case 0xb:
            cVar2 = fcn.18002ebb0(arg1, arg2, arg3, unaff_RBX);
            uVar8 = uVar7;
            if (cVar2 != '\0') {
                uVar8 = 1;
            }
            iVar6 = 0;
            uVar7 = uVar8;
            if (cVar2 == '\0') {
                iVar6 = arg2;
            }
            break;
        case 0xd:
            uVar4 = *(undefined4 *)(arg2 + 0x20);
code_r0x00018002ecc9:
            *(undefined4 *)(arg3 + 0xc) = uVar4;
code_r0x00018002eccc:
            uVar8 = 1;
            goto code_r0x00018002ecdf;
        case 0x10:
            do {
                cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(iVar6 + 0x10), arg3, unaff_RBX);
                if (cVar2 != '\0') goto code_r0x00018002eccc;
                iVar6 = *(int64_t *)(iVar6 + 0x28);
            } while (iVar6 != 0);
            iVar6 = *(int64_t *)(arg2 + 0x20);
            break;
        case 0x12:
            iVar6 = (uint64_t)*(uint32_t *)(arg2 + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80);
            cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(arg2 + 0x10), iVar6, unaff_RBX);
            if (cVar2 != '\0') {
                uVar4 = *(undefined4 *)(iVar6 + 0xc);
                goto code_r0x00018002ecc9;
            }
            *(undefined4 *)(iVar6 + 0xc) = *(undefined4 *)(arg1 + 0x20);
            iVar6 = *(int64_t *)(arg2 + 0x28);
        }
        if ((iVar6 == 0) || (arg2 = *(int64_t *)(iVar6 + 0x10), arg2 == 0)) goto code_r0x00018002ecdf;
    } while( true );
}

// ============================================================
// Function: FUN_18002ebec
// Address: 0x18002ebec
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.18002ebb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    int64_t unaff_RBX;
    int64_t iVar6;
    uint8_t uVar7;
    uint8_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((0 < *(int32_t *)(arg1 + 0xf8)) &&
       (iVar3 = *(int32_t *)(arg1 + 0xf8) + -1, *(int32_t *)(arg1 + 0xf8) = iVar3, iVar3 < 1)) {
        fcn.18045471c(0xc);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    uVar7 = 0;
    uVar8 = 0;
    if (arg2 == 0) {
code_r0x00018002ecdf:
        if (0 < *(int32_t *)(arg1 + 0xf8)) {
            *(int32_t *)(arg1 + 0xf8) = *(int32_t *)(arg1 + 0xf8) + 1;
        }
        return (uint64_t)uVar8;
    }
    do {
        iVar6 = arg2;
    // switch table (6 cases) at 0x18002ed10
        switch(*(undefined4 *)(arg2 + 8)) {
        default:
            goto code_r0x00018002ecdf;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xe:
        case 0xf:
        case 0x14:
            break;
        case 10:
        case 0xb:
            cVar2 = fcn.18002ebb0(arg1, arg2, arg3, unaff_RBX);
            uVar8 = uVar7;
            if (cVar2 != '\0') {
                uVar8 = 1;
            }
            iVar6 = 0;
            uVar7 = uVar8;
            if (cVar2 == '\0') {
                iVar6 = arg2;
            }
            break;
        case 0xd:
            uVar4 = *(undefined4 *)(arg2 + 0x20);
code_r0x00018002ecc9:
            *(undefined4 *)(arg3 + 0xc) = uVar4;
code_r0x00018002eccc:
            uVar8 = 1;
            goto code_r0x00018002ecdf;
        case 0x10:
            do {
                cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(iVar6 + 0x10), arg3, unaff_RBX);
                if (cVar2 != '\0') goto code_r0x00018002eccc;
                iVar6 = *(int64_t *)(iVar6 + 0x28);
            } while (iVar6 != 0);
            iVar6 = *(int64_t *)(arg2 + 0x20);
            break;
        case 0x12:
            iVar6 = (uint64_t)*(uint32_t *)(arg2 + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80);
            cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(arg2 + 0x10), iVar6, unaff_RBX);
            if (cVar2 != '\0') {
                uVar4 = *(undefined4 *)(iVar6 + 0xc);
                goto code_r0x00018002ecc9;
            }
            *(undefined4 *)(iVar6 + 0xc) = *(undefined4 *)(arg1 + 0x20);
            iVar6 = *(int64_t *)(arg2 + 0x28);
        }
        if ((iVar6 == 0) || (arg2 = *(int64_t *)(iVar6 + 0x10), arg2 == 0)) goto code_r0x00018002ecdf;
    } while( true );
}

// ============================================================
// Function: FUN_18002ecdf
// Address: 0x18002ecdf
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.18002ebb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    int64_t unaff_RBX;
    int64_t iVar6;
    uint8_t uVar7;
    uint8_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((0 < *(int32_t *)(arg1 + 0xf8)) &&
       (iVar3 = *(int32_t *)(arg1 + 0xf8) + -1, *(int32_t *)(arg1 + 0xf8) = iVar3, iVar3 < 1)) {
        fcn.18045471c(0xc);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    uVar7 = 0;
    uVar8 = 0;
    if (arg2 == 0) {
code_r0x00018002ecdf:
        if (0 < *(int32_t *)(arg1 + 0xf8)) {
            *(int32_t *)(arg1 + 0xf8) = *(int32_t *)(arg1 + 0xf8) + 1;
        }
        return (uint64_t)uVar8;
    }
    do {
        iVar6 = arg2;
    // switch table (6 cases) at 0x18002ed10
        switch(*(undefined4 *)(arg2 + 8)) {
        default:
            goto code_r0x00018002ecdf;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xe:
        case 0xf:
        case 0x14:
            break;
        case 10:
        case 0xb:
            cVar2 = fcn.18002ebb0(arg1, arg2, arg3, unaff_RBX);
            uVar8 = uVar7;
            if (cVar2 != '\0') {
                uVar8 = 1;
            }
            iVar6 = 0;
            uVar7 = uVar8;
            if (cVar2 == '\0') {
                iVar6 = arg2;
            }
            break;
        case 0xd:
            uVar4 = *(undefined4 *)(arg2 + 0x20);
code_r0x00018002ecc9:
            *(undefined4 *)(arg3 + 0xc) = uVar4;
code_r0x00018002eccc:
            uVar8 = 1;
            goto code_r0x00018002ecdf;
        case 0x10:
            do {
                cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(iVar6 + 0x10), arg3, unaff_RBX);
                if (cVar2 != '\0') goto code_r0x00018002eccc;
                iVar6 = *(int64_t *)(iVar6 + 0x28);
            } while (iVar6 != 0);
            iVar6 = *(int64_t *)(arg2 + 0x20);
            break;
        case 0x12:
            iVar6 = (uint64_t)*(uint32_t *)(arg2 + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80);
            cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(arg2 + 0x10), iVar6, unaff_RBX);
            if (cVar2 != '\0') {
                uVar4 = *(undefined4 *)(iVar6 + 0xc);
                goto code_r0x00018002ecc9;
            }
            *(undefined4 *)(iVar6 + 0xc) = *(undefined4 *)(arg1 + 0x20);
            iVar6 = *(int64_t *)(arg2 + 0x28);
        }
        if ((iVar6 == 0) || (arg2 = *(int64_t *)(iVar6 + 0x10), arg2 == 0)) goto code_r0x00018002ecdf;
    } while( true );
}

// ============================================================
// Function: FUN_18002ed02
// Address: 0x18002ed02
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

uint64_t fcn.18002ebb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    undefined4 uVar4;
    uint64_t uVar5;
    int64_t unaff_RBX;
    int64_t iVar6;
    uint8_t uVar7;
    uint8_t uVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((0 < *(int32_t *)(arg1 + 0xf8)) &&
       (iVar3 = *(int32_t *)(arg1 + 0xf8) + -1, *(int32_t *)(arg1 + 0xf8) = iVar3, iVar3 < 1)) {
        fcn.18045471c(0xc);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    uVar7 = 0;
    uVar8 = 0;
    if (arg2 == 0) {
code_r0x00018002ecdf:
        if (0 < *(int32_t *)(arg1 + 0xf8)) {
            *(int32_t *)(arg1 + 0xf8) = *(int32_t *)(arg1 + 0xf8) + 1;
        }
        return (uint64_t)uVar8;
    }
    do {
        iVar6 = arg2;
    // switch table (6 cases) at 0x18002ed10
        switch(*(undefined4 *)(arg2 + 8)) {
        default:
            goto code_r0x00018002ecdf;
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0xe:
        case 0xf:
        case 0x14:
            break;
        case 10:
        case 0xb:
            cVar2 = fcn.18002ebb0(arg1, arg2, arg3, unaff_RBX);
            uVar8 = uVar7;
            if (cVar2 != '\0') {
                uVar8 = 1;
            }
            iVar6 = 0;
            uVar7 = uVar8;
            if (cVar2 == '\0') {
                iVar6 = arg2;
            }
            break;
        case 0xd:
            uVar4 = *(undefined4 *)(arg2 + 0x20);
code_r0x00018002ecc9:
            *(undefined4 *)(arg3 + 0xc) = uVar4;
code_r0x00018002eccc:
            uVar8 = 1;
            goto code_r0x00018002ecdf;
        case 0x10:
            do {
                cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(iVar6 + 0x10), arg3, unaff_RBX);
                if (cVar2 != '\0') goto code_r0x00018002eccc;
                iVar6 = *(int64_t *)(iVar6 + 0x28);
            } while (iVar6 != 0);
            iVar6 = *(int64_t *)(arg2 + 0x20);
            break;
        case 0x12:
            iVar6 = (uint64_t)*(uint32_t *)(arg2 + 0x30) * 0x10 + *(int64_t *)(arg1 + 0x80);
            cVar2 = fcn.18002ebb0(arg1, *(int64_t *)(arg2 + 0x10), iVar6, unaff_RBX);
            if (cVar2 != '\0') {
                uVar4 = *(undefined4 *)(iVar6 + 0xc);
                goto code_r0x00018002ecc9;
            }
            *(undefined4 *)(iVar6 + 0xc) = *(undefined4 *)(arg1 + 0x20);
            iVar6 = *(int64_t *)(arg2 + 0x28);
        }
        if ((iVar6 == 0) || (arg2 = *(int64_t *)(iVar6 + 0x10), arg2 == 0)) goto code_r0x00018002ecdf;
    } while( true );
}

// ============================================================
// Function: FUN_18002ed40
// Address: 0x18002ed40
// Size: 12 bytes
// ============================================================
void fcn.18002ed40(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    
    fcn.18045471c(arg2 & 0xffffffff);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18002ed50
// Address: 0x18002ed50
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002ed50(int64_t arg1)
{
    uint32_t uVar1;
    int64_t *piVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined in_DL;
    uint32_t uVar7;
    undefined8 unaff_RDI;
    uint32_t uVar8;
    undefined8 in_R9;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(arg1 + 8) + 8) != 6) {
        puVar5 = (undefined8 *)fcn.180459890(0x30);
        puVar5[2] = 0;
        puVar5[3] = 0;
        *puVar5 = 0x1806221d8;
        puVar5[4] = 0;
        puVar5[5] = 0;
        puVar5[1] = 6;
        fcn.18002e210(arg1, puVar5);
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x100) != 0) {
        piVar2 = *(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        in_DL = (**(code **)(*piVar2 + 0x20))(piVar2, in_DL);
    }
    iVar3 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint32_t *)(iVar3 + 0x20);
    if (uVar1 <= *(uint32_t *)(iVar3 + 0x24)) {
        uVar8 = 0x10;
        if (0x10 < uVar1 >> 1) {
            uVar8 = uVar1 >> 1;
        }
        uVar7 = uVar1 + uVar8;
        if (~uVar8 <= uVar1) {
            uVar7 = 0xffffffff;
        }
        if (uVar7 != uVar1) {
            iVar6 = func_0x00018046d060(*(undefined8 *)(iVar3 + 0x28), uVar7, uVar8, in_R9, unaff_RDI);
            if (iVar6 != 0) {
                *(int64_t *)(iVar3 + 0x28) = iVar6;
                *(uint32_t *)(iVar3 + 0x20) = uVar7;
                goto code_r0x00018002f96e;
            }
        }
        fcn.18045471c(9);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
code_r0x00018002f96e:
    *(undefined *)((uint64_t)*(uint32_t *)(iVar3 + 0x24) + *(int64_t *)(iVar3 + 0x28)) = in_DL;
    *(int32_t *)(iVar3 + 0x24) = *(int32_t *)(iVar3 + 0x24) + 1;
    return;
}

// ============================================================
// Function: FUN_18002ee50
// Address: 0x18002ee50
// Size: 104 bytes
// ============================================================
void fcn.18002ee50(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 2) * 4;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x18002eea5;
        fcn.180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_18002eec0
// Address: 0x18002eec0
// Size: 415 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.18002eec0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint32_t *puVar9;
    uint32_t *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = (*(int64_t *)arg2 - *(int64_t *)arg1 >> 2) * 0x20 + *(int64_t *)(arg2 + 8);
    if (arg3 != 0) {
        if (0x7fffffffffffffffU - *(int64_t *)(arg1 + 0x18) < (uint64_t)arg3) {
            fcn.18002f9a0();
            pcVar3 = (code *)swi(3);
            uVar8 = (*pcVar3)();
            return uVar8;
        }
        var_8h._0_4_ = 0;
        fcn.18002fda0(arg1, (uint64_t)(arg3 + 0x1f + *(int64_t *)(arg1 + 0x18)) >> 5, &var_8h);
        uVar4 = *(uint64_t *)(arg1 + 0x18);
        if (uVar4 == 0) {
            *(int64_t *)(arg1 + 0x18) = arg3;
        } else {
            iVar2 = *(int64_t *)arg1;
            if (((int64_t)uVar4 < 0) && (uVar4 != 0)) {
                iVar1 = -((~uVar4 >> 5) * 4 + 4);
            } else {
                iVar1 = (uVar4 >> 5) * 4;
            }
            puVar9 = (uint32_t *)(iVar2 + iVar1);
            uVar6 = uVar4 + arg3;
            *(uint64_t *)(arg1 + 0x18) = uVar6;
            if (((int64_t)uVar6 < 0) && (uVar6 != 0)) {
                iVar1 = -((~uVar6 >> 5) * 4 + 4);
            } else {
                iVar1 = (uVar6 >> 5) * 4;
            }
            puVar10 = (uint32_t *)(iVar2 + iVar1);
            if (((int64_t)uVar8 < 0) && (uVar8 != 0)) {
                iVar1 = -((~uVar8 >> 5) * 4 + 4);
            } else {
                iVar1 = (uVar8 >> 5) * 4;
            }
            uVar4 = (uint64_t)((uint32_t)uVar4 & 0x1f);
            uVar6 = (uint64_t)((uint32_t)uVar6 & 0x1f);
            while (((uint32_t *)(iVar2 + iVar1) != puVar9 || (((uint32_t)uVar8 & 0x1f) != uVar4))) {
                if (uVar4 == 0) {
                    uVar5 = 0x1f;
                } else {
                    uVar5 = uVar4 - 1;
                }
                if (uVar4 == 0) {
                    puVar9 = puVar9 + -1;
                }
                if (uVar6 == 0) {
                    uVar7 = 0x1f;
                } else {
                    uVar7 = uVar6 - 1;
                }
                if (uVar6 == 0) {
                    puVar10 = puVar10 + -1;
                }
                uVar4 = uVar5;
                uVar6 = uVar7;
                if ((*puVar9 & 1 << ((uint8_t)uVar5 & 0x1f)) == 0) {
                    *puVar10 = *puVar10 & ~(1 << ((uint32_t)uVar7 & 0x1f));
                } else {
                    *puVar10 = *puVar10 | 1 << ((uint32_t)uVar7 & 0x1f);
                }
            }
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_18002f060
// Address: 0x18002f060
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18002f060(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    uint32_t *puVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    char in_R8B;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar1 = *(uint32_t **)arg2;
    puVar2 = *(uint32_t **)arg1;
    uVar3 = (uint8_t)*(int64_t *)(arg1 + 8);
    if (puVar2 == puVar1) {
        if (*(int64_t *)(arg1 + 8) != *(int64_t *)(arg2 + 8)) {
            uVar5 = -1 << (uVar3 & 0x1f);
            uVar4 = 0xffffffff >> (0x20U - *(char *)(arg2 + 8) & 0x1f);
            *puVar2 = (~uVar4 | ~uVar5) & *puVar2 | -(uint32_t)(in_R8B != '\0') & uVar4 & uVar5;
            return;
        }
    } else {
        uVar4 = -1 << (uVar3 & 0x1f);
        *puVar2 = *puVar2 & ~uVar4 | -(uint32_t)(in_R8B != '\0') & uVar4;
        fcn.1804986e0(puVar2 + 1, -(in_R8B != '\0'), (int64_t)puVar1 - (int64_t)(puVar2 + 1));
        if (*(int64_t *)(arg2 + 8) != 0) {
            uVar4 = 0xffffffff >> (0x20U - (char)*(int64_t *)(arg2 + 8) & 0x1f);
            *puVar1 = ~uVar4 & *puVar1 | -(uint32_t)(in_R8B != '\0') & uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18002f0db
// Address: 0x18002f0db
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18002f060(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    uint32_t *puVar2;
    uint8_t uVar3;
    uint32_t uVar4;
    char in_R8B;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar1 = *(uint32_t **)arg2;
    puVar2 = *(uint32_t **)arg1;
    uVar3 = (uint8_t)*(int64_t *)(arg1 + 8);
    if (puVar2 == puVar1) {
        if (*(int64_t *)(arg1 + 8) != *(int64_t *)(arg2 + 8)) {
            uVar5 = -1 << (uVar3 & 0x1f);
            uVar4 = 0xffffffff >> (0x20U - *(char *)(arg2 + 8) & 0x1f);
            *puVar2 = (~uVar4 | ~uVar5) & *puVar2 | -(uint32_t)(in_R8B != '\0') & uVar4 & uVar5;
            return;
        }
    } else {
        uVar4 = -1 << (uVar3 & 0x1f);
        *puVar2 = *puVar2 & ~uVar4 | -(uint32_t)(in_R8B != '\0') & uVar4;
        fcn.1804986e0(puVar2 + 1, -(in_R8B != '\0'), (int64_t)puVar1 - (int64_t)(puVar2 + 1));
        if (*(int64_t *)(arg2 + 8) != 0) {
            uVar4 = 0xffffffff >> (0x20U - (char)*(int64_t *)(arg2 + 8) & 0x1f);
            *puVar1 = ~uVar4 & *puVar1 | -(uint32_t)(in_R8B != '\0') & uVar4;
        }
    }
    return;
}

