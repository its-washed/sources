// Chunk 81 - 50 functions

// ============================================================
// Function: FUN_180110b83
// Address: 0x180110b83
// Size: 156 bytes
// ============================================================
undefined8 fcn.180110b83(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    float *pfVar1;
    char cVar2;
    char cVar3;
    char cVar4;
    int64_t unaff_RBX;
    char cVar5;
    int64_t iVar6;
    int64_t unaff_RDI;
    bool in_ZF;
    float fVar7;
    undefined4 uVar8;
    float fVar9;
    int64_t var_20h;
    
    if (in_ZF) {
        cVar4 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1708) == -1)) {
        cVar4 = '\x01';
    } else {
        cVar4 = '\0';
    }
    if (*(char *)(unaff_RDI + 0x1a0) == '\0') {
        cVar5 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1714) == -1)) {
        cVar5 = '\x01';
    } else {
        cVar5 = '\0';
    }
    cVar2 = func_0x000180107dc0(0x207, 1, 0xffffffff);
    cVar3 = func_0x000180107dc0(0x208, 1, 0xffffffff);
    if ((cVar4 != cVar5) || (cVar2 != cVar3)) {
        if (*(int32_t *)(unaff_RDI + 0x21e4) != 0) {
            func_0x00018010ed90(0);
        }
        if (((*(uint8_t *)(unaff_RBX + 0x1b4) & 1) != 0) || (*(char *)(unaff_RBX + 0x1ba) == '\0')) {
            iVar6 = (int64_t)*(int32_t *)(unaff_RDI + 0x21e4);
            fVar9 = ((*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) - *(float *)(unaff_RBX + 0x318)) +
                    (*(float *)(unaff_RBX + 0x464 + iVar6 * 0x10) - *(float *)(unaff_RBX + 0x45c + iVar6 * 0x10));
            fVar7 = 0.0;
            if (0.0 <= fVar9) {
                fVar7 = fVar9;
            }
            cVar4 = func_0x000180107dc0(0x205, 1, 0);
            if (cVar4 != '\0') {
                uVar8 = 0x80000000;
                fVar7 = (float)((uint32_t)fVar7 ^ 0x80000000);
                *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                *(undefined4 *)(unaff_RDI + 0x2290) = 2;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
                goto code_r0x000180110cd3;
            }
            cVar4 = func_0x000180107dc0(0x206, 1, 0);
            if (cVar4 == '\0') {
                fVar7 = 0.0;
                if (cVar2 != '\0') {
                    fVar7 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = 0;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = 0;
                    if (*pfVar1 <= fVar7 && fVar7 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    fVar7 = 0.0;
                    uVar8 = 0;
                    *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110cd3;
                }
                if (cVar3 != '\0') {
                    uVar8 = *(undefined4 *)(unaff_RBX + 0x7c);
                    fVar9 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = uVar8;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = uVar8;
                    if (*pfVar1 <= fVar9 && fVar9 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110e6c;
                }
            } else {
                *(undefined4 *)(unaff_RDI + 0x2290) = 3;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
code_r0x000180110e6c:
                *(undefined4 *)(unaff_RDI + 0x2288) = 2;
            }
            uVar8 = 0;
            goto code_r0x000180110cd3;
        }
        cVar4 = func_0x000180107dc0(0x205, 1, 0xffffffff);
        if (cVar4 == '\0') {
            cVar4 = func_0x000180107dc0(0x206, 1, 0xffffffff);
            if (cVar4 != '\0') {
                fVar7 = (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) + *(float *)(unaff_RBX + 0xd8);
                goto code_r0x000180110cba;
            }
            if (cVar2 == '\0') {
                if (cVar3 == '\0') goto code_r0x000180110cd0;
                *(undefined4 *)(unaff_RBX + 0xe8) = *(undefined4 *)(unaff_RBX + 0xe0);
            } else {
                *(undefined4 *)(unaff_RBX + 0xe8) = 0;
            }
        } else {
            fVar7 = *(float *)(unaff_RBX + 0xd8) - (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c));
code_r0x000180110cba:
            *(float *)(unaff_RBX + 0xe8) = fVar7;
        }
        *(undefined4 *)(unaff_RBX + 0xf8) = 0;
        *(undefined4 *)(unaff_RBX + 0xf0) = 0;
    }
code_r0x000180110cd0:
    fVar7 = 0.0;
    uVar8 = 0;
code_r0x000180110cd3:
    return CONCAT44(uVar8, fVar7);
}

// ============================================================
// Function: FUN_180110c1f
// Address: 0x180110c1f
// Size: 268 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h

undefined8 fcn.180110b83(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    float *pfVar1;
    char cVar2;
    char cVar3;
    char cVar4;
    int64_t unaff_RBX;
    char cVar5;
    int64_t iVar6;
    int64_t unaff_RDI;
    bool in_ZF;
    float fVar7;
    undefined4 uVar8;
    float fVar9;
    int64_t var_20h;
    
    if (in_ZF) {
        cVar4 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1708) == -1)) {
        cVar4 = '\x01';
    } else {
        cVar4 = '\0';
    }
    if (*(char *)(unaff_RDI + 0x1a0) == '\0') {
        cVar5 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1714) == -1)) {
        cVar5 = '\x01';
    } else {
        cVar5 = '\0';
    }
    cVar2 = func_0x000180107dc0(0x207, 1, 0xffffffff);
    cVar3 = func_0x000180107dc0(0x208, 1, 0xffffffff);
    if ((cVar4 != cVar5) || (cVar2 != cVar3)) {
        if (*(int32_t *)(unaff_RDI + 0x21e4) != 0) {
            func_0x00018010ed90(0);
        }
        if (((*(uint8_t *)(unaff_RBX + 0x1b4) & 1) != 0) || (*(char *)(unaff_RBX + 0x1ba) == '\0')) {
            iVar6 = (int64_t)*(int32_t *)(unaff_RDI + 0x21e4);
            fVar9 = ((*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) - *(float *)(unaff_RBX + 0x318)) +
                    (*(float *)(unaff_RBX + 0x464 + iVar6 * 0x10) - *(float *)(unaff_RBX + 0x45c + iVar6 * 0x10));
            fVar7 = 0.0;
            if (0.0 <= fVar9) {
                fVar7 = fVar9;
            }
            cVar4 = func_0x000180107dc0(0x205, 1, 0);
            if (cVar4 != '\0') {
                uVar8 = 0x80000000;
                fVar7 = (float)((uint32_t)fVar7 ^ 0x80000000);
                *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                *(undefined4 *)(unaff_RDI + 0x2290) = 2;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
                goto code_r0x000180110cd3;
            }
            cVar4 = func_0x000180107dc0(0x206, 1, 0);
            if (cVar4 == '\0') {
                fVar7 = 0.0;
                if (cVar2 != '\0') {
                    fVar7 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = 0;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = 0;
                    if (*pfVar1 <= fVar7 && fVar7 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    fVar7 = 0.0;
                    uVar8 = 0;
                    *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110cd3;
                }
                if (cVar3 != '\0') {
                    uVar8 = *(undefined4 *)(unaff_RBX + 0x7c);
                    fVar9 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = uVar8;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = uVar8;
                    if (*pfVar1 <= fVar9 && fVar9 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110e6c;
                }
            } else {
                *(undefined4 *)(unaff_RDI + 0x2290) = 3;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
code_r0x000180110e6c:
                *(undefined4 *)(unaff_RDI + 0x2288) = 2;
            }
            uVar8 = 0;
            goto code_r0x000180110cd3;
        }
        cVar4 = func_0x000180107dc0(0x205, 1, 0xffffffff);
        if (cVar4 == '\0') {
            cVar4 = func_0x000180107dc0(0x206, 1, 0xffffffff);
            if (cVar4 != '\0') {
                fVar7 = (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) + *(float *)(unaff_RBX + 0xd8);
                goto code_r0x000180110cba;
            }
            if (cVar2 == '\0') {
                if (cVar3 == '\0') goto code_r0x000180110cd0;
                *(undefined4 *)(unaff_RBX + 0xe8) = *(undefined4 *)(unaff_RBX + 0xe0);
            } else {
                *(undefined4 *)(unaff_RBX + 0xe8) = 0;
            }
        } else {
            fVar7 = *(float *)(unaff_RBX + 0xd8) - (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c));
code_r0x000180110cba:
            *(float *)(unaff_RBX + 0xe8) = fVar7;
        }
        *(undefined4 *)(unaff_RBX + 0xf8) = 0;
        *(undefined4 *)(unaff_RBX + 0xf0) = 0;
    }
code_r0x000180110cd0:
    fVar7 = 0.0;
    uVar8 = 0;
code_r0x000180110cd3:
    return CONCAT44(uVar8, fVar7);
}

// ============================================================
// Function: FUN_180110d2b
// Address: 0x180110d2b
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h

undefined8 fcn.180110b83(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    float *pfVar1;
    char cVar2;
    char cVar3;
    char cVar4;
    int64_t unaff_RBX;
    char cVar5;
    int64_t iVar6;
    int64_t unaff_RDI;
    bool in_ZF;
    float fVar7;
    undefined4 uVar8;
    float fVar9;
    int64_t var_20h;
    
    if (in_ZF) {
        cVar4 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1708) == -1)) {
        cVar4 = '\x01';
    } else {
        cVar4 = '\0';
    }
    if (*(char *)(unaff_RDI + 0x1a0) == '\0') {
        cVar5 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1714) == -1)) {
        cVar5 = '\x01';
    } else {
        cVar5 = '\0';
    }
    cVar2 = func_0x000180107dc0(0x207, 1, 0xffffffff);
    cVar3 = func_0x000180107dc0(0x208, 1, 0xffffffff);
    if ((cVar4 != cVar5) || (cVar2 != cVar3)) {
        if (*(int32_t *)(unaff_RDI + 0x21e4) != 0) {
            func_0x00018010ed90(0);
        }
        if (((*(uint8_t *)(unaff_RBX + 0x1b4) & 1) != 0) || (*(char *)(unaff_RBX + 0x1ba) == '\0')) {
            iVar6 = (int64_t)*(int32_t *)(unaff_RDI + 0x21e4);
            fVar9 = ((*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) - *(float *)(unaff_RBX + 0x318)) +
                    (*(float *)(unaff_RBX + 0x464 + iVar6 * 0x10) - *(float *)(unaff_RBX + 0x45c + iVar6 * 0x10));
            fVar7 = 0.0;
            if (0.0 <= fVar9) {
                fVar7 = fVar9;
            }
            cVar4 = func_0x000180107dc0(0x205, 1, 0);
            if (cVar4 != '\0') {
                uVar8 = 0x80000000;
                fVar7 = (float)((uint32_t)fVar7 ^ 0x80000000);
                *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                *(undefined4 *)(unaff_RDI + 0x2290) = 2;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
                goto code_r0x000180110cd3;
            }
            cVar4 = func_0x000180107dc0(0x206, 1, 0);
            if (cVar4 == '\0') {
                fVar7 = 0.0;
                if (cVar2 != '\0') {
                    fVar7 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = 0;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = 0;
                    if (*pfVar1 <= fVar7 && fVar7 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    fVar7 = 0.0;
                    uVar8 = 0;
                    *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110cd3;
                }
                if (cVar3 != '\0') {
                    uVar8 = *(undefined4 *)(unaff_RBX + 0x7c);
                    fVar9 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = uVar8;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = uVar8;
                    if (*pfVar1 <= fVar9 && fVar9 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110e6c;
                }
            } else {
                *(undefined4 *)(unaff_RDI + 0x2290) = 3;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
code_r0x000180110e6c:
                *(undefined4 *)(unaff_RDI + 0x2288) = 2;
            }
            uVar8 = 0;
            goto code_r0x000180110cd3;
        }
        cVar4 = func_0x000180107dc0(0x205, 1, 0xffffffff);
        if (cVar4 == '\0') {
            cVar4 = func_0x000180107dc0(0x206, 1, 0xffffffff);
            if (cVar4 != '\0') {
                fVar7 = (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) + *(float *)(unaff_RBX + 0xd8);
                goto code_r0x000180110cba;
            }
            if (cVar2 == '\0') {
                if (cVar3 == '\0') goto code_r0x000180110cd0;
                *(undefined4 *)(unaff_RBX + 0xe8) = *(undefined4 *)(unaff_RBX + 0xe0);
            } else {
                *(undefined4 *)(unaff_RBX + 0xe8) = 0;
            }
        } else {
            fVar7 = *(float *)(unaff_RBX + 0xd8) - (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c));
code_r0x000180110cba:
            *(float *)(unaff_RBX + 0xe8) = fVar7;
        }
        *(undefined4 *)(unaff_RBX + 0xf8) = 0;
        *(undefined4 *)(unaff_RBX + 0xf0) = 0;
    }
code_r0x000180110cd0:
    fVar7 = 0.0;
    uVar8 = 0;
code_r0x000180110cd3:
    return CONCAT44(uVar8, fVar7);
}

// ============================================================
// Function: FUN_180110d95
// Address: 0x180110d95
// Size: 137 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h

undefined8 fcn.180110b83(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    float *pfVar1;
    char cVar2;
    char cVar3;
    char cVar4;
    int64_t unaff_RBX;
    char cVar5;
    int64_t iVar6;
    int64_t unaff_RDI;
    bool in_ZF;
    float fVar7;
    undefined4 uVar8;
    float fVar9;
    int64_t var_20h;
    
    if (in_ZF) {
        cVar4 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1708) == -1)) {
        cVar4 = '\x01';
    } else {
        cVar4 = '\0';
    }
    if (*(char *)(unaff_RDI + 0x1a0) == '\0') {
        cVar5 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1714) == -1)) {
        cVar5 = '\x01';
    } else {
        cVar5 = '\0';
    }
    cVar2 = func_0x000180107dc0(0x207, 1, 0xffffffff);
    cVar3 = func_0x000180107dc0(0x208, 1, 0xffffffff);
    if ((cVar4 != cVar5) || (cVar2 != cVar3)) {
        if (*(int32_t *)(unaff_RDI + 0x21e4) != 0) {
            func_0x00018010ed90(0);
        }
        if (((*(uint8_t *)(unaff_RBX + 0x1b4) & 1) != 0) || (*(char *)(unaff_RBX + 0x1ba) == '\0')) {
            iVar6 = (int64_t)*(int32_t *)(unaff_RDI + 0x21e4);
            fVar9 = ((*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) - *(float *)(unaff_RBX + 0x318)) +
                    (*(float *)(unaff_RBX + 0x464 + iVar6 * 0x10) - *(float *)(unaff_RBX + 0x45c + iVar6 * 0x10));
            fVar7 = 0.0;
            if (0.0 <= fVar9) {
                fVar7 = fVar9;
            }
            cVar4 = func_0x000180107dc0(0x205, 1, 0);
            if (cVar4 != '\0') {
                uVar8 = 0x80000000;
                fVar7 = (float)((uint32_t)fVar7 ^ 0x80000000);
                *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                *(undefined4 *)(unaff_RDI + 0x2290) = 2;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
                goto code_r0x000180110cd3;
            }
            cVar4 = func_0x000180107dc0(0x206, 1, 0);
            if (cVar4 == '\0') {
                fVar7 = 0.0;
                if (cVar2 != '\0') {
                    fVar7 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = 0;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = 0;
                    if (*pfVar1 <= fVar7 && fVar7 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    fVar7 = 0.0;
                    uVar8 = 0;
                    *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110cd3;
                }
                if (cVar3 != '\0') {
                    uVar8 = *(undefined4 *)(unaff_RBX + 0x7c);
                    fVar9 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = uVar8;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = uVar8;
                    if (*pfVar1 <= fVar9 && fVar9 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110e6c;
                }
            } else {
                *(undefined4 *)(unaff_RDI + 0x2290) = 3;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
code_r0x000180110e6c:
                *(undefined4 *)(unaff_RDI + 0x2288) = 2;
            }
            uVar8 = 0;
            goto code_r0x000180110cd3;
        }
        cVar4 = func_0x000180107dc0(0x205, 1, 0xffffffff);
        if (cVar4 == '\0') {
            cVar4 = func_0x000180107dc0(0x206, 1, 0xffffffff);
            if (cVar4 != '\0') {
                fVar7 = (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) + *(float *)(unaff_RBX + 0xd8);
                goto code_r0x000180110cba;
            }
            if (cVar2 == '\0') {
                if (cVar3 == '\0') goto code_r0x000180110cd0;
                *(undefined4 *)(unaff_RBX + 0xe8) = *(undefined4 *)(unaff_RBX + 0xe0);
            } else {
                *(undefined4 *)(unaff_RBX + 0xe8) = 0;
            }
        } else {
            fVar7 = *(float *)(unaff_RBX + 0xd8) - (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c));
code_r0x000180110cba:
            *(float *)(unaff_RBX + 0xe8) = fVar7;
        }
        *(undefined4 *)(unaff_RBX + 0xf8) = 0;
        *(undefined4 *)(unaff_RBX + 0xf0) = 0;
    }
code_r0x000180110cd0:
    fVar7 = 0.0;
    uVar8 = 0;
code_r0x000180110cd3:
    return CONCAT44(uVar8, fVar7);
}

// ============================================================
// Function: FUN_180110e1e
// Address: 0x180110e1e
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h

undefined8 fcn.180110b83(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    float *pfVar1;
    char cVar2;
    char cVar3;
    char cVar4;
    int64_t unaff_RBX;
    char cVar5;
    int64_t iVar6;
    int64_t unaff_RDI;
    bool in_ZF;
    float fVar7;
    undefined4 uVar8;
    float fVar9;
    int64_t var_20h;
    
    if (in_ZF) {
        cVar4 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1708) == -1)) {
        cVar4 = '\x01';
    } else {
        cVar4 = '\0';
    }
    if (*(char *)(unaff_RDI + 0x1a0) == '\0') {
        cVar5 = '\0';
    } else if (((*(char *)(unaff_RDI + 0x1f6c) == '\0') || (*(int32_t *)(unaff_RDI + 0x1654) == -1)) &&
              (*(int32_t *)(unaff_RDI + 0x1714) == -1)) {
        cVar5 = '\x01';
    } else {
        cVar5 = '\0';
    }
    cVar2 = func_0x000180107dc0(0x207, 1, 0xffffffff);
    cVar3 = func_0x000180107dc0(0x208, 1, 0xffffffff);
    if ((cVar4 != cVar5) || (cVar2 != cVar3)) {
        if (*(int32_t *)(unaff_RDI + 0x21e4) != 0) {
            func_0x00018010ed90(0);
        }
        if (((*(uint8_t *)(unaff_RBX + 0x1b4) & 1) != 0) || (*(char *)(unaff_RBX + 0x1ba) == '\0')) {
            iVar6 = (int64_t)*(int32_t *)(unaff_RDI + 0x21e4);
            fVar9 = ((*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) - *(float *)(unaff_RBX + 0x318)) +
                    (*(float *)(unaff_RBX + 0x464 + iVar6 * 0x10) - *(float *)(unaff_RBX + 0x45c + iVar6 * 0x10));
            fVar7 = 0.0;
            if (0.0 <= fVar9) {
                fVar7 = fVar9;
            }
            cVar4 = func_0x000180107dc0(0x205, 1, 0);
            if (cVar4 != '\0') {
                uVar8 = 0x80000000;
                fVar7 = (float)((uint32_t)fVar7 ^ 0x80000000);
                *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                *(undefined4 *)(unaff_RDI + 0x2290) = 2;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
                goto code_r0x000180110cd3;
            }
            cVar4 = func_0x000180107dc0(0x206, 1, 0);
            if (cVar4 == '\0') {
                fVar7 = 0.0;
                if (cVar2 != '\0') {
                    fVar7 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = 0;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = 0;
                    if (*pfVar1 <= fVar7 && fVar7 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    fVar7 = 0.0;
                    uVar8 = 0;
                    *(undefined4 *)(unaff_RDI + 0x2288) = 3;
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110cd3;
                }
                if (cVar3 != '\0') {
                    uVar8 = *(undefined4 *)(unaff_RBX + 0x7c);
                    fVar9 = *(float *)(unaff_RBX + 0x458 + iVar6 * 0x10);
                    pfVar1 = (float *)(unaff_RBX + 0x460 + iVar6 * 0x10);
                    *(undefined4 *)(unaff_RBX + 0x464 + iVar6 * 0x10) = uVar8;
                    *(undefined4 *)(unaff_RBX + 0x45c + iVar6 * 0x10) = uVar8;
                    if (*pfVar1 <= fVar9 && fVar9 != *pfVar1) {
                        *(undefined4 *)(unaff_RBX + 0x460 + iVar6 * 0x10) = 0;
                        *(undefined4 *)(unaff_RBX + 0x458 + iVar6 * 0x10) = 0;
                    }
                    *(undefined4 *)(unaff_RDI + 0x227c) = 0x50;
                    goto code_r0x000180110e6c;
                }
            } else {
                *(undefined4 *)(unaff_RDI + 0x2290) = 3;
                *(undefined4 *)(unaff_RDI + 0x227c) = 0x810;
code_r0x000180110e6c:
                *(undefined4 *)(unaff_RDI + 0x2288) = 2;
            }
            uVar8 = 0;
            goto code_r0x000180110cd3;
        }
        cVar4 = func_0x000180107dc0(0x205, 1, 0xffffffff);
        if (cVar4 == '\0') {
            cVar4 = func_0x000180107dc0(0x206, 1, 0xffffffff);
            if (cVar4 != '\0') {
                fVar7 = (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c)) + *(float *)(unaff_RBX + 0xd8);
                goto code_r0x000180110cba;
            }
            if (cVar2 == '\0') {
                if (cVar3 == '\0') goto code_r0x000180110cd0;
                *(undefined4 *)(unaff_RBX + 0xe8) = *(undefined4 *)(unaff_RBX + 0xe0);
            } else {
                *(undefined4 *)(unaff_RBX + 0xe8) = 0;
            }
        } else {
            fVar7 = *(float *)(unaff_RBX + 0xd8) - (*(float *)(unaff_RBX + 0x284) - *(float *)(unaff_RBX + 0x27c));
code_r0x000180110cba:
            *(float *)(unaff_RBX + 0xe8) = fVar7;
        }
        *(undefined4 *)(unaff_RBX + 0xf8) = 0;
        *(undefined4 *)(unaff_RBX + 0xf0) = 0;
    }
code_r0x000180110cd0:
    fVar7 = 0.0;
    uVar8 = 0;
code_r0x000180110cd3:
    return CONCAT44(uVar8, fVar7);
}

// ============================================================
// Function: FUN_1801110c0
// Address: 0x1801110c0
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801110c0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t var_8h;
    
    if (-1 < (int32_t)arg1) {
        do {
            iVar2 = (int32_t)arg1;
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1590) <= iVar2) {
                return 0;
            }
            if (iVar2 == (int32_t)arg2) {
                return 0;
            }
            iVar1 = *(int64_t *)((arg1 & 0xffffffffU) * 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x1598));
            if (((*(char *)(iVar1 + 0x10a) != '\0') && (iVar1 == *(int64_t *)(iVar1 + 0x418))) &&
               ((*(uint32_t *)(iVar1 + 0x14) & 0x20000) == 0)) {
                return iVar1;
            }
            uVar3 = iVar2 + (int32_t)arg3;
            arg1 = (int64_t)uVar3;
        } while (-1 < (int32_t)uVar3);
    }
    return 0;
}

// ============================================================
// Function: FUN_180111130
// Address: 0x180111130
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180111130(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t arg1_00;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) + 0x14) & 0x8000000) != 0) {
        return;
    }
    uVar3 = (uint32_t)*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) + 0x120);
    iVar2 = fcn.1801110c0((uint64_t)((int32_t)arg1 + uVar3), 0x80000001, arg1 & 0xffffffff);
    arg1_00 = 0;
    if (iVar2 == 0) {
        if ((int32_t)arg1 < 0) {
            arg1_00 = (uint64_t)(*(int32_t *)(iVar1 + 0x1590) - 1);
        }
        iVar2 = fcn.1801110c0(arg1_00, (uint64_t)uVar3, arg1 & 0xffffffff);
        if (iVar2 == 0) goto code_r0x0001801111b5;
    }
    *(int64_t *)(iVar1 + 0x23c8) = iVar2;
    *(int64_t *)(iVar1 + 0x23c0) = iVar2;
    *(undefined8 *)(iVar1 + 0x23f4) = 0;
    *(undefined8 *)(iVar1 + 0x23ec) = 0;
code_r0x0001801111b5:
    *(undefined *)(iVar1 + 0x23e4) = 0;
    return;
}

// ============================================================
// Function: FUN_180111153
// Address: 0x180111153
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180111130(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t arg1_00;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) + 0x14) & 0x8000000) != 0) {
        return;
    }
    uVar3 = (uint32_t)*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) + 0x120);
    iVar2 = fcn.1801110c0((uint64_t)((int32_t)arg1 + uVar3), 0x80000001, arg1 & 0xffffffff);
    arg1_00 = 0;
    if (iVar2 == 0) {
        if ((int32_t)arg1 < 0) {
            arg1_00 = (uint64_t)(*(int32_t *)(iVar1 + 0x1590) - 1);
        }
        iVar2 = fcn.1801110c0(arg1_00, (uint64_t)uVar3, arg1 & 0xffffffff);
        if (iVar2 == 0) goto code_r0x0001801111b5;
    }
    *(int64_t *)(iVar1 + 0x23c8) = iVar2;
    *(int64_t *)(iVar1 + 0x23c0) = iVar2;
    *(undefined8 *)(iVar1 + 0x23f4) = 0;
    *(undefined8 *)(iVar1 + 0x23ec) = 0;
code_r0x0001801111b5:
    *(undefined *)(iVar1 + 0x23e4) = 0;
    return;
}

// ============================================================
// Function: FUN_1801111c6
// Address: 0x1801111c6
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180111130(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t arg1_00;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) + 0x14) & 0x8000000) != 0) {
        return;
    }
    uVar3 = (uint32_t)*(int16_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) + 0x120);
    iVar2 = fcn.1801110c0((uint64_t)((int32_t)arg1 + uVar3), 0x80000001, arg1 & 0xffffffff);
    arg1_00 = 0;
    if (iVar2 == 0) {
        if ((int32_t)arg1 < 0) {
            arg1_00 = (uint64_t)(*(int32_t *)(iVar1 + 0x1590) - 1);
        }
        iVar2 = fcn.1801110c0(arg1_00, (uint64_t)uVar3, arg1 & 0xffffffff);
        if (iVar2 == 0) goto code_r0x0001801111b5;
    }
    *(int64_t *)(iVar1 + 0x23c8) = iVar2;
    *(int64_t *)(iVar1 + 0x23c0) = iVar2;
    *(undefined8 *)(iVar1 + 0x23f4) = 0;
    *(undefined8 *)(iVar1 + 0x23ec) = 0;
code_r0x0001801111b5:
    *(undefined *)(iVar1 + 0x23e4) = 0;
    return;
}

// ============================================================
// Function: FUN_1801111e0
// Address: 0x1801111e0
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801111ea
// Address: 0x1801111ea
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180111203
// Address: 0x180111203
// Size: 287 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180111322
// Address: 0x180111322
// Size: 474 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801114fc
// Address: 0x1801114fc
// Size: 355 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_18011165f
// Address: 0x18011165f
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801116ac
// Address: 0x1801116ac
// Size: 200 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180111774
// Address: 0x180111774
// Size: 1344 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180111cb4
// Address: 0x180111cb4
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180111d61
// Address: 0x180111d61
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_23c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Removing arg arg_2150h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2338h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_215ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_954h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_974h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Removing arg arg_e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_104h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1ee4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1d70h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_15cch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Removing arg arg_858h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1c04h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_232ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Removing arg arg_2374h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2354h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2340h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_20a0h because it doesn't fit into ProtoModel

void fcn.1801111e0(int64_t arg1, int64_t arg_30h, int64_t arg_90h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    char cVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    float *pfVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint8_t *puVar18;
    uint64_t uVar19;
    int64_t *piVar20;
    int64_t iVar21;
    uint64_t uVar22;
    uint32_t uVar23;
    uint8_t uVar24;
    bool bVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_80h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_58h = CONCAT44(unaff_XMM9_Db, unaff_XMM9_Da);
    uVar17 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) - 1;
    var_18h = 0;
    bVar6 = false;
    if (-1 < (int32_t)uVar17) {
        do {
            iVar21 = *(int64_t *)((uint64_t)uVar17 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if ((iVar21 != 0) && ((*(uint32_t *)(iVar21 + 0x14) & 0x8000000) != 0)) {
                *(undefined8 *)(*(int64_t *)0x180781f28 + 0x23c0) = 0;
                iVar13 = 0;
                goto code_r0x00018011125c;
            }
            uVar17 = uVar17 - 1;
        } while (-1 < (int32_t)uVar17);
    }
    iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0);
    iVar21 = 0;
code_r0x00018011125c:
    if ((*(int64_t *)(iVar7 + 0x23c8) != 0) && (iVar13 == 0)) {
        fVar26 = *(float *)(iVar7 + 0x23dc) - *(float *)(iVar7 + 0x48) * 10.0;
        if (fVar26 <= 0.0) {
            fVar26 = 0.0;
        }
        *(float *)(iVar7 + 0x23dc) = fVar26;
        if ((*(float *)(iVar7 + 0x23fc) <= 0.0) && (fVar26 <= 0.0)) {
            *(undefined8 *)(iVar7 + 0x23c8) = 0;
        }
    }
    uVar19 = 0xffffffff;
    puVar18 = (uint8_t *)0x180644f51;
    uVar22 = 0x23;
    do {
        if ((((char)uVar22 == '#') && (*puVar18 == 0x23)) && (puVar18[1] == 0x23)) {
            uVar19 = 0xffffffff;
            puVar18 = puVar18 + 2;
        } else {
            uVar19 = (uint64_t)((uint32_t)(uVar19 >> 8) ^ *(uint32_t *)((uVar19 & 0xff ^ uVar22) * 4 + 0x180618620));
        }
        uVar24 = *puVar18;
        uVar22 = (uint64_t)uVar24;
        puVar18 = puVar18 + 1;
    } while (uVar24 != 0);
    uVar17 = ~(uint32_t)uVar19;
    if (((*(uint32_t *)(iVar7 + 0x30) & 2) == 0) || ((*(uint8_t *)(iVar7 + 0x34) & 1) == 0)) {
        bVar3 = false;
    } else {
        bVar3 = true;
    }
    var_10h._0_4_ = (float)(CONCAT31(var_10h._1_3_, (char)*(uint32_t *)(iVar7 + 0x30)) & 0xffffff01);
    iVar13 = iVar7;
    if (((iVar21 == 0) && (*(int32_t *)(iVar7 + 0x23b4) != 0)) &&
       (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b4), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
       cVar8 != '\0')) {
        uVar24 = 1;
code_r0x000180111367:
        if ((*(int32_t *)(iVar7 + 0x23b8) == 0) ||
           (cVar8 = func_0x000180109d80(*(int32_t *)(iVar7 + 0x23b8), 0x2001, uVar17), iVar13 = *(int64_t *)0x180781f28,
           cVar8 == '\0')) goto code_r0x00018011138e;
        bVar4 = true;
    } else {
        uVar24 = 0;
        if (iVar21 == 0) goto code_r0x000180111367;
code_r0x00018011138e:
        bVar4 = false;
    }
    if (((bVar3) && (*(int64_t *)(iVar7 + 0x23c0) == 0)) &&
       (cVar8 = func_0x000180109d80(0x27a, 0x2000, uVar17), iVar13 = *(int64_t *)0x180781f28, cVar8 != '\0')) {
        bVar3 = true;
    } else {
        bVar3 = false;
    }
    if ((iVar21 == 0) && (bVar3)) {
        bVar5 = true;
code_r0x0001801113d7:
        if ((*(int64_t *)(iVar7 + 0x23c0) != 0) || ((uVar24 == 0 && (!bVar4)))) goto code_r0x0001801113f0;
        uVar9 = 1;
    } else {
        bVar5 = false;
        if (iVar21 == 0) goto code_r0x0001801113d7;
code_r0x0001801113f0:
        uVar9 = 0;
    }
    bVar25 = false;
    if (bVar3) {
        *(undefined *)(iVar7 + 0x23e4) = 1;
        *(undefined4 *)(iVar7 + 0x23e8) = 0x27a;
        *(undefined4 *)(iVar7 + 0x2228) = 3;
        *(undefined4 *)(iVar7 + 0x23e0) = 3;
    }
    if (((bVar5) || (uVar9 != 0)) &&
       (((iVar21 = *(int64_t *)(iVar7 + 0x21d8), iVar21 != 0 &&
         (((*(char *)(iVar21 + 0x10a) != '\0' && (iVar21 == *(int64_t *)(iVar21 + 0x418))) &&
          (iVar14 = iVar21, (*(uint32_t *)(iVar21 + 0x14) & 0x20000) == 0)))) ||
        (iVar14 = fcn.1801110c0((uint64_t)(*(int32_t *)(iVar7 + 0x1590) - 1), 0x80000001, 0xffffffff), iVar14 != 0)))) {
        if ((uVar9 != 0) || (*(char *)(iVar7 + 0x23b3) != '\0')) {
            uVar2 = *(undefined8 *)(iVar14 + 0x418);
            *(undefined8 *)(iVar7 + 0x23c8) = uVar2;
            *(undefined8 *)(iVar7 + 0x23c0) = uVar2;
        }
        *(undefined8 *)(iVar7 + 0x23d8) = 0;
        *(undefined8 *)(iVar7 + 0x23f4) = 0;
        *(undefined8 *)(iVar7 + 0x23ec) = 0;
        iVar12 = (uVar9 ^ 1) + 2;
        bVar25 = iVar21 == 0;
        *(int32_t *)(iVar7 + 0x2228) = iVar12;
        *(int32_t *)(iVar7 + 0x23e0) = iVar12;
        if ((uVar24 != 0) || (bVar4)) {
            func_0x000180109c30((*(uint32_t *)(iVar7 + 0x23b8) | *(uint32_t *)(iVar7 + 0x23b4)) & 0xf000, uVar17);
        }
    }
    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
    if ((iVar21 != 0) || (iVar14 = var_18h, *(char *)(iVar7 + 0x23e4) != '\0')) {
        if (*(int32_t *)(iVar7 + 0x23e0) == 3) {
            if (iVar21 != 0) {
                fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
                *(float *)(iVar7 + 0x23d8) = fVar26;
                fVar26 = (fVar26 - 0.2) / 0.05;
                if (0.0 <= fVar26) {
                    fVar28 = 1.0;
                    if (fVar26 <= 1.0) {
                        fVar28 = fVar26;
                    }
                } else {
                    fVar28 = 0.0;
                }
                fVar26 = *(float *)(iVar7 + 0x23dc);
                if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                    fVar26 = fVar28;
                }
                *(float *)(iVar7 + 0x23dc) = fVar26;
                uVar9 = func_0x000180107dc0(0x282, 1, 0);
                uVar10 = func_0x000180107dc0(0x283, 1, 0);
                if (((uint32_t)uVar9 - (uint32_t)uVar10 != 0) && (!bVar25)) {
                    fcn.180111130((uint64_t)((uint32_t)uVar9 - (uint32_t)uVar10), var_58h);
                    iVar21 = *(int64_t *)(iVar7 + 0x23c0);
                    *(undefined4 *)(iVar7 + 0x23dc) = 0x3f800000;
                }
            }
            if ((*(char *)(iVar13 + 0x8e0) == '\0') || (*(char *)(iVar13 + 0x1c8c) != '\0')) {
                if ((*(uint8_t *)(iVar7 + 0x23e4) &
                    (*(float *)(iVar7 + 0x23dc) <= 1.0 && *(float *)(iVar7 + 0x23dc) != 1.0)) == 0) {
                    var_18h = *(int64_t *)(iVar7 + 0x23c0);
                } else if (*(int64_t *)(iVar7 + 0x21d8) != 0) {
                    bVar6 = true;
                }
                *(undefined8 *)(iVar7 + 0x23c0) = 0;
                *(undefined *)(iVar7 + 0x23e4) = 0;
                iVar14 = var_18h;
                goto code_r0x000180111632;
            }
        }
        iVar14 = var_18h;
        if ((iVar21 != 0) && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
            fVar26 = *(float *)(iVar7 + 0x48) + *(float *)(iVar7 + 0x23d8);
            uVar17 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b4) != 0) {
                uVar17 = *(uint32_t *)(iVar7 + 0x23b4);
            }
            *(float *)(iVar7 + 0x23d8) = fVar26;
            uVar16 = 0xf000;
            if (*(uint32_t *)(iVar7 + 0x23b8) != 0) {
                uVar16 = *(uint32_t *)(iVar7 + 0x23b8);
            }
            fVar26 = (fVar26 - 0.2) / 0.05;
            if (0.0 <= fVar26) {
                fVar28 = 1.0;
                if (fVar26 <= 1.0) {
                    fVar28 = fVar26;
                }
            } else {
                fVar28 = 0.0;
            }
            fVar26 = *(float *)(iVar7 + 0x23dc);
            if (*(float *)(iVar7 + 0x23dc) <= fVar28) {
                fVar26 = fVar28;
            }
            *(float *)(iVar7 + 0x23dc) = fVar26;
            if (((uVar24 == 0) && (!bVar4)) || (bVar25)) {
                if ((~*(uint32_t *)(iVar7 + 0x13c) & uVar16 & uVar17 & 0xf000) != 0) {
                    iVar14 = iVar21;
                }
            } else {
                fcn.180111130((uint64_t)((uVar24 ^ 1) * 2 - 1), var_58h);
                iVar14 = var_18h;
            }
        }
    }
code_r0x000180111632:
    bVar3 = false;
    var_68h._0_4_ = 0x211;
    var_68h._4_4_ = 0x215;
    if (((*(int64_t *)(iVar7 + 0x21d8) != 0) && ((*(uint32_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x14) & 0x10000) == 0))
       && ((char)var_10h != '\0')) {
        piVar20 = &var_68h;
        do {
            uVar1 = *(undefined4 *)piVar20;
            cVar8 = func_0x000180107dc0(uVar1, 0, 0xffffffff);
            if (cVar8 != '\0') {
                bVar3 = true;
                *(undefined4 *)(iVar7 + 0x23e8) = uVar1;
                *(undefined *)(iVar7 + 0x23e4) = 1;
                *(undefined4 *)(iVar7 + 0x2228) = 2;
                *(undefined4 *)(iVar7 + 0x23e0) = 2;
                break;
            }
            piVar20 = (int64_t *)((int64_t)piVar20 + 4);
        } while (piVar20 != &var_60h);
    }
    if ((*(char *)(iVar7 + 0x23e4) != '\0') && (*(int32_t *)(iVar7 + 0x23e0) == 2)) {
        if ((*(int32_t *)(iVar7 + 0xc18) < 1) &&
           ((((*(char *)(iVar7 + 0x138) == '\0' && (*(char *)(iVar7 + 0x139) == '\0')) &&
             (*(char *)(iVar7 + 0x13b) == '\0')) &&
            ((bVar3 || (*(double *)(iVar7 + 0x16b0) != *(double *)(iVar7 + 0x18))))))) {
            uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
            if (((uVar17 - 0x200 < 0x9b) || ((uVar17 == 0x1000 || (uVar17 == 0x2000)))) ||
               ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
                if (((*(char *)(iVar13 + 0x1f6c) == '\0') || (*(int32_t *)(iVar13 + 0x1654) == -1)) ||
                   (0x77 < uVar17 - 0x200)) {
                    uVar16 = uVar17;
                    if (((uVar17 & 0xf000) != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                        if (uVar17 == 0x2000) {
                            uVar16 = 0x298;
                        } else if (uVar17 == 0x4000) {
                            uVar16 = 0x299;
                        } else {
                            uVar16 = uVar17;
                            if (uVar17 == 0x8000) {
                                uVar16 = 0x29a;
                            }
                        }
                    }
                    if (*(int32_t *)(iVar13 + -0x134 + (int64_t)(int32_t)uVar16 * 0xc) == -1) goto code_r0x0001801118aa;
                }
                goto code_r0x0001801118b3;
            }
code_r0x0001801118aa:
            if (*(int32_t *)(iVar13 + 0x1df8) != -1) goto code_r0x0001801118b3;
        } else {
code_r0x0001801118b3:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        }
        uVar17 = *(uint32_t *)(iVar7 + 0x23e8);
        uVar23 = uVar17 & 0xf000;
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        pfVar15 = (float *)(iVar13 + 8 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10);
        if ((0.0 < *pfVar15 || *pfVar15 == 0.0) &&
           (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0')) {
            if (((uVar17 - 0x200 < 0x9b) || (((uVar17 == 0x1000 || (uVar17 == 0x2000)) || (uVar17 == 0x4000)))) ||
               (uVar17 == 0x8000)) {
                uVar16 = uVar17;
                if (uVar23 != 0) {
                    if (uVar17 == 0x1000) {
                        uVar16 = 0x297;
                    } else if (uVar17 == 0x2000) {
                        uVar16 = 0x298;
                    } else if (uVar17 == 0x4000) {
                        uVar16 = 0x299;
                    } else if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
                if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111a58;
            }
            if ((*(char *)(iVar7 + 0x23e4) != '\0') &&
               ((*(int32_t *)(iVar7 + 0x1654) == 0 || (*(char *)(iVar7 + 0x1661) != '\0')))) {
                pfVar15 = (float *)(iVar7 + 0xaf4);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar8 = '\0';
                } else {
                    cVar8 = '\x01';
                }
                pfVar15 = (float *)(iVar7 + 0x118);
                if (pfVar15 == (float *)0x0) {
                    pfVar15 = (float *)(iVar13 + 0x118);
                }
                if ((*pfVar15 < -256000.0) || (pfVar15[1] < -256000.0)) {
                    cVar11 = '\0';
                } else {
                    cVar11 = '\x01';
                }
                if (cVar11 == cVar8) {
                    bVar6 = true;
                }
            }
        }
code_r0x000180111a58:
        uVar16 = uVar17;
        if (uVar23 != 0) {
            if (uVar17 == 0x1000) {
                uVar16 = 0x297;
            } else if (uVar17 == 0x2000) {
                uVar16 = 0x298;
            } else if (uVar17 == 0x4000) {
                uVar16 = 0x299;
            } else if (uVar17 == 0x8000) {
                uVar16 = 0x29a;
            }
        }
        if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x1ec) * 0x10) == '\0') {
code_r0x000180111b28:
            *(undefined *)(iVar7 + 0x23e4) = 0;
        } else if ((((uVar17 - 0x200 < 0x9b) || (uVar17 == 0x1000)) || (uVar17 == 0x2000)) ||
                  ((uVar17 == 0x4000 || (uVar17 == 0x8000)))) {
            uVar16 = uVar17;
            if ((uVar23 != 0) && (uVar16 = 0x297, uVar17 != 0x1000)) {
                if (uVar17 == 0x2000) {
                    uVar16 = 0x298;
                } else if (uVar17 == 0x4000) {
                    uVar16 = 0x299;
                } else {
                    uVar16 = uVar17;
                    if (uVar17 == 0x8000) {
                        uVar16 = 0x29a;
                    }
                }
            }
            if (*(char *)(iVar13 + ((int64_t)(int32_t)uVar16 + -0x19) * 0xc) != '\0') goto code_r0x000180111b28;
        }
    }
    if ((*(int64_t *)(iVar7 + 0x23c0) != 0) && ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x14) & 4) == 0)) {
        if (*(int32_t *)(iVar7 + 0x2228) == 2) {
            if (*(char *)(iVar7 + 0x139) == '\0') {
                fVar26 = *(float *)(iVar13 + 0x16c) - *(float *)(iVar13 + 0x15c);
                fVar28 = *(float *)(iVar13 + 0x18c) - *(float *)(iVar13 + 0x17c);
code_r0x000180111bb4:
                if ((fVar26 != 0.0) || (fVar28 != 0.0)) {
                    fVar27 = *(float *)(iVar7 + 0x48) * 800.0 * *(float *)(iVar13 + 0x12c4);
                    *(undefined *)(iVar7 + 0x21cd) = 1;
                    fVar28 = fVar27 * fVar28 + *(float *)(iVar7 + 0x23f0);
                    fVar26 = fVar27 * fVar26 + *(float *)(iVar7 + 0x23ec);
                    *(float *)(iVar7 + 0x23f0) = fVar28;
                    *(float *)(iVar7 + 0x23ec) = fVar26;
                    fVar27 = (float)(int32_t)fVar26;
                    fVar26 = (float)(int32_t)fVar28;
                    if ((fVar27 != 0.0) || (fVar26 != 0.0)) {
                        iVar21 = *(int64_t *)(*(int64_t *)(iVar7 + 0x23c0) + 0x428);
                        var_10h._0_4_ = fVar27 + *(float *)(iVar21 + 0x60);
                        var_10h._4_4_ = fVar26 + *(float *)(iVar21 + 100);
                        func_0x000180106470(iVar21, &var_10h, 1);
                        *(float *)(iVar7 + 0x23f0) = *(float *)(iVar7 + 0x23f0) - fVar26;
                        *(float *)(iVar7 + 0x23ec) = *(float *)(iVar7 + 0x23ec) - fVar27;
                    }
                }
            }
        } else if (*(int32_t *)(iVar7 + 0x2228) == 3) {
            fVar26 = *(float *)(iVar13 + 0x9dc) - *(float *)(iVar13 + 0x9cc);
            fVar28 = *(float *)(iVar13 + 0x9fc) - *(float *)(iVar13 + 0x9ec);
            goto code_r0x000180111bb4;
        }
    }
    if (iVar14 == 0) goto code_r0x000180111d41;
    iVar21 = *(int64_t *)(iVar13 + 0x21d8);
    if (iVar21 == 0) {
        iVar21 = 0;
code_r0x000180111cd1:
        func_0x0001800f9f30(0, 0);
        func_0x00018010e380();
        func_0x00018010d210(iVar14, 0);
        func_0x00018010e050(iVar14, 1);
        iVar14 = *(int64_t *)(iVar13 + 0x21d8);
        if (*(int32_t *)(iVar14 + 0x450) == 0) {
            func_0x00018010ee50(iVar14, 0);
        }
        if (*(int16_t *)(iVar14 + 0x1b6) == 2) {
            *(undefined4 *)(iVar13 + 0x21e4) = 1;
        }
        if ((*(int64_t *)(iVar14 + 0x48) != iVar21) && (*(code **)(iVar13 + 0xcd8) != (code *)0x0)) {
            (**(code **)(iVar13 + 0xcd8))();
        }
    } else if (iVar14 != *(int64_t *)(iVar21 + 0x418)) {
        iVar21 = *(int64_t *)(iVar21 + 0x48);
        goto code_r0x000180111cd1;
    }
    *(undefined8 *)(iVar13 + 0x23c0) = 0;
code_r0x000180111d41:
    if ((bVar6) && (*(int64_t *)(iVar7 + 0x21d8) != 0)) {
        func_0x0001800f9f30(0, 0);
        iVar21 = *(int64_t *)(iVar7 + 0x21d8);
        iVar13 = iVar21;
        if (*(int64_t *)(iVar21 + 0x408) != 0) {
            do {
                if (((*(uint8_t *)(iVar13 + 0x1b4) & 2) != 0) ||
                   ((*(uint32_t *)(iVar13 + 0x14) & 0x15000000) != 0x1000000)) break;
                iVar13 = *(int64_t *)(iVar13 + 0x408);
            } while (*(int64_t *)(iVar13 + 0x408) != 0);
            if (iVar13 != iVar21) {
                func_0x00018010e050(iVar13, 0);
                *(int64_t *)(iVar13 + 0x448) = iVar21;
            }
        }
        if ((*(uint8_t *)(*(int64_t *)(iVar7 + 0x21d8) + 0x1b4) & 2) == 0) {
            uVar17 = 0;
        } else {
            uVar17 = *(uint32_t *)(iVar7 + 0x21e4) ^ 1;
        }
        if (uVar17 != *(uint32_t *)(iVar7 + 0x21e4)) {
            if ((uVar17 == 1) && (*(int64_t *)(iVar13 + 0x4c8) == 0)) {
                *(undefined4 *)(*(int64_t *)(iVar7 + 0x21d8) + 0x454) = 0;
            }
            func_0x00018010ed90();
            func_0x00018010e380();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180111e20
// Address: 0x180111e20
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180111e20(int64_t arg_40h)
{
    char *pcVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    char *pcVar10;
    char *pcVar11;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if (0.15 < *(float *)(*(int64_t *)0x180781f28 + 0x23d8) || *(float *)(*(int64_t *)0x180781f28 + 0x23d8) == 0.15) {
        iVar7 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
        fVar2 = *(float *)(iVar7 + 0x10);
        fVar3 = *(float *)(iVar7 + 0x14);
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x10;
        *(float *)(iVar8 + 0x2050) = fVar2 * 0.2;
        *(float *)(iVar8 + 0x2054) = fVar3 * 0.2;
        *(undefined4 *)(iVar8 + 0x2058) = 0x7f7fffff;
        *(undefined4 *)(iVar8 + 0x205c) = 0x7f7fffff;
        *(undefined8 *)(iVar8 + 0x2060) = 0;
        *(undefined8 *)(iVar8 + 0x2068) = 0;
        fVar2 = *(float *)(iVar7 + 0x14);
        fVar3 = *(float *)(iVar7 + 0x10);
        fVar4 = *(float *)(iVar7 + 0xc);
        fVar5 = *(float *)(iVar7 + 8);
        *(uint32_t *)(iVar8 + 0x2008) = *(uint32_t *)(iVar8 + 0x2008) | 1;
        *(undefined4 *)(iVar8 + 0x2024) = 0x3f000000;
        *(float *)(iVar8 + 0x2020) = fVar2 * 0.5 + fVar4;
        *(undefined4 *)(iVar8 + 0x2028) = 0x3f000000;
        *(float *)(iVar8 + 0x201c) = fVar3 * 0.5 + fVar5;
        *(undefined4 *)(iVar8 + 0x200c) = 1;
        *(undefined *)(iVar8 + 0x204c) = 1;
        var_8h = CONCAT44(*(float *)(iVar8 + 0xda8) + *(float *)(iVar8 + 0xda8), 
                          *(float *)(iVar8 + 0xda4) + *(float *)(iVar8 + 0xda4));
        func_0x0001800f6960(2, &var_8h);
        func_0x0001801019f0(0x180644f08, 0, 0x31347);
        *(undefined8 *)(iVar8 + 0x23d0) = *(undefined8 *)(iVar8 + 0x15e0);
        if (*(char *)(iVar8 + 0x20) != '\0') {
            func_0x00018013cb40(iVar8 + 0x20);
        }
        uVar6 = *(uint32_t *)(iVar8 + 0x1590);
        while (uVar6 = uVar6 - 1, -1 < (int32_t)uVar6) {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1598) + (uint64_t)uVar6 * 8);
            if (((*(char *)(iVar7 + 0x10a) != '\0') && (iVar7 == *(int64_t *)(iVar7 + 0x418))) &&
               ((*(uint32_t *)(iVar7 + 0x14) & 0x20000) == 0)) {
                pcVar11 = *(char **)(iVar7 + 8);
                pcVar10 = pcVar11;
                if (pcVar11 == (char *)0xffffffffffffffff) {
code_r0x000180111fe2:
                    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x1a & 1) == 0) {
                        if (((*(uint32_t *)(iVar7 + 0x14) >> 10 & 1) == 0) ||
                           (iVar9 = func_0x000180498f10(pcVar11, 0x180644ee8), iVar9 != 0)) {
                            if (*(int64_t *)(iVar7 + 0x4c8) != 0) {
                                pcVar11 = "(Dock node)";
                                goto code_r0x000180112053;
                            }
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c8);
                        } else {
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29b8);
                        }
                    } else {
                        pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c0);
                    }
                    pcVar11 = "*Missing Text*";
                    if (pcVar10 != (char *)0x0) {
                        pcVar11 = pcVar10;
                    }
                } else {
                    do {
                        if ((*pcVar10 == '\0') || ((pcVar1 = pcVar10 + 1, *pcVar10 == '#' && (*pcVar1 == '#')))) break;
                        pcVar10 = pcVar1;
                    } while (pcVar1 != (char *)0xffffffffffffffff);
                    if (pcVar11 == pcVar10) goto code_r0x000180111fe2;
                }
code_r0x000180112053:
                var_8h = 0;
                func_0x000180146c70(pcVar11, *(int64_t *)(iVar8 + 0x23c0) == iVar7, 0, &var_8h);
            }
        }
        func_0x000180105c20();
        func_0x0001800f6a20(1);
    }
    return;
}

// ============================================================
// Function: FUN_180111e4b
// Address: 0x180111e4b
// Size: 302 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180111e20(int64_t arg_40h)
{
    char *pcVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    char *pcVar10;
    char *pcVar11;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if (0.15 < *(float *)(*(int64_t *)0x180781f28 + 0x23d8) || *(float *)(*(int64_t *)0x180781f28 + 0x23d8) == 0.15) {
        iVar7 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
        fVar2 = *(float *)(iVar7 + 0x10);
        fVar3 = *(float *)(iVar7 + 0x14);
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x10;
        *(float *)(iVar8 + 0x2050) = fVar2 * 0.2;
        *(float *)(iVar8 + 0x2054) = fVar3 * 0.2;
        *(undefined4 *)(iVar8 + 0x2058) = 0x7f7fffff;
        *(undefined4 *)(iVar8 + 0x205c) = 0x7f7fffff;
        *(undefined8 *)(iVar8 + 0x2060) = 0;
        *(undefined8 *)(iVar8 + 0x2068) = 0;
        fVar2 = *(float *)(iVar7 + 0x14);
        fVar3 = *(float *)(iVar7 + 0x10);
        fVar4 = *(float *)(iVar7 + 0xc);
        fVar5 = *(float *)(iVar7 + 8);
        *(uint32_t *)(iVar8 + 0x2008) = *(uint32_t *)(iVar8 + 0x2008) | 1;
        *(undefined4 *)(iVar8 + 0x2024) = 0x3f000000;
        *(float *)(iVar8 + 0x2020) = fVar2 * 0.5 + fVar4;
        *(undefined4 *)(iVar8 + 0x2028) = 0x3f000000;
        *(float *)(iVar8 + 0x201c) = fVar3 * 0.5 + fVar5;
        *(undefined4 *)(iVar8 + 0x200c) = 1;
        *(undefined *)(iVar8 + 0x204c) = 1;
        var_8h = CONCAT44(*(float *)(iVar8 + 0xda8) + *(float *)(iVar8 + 0xda8), 
                          *(float *)(iVar8 + 0xda4) + *(float *)(iVar8 + 0xda4));
        func_0x0001800f6960(2, &var_8h);
        func_0x0001801019f0(0x180644f08, 0, 0x31347);
        *(undefined8 *)(iVar8 + 0x23d0) = *(undefined8 *)(iVar8 + 0x15e0);
        if (*(char *)(iVar8 + 0x20) != '\0') {
            func_0x00018013cb40(iVar8 + 0x20);
        }
        uVar6 = *(uint32_t *)(iVar8 + 0x1590);
        while (uVar6 = uVar6 - 1, -1 < (int32_t)uVar6) {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1598) + (uint64_t)uVar6 * 8);
            if (((*(char *)(iVar7 + 0x10a) != '\0') && (iVar7 == *(int64_t *)(iVar7 + 0x418))) &&
               ((*(uint32_t *)(iVar7 + 0x14) & 0x20000) == 0)) {
                pcVar11 = *(char **)(iVar7 + 8);
                pcVar10 = pcVar11;
                if (pcVar11 == (char *)0xffffffffffffffff) {
code_r0x000180111fe2:
                    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x1a & 1) == 0) {
                        if (((*(uint32_t *)(iVar7 + 0x14) >> 10 & 1) == 0) ||
                           (iVar9 = func_0x000180498f10(pcVar11, 0x180644ee8), iVar9 != 0)) {
                            if (*(int64_t *)(iVar7 + 0x4c8) != 0) {
                                pcVar11 = "(Dock node)";
                                goto code_r0x000180112053;
                            }
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c8);
                        } else {
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29b8);
                        }
                    } else {
                        pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c0);
                    }
                    pcVar11 = "*Missing Text*";
                    if (pcVar10 != (char *)0x0) {
                        pcVar11 = pcVar10;
                    }
                } else {
                    do {
                        if ((*pcVar10 == '\0') || ((pcVar1 = pcVar10 + 1, *pcVar10 == '#' && (*pcVar1 == '#')))) break;
                        pcVar10 = pcVar1;
                    } while (pcVar1 != (char *)0xffffffffffffffff);
                    if (pcVar11 == pcVar10) goto code_r0x000180111fe2;
                }
code_r0x000180112053:
                var_8h = 0;
                func_0x000180146c70(pcVar11, *(int64_t *)(iVar8 + 0x23c0) == iVar7, 0, &var_8h);
            }
        }
        func_0x000180105c20();
        func_0x0001800f6a20(1);
    }
    return;
}

// ============================================================
// Function: FUN_180111f79
// Address: 0x180111f79
// Size: 267 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180111e20(int64_t arg_40h)
{
    char *pcVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    char *pcVar10;
    char *pcVar11;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if (0.15 < *(float *)(*(int64_t *)0x180781f28 + 0x23d8) || *(float *)(*(int64_t *)0x180781f28 + 0x23d8) == 0.15) {
        iVar7 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
        fVar2 = *(float *)(iVar7 + 0x10);
        fVar3 = *(float *)(iVar7 + 0x14);
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x10;
        *(float *)(iVar8 + 0x2050) = fVar2 * 0.2;
        *(float *)(iVar8 + 0x2054) = fVar3 * 0.2;
        *(undefined4 *)(iVar8 + 0x2058) = 0x7f7fffff;
        *(undefined4 *)(iVar8 + 0x205c) = 0x7f7fffff;
        *(undefined8 *)(iVar8 + 0x2060) = 0;
        *(undefined8 *)(iVar8 + 0x2068) = 0;
        fVar2 = *(float *)(iVar7 + 0x14);
        fVar3 = *(float *)(iVar7 + 0x10);
        fVar4 = *(float *)(iVar7 + 0xc);
        fVar5 = *(float *)(iVar7 + 8);
        *(uint32_t *)(iVar8 + 0x2008) = *(uint32_t *)(iVar8 + 0x2008) | 1;
        *(undefined4 *)(iVar8 + 0x2024) = 0x3f000000;
        *(float *)(iVar8 + 0x2020) = fVar2 * 0.5 + fVar4;
        *(undefined4 *)(iVar8 + 0x2028) = 0x3f000000;
        *(float *)(iVar8 + 0x201c) = fVar3 * 0.5 + fVar5;
        *(undefined4 *)(iVar8 + 0x200c) = 1;
        *(undefined *)(iVar8 + 0x204c) = 1;
        var_8h = CONCAT44(*(float *)(iVar8 + 0xda8) + *(float *)(iVar8 + 0xda8), 
                          *(float *)(iVar8 + 0xda4) + *(float *)(iVar8 + 0xda4));
        func_0x0001800f6960(2, &var_8h);
        func_0x0001801019f0(0x180644f08, 0, 0x31347);
        *(undefined8 *)(iVar8 + 0x23d0) = *(undefined8 *)(iVar8 + 0x15e0);
        if (*(char *)(iVar8 + 0x20) != '\0') {
            func_0x00018013cb40(iVar8 + 0x20);
        }
        uVar6 = *(uint32_t *)(iVar8 + 0x1590);
        while (uVar6 = uVar6 - 1, -1 < (int32_t)uVar6) {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1598) + (uint64_t)uVar6 * 8);
            if (((*(char *)(iVar7 + 0x10a) != '\0') && (iVar7 == *(int64_t *)(iVar7 + 0x418))) &&
               ((*(uint32_t *)(iVar7 + 0x14) & 0x20000) == 0)) {
                pcVar11 = *(char **)(iVar7 + 8);
                pcVar10 = pcVar11;
                if (pcVar11 == (char *)0xffffffffffffffff) {
code_r0x000180111fe2:
                    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x1a & 1) == 0) {
                        if (((*(uint32_t *)(iVar7 + 0x14) >> 10 & 1) == 0) ||
                           (iVar9 = func_0x000180498f10(pcVar11, 0x180644ee8), iVar9 != 0)) {
                            if (*(int64_t *)(iVar7 + 0x4c8) != 0) {
                                pcVar11 = "(Dock node)";
                                goto code_r0x000180112053;
                            }
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c8);
                        } else {
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29b8);
                        }
                    } else {
                        pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c0);
                    }
                    pcVar11 = "*Missing Text*";
                    if (pcVar10 != (char *)0x0) {
                        pcVar11 = pcVar10;
                    }
                } else {
                    do {
                        if ((*pcVar10 == '\0') || ((pcVar1 = pcVar10 + 1, *pcVar10 == '#' && (*pcVar1 == '#')))) break;
                        pcVar10 = pcVar1;
                    } while (pcVar1 != (char *)0xffffffffffffffff);
                    if (pcVar11 == pcVar10) goto code_r0x000180111fe2;
                }
code_r0x000180112053:
                var_8h = 0;
                func_0x000180146c70(pcVar11, *(int64_t *)(iVar8 + 0x23c0) == iVar7, 0, &var_8h);
            }
        }
        func_0x000180105c20();
        func_0x0001800f6a20(1);
    }
    return;
}

// ============================================================
// Function: FUN_180112084
// Address: 0x180112084
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180111e20(int64_t arg_40h)
{
    char *pcVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    char *pcVar10;
    char *pcVar11;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if (0.15 < *(float *)(*(int64_t *)0x180781f28 + 0x23d8) || *(float *)(*(int64_t *)0x180781f28 + 0x23d8) == 0.15) {
        iVar7 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
        fVar2 = *(float *)(iVar7 + 0x10);
        fVar3 = *(float *)(iVar7 + 0x14);
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x10;
        *(float *)(iVar8 + 0x2050) = fVar2 * 0.2;
        *(float *)(iVar8 + 0x2054) = fVar3 * 0.2;
        *(undefined4 *)(iVar8 + 0x2058) = 0x7f7fffff;
        *(undefined4 *)(iVar8 + 0x205c) = 0x7f7fffff;
        *(undefined8 *)(iVar8 + 0x2060) = 0;
        *(undefined8 *)(iVar8 + 0x2068) = 0;
        fVar2 = *(float *)(iVar7 + 0x14);
        fVar3 = *(float *)(iVar7 + 0x10);
        fVar4 = *(float *)(iVar7 + 0xc);
        fVar5 = *(float *)(iVar7 + 8);
        *(uint32_t *)(iVar8 + 0x2008) = *(uint32_t *)(iVar8 + 0x2008) | 1;
        *(undefined4 *)(iVar8 + 0x2024) = 0x3f000000;
        *(float *)(iVar8 + 0x2020) = fVar2 * 0.5 + fVar4;
        *(undefined4 *)(iVar8 + 0x2028) = 0x3f000000;
        *(float *)(iVar8 + 0x201c) = fVar3 * 0.5 + fVar5;
        *(undefined4 *)(iVar8 + 0x200c) = 1;
        *(undefined *)(iVar8 + 0x204c) = 1;
        var_8h = CONCAT44(*(float *)(iVar8 + 0xda8) + *(float *)(iVar8 + 0xda8), 
                          *(float *)(iVar8 + 0xda4) + *(float *)(iVar8 + 0xda4));
        func_0x0001800f6960(2, &var_8h);
        func_0x0001801019f0(0x180644f08, 0, 0x31347);
        *(undefined8 *)(iVar8 + 0x23d0) = *(undefined8 *)(iVar8 + 0x15e0);
        if (*(char *)(iVar8 + 0x20) != '\0') {
            func_0x00018013cb40(iVar8 + 0x20);
        }
        uVar6 = *(uint32_t *)(iVar8 + 0x1590);
        while (uVar6 = uVar6 - 1, -1 < (int32_t)uVar6) {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1598) + (uint64_t)uVar6 * 8);
            if (((*(char *)(iVar7 + 0x10a) != '\0') && (iVar7 == *(int64_t *)(iVar7 + 0x418))) &&
               ((*(uint32_t *)(iVar7 + 0x14) & 0x20000) == 0)) {
                pcVar11 = *(char **)(iVar7 + 8);
                pcVar10 = pcVar11;
                if (pcVar11 == (char *)0xffffffffffffffff) {
code_r0x000180111fe2:
                    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x1a & 1) == 0) {
                        if (((*(uint32_t *)(iVar7 + 0x14) >> 10 & 1) == 0) ||
                           (iVar9 = func_0x000180498f10(pcVar11, 0x180644ee8), iVar9 != 0)) {
                            if (*(int64_t *)(iVar7 + 0x4c8) != 0) {
                                pcVar11 = "(Dock node)";
                                goto code_r0x000180112053;
                            }
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c8);
                        } else {
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29b8);
                        }
                    } else {
                        pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c0);
                    }
                    pcVar11 = "*Missing Text*";
                    if (pcVar10 != (char *)0x0) {
                        pcVar11 = pcVar10;
                    }
                } else {
                    do {
                        if ((*pcVar10 == '\0') || ((pcVar1 = pcVar10 + 1, *pcVar10 == '#' && (*pcVar1 == '#')))) break;
                        pcVar10 = pcVar1;
                    } while (pcVar1 != (char *)0xffffffffffffffff);
                    if (pcVar11 == pcVar10) goto code_r0x000180111fe2;
                }
code_r0x000180112053:
                var_8h = 0;
                func_0x000180146c70(pcVar11, *(int64_t *)(iVar8 + 0x23c0) == iVar7, 0, &var_8h);
            }
        }
        func_0x000180105c20();
        func_0x0001800f6a20(1);
    }
    return;
}

// ============================================================
// Function: FUN_180112098
// Address: 0x180112098
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180111e20(int64_t arg_40h)
{
    char *pcVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    char *pcVar10;
    char *pcVar11;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar8 = *(int64_t *)0x180781f28;
    if (0.15 < *(float *)(*(int64_t *)0x180781f28 + 0x23d8) || *(float *)(*(int64_t *)0x180781f28 + 0x23d8) == 0.15) {
        iVar7 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
        fVar2 = *(float *)(iVar7 + 0x10);
        fVar3 = *(float *)(iVar7 + 0x14);
        *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x10;
        *(float *)(iVar8 + 0x2050) = fVar2 * 0.2;
        *(float *)(iVar8 + 0x2054) = fVar3 * 0.2;
        *(undefined4 *)(iVar8 + 0x2058) = 0x7f7fffff;
        *(undefined4 *)(iVar8 + 0x205c) = 0x7f7fffff;
        *(undefined8 *)(iVar8 + 0x2060) = 0;
        *(undefined8 *)(iVar8 + 0x2068) = 0;
        fVar2 = *(float *)(iVar7 + 0x14);
        fVar3 = *(float *)(iVar7 + 0x10);
        fVar4 = *(float *)(iVar7 + 0xc);
        fVar5 = *(float *)(iVar7 + 8);
        *(uint32_t *)(iVar8 + 0x2008) = *(uint32_t *)(iVar8 + 0x2008) | 1;
        *(undefined4 *)(iVar8 + 0x2024) = 0x3f000000;
        *(float *)(iVar8 + 0x2020) = fVar2 * 0.5 + fVar4;
        *(undefined4 *)(iVar8 + 0x2028) = 0x3f000000;
        *(float *)(iVar8 + 0x201c) = fVar3 * 0.5 + fVar5;
        *(undefined4 *)(iVar8 + 0x200c) = 1;
        *(undefined *)(iVar8 + 0x204c) = 1;
        var_8h = CONCAT44(*(float *)(iVar8 + 0xda8) + *(float *)(iVar8 + 0xda8), 
                          *(float *)(iVar8 + 0xda4) + *(float *)(iVar8 + 0xda4));
        func_0x0001800f6960(2, &var_8h);
        func_0x0001801019f0(0x180644f08, 0, 0x31347);
        *(undefined8 *)(iVar8 + 0x23d0) = *(undefined8 *)(iVar8 + 0x15e0);
        if (*(char *)(iVar8 + 0x20) != '\0') {
            func_0x00018013cb40(iVar8 + 0x20);
        }
        uVar6 = *(uint32_t *)(iVar8 + 0x1590);
        while (uVar6 = uVar6 - 1, -1 < (int32_t)uVar6) {
            iVar7 = *(int64_t *)(*(int64_t *)(iVar8 + 0x1598) + (uint64_t)uVar6 * 8);
            if (((*(char *)(iVar7 + 0x10a) != '\0') && (iVar7 == *(int64_t *)(iVar7 + 0x418))) &&
               ((*(uint32_t *)(iVar7 + 0x14) & 0x20000) == 0)) {
                pcVar11 = *(char **)(iVar7 + 8);
                pcVar10 = pcVar11;
                if (pcVar11 == (char *)0xffffffffffffffff) {
code_r0x000180111fe2:
                    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x1a & 1) == 0) {
                        if (((*(uint32_t *)(iVar7 + 0x14) >> 10 & 1) == 0) ||
                           (iVar9 = func_0x000180498f10(pcVar11, 0x180644ee8), iVar9 != 0)) {
                            if (*(int64_t *)(iVar7 + 0x4c8) != 0) {
                                pcVar11 = "(Dock node)";
                                goto code_r0x000180112053;
                            }
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c8);
                        } else {
                            pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29b8);
                        }
                    } else {
                        pcVar10 = *(char **)(*(int64_t *)0x180781f28 + 0x29c0);
                    }
                    pcVar11 = "*Missing Text*";
                    if (pcVar10 != (char *)0x0) {
                        pcVar11 = pcVar10;
                    }
                } else {
                    do {
                        if ((*pcVar10 == '\0') || ((pcVar1 = pcVar10 + 1, *pcVar10 == '#' && (*pcVar1 == '#')))) break;
                        pcVar10 = pcVar1;
                    } while (pcVar1 != (char *)0xffffffffffffffff);
                    if (pcVar11 == pcVar10) goto code_r0x000180111fe2;
                }
code_r0x000180112053:
                var_8h = 0;
                func_0x000180146c70(pcVar11, *(int64_t *)(iVar8 + 0x23c0) == iVar7, 0, &var_8h);
            }
        }
        func_0x000180105c20();
        func_0x0001800f6a20(1);
    }
    return;
}

// ============================================================
// Function: FUN_1801120a0
// Address: 0x1801120a0
// Size: 173 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801120a0(void)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x241c) = 0;
    *(undefined8 *)(iVar1 + 0x2410) = 0;
    *(undefined4 *)(iVar1 + 0x2418) = 0;
    *(undefined *)(iVar1 + 0x2400) = 0;
    *(undefined (*) [16])(iVar1 + 0x2428) = ZEXT816(0);
    *(undefined (*) [16])(iVar1 + 0x2438) = ZEXT816(0);
    *(undefined2 *)(iVar1 + 0x2448) = 0;
    *(undefined4 *)(iVar1 + 0x2424) = 0xffffffff;
    *(undefined *)(iVar1 + 0x244a) = 0;
    *(undefined4 *)(iVar1 + 0x2478) = 0;
    *(undefined8 *)(iVar1 + 0x2484) = 0;
    *(undefined4 *)(iVar1 + 0x2480) = 0x7f7fffff;
    *(undefined4 *)(iVar1 + 0x248c) = 0xffffffff;
    if (*(int64_t *)(iVar1 + 0x24a0) != 0) {
        *(undefined8 *)(iVar1 + 0x2498) = 0;
        fcn.180460d90();
        *(undefined8 *)(iVar1 + 0x24a0) = 0;
    }
    *(undefined (*) [16])(iVar1 + 0x24a8) = ZEXT816(0);
    return;
}

// ============================================================
// Function: FUN_180112150
// Address: 0x180112150
// Size: 287 bytes
// ============================================================
uint64_t fcn.180112150(void)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    uint64_t in_RAX;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar1 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
    if ((iVar1 != 0) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar1)) {
        iVar4 = (int32_t)*(char *)(*(int64_t *)0x180781f28 + 0x1667);
        if (*(char *)(*(int64_t *)0x180781f28 + 0x1667) == -1) {
            iVar4 = 0;
        }
        in_RAX = (uint64_t)iVar4;
        if ((*(char *)(in_RAX + 0x120 + *(int64_t *)0x180781f28) != '\0') &&
           (in_RAX = *(uint64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(in_RAX + 0x10e) == '\0')) {
            *(undefined *)(*(int64_t *)0x180781f28 + 0x1661) = 0;
            uVar2 = *(undefined4 *)(*(int64_t *)(in_RAX + 0x150) + -4 + (int64_t)*(int32_t *)(in_RAX + 0x148) * 4);
            in_RAX = fcn.180108230(iVar4, 0xbf800000);
            *(undefined4 *)(iVar3 + 0x1f68) = 0xf;
            *(undefined *)(iVar3 + 0x1f6c) = 1;
            *(bool *)(iVar3 + 0x2239) = *(char *)(iVar3 + 0x223a) != '\0';
            *(undefined2 *)(iVar3 + 0x2278) = 0;
            if ((char)in_RAX != '\0') {
                if (*(char *)(iVar3 + 0x2400) == '\0') {
                    fcn.1801120a0();
                    *(int32_t *)(iVar3 + 0x241c) = iVar1;
                    *(undefined4 *)(iVar3 + 0x2420) = uVar2;
                    *(undefined *)(iVar3 + 0x2400) = 1;
                    *(undefined4 *)(iVar3 + 0x2404) = 0xe5;
                    *(int32_t *)(iVar3 + 0x240c) = iVar4;
                    if (iVar1 == *(int32_t *)(iVar3 + 0x1654)) {
                        *(undefined *)(iVar3 + 0x1662) = 1;
                    }
                }
                *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) & 0xfffffffe;
                *(undefined4 *)(iVar3 + 0x2408) = *(undefined4 *)(iVar3 + 4);
                *(undefined *)(iVar3 + 0x2401) = 1;
                return CONCAT71((unkuint7)(unkuint3)((uint32_t)*(undefined4 *)(iVar3 + 4) >> 8), 1);
            }
        }
    }
    return in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_180112270
// Address: 0x180112270
// Size: 54 bytes
// ============================================================
void fcn.180112270(void)
{
    int64_t iVar1;
    
    iVar1 = *(int64_t *)0x180781f28;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x2404) & 1) == 0) {
        func_0x000180105c20();
    }
    if (*(int32_t *)(iVar1 + 0x2424) == -1) {
        fcn.1801120a0();
    }
    *(undefined *)(iVar1 + 0x2401) = 0;
    return;
}

// ============================================================
// Function: FUN_1801122b0
// Address: 0x1801122b0
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1801122b0(undefined8 placeholder_0, int64_t arg2)
{
    undefined (*pauVar1) [16];
    int64_t iVar2;
    int32_t iVar3;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fcn.180498d90(*(int64_t *)0x180781f28 + 0x2428, 0x180644588, 0x20);
    *(undefined *)(iVar2 + 0x2448) = 0;
    fcn.18011f640(unaff_RSI);
    pauVar1 = (undefined (*) [16])(iVar2 + 0x24a8);
    *pauVar1 = ZEXT816(0);
    *(undefined (**) [16])(iVar2 + 0x2410) = pauVar1;
    *(undefined8 *)*pauVar1 = *(undefined8 *)arg2;
    *(undefined4 *)(iVar2 + 0x2418) = 8;
    *(undefined4 *)(iVar2 + 0x2424) = *(undefined4 *)(iVar2 + 4);
    iVar3 = *(int32_t *)(iVar2 + 4);
    if ((*(int32_t *)(iVar2 + 0x248c) != iVar3) && (iVar3 = iVar3 + -1, *(int32_t *)(iVar2 + 0x248c) != iVar3)) {
        return (uint64_t)(unkuint3)((uint32_t)iVar3 >> 8) << 8;
    }
    return CONCAT71((unkuint7)(unkuint3)((uint32_t)iVar3 >> 8), 1);
}

// ============================================================
// Function: FUN_180112360
// Address: 0x180112360
// Size: 257 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180112360(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined uVar3;
    char cVar4;
    int32_t iVar5;
    float fVar6;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2424) == -1) {
        return 0;
    }
    iVar5 = func_0x000180498f10(0x180644588, *(int64_t *)0x180781f28 + 0x2428);
    if (iVar5 != 0) {
        return 0;
    }
    fVar6 = (*(float *)(iVar2 + 0x245c) - *(float *)(iVar2 + 0x2454)) *
            (*(float *)(iVar2 + 0x2458) - *(float *)(iVar2 + 0x2450));
    if (*(float *)(iVar2 + 0x2480) <= fVar6 && fVar6 != *(float *)(iVar2 + 0x2480)) {
        return 0;
    }
    iVar5 = *(int32_t *)(iVar2 + 0x2470);
    iVar1 = *(int32_t *)(iVar2 + 0x2488);
    *(float *)(iVar2 + 0x2480) = fVar6;
    *(undefined4 *)(iVar2 + 0x2478) = 0xc00;
    *(int32_t *)(iVar2 + 0x2484) = iVar5;
    *(bool *)(iVar2 + 0x2449) = iVar1 == iVar5;
    *(int32_t *)(iVar2 + 0x248c) = *(int32_t *)(iVar2 + 4);
    if (((*(uint8_t *)(iVar2 + 0x2404) & 0x10) == 0) || (*(int32_t *)(iVar2 + 0x240c) != -1)) {
        if ((iVar1 == iVar5) && (cVar4 = func_0x000180107f80(*(undefined4 *)(iVar2 + 0x240c)), cVar4 == '\0'))
        goto code_r0x00018011244d;
    } else if ((iVar1 == iVar5) && (*(int32_t *)(iVar2 + 0x2408) < *(int32_t *)(iVar2 + 4))) {
code_r0x00018011244d:
        uVar3 = 1;
        goto code_r0x000180112422;
    }
    uVar3 = 0;
code_r0x000180112422:
    *(undefined *)(iVar2 + 0x244a) = uVar3;
    return iVar2 + 0x2410;
}

// ============================================================
// Function: FUN_180112470
// Address: 0x180112470
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180112470(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if (*(int64_t *)(arg1 + 0x2a08) != 0) {
        fcn.18011f640(in_stack_00000010);
        iVar2 = *(int32_t *)(arg1 + 0x2a10) + -1;
        if (*(int32_t *)(arg1 + 0x2a10) == 0) {
            iVar2 = 0;
        }
        iVar1 = 0x180781edb;
        if (*(int64_t *)(arg1 + 0x2a18) != 0) {
            iVar1 = *(int64_t *)(arg1 + 0x2a18);
        }
        fcn.180460a38(iVar1, 1, (int64_t)iVar2, *(undefined8 *)(arg1 + 0x2a08));
    }
    return;
}

// ============================================================
// Function: FUN_180112485
// Address: 0x180112485
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180112470(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if (*(int64_t *)(arg1 + 0x2a08) != 0) {
        fcn.18011f640(in_stack_00000010);
        iVar2 = *(int32_t *)(arg1 + 0x2a10) + -1;
        if (*(int32_t *)(arg1 + 0x2a10) == 0) {
            iVar2 = 0;
        }
        iVar1 = 0x180781edb;
        if (*(int64_t *)(arg1 + 0x2a18) != 0) {
            iVar1 = *(int64_t *)(arg1 + 0x2a18);
        }
        fcn.180460a38(iVar1, 1, (int64_t)iVar2, *(undefined8 *)(arg1 + 0x2a08));
    }
    return;
}

// ============================================================
// Function: FUN_1801124d4
// Address: 0x1801124d4
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180112470(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if (*(int64_t *)(arg1 + 0x2a08) != 0) {
        fcn.18011f640(in_stack_00000010);
        iVar2 = *(int32_t *)(arg1 + 0x2a10) + -1;
        if (*(int32_t *)(arg1 + 0x2a10) == 0) {
            iVar2 = 0;
        }
        iVar1 = 0x180781edb;
        if (*(int64_t *)(arg1 + 0x2a18) != 0) {
            iVar1 = *(int64_t *)(arg1 + 0x2a18);
        }
        fcn.180460a38(iVar1, 1, (int64_t)iVar2, *(undefined8 *)(arg1 + 0x2a08));
    }
    return;
}

// ============================================================
// Function: FUN_1801124e0
// Address: 0x1801124e0
// Size: 50 bytes
// ============================================================
void fcn.1801124e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if (*(char *)(*(int64_t *)0x180781f28 + 0x29f8) != '\0') {
        fcn.180112470(*(int64_t *)0x180781f28);
    }
    return;
}

// ============================================================
// Function: FUN_180112520
// Address: 0x180112520
// Size: 471 bytes
// ============================================================
void fcn.180112520(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t arg2_00;
    char *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    char *pcVar7;
    unkuint7 Var8;
    int64_t arg2_01;
    char *pcVar9;
    char *pcVar10;
    float fVar11;
    int64_t var_68h;
    int64_t var_58h;
    
    pcVar10 = (char *)arg2;
    iVar6 = arg3;
    do {
        iVar4 = *(int64_t *)0x180781f28;
        arg2_00 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        pcVar2 = *(char **)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar4 + 0x2a20) = 0;
        if (((char *)arg3 == (char *)0x0) && (arg3 = (int64_t)pcVar10, pcVar10 != (char *)0xffffffffffffffff)) {
            while (*(char *)arg3 != '\0') {
                pcVar9 = (char *)(arg3 + 1);
                if (((*(char *)arg3 == '#') && (*pcVar9 == '#')) ||
                   (arg3 = (int64_t)pcVar9, pcVar9 == (char *)0xffffffffffffffff)) break;
            }
        }
        if (arg1 != 0) {
            fVar11 = *(float *)(iVar4 + 0xde0);
            if (*(float *)(iVar4 + 0xde0) <= *(float *)(iVar4 + 0xdf0)) {
                fVar11 = *(float *)(iVar4 + 0xdf0);
            }
            Var8 = (unkuint7)((uint64_t)arg2 >> 8);
            if (*(float *)(arg1 + 4) <= fVar11 + *(float *)(iVar4 + 0x2a30) + 1.0) {
                if (arg1 == 0) goto code_r0x0001801125fc;
                arg2_01 = (uint64_t)Var8 << 8;
            } else {
                arg2_01 = CONCAT71(Var8, 1);
            }
            *(float *)(iVar4 + 0x2a30) = *(float *)(arg1 + 4);
            if ((char)arg2_01 != '\0') {
                fcn.1801124e0(0x180644f68, arg2_01, iVar6, arg4);
                *(undefined *)(iVar4 + 0x29f9) = 1;
            }
        }
code_r0x0001801125fc:
        if (arg2_00 != 0) {
            iVar6 = func_0x000180498cd0(arg2_00);
            fcn.180112520(arg1, arg2_00, iVar6 + arg2_00, arg4);
        }
        iVar1 = *(int32_t *)(iVar3 + 0x1e0);
        iVar5 = *(int32_t *)(iVar4 + 0x2a34);
        if (iVar1 < iVar5) {
            *(int32_t *)(iVar4 + 0x2a34) = iVar1;
            iVar5 = iVar1;
        }
        iVar1 = *(int32_t *)(iVar3 + 0x1e0);
        while( true ) {
            arg2 = 0;
            iVar6 = arg3 - (int64_t)pcVar10;
            pcVar7 = (char *)func_0x000180498a80(pcVar10);
            pcVar9 = (char *)arg3;
            if (pcVar7 != (char *)0x0) {
                pcVar9 = pcVar7;
            }
            if ((pcVar10 == pcVar9) && (pcVar9 == (char *)arg3)) break;
            arg2 = (int64_t)(uint32_t)((iVar1 - iVar5) * 4);
            arg4 = (int64_t)(uint32_t)((int32_t)pcVar9 - (int32_t)pcVar10);
            if (*(char *)(iVar4 + 0x29f9) == '\0') {
                arg2 = 1;
            }
            iVar6 = 0x1805aadb1;
            fcn.1801124e0(0x180644f70, arg2, 0x1805aadb1, arg4);
            *(undefined *)(iVar4 + 0x29f9) = 0;
            if (*pcVar9 == '\n') {
                fcn.1801124e0(0x180644f68, arg2, iVar6, arg4);
                *(undefined *)(iVar4 + 0x29f9) = 1;
            }
            if (pcVar9 == (char *)arg3) break;
            pcVar10 = pcVar9 + 1;
        }
        if (pcVar2 == (char *)0x0) {
            return;
        }
        arg3 = func_0x000180498cd0(pcVar2);
        arg3 = (int64_t)(pcVar2 + arg3);
        pcVar10 = pcVar2;
    } while( true );
}

// ============================================================
// Function: FUN_180112840
// Address: 0x180112840
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180112840(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    char *pcVar3;
    char *pcVar4;
    int64_t iVar5;
    char *pcVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_10h = arg2;
    if (arg2 == 0) {
        var_10h = func_0x000180498cd0();
    }
    fcn.18011f640(unaff_RSI);
    pcVar3 = *(char **)(iVar5 + 0x2938);
    pcVar2 = pcVar3 + var_10h;
    func_0x000180498030(pcVar3, arg1, var_10h);
    *pcVar2 = '\0';
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x18) != (code *)0x0) {
            (**(code **)(iVar10 + 0x18))(iVar5, iVar10);
        }
    }
    iVar9 = 0;
    iVar10 = 0;
    pcVar6 = pcVar3;
    while (pcVar6 < pcVar2) {
        for (; (*pcVar6 == '\n' || (pcVar4 = pcVar6, *pcVar6 == '\r')); pcVar6 = pcVar6 + 1) {
        }
        for (; ((pcVar4 < pcVar2 && (*pcVar4 != '\n')) && (*pcVar4 != '\r')); pcVar4 = pcVar4 + 1) {
        }
        *pcVar4 = '\0';
        if (*pcVar6 != ';') {
            if (((*pcVar6 == '[') && (pcVar6 < pcVar4)) && (pcVar1 = pcVar4 + -1, pcVar4[-1] == ']')) {
                pcVar6 = pcVar6 + 1;
                *pcVar1 = '\0';
                puVar7 = (undefined *)func_0x000180498a80(pcVar6, 0x5d, (int64_t)pcVar1 - (int64_t)pcVar6);
                if ((puVar7 != (undefined *)0x0) &&
                   (iVar8 = func_0x000180498a80(puVar7 + 1, 0x5b, (int64_t)pcVar1 - (int64_t)(puVar7 + 1)), iVar8 != 0))
                {
                    *puVar7 = 0;
                    iVar10 = func_0x0001801127a0(pcVar6);
                    if (iVar10 == 0) {
                        iVar9 = 0;
                    } else {
                        iVar9 = (**(code **)(iVar10 + 0x20))(iVar5, iVar10, iVar8 + 1);
                    }
                }
            } else if ((iVar10 != 0) && (iVar9 != 0)) {
                (**(code **)(iVar10 + 0x28))(iVar5, iVar10, iVar9, pcVar6);
            }
        }
        pcVar6 = pcVar4 + 1;
    }
    *(undefined *)(iVar5 + 0x2928) = 1;
    func_0x000180498030(pcVar3, arg1, var_10h);
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x30) != (code *)0x0) {
            (**(code **)(iVar10 + 0x30))(iVar5, iVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18011285c
// Address: 0x18011285c
// Size: 161 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180112840(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    char *pcVar3;
    char *pcVar4;
    int64_t iVar5;
    char *pcVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_10h = arg2;
    if (arg2 == 0) {
        var_10h = func_0x000180498cd0();
    }
    fcn.18011f640(unaff_RSI);
    pcVar3 = *(char **)(iVar5 + 0x2938);
    pcVar2 = pcVar3 + var_10h;
    func_0x000180498030(pcVar3, arg1, var_10h);
    *pcVar2 = '\0';
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x18) != (code *)0x0) {
            (**(code **)(iVar10 + 0x18))(iVar5, iVar10);
        }
    }
    iVar9 = 0;
    iVar10 = 0;
    pcVar6 = pcVar3;
    while (pcVar6 < pcVar2) {
        for (; (*pcVar6 == '\n' || (pcVar4 = pcVar6, *pcVar6 == '\r')); pcVar6 = pcVar6 + 1) {
        }
        for (; ((pcVar4 < pcVar2 && (*pcVar4 != '\n')) && (*pcVar4 != '\r')); pcVar4 = pcVar4 + 1) {
        }
        *pcVar4 = '\0';
        if (*pcVar6 != ';') {
            if (((*pcVar6 == '[') && (pcVar6 < pcVar4)) && (pcVar1 = pcVar4 + -1, pcVar4[-1] == ']')) {
                pcVar6 = pcVar6 + 1;
                *pcVar1 = '\0';
                puVar7 = (undefined *)func_0x000180498a80(pcVar6, 0x5d, (int64_t)pcVar1 - (int64_t)pcVar6);
                if ((puVar7 != (undefined *)0x0) &&
                   (iVar8 = func_0x000180498a80(puVar7 + 1, 0x5b, (int64_t)pcVar1 - (int64_t)(puVar7 + 1)), iVar8 != 0))
                {
                    *puVar7 = 0;
                    iVar10 = func_0x0001801127a0(pcVar6);
                    if (iVar10 == 0) {
                        iVar9 = 0;
                    } else {
                        iVar9 = (**(code **)(iVar10 + 0x20))(iVar5, iVar10, iVar8 + 1);
                    }
                }
            } else if ((iVar10 != 0) && (iVar9 != 0)) {
                (**(code **)(iVar10 + 0x28))(iVar5, iVar10, iVar9, pcVar6);
            }
        }
        pcVar6 = pcVar4 + 1;
    }
    *(undefined *)(iVar5 + 0x2928) = 1;
    func_0x000180498030(pcVar3, arg1, var_10h);
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x30) != (code *)0x0) {
            (**(code **)(iVar10 + 0x30))(iVar5, iVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801128fd
// Address: 0x1801128fd
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180112840(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    char *pcVar3;
    char *pcVar4;
    int64_t iVar5;
    char *pcVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_10h = arg2;
    if (arg2 == 0) {
        var_10h = func_0x000180498cd0();
    }
    fcn.18011f640(unaff_RSI);
    pcVar3 = *(char **)(iVar5 + 0x2938);
    pcVar2 = pcVar3 + var_10h;
    func_0x000180498030(pcVar3, arg1, var_10h);
    *pcVar2 = '\0';
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x18) != (code *)0x0) {
            (**(code **)(iVar10 + 0x18))(iVar5, iVar10);
        }
    }
    iVar9 = 0;
    iVar10 = 0;
    pcVar6 = pcVar3;
    while (pcVar6 < pcVar2) {
        for (; (*pcVar6 == '\n' || (pcVar4 = pcVar6, *pcVar6 == '\r')); pcVar6 = pcVar6 + 1) {
        }
        for (; ((pcVar4 < pcVar2 && (*pcVar4 != '\n')) && (*pcVar4 != '\r')); pcVar4 = pcVar4 + 1) {
        }
        *pcVar4 = '\0';
        if (*pcVar6 != ';') {
            if (((*pcVar6 == '[') && (pcVar6 < pcVar4)) && (pcVar1 = pcVar4 + -1, pcVar4[-1] == ']')) {
                pcVar6 = pcVar6 + 1;
                *pcVar1 = '\0';
                puVar7 = (undefined *)func_0x000180498a80(pcVar6, 0x5d, (int64_t)pcVar1 - (int64_t)pcVar6);
                if ((puVar7 != (undefined *)0x0) &&
                   (iVar8 = func_0x000180498a80(puVar7 + 1, 0x5b, (int64_t)pcVar1 - (int64_t)(puVar7 + 1)), iVar8 != 0))
                {
                    *puVar7 = 0;
                    iVar10 = func_0x0001801127a0(pcVar6);
                    if (iVar10 == 0) {
                        iVar9 = 0;
                    } else {
                        iVar9 = (**(code **)(iVar10 + 0x20))(iVar5, iVar10, iVar8 + 1);
                    }
                }
            } else if ((iVar10 != 0) && (iVar9 != 0)) {
                (**(code **)(iVar10 + 0x28))(iVar5, iVar10, iVar9, pcVar6);
            }
        }
        pcVar6 = pcVar4 + 1;
    }
    *(undefined *)(iVar5 + 0x2928) = 1;
    func_0x000180498030(pcVar3, arg1, var_10h);
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x30) != (code *)0x0) {
            (**(code **)(iVar10 + 0x30))(iVar5, iVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801129f1
// Address: 0x1801129f1
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180112840(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    char *pcVar3;
    char *pcVar4;
    int64_t iVar5;
    char *pcVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_10h = arg2;
    if (arg2 == 0) {
        var_10h = func_0x000180498cd0();
    }
    fcn.18011f640(unaff_RSI);
    pcVar3 = *(char **)(iVar5 + 0x2938);
    pcVar2 = pcVar3 + var_10h;
    func_0x000180498030(pcVar3, arg1, var_10h);
    *pcVar2 = '\0';
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x18) != (code *)0x0) {
            (**(code **)(iVar10 + 0x18))(iVar5, iVar10);
        }
    }
    iVar9 = 0;
    iVar10 = 0;
    pcVar6 = pcVar3;
    while (pcVar6 < pcVar2) {
        for (; (*pcVar6 == '\n' || (pcVar4 = pcVar6, *pcVar6 == '\r')); pcVar6 = pcVar6 + 1) {
        }
        for (; ((pcVar4 < pcVar2 && (*pcVar4 != '\n')) && (*pcVar4 != '\r')); pcVar4 = pcVar4 + 1) {
        }
        *pcVar4 = '\0';
        if (*pcVar6 != ';') {
            if (((*pcVar6 == '[') && (pcVar6 < pcVar4)) && (pcVar1 = pcVar4 + -1, pcVar4[-1] == ']')) {
                pcVar6 = pcVar6 + 1;
                *pcVar1 = '\0';
                puVar7 = (undefined *)func_0x000180498a80(pcVar6, 0x5d, (int64_t)pcVar1 - (int64_t)pcVar6);
                if ((puVar7 != (undefined *)0x0) &&
                   (iVar8 = func_0x000180498a80(puVar7 + 1, 0x5b, (int64_t)pcVar1 - (int64_t)(puVar7 + 1)), iVar8 != 0))
                {
                    *puVar7 = 0;
                    iVar10 = func_0x0001801127a0(pcVar6);
                    if (iVar10 == 0) {
                        iVar9 = 0;
                    } else {
                        iVar9 = (**(code **)(iVar10 + 0x20))(iVar5, iVar10, iVar8 + 1);
                    }
                }
            } else if ((iVar10 != 0) && (iVar9 != 0)) {
                (**(code **)(iVar10 + 0x28))(iVar5, iVar10, iVar9, pcVar6);
            }
        }
        pcVar6 = pcVar4 + 1;
    }
    *(undefined *)(iVar5 + 0x2928) = 1;
    func_0x000180498030(pcVar3, arg1, var_10h);
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x30) != (code *)0x0) {
            (**(code **)(iVar10 + 0x30))(iVar5, iVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180112a40
// Address: 0x180112a40
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.180112840(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char *pcVar2;
    char *pcVar3;
    char *pcVar4;
    int64_t iVar5;
    char *pcVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_10h = arg2;
    if (arg2 == 0) {
        var_10h = func_0x000180498cd0();
    }
    fcn.18011f640(unaff_RSI);
    pcVar3 = *(char **)(iVar5 + 0x2938);
    pcVar2 = pcVar3 + var_10h;
    func_0x000180498030(pcVar3, arg1, var_10h);
    *pcVar2 = '\0';
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x18) != (code *)0x0) {
            (**(code **)(iVar10 + 0x18))(iVar5, iVar10);
        }
    }
    iVar9 = 0;
    iVar10 = 0;
    pcVar6 = pcVar3;
    while (pcVar6 < pcVar2) {
        for (; (*pcVar6 == '\n' || (pcVar4 = pcVar6, *pcVar6 == '\r')); pcVar6 = pcVar6 + 1) {
        }
        for (; ((pcVar4 < pcVar2 && (*pcVar4 != '\n')) && (*pcVar4 != '\r')); pcVar4 = pcVar4 + 1) {
        }
        *pcVar4 = '\0';
        if (*pcVar6 != ';') {
            if (((*pcVar6 == '[') && (pcVar6 < pcVar4)) && (pcVar1 = pcVar4 + -1, pcVar4[-1] == ']')) {
                pcVar6 = pcVar6 + 1;
                *pcVar1 = '\0';
                puVar7 = (undefined *)func_0x000180498a80(pcVar6, 0x5d, (int64_t)pcVar1 - (int64_t)pcVar6);
                if ((puVar7 != (undefined *)0x0) &&
                   (iVar8 = func_0x000180498a80(puVar7 + 1, 0x5b, (int64_t)pcVar1 - (int64_t)(puVar7 + 1)), iVar8 != 0))
                {
                    *puVar7 = 0;
                    iVar10 = func_0x0001801127a0(pcVar6);
                    if (iVar10 == 0) {
                        iVar9 = 0;
                    } else {
                        iVar9 = (**(code **)(iVar10 + 0x20))(iVar5, iVar10, iVar8 + 1);
                    }
                }
            } else if ((iVar10 != 0) && (iVar9 != 0)) {
                (**(code **)(iVar10 + 0x28))(iVar5, iVar10, iVar9, pcVar6);
            }
        }
        pcVar6 = pcVar4 + 1;
    }
    *(undefined *)(iVar5 + 0x2928) = 1;
    func_0x000180498030(pcVar3, arg1, var_10h);
    iVar10 = *(int64_t *)(iVar5 + 0x2948);
    iVar9 = iVar10 + (int64_t)*(int32_t *)(iVar5 + 0x2940) * 0x48;
    for (; iVar10 != iVar9; iVar10 = iVar10 + 0x48) {
        if (*(code **)(iVar10 + 0x30) != (code *)0x0) {
            (**(code **)(iVar10 + 0x30))(iVar5, iVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180112a70
// Address: 0x180112a70
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180112a70(int64_t arg1, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = 0;
    if (arg1 != 0) {
        var_8h = 0;
        uVar1 = fcn.180112af0(&var_8h);
        iVar2 = fcn.1800f5b50(arg1, 0x180644fc8);
        if (iVar2 != 0) {
            fcn.180460a38(uVar1, 1, var_8h, iVar2);
            fcn.18045ff84(iVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180112a97
// Address: 0x180112a97
// Size: 70 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180112a70(int64_t arg1, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = 0;
    if (arg1 != 0) {
        var_8h = 0;
        uVar1 = fcn.180112af0(&var_8h);
        iVar2 = fcn.1800f5b50(arg1, 0x180644fc8);
        if (iVar2 != 0) {
            fcn.180460a38(uVar1, 1, var_8h, iVar2);
            fcn.18045ff84(iVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180112add
// Address: 0x180112add
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180112a70(int64_t arg1, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = 0;
    if (arg1 != 0) {
        var_8h = 0;
        uVar1 = fcn.180112af0(&var_8h);
        iVar2 = fcn.1800f5b50(arg1, 0x180644fc8);
        if (iVar2 != 0) {
            fcn.180460a38(uVar1, 1, var_8h, iVar2);
            fcn.18045ff84(iVar2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180112af0
// Address: 0x180112af0
// Size: 268 bytes
// ============================================================
int64_t fcn.180112af0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t unaff_RBP;
    
    iVar2 = *(int64_t *)0x180781f28;
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2930);
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) = 0;
    fcn.18011f640(unaff_RBP);
    iVar6 = *(int32_t *)(iVar2 + 0x2934);
    if (*piVar1 == iVar6) {
        iVar7 = *piVar1 + 1;
        if (iVar6 == 0) {
            iVar3 = 8;
        } else {
            iVar3 = iVar6 / 2 + iVar6;
        }
        if (iVar7 < iVar3) {
            iVar7 = iVar3;
        }
        if (iVar6 < iVar7) {
            uVar4 = func_0x00018046d050((int64_t)iVar7);
            if (*(int64_t *)(iVar2 + 0x2938) != 0) {
                func_0x000180498030(uVar4, *(int64_t *)(iVar2 + 0x2938), (int64_t)*piVar1);
                fcn.180460d90(*(undefined8 *)(iVar2 + 0x2938));
            }
            *(undefined8 *)(iVar2 + 0x2938) = uVar4;
            *(int32_t *)(iVar2 + 0x2934) = iVar7;
        }
    }
    *(undefined *)((int64_t)*piVar1 + *(int64_t *)(iVar2 + 0x2938)) = 0;
    *piVar1 = *piVar1 + 1;
    iVar8 = *(int64_t *)(iVar2 + 0x2948);
    iVar5 = iVar8 + (int64_t)*(int32_t *)(iVar2 + 0x2940) * 0x48;
    for (; iVar8 != iVar5; iVar8 = iVar8 + 0x48) {
        (**(code **)(iVar8 + 0x38))(iVar2, iVar8, piVar1);
    }
    if (arg1 != 0) {
        iVar6 = *piVar1 + -1;
        if (*piVar1 == 0) {
            iVar6 = 0;
        }
        *(int64_t *)arg1 = (int64_t)iVar6;
    }
    iVar5 = 0x180781edb;
    if (*(int64_t *)(iVar2 + 0x2938) != 0) {
        iVar5 = *(int64_t *)(iVar2 + 0x2938);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_180112c00
// Address: 0x180112c00
// Size: 227 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined (*) [16] fcn.180112c00(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    char *pcVar4;
    int64_t iVar5;
    char cVar6;
    undefined (*pauVar7) [16];
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_37h;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (*(char *)(*(int64_t *)0x180781f28 + 0xba) == '\0') {
        cVar6 = *(char *)arg1;
        pcVar4 = (char *)(arg1 + 1);
        while (cVar6 != '\0') {
            for (; ((cVar6 == '#' && (*pcVar4 == '#')) && (pcVar4[1] == '#')); pcVar4 = pcVar4 + 1) {
                cVar6 = *pcVar4;
                arg1 = (int64_t)(pcVar4 + 2);
            }
            cVar6 = *pcVar4;
            pcVar4 = pcVar4 + 1;
        }
    }
    iVar5 = func_0x000180498cd0(arg1);
    iVar1 = *(int32_t *)(iVar2 + 0x2950);
    fcn.18011f640(unaff_retaddr);
    *(uint32_t *)((int64_t)iVar1 + *(int64_t *)(iVar2 + 0x2958)) = (int32_t)iVar5 + 0x2cU & 0xfffffffc;
    pauVar7 = (undefined (*) [16])(*(int64_t *)(iVar2 + 0x2958) + 4 + (int64_t)iVar1);
    if (pauVar7 != (undefined (*) [16])0x0) {
        *pauVar7 = ZEXT816(0);
        pauVar7[1] = ZEXT816(0);
        *(undefined4 *)pauVar7[2] = 0;
        *(undefined2 *)(pauVar7[1] + 0xc) = 0xffff;
    }
    uVar3 = func_0x0001800f5a90(arg1, iVar5, 0);
    *(undefined4 *)*pauVar7 = uVar3;
    func_0x000180498030(pauVar7[2] + 4, arg1, iVar5 + 1);
    return pauVar7;
}

// ============================================================
// Function: FUN_180112d50
// Address: 0x180112d50
// Size: 99 bytes
// ============================================================
void fcn.180112d50(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    
    piVar2 = *(int64_t **)(arg1 + 0x1588);
    piVar1 = piVar2 + *(int32_t *)(arg1 + 0x1580);
    for (; piVar2 != piVar1; piVar2 = piVar2 + 1) {
        *(undefined4 *)(*piVar2 + 0x31c) = 0xffffffff;
    }
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        *(undefined8 *)(arg1 + 0x2950) = 0;
        fcn.180460d90();
        *(undefined8 *)(arg1 + 0x2958) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180112dc0
// Address: 0x180112dc0
// Size: 251 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined (*) [16] fcn.180112dc0(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined (*pauVar3) [16];
    undefined *puVar4;
    uint8_t *puVar5;
    undefined (*pauVar6) [16];
    uint32_t uVar7;
    uint64_t uVar8;
    int64_t var_28h;
    int64_t var_1ch;
    
    uVar8 = 0xffffffff;
    uVar7 = 0xffffffff;
    uVar1 = *(uint8_t *)arg3;
    puVar5 = (uint8_t *)(arg3 + 1);
    while (uVar1 != 0) {
        if (((uVar1 == 0x23) && (*puVar5 == 0x23)) && (puVar5[1] == 0x23)) {
            uVar8 = 0xffffffff;
            puVar5 = puVar5 + 2;
        } else {
            uVar8 = (uint64_t)
                    ((uint32_t)(uVar8 >> 8) ^ *(uint32_t *)((uVar8 & 0xff ^ (uint64_t)uVar1) * 4 + 0x180618620));
        }
        uVar7 = (uint32_t)uVar8;
        uVar1 = *puVar5;
        puVar5 = puVar5 + 1;
    }
    uVar7 = ~uVar7;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2958);
    pauVar6 = (undefined (*) [16])0x0;
    if (iVar2 != 0) {
        pauVar6 = (undefined (*) [16])(iVar2 + 4);
    }
    while( true ) {
        if (pauVar6 == (undefined (*) [16])0x0) {
            pauVar6 = (undefined (*) [16])fcn.180112c00(arg3);
            *(uint32_t *)*pauVar6 = uVar7;
            pauVar6[2][0] = 1;
            return pauVar6;
        }
        if ((*(uint32_t *)*pauVar6 == uVar7) && (pauVar6[2][1] == '\0')) break;
        pauVar3 = pauVar6 + -1;
        puVar4 = *pauVar6;
        pauVar6 = (undefined (*) [16])0x0;
        if ((undefined (*) [16])(puVar4 + *(int32_t *)(*pauVar3 + 0xc)) !=
            (undefined (*) [16])((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2950) + 4 + iVar2)) {
            pauVar6 = (undefined (*) [16])(puVar4 + *(int32_t *)(*pauVar3 + 0xc));
        }
    }
    *pauVar6 = ZEXT816(0);
    *(undefined4 *)pauVar6[1] = 0;
    *(undefined4 *)(pauVar6[1] + 4) = 0;
    *(undefined4 *)(pauVar6[1] + 8) = 0;
    *(undefined4 *)(pauVar6[1] + 0xc) = 0xffff;
    *(undefined4 *)pauVar6[2] = 0;
    *(uint32_t *)*pauVar6 = uVar7;
    pauVar6[2][0] = 1;
    return pauVar6;
}

// ============================================================
// Function: FUN_180112ec0
// Address: 0x180112ec0
// Size: 506 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.180112ec0(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    undefined4 auStackX_18 [4];
    undefined2 var_18h [2];
    int64_t var_14h;
    
    iVar1 = fcn.1800f3a40(arg4, 0x180644fd0, var_18h, &var_14h);
    if (iVar1 == 2) {
        *(undefined2 *)(arg3 + 4) = var_18h[0];
        *(undefined2 *)(arg3 + 6) = (undefined2)var_14h;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180644f78, var_18h, &var_14h);
    if (iVar1 == 2) {
        *(undefined2 *)(arg3 + 8) = var_18h[0];
        *(undefined2 *)(arg3 + 10) = (undefined2)var_14h;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180644f88, auStackX_18);
    if (iVar1 == 1) {
        *(undefined4 *)(arg3 + 0x10) = auStackX_18[0];
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180644fa0, var_18h, &var_14h);
    if (iVar1 == 2) {
        *(undefined2 *)(arg3 + 0xc) = var_18h[0];
        *(undefined2 *)(arg3 + 0xe) = (undefined2)var_14h;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180644fb8, (int64_t)&var_14h + 4);
    if (iVar1 == 1) {
        *(bool *)(arg3 + 0x1e) = var_14h._4_4_ != 0;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180645028, (int64_t)&var_14h + 4);
    if (iVar1 == 1) {
        *(bool *)(arg3 + 0x1f) = var_14h._4_4_ != 0;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180645038, auStackX_18, (int64_t)&var_14h + 4);
    if (iVar1 == 2) {
        *(undefined4 *)(arg3 + 0x14) = auStackX_18[0];
        *(undefined2 *)(arg3 + 0x1c) = var_14h._4_2_;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180645048, auStackX_18);
    if (iVar1 == 1) {
        *(undefined4 *)(arg3 + 0x14) = auStackX_18[0];
        *(undefined2 *)(arg3 + 0x1c) = 0xffff;
        return;
    }
    iVar1 = fcn.1800f3a40(arg4, 0x180645058, auStackX_18);
    if (iVar1 == 1) {
        *(undefined4 *)(arg3 + 0x18) = auStackX_18[0];
    }
    return;
}

// ============================================================
// Function: FUN_1801130c0
// Address: 0x1801130c0
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801130c0(int64_t arg1, int64_t arg_38h)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)0x180781f28;
    puVar1 = (undefined4 *)0x0;
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x2958) + 4);
    }
    while (puVar1 != (undefined4 *)0x0) {
        if (*(char *)(puVar1 + 8) != '\0') {
            iVar3 = func_0x0001800f60f0(iVar2 + 0x15c0, *puVar1);
            if (iVar3 != 0) {
                func_0x0001800fed40(iVar3, puVar1);
            }
            *(undefined *)(puVar1 + 8) = 0;
        }
        puVar4 = (undefined4 *)((int64_t)(int32_t)puVar1[-1] + (int64_t)puVar1);
        puVar1 = (undefined4 *)0x0;
        if (puVar4 != (undefined4 *)(*(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950))) {
            puVar1 = puVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801130e6
// Address: 0x1801130e6
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801130c0(int64_t arg1, int64_t arg_38h)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)0x180781f28;
    puVar1 = (undefined4 *)0x0;
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x2958) + 4);
    }
    while (puVar1 != (undefined4 *)0x0) {
        if (*(char *)(puVar1 + 8) != '\0') {
            iVar3 = func_0x0001800f60f0(iVar2 + 0x15c0, *puVar1);
            if (iVar3 != 0) {
                func_0x0001800fed40(iVar3, puVar1);
            }
            *(undefined *)(puVar1 + 8) = 0;
        }
        puVar4 = (undefined4 *)((int64_t)(int32_t)puVar1[-1] + (int64_t)puVar1);
        puVar1 = (undefined4 *)0x0;
        if (puVar4 != (undefined4 *)(*(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950))) {
            puVar1 = puVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180113149
// Address: 0x180113149
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801130c0(int64_t arg1, int64_t arg_38h)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)0x180781f28;
    puVar1 = (undefined4 *)0x0;
    if (*(int64_t *)(arg1 + 0x2958) != 0) {
        puVar1 = (undefined4 *)(*(int64_t *)(arg1 + 0x2958) + 4);
    }
    while (puVar1 != (undefined4 *)0x0) {
        if (*(char *)(puVar1 + 8) != '\0') {
            iVar3 = func_0x0001800f60f0(iVar2 + 0x15c0, *puVar1);
            if (iVar3 != 0) {
                func_0x0001800fed40(iVar3, puVar1);
            }
            *(undefined *)(puVar1 + 8) = 0;
        }
        puVar4 = (undefined4 *)((int64_t)(int32_t)puVar1[-1] + (int64_t)puVar1);
        puVar1 = (undefined4 *)0x0;
        if (puVar4 != (undefined4 *)(*(int64_t *)(arg1 + 0x2958) + 4 + (int64_t)*(int32_t *)(arg1 + 0x2950))) {
            puVar1 = puVar4;
        }
    }
    return;
}

