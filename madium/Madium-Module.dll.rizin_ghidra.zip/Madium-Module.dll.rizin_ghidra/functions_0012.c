// Chunk 12 - 50 functions

// ============================================================
// Function: FUN_18001f220
// Address: 0x18001f220
// Size: 35 bytes
// ============================================================
void fcn.18001f220(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStack_30 [5];
    
    piVar1 = *(int64_t **)arg1;
    *(undefined8 *)piVar1[1] = 0;
    iVar5 = *piVar1;
    if (iVar5 == 0) {
        iVar5 = *(int64_t *)arg1;
    } else {
        auStack_30[0] = 0x18001f25c;
        func_0x000180004e40(iVar5 + 0x10);
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001f269;
        unaff_RBX = iVar5;
    }
    if (iVar5 != 0) {
        *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)func_0x00018046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001f243
// Address: 0x18001f243
// Size: 51 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001f264: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001f269)
// WARNING: Removing unreachable block (ram,0x00018001f271)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001f220(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStack_30 [5];
    
    piVar1 = *(int64_t **)arg1;
    *(undefined8 *)piVar1[1] = 0;
    iVar5 = *piVar1;
    if (iVar5 == 0) {
        iVar5 = *(int64_t *)arg1;
    } else {
        auStack_30[0] = 0x18001f25c;
        func_0x000180004e40(iVar5 + 0x10);
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001f269;
        unaff_RBX = iVar5;
    }
    if (iVar5 != 0) {
        *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)func_0x00018046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001f276
// Address: 0x18001f276
// Size: 23 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018001f264: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018001f269)
// WARNING: Removing unreachable block (ram,0x00018001f271)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001f220(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStack_30 [5];
    
    piVar1 = *(int64_t **)arg1;
    *(undefined8 *)piVar1[1] = 0;
    iVar5 = *piVar1;
    if (iVar5 == 0) {
        iVar5 = *(int64_t *)arg1;
    } else {
        auStack_30[0] = 0x18001f25c;
        func_0x000180004e40(iVar5 + 0x10);
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x18001f269;
        unaff_RBX = iVar5;
    }
    if (iVar5 != 0) {
        *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)func_0x00018046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18001f290
// Address: 0x18001f290
// Size: 35 bytes
// ============================================================
void fcn.18001f290(int64_t arg1)
{
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    func_0x00018001fa20(arg1, *(undefined8 *)arg1);
    if ((*(int64_t *)arg1 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *(int64_t *)arg1, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = func_0x00018046b63c(uVar3);
        puVar1 = (undefined4 *)func_0x00018046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18001f2c0
// Address: 0x18001f2c0
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18001f2c0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined4 *)0x180782810 = 0;
    *(undefined8 *)0x180782818 = 0;
    *(undefined8 *)0x180782820 = 0;
    *(int64_t *)0x180782818 = fcn.180459890(0x70);
    *(int64_t *)*(int64_t *)0x180782818 = *(int64_t *)0x180782818;
    *(int64_t *)(*(int64_t *)0x180782818 + 8) = *(int64_t *)0x180782818;
    *(undefined8 *)0x180782828 = 0;
    *(undefined (*) [16])0x180782830 = ZEXT816(0);
    *(undefined8 *)0x180782840 = 7;
    *(undefined8 *)0x180782848 = 8;
    *(undefined4 *)0x180782810 = 0x3f800000;
    uVar1 = fcn.18000f7e0(0x180782828, 0x10, *(int64_t *)0x180782818);
    fcn.18001fa90(uVar1, *(undefined8 *)arg2, *(undefined8 *)(arg2 + 8));
    return 0x180782810;
}

// ============================================================
// Function: FUN_18001f380
// Address: 0x18001f380
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18001f380(int64_t arg1, int64_t arg2)
{
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_18h._0_4_ = 0;
    fcn.18001f430(arg1, &var_18h, &var_10h);
    fcn.18001f7a0(unaff_RDI);
    return arg1;
}

// ============================================================
// Function: FUN_18001f3d0
// Address: 0x18001f3d0
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18001f3d0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    iVar2 = arg2;
    if ((uint64_t)arg4 < (uint64_t)arg2) {
        iVar2 = arg4;
    }
    uVar1 = fcn.180497f30(placeholder_0, arg3, iVar2);
    if ((int32_t)uVar1 == 0) {
        if ((uint64_t)arg2 < (uint64_t)arg4) {
            return 0xffffffff;
        }
        uVar1 = (uint64_t)((uint64_t)arg4 < (uint64_t)arg2);
    }
    return uVar1;
}

// ============================================================
// Function: FUN_18001f430
// Address: 0x18001f430
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18001f430(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined4 *)arg1 = *(undefined4 *)arg2;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    iVar1 = fcn.180459890(0x30);
    *(int64_t *)iVar1 = iVar1;
    *(int64_t *)(iVar1 + 8) = iVar1;
    *(int64_t *)(arg1 + 8) = iVar1;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 7;
    *(undefined8 *)(arg1 + 0x38) = 8;
    *(undefined4 *)arg1 = 0x3f800000;
    fcn.18000f7e0((undefined8 *)(arg1 + 0x18), 0x10, *(undefined8 *)(arg1 + 8));
    return arg1;
}

// ============================================================
// Function: FUN_18001f4b0
// Address: 0x18001f4b0
// Size: 746 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18001f4b0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t iVar5;
    code *pcVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    undefined8 *puVar13;
    int64_t *piVar14;
    uint64_t uVar15;
    float fVar16;
    float fVar17;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    *(undefined4 *)arg1 = *(undefined4 *)arg2;
    piVar9 = (int64_t *)(arg1 + 8);
    *piVar9 = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    iVar8 = fcn.180459890(0x30);
    *(int64_t *)iVar8 = iVar8;
    *(int64_t *)(iVar8 + 8) = iVar8;
    *piVar9 = iVar8;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg2 + 0x30);
    *(undefined8 *)(arg1 + 0x38) = *(undefined8 *)(arg2 + 0x38);
    fcn.18000f7e0((undefined8 *)(arg1 + 0x18), *(int64_t *)(arg2 + 0x20) - *(int64_t *)(arg2 + 0x18) >> 3, *piVar9);
    puVar1 = *(undefined8 **)(arg2 + 8);
    puVar2 = (undefined8 *)*puVar1;
    do {
        if (puVar2 == puVar1) {
            return arg1;
        }
        uVar11 = 0;
        if ((uint64_t)puVar2[5] < 0x10) {
            puVar13 = puVar2 + 2;
        } else {
            puVar13 = (undefined8 *)puVar2[2];
        }
        uVar15 = 0xcbf29ce484222325;
        if (puVar2[4] != 0) {
            do {
                uVar15 = (uVar15 ^ *(uint8_t *)((int64_t)puVar13 + uVar11)) * 0x100000001b3;
                uVar11 = uVar11 + 1;
            } while (uVar11 < (uint64_t)puVar2[4]);
        }
        func_0x00018001fd20(arg1, &var_58h, puVar2 + 2, uVar15);
        if (var_50h == 0) {
            if (*(int64_t *)(arg1 + 0x10) == 0x555555555555555) {
                func_0x0001804546d4(0x180620428);
                pcVar6 = (code *)swi(3);
                iVar8 = (*pcVar6)();
                return iVar8;
            }
            var_40h = 0;
            var_48h = (int64_t)(int64_t **)(arg1 + 8);
            piVar9 = (int64_t *)fcn.180459890(0x30);
            var_40h = (int64_t)piVar9;
            func_0x00018000b4d0(piVar9 + 2, puVar2 + 2);
            uVar11 = *(int64_t *)(arg1 + 0x10) + 1;
            if ((int64_t)uVar11 < 0) {
                fVar16 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
                fVar16 = fVar16 + fVar16;
            } else {
                fVar16 = (float)uVar11;
            }
            uVar11 = *(uint64_t *)(arg1 + 0x38);
            if ((int64_t)uVar11 < 0) {
                fVar17 = (float)(uVar11 >> 1 | (uint64_t)((uint32_t)uVar11 & 1));
                fVar17 = fVar17 + fVar17;
            } else {
                fVar17 = (float)uVar11;
            }
            if (*(float *)arg1 <= fVar16 / fVar17 && fVar16 / fVar17 != *(float *)arg1) {
                func_0x00018001ffd0(arg1);
                uVar11 = uVar15 & *(uint64_t *)(arg1 + 0x30);
                piVar14 = *(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8 + uVar11 * 0x10);
                piVar10 = *(int64_t **)(arg1 + 8);
                if (piVar14 != piVar10) {
                    piVar3 = *(int64_t **)(*(int64_t *)(arg1 + 0x18) + uVar11 * 0x10);
                    iVar8 = piVar9[4];
                    piVar10 = piVar14;
                    while( true ) {
                        piVar14 = piVar10 + 2;
                        if (0xf < (uint64_t)piVar10[5]) {
                            piVar14 = (int64_t *)*piVar14;
                        }
                        if ((uint64_t)piVar9[5] < 0x10) {
                            piVar12 = piVar9 + 2;
                        } else {
                            piVar12 = (int64_t *)piVar9[2];
                        }
                        if ((iVar8 == piVar10[4]) &&
                           ((iVar8 == 0 || (iVar7 = fcn.180497f30(piVar12, piVar14, iVar8), iVar7 == 0)))) {
                            var_58h = *piVar10;
                            var_50h = (int64_t)piVar10;
                            goto code_r0x00018001f70a;
                        }
                        if (piVar10 == piVar3) break;
                        piVar10 = (int64_t *)piVar10[1];
                    }
                }
                var_50h = 0;
                var_58h = (int64_t)piVar10;
            }
code_r0x00018001f70a:
            var_40h = 0;
            ppiVar4 = *(int64_t ***)(var_58h + 8);
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            *piVar9 = var_58h;
            piVar9[1] = (int64_t)ppiVar4;
            *ppiVar4 = piVar9;
            *(int64_t **)(var_58h + 8) = piVar9;
            iVar8 = *(int64_t *)(arg1 + 0x18);
            uVar15 = uVar15 & *(uint64_t *)(arg1 + 0x30);
            iVar5 = *(int64_t *)(iVar8 + uVar15 * 0x10);
            if (iVar5 == *(int64_t *)(arg1 + 8)) {
                *(int64_t **)(iVar8 + uVar15 * 0x10) = piVar9;
code_r0x00018001f757:
                *(int64_t **)(iVar8 + 8 + uVar15 * 0x10) = piVar9;
            } else if (iVar5 == var_58h) {
                *(int64_t **)(iVar8 + uVar15 * 0x10) = piVar9;
            } else if (*(int64_t ***)(iVar8 + 8 + uVar15 * 0x10) == ppiVar4) goto code_r0x00018001f757;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18001f7a0
// Address: 0x18001f7a0
// Size: 634 bytes
// ============================================================
void fcn.18001f7a0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    undefined8 *puVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    float fVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    if (arg2 != arg3) {
        do {
            puVar10 = (undefined8 *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                puVar10 = *(undefined8 **)arg2;
            }
            uVar13 = 0xcbf29ce484222325;
            uVar8 = 0;
            if (*(uint64_t *)(arg2 + 0x10) != 0) {
                do {
                    uVar13 = (uVar13 ^ *(uint8_t *)((int64_t)puVar10 + uVar8)) * 0x100000001b3;
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(arg2 + 0x10));
            }
            func_0x00018001fd20(arg1, &var_68h, arg2, uVar13);
            if (var_60h == 0) {
                if (*(int64_t *)(arg1 + 0x10) == 0x555555555555555) {
                    func_0x0001804546d4(0x180620428);
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
                var_50h = 0;
                var_58h = (int64_t)(int64_t **)(arg1 + 8);
                piVar7 = (int64_t *)fcn.180459890(0x30);
                var_50h = (int64_t)piVar7;
                func_0x00018000b4d0(piVar7 + 2, arg2);
                uVar8 = *(int64_t *)(arg1 + 0x10) + 1;
                if ((int64_t)uVar8 < 0) {
                    fVar14 = (float)(uVar8 >> 1 | (uint64_t)((uint32_t)uVar8 & 1));
                    fVar14 = fVar14 + fVar14;
                } else {
                    fVar14 = (float)uVar8;
                }
                uVar8 = *(uint64_t *)(arg1 + 0x38);
                if ((int64_t)uVar8 < 0) {
                    fVar15 = (float)(uVar8 >> 1 | (uint64_t)((uint32_t)uVar8 & 1));
                    fVar15 = fVar15 + fVar15;
                } else {
                    fVar15 = (float)uVar8;
                }
                if (*(float *)arg1 <= fVar14 / fVar15 && fVar14 / fVar15 != *(float *)arg1) {
                    func_0x00018001ffd0(arg1);
                    uVar8 = uVar13 & *(uint64_t *)(arg1 + 0x30);
                    piVar11 = *(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8 + uVar8 * 0x10);
                    piVar12 = *(int64_t **)(arg1 + 8);
                    if (piVar11 != piVar12) {
                        piVar1 = *(int64_t **)(*(int64_t *)(arg1 + 0x18) + uVar8 * 0x10);
                        iVar2 = piVar7[4];
                        piVar12 = piVar11;
                        while( true ) {
                            piVar11 = piVar12 + 2;
                            if (0xf < (uint64_t)piVar12[5]) {
                                piVar11 = (int64_t *)*piVar11;
                            }
                            if ((uint64_t)piVar7[5] < 0x10) {
                                piVar9 = piVar7 + 2;
                            } else {
                                piVar9 = (int64_t *)piVar7[2];
                            }
                            if ((iVar2 == piVar12[4]) &&
                               ((iVar2 == 0 || (iVar6 = fcn.180497f30(piVar9, piVar11, iVar2), iVar6 == 0)))) {
                                var_68h = *piVar12;
                                var_60h = (int64_t)piVar12;
                                goto code_r0x00018001f991;
                            }
                            if (piVar12 == piVar1) break;
                            piVar12 = (int64_t *)piVar12[1];
                        }
                    }
                    var_60h = 0;
                    var_68h = (int64_t)piVar12;
                }
code_r0x00018001f991:
                var_50h = 0;
                ppiVar3 = *(int64_t ***)(var_68h + 8);
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
                *piVar7 = var_68h;
                piVar7[1] = (int64_t)ppiVar3;
                *ppiVar3 = piVar7;
                *(int64_t **)(var_68h + 8) = piVar7;
                iVar2 = *(int64_t *)(arg1 + 0x18);
                uVar13 = *(uint64_t *)(arg1 + 0x30) & uVar13;
                iVar4 = *(int64_t *)(iVar2 + uVar13 * 0x10);
                if (iVar4 == *(int64_t *)(arg1 + 8)) {
                    *(int64_t **)(iVar2 + uVar13 * 0x10) = piVar7;
code_r0x00018001f9e0:
                    *(int64_t **)(iVar2 + 8 + uVar13 * 0x10) = piVar7;
                } else if (iVar4 == var_68h) {
                    *(int64_t **)(iVar2 + uVar13 * 0x10) = piVar7;
                } else if (*(int64_t ***)(iVar2 + 8 + uVar13 * 0x10) == ppiVar3) goto code_r0x00018001f9e0;
            }
            arg2 = arg2 + 0x20;
        } while (arg2 != arg3);
    }
    return;
}

// ============================================================
// Function: FUN_18001fa20
// Address: 0x18001fa20
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18001fa20(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar2 = *(undefined8 **)arg2;
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)*puVar2;
        fcn.18000ace0(puVar2 + 9);
        fcn.18001f220((int64_t)(puVar2 + 7), unaff_RSI);
        fcn.180004e40(puVar2 + 2);
        fcn.180459c3c(puVar2, 0x70);
        puVar2 = puVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18001fa39
// Address: 0x18001fa39
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18001fa20(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar2 = *(undefined8 **)arg2;
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)*puVar2;
        fcn.18000ace0(puVar2 + 9);
        fcn.18001f220((int64_t)(puVar2 + 7), unaff_RSI);
        fcn.180004e40(puVar2 + 2);
        fcn.180459c3c(puVar2, 0x70);
        puVar2 = puVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18001fa80
// Address: 0x18001fa80
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18001fa20(undefined8 placeholder_0, int64_t arg2, int64_t arg_38h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    
    **(undefined8 **)(arg2 + 8) = 0;
    puVar2 = *(undefined8 **)arg2;
    while (puVar2 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)*puVar2;
        fcn.18000ace0(puVar2 + 9);
        fcn.18001f220((int64_t)(puVar2 + 7), unaff_RSI);
        fcn.180004e40(puVar2 + 2);
        fcn.180459c3c(puVar2, 0x70);
        puVar2 = puVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18001fa90
// Address: 0x18001fa90
// Size: 656 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h

void fcn.18001fa90(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t **ppiVar1;
    code *pcVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    undefined4 *puVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    float fVar13;
    undefined4 uVar14;
    float fVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    if (arg2 != arg3) {
        do {
            puVar10 = (undefined8 *)arg2;
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                puVar10 = *(undefined8 **)arg2;
            }
            uVar11 = 0xcbf29ce484222325;
            uVar8 = 0;
            if (*(uint64_t *)(arg2 + 0x10) != 0) {
                do {
                    uVar11 = (uVar11 ^ *(uint8_t *)((int64_t)puVar10 + uVar8)) * 0x100000001b3;
                    uVar8 = uVar8 + 1;
                } while (uVar8 < *(uint64_t *)(arg2 + 0x10));
            }
            func_0x00018001fdf0(uVar8, &var_78h, arg2, uVar11);
            if (CONCAT44(var_70h._4_4_, (undefined4)var_70h) == 0) {
                if (*(int64_t *)0x180782820 == 0x249249249249249) {
                    func_0x0001804546d4(0x180620428);
                    pcVar2 = (code *)swi(3);
                    (*pcVar2)();
                    return;
                }
                piVar6 = (int64_t *)fcn.180459890(0x70);
                func_0x00018000b4d0(piVar6 + 2, arg2);
                fcn.18001f4b0((int64_t)(piVar6 + 6), (int64_t)(arg2 + 0x20));
                uVar5 = *(uint64_t *)0x180782848;
                uVar8 = *(int64_t *)0x180782820 + 1;
                if ((int64_t)uVar8 < 0) {
                    fVar13 = (float)(uVar8 >> 1 | (uint64_t)((uint32_t)uVar8 & 1));
                    fVar13 = fVar13 + fVar13;
                } else {
                    fVar13 = (float)uVar8;
                }
                if ((int64_t)*(uint64_t *)0x180782848 < 0) {
                    fVar15 = (float)(*(uint64_t *)0x180782848 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x180782848 & 1))
                    ;
                    fVar15 = fVar15 + fVar15;
                } else {
                    fVar15 = (float)*(uint64_t *)0x180782848;
                }
                if (*(float *)0x180782810 < fVar13 / fVar15) {
                    fVar13 = (float)func_0x000180471c90(fVar13 / *(float *)0x180782810, fVar13 / fVar15, 
                                                        *(int64_t *)0x180782820, *(float *)0x180782810, 0x180782818, 
                                                        piVar6);
                    iVar9 = 0;
                    if ((9.223372e+18 <= fVar13) && (fVar13 = fVar13 - 9.223372e+18, fVar13 < 9.223372e+18)) {
                        iVar9 = -0x8000000000000000;
                    }
                    uVar8 = 8;
                    if (8 < (uint64_t)((int64_t)fVar13 + iVar9)) {
                        uVar8 = (int64_t)fVar13 + iVar9;
                    }
                    uVar12 = uVar5;
                    if ((uVar5 < uVar8) && ((0x1ff < uVar5 || (uVar12 = uVar5 * 8, uVar5 * 8 < uVar8)))) {
                        uVar12 = uVar8;
                    }
                    uVar14 = func_0x000180020360(uVar8, uVar12);
                    puVar7 = (undefined4 *)func_0x00018001fdf0(uVar14, &var_68h, piVar6 + 2, uVar11);
                    var_78h._0_4_ = *puVar7;
                    var_78h._4_4_ = puVar7[1];
                    var_70h._0_4_ = puVar7[2];
                    var_70h._4_4_ = puVar7[3];
                }
                iVar3 = CONCAT44(var_78h._4_4_, (undefined4)var_78h);
                ppiVar1 = *(int64_t ***)(iVar3 + 8);
                *(int64_t *)0x180782820 = *(int64_t *)0x180782820 + 1;
                *piVar6 = iVar3;
                piVar6[1] = (int64_t)ppiVar1;
                *ppiVar1 = piVar6;
                *(int64_t **)(iVar3 + 8) = piVar6;
                iVar4 = *(int64_t *)0x180782828;
                uVar11 = uVar11 & *(uint64_t *)0x180782840;
                iVar9 = *(int64_t *)(*(int64_t *)0x180782828 + uVar11 * 0x10);
                if (iVar9 == *(int64_t *)0x180782818) {
                    *(int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10) = piVar6;
code_r0x00018001fcda:
                    *(int64_t **)(iVar4 + 8 + uVar11 * 0x10) = piVar6;
                } else if (iVar9 == iVar3) {
                    *(int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10) = piVar6;
                } else if (*(int64_t ***)(*(int64_t *)0x180782828 + 8 + uVar11 * 0x10) == ppiVar1)
                goto code_r0x00018001fcda;
            }
            arg2 = arg2 + 0x60;
        } while (arg2 != arg3);
    }
    return;
}

// ============================================================
// Function: FUN_18001fd20
// Address: 0x18001fd20
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18001fd20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = (int64_t *)((*(uint64_t *)(arg1 + 0x30) & arg4) * 0x10 + *(int64_t *)(arg1 + 0x18));
    puVar7 = (undefined8 *)piVar6[1];
    if (puVar7 == *(undefined8 **)(arg1 + 8)) {
        *(undefined8 **)arg2 = *(undefined8 **)(arg1 + 8);
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    puVar1 = (undefined8 *)*piVar6;
    iVar2 = *(int64_t *)(arg3 + 0x10);
    uVar3 = *(uint64_t *)(arg3 + 0x18);
    while( true ) {
        piVar6 = puVar7 + 2;
        if (0xf < (uint64_t)puVar7[5]) {
            piVar6 = (int64_t *)*piVar6;
        }
        iVar5 = arg3;
        if (0xf < uVar3) {
            iVar5 = *(int64_t *)arg3;
        }
        if ((iVar2 == puVar7[4]) && ((iVar2 == 0 || (iVar4 = fcn.180497f30(iVar5, piVar6, iVar2), iVar4 == 0)))) break;
        if (puVar7 == puVar1) {
            *(undefined8 **)arg2 = puVar7;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        puVar7 = (undefined8 *)puVar7[1];
    }
    *(undefined8 *)arg2 = *puVar7;
    *(undefined8 **)(arg2 + 8) = puVar7;
    return arg2;
}

// ============================================================
// Function: FUN_18001fdf0
// Address: 0x18001fdf0
// Size: 213 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18001fdf0(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar6 = (int64_t *)((*(uint64_t *)0x180782840 & arg4) * 0x10 + *(int64_t *)0x180782828);
    puVar7 = (undefined8 *)piVar6[1];
    if (puVar7 == *(undefined8 **)0x180782818) {
        *(undefined8 **)arg2 = *(undefined8 **)0x180782818;
        *(undefined8 *)(arg2 + 8) = 0;
        return arg2;
    }
    puVar1 = (undefined8 *)*piVar6;
    iVar2 = *(int64_t *)(arg3 + 0x10);
    uVar3 = *(uint64_t *)(arg3 + 0x18);
    while( true ) {
        piVar6 = puVar7 + 2;
        if (0xf < (uint64_t)puVar7[5]) {
            piVar6 = (int64_t *)*piVar6;
        }
        iVar5 = arg3;
        if (0xf < uVar3) {
            iVar5 = *(int64_t *)arg3;
        }
        if ((iVar2 == puVar7[4]) && ((iVar2 == 0 || (iVar4 = fcn.180497f30(iVar5, piVar6, iVar2), iVar4 == 0)))) break;
        if (puVar7 == puVar1) {
            *(undefined8 **)arg2 = puVar7;
            *(undefined8 *)(arg2 + 8) = 0;
            return arg2;
        }
        puVar7 = (undefined8 *)puVar7[1];
    }
    *(undefined8 *)arg2 = *puVar7;
    *(undefined8 **)(arg2 + 8) = puVar7;
    return arg2;
}

// ============================================================
// Function: FUN_18001fed0
// Address: 0x18001fed0
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18001fed0(int64_t arg1)
{
    int64_t iVar1;
    int64_t unaff_RBX;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    if (iVar1 != 0) {
        fcn.18000ace0(iVar1 + 0x48);
        fcn.18001f220(iVar1 + 0x38, unaff_RBX);
        fcn.180004e40(iVar1 + 0x10);
    }
    if (*(int64_t *)(arg1 + 8) != 0) {
        fcn.180459c3c(*(int64_t *)(arg1 + 8), 0x70);
    }
    return;
}

// ============================================================
// Function: FUN_18001ff20
// Address: 0x18001ff20
// Size: 57 bytes
// ============================================================
void fcn.18001ff20(int64_t arg1)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    if (*(int64_t *)(arg1 + 8) != 0) {
        fcn.180004e40(*(int64_t *)(arg1 + 8) + 0x10);
    }
    iVar1 = *(int64_t *)(arg1 + 8);
    if (iVar1 == 0) {
        return;
    }
    if ((iVar1 != 0) &&
       (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar1, in_R9, unaff_RBX), iVar3 == 0)) {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = func_0x00018046b63c(uVar4);
        puVar2 = (undefined4 *)func_0x00018046b77c();
        *puVar2 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_18001ff60
// Address: 0x18001ff60
// Size: 112 bytes
// ============================================================
uint64_t fcn.18001ff60(undefined8 placeholder_0, int64_t arg2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    
    if ((uint64_t)arg2 < 0x555555555555556) {
        uVar5 = arg2 * 0x30;
        if (uVar5 == 0) {
            return 0;
        }
        if (uVar5 < 0x1000) {
            do {
                uVar4 = fcn.18046d050(uVar5);
                if (uVar4 != 0) {
                    return uVar4;
                }
                iVar2 = fcn.18047a460(uVar5);
            } while (iVar2 != 0);
            if (uVar5 == 0xffffffffffffffff) {
                fcn.180004720();
                pcVar1 = (code *)swi(3);
                uVar5 = (*pcVar1)();
                return uVar5;
            }
            fcn.180454670();
            pcVar1 = (code *)swi(3);
            uVar5 = (*pcVar1)();
            return uVar5;
        }
        if (uVar5 < uVar5 + 0x27) {
            iVar3 = fcn.180459890(uVar5 + 0x27);
            iVar6 = iVar3;
            if (iVar3 == 0) {
                iVar6 = 5;
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)();
            }
            uVar5 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar6;
            return uVar5;
        }
    }
    fcn.180004720();
    pcVar1 = (code *)swi(3);
    uVar5 = (*pcVar1)();
    return uVar5;
}

// ============================================================
// Function: FUN_18001ffd0
// Address: 0x18001ffd0
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_1800200c0
// Address: 0x1800200c0
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_1800200f0
// Address: 0x1800200f0
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18002014a
// Address: 0x18002014a
// Size: 447 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_180020309
// Address: 0x180020309
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_180020325
// Address: 0x180020325
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_18002034b
// Address: 0x18002034b
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.18001ffd0(int64_t arg1, int64_t arg_30h)
{
    uint8_t *puVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    code *pcVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *piVar13;
    int64_t **ppiVar14;
    uint64_t uVar15;
    int64_t **ppiVar16;
    uint64_t uVar17;
    int64_t **ppiVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar15 = *(int64_t *)(arg1 + 0x10) + 1;
    uVar11 = *(uint64_t *)(arg1 + 0x38);
    if ((int64_t)uVar15 < 0) {
        fVar19 = (float)(uVar15 >> 1 | (uint64_t)((uint32_t)uVar15 & 1));
        fVar19 = fVar19 + fVar19;
    } else {
        fVar19 = (float)uVar15;
    }
    fVar19 = (float)func_0x000180471c90(fVar19 / *(float *)arg1);
    iVar12 = 0;
    if ((9.223372e+18 <= fVar19) && (fVar19 = fVar19 - 9.223372e+18, fVar19 < 9.223372e+18)) {
        iVar12 = -0x8000000000000000;
    }
    uVar15 = 8;
    if (8 < (uint64_t)((int64_t)fVar19 + iVar12)) {
        uVar15 = (int64_t)fVar19 + iVar12;
    }
    uVar17 = uVar11;
    if ((uVar11 < uVar15) && ((0x1ff < uVar11 || (uVar17 = uVar11 * 8, uVar11 * 8 < uVar15)))) {
        uVar17 = uVar15;
    }
    for (iVar12 = 0x3f; 0xfffffffffffffffU >> iVar12 == 0; iVar12 = iVar12 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar12 & 0x3f)) < uVar17) {
        func_0x0001804546d4(0x180620448);
        pcVar8 = (code *)swi(3);
        (*pcVar8)();
        return;
    }
    ppiVar2 = *(int64_t ***)(arg1 + 8);
    uVar11 = uVar17 - 1 | 1;
    iVar12 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar12 == 0; iVar12 = iVar12 + -1) {
        }
    }
    iVar12 = 1LL << ((char)iVar12 + 1U & 0x3f);
    fcn.18000f7e0(arg1 + 0x18, iVar12 * 2, ppiVar2);
    *(int64_t *)(arg1 + 0x38) = iVar12;
    *(int64_t *)(arg1 + 0x30) = iVar12 + -1;
    ppiVar9 = (int64_t **)**(undefined8 **)(arg1 + 8);
joined_r0x000180020144:
    do {
        while( true ) {
            if (ppiVar9 == ppiVar2) {
                return;
            }
            piVar3 = ppiVar9[5];
            ppiVar18 = ppiVar9 + 2;
            ppiVar4 = (int64_t **)*ppiVar9;
            piVar5 = ppiVar9[4];
            if ((int64_t *)0xf < piVar3) {
                ppiVar18 = (int64_t **)ppiVar9[2];
            }
            piVar13 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar5 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar18 + (int64_t)piVar13);
                    piVar13 = (int64_t *)((int64_t)piVar13 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar13 < piVar5);
            }
            iVar12 = *(int64_t *)(arg1 + 0x18);
            uVar11 = *(uint64_t *)(arg1 + 0x30) & uVar11;
            ppiVar6 = *(int64_t ***)(iVar12 + uVar11 * 0x10);
            ppiVar18 = (int64_t **)(iVar12 + uVar11 * 0x10);
            iVar12 = iVar12 + uVar11 * 0x10;
            if (ppiVar6 != ppiVar2) break;
            *ppiVar18 = (int64_t *)ppiVar9;
            *(int64_t ***)(iVar12 + 8) = ppiVar9;
            ppiVar9 = ppiVar4;
        }
        ppiVar7 = *(int64_t ***)(iVar12 + 8);
        ppiVar16 = ppiVar7 + 2;
        if ((int64_t *)0xf < ppiVar7[5]) {
            ppiVar16 = (int64_t **)*ppiVar16;
        }
        ppiVar14 = ppiVar9 + 2;
        if ((int64_t *)0xf < piVar3) {
            ppiVar14 = (int64_t **)ppiVar9[2];
        }
        if (piVar5 != ppiVar7[4]) {
joined_r0x00018002025a:
            while (ppiVar6 != ppiVar7) {
                ppiVar7 = (int64_t **)ppiVar7[1];
                ppiVar16 = ppiVar7 + 2;
                if ((int64_t *)0xf < ppiVar7[5]) {
                    ppiVar16 = (int64_t **)*ppiVar16;
                }
                if (piVar3 < (int64_t *)0x10) {
                    ppiVar14 = ppiVar9 + 2;
                } else {
                    ppiVar14 = (int64_t **)ppiVar9[2];
                }
                if (piVar5 == ppiVar7[4]) {
                    if ((piVar5 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 == 0))
                    {
                        piVar3 = *ppiVar7;
                        piVar5 = ppiVar9[1];
                        *piVar5 = (int64_t)ppiVar4;
                        ppiVar18 = (int64_t **)ppiVar4[1];
                        *ppiVar18 = piVar3;
                        piVar13 = (int64_t *)piVar3[1];
                        *piVar13 = (int64_t)ppiVar9;
                        piVar3[1] = (int64_t)ppiVar18;
                        ppiVar4[1] = piVar5;
                        ppiVar9[1] = piVar13;
                        ppiVar9 = ppiVar4;
                        goto joined_r0x000180020144;
                    }
                    piVar3 = ppiVar9[5];
                }
            }
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar6 = (int64_t **)ppiVar4[1];
            *ppiVar6 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar6;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
            *ppiVar18 = (int64_t *)ppiVar9;
            ppiVar9 = ppiVar4;
            goto joined_r0x000180020144;
        }
        if ((piVar5 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar14, ppiVar16, piVar5), iVar10 != 0)) {
            piVar3 = ppiVar9[5];
            goto joined_r0x00018002025a;
        }
        ppiVar7 = (int64_t **)*ppiVar7;
        if (ppiVar7 != ppiVar9) {
            piVar3 = ppiVar9[1];
            *piVar3 = (int64_t)ppiVar4;
            ppiVar18 = (int64_t **)ppiVar4[1];
            *ppiVar18 = (int64_t *)ppiVar7;
            piVar5 = ppiVar7[1];
            *piVar5 = (int64_t)ppiVar9;
            ppiVar7[1] = (int64_t *)ppiVar18;
            ppiVar4[1] = piVar3;
            ppiVar9[1] = piVar5;
        }
        *(int64_t ***)(iVar12 + 8) = ppiVar9;
        ppiVar9 = ppiVar4;
    } while( true );
}

// ============================================================
// Function: FUN_180020360
// Address: 0x180020360
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180020360(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar9 = *(int64_t ***)0x180782818;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar11 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    fcn.18000f7e0(0x180782828, iVar15 * 2, *(int64_t ***)0x180782818);
    *(uint64_t *)0x180782840 = iVar15 - 1;
    *(int64_t *)0x180782848 = iVar15;
    ppiVar8 = (int64_t **)**(int64_t ***)0x180782818;
joined_r0x0001800203e6:
    do {
        while( true ) {
            if (ppiVar8 == ppiVar9) {
                return;
            }
            piVar2 = ppiVar8[5];
            ppiVar16 = ppiVar8 + 2;
            ppiVar3 = (int64_t **)*ppiVar8;
            piVar4 = ppiVar8[4];
            if ((int64_t *)0xf < piVar2) {
                ppiVar16 = (int64_t **)ppiVar8[2];
            }
            piVar14 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar4 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar16 + (int64_t)piVar14);
                    piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar14 < piVar4);
            }
            uVar11 = uVar11 & *(uint64_t *)0x180782840;
            ppiVar5 = *(int64_t ***)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            ppiVar16 = (int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            iVar15 = *(int64_t *)0x180782828 + uVar11 * 0x10;
            if (ppiVar5 != ppiVar9) break;
            *ppiVar16 = (int64_t *)ppiVar8;
            *(int64_t ***)(iVar15 + 8) = ppiVar8;
            ppiVar8 = ppiVar3;
        }
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        ppiVar13 = ppiVar6 + 2;
        if ((int64_t *)0xf < ppiVar6[5]) {
            ppiVar13 = (int64_t **)*ppiVar13;
        }
        ppiVar12 = ppiVar8 + 2;
        if ((int64_t *)0xf < piVar2) {
            ppiVar12 = (int64_t **)ppiVar8[2];
        }
        if (piVar4 != ppiVar6[4]) {
joined_r0x0001800204f6:
            while (ppiVar5 != ppiVar6) {
                ppiVar6 = (int64_t **)ppiVar6[1];
                piVar14 = (int64_t *)(ppiVar6 + 2);
                if (0xf < ppiVar6[5]) {
                    piVar14 = (int64_t *)*piVar14;
                }
                if (piVar2 < (int64_t *)0x10) {
                    ppiVar13 = ppiVar8 + 2;
                } else {
                    ppiVar13 = (int64_t **)ppiVar8[2];
                }
                if (piVar4 == ppiVar6[4]) {
                    if ((piVar4 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar13, piVar14, piVar4), iVar10 == 0))
                    {
                        iVar15 = (int64_t)*ppiVar6;
                        ppiVar16 = (int64_t **)ppiVar8[1];
                        *ppiVar16 = (int64_t *)ppiVar3;
                        piVar2 = ppiVar3[1];
                        *piVar2 = iVar15;
                        ppiVar5 = *(int64_t ***)(iVar15 + 8);
                        *ppiVar5 = (int64_t *)ppiVar8;
                        *(int64_t **)(iVar15 + 8) = piVar2;
                        ppiVar3[1] = (int64_t *)ppiVar16;
                        ppiVar8[1] = (int64_t *)ppiVar5;
                        ppiVar8 = ppiVar3;
                        goto joined_r0x0001800203e6;
                    }
                    piVar2 = ppiVar8[5];
                }
            }
            ppiVar5 = (int64_t **)ppiVar8[1];
            *ppiVar5 = (int64_t *)ppiVar3;
            piVar2 = ppiVar3[1];
            *piVar2 = (int64_t)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = piVar2;
            ppiVar3[1] = (int64_t *)ppiVar5;
            ppiVar8[1] = (int64_t *)ppiVar13;
            *ppiVar16 = (int64_t *)ppiVar8;
            ppiVar8 = ppiVar3;
            goto joined_r0x0001800203e6;
        }
        if ((piVar4 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar12, ppiVar13, piVar4), iVar10 != 0)) {
            piVar2 = ppiVar8[5];
            goto joined_r0x0001800204f6;
        }
        ppiVar6 = (int64_t **)*ppiVar6;
        if (ppiVar6 != ppiVar8) {
            ppiVar16 = (int64_t **)ppiVar8[1];
            *ppiVar16 = (int64_t *)ppiVar3;
            ppiVar5 = (int64_t **)ppiVar3[1];
            *ppiVar5 = (int64_t *)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = (int64_t *)ppiVar5;
            ppiVar3[1] = (int64_t *)ppiVar16;
            ppiVar8[1] = (int64_t *)ppiVar13;
        }
        *(int64_t ***)(iVar15 + 8) = ppiVar8;
        ppiVar8 = ppiVar3;
    } while( true );
}

// ============================================================
// Function: FUN_18002038f
// Address: 0x18002038f
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180020360(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar9 = *(int64_t ***)0x180782818;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar11 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    fcn.18000f7e0(0x180782828, iVar15 * 2, *(int64_t ***)0x180782818);
    *(uint64_t *)0x180782840 = iVar15 - 1;
    *(int64_t *)0x180782848 = iVar15;
    ppiVar8 = (int64_t **)**(int64_t ***)0x180782818;
joined_r0x0001800203e6:
    do {
        while( true ) {
            if (ppiVar8 == ppiVar9) {
                return;
            }
            piVar2 = ppiVar8[5];
            ppiVar16 = ppiVar8 + 2;
            ppiVar3 = (int64_t **)*ppiVar8;
            piVar4 = ppiVar8[4];
            if ((int64_t *)0xf < piVar2) {
                ppiVar16 = (int64_t **)ppiVar8[2];
            }
            piVar14 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar4 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar16 + (int64_t)piVar14);
                    piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar14 < piVar4);
            }
            uVar11 = uVar11 & *(uint64_t *)0x180782840;
            ppiVar5 = *(int64_t ***)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            ppiVar16 = (int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            iVar15 = *(int64_t *)0x180782828 + uVar11 * 0x10;
            if (ppiVar5 != ppiVar9) break;
            *ppiVar16 = (int64_t *)ppiVar8;
            *(int64_t ***)(iVar15 + 8) = ppiVar8;
            ppiVar8 = ppiVar3;
        }
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        ppiVar13 = ppiVar6 + 2;
        if ((int64_t *)0xf < ppiVar6[5]) {
            ppiVar13 = (int64_t **)*ppiVar13;
        }
        ppiVar12 = ppiVar8 + 2;
        if ((int64_t *)0xf < piVar2) {
            ppiVar12 = (int64_t **)ppiVar8[2];
        }
        if (piVar4 != ppiVar6[4]) {
joined_r0x0001800204f6:
            while (ppiVar5 != ppiVar6) {
                ppiVar6 = (int64_t **)ppiVar6[1];
                piVar14 = (int64_t *)(ppiVar6 + 2);
                if (0xf < ppiVar6[5]) {
                    piVar14 = (int64_t *)*piVar14;
                }
                if (piVar2 < (int64_t *)0x10) {
                    ppiVar13 = ppiVar8 + 2;
                } else {
                    ppiVar13 = (int64_t **)ppiVar8[2];
                }
                if (piVar4 == ppiVar6[4]) {
                    if ((piVar4 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar13, piVar14, piVar4), iVar10 == 0))
                    {
                        iVar15 = (int64_t)*ppiVar6;
                        ppiVar16 = (int64_t **)ppiVar8[1];
                        *ppiVar16 = (int64_t *)ppiVar3;
                        piVar2 = ppiVar3[1];
                        *piVar2 = iVar15;
                        ppiVar5 = *(int64_t ***)(iVar15 + 8);
                        *ppiVar5 = (int64_t *)ppiVar8;
                        *(int64_t **)(iVar15 + 8) = piVar2;
                        ppiVar3[1] = (int64_t *)ppiVar16;
                        ppiVar8[1] = (int64_t *)ppiVar5;
                        ppiVar8 = ppiVar3;
                        goto joined_r0x0001800203e6;
                    }
                    piVar2 = ppiVar8[5];
                }
            }
            ppiVar5 = (int64_t **)ppiVar8[1];
            *ppiVar5 = (int64_t *)ppiVar3;
            piVar2 = ppiVar3[1];
            *piVar2 = (int64_t)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = piVar2;
            ppiVar3[1] = (int64_t *)ppiVar5;
            ppiVar8[1] = (int64_t *)ppiVar13;
            *ppiVar16 = (int64_t *)ppiVar8;
            ppiVar8 = ppiVar3;
            goto joined_r0x0001800203e6;
        }
        if ((piVar4 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar12, ppiVar13, piVar4), iVar10 != 0)) {
            piVar2 = ppiVar8[5];
            goto joined_r0x0001800204f6;
        }
        ppiVar6 = (int64_t **)*ppiVar6;
        if (ppiVar6 != ppiVar8) {
            ppiVar16 = (int64_t **)ppiVar8[1];
            *ppiVar16 = (int64_t *)ppiVar3;
            ppiVar5 = (int64_t **)ppiVar3[1];
            *ppiVar5 = (int64_t *)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = (int64_t *)ppiVar5;
            ppiVar3[1] = (int64_t *)ppiVar16;
            ppiVar8[1] = (int64_t *)ppiVar13;
        }
        *(int64_t ***)(iVar15 + 8) = ppiVar8;
        ppiVar8 = ppiVar3;
    } while( true );
}

// ============================================================
// Function: FUN_1800203ec
// Address: 0x1800203ec
// Size: 464 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180020360(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar9 = *(int64_t ***)0x180782818;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar11 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    fcn.18000f7e0(0x180782828, iVar15 * 2, *(int64_t ***)0x180782818);
    *(uint64_t *)0x180782840 = iVar15 - 1;
    *(int64_t *)0x180782848 = iVar15;
    ppiVar8 = (int64_t **)**(int64_t ***)0x180782818;
joined_r0x0001800203e6:
    do {
        while( true ) {
            if (ppiVar8 == ppiVar9) {
                return;
            }
            piVar2 = ppiVar8[5];
            ppiVar16 = ppiVar8 + 2;
            ppiVar3 = (int64_t **)*ppiVar8;
            piVar4 = ppiVar8[4];
            if ((int64_t *)0xf < piVar2) {
                ppiVar16 = (int64_t **)ppiVar8[2];
            }
            piVar14 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar4 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar16 + (int64_t)piVar14);
                    piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar14 < piVar4);
            }
            uVar11 = uVar11 & *(uint64_t *)0x180782840;
            ppiVar5 = *(int64_t ***)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            ppiVar16 = (int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            iVar15 = *(int64_t *)0x180782828 + uVar11 * 0x10;
            if (ppiVar5 != ppiVar9) break;
            *ppiVar16 = (int64_t *)ppiVar8;
            *(int64_t ***)(iVar15 + 8) = ppiVar8;
            ppiVar8 = ppiVar3;
        }
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        ppiVar13 = ppiVar6 + 2;
        if ((int64_t *)0xf < ppiVar6[5]) {
            ppiVar13 = (int64_t **)*ppiVar13;
        }
        ppiVar12 = ppiVar8 + 2;
        if ((int64_t *)0xf < piVar2) {
            ppiVar12 = (int64_t **)ppiVar8[2];
        }
        if (piVar4 != ppiVar6[4]) {
joined_r0x0001800204f6:
            while (ppiVar5 != ppiVar6) {
                ppiVar6 = (int64_t **)ppiVar6[1];
                piVar14 = (int64_t *)(ppiVar6 + 2);
                if (0xf < ppiVar6[5]) {
                    piVar14 = (int64_t *)*piVar14;
                }
                if (piVar2 < (int64_t *)0x10) {
                    ppiVar13 = ppiVar8 + 2;
                } else {
                    ppiVar13 = (int64_t **)ppiVar8[2];
                }
                if (piVar4 == ppiVar6[4]) {
                    if ((piVar4 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar13, piVar14, piVar4), iVar10 == 0))
                    {
                        iVar15 = (int64_t)*ppiVar6;
                        ppiVar16 = (int64_t **)ppiVar8[1];
                        *ppiVar16 = (int64_t *)ppiVar3;
                        piVar2 = ppiVar3[1];
                        *piVar2 = iVar15;
                        ppiVar5 = *(int64_t ***)(iVar15 + 8);
                        *ppiVar5 = (int64_t *)ppiVar8;
                        *(int64_t **)(iVar15 + 8) = piVar2;
                        ppiVar3[1] = (int64_t *)ppiVar16;
                        ppiVar8[1] = (int64_t *)ppiVar5;
                        ppiVar8 = ppiVar3;
                        goto joined_r0x0001800203e6;
                    }
                    piVar2 = ppiVar8[5];
                }
            }
            ppiVar5 = (int64_t **)ppiVar8[1];
            *ppiVar5 = (int64_t *)ppiVar3;
            piVar2 = ppiVar3[1];
            *piVar2 = (int64_t)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = piVar2;
            ppiVar3[1] = (int64_t *)ppiVar5;
            ppiVar8[1] = (int64_t *)ppiVar13;
            *ppiVar16 = (int64_t *)ppiVar8;
            ppiVar8 = ppiVar3;
            goto joined_r0x0001800203e6;
        }
        if ((piVar4 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar12, ppiVar13, piVar4), iVar10 != 0)) {
            piVar2 = ppiVar8[5];
            goto joined_r0x0001800204f6;
        }
        ppiVar6 = (int64_t **)*ppiVar6;
        if (ppiVar6 != ppiVar8) {
            ppiVar16 = (int64_t **)ppiVar8[1];
            *ppiVar16 = (int64_t *)ppiVar3;
            ppiVar5 = (int64_t **)ppiVar3[1];
            *ppiVar5 = (int64_t *)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = (int64_t *)ppiVar5;
            ppiVar3[1] = (int64_t *)ppiVar16;
            ppiVar8[1] = (int64_t *)ppiVar13;
        }
        *(int64_t ***)(iVar15 + 8) = ppiVar8;
        ppiVar8 = ppiVar3;
    } while( true );
}

// ============================================================
// Function: FUN_1800205bc
// Address: 0x1800205bc
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180020360(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar9 = *(int64_t ***)0x180782818;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar11 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    fcn.18000f7e0(0x180782828, iVar15 * 2, *(int64_t ***)0x180782818);
    *(uint64_t *)0x180782840 = iVar15 - 1;
    *(int64_t *)0x180782848 = iVar15;
    ppiVar8 = (int64_t **)**(int64_t ***)0x180782818;
joined_r0x0001800203e6:
    do {
        while( true ) {
            if (ppiVar8 == ppiVar9) {
                return;
            }
            piVar2 = ppiVar8[5];
            ppiVar16 = ppiVar8 + 2;
            ppiVar3 = (int64_t **)*ppiVar8;
            piVar4 = ppiVar8[4];
            if ((int64_t *)0xf < piVar2) {
                ppiVar16 = (int64_t **)ppiVar8[2];
            }
            piVar14 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar4 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar16 + (int64_t)piVar14);
                    piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar14 < piVar4);
            }
            uVar11 = uVar11 & *(uint64_t *)0x180782840;
            ppiVar5 = *(int64_t ***)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            ppiVar16 = (int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            iVar15 = *(int64_t *)0x180782828 + uVar11 * 0x10;
            if (ppiVar5 != ppiVar9) break;
            *ppiVar16 = (int64_t *)ppiVar8;
            *(int64_t ***)(iVar15 + 8) = ppiVar8;
            ppiVar8 = ppiVar3;
        }
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        ppiVar13 = ppiVar6 + 2;
        if ((int64_t *)0xf < ppiVar6[5]) {
            ppiVar13 = (int64_t **)*ppiVar13;
        }
        ppiVar12 = ppiVar8 + 2;
        if ((int64_t *)0xf < piVar2) {
            ppiVar12 = (int64_t **)ppiVar8[2];
        }
        if (piVar4 != ppiVar6[4]) {
joined_r0x0001800204f6:
            while (ppiVar5 != ppiVar6) {
                ppiVar6 = (int64_t **)ppiVar6[1];
                piVar14 = (int64_t *)(ppiVar6 + 2);
                if (0xf < ppiVar6[5]) {
                    piVar14 = (int64_t *)*piVar14;
                }
                if (piVar2 < (int64_t *)0x10) {
                    ppiVar13 = ppiVar8 + 2;
                } else {
                    ppiVar13 = (int64_t **)ppiVar8[2];
                }
                if (piVar4 == ppiVar6[4]) {
                    if ((piVar4 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar13, piVar14, piVar4), iVar10 == 0))
                    {
                        iVar15 = (int64_t)*ppiVar6;
                        ppiVar16 = (int64_t **)ppiVar8[1];
                        *ppiVar16 = (int64_t *)ppiVar3;
                        piVar2 = ppiVar3[1];
                        *piVar2 = iVar15;
                        ppiVar5 = *(int64_t ***)(iVar15 + 8);
                        *ppiVar5 = (int64_t *)ppiVar8;
                        *(int64_t **)(iVar15 + 8) = piVar2;
                        ppiVar3[1] = (int64_t *)ppiVar16;
                        ppiVar8[1] = (int64_t *)ppiVar5;
                        ppiVar8 = ppiVar3;
                        goto joined_r0x0001800203e6;
                    }
                    piVar2 = ppiVar8[5];
                }
            }
            ppiVar5 = (int64_t **)ppiVar8[1];
            *ppiVar5 = (int64_t *)ppiVar3;
            piVar2 = ppiVar3[1];
            *piVar2 = (int64_t)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = piVar2;
            ppiVar3[1] = (int64_t *)ppiVar5;
            ppiVar8[1] = (int64_t *)ppiVar13;
            *ppiVar16 = (int64_t *)ppiVar8;
            ppiVar8 = ppiVar3;
            goto joined_r0x0001800203e6;
        }
        if ((piVar4 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar12, ppiVar13, piVar4), iVar10 != 0)) {
            piVar2 = ppiVar8[5];
            goto joined_r0x0001800204f6;
        }
        ppiVar6 = (int64_t **)*ppiVar6;
        if (ppiVar6 != ppiVar8) {
            ppiVar16 = (int64_t **)ppiVar8[1];
            *ppiVar16 = (int64_t *)ppiVar3;
            ppiVar5 = (int64_t **)ppiVar3[1];
            *ppiVar5 = (int64_t *)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = (int64_t *)ppiVar5;
            ppiVar3[1] = (int64_t *)ppiVar16;
            ppiVar8[1] = (int64_t *)ppiVar13;
        }
        *(int64_t ***)(iVar15 + 8) = ppiVar8;
        ppiVar8 = ppiVar3;
    } while( true );
}

// ============================================================
// Function: FUN_1800205d1
// Address: 0x1800205d1
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180020360(int64_t arg1, int64_t arg2, int64_t arg_40h)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    code *pcVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int32_t iVar10;
    uint64_t uVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t *piVar14;
    int64_t iVar15;
    int64_t **ppiVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    ppiVar9 = *(int64_t ***)0x180782818;
    for (iVar15 = 0x3f; 0xfffffffffffffffU >> iVar15 == 0; iVar15 = iVar15 + -1) {
    }
    if ((uint64_t)(1LL << ((uint8_t)iVar15 & 0x3f)) < (uint64_t)arg2) {
        func_0x0001804546d4(0x180620448);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    uVar11 = arg2 - 1U | 1;
    iVar15 = 0x3f;
    if (uVar11 != 0) {
        for (; uVar11 >> iVar15 == 0; iVar15 = iVar15 + -1) {
        }
    }
    iVar15 = 1LL << ((char)iVar15 + 1U & 0x3f);
    fcn.18000f7e0(0x180782828, iVar15 * 2, *(int64_t ***)0x180782818);
    *(uint64_t *)0x180782840 = iVar15 - 1;
    *(int64_t *)0x180782848 = iVar15;
    ppiVar8 = (int64_t **)**(int64_t ***)0x180782818;
joined_r0x0001800203e6:
    do {
        while( true ) {
            if (ppiVar8 == ppiVar9) {
                return;
            }
            piVar2 = ppiVar8[5];
            ppiVar16 = ppiVar8 + 2;
            ppiVar3 = (int64_t **)*ppiVar8;
            piVar4 = ppiVar8[4];
            if ((int64_t *)0xf < piVar2) {
                ppiVar16 = (int64_t **)ppiVar8[2];
            }
            piVar14 = (int64_t *)0x0;
            uVar11 = 0xcbf29ce484222325;
            if (piVar4 != (int64_t *)0x0) {
                do {
                    puVar1 = (uint8_t *)((int64_t)ppiVar16 + (int64_t)piVar14);
                    piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                    uVar11 = (uVar11 ^ *puVar1) * 0x100000001b3;
                } while (piVar14 < piVar4);
            }
            uVar11 = uVar11 & *(uint64_t *)0x180782840;
            ppiVar5 = *(int64_t ***)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            ppiVar16 = (int64_t **)(*(int64_t *)0x180782828 + uVar11 * 0x10);
            iVar15 = *(int64_t *)0x180782828 + uVar11 * 0x10;
            if (ppiVar5 != ppiVar9) break;
            *ppiVar16 = (int64_t *)ppiVar8;
            *(int64_t ***)(iVar15 + 8) = ppiVar8;
            ppiVar8 = ppiVar3;
        }
        ppiVar6 = *(int64_t ***)(iVar15 + 8);
        ppiVar13 = ppiVar6 + 2;
        if ((int64_t *)0xf < ppiVar6[5]) {
            ppiVar13 = (int64_t **)*ppiVar13;
        }
        ppiVar12 = ppiVar8 + 2;
        if ((int64_t *)0xf < piVar2) {
            ppiVar12 = (int64_t **)ppiVar8[2];
        }
        if (piVar4 != ppiVar6[4]) {
joined_r0x0001800204f6:
            while (ppiVar5 != ppiVar6) {
                ppiVar6 = (int64_t **)ppiVar6[1];
                piVar14 = (int64_t *)(ppiVar6 + 2);
                if (0xf < ppiVar6[5]) {
                    piVar14 = (int64_t *)*piVar14;
                }
                if (piVar2 < (int64_t *)0x10) {
                    ppiVar13 = ppiVar8 + 2;
                } else {
                    ppiVar13 = (int64_t **)ppiVar8[2];
                }
                if (piVar4 == ppiVar6[4]) {
                    if ((piVar4 == (int64_t *)0x0) || (iVar10 = fcn.180497f30(ppiVar13, piVar14, piVar4), iVar10 == 0))
                    {
                        iVar15 = (int64_t)*ppiVar6;
                        ppiVar16 = (int64_t **)ppiVar8[1];
                        *ppiVar16 = (int64_t *)ppiVar3;
                        piVar2 = ppiVar3[1];
                        *piVar2 = iVar15;
                        ppiVar5 = *(int64_t ***)(iVar15 + 8);
                        *ppiVar5 = (int64_t *)ppiVar8;
                        *(int64_t **)(iVar15 + 8) = piVar2;
                        ppiVar3[1] = (int64_t *)ppiVar16;
                        ppiVar8[1] = (int64_t *)ppiVar5;
                        ppiVar8 = ppiVar3;
                        goto joined_r0x0001800203e6;
                    }
                    piVar2 = ppiVar8[5];
                }
            }
            ppiVar5 = (int64_t **)ppiVar8[1];
            *ppiVar5 = (int64_t *)ppiVar3;
            piVar2 = ppiVar3[1];
            *piVar2 = (int64_t)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = piVar2;
            ppiVar3[1] = (int64_t *)ppiVar5;
            ppiVar8[1] = (int64_t *)ppiVar13;
            *ppiVar16 = (int64_t *)ppiVar8;
            ppiVar8 = ppiVar3;
            goto joined_r0x0001800203e6;
        }
        if ((piVar4 != (int64_t *)0x0) && (iVar10 = fcn.180497f30(ppiVar12, ppiVar13, piVar4), iVar10 != 0)) {
            piVar2 = ppiVar8[5];
            goto joined_r0x0001800204f6;
        }
        ppiVar6 = (int64_t **)*ppiVar6;
        if (ppiVar6 != ppiVar8) {
            ppiVar16 = (int64_t **)ppiVar8[1];
            *ppiVar16 = (int64_t *)ppiVar3;
            ppiVar5 = (int64_t **)ppiVar3[1];
            *ppiVar5 = (int64_t *)ppiVar6;
            ppiVar13 = (int64_t **)ppiVar6[1];
            *ppiVar13 = (int64_t *)ppiVar8;
            ppiVar6[1] = (int64_t *)ppiVar5;
            ppiVar3[1] = (int64_t *)ppiVar16;
            ppiVar8[1] = (int64_t *)ppiVar13;
        }
        *(int64_t ***)(iVar15 + 8) = ppiVar8;
        ppiVar8 = ppiVar3;
    } while( true );
}

// ============================================================
// Function: FUN_1800205e0
// Address: 0x1800205e0
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1800205e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined (*pauVar3) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined4 uVar4;
    
    pauVar3 = (undefined (*) [16])fcn.180459890(0x20);
    *pauVar3 = ZEXT816(0);
    *(undefined4 *)(*pauVar3 + 8) = 1;
    *(undefined4 *)(*pauVar3 + 0xc) = 1;
    *(undefined8 *)*pauVar3 = 0x1806219d8;
    pauVar3[1] = ZEXT816(0);
    *(undefined (**) [16])arg1 = pauVar3 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar3;
    uVar4 = 3;
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    fcn.180086c20(arg2);
    (**(code **)0x180782598)(arg2, iVar1 - iVar2 >> 4 & 0xffffffff, 0x1806217b8, *(undefined8 *)arg1, uVar4);
    *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x10;
    return arg1;
}

// ============================================================
// Function: FUN_180020690
// Address: 0x180020690
// Size: 599 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

int64_t fcn.180020690(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t *piVar3;
    code *pcVar4;
    int64_t iVar5;
    int32_t *piVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    undefined *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    uint64_t uVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    if (*(int64_t *)(arg2 + 0x50) != 0) {
        iVar5 = *(int64_t *)(*(int64_t *)(arg2 + 0x50) + 0x98);
        piVar10 = *(int64_t **)(iVar5 + 0x1c0);
        piVar11 = (int64_t *)*piVar10;
        if (piVar11 != piVar10) {
            do {
                iVar13 = piVar11[3];
                if ((((iVar13 != 0) && (piVar6 = (int32_t *)(iVar13 + 0xf0), piVar6 != (int32_t *)0x0)) &&
                    (iVar13 = CONCAT44((int32_t)piVar6 - *(int32_t *)(iVar13 + 0xf4), (int32_t)piVar6 - *piVar6),
                    iVar13 != 0)) && (*(char *)(iVar13 + 2) == '\n')) {
                    piVar10 = *(int64_t **)(arg1 + 8);
                    if (piVar10 == *(int64_t **)(arg1 + 0x10)) {
                        iVar2 = *(int64_t *)arg1;
                        iVar9 = (int64_t)piVar10 - iVar2 >> 3;
                        if (iVar9 == 0x1fffffffffffffff) {
                            func_0x000180010010();
                            pcVar4 = (code *)swi(3);
                            iVar5 = (*pcVar4)();
                            return iVar5;
                        }
                        uVar7 = (int64_t)*(int64_t **)(arg1 + 0x10) - iVar2 >> 3;
                        puVar12 = auStack_58;
                        if (0x1fffffffffffffff - (uVar7 >> 1) < uVar7) goto code_r0x0001800208db;
                        uVar1 = iVar9 + 1;
                        uVar7 = uVar7 + (uVar7 >> 1);
                        uVar15 = uVar1;
                        if (uVar1 <= uVar7) {
                            uVar15 = uVar7;
                        }
                        puVar12 = auStack_58;
                        if (0x1fffffffffffffff < uVar15) goto code_r0x0001800208db;
                        uVar7 = uVar15 * 8;
                        if (uVar7 != 0) {
                            if (uVar7 < 0x1000) {
                                piVar14 = (int64_t *)fcn.180459890(uVar7);
                                goto code_r0x0001800207ff;
                            }
                            puVar12 = auStack_58;
                            if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800208db;
                            iVar9 = fcn.180459890();
                            if (iVar9 != 0) {
                                piVar14 = (int64_t *)(iVar9 + 0x27U & 0xffffffffffffffe0);
                                piVar14[-1] = iVar9;
                                goto code_r0x0001800207ff;
                            }
code_r0x0001800208d4:
                            pcVar4 = (code *)swi(0x29);
                            (*pcVar4)(5);
                            puVar12 = auStack_50;
code_r0x0001800208db:
                            *(undefined8 *)(puVar12 + -8) = 0x1800208e0;
                            fcn.180004720();
                            pcVar4 = (code *)swi(3);
                            iVar5 = (*pcVar4)();
                            return iVar5;
                        }
                        piVar14 = (int64_t *)0x0;
code_r0x0001800207ff:
                        piVar14[(int64_t)piVar10 - iVar2 >> 3] = iVar13;
                        piVar3 = *(int64_t **)arg1;
                        if (piVar10 == *(int64_t **)(arg1 + 8)) {
                            iVar13 = (int64_t)*(int64_t **)(arg1 + 8) - (int64_t)piVar3;
                            piVar8 = piVar14;
                            piVar10 = piVar3;
                        } else {
                            func_0x000180498030(piVar14, piVar3, (int64_t)piVar10 - (int64_t)piVar3);
                            iVar13 = *(int64_t *)(arg1 + 8) - (int64_t)piVar10;
                            piVar8 = piVar14 + ((int64_t)piVar10 - iVar2 >> 3) + 1;
                        }
                        func_0x000180498030(piVar8, piVar10, iVar13);
                        iVar13 = *(int64_t *)arg1;
                        if (iVar13 != 0) {
                            uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar13 >> 3) * 8;
                            if (0xfff < uVar7) {
                                if (0x1f < (iVar13 - *(int64_t *)(iVar13 + -8)) - 8U) goto code_r0x0001800208d4;
                                uVar7 = uVar7 + 0x27;
                                iVar13 = *(int64_t *)(iVar13 + -8);
                            }
                            fcn.180459c3c(iVar13, uVar7);
                        }
                        *(int64_t **)arg1 = piVar14;
                        *(int64_t **)(arg1 + 8) = piVar14 + uVar1;
                        *(int64_t **)(arg1 + 0x10) = piVar14 + uVar15;
                    } else {
                        *piVar10 = iVar13;
                        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 8;
                    }
                }
                piVar11 = (int64_t *)*piVar11;
            } while (piVar11 != (int64_t *)*(int64_t *)(iVar5 + 0x1c0));
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800208f0
// Address: 0x1800208f0
// Size: 1530 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Detected overlap for variable var_12h
// WARNING: [rz-ghidra] Detected overlap for variable var_13h
// WARNING: [rz-ghidra] Detected overlap for variable var_1h

undefined8 fcn.1800208f0(int64_t arg1, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    int64_t **ppiVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t *piVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    code *pcVar13;
    undefined4 uVar14;
    undefined4 uVar15;
    undefined4 uVar16;
    uint64_t uVar17;
    int32_t iVar18;
    int64_t *piVar19;
    int64_t **ppiVar20;
    uint64_t uVar21;
    undefined8 uVar22;
    int64_t iVar23;
    uint64_t uVar24;
    int64_t **ppiVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    float fVar28;
    float fVar29;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    uVar26 = *(int32_t *)0x180782090 + 1;
    piVar19 = (int64_t *)0x0;
    func_0x0001800869f0(arg1, *(undefined8 *)0x1807823f0, 0, 0, 0);
    func_0x0001800867f0(arg1, 0x1806217a8, 0xd);
    var_58h = *(int64_t *)(arg1 + 0x40) + -0x20;
    var_50h = CONCAT44(var_50h._4_4_, 1);
    iVar18 = func_0x000180094080(arg1, 0x180087890, &var_58h, var_58h - *(int64_t *)(arg1 + 0x38), 0);
    if (iVar18 != 0) {
code_r0x000180020ed4:
        func_0x000180087960(arg1);
code_r0x000180020edd:
        func_0x0001804546d4(0x180620428);
        pcVar13 = (code *)swi(3);
        uVar22 = (*pcVar13)();
        return uVar22;
    }
    iVar23 = *(int64_t *)(arg1 + 0x40);
    if (*(int32_t *)(iVar23 + -4) == 9) {
        piVar19 = (int64_t *)(*(int64_t *)(iVar23 + -0x10) + 0x10);
    } else if (*(int32_t *)(iVar23 + -4) == 2) {
        piVar19 = *(int64_t **)(iVar23 + -0x10);
    }
    if (piVar19[1] != 0) {
        LOCK();
        piVar1 = (int32_t *)(piVar19[1] + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    var_48h = *piVar19;
    piVar19 = (int64_t *)piVar19[1];
    var_10h._1_1_ = (uint8_t)(uVar26 >> 8);
    var_10h._2_1_ = (uint8_t)(uVar26 >> 0x10);
    var_10h._3_1_ = (uint8_t)(uVar26 >> 0x18);
    uVar27 = (((((uint64_t)(uVar26 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)var_10h._1_1_) *
               0x100000001b3 ^ (uint64_t)var_10h._2_1_) * 0x100000001b3 ^ (uint64_t)var_10h._3_1_) * 0x100000001b3;
    ppiVar20 = *(int64_t ***)(*(int64_t *)0x180782098 + 8 + (uVar27 & *(uint64_t *)0x1807820b0) * 0x10);
    ppiVar25 = *(int64_t ***)0x180782088;
    var_40h = (int64_t)piVar19;
    if (ppiVar20 != *(int64_t ***)0x180782088) {
        uVar3 = *(uint32_t *)(ppiVar20 + 2);
        ppiVar25 = ppiVar20;
        while (ppiVar20 = ppiVar25, uVar26 != uVar3) {
            if (ppiVar25 == *(int64_t ***)(*(int64_t *)0x180782098 + (uVar27 & *(uint64_t *)0x1807820b0) * 0x10))
            goto code_r0x000180020a67;
            ppiVar25 = (int64_t **)ppiVar25[1];
            uVar3 = *(uint32_t *)(ppiVar25 + 2);
        }
        goto code_r0x000180020dd8;
    }
code_r0x000180020a67:
    if (*(int64_t *)0x180782090 == 0x666666666666666) goto code_r0x000180020edd;
    var_58h = 0x180782088;
    var_50h = 0;
    ppiVar20 = (int64_t **)fcn.180459890(0x28);
    *(uint32_t *)(ppiVar20 + 2) = uVar26;
    ppiVar20[3] = (int64_t *)0x0;
    ppiVar20[4] = (int64_t *)0x0;
    uVar17 = *(uint64_t *)0x1807820b8;
    uVar21 = *(int64_t *)0x180782090 + 1;
    if ((int64_t)uVar21 < 0) {
        fVar28 = (float)(uVar21 >> 1 | (uint64_t)((uint32_t)uVar21 & 1));
        fVar28 = fVar28 + fVar28;
    } else {
        fVar28 = (float)uVar21;
    }
    if ((int64_t)*(uint64_t *)0x1807820b8 < 0) {
        fVar29 = (float)(*(uint64_t *)0x1807820b8 >> 1 | (uint64_t)((uint32_t)*(uint64_t *)0x1807820b8 & 1));
        fVar29 = fVar29 + fVar29;
    } else {
        fVar29 = (float)*(uint64_t *)0x1807820b8;
    }
    var_50h = (int64_t)ppiVar20;
    if (*(float *)0x180782080 < fVar28 / fVar29) {
        fVar28 = (float)func_0x000180471c90(fVar28 / *(float *)0x180782080);
        ppiVar25 = *(int64_t ***)0x180782088;
        iVar23 = 0;
        if ((9.223372e+18 <= fVar28) && (fVar28 = fVar28 - 9.223372e+18, fVar28 < 9.223372e+18)) {
            iVar23 = -0x8000000000000000;
        }
        uVar21 = 8;
        if (8 < (uint64_t)((int64_t)fVar28 + iVar23)) {
            uVar21 = (int64_t)fVar28 + iVar23;
        }
        uVar24 = uVar17;
        if ((uVar17 < uVar21) && ((0x1ff < uVar17 || (uVar24 = uVar17 * 8, uVar17 * 8 < uVar21)))) {
            uVar24 = uVar21;
        }
        for (iVar23 = 0x3f; 0xfffffffffffffffU >> iVar23 == 0; iVar23 = iVar23 + -1) {
        }
        if ((uint64_t)(1LL << ((uint8_t)iVar23 & 0x3f)) < uVar24) {
            func_0x0001804546d4(0x180620448);
            goto code_r0x000180020ed4;
        }
        uVar21 = uVar24 - 1 | 1;
        iVar23 = 0x3f;
        if (uVar21 != 0) {
            for (; uVar21 >> iVar23 == 0; iVar23 = iVar23 + -1) {
            }
        }
        uVar21 = 1LL << ((char)iVar23 + 1U & 0x3f);
        fcn.18000f7e0(0x180782098, uVar21 * 2, *(int64_t ***)0x180782088);
        *(uint64_t *)0x1807820b0 = uVar21 - 1;
        *(uint64_t *)0x1807820b8 = uVar21;
        ppiVar9 = (int64_t **)**(int64_t ***)0x180782088;
        iVar23 = *(int64_t *)0x180782098;
joined_r0x000180020bed:
        *(int64_t *)0x180782098 = iVar23;
        if (ppiVar9 != ppiVar25) {
            ppiVar4 = (int64_t **)*ppiVar9;
            uVar21 = (((((uint64_t)*(uint8_t *)(ppiVar9 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                       (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x11)) * 0x100000001b3 ^
                      (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x12)) * 0x100000001b3 ^
                     (uint64_t)*(uint8_t *)((int64_t)ppiVar9 + 0x13)) * 0x100000001b3 & *(uint64_t *)0x1807820b0;
            ppiVar5 = *(int64_t ***)(iVar23 + uVar21 * 0x10);
            if (ppiVar5 == ppiVar25) {
                *(int64_t ***)(iVar23 + uVar21 * 0x10) = ppiVar9;
                *(int64_t ***)(iVar23 + 8 + uVar21 * 0x10) = ppiVar9;
                ppiVar9 = ppiVar4;
                iVar23 = *(int64_t *)0x180782098;
            } else {
                ppiVar6 = *(int64_t ***)(iVar23 + 8 + uVar21 * 0x10);
                if (*(int32_t *)(ppiVar9 + 2) == *(int32_t *)(ppiVar6 + 2)) {
                    ppiVar6 = (int64_t **)*ppiVar6;
                    if (ppiVar6 != ppiVar9) {
                        ppiVar5 = (int64_t **)ppiVar9[1];
                        *ppiVar5 = (int64_t *)ppiVar4;
                        ppiVar7 = (int64_t **)ppiVar4[1];
                        *ppiVar7 = (int64_t *)ppiVar6;
                        ppiVar8 = (int64_t **)ppiVar6[1];
                        *ppiVar8 = (int64_t *)ppiVar9;
                        ppiVar6[1] = (int64_t *)ppiVar7;
                        ppiVar4[1] = (int64_t *)ppiVar5;
                        ppiVar9[1] = (int64_t *)ppiVar8;
                    }
                    *(int64_t ***)(iVar23 + 8 + uVar21 * 0x10) = ppiVar9;
                    ppiVar9 = ppiVar4;
                    iVar23 = *(int64_t *)0x180782098;
                } else {
                    do {
                        if (ppiVar5 == ppiVar6) {
                            ppiVar5 = (int64_t **)ppiVar9[1];
                            *ppiVar5 = (int64_t *)ppiVar4;
                            piVar10 = ppiVar4[1];
                            *piVar10 = (int64_t)ppiVar6;
                            ppiVar7 = (int64_t **)ppiVar6[1];
                            *ppiVar7 = (int64_t *)ppiVar9;
                            ppiVar6[1] = piVar10;
                            ppiVar4[1] = (int64_t *)ppiVar5;
                            ppiVar9[1] = (int64_t *)ppiVar7;
                            *(int64_t ***)(iVar23 + uVar21 * 0x10) = ppiVar9;
                            ppiVar9 = ppiVar4;
                            iVar23 = *(int64_t *)0x180782098;
                            goto joined_r0x000180020bed;
                        }
                        ppiVar6 = (int64_t **)ppiVar6[1];
                    } while (*(int32_t *)(ppiVar9 + 2) != *(int32_t *)(ppiVar6 + 2));
                    iVar23 = (int64_t)*ppiVar6;
                    ppiVar5 = (int64_t **)ppiVar9[1];
                    *ppiVar5 = (int64_t *)ppiVar4;
                    piVar10 = ppiVar4[1];
                    *piVar10 = iVar23;
                    ppiVar6 = *(int64_t ***)(iVar23 + 8);
                    *ppiVar6 = (int64_t *)ppiVar9;
                    *(int64_t **)(iVar23 + 8) = piVar10;
                    ppiVar4[1] = (int64_t *)ppiVar5;
                    ppiVar9[1] = (int64_t *)ppiVar6;
                    ppiVar9 = ppiVar4;
                    iVar23 = *(int64_t *)0x180782098;
                }
            }
            goto joined_r0x000180020bed;
        }
        ppiVar9 = *(int64_t ***)(iVar23 + 8 + (uVar27 & *(uint64_t *)0x1807820b0) * 0x10);
        ppiVar25 = *(int64_t ***)0x180782088;
        if (ppiVar9 != *(int64_t ***)0x180782088) {
            iVar18 = *(int32_t *)(ppiVar9 + 2);
            ppiVar25 = ppiVar9;
            while (*(int32_t *)(ppiVar20 + 2) != iVar18) {
                if (ppiVar25 == *(int64_t ***)(iVar23 + (uVar27 & *(uint64_t *)0x1807820b0) * 0x10))
                goto code_r0x000180020d4e;
                ppiVar25 = (int64_t **)ppiVar25[1];
                iVar18 = *(int32_t *)(ppiVar25 + 2);
            }
            ppiVar25 = (int64_t **)*ppiVar25;
        }
    }
code_r0x000180020d4e:
    piVar10 = ppiVar25[1];
    *(int64_t *)0x180782090 = *(int64_t *)0x180782090 + 1;
    *ppiVar20 = (int64_t *)ppiVar25;
    ppiVar20[1] = piVar10;
    *piVar10 = (int64_t)ppiVar20;
    ppiVar25[1] = (int64_t *)ppiVar20;
    iVar23 = *(int64_t *)0x180782098;
    uVar27 = uVar27 & *(uint64_t *)0x1807820b0;
    ppiVar9 = *(int64_t ***)(*(int64_t *)0x180782098 + uVar27 * 0x10);
    if (ppiVar9 == *(int64_t ***)0x180782088) {
        *(int64_t ***)(*(int64_t *)0x180782098 + uVar27 * 0x10) = ppiVar20;
    } else {
        if (ppiVar9 == ppiVar25) {
            *(int64_t ***)(*(int64_t *)0x180782098 + uVar27 * 0x10) = ppiVar20;
            goto code_r0x000180020dd8;
        }
        if (*(int64_t **)(*(int64_t *)0x180782098 + 8 + uVar27 * 0x10) != piVar10) goto code_r0x000180020dd8;
    }
    *(int64_t ***)(iVar23 + 8 + uVar27 * 0x10) = ppiVar20;
code_r0x000180020dd8:
    if (piVar19 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar19 + 1) = *(int32_t *)(piVar19 + 1) + 1;
        UNLOCK();
    }
    ppiVar20[3] = (int64_t *)var_48h;
    piVar10 = ppiVar20[4];
    ppiVar20[4] = piVar19;
    if (piVar10 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar10 + 1;
        iVar18 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar18 == 1) {
            (**(code **)*piVar10)(piVar10);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
            iVar18 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar18 == 1) {
                (**(code **)(*piVar10 + 8))(piVar10);
            }
        }
    }
    func_0x0001800865e0(arg1, uVar26);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar11 = *(undefined4 **)(arg1 + 0x40);
    puVar12 = puVar11;
    while (puVar11 + -8 < puVar12) {
        *puVar12 = puVar12[-4];
        puVar12[1] = puVar12[-3];
        puVar12[2] = puVar12[-2];
        puVar12[3] = puVar12[-1];
        puVar12 = puVar12 + -4;
    }
    puVar12 = *(undefined4 **)(arg1 + 0x40);
    uVar14 = puVar12[1];
    uVar15 = puVar12[2];
    uVar16 = puVar12[3];
    puVar11[-8] = *puVar12;
    puVar11[-7] = uVar14;
    puVar11[-6] = uVar15;
    puVar11[-5] = uVar16;
    if (piVar19 != (int64_t *)0x0) {
        LOCK();
        piVar10 = piVar19 + 1;
        iVar18 = *(int32_t *)piVar10;
        *(int32_t *)piVar10 = *(int32_t *)piVar10 + -1;
        UNLOCK();
        if (iVar18 == 1) {
            (**(code **)*piVar19)(piVar19);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar19 + 0xc);
            iVar18 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar18 == 1) {
                (**(code **)(*piVar19 + 8))(piVar19);
            }
        }
    }
    return 2;
}

// ============================================================
// Function: FUN_180020ef0
// Address: 0x180020ef0
// Size: 266 bytes
// ============================================================
undefined8 fcn.180020ef0(int64_t arg1)
{
    int32_t *piVar1;
    uint32_t uVar2;
    code *pcVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t var_18h;
    int64_t var_10h;
    
    uVar4 = func_0x000180088860(arg1, 1);
    pcVar3 = *(code **)0x180782630;
    piVar6 = (int64_t *)
             (((((uint64_t)(uVar4 >> 0x10 & 0xff) ^
                (((uint64_t)(uint8_t)uVar4 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)(uVar4 >> 8) & 0xff) *
                0x100000001b3) * 0x100000001b3 ^ (uint64_t)(uVar4 >> 0x18)) * 0x100000001b3 & *(uint64_t *)0x1807820b0)
              * 0x10 + *(int64_t *)0x180782098);
    iVar5 = piVar6[1];
    if (iVar5 == *(int64_t *)0x180782088) {
code_r0x000180020f91:
        iVar5 = 0;
    } else {
        uVar2 = *(uint32_t *)(iVar5 + 0x10);
        while (uVar4 != uVar2) {
            if (iVar5 == *piVar6) goto code_r0x000180020f91;
            iVar5 = *(int64_t *)(iVar5 + 8);
            uVar2 = *(uint32_t *)(iVar5 + 0x10);
        }
    }
    iVar7 = *(int64_t *)0x180782088;
    if (iVar5 != 0) {
        iVar7 = iVar5;
    }
    if (iVar7 == *(int64_t *)0x180782088) {
        func_0x000180086510(arg1);
        return 1;
    }
    if (*(int64_t *)(iVar7 + 0x20) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(iVar7 + 0x20) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    _var_18h = *(undefined (*) [16])(iVar7 + 0x18);
    (*pcVar3)(arg1, &var_18h);
    return 1;
}

// ============================================================
// Function: FUN_180021000
// Address: 0x180021000
// Size: 590 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

undefined8 fcn.180021000(int64_t arg1, int64_t arg_48h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    undefined4 *puVar11;
    undefined8 uVar12;
    uint64_t uVar13;
    int64_t *piVar14;
    undefined *puVar15;
    int32_t iVar16;
    int64_t *piVar17;
    uint64_t uVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_10h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t iStack_58;
    
    bVar19 = false;
    iVar16 = 1;
    func_0x000180086fd0(arg1, 0, 0);
    fcn.180020690((int64_t)&var_68h, arg1);
    if (var_68h != var_60h) {
        piVar14 = (int64_t *)((uint64_t)var_10h._4_4_ << 0x20);
        piVar17 = (int64_t *)var_68h;
        do {
            piVar3 = *(int64_t **)(*(int64_t *)(*piVar17 + 0x50) + 8);
            if (((piVar3 != (int64_t *)0x0) && (iVar4 = piVar3[1], iVar4 != 0)) && (*piVar3 != 0)) {
                iVar5 = *(int64_t *)(iVar4 + 0x48);
                if ((iVar5 == 0) || (*(int32_t *)(iVar5 + 8) == 0)) {
code_r0x0001800210b8:
                    bVar20 = false;
                } else {
                    iVar2 = *(int32_t *)(iVar5 + 8);
                    do {
                        if (iVar2 == 0) {
                            piVar14 = (int64_t *)0x0;
                            bVar19 = true;
                            goto code_r0x0001800210b8;
                        }
                        LOCK();
                        iVar10 = *(int32_t *)(iVar5 + 8);
                        bVar19 = iVar2 == iVar10;
                        if (bVar19) {
                            *(int32_t *)(iVar5 + 8) = iVar2 + 1;
                            iVar10 = iVar2;
                        }
                        UNLOCK();
                        iVar2 = iVar10;
                    } while (!bVar19);
                    piVar14 = *(int64_t **)(iVar4 + 0x48);
                    bVar19 = true;
                    if (*(int64_t *)(iVar4 + 0x40) == 0) goto code_r0x0001800210b8;
                    bVar20 = true;
                }
                if ((bVar19) && (bVar19 = false, piVar14 != (int64_t *)0x0)) {
                    LOCK();
                    piVar3 = piVar14 + 1;
                    iVar2 = *(int32_t *)piVar3;
                    *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
                    UNLOCK();
                    if (iVar2 == 1) {
                        (**(code **)*piVar14)(piVar14);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar14 + 0xc);
                        iVar2 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar2 == 1) {
                            (**(code **)(*piVar14 + 8))(piVar14);
                        }
                    }
                }
                pcVar6 = *(code **)0x180782630;
                if (bVar20) {
                    _var_78h = ZEXT816(0);
                    iVar5 = *(int64_t *)(iVar4 + 0x48);
                    if (iVar5 != 0) {
                        iVar2 = *(int32_t *)(iVar5 + 8);
                        do {
                            if (iVar2 == 0) goto code_r0x00018002115d;
                            LOCK();
                            iVar10 = *(int32_t *)(iVar5 + 8);
                            bVar20 = iVar2 == iVar10;
                            if (bVar20) {
                                *(int32_t *)(iVar5 + 8) = iVar2 + 1;
                                iVar10 = iVar2;
                            }
                            UNLOCK();
                            iVar2 = iVar10;
                        } while (!bVar20);
                        _var_78h = *(undefined (*) [16])(iVar4 + 0x40);
                    }
code_r0x00018002115d:
                    (*pcVar6)(arg1, &var_78h);
                    iVar4 = *(int64_t *)(arg1 + 0x40);
                    if (*(char *)(*(int64_t *)(iVar4 + -0x20) + 4) != '\0') {
                        func_0x000180092f10(arg1);
                        pcVar6 = (code *)swi(3);
                        uVar12 = (*pcVar6)();
                        return uVar12;
                    }
                    puVar11 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar4 + -0x20), iVar16);
                    uVar7 = *(undefined4 *)(iVar4 + -0xc);
                    uVar8 = *(undefined4 *)(iVar4 + -8);
                    uVar9 = *(undefined4 *)(iVar4 + -4);
                    *puVar11 = *(undefined4 *)(iVar4 + -0x10);
                    puVar11[1] = uVar7;
                    puVar11[2] = uVar8;
                    puVar11[3] = uVar9;
                    if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                        iVar4 = *(int64_t *)(iVar4 + -0x20);
                        if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
                           ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                            iVar5 = *(int64_t *)(arg1 + 0x20);
                            if (*(char *)(iVar5 + 0x59) == '\x02') {
                                func_0x000180094420();
                            } else {
                                *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                                *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                                *(int64_t *)(iVar5 + 0x18) = iVar4;
                            }
                        }
                    }
                    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                    iVar16 = iVar16 + 1;
                }
            }
            piVar17 = piVar17 + 1;
        } while (piVar17 != (int64_t *)var_60h);
    }
    if (var_68h != 0) {
        uVar13 = var_68h;
        puVar15 = auStack_98;
        if (0xfff < (uint64_t)((iStack_58 - var_68h >> 3) * 8)) {
            uVar13 = *(uint64_t *)(var_68h - 8);
            uVar18 = (var_68h - uVar13) - 8;
            puVar15 = auStack_98;
            if (0x1f < uVar18) {
                pcVar6 = (code *)swi(0x29);
                (*pcVar6)(5);
                uVar13 = uVar18;
                puVar15 = auStack_90;
            }
        }
        *(undefined8 *)(puVar15 + -8) = 0x180021232;
        fcn.180459c3c(uVar13);
    }
    return 1;
}

// ============================================================
// Function: FUN_180021250
// Address: 0x180021250
// Size: 375 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

undefined8 fcn.180021250(int64_t arg1, int64_t arg_38h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    undefined *puVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t iStack_38;
    
    func_0x000180086fd0(arg1, 0, 0);
    fcn.180020690((int64_t)&var_48h, arg1);
    piVar12 = (int64_t *)var_48h;
    do {
        if (piVar12 == (int64_t *)var_40h) {
            if (var_48h != 0) {
                uVar10 = var_48h;
                puVar11 = auStack_68;
                if (0xfff < (uint64_t)((iStack_38 - var_48h >> 3) * 8)) {
                    uVar10 = *(uint64_t *)(var_48h - 8);
                    uVar13 = (var_48h - uVar10) - 8;
                    puVar11 = auStack_68;
                    if (0x1f < uVar13) {
                        pcVar4 = (code *)swi(0x29);
                        (*pcVar4)(5);
                        uVar10 = uVar13;
                        puVar11 = auStack_60;
                    }
                }
                *(undefined8 *)(puVar11 + -8) = 0x1800213b1;
                fcn.180459c3c(uVar10);
            }
            return 1;
        }
        piVar1 = *(int64_t **)(*(int64_t *)(*piVar12 + 0x50) + 8);
        if ((*piVar1 != 0) && ((iVar2 = *(int64_t *)(piVar1[1] + 0x48), iVar2 == 0 || (*(int32_t *)(iVar2 + 8) == 0))))
        {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            func_0x000180086ba0(arg1, *piVar12, 0);
            iVar2 = *(int64_t *)(arg1 + 0x40);
            if (*(char *)(*(int64_t *)(iVar2 + -0x20) + 4) != '\0') {
                func_0x000180092f10(arg1);
                pcVar4 = (code *)swi(3);
                uVar9 = (*pcVar4)();
                return uVar9;
            }
            puVar8 = (undefined4 *)func_0x0001800a1010();
            uVar5 = *(undefined4 *)(iVar2 + -0xc);
            uVar6 = *(undefined4 *)(iVar2 + -8);
            uVar7 = *(undefined4 *)(iVar2 + -4);
            *puVar8 = *(undefined4 *)(iVar2 + -0x10);
            puVar8[1] = uVar5;
            puVar8[2] = uVar6;
            puVar8[3] = uVar7;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar2 = *(int64_t *)(iVar2 + -0x20);
                if (((*(uint8_t *)(iVar2 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar3 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar3 + 0x59) == '\x02') {
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
                        *(undefined8 *)(iVar2 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                        *(int64_t *)(iVar3 + 0x18) = iVar2;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        }
        piVar12 = piVar12 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800213d0
// Address: 0x1800213d0
// Size: 393 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2h

undefined8 fcn.1800213d0(int64_t arg1, int64_t arg_38h)
{
    int32_t iVar1;
    undefined8 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 *puVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    undefined *puVar15;
    undefined8 *puVar16;
    uint64_t uVar17;
    int64_t var_10h;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t iStack_48;
    
    func_0x000180086fd0(arg1, 0, 0);
    fcn.180020690((int64_t)&var_58h, arg1);
    puVar16 = (undefined8 *)var_58h;
    while( true ) {
        if (puVar16 == (undefined8 *)var_50h) {
            if (var_58h != 0) {
                uVar13 = var_58h;
                puVar15 = auStack_78;
                if (0xfff < (uint64_t)((iStack_48 - var_58h >> 3) * 8)) {
                    uVar13 = *(uint64_t *)(var_58h - 8);
                    uVar17 = (var_58h - uVar13) - 8;
                    puVar15 = auStack_78;
                    if (0x1f < uVar17) {
                        pcVar6 = (code *)swi(0x29);
                        (*pcVar6)(5);
                        uVar13 = uVar17;
                        puVar15 = auStack_70;
                    }
                }
                *(undefined8 *)(puVar15 + -8) = 0x180021541;
                fcn.180459c3c(uVar13);
            }
            return 1;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar2 = *(undefined8 **)(arg1 + 0x40);
        *puVar2 = *puVar16;
        *(undefined4 *)((int64_t)puVar2 + 0xc) = 10;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar1 = *(int32_t *)(arg1 + 0x60);
            iVar12 = (int32_t)(int32_t *)(arg1 + 0x60);
            iVar14 = iVar1 - iVar12;
            if (iVar1 - iVar12 < 1) {
                iVar14 = iVar14 + 1;
            } else {
                iVar14 = iVar14 * 2;
            }
            func_0x000180093240(arg1, iVar14, 0);
        }
        puVar3 = *(undefined4 **)(arg1 + 0x40);
        *(undefined4 **)(arg1 + 0x40) = puVar3 + 4;
        if (*(char *)(*(int64_t *)(puVar3 + -4) + 4) != '\0') break;
        puVar10 = (undefined4 *)func_0x0001800a1010();
        uVar7 = puVar3[1];
        uVar8 = puVar3[2];
        uVar9 = puVar3[3];
        *puVar10 = *puVar3;
        puVar10[1] = uVar7;
        puVar10[2] = uVar8;
        puVar10[3] = uVar9;
        if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
            iVar4 = *(int64_t *)(puVar3 + -4);
            if (((*(uint8_t *)(iVar4 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar5 = *(int64_t *)(arg1 + 0x20);
                if (*(char *)(iVar5 + 0x59) == '\x02') {
                    func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) & 0xfb;
                    *(undefined8 *)(iVar4 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                    *(int64_t *)(iVar5 + 0x18) = iVar4;
                }
            }
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        puVar16 = puVar16 + 1;
    }
    func_0x000180092f10(arg1);
    pcVar6 = (code *)swi(3);
    uVar11 = (*pcVar6)();
    return uVar11;
}

// ============================================================
// Function: FUN_180021560
// Address: 0x180021560
// Size: 168 bytes
// ============================================================
undefined8 fcn.180021560(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar3 = (int64_t *)func_0x000180008740();
    var_8h._0_4_ = 2;
    var_10h = 0;
    uVar4 = (**(code **)0x180782570)(*(undefined8 *)(*piVar3 + 0x20), &var_8h, &var_10h);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    *puVar1 = uVar4;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 10;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar5 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar2 = iVar5 * 2;
        if (iVar5 < 1) {
            iVar2 = iVar5 + 1;
        }
        func_0x000180093240(arg1, iVar2, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180021610
// Address: 0x180021610
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021610(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        func_0x000180088470(arg1, 1, 10);
        pcVar9 = (code *)swi(3);
        uVar7 = (*pcVar9)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 10) {
        iVar6 = *piVar5;
    } else {
        iVar6 = 0;
    }
    iVar6 = *(int64_t *)(iVar6 + 0x50);
    if (iVar6 == 0) {
        func_0x000180086510(arg1);
        return 1;
    }
    iVar3 = *(int64_t *)(iVar6 + 0x48);
    if ((iVar3 != 0) && (*(int32_t *)(iVar3 + 8) != 0)) {
        iVar2 = *(int32_t *)(iVar3 + 8);
        do {
            if (iVar2 == 0) goto code_r0x0001800216a2;
            LOCK();
            iVar4 = *(int32_t *)(iVar3 + 8);
            bVar10 = iVar2 == iVar4;
            if (bVar10) {
                *(int32_t *)(iVar3 + 8) = iVar2 + 1;
                iVar4 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar4;
        } while (!bVar10);
        iVar3 = *(int64_t *)(iVar6 + 0x40);
        piVar5 = *(int64_t **)(iVar6 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar8 = piVar5 + 1;
            iVar2 = *(int32_t *)piVar8;
            *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        if (iVar3 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar7 = func_0x0001800231b0((int64_t *)(iVar6 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar7);
            return 1;
        }
    }
code_r0x0001800216a2:
    func_0x000180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021679
// Address: 0x180021679
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021610(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        func_0x000180088470(arg1, 1, 10);
        pcVar9 = (code *)swi(3);
        uVar7 = (*pcVar9)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 10) {
        iVar6 = *piVar5;
    } else {
        iVar6 = 0;
    }
    iVar6 = *(int64_t *)(iVar6 + 0x50);
    if (iVar6 == 0) {
        func_0x000180086510(arg1);
        return 1;
    }
    iVar3 = *(int64_t *)(iVar6 + 0x48);
    if ((iVar3 != 0) && (*(int32_t *)(iVar3 + 8) != 0)) {
        iVar2 = *(int32_t *)(iVar3 + 8);
        do {
            if (iVar2 == 0) goto code_r0x0001800216a2;
            LOCK();
            iVar4 = *(int32_t *)(iVar3 + 8);
            bVar10 = iVar2 == iVar4;
            if (bVar10) {
                *(int32_t *)(iVar3 + 8) = iVar2 + 1;
                iVar4 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar4;
        } while (!bVar10);
        iVar3 = *(int64_t *)(iVar6 + 0x40);
        piVar5 = *(int64_t **)(iVar6 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar8 = piVar5 + 1;
            iVar2 = *(int32_t *)piVar8;
            *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        if (iVar3 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar7 = func_0x0001800231b0((int64_t *)(iVar6 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar7);
            return 1;
        }
    }
code_r0x0001800216a2:
    func_0x000180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800216ba
// Address: 0x1800216ba
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021610(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        func_0x000180088470(arg1, 1, 10);
        pcVar9 = (code *)swi(3);
        uVar7 = (*pcVar9)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 10) {
        iVar6 = *piVar5;
    } else {
        iVar6 = 0;
    }
    iVar6 = *(int64_t *)(iVar6 + 0x50);
    if (iVar6 == 0) {
        func_0x000180086510(arg1);
        return 1;
    }
    iVar3 = *(int64_t *)(iVar6 + 0x48);
    if ((iVar3 != 0) && (*(int32_t *)(iVar3 + 8) != 0)) {
        iVar2 = *(int32_t *)(iVar3 + 8);
        do {
            if (iVar2 == 0) goto code_r0x0001800216a2;
            LOCK();
            iVar4 = *(int32_t *)(iVar3 + 8);
            bVar10 = iVar2 == iVar4;
            if (bVar10) {
                *(int32_t *)(iVar3 + 8) = iVar2 + 1;
                iVar4 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar4;
        } while (!bVar10);
        iVar3 = *(int64_t *)(iVar6 + 0x40);
        piVar5 = *(int64_t **)(iVar6 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar8 = piVar5 + 1;
            iVar2 = *(int32_t *)piVar8;
            *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        if (iVar3 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar7 = func_0x0001800231b0((int64_t *)(iVar6 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar7);
            return 1;
        }
    }
code_r0x0001800216a2:
    func_0x000180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021715
// Address: 0x180021715
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021610(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        func_0x000180088470(arg1, 1, 10);
        pcVar9 = (code *)swi(3);
        uVar7 = (*pcVar9)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 10) {
        iVar6 = *piVar5;
    } else {
        iVar6 = 0;
    }
    iVar6 = *(int64_t *)(iVar6 + 0x50);
    if (iVar6 == 0) {
        func_0x000180086510(arg1);
        return 1;
    }
    iVar3 = *(int64_t *)(iVar6 + 0x48);
    if ((iVar3 != 0) && (*(int32_t *)(iVar3 + 8) != 0)) {
        iVar2 = *(int32_t *)(iVar3 + 8);
        do {
            if (iVar2 == 0) goto code_r0x0001800216a2;
            LOCK();
            iVar4 = *(int32_t *)(iVar3 + 8);
            bVar10 = iVar2 == iVar4;
            if (bVar10) {
                *(int32_t *)(iVar3 + 8) = iVar2 + 1;
                iVar4 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar4;
        } while (!bVar10);
        iVar3 = *(int64_t *)(iVar6 + 0x40);
        piVar5 = *(int64_t **)(iVar6 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar8 = piVar5 + 1;
            iVar2 = *(int32_t *)piVar8;
            *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        if (iVar3 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar7 = func_0x0001800231b0((int64_t *)(iVar6 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar7);
            return 1;
        }
    }
code_r0x0001800216a2:
    func_0x000180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021742
// Address: 0x180021742
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021610(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar8 = piVar5;
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 10)) {
        func_0x000180088470(arg1, 1, 10);
        pcVar9 = (code *)swi(3);
        uVar7 = (*pcVar9)();
        return uVar7;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar5) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 10) {
        iVar6 = *piVar5;
    } else {
        iVar6 = 0;
    }
    iVar6 = *(int64_t *)(iVar6 + 0x50);
    if (iVar6 == 0) {
        func_0x000180086510(arg1);
        return 1;
    }
    iVar3 = *(int64_t *)(iVar6 + 0x48);
    if ((iVar3 != 0) && (*(int32_t *)(iVar3 + 8) != 0)) {
        iVar2 = *(int32_t *)(iVar3 + 8);
        do {
            if (iVar2 == 0) goto code_r0x0001800216a2;
            LOCK();
            iVar4 = *(int32_t *)(iVar3 + 8);
            bVar10 = iVar2 == iVar4;
            if (bVar10) {
                *(int32_t *)(iVar3 + 8) = iVar2 + 1;
                iVar4 = iVar2;
            }
            UNLOCK();
            iVar2 = iVar4;
        } while (!bVar10);
        iVar3 = *(int64_t *)(iVar6 + 0x40);
        piVar5 = *(int64_t **)(iVar6 + 0x48);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar8 = piVar5 + 1;
            iVar2 = *(int32_t *)piVar8;
            *(int32_t *)piVar8 = *(int32_t *)piVar8 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)*piVar5)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*piVar5 + 8))(piVar5);
                }
            }
        }
        if (iVar3 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar7 = func_0x0001800231b0((int64_t *)(iVar6 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar7);
            return 1;
        }
    }
code_r0x0001800216a2:
    func_0x000180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021760
// Address: 0x180021760
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021760(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)(arg1 + 0x50);
    if (iVar4 == 0) {
        fcn.180086510();
        return 1;
    }
    iVar5 = *(int64_t *)(iVar4 + 0x48);
    if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 8) != 0)) {
        iVar3 = *(int32_t *)(iVar5 + 8);
        do {
            if (iVar3 == 0) goto code_r0x0001800217af;
            LOCK();
            iVar7 = *(int32_t *)(iVar5 + 8);
            bVar10 = iVar3 == iVar7;
            if (bVar10) {
                *(int32_t *)(iVar5 + 8) = iVar3 + 1;
                iVar7 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar7;
        } while (!bVar10);
        iVar5 = *(int64_t *)(iVar4 + 0x40);
        piVar6 = *(int64_t **)(iVar4 + 0x48);
        if (piVar6 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar6 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar6)(piVar6);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar6 + 8))(piVar6);
                }
            }
        }
        if (iVar5 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar8 = fcn.1800231b0((int64_t *)(iVar4 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar8);
            return 1;
        }
    }
code_r0x0001800217af:
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021786
// Address: 0x180021786
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021760(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)(arg1 + 0x50);
    if (iVar4 == 0) {
        fcn.180086510();
        return 1;
    }
    iVar5 = *(int64_t *)(iVar4 + 0x48);
    if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 8) != 0)) {
        iVar3 = *(int32_t *)(iVar5 + 8);
        do {
            if (iVar3 == 0) goto code_r0x0001800217af;
            LOCK();
            iVar7 = *(int32_t *)(iVar5 + 8);
            bVar10 = iVar3 == iVar7;
            if (bVar10) {
                *(int32_t *)(iVar5 + 8) = iVar3 + 1;
                iVar7 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar7;
        } while (!bVar10);
        iVar5 = *(int64_t *)(iVar4 + 0x40);
        piVar6 = *(int64_t **)(iVar4 + 0x48);
        if (piVar6 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar6 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar6)(piVar6);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar6 + 8))(piVar6);
                }
            }
        }
        if (iVar5 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar8 = fcn.1800231b0((int64_t *)(iVar4 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar8);
            return 1;
        }
    }
code_r0x0001800217af:
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_1800217c7
// Address: 0x1800217c7
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021760(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)(arg1 + 0x50);
    if (iVar4 == 0) {
        fcn.180086510();
        return 1;
    }
    iVar5 = *(int64_t *)(iVar4 + 0x48);
    if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 8) != 0)) {
        iVar3 = *(int32_t *)(iVar5 + 8);
        do {
            if (iVar3 == 0) goto code_r0x0001800217af;
            LOCK();
            iVar7 = *(int32_t *)(iVar5 + 8);
            bVar10 = iVar3 == iVar7;
            if (bVar10) {
                *(int32_t *)(iVar5 + 8) = iVar3 + 1;
                iVar7 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar7;
        } while (!bVar10);
        iVar5 = *(int64_t *)(iVar4 + 0x40);
        piVar6 = *(int64_t **)(iVar4 + 0x48);
        if (piVar6 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar6 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar6)(piVar6);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar6 + 8))(piVar6);
                }
            }
        }
        if (iVar5 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar8 = fcn.1800231b0((int64_t *)(iVar4 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar8);
            return 1;
        }
    }
code_r0x0001800217af:
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021822
// Address: 0x180021822
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180021760(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    undefined8 uVar8;
    code *pcVar9;
    bool bVar10;
    int64_t var_10h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar4 = *(int64_t *)(arg1 + 0x50);
    if (iVar4 == 0) {
        fcn.180086510();
        return 1;
    }
    iVar5 = *(int64_t *)(iVar4 + 0x48);
    if ((iVar5 != 0) && (*(int32_t *)(iVar5 + 8) != 0)) {
        iVar3 = *(int32_t *)(iVar5 + 8);
        do {
            if (iVar3 == 0) goto code_r0x0001800217af;
            LOCK();
            iVar7 = *(int32_t *)(iVar5 + 8);
            bVar10 = iVar3 == iVar7;
            if (bVar10) {
                *(int32_t *)(iVar5 + 8) = iVar3 + 1;
                iVar7 = iVar3;
            }
            UNLOCK();
            iVar3 = iVar7;
        } while (!bVar10);
        iVar5 = *(int64_t *)(iVar4 + 0x40);
        piVar6 = *(int64_t **)(iVar4 + 0x48);
        if (piVar6 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar6 + 1;
            iVar3 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar6)(piVar6);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar6 + 8))(piVar6);
                }
            }
        }
        if (iVar5 != 0) {
            pcVar9 = *(code **)0x180782630;
            uVar8 = fcn.1800231b0((int64_t *)(iVar4 + 0x40), &var_28h);
            (*pcVar9)(arg1, uVar8);
            return 1;
        }
    }
code_r0x0001800217af:
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180021850
// Address: 0x180021850
// Size: 51 bytes
// ============================================================
undefined8 fcn.180021850(int64_t arg1)
{
    fcn.180018f70();
    fcn.180086b20(arg1, *(undefined *)(*(int64_t *)(*(int64_t *)(arg1 + 0x50) + 0x98) + 0x118));
    return 1;
}

// ============================================================
// Function: FUN_180021890
// Address: 0x180021890
// Size: 317 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180021890(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar5 = (int32_t)arg3;
    uVar4 = (uint64_t)iVar5;
    uVar6 = *(uint64_t *)0x180782430;
    if (iVar5 < 1) {
        if (iVar5 < -9999) {
            uVar3 = func_0x000180085370(arg1, arg3 & 0xffffffff);
        } else {
            uVar3 = uVar4 * 0x10 + *(int64_t *)(arg1 + 0x40);
        }
    } else {
        uVar3 = *(int64_t *)(arg1 + 0x28) + -0x10 + uVar4 * 0x10;
        if (*(uint64_t *)(arg1 + 0x40) <= uVar3) {
            uVar3 = *(uint64_t *)0x180782430;
        }
    }
    if ((uVar3 == uVar6) || (*(int32_t *)(uVar3 + 0xc) != 7)) {
        func_0x0001800219d0(arg1, arg2, arg3 & 0xffffffff);
    } else {
        if (iVar5 < 0) {
            uVar4 = (uint64_t)
                    (uint32_t)(iVar5 + 1 + (int32_t)(*(int64_t *)(arg1 + 0x40) - *(int64_t *)(arg1 + 0x28) >> 4));
        }
        iVar5 = (int32_t)arg4;
        if (iVar5 < 0x21) {
            func_0x000180086fd0(arg2, 0, 0);
            fcn.180086510(arg1);
            iVar2 = func_0x000180087970(arg1, uVar4 & 0xffffffff);
            while (iVar2 != 0) {
                fcn.180021890(arg1, arg2, 0xfffffffe, (uint64_t)(iVar5 + 1));
                fcn.180021890(arg1, arg2, 0xffffffff, (uint64_t)(iVar5 + 1));
                iVar1 = *(int64_t *)(arg2 + 0x40);
                func_0x0001800a8680(arg2, iVar1 + -0x30, iVar1 + -0x20, iVar1 + -0x10);
                *(int64_t *)(arg2 + 0x40) = *(int64_t *)(arg2 + 0x40) + -0x20;
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar2 = func_0x000180087970(arg1, uVar4 & 0xffffffff);
            }
        }
    }
    return;
}

