// Chunk 195 - 50 functions

// ============================================================
// Function: FUN_18025f2b0
// Address: 0x18025f2b0
// Size: 63 bytes
// ============================================================
undefined8 fcn.18025f2b0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f2bc;
    iVar1 = fcn.18045a350();
    if (*(int64_t *)(param_1 + 0x58) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18025f2d6;
    uVar2 = fcn.18001ed90();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18025f2de;
    uVar2 = fcn.18027e810(uVar2);
    // WARNING: Could not recover jumptable at 0x00018025f2ec. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(param_1 + 0x58))(0, uVar2, *(code **)(param_1 + 0x58));
    return uVar2;
}

// ============================================================
// Function: FUN_18025f2f0
// Address: 0x18025f2f0
// Size: 63 bytes
// ============================================================
undefined8 fcn.18025f2f0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f2fc;
    iVar1 = fcn.18045a350();
    if (*(int64_t *)(param_1 + 0x60) == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18025f316;
    uVar2 = fcn.18001ed90();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x18025f31e;
    uVar2 = fcn.18027e810(uVar2);
    // WARNING: Could not recover jumptable at 0x00018025f32c. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(param_1 + 0x60))(0, uVar2, *(code **)(param_1 + 0x60));
    return uVar2;
}

// ============================================================
// Function: FUN_18025f330
// Address: 0x18025f330
// Size: 94 bytes
// ============================================================
void fcn.18025f330(int64_t arg1)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025f340;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        puVar1 = (undefined8 *)(arg1 + 0x20);
        iVar2 = *(int32_t *)puVar1;
        *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025f36b;
            fcn.180224990(uVar3, 0x1804e6a98, 0x28);
            uVar3 = *(undefined8 *)arg1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025f373;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025f388;
            fcn.180224990(arg1, 0x1804e6a98, 0x2b);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18025f390
// Address: 0x18025f390
// Size: 776 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t * fcn.18025f390(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                       int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined4 in_ECX;
    int64_t in_RDX;
    int64_t *piVar7;
    int64_t in_R8;
    int32_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18025f3b4;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar3 = 0;
    iVar8 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f3e0;
    piVar5 = (int64_t *)func_0x000180224d60(0x90, 0x1804e6a98, 0x32);
    if (piVar5 == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f614;
        fcn.180224990(0, 0x1804e6a98, 0x34);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f619;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f631;
        func_0x0001802295a0(0x1804e6a98, 0x43, 0x1804e6ab0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f643;
        func_0x0001802296d0(6, 0x80006, 0);
        return (int64_t *)0x0;
    }
    *(undefined4 *)(piVar5 + 4) = 1;
    *(undefined4 *)(piVar5 + 1) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f3fe;
    iVar6 = func_0x000180282210(in_RDX);
    piVar5[2] = iVar6;
    if (iVar6 != 0) {
        piVar5[3] = *(int64_t *)(in_RDX + 0x18);
        iVar2 = *piVar1;
        if (iVar2 != 0) {
            piVar7 = (int64_t *)(piVar1 + 2);
            do {
    // switch table (13 cases) at 0x18025f664
                switch(iVar2) {
                case 1:
                    if (piVar5[5] == 0) {
                        iVar8 = iVar8 + 1;
                        piVar5[5] = *piVar7;
                    }
                    break;
                case 2:
                    if (piVar5[6] == 0) {
                        piVar5[6] = *piVar7;
                    }
                    break;
                case 3:
                    if (piVar5[7] == 0) {
                        iVar8 = iVar8 + 1;
                        piVar5[7] = *piVar7;
                    }
                    break;
                case 4:
                    if (piVar5[8] == 0) {
                        piVar5[8] = *piVar7;
                    }
                    break;
                case 5:
                    if (piVar5[9] == 0) {
                        iVar3 = iVar3 + 1;
                        piVar5[9] = *piVar7;
                    }
                    break;
                case 6:
                    if (piVar5[10] == 0) {
                        piVar5[10] = *piVar7;
                    }
                    break;
                case 7:
                    if (piVar5[0xb] == 0) {
                        piVar5[0xb] = *piVar7;
                    }
                    break;
                case 8:
                    if (piVar5[0xc] == 0) {
                        piVar5[0xc] = *piVar7;
                    }
                    break;
                case 9:
                    if (piVar5[0xd] == 0) {
                        piVar5[0xd] = *piVar7;
                    }
                    break;
                case 10:
                    if (piVar5[0xe] == 0) {
                        piVar5[0xe] = *piVar7;
                    }
                    break;
                case 0xb:
                    if (piVar5[0xf] == 0) {
                        piVar5[0xf] = *piVar7;
                    }
                    break;
                case 0xc:
                    if (piVar5[0x10] == 0) {
                        piVar5[0x10] = *piVar7;
                    }
                    break;
                case 0xd:
                    if (piVar5[0x11] == 0) {
                        piVar5[0x11] = *piVar7;
                    }
                }
                iVar2 = *(int32_t *)(piVar7 + 1);
                piVar7 = piVar7 + 2;
            } while (iVar2 != 0);
            if ((iVar3 == 1) && (iVar8 == 2)) {
                if (in_R8 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f57c;
                    iVar3 = func_0x00018027fb30(in_R8);
                    if (iVar3 == 0) goto code_r0x00018025f5bb;
                }
                *piVar5 = in_R8;
                return piVar5;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f591;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f5a9;
        func_0x0001802295a0(0x1804e6a98, 0x9d, 0x1804e6ab0);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f5bb;
        func_0x0001802296d0(6, 0xc1, 0);
    }
code_r0x00018025f5bb:
    LOCK();
    piVar7 = piVar5 + 4;
    iVar3 = *(int32_t *)piVar7;
    *(int32_t *)piVar7 = *(int32_t *)piVar7 + -1;
    UNLOCK();
    if (iVar3 < 2) {
        iVar6 = piVar5[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f5e0;
        fcn.180224990(iVar6, 0x1804e6a98, 0x28);
        iVar6 = *piVar5;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f5e8;
        fcn.18027edb0(iVar6);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025f5fd;
        fcn.180224990(piVar5, 0x1804e6a98, 0x2b);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18025f6a0
// Address: 0x18025f6a0
// Size: 249 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.18025f6a0(int64_t arg_28h)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    int64_t *in_RCX;
    undefined8 uVar9;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f6b0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (((in_RCX != (int64_t *)0x0) && (in_RCX[1] != 0)) && (*(int64_t *)(*in_RCX + 0x30) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f6e7;
        piVar7 = (int64_t *)
                 fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                               *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
        if (piVar7 != (int64_t *)0x0) {
            uVar2 = *(undefined4 *)((int64_t)in_RCX + 4);
            uVar3 = *(undefined4 *)(in_RCX + 1);
            uVar4 = *(undefined4 *)((int64_t)in_RCX + 0xc);
            *(undefined4 *)piVar7 = *(undefined4 *)in_RCX;
            *(undefined4 *)((int64_t)piVar7 + 4) = uVar2;
            *(undefined4 *)(piVar7 + 1) = uVar3;
            *(undefined4 *)((int64_t)piVar7 + 0xc) = uVar4;
            iVar8 = *piVar7;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f6fd;
            iVar5 = fcn.180248230(iVar8);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f706;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f71e;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f730;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar6));
                uVar9 = 0x46;
            } else {
                iVar8 = in_RCX[1];
                pcVar1 = *(code **)(*in_RCX + 0x30);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f75f;
                iVar8 = (*pcVar1)(iVar8);
                piVar7[1] = iVar8;
                if (iVar8 != 0) {
                    return piVar7;
                }
                pcVar1 = *(code **)(*piVar7 + 0x38);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f773;
                (*pcVar1)(0);
                iVar8 = *piVar7;
                piVar7[1] = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f783;
                fcn.18025f250(iVar8);
                uVar9 = 0x35;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18025f745;
            fcn.180224990(piVar7, 0x1804e6ac8, uVar9);
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18025f7a0
// Address: 0x18025f7a0
// Size: 78 bytes
// ============================================================
void fcn.18025f7a0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18025f7b0;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        iVar1 = *(int64_t *)(arg1 + 8);
        pcVar2 = *(code **)(*(int64_t *)arg1 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f7c3;
        (*pcVar2)(iVar1);
        iVar1 = *(int64_t *)arg1;
        *(int64_t *)(arg1 + 8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f7d3;
        fcn.18025f250(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f7e8;
        fcn.180224990(arg1, 0x1804e6ac8, 0x35);
    }
    return;
}

// ============================================================
// Function: FUN_18025f7f0
// Address: 0x18025f7f0
// Size: 225 bytes
// ============================================================
undefined8
fcn.18025f7f0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a8h, int64_t arg_158h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t *in_RCX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f7fc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = 0;
    if (in_RCX != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025f866;
        puVar8 = (undefined4 *)func_0x000180229cc0((int64_t)&var_18h + iVar7, 0x18063dcac, (int64_t)&arg_a8h + iVar7);
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
        *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
        uVar3 = puVar8[5];
        uVar4 = puVar8[6];
        uVar5 = puVar8[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
        iVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
        pcVar2 = *(code **)(iVar1 + 0x70);
        if (pcVar2 != (code *)0x0) {
            iVar1 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025f89a;
            iVar6 = (*pcVar2)(iVar1, (int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) goto code_r0x00018025f8b5;
        }
        pcVar2 = *(code **)(*in_RCX + 0x68);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025f8b1;
            iVar6 = (*pcVar2)((int64_t)&arg_48h + iVar7);
            if (iVar6 != 0) {
code_r0x00018025f8b5:
                return *(undefined8 *)((int64_t)&arg_a8h + iVar7);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18025f8e0
// Address: 0x18025f8e0
// Size: 46 bytes
// ============================================================
undefined8 fcn.18025f8e0(int64_t *param_1)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(*param_1 + 0x70) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018025f901. Too many branches
    // WARNING: Treating indirect jump as call
        uVar1 = (**(code **)(*param_1 + 0x70))(param_1[1]);
        return uVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18025f910
// Address: 0x18025f910
// Size: 37 bytes
// ============================================================
undefined8 * fcn.18025f910(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f91c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f94b;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f964;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f969;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f97f;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                *puVar4 = in_RCX;
                return puVar4;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f999;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9b1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9c3;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9d2;
        (*pcVar1)(uVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9e7;
    fcn.180224990(puVar4, 0x1804e6ac8, 0x26);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025f935
// Address: 0x18025f935
// Size: 33 bytes
// ============================================================
undefined8 * fcn.18025f910(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f91c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f94b;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f964;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f969;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f97f;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                *puVar4 = in_RCX;
                return puVar4;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f999;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9b1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9c3;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9d2;
        (*pcVar1)(uVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9e7;
    fcn.180224990(puVar4, 0x1804e6ac8, 0x26);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025f956
// Address: 0x18025f956
// Size: 33 bytes
// ============================================================
undefined8 * fcn.18025f910(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f91c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f94b;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f964;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f969;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f97f;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                *puVar4 = in_RCX;
                return puVar4;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f999;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9b1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9c3;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9d2;
        (*pcVar1)(uVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9e7;
    fcn.180224990(puVar4, 0x1804e6ac8, 0x26);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025f977
// Address: 0x18025f977
// Size: 29 bytes
// ============================================================
undefined8 * fcn.18025f910(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f91c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f94b;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f964;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f969;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f97f;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                *puVar4 = in_RCX;
                return puVar4;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f999;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9b1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9c3;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9d2;
        (*pcVar1)(uVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9e7;
    fcn.180224990(puVar4, 0x1804e6ac8, 0x26);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025f994
// Address: 0x18025f994
// Size: 98 bytes
// ============================================================
undefined8 * fcn.18025f910(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025f91c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == (undefined8 *)0x0) {
        return (undefined8 *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f94b;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f964;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f969;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f97f;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                *puVar4 = in_RCX;
                return puVar4;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f999;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9b1;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9c3;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9d2;
        (*pcVar1)(uVar5);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025f9e7;
    fcn.180224990(puVar4, 0x1804e6ac8, 0x26);
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_18025fa00
// Address: 0x18025fa00
// Size: 46 bytes
// ============================================================
undefined8 fcn.18025fa00(int64_t *param_1)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(*param_1 + 0x78) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x00018025fa21. Too many branches
    // WARNING: Treating indirect jump as call
        uVar1 = (**(code **)(*param_1 + 0x78))(param_1[1]);
        return uVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_18025fa30
// Address: 0x18025fa30
// Size: 43 bytes
// ============================================================
undefined8 fcn.18025fa30(int64_t *param_1)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (param_1 == (int64_t *)0x0) {
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x00018025fa58. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(*param_1 + 0x48))(param_1[1]);
    return uVar1;
}

// ============================================================
// Function: FUN_18025fa60
// Address: 0x18025fa60
// Size: 190 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180296560: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180296565)

int32_t fcn.18025fa60(int64_t arg_30h, int64_t arg_50h)
{
    int32_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int32_t *in_RCX;
    int32_t *piVar7;
    uint64_t *puVar8;
    int32_t *in_RDX;
    int32_t *piVar9;
    int64_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint64_t uVar11;
    uint64_t uVar12;
    bool bVar13;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == (int32_t *)0x0) || (in_RDX == (int32_t *)0x0)) || (*in_RCX != *in_RDX)) {
        return -1;
    }
    // switch table (34 cases) at 0x18025fae8
    switch(*in_RCX) {
    case 1:
        return in_RCX[2] - in_RDX[2];
    case 5:
        return 0;
    case 6:
        iVar10 = *(int64_t *)(in_RDX + 2);
        iVar5 = *(int64_t *)(in_RCX + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = 0x18029838a;
        fcn.18045a350();
        iVar1 = *(int32_t *)(iVar5 + 0x14);
        iVar3 = iVar1 - *(int32_t *)(iVar10 + 0x14);
        if (iVar3 != 0) {
            return iVar3;
        }
        iVar10 = *(int64_t *)(iVar10 + 0x18);
        puVar8 = *(uint64_t **)(iVar5 + 0x18);
code_r0x000180497f30:
        uVar11 = (uint64_t)iVar1;
        iVar10 = iVar10 - (int64_t)puVar8;
        if (7 < uVar11) {
            for (; ((uint64_t)puVar8 & 7) != 0; puVar8 = (uint64_t *)((int64_t)puVar8 + 1)) {
                bVar13 = *(uint8_t *)puVar8 < *(uint8_t *)((int64_t)puVar8 + iVar10);
                if (*(uint8_t *)puVar8 != *(uint8_t *)((int64_t)puVar8 + iVar10)) goto code_r0x000180497f73;
                uVar11 = uVar11 - 1;
            }
            if (uVar11 >> 3 != 0) {
                uVar12 = uVar11 >> 5;
                if (uVar12 != 0) {
                    do {
                        uVar6 = *puVar8;
                        if (uVar6 != *(uint64_t *)((int64_t)puVar8 + iVar10)) goto code_r0x000180497fe4;
                        uVar6 = puVar8[1];
                        if (uVar6 != *(uint64_t *)((int64_t)puVar8 + iVar10 + 8)) {
code_r0x000180497fe0:
                            puVar8 = puVar8 + 1;
                            goto code_r0x000180497fe4;
                        }
                        uVar6 = puVar8[2];
                        if (uVar6 != *(uint64_t *)((int64_t)puVar8 + iVar10 + 0x10)) {
code_r0x000180497fdc:
                            puVar8 = puVar8 + 1;
                            goto code_r0x000180497fe0;
                        }
                        uVar6 = puVar8[3];
                        if (uVar6 != *(uint64_t *)((int64_t)puVar8 + iVar10 + 0x18)) {
                            puVar8 = puVar8 + 1;
                            goto code_r0x000180497fdc;
                        }
                        puVar8 = puVar8 + 4;
                        uVar12 = uVar12 - 1;
                    } while (uVar12 != 0);
                    uVar11 = uVar11 & 0x1f;
                }
                uVar12 = uVar11 >> 3;
                if (uVar12 != 0) {
                    do {
                        uVar6 = *puVar8;
                        if (uVar6 != *(uint64_t *)((int64_t)puVar8 + iVar10)) {
code_r0x000180497fe4:
                            uVar11 = *(uint64_t *)(iVar10 + (int64_t)puVar8);
                            uVar2 = (uint32_t)
                                    ((uVar6 >> 0x38 | (uVar6 & 0xff000000000000) >> 0x28 |
                                      (uVar6 & 0xff0000000000) >> 0x18 | (uVar6 & 0xff00000000) >> 8 |
                                      (uVar6 & 0xff000000) << 8 | (uVar6 & 0xff0000) << 0x18 | (uVar6 & 0xff00) << 0x28
                                     | uVar6 << 0x38) <
                                    (uVar11 >> 0x38 | (uVar11 & 0xff000000000000) >> 0x28 |
                                     (uVar11 & 0xff0000000000) >> 0x18 | (uVar11 & 0xff00000000) >> 8 |
                                     (uVar11 & 0xff000000) << 8 | (uVar11 & 0xff0000) << 0x18 |
                                     (uVar11 & 0xff00) << 0x28 | uVar11 << 0x38));
                            return (1 - uVar2) - (uint32_t)(uVar2 != 0);
                        }
                        puVar8 = puVar8 + 1;
                        uVar12 = uVar12 - 1;
                    } while (uVar12 != 0);
                    uVar11 = uVar11 & 7;
                }
            }
        }
        while( true ) {
            if (uVar11 == 0) {
                return 0;
            }
            bVar13 = *(uint8_t *)puVar8 < *(uint8_t *)((int64_t)puVar8 + iVar10);
            if (*(uint8_t *)puVar8 != *(uint8_t *)((int64_t)puVar8 + iVar10)) break;
            puVar8 = (uint64_t *)((int64_t)puVar8 + 1);
            uVar11 = uVar11 - 1;
        }
code_r0x000180497f73:
        return (1 - (uint32_t)bVar13) - (uint32_t)(bVar13 != 0);
    }
    piVar9 = *(int32_t **)(in_RDX + 2);
    piVar7 = *(int32_t **)(in_RCX + 2);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x180296540;
    iVar5 = fcn.18045a350();
    iVar1 = *piVar7;
    iVar3 = iVar1 - *piVar9;
    if (iVar3 == 0) {
        if (iVar1 != 0) {
            iVar10 = *(int64_t *)(piVar9 + 2);
            puVar8 = *(uint64_t **)(piVar7 + 2);
            *(undefined8 *)((int64_t)auStackX_18 + (iVar4 - iVar5)) = 0x180296565;
            goto code_r0x000180497f30;
        }
        iVar3 = piVar7[1] - piVar9[1];
    }
    return iVar3;
}

// ============================================================
// Function: FUN_18025fb40
// Address: 0x18025fb40
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t * fcn.18025fb40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    undefined8 unaff_RBX;
    int32_t **in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025fb50;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fb67;
    iVar2 = fcn.1802ae820(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1));
    if (iVar2 == 0) {
        return (int32_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    if ((in_R8 == (int32_t **)0x0) || (piVar3 = *in_R8, piVar3 == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fb91;
        piVar3 = (int32_t *)
                 fcn.180228960(*(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
        if (piVar3 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fba1;
            fcn.180228780(*(int64_t *)((int64_t)&arg_40h + iVar1));
            return (int32_t *)0x0;
        }
        if (in_R8 != (int32_t **)0x0) {
            *in_R8 = piVar3;
        }
    }
    *(int32_t **)((int64_t)&arg_40h + iVar1) = piVar3;
    piVar4 = piVar3;
    if (((*piVar3 != 1) && (*piVar3 != 5)) && (*(int64_t *)(piVar3 + 2) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fbe5;
        fcn.180261550(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        piVar4 = *(int32_t **)((int64_t)&arg_40h + iVar1);
    }
    *piVar4 = 0x10;
    *(int64_t *)(*(int64_t *)((int64_t)&arg_40h + iVar1) + 8) = iVar2;
    return piVar3;
}

// ============================================================
// Function: FUN_18025fb7a
// Address: 0x18025fb7a
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t * fcn.18025fb40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    undefined8 unaff_RBX;
    int32_t **in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025fb50;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fb67;
    iVar2 = fcn.1802ae820(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1));
    if (iVar2 == 0) {
        return (int32_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    if ((in_R8 == (int32_t **)0x0) || (piVar3 = *in_R8, piVar3 == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fb91;
        piVar3 = (int32_t *)
                 fcn.180228960(*(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
        if (piVar3 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fba1;
            fcn.180228780(*(int64_t *)((int64_t)&arg_40h + iVar1));
            return (int32_t *)0x0;
        }
        if (in_R8 != (int32_t **)0x0) {
            *in_R8 = piVar3;
        }
    }
    *(int32_t **)((int64_t)&arg_40h + iVar1) = piVar3;
    piVar4 = piVar3;
    if (((*piVar3 != 1) && (*piVar3 != 5)) && (*(int64_t *)(piVar3 + 2) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fbe5;
        fcn.180261550(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        piVar4 = *(int32_t **)((int64_t)&arg_40h + iVar1);
    }
    *piVar4 = 0x10;
    *(int64_t *)(*(int64_t *)((int64_t)&arg_40h + iVar1) + 8) = iVar2;
    return piVar3;
}

// ============================================================
// Function: FUN_18025fbb3
// Address: 0x18025fbb3
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t * fcn.18025fb40(int64_t arg_28h, int64_t arg_30h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    undefined8 unaff_RBX;
    int32_t **in_R8;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025fb50;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fb67;
    iVar2 = fcn.1802ae820(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1));
    if (iVar2 == 0) {
        return (int32_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RBX;
    if ((in_R8 == (int32_t **)0x0) || (piVar3 = *in_R8, piVar3 == (int32_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fb91;
        piVar3 = (int32_t *)
                 fcn.180228960(*(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
        if (piVar3 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fba1;
            fcn.180228780(*(int64_t *)((int64_t)&arg_40h + iVar1));
            return (int32_t *)0x0;
        }
        if (in_R8 != (int32_t **)0x0) {
            *in_R8 = piVar3;
        }
    }
    *(int32_t **)((int64_t)&arg_40h + iVar1) = piVar3;
    piVar4 = piVar3;
    if (((*piVar3 != 1) && (*piVar3 != 5)) && (*(int64_t *)(piVar3 + 2) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fbe5;
        fcn.180261550(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        piVar4 = *(int32_t **)((int64_t)&arg_40h + iVar1);
    }
    *piVar4 = 0x10;
    *(int64_t *)(*(int64_t *)((int64_t)&arg_40h + iVar1) + 8) = iVar2;
    return piVar3;
}

// ============================================================
// Function: FUN_18025fc10
// Address: 0x18025fc10
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18025fc10(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int32_t in_EDX;
    int64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025fc25;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (((*(int32_t *)arg1 != 1) && (*(int32_t *)arg1 != 5)) && (*(int64_t *)(arg1 + 8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025fc4f;
        fcn.180261550(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
        arg1 = *(int64_t *)((int64_t)&arg_28h + iVar1);
    }
    *(int32_t *)arg1 = in_EDX;
    if (in_EDX == 1) {
        *(uint32_t *)(*(int64_t *)((int64_t)&arg_28h + iVar1) + 8) = -(uint32_t)(in_R8 != 0) & 0xff;
        return;
    }
    *(int64_t *)(*(int64_t *)((int64_t)&arg_28h + iVar1) + 8) = in_R8;
    return;
}

// ============================================================
// Function: FUN_18025fc90
// Address: 0x18025fc90
// Size: 54 bytes
// ============================================================
int64_t fcn.18025fc90(int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (((in_RDX != (int32_t *)0x0) && (*in_RDX == 0x10)) && (iVar3 = *(int64_t *)(in_RDX + 2), iVar3 != 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x1802ae95c;
        iVar2 = fcn.18045a350(iVar3, in_RCX);
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&arg_50h + iVar2 + iVar1) = *(undefined8 *)(iVar3 + 8);
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x1802ae97a;
        iVar3 = fcn.180261770(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar1), 
                              *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000060 + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000068 + iVar2 + iVar1), 
                              *(int64_t *)(&stack0x00000080 + iVar2 + iVar1));
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x1802ae987;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x1802ae99f;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                          , *(int64_t *)((int64_t)&arg_50h + iVar2 + iVar1), 
                          *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000070 + iVar2 + iVar1)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x1802ae9b1;
            fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
        }
        return iVar3;
    }
    return 0;
}

// ============================================================
// Function: FUN_18025fcd0
// Address: 0x18025fcd0
// Size: 95 bytes
// ============================================================
int64_t fcn.18025fcd0(int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *in_RCX;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025fcda;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == (int32_t *)0x0) {
        return 0;
    }
    if (((in_RCX[1] & 0xfffffeffU) == 10) && (*in_RCX < 5)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fd0a;
        iVar1 = fcn.180260030((int64_t)&arg_30h + iVar2, in_RCX, 10);
        if ((iVar1 != 0) && (*(int64_t *)((int64_t)&arg_30h + iVar2) + 0x80000000U < 0x100000000)) {
            return *(int64_t *)((int64_t)&arg_30h + iVar2);
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_18025fd30
// Address: 0x18025fd30
// Size: 28 bytes
// ============================================================
undefined8 fcn.18025fd30(uint64_t *param_1, int32_t *param_2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    uint64_t uVar9;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = 10;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18026003a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == uVar8) {
        uVar9 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
        if (uVar9 < 9) {
            if (iVar2 != 0) {
                uVar5 = 0;
                uVar6 = uVar5;
                if (uVar9 != 0) {
                    do {
                        uVar7 = uVar6 + 1;
                        uVar5 = uVar5 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar6);
                        uVar6 = uVar7;
                    } while (uVar7 < uVar9);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar5) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar5;
                    return 1;
                }
                if (0x8000000000000000 < uVar5) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
                    return 0;
                }
                *param_1 = -uVar5;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), *(int64_t *)(&stack0x00000078 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18025fd50
// Address: 0x18025fd50
// Size: 28 bytes
// ============================================================
int64_t fcn.18025fd50(int64_t arg_50h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint32_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802602ac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX[1] & 0xfffffeff) != uVar6) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602c3;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602db;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602ed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_RBX;
    uVar1 = *in_RCX;
    uVar2 = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260308;
    iVar5 = fcn.180254c30(uVar2, uVar1, in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260315;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026032d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026033f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    if ((in_RCX[1] & 0x100) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260362;
        fcn.180255840(iVar5, 1);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18025fd70
// Address: 0x18025fd70
// Size: 77 bytes
// ============================================================
int32_t fcn.18025fd70(int64_t param_1, int64_t param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025fd7c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar3 = *(uint32_t *)(param_1 + 4) & 0x100;
    if (uVar3 != (*(uint32_t *)(param_2 + 4) & 0x100)) {
        iVar1 = 1;
        if (uVar3 != 0) {
            iVar1 = -1;
        }
        return iVar1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025fdae;
    iVar1 = fcn.180296530(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2));
    if (uVar3 != 0) {
        iVar1 = -iVar1;
    }
    return iVar1;
}

// ============================================================
// Function: FUN_18025fdc0
// Address: 0x18025fdc0
// Size: 22 bytes
// ============================================================
int32_t * fcn.18025fdc0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                       int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1802966d0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802966f6;
    piVar6 = (int32_t *)fcn.180224d60(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4));
    if (piVar6 == (int32_t *)0x0) {
        return (int32_t *)0x0;
    }
    piVar6[1] = 4;
    piVar6[1] = in_RCX[1];
    uVar7 = (uint64_t)*in_RCX;
    iVar2 = *(int64_t *)(in_RCX + 2);
    if (*in_RCX < 0) {
        if (iVar2 == 0) goto code_r0x0001802967a6;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18029672b;
        uVar7 = func_0x000180498cd0(iVar2);
    }
    if (0x7ffffffe < uVar7) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x18029673b;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180296753;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180296765;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
code_r0x0001802967a6:
        uVar1 = piVar6[4];
        if ((uVar1 & 0x10) == 0) {
            uVar3 = *(undefined8 *)(piVar6 + 2);
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802967cb;
            fcn.180224990(uVar3, 0x1804ed9c0, 0x16f);
        }
        if ((uVar1 & 0x80) == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802967e4;
            fcn.180224990(piVar6, 0x1804ed9c0, 0x171);
        }
        return (int32_t *)0x0;
    }
    if (((uint64_t)(int64_t)*piVar6 <= uVar7) || (iVar8 = *(int64_t *)(piVar6 + 2), iVar8 == 0)) {
        uVar3 = *(undefined8 *)(piVar6 + 2);
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180296799;
        iVar8 = func_0x0001802249c0(uVar3, uVar7 + 1, 0x1804ed9c0, 0x13a);
        *(int64_t *)(piVar6 + 2) = iVar8;
        if (iVar8 == 0) {
            *(undefined8 *)(piVar6 + 2) = uVar3;
            goto code_r0x0001802967a6;
        }
    }
    *piVar6 = (int32_t)uVar7;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x180296816;
        func_0x000180498030(iVar8, iVar2, uVar7);
        *(undefined *)(uVar7 + *(int64_t *)(piVar6 + 2)) = 0;
    }
    uVar1 = piVar6[4];
    piVar6[4] = uVar1 & 0x80;
    piVar6[4] = (uVar1 ^ in_RCX[4]) & 0xffffff7f ^ uVar1;
    return piVar6;
}

// ============================================================
// Function: FUN_18025fde0
// Address: 0x18025fde0
// Size: 81 bytes
// ============================================================
int64_t fcn.18025fde0(int64_t arg_30h, int64_t arg_60h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025fdea;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fe0c;
    iVar1 = fcn.180260030((int64_t)&arg_30h + iVar2, in_RCX, 2);
    if ((iVar1 == 0) || (iVar2 = *(int64_t *)((int64_t)&arg_30h + iVar2), 0xffffffff < iVar2 + 0x80000000U)) {
        iVar2 = 0xffffffff;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18025fe40
// Address: 0x18025fe40
// Size: 28 bytes
// ============================================================
undefined8 fcn.18025fe40(uint64_t *param_1, int32_t *param_2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    uint32_t uVar8;
    uint64_t uVar9;
    undefined8 uStackX_20;
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = 2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar3) = 0x18026003a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == uVar8) {
        uVar9 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)(&stack0x00000048 + iVar4 + iVar3) = unaff_RBX;
        if (uVar9 < 9) {
            if (iVar2 != 0) {
                uVar5 = 0;
                uVar6 = uVar5;
                if (uVar9 != 0) {
                    do {
                        uVar7 = uVar6 + 1;
                        uVar5 = uVar5 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar6);
                        uVar6 = uVar7;
                    } while (uVar7 < uVar9);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar5) {
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                        *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar5;
                    return 1;
                }
                if (0x8000000000000000 < uVar5) {
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
                    return 0;
                }
                *param_1 = -uVar5;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), *(int64_t *)(&stack0x00000078 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar4 + iVar3), *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000060 + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000078 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18025fe60
// Address: 0x18025fe60
// Size: 222 bytes
// ============================================================
undefined8 fcn.18025fe60(uint64_t *param_1, int32_t *param_2)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025fe6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fe7a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fe92;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fea4;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if ((param_2[1] & 0xfffffeffU) != 2) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025febe;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fed6;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fee8;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if (((uint32_t)param_2[1] >> 8 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fefa;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025ff12;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025ff24;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    uVar7 = (uint64_t)*param_2;
    iVar5 = *(int64_t *)(param_2 + 2);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2) = 0x18025ffaa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (uVar7 < 9) {
        if (iVar5 != 0) {
            uVar4 = 0;
            uVar6 = uVar4;
            if (uVar7 != 0) {
                do {
                    puVar1 = (uint8_t *)(iVar5 + uVar6);
                    uVar6 = uVar6 + 1;
                    uVar4 = uVar4 << 8 | (uint64_t)*puVar1;
                } while (uVar6 < uVar7);
            }
            *param_1 = uVar4;
            return 1;
        }
    } else {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + iVar2) = 0x18025ffbe;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + iVar2) = 0x18025ffd6;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + iVar2) = 0x18025ffe8;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_18025ff40
// Address: 0x18025ff40
// Size: 31 bytes
// ============================================================
void fcn.18025ff40(int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    uint64_t uVar4;
    uint32_t uVar5;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = (uint64_t)in_EDX;
    uVar5 = 2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x18026021a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_50h + iVar2 + iVar1) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1);
    iVar3 = 8;
    if ((int64_t)uVar4 < 0) {
        uVar4 = -uVar4;
        do {
            iVar3 = iVar3 + -1;
            (&stack0x00000047)[iVar3 + iVar2 + iVar1 + 1] = (char)uVar4;
            uVar4 = uVar4 >> 8;
        } while (uVar4 != 0);
        uVar5 = uVar5 | 0x100;
    } else {
        do {
            iVar3 = iVar3 + -1;
            (&stack0x00000047)[iVar3 + iVar2 + iVar1 + 1] = (char)uVar4;
            uVar4 = uVar4 >> 8;
        } while (uVar4 != 0);
        uVar5 = uVar5 & 0xfffffeff;
    }
    *(uint32_t *)(in_RCX + 4) = uVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x18026028e;
    func_0x0001802968f0(in_RCX, (int64_t)&arg_48h + iVar3 + iVar2 + iVar1, 8 - (int32_t)iVar3);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x18026029b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar2 + iVar1) ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1))
    ;
    return;
}

// ============================================================
// Function: FUN_18025ff60
// Address: 0x18025ff60
// Size: 28 bytes
// ============================================================
int64_t fcn.18025ff60(undefined4 *param_1, undefined8 param_2)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint32_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802602ac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((param_1[1] & 0xfffffeff) != uVar6) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602c3;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602db;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602ed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)(&stack0x00000050 + iVar4 + iVar3) = unaff_RBX;
    uVar1 = *param_1;
    uVar2 = *(undefined8 *)(param_1 + 2);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260308;
    iVar5 = fcn.180254c30(uVar2, uVar1, param_2);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260315;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026032d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026033f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    if ((param_1[1] & 0x100) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260362;
        fcn.180255840(iVar5, 1);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18025ff80
// Address: 0x18025ff80
// Size: 28 bytes
// ============================================================
int32_t * fcn.18025ff80(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                       int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    undefined8 in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 2;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18026038a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603a0;
        piVar5 = (int32_t *)func_0x000180296a40(uVar6 & 0xffffffff);
        if (piVar5 == (int32_t *)0x0) goto code_r0x000180260414;
    } else {
        in_RDX[1] = (int32_t)uVar6;
        piVar5 = in_RDX;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603c3;
    iVar1 = func_0x000180255370(in_RCX);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603cf;
        iVar1 = func_0x0001802553f0(in_RCX);
        if (iVar1 == 0) {
            piVar5[1] = piVar5[1] | 0x102;
        }
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603e2;
    iVar1 = func_0x000180255500(in_RCX);
    iVar1 = (int32_t)((iVar1 + 7 >> 0x1f & 7U) + iVar1 + 7) >> 3;
    if (iVar1 == 0) {
        iVar1 = 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260406;
    iVar2 = func_0x0001802968f0(piVar5, 0, iVar1);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260456;
        iVar2 = func_0x0001802553f0(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026046b;
            iVar1 = func_0x000180254c60(in_RCX);
        } else {
            **(undefined **)(piVar5 + 2) = 0;
        }
        *piVar5 = iVar1;
        return piVar5;
    }
code_r0x000180260414:
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260419;
    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026042e;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026043d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    if (piVar5 != in_RDX) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026044a;
        fcn.180228780(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    }
    return (int32_t *)0x0;
}

// ============================================================
// Function: FUN_18025ffa0
// Address: 0x18025ffa0
// Size: 129 bytes
// ============================================================
undefined8 fcn.18025fe60(uint64_t *param_1, int32_t *param_2)
{
    uint8_t *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025fe6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fe7a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fe92;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fea4;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if ((param_2[1] & 0xfffffeffU) != 2) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025febe;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fed6;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fee8;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    if (((uint32_t)param_2[1] >> 8 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025fefa;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025ff12;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18025ff24;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0;
    }
    uVar7 = (uint64_t)*param_2;
    iVar5 = *(int64_t *)(param_2 + 2);
    *(undefined8 *)((int64_t)&iStackX_20 + iVar2) = 0x18025ffaa;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (uVar7 < 9) {
        if (iVar5 != 0) {
            uVar4 = 0;
            uVar6 = uVar4;
            if (uVar7 != 0) {
                do {
                    puVar1 = (uint8_t *)(iVar5 + uVar6);
                    uVar6 = uVar6 + 1;
                    uVar4 = uVar4 << 8 | (uint64_t)*puVar1;
                } while (uVar6 < uVar7);
            }
            *param_1 = uVar4;
            return 1;
        }
    } else {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + iVar2) = 0x18025ffbe;
        fcn.180229480(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + iVar2) = 0x18025ffd6;
        fcn.1802295a0(*(int64_t *)(&stack0x00000048 + iVar3 + iVar2), *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), *(int64_t *)(&stack0x00000060 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000078 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)&iStackX_20 + iVar3 + iVar2) = 0x18025ffe8;
        fcn.1802296d0(*(int64_t *)(&stack0x00000068 + iVar3 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_180260030
// Address: 0x180260030
// Size: 159 bytes
// ============================================================
undefined8 fcn.180260030(uint64_t *param_1, int32_t *param_2, uint32_t param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t uVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026003a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == param_3) {
        uVar7 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        if (uVar7 < 9) {
            if (iVar2 != 0) {
                uVar4 = 0;
                uVar5 = uVar4;
                if (uVar7 != 0) {
                    do {
                        uVar6 = uVar5 + 1;
                        uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar5);
                        uVar5 = uVar6;
                    } while (uVar6 < uVar7);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar4) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar4;
                    return 1;
                }
                if (0x8000000000000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                    return 0;
                }
                *param_1 = -uVar4;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1802600cf
// Address: 0x1802600cf
// Size: 72 bytes
// ============================================================
undefined8 fcn.180260030(uint64_t *param_1, int32_t *param_2, uint32_t param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t uVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026003a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == param_3) {
        uVar7 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        if (uVar7 < 9) {
            if (iVar2 != 0) {
                uVar4 = 0;
                uVar5 = uVar4;
                if (uVar7 != 0) {
                    do {
                        uVar6 = uVar5 + 1;
                        uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar5);
                        uVar5 = uVar6;
                    } while (uVar6 < uVar7);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar4) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar4;
                    return 1;
                }
                if (0x8000000000000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                    return 0;
                }
                *param_1 = -uVar4;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180260117
// Address: 0x180260117
// Size: 88 bytes
// ============================================================
undefined8 fcn.180260030(uint64_t *param_1, int32_t *param_2, uint32_t param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t uVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026003a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == param_3) {
        uVar7 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        if (uVar7 < 9) {
            if (iVar2 != 0) {
                uVar4 = 0;
                uVar5 = uVar4;
                if (uVar7 != 0) {
                    do {
                        uVar6 = uVar5 + 1;
                        uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar5);
                        uVar5 = uVar6;
                    } while (uVar6 < uVar7);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar4) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar4;
                    return 1;
                }
                if (0x8000000000000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                    return 0;
                }
                *param_1 = -uVar4;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18026016f
// Address: 0x18026016f
// Size: 59 bytes
// ============================================================
undefined8 fcn.180260030(uint64_t *param_1, int32_t *param_2, uint32_t param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t uVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026003a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == param_3) {
        uVar7 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        if (uVar7 < 9) {
            if (iVar2 != 0) {
                uVar4 = 0;
                uVar5 = uVar4;
                if (uVar7 != 0) {
                    do {
                        uVar6 = uVar5 + 1;
                        uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar5);
                        uVar5 = uVar6;
                    } while (uVar6 < uVar7);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar4) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar4;
                    return 1;
                }
                if (0x8000000000000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                    return 0;
                }
                *param_1 = -uVar4;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1802601aa
// Address: 0x1802601aa
// Size: 35 bytes
// ============================================================
undefined8 fcn.180260030(uint64_t *param_1, int32_t *param_2, uint32_t param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t uVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026003a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == param_3) {
        uVar7 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        if (uVar7 < 9) {
            if (iVar2 != 0) {
                uVar4 = 0;
                uVar5 = uVar4;
                if (uVar7 != 0) {
                    do {
                        uVar6 = uVar5 + 1;
                        uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar5);
                        uVar5 = uVar6;
                    } while (uVar6 < uVar7);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar4) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar4;
                    return 1;
                }
                if (0x8000000000000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                    return 0;
                }
                *param_1 = -uVar4;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1802601cd
// Address: 0x1802601cd
// Size: 59 bytes
// ============================================================
undefined8 fcn.180260030(uint64_t *param_1, int32_t *param_2, uint32_t param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    uint64_t uVar7;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026003a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026004a;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260062;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar3));
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260074;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        return 0;
    }
    uVar1 = param_2[1];
    if ((uVar1 & 0xfffffeff) == param_3) {
        uVar7 = (uint64_t)*param_2;
        iVar2 = *(int64_t *)(param_2 + 2);
        *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
        if (uVar7 < 9) {
            if (iVar2 != 0) {
                uVar4 = 0;
                uVar5 = uVar4;
                if (uVar7 != 0) {
                    do {
                        uVar6 = uVar5 + 1;
                        uVar4 = uVar4 << 8 | (uint64_t)*(uint8_t *)(iVar2 + uVar5);
                        uVar5 = uVar6;
                    } while (uVar6 < uVar7);
                }
                if ((uVar1 & 0x100) == 0) {
                    if (0x7fffffffffffffff < uVar4) {
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601d2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601ea;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                      *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                      *(int64_t *)(&stack0x00000050 + iVar3));
                        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802601fc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                        return 0;
                    }
                    *param_1 = uVar4;
                    return 1;
                }
                if (0x8000000000000000 < uVar4) {
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260174;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026018c;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                                  *(int64_t *)(&stack0x00000050 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026019e;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
                    return 0;
                }
                *param_1 = -uVar4;
                return 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600df;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600f7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                          *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260109;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
        }
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180260090;
    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600a8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)(&stack0x00000030 + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x1802600ba;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180260210
// Address: 0x180260210
// Size: 144 bytes
// ============================================================
void fcn.18025ff40(int64_t arg_48h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int32_t in_EDX;
    uint64_t uVar4;
    uint32_t uVar5;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = (uint64_t)in_EDX;
    uVar5 = 2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x18026021a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_50h + iVar2 + iVar1) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1);
    iVar3 = 8;
    if ((int64_t)uVar4 < 0) {
        uVar4 = -uVar4;
        do {
            iVar3 = iVar3 + -1;
            (&stack0x00000047)[iVar3 + iVar2 + iVar1 + 1] = (char)uVar4;
            uVar4 = uVar4 >> 8;
        } while (uVar4 != 0);
        uVar5 = uVar5 | 0x100;
    } else {
        do {
            iVar3 = iVar3 + -1;
            (&stack0x00000047)[iVar3 + iVar2 + iVar1 + 1] = (char)uVar4;
            uVar4 = uVar4 >> 8;
        } while (uVar4 != 0);
        uVar5 = uVar5 & 0xfffffeff;
    }
    *(uint32_t *)(in_RCX + 4) = uVar5;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x18026028e;
    func_0x0001802968f0(in_RCX, (int64_t)&arg_48h + iVar3 + iVar2 + iVar1, 8 - (int32_t)iVar3);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x18026029b;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar2 + iVar1) ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1))
    ;
    return;
}

// ============================================================
// Function: FUN_1802602a0
// Address: 0x1802602a0
// Size: 88 bytes
// ============================================================
int64_t fcn.18025fd50(int64_t arg_50h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint32_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802602ac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX[1] & 0xfffffeff) != uVar6) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602c3;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602db;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602ed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_RBX;
    uVar1 = *in_RCX;
    uVar2 = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260308;
    iVar5 = fcn.180254c30(uVar2, uVar1, in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260315;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026032d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026033f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    if ((in_RCX[1] & 0x100) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260362;
        fcn.180255840(iVar5, 1);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_1802602f8
// Address: 0x1802602f8
// Size: 84 bytes
// ============================================================
int64_t fcn.18025fd50(int64_t arg_50h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint32_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802602ac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX[1] & 0xfffffeff) != uVar6) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602c3;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602db;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602ed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_RBX;
    uVar1 = *in_RCX;
    uVar2 = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260308;
    iVar5 = fcn.180254c30(uVar2, uVar1, in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260315;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026032d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026033f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    if ((in_RCX[1] & 0x100) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260362;
        fcn.180255840(iVar5, 1);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18026034c
// Address: 0x18026034c
// Size: 36 bytes
// ============================================================
int64_t fcn.18025fd50(int64_t arg_50h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint32_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802602ac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX[1] & 0xfffffeff) != uVar6) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602c3;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602db;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802602ed;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = unaff_RBX;
    uVar1 = *in_RCX;
    uVar2 = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260308;
    iVar5 = fcn.180254c30(uVar2, uVar1, in_RDX);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260315;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026032d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026033f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
        return 0;
    }
    if ((in_RCX[1] & 0x100) != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260362;
        fcn.180255840(iVar5, 1);
    }
    return iVar5;
}

// ============================================================
// Function: FUN_180260370
// Address: 0x180260370
// Size: 279 bytes
// ============================================================
int32_t * fcn.18025ff80(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h,
                       int64_t arg_60h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t *piVar5;
    undefined8 in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar6;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar6 = 2;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18026038a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603a0;
        piVar5 = (int32_t *)func_0x000180296a40(uVar6 & 0xffffffff);
        if (piVar5 == (int32_t *)0x0) goto code_r0x000180260414;
    } else {
        in_RDX[1] = (int32_t)uVar6;
        piVar5 = in_RDX;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603c3;
    iVar1 = func_0x000180255370(in_RCX);
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603cf;
        iVar1 = func_0x0001802553f0(in_RCX);
        if (iVar1 == 0) {
            piVar5[1] = piVar5[1] | 0x102;
        }
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802603e2;
    iVar1 = func_0x000180255500(in_RCX);
    iVar1 = (int32_t)((iVar1 + 7 >> 0x1f & 7U) + iVar1 + 7) >> 3;
    if (iVar1 == 0) {
        iVar1 = 1;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260406;
    iVar2 = func_0x0001802968f0(piVar5, 0, iVar1);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260456;
        iVar2 = func_0x0001802553f0(in_RCX);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026046b;
            iVar1 = func_0x000180254c60(in_RCX);
        } else {
            **(undefined **)(piVar5 + 2) = 0;
        }
        *piVar5 = iVar1;
        return piVar5;
    }
code_r0x000180260414:
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180260419;
    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026042e;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026043d;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    if (piVar5 != in_RDX) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18026044a;
        fcn.180228780(*(int64_t *)(&stack0x00000068 + iVar4 + iVar3));
    }
    return (int32_t *)0x0;
}

// ============================================================
// Function: FUN_180260490
// Address: 0x180260490
// Size: 411 bytes
// ============================================================
int64_t fcn.180260490(uint8_t *param_1, uint32_t *param_2, uint8_t *param_3, uint64_t param_4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined auVar3 [13];
    undefined auVar4 [13];
    undefined auVar5 [13];
    undefined auVar6 [13];
    uint8_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 unaff_RBX;
    uint32_t uVar10;
    int64_t iVar11;
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026049a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_4 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                      *(int64_t *)(&stack0x00000050 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604d7;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar8));
        return 0;
    }
    uVar2 = *param_3;
    if (param_2 != (uint32_t *)0x0) {
        *param_2 = uVar2 & 0x80;
    }
    if (param_4 == 1) {
        if (param_1 != (uint8_t *)0x0) {
            uVar7 = *param_3;
            if ((uVar2 & 0x80) != 0) {
                uVar7 = -uVar7;
            }
            *param_1 = uVar7;
        }
        return 1;
    }
    if (*param_3 == 0) {
        uVar9 = 1;
    } else {
        uVar9 = 0;
        if (*param_3 != 0xff) goto code_r0x000180260620;
        uVar10 = 0;
        uVar9 = 1;
        if (1 < param_4) {
            if (7 < param_4 - 1) {
                auVar15 = ZEXT816(0);
                auVar14 = ZEXT816(0);
                do {
                    uVar10 = *(uint32_t *)(param_3 + uVar9);
                    auVar3[12] = (char)(uVar10 >> 0x18);
                    auVar3._0_12_ = ZEXT712(0);
                    auVar5[1] = 0;
                    auVar5[0] = (uint8_t)(uVar10 >> 0x10);
                    auVar5._2_3_ = auVar3._10_3_;
                    auVar5._5_8_ = 0;
                    auVar12[5] = 0;
                    auVar12[4] = (uint8_t)(uVar10 >> 8);
                    auVar12._6_7_ = SUB137(auVar5 << 0x40, 6);
                    auVar12._0_4_ = uVar10 & 0xff;
                    auVar12._13_3_ = 0;
                    auVar15 = auVar15 | auVar12;
                    uVar10 = *(uint32_t *)(param_3 + uVar9 + 4);
                    uVar9 = uVar9 + 8;
                    auVar4[12] = (char)(uVar10 >> 0x18);
                    auVar4._0_12_ = ZEXT712(0);
                    auVar6[1] = 0;
                    auVar6[0] = (uint8_t)(uVar10 >> 0x10);
                    auVar6._2_3_ = auVar4._10_3_;
                    auVar6._5_8_ = 0;
                    auVar13[5] = 0;
                    auVar13[4] = (uint8_t)(uVar10 >> 8);
                    auVar13._6_7_ = SUB137(auVar6 << 0x40, 6);
                    auVar13._0_4_ = uVar10 & 0xff;
                    auVar13._13_3_ = 0;
                    auVar14 = auVar14 | auVar13;
                } while (uVar9 < param_4 - ((uint32_t)(param_4 - 1) & 7));
                auVar14 = auVar14 | auVar15 | (auVar14 | auVar15) >> 0x40;
                uVar10 = auVar14._0_4_ | auVar14._4_4_;
                if (param_4 <= uVar9) goto code_r0x0001802605cf;
            }
            do {
                puVar1 = param_3 + uVar9;
                uVar9 = uVar9 + 1;
                uVar10 = uVar10 | *puVar1;
            } while (uVar9 < param_4);
        }
code_r0x0001802605cf:
        uVar9 = (uint64_t)(uVar10 != 0);
        if (uVar10 == 0) goto code_r0x000180260620;
    }
    if ((uVar2 & 0x80) == (param_3[1] & 0x80)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802605ef;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180260607;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                      *(int64_t *)(&stack0x00000050 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180260619;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar8));
        return 0;
    }
code_r0x000180260620:
    iVar11 = param_4 - uVar9;
    if (param_1 != (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_RBX;
        uVar2 = -((uVar2 & 0x80) != 0);
        uVar10 = uVar2 & 1;
        if (iVar11 != 0) {
            param_3 = param_3 + iVar11 + uVar9;
            iVar8 = iVar11;
            do {
                puVar1 = param_3 + -1;
                param_3 = param_3 + -1;
                iVar8 = iVar8 + -1;
                uVar10 = uVar10 + (uVar2 ^ *puVar1);
                param_1[iVar8] = (uint8_t)uVar10;
                uVar10 = uVar10 >> 8;
            } while (iVar8 != 0);
        }
    }
    return iVar11;
}

// ============================================================
// Function: FUN_18026062b
// Address: 0x18026062b
// Size: 73 bytes
// ============================================================
int64_t fcn.180260490(uint8_t *param_1, uint32_t *param_2, uint8_t *param_3, uint64_t param_4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined auVar3 [13];
    undefined auVar4 [13];
    undefined auVar5 [13];
    undefined auVar6 [13];
    uint8_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 unaff_RBX;
    uint32_t uVar10;
    int64_t iVar11;
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026049a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_4 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                      *(int64_t *)(&stack0x00000050 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604d7;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar8));
        return 0;
    }
    uVar2 = *param_3;
    if (param_2 != (uint32_t *)0x0) {
        *param_2 = uVar2 & 0x80;
    }
    if (param_4 == 1) {
        if (param_1 != (uint8_t *)0x0) {
            uVar7 = *param_3;
            if ((uVar2 & 0x80) != 0) {
                uVar7 = -uVar7;
            }
            *param_1 = uVar7;
        }
        return 1;
    }
    if (*param_3 == 0) {
        uVar9 = 1;
    } else {
        uVar9 = 0;
        if (*param_3 != 0xff) goto code_r0x000180260620;
        uVar10 = 0;
        uVar9 = 1;
        if (1 < param_4) {
            if (7 < param_4 - 1) {
                auVar15 = ZEXT816(0);
                auVar14 = ZEXT816(0);
                do {
                    uVar10 = *(uint32_t *)(param_3 + uVar9);
                    auVar3[12] = (char)(uVar10 >> 0x18);
                    auVar3._0_12_ = ZEXT712(0);
                    auVar5[1] = 0;
                    auVar5[0] = (uint8_t)(uVar10 >> 0x10);
                    auVar5._2_3_ = auVar3._10_3_;
                    auVar5._5_8_ = 0;
                    auVar12[5] = 0;
                    auVar12[4] = (uint8_t)(uVar10 >> 8);
                    auVar12._6_7_ = SUB137(auVar5 << 0x40, 6);
                    auVar12._0_4_ = uVar10 & 0xff;
                    auVar12._13_3_ = 0;
                    auVar15 = auVar15 | auVar12;
                    uVar10 = *(uint32_t *)(param_3 + uVar9 + 4);
                    uVar9 = uVar9 + 8;
                    auVar4[12] = (char)(uVar10 >> 0x18);
                    auVar4._0_12_ = ZEXT712(0);
                    auVar6[1] = 0;
                    auVar6[0] = (uint8_t)(uVar10 >> 0x10);
                    auVar6._2_3_ = auVar4._10_3_;
                    auVar6._5_8_ = 0;
                    auVar13[5] = 0;
                    auVar13[4] = (uint8_t)(uVar10 >> 8);
                    auVar13._6_7_ = SUB137(auVar6 << 0x40, 6);
                    auVar13._0_4_ = uVar10 & 0xff;
                    auVar13._13_3_ = 0;
                    auVar14 = auVar14 | auVar13;
                } while (uVar9 < param_4 - ((uint32_t)(param_4 - 1) & 7));
                auVar14 = auVar14 | auVar15 | (auVar14 | auVar15) >> 0x40;
                uVar10 = auVar14._0_4_ | auVar14._4_4_;
                if (param_4 <= uVar9) goto code_r0x0001802605cf;
            }
            do {
                puVar1 = param_3 + uVar9;
                uVar9 = uVar9 + 1;
                uVar10 = uVar10 | *puVar1;
            } while (uVar9 < param_4);
        }
code_r0x0001802605cf:
        uVar9 = (uint64_t)(uVar10 != 0);
        if (uVar10 == 0) goto code_r0x000180260620;
    }
    if ((uVar2 & 0x80) == (param_3[1] & 0x80)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802605ef;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180260607;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                      *(int64_t *)(&stack0x00000050 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180260619;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar8));
        return 0;
    }
code_r0x000180260620:
    iVar11 = param_4 - uVar9;
    if (param_1 != (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_RBX;
        uVar2 = -((uVar2 & 0x80) != 0);
        uVar10 = uVar2 & 1;
        if (iVar11 != 0) {
            param_3 = param_3 + iVar11 + uVar9;
            iVar8 = iVar11;
            do {
                puVar1 = param_3 + -1;
                param_3 = param_3 + -1;
                iVar8 = iVar8 + -1;
                uVar10 = uVar10 + (uVar2 ^ *puVar1);
                param_1[iVar8] = (uint8_t)uVar10;
                uVar10 = uVar10 >> 8;
            } while (iVar8 != 0);
        }
    }
    return iVar11;
}

// ============================================================
// Function: FUN_180260674
// Address: 0x180260674
// Size: 8 bytes
// ============================================================
int64_t fcn.180260490(uint8_t *param_1, uint32_t *param_2, uint8_t *param_3, uint64_t param_4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined auVar3 [13];
    undefined auVar4 [13];
    undefined auVar5 [13];
    undefined auVar6 [13];
    uint8_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined8 unaff_RBX;
    uint32_t uVar10;
    int64_t iVar11;
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026049a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (param_4 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604ad;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604c5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                      *(int64_t *)(&stack0x00000050 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802604d7;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar8));
        return 0;
    }
    uVar2 = *param_3;
    if (param_2 != (uint32_t *)0x0) {
        *param_2 = uVar2 & 0x80;
    }
    if (param_4 == 1) {
        if (param_1 != (uint8_t *)0x0) {
            uVar7 = *param_3;
            if ((uVar2 & 0x80) != 0) {
                uVar7 = -uVar7;
            }
            *param_1 = uVar7;
        }
        return 1;
    }
    if (*param_3 == 0) {
        uVar9 = 1;
    } else {
        uVar9 = 0;
        if (*param_3 != 0xff) goto code_r0x000180260620;
        uVar10 = 0;
        uVar9 = 1;
        if (1 < param_4) {
            if (7 < param_4 - 1) {
                auVar15 = ZEXT816(0);
                auVar14 = ZEXT816(0);
                do {
                    uVar10 = *(uint32_t *)(param_3 + uVar9);
                    auVar3[12] = (char)(uVar10 >> 0x18);
                    auVar3._0_12_ = ZEXT712(0);
                    auVar5[1] = 0;
                    auVar5[0] = (uint8_t)(uVar10 >> 0x10);
                    auVar5._2_3_ = auVar3._10_3_;
                    auVar5._5_8_ = 0;
                    auVar12[5] = 0;
                    auVar12[4] = (uint8_t)(uVar10 >> 8);
                    auVar12._6_7_ = SUB137(auVar5 << 0x40, 6);
                    auVar12._0_4_ = uVar10 & 0xff;
                    auVar12._13_3_ = 0;
                    auVar15 = auVar15 | auVar12;
                    uVar10 = *(uint32_t *)(param_3 + uVar9 + 4);
                    uVar9 = uVar9 + 8;
                    auVar4[12] = (char)(uVar10 >> 0x18);
                    auVar4._0_12_ = ZEXT712(0);
                    auVar6[1] = 0;
                    auVar6[0] = (uint8_t)(uVar10 >> 0x10);
                    auVar6._2_3_ = auVar4._10_3_;
                    auVar6._5_8_ = 0;
                    auVar13[5] = 0;
                    auVar13[4] = (uint8_t)(uVar10 >> 8);
                    auVar13._6_7_ = SUB137(auVar6 << 0x40, 6);
                    auVar13._0_4_ = uVar10 & 0xff;
                    auVar13._13_3_ = 0;
                    auVar14 = auVar14 | auVar13;
                } while (uVar9 < param_4 - ((uint32_t)(param_4 - 1) & 7));
                auVar14 = auVar14 | auVar15 | (auVar14 | auVar15) >> 0x40;
                uVar10 = auVar14._0_4_ | auVar14._4_4_;
                if (param_4 <= uVar9) goto code_r0x0001802605cf;
            }
            do {
                puVar1 = param_3 + uVar9;
                uVar9 = uVar9 + 1;
                uVar10 = uVar10 | *puVar1;
            } while (uVar9 < param_4);
        }
code_r0x0001802605cf:
        uVar9 = (uint64_t)(uVar10 != 0);
        if (uVar10 == 0) goto code_r0x000180260620;
    }
    if ((uVar2 & 0x80) == (param_3[1] & 0x80)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x1802605ef;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180260607;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0x00000028 + iVar8), 
                      *(int64_t *)(&stack0x00000030 + iVar8), *(int64_t *)(&stack0x00000038 + iVar8), 
                      *(int64_t *)(&stack0x00000050 + iVar8));
        *(undefined8 *)((int64_t)&uStack_8 + iVar8) = 0x180260619;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar8));
        return 0;
    }
code_r0x000180260620:
    iVar11 = param_4 - uVar9;
    if (param_1 != (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&var_20h + iVar8) = unaff_RBX;
        uVar2 = -((uVar2 & 0x80) != 0);
        uVar10 = uVar2 & 1;
        if (iVar11 != 0) {
            param_3 = param_3 + iVar11 + uVar9;
            iVar8 = iVar11;
            do {
                puVar1 = param_3 + -1;
                param_3 = param_3 + -1;
                iVar8 = iVar8 + -1;
                uVar10 = uVar10 + (uVar2 ^ *puVar1);
                param_1[iVar8] = (uint8_t)uVar10;
                uVar10 = uVar10 >> 8;
            } while (iVar8 != 0);
        }
    }
    return iVar11;
}

// ============================================================
// Function: FUN_180260680
// Address: 0x180260680
// Size: 282 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180260680(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined *puVar3;
    undefined auVar4 [13];
    undefined auVar5 [13];
    undefined auVar6 [13];
    undefined auVar7 [13];
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = 0;
    uVar12 = 0;
    uVar11 = 0;
    if ((arg1 == 0) || (arg2 == 0)) {
        iVar9 = 1;
        arg2 = 0;
        goto code_r0x00018026078d;
    }
    uVar2 = *(uint8_t *)arg1;
    if ((int32_t)arg3 == 0) {
        if (0x7f < uVar2) {
            uVar11 = 1;
            iVar9 = arg2 + 1;
            goto code_r0x00018026078d;
        }
    } else {
        uVar8 = 0xff;
        if (0x80 < uVar2) {
            uVar11 = 1;
            iVar9 = arg2 + 1;
            goto code_r0x00018026078d;
        }
        if (uVar2 == 0x80) {
            uVar10 = 1;
            if (1 < (uint64_t)arg2) {
                if (7 < arg2 - 1U) {
                    auVar17 = ZEXT816(0);
                    auVar16 = ZEXT816(0);
                    do {
                        uVar8 = *(uint32_t *)(arg1 + uVar10);
                        auVar4[12] = (char)(uVar8 >> 0x18);
                        auVar4._0_12_ = ZEXT712(0);
                        auVar6[1] = 0;
                        auVar6[0] = (uint8_t)(uVar8 >> 0x10);
                        auVar6._2_3_ = auVar4._10_3_;
                        auVar6._5_8_ = 0;
                        auVar14[5] = 0;
                        auVar14[4] = (uint8_t)(uVar8 >> 8);
                        auVar14._6_7_ = SUB137(auVar6 << 0x40, 6);
                        auVar14._0_4_ = uVar8 & 0xff;
                        auVar14._13_3_ = 0;
                        auVar17 = auVar17 | auVar14;
                        uVar8 = *(uint32_t *)(arg1 + 4 + uVar10);
                        uVar10 = uVar10 + 8;
                        auVar5[12] = (char)(uVar8 >> 0x18);
                        auVar5._0_12_ = ZEXT712(0);
                        auVar7[1] = 0;
                        auVar7[0] = (uint8_t)(uVar8 >> 0x10);
                        auVar7._2_3_ = auVar5._10_3_;
                        auVar7._5_8_ = 0;
                        auVar15[5] = 0;
                        auVar15[4] = (uint8_t)(uVar8 >> 8);
                        auVar15._6_7_ = SUB137(auVar7 << 0x40, 6);
                        auVar15._0_4_ = uVar8 & 0xff;
                        auVar15._13_3_ = 0;
                        auVar16 = auVar16 | auVar15;
                    } while (uVar10 < arg2 - (uint64_t)((uint32_t)(arg2 - 1U) & 7));
                    auVar16 = auVar16 | auVar17 | (auVar16 | auVar17) >> 0x40;
                    uVar11 = auVar16._0_4_ | auVar16._4_4_;
                    uVar12 = (uint64_t)uVar11;
                    if ((uint64_t)arg2 <= uVar10) goto code_r0x00018026076f;
                }
                do {
                    puVar1 = (uint8_t *)(arg1 + uVar10);
                    uVar10 = uVar10 + 1;
                    uVar11 = (uint32_t)uVar12 | (uint32_t)*puVar1;
                    uVar12 = (uint64_t)uVar11;
                } while (uVar10 < (uint64_t)arg2);
            }
code_r0x00018026076f:
            uVar8 = (uint32_t)(uint8_t)-(uVar11 != 0);
            uVar12 = (uint64_t)(uVar8 & 1);
        }
    }
    uVar11 = (uint32_t)uVar12;
    iVar9 = uVar12 + arg2;
code_r0x00018026078d:
    if ((arg4 != 0) && (puVar3 = *(undefined **)arg4, puVar3 != (undefined *)0x0)) {
        uVar13 = uVar8 & 1;
        *puVar3 = (char)uVar8;
        if (arg2 != 0) {
            arg1 = arg1 + arg2;
            do {
                puVar1 = (uint8_t *)(arg1 + -1);
                arg1 = arg1 + -1;
                arg2 = arg2 + -1;
                uVar13 = uVar13 + (*puVar1 ^ uVar8);
                puVar3[arg2 + (uint64_t)uVar11] = (char)uVar13;
                uVar13 = uVar13 >> 8;
            } while (arg2 != 0);
        }
        *(int64_t *)arg4 = *(int64_t *)arg4 + iVar9;
    }
    return;
}

// ============================================================
// Function: FUN_18026079a
// Address: 0x18026079a
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180260680(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined *puVar3;
    undefined auVar4 [13];
    undefined auVar5 [13];
    undefined auVar6 [13];
    undefined auVar7 [13];
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = 0;
    uVar12 = 0;
    uVar11 = 0;
    if ((arg1 == 0) || (arg2 == 0)) {
        iVar9 = 1;
        arg2 = 0;
        goto code_r0x00018026078d;
    }
    uVar2 = *(uint8_t *)arg1;
    if ((int32_t)arg3 == 0) {
        if (0x7f < uVar2) {
            uVar11 = 1;
            iVar9 = arg2 + 1;
            goto code_r0x00018026078d;
        }
    } else {
        uVar8 = 0xff;
        if (0x80 < uVar2) {
            uVar11 = 1;
            iVar9 = arg2 + 1;
            goto code_r0x00018026078d;
        }
        if (uVar2 == 0x80) {
            uVar10 = 1;
            if (1 < (uint64_t)arg2) {
                if (7 < arg2 - 1U) {
                    auVar17 = ZEXT816(0);
                    auVar16 = ZEXT816(0);
                    do {
                        uVar8 = *(uint32_t *)(arg1 + uVar10);
                        auVar4[12] = (char)(uVar8 >> 0x18);
                        auVar4._0_12_ = ZEXT712(0);
                        auVar6[1] = 0;
                        auVar6[0] = (uint8_t)(uVar8 >> 0x10);
                        auVar6._2_3_ = auVar4._10_3_;
                        auVar6._5_8_ = 0;
                        auVar14[5] = 0;
                        auVar14[4] = (uint8_t)(uVar8 >> 8);
                        auVar14._6_7_ = SUB137(auVar6 << 0x40, 6);
                        auVar14._0_4_ = uVar8 & 0xff;
                        auVar14._13_3_ = 0;
                        auVar17 = auVar17 | auVar14;
                        uVar8 = *(uint32_t *)(arg1 + 4 + uVar10);
                        uVar10 = uVar10 + 8;
                        auVar5[12] = (char)(uVar8 >> 0x18);
                        auVar5._0_12_ = ZEXT712(0);
                        auVar7[1] = 0;
                        auVar7[0] = (uint8_t)(uVar8 >> 0x10);
                        auVar7._2_3_ = auVar5._10_3_;
                        auVar7._5_8_ = 0;
                        auVar15[5] = 0;
                        auVar15[4] = (uint8_t)(uVar8 >> 8);
                        auVar15._6_7_ = SUB137(auVar7 << 0x40, 6);
                        auVar15._0_4_ = uVar8 & 0xff;
                        auVar15._13_3_ = 0;
                        auVar16 = auVar16 | auVar15;
                    } while (uVar10 < arg2 - (uint64_t)((uint32_t)(arg2 - 1U) & 7));
                    auVar16 = auVar16 | auVar17 | (auVar16 | auVar17) >> 0x40;
                    uVar11 = auVar16._0_4_ | auVar16._4_4_;
                    uVar12 = (uint64_t)uVar11;
                    if ((uint64_t)arg2 <= uVar10) goto code_r0x00018026076f;
                }
                do {
                    puVar1 = (uint8_t *)(arg1 + uVar10);
                    uVar10 = uVar10 + 1;
                    uVar11 = (uint32_t)uVar12 | (uint32_t)*puVar1;
                    uVar12 = (uint64_t)uVar11;
                } while (uVar10 < (uint64_t)arg2);
            }
code_r0x00018026076f:
            uVar8 = (uint32_t)(uint8_t)-(uVar11 != 0);
            uVar12 = (uint64_t)(uVar8 & 1);
        }
    }
    uVar11 = (uint32_t)uVar12;
    iVar9 = uVar12 + arg2;
code_r0x00018026078d:
    if ((arg4 != 0) && (puVar3 = *(undefined **)arg4, puVar3 != (undefined *)0x0)) {
        uVar13 = uVar8 & 1;
        *puVar3 = (char)uVar8;
        if (arg2 != 0) {
            arg1 = arg1 + arg2;
            do {
                puVar1 = (uint8_t *)(arg1 + -1);
                arg1 = arg1 + -1;
                arg2 = arg2 + -1;
                uVar13 = uVar13 + (*puVar1 ^ uVar8);
                puVar3[arg2 + (uint64_t)uVar11] = (char)uVar13;
                uVar13 = uVar13 >> 8;
            } while (arg2 != 0);
        }
        *(int64_t *)arg4 = *(int64_t *)arg4 + iVar9;
    }
    return;
}

// ============================================================
// Function: FUN_1802607ea
// Address: 0x1802607ea
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180260680(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    undefined *puVar3;
    undefined auVar4 [13];
    undefined auVar5 [13];
    undefined auVar6 [13];
    undefined auVar7 [13];
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    uint32_t uVar13;
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    int64_t var_10h;
    int64_t var_18h;
    
    uVar8 = 0;
    uVar12 = 0;
    uVar11 = 0;
    if ((arg1 == 0) || (arg2 == 0)) {
        iVar9 = 1;
        arg2 = 0;
        goto code_r0x00018026078d;
    }
    uVar2 = *(uint8_t *)arg1;
    if ((int32_t)arg3 == 0) {
        if (0x7f < uVar2) {
            uVar11 = 1;
            iVar9 = arg2 + 1;
            goto code_r0x00018026078d;
        }
    } else {
        uVar8 = 0xff;
        if (0x80 < uVar2) {
            uVar11 = 1;
            iVar9 = arg2 + 1;
            goto code_r0x00018026078d;
        }
        if (uVar2 == 0x80) {
            uVar10 = 1;
            if (1 < (uint64_t)arg2) {
                if (7 < arg2 - 1U) {
                    auVar17 = ZEXT816(0);
                    auVar16 = ZEXT816(0);
                    do {
                        uVar8 = *(uint32_t *)(arg1 + uVar10);
                        auVar4[12] = (char)(uVar8 >> 0x18);
                        auVar4._0_12_ = ZEXT712(0);
                        auVar6[1] = 0;
                        auVar6[0] = (uint8_t)(uVar8 >> 0x10);
                        auVar6._2_3_ = auVar4._10_3_;
                        auVar6._5_8_ = 0;
                        auVar14[5] = 0;
                        auVar14[4] = (uint8_t)(uVar8 >> 8);
                        auVar14._6_7_ = SUB137(auVar6 << 0x40, 6);
                        auVar14._0_4_ = uVar8 & 0xff;
                        auVar14._13_3_ = 0;
                        auVar17 = auVar17 | auVar14;
                        uVar8 = *(uint32_t *)(arg1 + 4 + uVar10);
                        uVar10 = uVar10 + 8;
                        auVar5[12] = (char)(uVar8 >> 0x18);
                        auVar5._0_12_ = ZEXT712(0);
                        auVar7[1] = 0;
                        auVar7[0] = (uint8_t)(uVar8 >> 0x10);
                        auVar7._2_3_ = auVar5._10_3_;
                        auVar7._5_8_ = 0;
                        auVar15[5] = 0;
                        auVar15[4] = (uint8_t)(uVar8 >> 8);
                        auVar15._6_7_ = SUB137(auVar7 << 0x40, 6);
                        auVar15._0_4_ = uVar8 & 0xff;
                        auVar15._13_3_ = 0;
                        auVar16 = auVar16 | auVar15;
                    } while (uVar10 < arg2 - (uint64_t)((uint32_t)(arg2 - 1U) & 7));
                    auVar16 = auVar16 | auVar17 | (auVar16 | auVar17) >> 0x40;
                    uVar11 = auVar16._0_4_ | auVar16._4_4_;
                    uVar12 = (uint64_t)uVar11;
                    if ((uint64_t)arg2 <= uVar10) goto code_r0x00018026076f;
                }
                do {
                    puVar1 = (uint8_t *)(arg1 + uVar10);
                    uVar10 = uVar10 + 1;
                    uVar11 = (uint32_t)uVar12 | (uint32_t)*puVar1;
                    uVar12 = (uint64_t)uVar11;
                } while (uVar10 < (uint64_t)arg2);
            }
code_r0x00018026076f:
            uVar8 = (uint32_t)(uint8_t)-(uVar11 != 0);
            uVar12 = (uint64_t)(uVar8 & 1);
        }
    }
    uVar11 = (uint32_t)uVar12;
    iVar9 = uVar12 + arg2;
code_r0x00018026078d:
    if ((arg4 != 0) && (puVar3 = *(undefined **)arg4, puVar3 != (undefined *)0x0)) {
        uVar13 = uVar8 & 1;
        *puVar3 = (char)uVar8;
        if (arg2 != 0) {
            arg1 = arg1 + arg2;
            do {
                puVar1 = (uint8_t *)(arg1 + -1);
                arg1 = arg1 + -1;
                arg2 = arg2 + -1;
                uVar13 = uVar13 + (*puVar1 ^ uVar8);
                puVar3[arg2 + (uint64_t)uVar11] = (char)uVar13;
                uVar13 = uVar13 >> 8;
            } while (arg2 != 0);
        }
        *(int64_t *)arg4 = *(int64_t *)arg4 + iVar9;
    }
    return;
}

