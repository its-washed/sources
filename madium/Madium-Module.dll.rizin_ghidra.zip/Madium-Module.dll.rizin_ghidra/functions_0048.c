// Chunk 48 - 50 functions

// ============================================================
// Function: FUN_180098c01
// Address: 0x180098c01
// Size: 359 bytes
// ============================================================
void fcn.180098c01(undefined8 placeholder_0, int64_t arg2, int64_t arg3, undefined8 placeholder_3,
                  undefined8 placeholder_4, int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h)
{
    undefined *puVar1;
    undefined4 *puVar2;
    char cVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar19 [16];
    bool bVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    int64_t iVar25;
    unkbyte7 Var26;
    uint8_t uVar27;
    int8_t iVar28;
    undefined uVar29;
    uint32_t uVar30;
    int64_t iVar31;
    int32_t iVar32;
    uint64_t uVar33;
    uint64_t uVar34;
    undefined *puVar35;
    int64_t unaff_RBX;
    uint64_t uVar36;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    uint64_t uVar37;
    uint32_t uVar38;
    uint64_t uVar39;
    int64_t *piVar40;
    undefined2 *puVar41;
    uint64_t uVar42;
    uint64_t uVar43;
    undefined4 *unaff_R14;
    int32_t iVar44;
    bool bVar45;
    undefined2 auStackX_18 [2];
    int64_t var_1ch;
    
    iVar44 = (int32_t)((-(uint32_t)((int32_t)unaff_RBP != 0) & 0xfffe0040) + (int32_t)arg3 * 0x4d104) >> 0x14;
    uVar30 = 0x124 - iVar44;
    iVar25 = (int64_t)(int32_t)uVar30 >> 4;
    uVar27 = (char)(iVar44 * -0x35269e >> 0x14) + (char)arg3 + '\x01';
    uVar37 = *(uint64_t *)(unaff_RBX + 0x612510 + (uint64_t)(uVar30 & 0xf) * 8);
    auVar4._8_8_ = 0;
    auVar4._0_8_ = uVar37;
    auVar12._8_8_ = 0;
    auVar12._0_8_ = *(uint64_t *)(unaff_RBX + 0x612660 + iVar25 * 0x18);
    auVar5._8_8_ = 0;
    auVar5._0_8_ = uVar37;
    auVar13._8_8_ = 0;
    auVar13._0_8_ = *(uint64_t *)(unaff_RBX + 0x612668 + iVar25 * 0x18);
    uVar33 = SUB168(auVar5 * auVar13, 8);
    uVar37 = uVar33 + SUB168(auVar4 * auVar12, 0);
    iVar31 = unaff_RSI * 4;
    uVar38 = (uint32_t)(*(uint64_t *)(unaff_RBX + 0x612670 + iVar25 * 0x18) >> (int8_t)((uVar30 & 0xf) << 2));
    uVar30 = (uVar38 & 0xf) >> 3;
    iVar28 = (int8_t)uVar30;
    uVar39 = iVar31 + -2 << (uVar27 & 0x3f);
    uVar36 = (uVar37 >> 0x3f & (uint64_t)uVar30) +
             (SUB168(auVar4 * auVar12, 8) + unaff_RBP + (uint64_t)(uVar37 < uVar33) << iVar28);
    uVar37 = ((uVar37 << iVar28) - (uint64_t)(uVar38 & 7)) + 4;
    auVar6._8_8_ = 0;
    auVar6._0_8_ = uVar39;
    auVar14._8_8_ = 0;
    auVar14._0_8_ = uVar37;
    uVar34 = SUB168(auVar6 * auVar14, 8);
    auVar7._8_8_ = 0;
    auVar7._0_8_ = uVar39;
    auVar15._8_8_ = 0;
    auVar15._0_8_ = uVar36;
    uVar33 = SUB168(auVar7 * auVar15, 0) + uVar34;
    Var26 = (unkbyte7)((uint64_t)unaff_RBP >> 8);
    uVar39 = iVar31 << (uVar27 & 0x3f);
    uVar42 = SUB168(auVar7 * auVar15, 8) + unaff_RBP + (uint64_t)(uVar33 < uVar34) | CONCAT71(Var26, 1 < uVar33);
    auVar8._8_8_ = 0;
    auVar8._0_8_ = uVar39;
    auVar16._8_8_ = 0;
    auVar16._0_8_ = uVar37;
    uVar34 = SUB168(auVar8 * auVar16, 8);
    auVar9._8_8_ = 0;
    auVar9._0_8_ = uVar39;
    auVar17._8_8_ = 0;
    auVar17._0_8_ = uVar36;
    uVar33 = SUB168(auVar9 * auVar17, 0) + uVar34;
    uVar39 = iVar31 + 2 << (uVar27 & 0x3f);
    uVar43 = SUB168(auVar9 * auVar17, 8) + unaff_RBP + (uint64_t)(uVar33 < uVar34) | CONCAT71(Var26, 1 < uVar33);
    auVar10._8_8_ = 0;
    auVar10._0_8_ = uVar39;
    auVar18._8_8_ = 0;
    auVar18._0_8_ = uVar37;
    uVar34 = SUB168(auVar10 * auVar18, 8);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = uVar39;
    auVar19._8_8_ = 0;
    auVar19._0_8_ = uVar36;
    uVar37 = SUB168(auVar11 * auVar19, 0) + uVar34;
    uVar33 = uVar43 >> 2;
    uVar34 = SUB168(auVar11 * auVar19, 8) + unaff_RBP + (uint64_t)(uVar37 < uVar34) | CONCAT71(Var26, 1 < uVar37);
    uVar37 = (uint64_t)((uint32_t)unaff_RSI & 1);
    if (9 < uVar33) {
        uVar36 = (uVar33 / 10) * 0x28;
        bVar45 = uVar36 + 0x28 + uVar37 <= uVar34;
        if (uVar37 + uVar42 <= uVar36 != bVar45) {
            iVar44 = iVar44 + 1;
            uVar33 = (uint64_t)bVar45 + uVar33 / 10;
            goto code_r0x000180098dfc;
        }
    }
    uVar36 = uVar43 & 0xfffffffffffffffc;
    bVar45 = uVar36 + 4 + uVar37 <= uVar34;
    bVar20 = (uVar36 - ((uint32_t)uVar33 & 1)) + 3 <= uVar43;
    if ((uint32_t)CONCAT71(Var26, uVar37 + uVar42 <= uVar36) != (uint32_t)bVar45) {
        bVar20 = bVar45;
    }
    uVar33 = bVar20 + uVar33;
code_r0x000180098dfc:
    piVar40 = &var_1ch;
    while (uVar30 = (uint32_t)uVar33, 9999 < uVar33) {
        uVar33 = uVar33 / 10000;
        uVar30 = uVar30 + (int32_t)uVar33 * -10000;
        *(undefined2 *)((int64_t)piVar40 + -4) = *(undefined2 *)((int64_t)(int32_t)((uVar30 / 100) * 2) + 0x180612590);
        *(undefined2 *)((int64_t)piVar40 + -2) = *(undefined2 *)((int64_t)(int32_t)((uVar30 % 100) * 2) + 0x180612590);
        piVar40 = (int64_t *)((int64_t)piVar40 + -4);
    }
    while (9 < uVar30) {
        piVar40 = (int64_t *)((int64_t)piVar40 + -2);
        uVar37 = (uVar33 & 0xffffffff) / 100;
        uVar30 = (uint32_t)uVar37;
        *(undefined2 *)piVar40 =
             *(undefined2 *)((int64_t)(int32_t)(((int32_t)uVar33 + uVar30 * -100) * 2) + 0x180612590);
        uVar33 = uVar37;
    }
    if (uVar30 != 0) {
        piVar40 = (int64_t *)((int64_t)piVar40 + -1);
        *(char *)piVar40 = (char)uVar30 + '0';
    }
    iVar32 = (int32_t)&var_1ch - (int32_t)piVar40;
    iVar44 = iVar32 + iVar44;
    if (iVar44 + 5U < 0x1b) {
        uVar21 = *(undefined4 *)piVar40;
        uVar22 = *(undefined4 *)((int64_t)piVar40 + 4);
        uVar23 = *(undefined4 *)(piVar40 + 1);
        uVar24 = *(undefined4 *)((int64_t)piVar40 + 0xc);
        if (iVar44 < 1) {
            *(undefined2 *)unaff_R14 = 0x2e30;
            *(undefined4 *)((int64_t)unaff_R14 + 2) = 0x30303030;
            *(undefined *)((int64_t)unaff_R14 + 6) = 0x30;
            uVar29 = *(undefined *)(piVar40 + 2);
            iVar31 = (int64_t)-iVar44;
            puVar2 = (undefined4 *)((int64_t)unaff_R14 + iVar31 + 2);
            *puVar2 = uVar21;
            puVar2[1] = uVar22;
            puVar2[2] = uVar23;
            puVar2[3] = uVar24;
            *(undefined *)((int64_t)unaff_R14 + iVar31 + 0x12) = uVar29;
            iVar31 = (int64_t)unaff_R14 + iVar31 + (int64_t)iVar32 + 2;
            cVar3 = *(char *)(iVar31 + -1);
            while (cVar3 == '0') {
                cVar3 = *(char *)(iVar31 + -2);
                iVar31 = iVar31 + -1;
            }
        } else {
            *unaff_R14 = uVar21;
            unaff_R14[1] = uVar22;
            unaff_R14[2] = uVar23;
            unaff_R14[3] = uVar24;
            puVar1 = (undefined *)((int64_t)unaff_R14 + (int64_t)iVar44);
            if (iVar44 == iVar32) {
                *(undefined *)(unaff_R14 + 4) = *(undefined *)(piVar40 + 2);
            } else {
                iVar31 = (int64_t)iVar32;
                if (iVar44 < iVar32) {
                    puVar2 = (undefined4 *)((int64_t)iVar44 + (int64_t)piVar40);
                    uVar21 = *puVar2;
                    uVar22 = puVar2[1];
                    uVar23 = puVar2[2];
                    uVar24 = puVar2[3];
                    *puVar1 = 0x2e;
                    *(undefined4 *)(puVar1 + 1) = uVar21;
                    *(undefined4 *)(puVar1 + 5) = uVar22;
                    *(undefined4 *)(puVar1 + 9) = uVar23;
                    *(undefined4 *)(puVar1 + 0xd) = uVar24;
                    cVar3 = *(char *)(iVar31 + (int64_t)unaff_R14);
                    iVar31 = (int64_t)unaff_R14 + iVar31 + 1;
                    while (cVar3 == '0') {
                        cVar3 = *(char *)(iVar31 + -2);
                        iVar31 = iVar31 + -1;
                    }
                } else {
                    *(undefined *)(unaff_R14 + 4) = *(undefined *)(piVar40 + 2);
                    *(undefined8 *)(iVar31 + (int64_t)unaff_R14) = 0x3030303030303030;
                }
            }
        }
    } else {
        uVar21 = *(undefined4 *)((int64_t)piVar40 + 1);
        uVar22 = *(undefined4 *)((int64_t)piVar40 + 5);
        uVar23 = *(undefined4 *)((int64_t)piVar40 + 9);
        uVar24 = *(undefined4 *)((int64_t)piVar40 + 0xd);
        *(undefined *)unaff_R14 = *(undefined *)piVar40;
        *(undefined *)((int64_t)unaff_R14 + 1) = 0x2e;
        *(undefined4 *)((int64_t)unaff_R14 + 2) = uVar21;
        *(undefined4 *)((int64_t)unaff_R14 + 6) = uVar22;
        *(undefined4 *)((int64_t)unaff_R14 + 10) = uVar23;
        *(undefined4 *)((int64_t)unaff_R14 + 0xe) = uVar24;
        cVar3 = *(char *)((int64_t)iVar32 + (int64_t)unaff_R14);
        puVar1 = (undefined *)((int64_t)unaff_R14 + (int64_t)iVar32 + 1);
        while (cVar3 == '0') {
            cVar3 = puVar1[-2];
            puVar1 = puVar1 + -1;
        }
        puVar35 = puVar1 + -1;
        if (puVar1[-1] != '.') {
            puVar35 = puVar1;
        }
        iVar44 = iVar44 + -1;
        uVar29 = 0x2b;
        if (iVar44 < 0) {
            uVar29 = 0x2d;
        }
        puVar35[1] = uVar29;
        puVar41 = (undefined2 *)(puVar35 + 2);
        *puVar35 = 0x65;
        iVar32 = -iVar44;
        if (0 < iVar44) {
            iVar32 = iVar44;
        }
        if (99 < iVar32) {
            *(char *)puVar41 = (char)(iVar32 / 100) + '0';
            puVar41 = (undefined2 *)(puVar35 + 3);
            iVar32 = iVar32 % 100;
        }
        *puVar41 = *(undefined2 *)((int64_t)(iVar32 * 2) + 0x180612590);
    }
    func_0x000180459870(arg_30h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_180098d68
// Address: 0x180098d68
// Size: 170 bytes
// ============================================================
void fcn.180098c01(undefined8 placeholder_0, int64_t arg2, int64_t arg3, undefined8 placeholder_3,
                  undefined8 placeholder_4, int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h)
{
    undefined *puVar1;
    undefined4 *puVar2;
    char cVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar19 [16];
    bool bVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    int64_t iVar25;
    unkbyte7 Var26;
    uint8_t uVar27;
    int8_t iVar28;
    undefined uVar29;
    uint32_t uVar30;
    int64_t iVar31;
    int32_t iVar32;
    uint64_t uVar33;
    uint64_t uVar34;
    undefined *puVar35;
    int64_t unaff_RBX;
    uint64_t uVar36;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    uint64_t uVar37;
    uint32_t uVar38;
    uint64_t uVar39;
    int64_t *piVar40;
    undefined2 *puVar41;
    uint64_t uVar42;
    uint64_t uVar43;
    undefined4 *unaff_R14;
    int32_t iVar44;
    bool bVar45;
    undefined2 auStackX_18 [2];
    int64_t var_1ch;
    
    iVar44 = (int32_t)((-(uint32_t)((int32_t)unaff_RBP != 0) & 0xfffe0040) + (int32_t)arg3 * 0x4d104) >> 0x14;
    uVar30 = 0x124 - iVar44;
    iVar25 = (int64_t)(int32_t)uVar30 >> 4;
    uVar27 = (char)(iVar44 * -0x35269e >> 0x14) + (char)arg3 + '\x01';
    uVar37 = *(uint64_t *)(unaff_RBX + 0x612510 + (uint64_t)(uVar30 & 0xf) * 8);
    auVar4._8_8_ = 0;
    auVar4._0_8_ = uVar37;
    auVar12._8_8_ = 0;
    auVar12._0_8_ = *(uint64_t *)(unaff_RBX + 0x612660 + iVar25 * 0x18);
    auVar5._8_8_ = 0;
    auVar5._0_8_ = uVar37;
    auVar13._8_8_ = 0;
    auVar13._0_8_ = *(uint64_t *)(unaff_RBX + 0x612668 + iVar25 * 0x18);
    uVar33 = SUB168(auVar5 * auVar13, 8);
    uVar37 = uVar33 + SUB168(auVar4 * auVar12, 0);
    iVar31 = unaff_RSI * 4;
    uVar38 = (uint32_t)(*(uint64_t *)(unaff_RBX + 0x612670 + iVar25 * 0x18) >> (int8_t)((uVar30 & 0xf) << 2));
    uVar30 = (uVar38 & 0xf) >> 3;
    iVar28 = (int8_t)uVar30;
    uVar39 = iVar31 + -2 << (uVar27 & 0x3f);
    uVar36 = (uVar37 >> 0x3f & (uint64_t)uVar30) +
             (SUB168(auVar4 * auVar12, 8) + unaff_RBP + (uint64_t)(uVar37 < uVar33) << iVar28);
    uVar37 = ((uVar37 << iVar28) - (uint64_t)(uVar38 & 7)) + 4;
    auVar6._8_8_ = 0;
    auVar6._0_8_ = uVar39;
    auVar14._8_8_ = 0;
    auVar14._0_8_ = uVar37;
    uVar34 = SUB168(auVar6 * auVar14, 8);
    auVar7._8_8_ = 0;
    auVar7._0_8_ = uVar39;
    auVar15._8_8_ = 0;
    auVar15._0_8_ = uVar36;
    uVar33 = SUB168(auVar7 * auVar15, 0) + uVar34;
    Var26 = (unkbyte7)((uint64_t)unaff_RBP >> 8);
    uVar39 = iVar31 << (uVar27 & 0x3f);
    uVar42 = SUB168(auVar7 * auVar15, 8) + unaff_RBP + (uint64_t)(uVar33 < uVar34) | CONCAT71(Var26, 1 < uVar33);
    auVar8._8_8_ = 0;
    auVar8._0_8_ = uVar39;
    auVar16._8_8_ = 0;
    auVar16._0_8_ = uVar37;
    uVar34 = SUB168(auVar8 * auVar16, 8);
    auVar9._8_8_ = 0;
    auVar9._0_8_ = uVar39;
    auVar17._8_8_ = 0;
    auVar17._0_8_ = uVar36;
    uVar33 = SUB168(auVar9 * auVar17, 0) + uVar34;
    uVar39 = iVar31 + 2 << (uVar27 & 0x3f);
    uVar43 = SUB168(auVar9 * auVar17, 8) + unaff_RBP + (uint64_t)(uVar33 < uVar34) | CONCAT71(Var26, 1 < uVar33);
    auVar10._8_8_ = 0;
    auVar10._0_8_ = uVar39;
    auVar18._8_8_ = 0;
    auVar18._0_8_ = uVar37;
    uVar34 = SUB168(auVar10 * auVar18, 8);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = uVar39;
    auVar19._8_8_ = 0;
    auVar19._0_8_ = uVar36;
    uVar37 = SUB168(auVar11 * auVar19, 0) + uVar34;
    uVar33 = uVar43 >> 2;
    uVar34 = SUB168(auVar11 * auVar19, 8) + unaff_RBP + (uint64_t)(uVar37 < uVar34) | CONCAT71(Var26, 1 < uVar37);
    uVar37 = (uint64_t)((uint32_t)unaff_RSI & 1);
    if (9 < uVar33) {
        uVar36 = (uVar33 / 10) * 0x28;
        bVar45 = uVar36 + 0x28 + uVar37 <= uVar34;
        if (uVar37 + uVar42 <= uVar36 != bVar45) {
            iVar44 = iVar44 + 1;
            uVar33 = (uint64_t)bVar45 + uVar33 / 10;
            goto code_r0x000180098dfc;
        }
    }
    uVar36 = uVar43 & 0xfffffffffffffffc;
    bVar45 = uVar36 + 4 + uVar37 <= uVar34;
    bVar20 = (uVar36 - ((uint32_t)uVar33 & 1)) + 3 <= uVar43;
    if ((uint32_t)CONCAT71(Var26, uVar37 + uVar42 <= uVar36) != (uint32_t)bVar45) {
        bVar20 = bVar45;
    }
    uVar33 = bVar20 + uVar33;
code_r0x000180098dfc:
    piVar40 = &var_1ch;
    while (uVar30 = (uint32_t)uVar33, 9999 < uVar33) {
        uVar33 = uVar33 / 10000;
        uVar30 = uVar30 + (int32_t)uVar33 * -10000;
        *(undefined2 *)((int64_t)piVar40 + -4) = *(undefined2 *)((int64_t)(int32_t)((uVar30 / 100) * 2) + 0x180612590);
        *(undefined2 *)((int64_t)piVar40 + -2) = *(undefined2 *)((int64_t)(int32_t)((uVar30 % 100) * 2) + 0x180612590);
        piVar40 = (int64_t *)((int64_t)piVar40 + -4);
    }
    while (9 < uVar30) {
        piVar40 = (int64_t *)((int64_t)piVar40 + -2);
        uVar37 = (uVar33 & 0xffffffff) / 100;
        uVar30 = (uint32_t)uVar37;
        *(undefined2 *)piVar40 =
             *(undefined2 *)((int64_t)(int32_t)(((int32_t)uVar33 + uVar30 * -100) * 2) + 0x180612590);
        uVar33 = uVar37;
    }
    if (uVar30 != 0) {
        piVar40 = (int64_t *)((int64_t)piVar40 + -1);
        *(char *)piVar40 = (char)uVar30 + '0';
    }
    iVar32 = (int32_t)&var_1ch - (int32_t)piVar40;
    iVar44 = iVar32 + iVar44;
    if (iVar44 + 5U < 0x1b) {
        uVar21 = *(undefined4 *)piVar40;
        uVar22 = *(undefined4 *)((int64_t)piVar40 + 4);
        uVar23 = *(undefined4 *)(piVar40 + 1);
        uVar24 = *(undefined4 *)((int64_t)piVar40 + 0xc);
        if (iVar44 < 1) {
            *(undefined2 *)unaff_R14 = 0x2e30;
            *(undefined4 *)((int64_t)unaff_R14 + 2) = 0x30303030;
            *(undefined *)((int64_t)unaff_R14 + 6) = 0x30;
            uVar29 = *(undefined *)(piVar40 + 2);
            iVar31 = (int64_t)-iVar44;
            puVar2 = (undefined4 *)((int64_t)unaff_R14 + iVar31 + 2);
            *puVar2 = uVar21;
            puVar2[1] = uVar22;
            puVar2[2] = uVar23;
            puVar2[3] = uVar24;
            *(undefined *)((int64_t)unaff_R14 + iVar31 + 0x12) = uVar29;
            iVar31 = (int64_t)unaff_R14 + iVar31 + (int64_t)iVar32 + 2;
            cVar3 = *(char *)(iVar31 + -1);
            while (cVar3 == '0') {
                cVar3 = *(char *)(iVar31 + -2);
                iVar31 = iVar31 + -1;
            }
        } else {
            *unaff_R14 = uVar21;
            unaff_R14[1] = uVar22;
            unaff_R14[2] = uVar23;
            unaff_R14[3] = uVar24;
            puVar1 = (undefined *)((int64_t)unaff_R14 + (int64_t)iVar44);
            if (iVar44 == iVar32) {
                *(undefined *)(unaff_R14 + 4) = *(undefined *)(piVar40 + 2);
            } else {
                iVar31 = (int64_t)iVar32;
                if (iVar44 < iVar32) {
                    puVar2 = (undefined4 *)((int64_t)iVar44 + (int64_t)piVar40);
                    uVar21 = *puVar2;
                    uVar22 = puVar2[1];
                    uVar23 = puVar2[2];
                    uVar24 = puVar2[3];
                    *puVar1 = 0x2e;
                    *(undefined4 *)(puVar1 + 1) = uVar21;
                    *(undefined4 *)(puVar1 + 5) = uVar22;
                    *(undefined4 *)(puVar1 + 9) = uVar23;
                    *(undefined4 *)(puVar1 + 0xd) = uVar24;
                    cVar3 = *(char *)(iVar31 + (int64_t)unaff_R14);
                    iVar31 = (int64_t)unaff_R14 + iVar31 + 1;
                    while (cVar3 == '0') {
                        cVar3 = *(char *)(iVar31 + -2);
                        iVar31 = iVar31 + -1;
                    }
                } else {
                    *(undefined *)(unaff_R14 + 4) = *(undefined *)(piVar40 + 2);
                    *(undefined8 *)(iVar31 + (int64_t)unaff_R14) = 0x3030303030303030;
                }
            }
        }
    } else {
        uVar21 = *(undefined4 *)((int64_t)piVar40 + 1);
        uVar22 = *(undefined4 *)((int64_t)piVar40 + 5);
        uVar23 = *(undefined4 *)((int64_t)piVar40 + 9);
        uVar24 = *(undefined4 *)((int64_t)piVar40 + 0xd);
        *(undefined *)unaff_R14 = *(undefined *)piVar40;
        *(undefined *)((int64_t)unaff_R14 + 1) = 0x2e;
        *(undefined4 *)((int64_t)unaff_R14 + 2) = uVar21;
        *(undefined4 *)((int64_t)unaff_R14 + 6) = uVar22;
        *(undefined4 *)((int64_t)unaff_R14 + 10) = uVar23;
        *(undefined4 *)((int64_t)unaff_R14 + 0xe) = uVar24;
        cVar3 = *(char *)((int64_t)iVar32 + (int64_t)unaff_R14);
        puVar1 = (undefined *)((int64_t)unaff_R14 + (int64_t)iVar32 + 1);
        while (cVar3 == '0') {
            cVar3 = puVar1[-2];
            puVar1 = puVar1 + -1;
        }
        puVar35 = puVar1 + -1;
        if (puVar1[-1] != '.') {
            puVar35 = puVar1;
        }
        iVar44 = iVar44 + -1;
        uVar29 = 0x2b;
        if (iVar44 < 0) {
            uVar29 = 0x2d;
        }
        puVar35[1] = uVar29;
        puVar41 = (undefined2 *)(puVar35 + 2);
        *puVar35 = 0x65;
        iVar32 = -iVar44;
        if (0 < iVar44) {
            iVar32 = iVar44;
        }
        if (99 < iVar32) {
            *(char *)puVar41 = (char)(iVar32 / 100) + '0';
            puVar41 = (undefined2 *)(puVar35 + 3);
            iVar32 = iVar32 % 100;
        }
        *puVar41 = *(undefined2 *)((int64_t)(iVar32 * 2) + 0x180612590);
    }
    func_0x000180459870(arg_30h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_180098e12
// Address: 0x180098e12
// Size: 615 bytes
// ============================================================
void fcn.180098c01(undefined8 placeholder_0, int64_t arg2, int64_t arg3, undefined8 placeholder_3,
                  undefined8 placeholder_4, int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h,
                  int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_90h)
{
    undefined *puVar1;
    undefined4 *puVar2;
    char cVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [16];
    undefined auVar9 [16];
    undefined auVar10 [16];
    undefined auVar11 [16];
    undefined auVar12 [16];
    undefined auVar13 [16];
    undefined auVar14 [16];
    undefined auVar15 [16];
    undefined auVar16 [16];
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined auVar19 [16];
    bool bVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    undefined4 uVar23;
    undefined4 uVar24;
    int64_t iVar25;
    unkbyte7 Var26;
    uint8_t uVar27;
    int8_t iVar28;
    undefined uVar29;
    uint32_t uVar30;
    int64_t iVar31;
    int32_t iVar32;
    uint64_t uVar33;
    uint64_t uVar34;
    undefined *puVar35;
    int64_t unaff_RBX;
    uint64_t uVar36;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    uint64_t uVar37;
    uint32_t uVar38;
    uint64_t uVar39;
    int64_t *piVar40;
    undefined2 *puVar41;
    uint64_t uVar42;
    uint64_t uVar43;
    undefined4 *unaff_R14;
    int32_t iVar44;
    bool bVar45;
    undefined2 auStackX_18 [2];
    int64_t var_1ch;
    
    iVar44 = (int32_t)((-(uint32_t)((int32_t)unaff_RBP != 0) & 0xfffe0040) + (int32_t)arg3 * 0x4d104) >> 0x14;
    uVar30 = 0x124 - iVar44;
    iVar25 = (int64_t)(int32_t)uVar30 >> 4;
    uVar27 = (char)(iVar44 * -0x35269e >> 0x14) + (char)arg3 + '\x01';
    uVar37 = *(uint64_t *)(unaff_RBX + 0x612510 + (uint64_t)(uVar30 & 0xf) * 8);
    auVar4._8_8_ = 0;
    auVar4._0_8_ = uVar37;
    auVar12._8_8_ = 0;
    auVar12._0_8_ = *(uint64_t *)(unaff_RBX + 0x612660 + iVar25 * 0x18);
    auVar5._8_8_ = 0;
    auVar5._0_8_ = uVar37;
    auVar13._8_8_ = 0;
    auVar13._0_8_ = *(uint64_t *)(unaff_RBX + 0x612668 + iVar25 * 0x18);
    uVar33 = SUB168(auVar5 * auVar13, 8);
    uVar37 = uVar33 + SUB168(auVar4 * auVar12, 0);
    iVar31 = unaff_RSI * 4;
    uVar38 = (uint32_t)(*(uint64_t *)(unaff_RBX + 0x612670 + iVar25 * 0x18) >> (int8_t)((uVar30 & 0xf) << 2));
    uVar30 = (uVar38 & 0xf) >> 3;
    iVar28 = (int8_t)uVar30;
    uVar39 = iVar31 + -2 << (uVar27 & 0x3f);
    uVar36 = (uVar37 >> 0x3f & (uint64_t)uVar30) +
             (SUB168(auVar4 * auVar12, 8) + unaff_RBP + (uint64_t)(uVar37 < uVar33) << iVar28);
    uVar37 = ((uVar37 << iVar28) - (uint64_t)(uVar38 & 7)) + 4;
    auVar6._8_8_ = 0;
    auVar6._0_8_ = uVar39;
    auVar14._8_8_ = 0;
    auVar14._0_8_ = uVar37;
    uVar34 = SUB168(auVar6 * auVar14, 8);
    auVar7._8_8_ = 0;
    auVar7._0_8_ = uVar39;
    auVar15._8_8_ = 0;
    auVar15._0_8_ = uVar36;
    uVar33 = SUB168(auVar7 * auVar15, 0) + uVar34;
    Var26 = (unkbyte7)((uint64_t)unaff_RBP >> 8);
    uVar39 = iVar31 << (uVar27 & 0x3f);
    uVar42 = SUB168(auVar7 * auVar15, 8) + unaff_RBP + (uint64_t)(uVar33 < uVar34) | CONCAT71(Var26, 1 < uVar33);
    auVar8._8_8_ = 0;
    auVar8._0_8_ = uVar39;
    auVar16._8_8_ = 0;
    auVar16._0_8_ = uVar37;
    uVar34 = SUB168(auVar8 * auVar16, 8);
    auVar9._8_8_ = 0;
    auVar9._0_8_ = uVar39;
    auVar17._8_8_ = 0;
    auVar17._0_8_ = uVar36;
    uVar33 = SUB168(auVar9 * auVar17, 0) + uVar34;
    uVar39 = iVar31 + 2 << (uVar27 & 0x3f);
    uVar43 = SUB168(auVar9 * auVar17, 8) + unaff_RBP + (uint64_t)(uVar33 < uVar34) | CONCAT71(Var26, 1 < uVar33);
    auVar10._8_8_ = 0;
    auVar10._0_8_ = uVar39;
    auVar18._8_8_ = 0;
    auVar18._0_8_ = uVar37;
    uVar34 = SUB168(auVar10 * auVar18, 8);
    auVar11._8_8_ = 0;
    auVar11._0_8_ = uVar39;
    auVar19._8_8_ = 0;
    auVar19._0_8_ = uVar36;
    uVar37 = SUB168(auVar11 * auVar19, 0) + uVar34;
    uVar33 = uVar43 >> 2;
    uVar34 = SUB168(auVar11 * auVar19, 8) + unaff_RBP + (uint64_t)(uVar37 < uVar34) | CONCAT71(Var26, 1 < uVar37);
    uVar37 = (uint64_t)((uint32_t)unaff_RSI & 1);
    if (9 < uVar33) {
        uVar36 = (uVar33 / 10) * 0x28;
        bVar45 = uVar36 + 0x28 + uVar37 <= uVar34;
        if (uVar37 + uVar42 <= uVar36 != bVar45) {
            iVar44 = iVar44 + 1;
            uVar33 = (uint64_t)bVar45 + uVar33 / 10;
            goto code_r0x000180098dfc;
        }
    }
    uVar36 = uVar43 & 0xfffffffffffffffc;
    bVar45 = uVar36 + 4 + uVar37 <= uVar34;
    bVar20 = (uVar36 - ((uint32_t)uVar33 & 1)) + 3 <= uVar43;
    if ((uint32_t)CONCAT71(Var26, uVar37 + uVar42 <= uVar36) != (uint32_t)bVar45) {
        bVar20 = bVar45;
    }
    uVar33 = bVar20 + uVar33;
code_r0x000180098dfc:
    piVar40 = &var_1ch;
    while (uVar30 = (uint32_t)uVar33, 9999 < uVar33) {
        uVar33 = uVar33 / 10000;
        uVar30 = uVar30 + (int32_t)uVar33 * -10000;
        *(undefined2 *)((int64_t)piVar40 + -4) = *(undefined2 *)((int64_t)(int32_t)((uVar30 / 100) * 2) + 0x180612590);
        *(undefined2 *)((int64_t)piVar40 + -2) = *(undefined2 *)((int64_t)(int32_t)((uVar30 % 100) * 2) + 0x180612590);
        piVar40 = (int64_t *)((int64_t)piVar40 + -4);
    }
    while (9 < uVar30) {
        piVar40 = (int64_t *)((int64_t)piVar40 + -2);
        uVar37 = (uVar33 & 0xffffffff) / 100;
        uVar30 = (uint32_t)uVar37;
        *(undefined2 *)piVar40 =
             *(undefined2 *)((int64_t)(int32_t)(((int32_t)uVar33 + uVar30 * -100) * 2) + 0x180612590);
        uVar33 = uVar37;
    }
    if (uVar30 != 0) {
        piVar40 = (int64_t *)((int64_t)piVar40 + -1);
        *(char *)piVar40 = (char)uVar30 + '0';
    }
    iVar32 = (int32_t)&var_1ch - (int32_t)piVar40;
    iVar44 = iVar32 + iVar44;
    if (iVar44 + 5U < 0x1b) {
        uVar21 = *(undefined4 *)piVar40;
        uVar22 = *(undefined4 *)((int64_t)piVar40 + 4);
        uVar23 = *(undefined4 *)(piVar40 + 1);
        uVar24 = *(undefined4 *)((int64_t)piVar40 + 0xc);
        if (iVar44 < 1) {
            *(undefined2 *)unaff_R14 = 0x2e30;
            *(undefined4 *)((int64_t)unaff_R14 + 2) = 0x30303030;
            *(undefined *)((int64_t)unaff_R14 + 6) = 0x30;
            uVar29 = *(undefined *)(piVar40 + 2);
            iVar31 = (int64_t)-iVar44;
            puVar2 = (undefined4 *)((int64_t)unaff_R14 + iVar31 + 2);
            *puVar2 = uVar21;
            puVar2[1] = uVar22;
            puVar2[2] = uVar23;
            puVar2[3] = uVar24;
            *(undefined *)((int64_t)unaff_R14 + iVar31 + 0x12) = uVar29;
            iVar31 = (int64_t)unaff_R14 + iVar31 + (int64_t)iVar32 + 2;
            cVar3 = *(char *)(iVar31 + -1);
            while (cVar3 == '0') {
                cVar3 = *(char *)(iVar31 + -2);
                iVar31 = iVar31 + -1;
            }
        } else {
            *unaff_R14 = uVar21;
            unaff_R14[1] = uVar22;
            unaff_R14[2] = uVar23;
            unaff_R14[3] = uVar24;
            puVar1 = (undefined *)((int64_t)unaff_R14 + (int64_t)iVar44);
            if (iVar44 == iVar32) {
                *(undefined *)(unaff_R14 + 4) = *(undefined *)(piVar40 + 2);
            } else {
                iVar31 = (int64_t)iVar32;
                if (iVar44 < iVar32) {
                    puVar2 = (undefined4 *)((int64_t)iVar44 + (int64_t)piVar40);
                    uVar21 = *puVar2;
                    uVar22 = puVar2[1];
                    uVar23 = puVar2[2];
                    uVar24 = puVar2[3];
                    *puVar1 = 0x2e;
                    *(undefined4 *)(puVar1 + 1) = uVar21;
                    *(undefined4 *)(puVar1 + 5) = uVar22;
                    *(undefined4 *)(puVar1 + 9) = uVar23;
                    *(undefined4 *)(puVar1 + 0xd) = uVar24;
                    cVar3 = *(char *)(iVar31 + (int64_t)unaff_R14);
                    iVar31 = (int64_t)unaff_R14 + iVar31 + 1;
                    while (cVar3 == '0') {
                        cVar3 = *(char *)(iVar31 + -2);
                        iVar31 = iVar31 + -1;
                    }
                } else {
                    *(undefined *)(unaff_R14 + 4) = *(undefined *)(piVar40 + 2);
                    *(undefined8 *)(iVar31 + (int64_t)unaff_R14) = 0x3030303030303030;
                }
            }
        }
    } else {
        uVar21 = *(undefined4 *)((int64_t)piVar40 + 1);
        uVar22 = *(undefined4 *)((int64_t)piVar40 + 5);
        uVar23 = *(undefined4 *)((int64_t)piVar40 + 9);
        uVar24 = *(undefined4 *)((int64_t)piVar40 + 0xd);
        *(undefined *)unaff_R14 = *(undefined *)piVar40;
        *(undefined *)((int64_t)unaff_R14 + 1) = 0x2e;
        *(undefined4 *)((int64_t)unaff_R14 + 2) = uVar21;
        *(undefined4 *)((int64_t)unaff_R14 + 6) = uVar22;
        *(undefined4 *)((int64_t)unaff_R14 + 10) = uVar23;
        *(undefined4 *)((int64_t)unaff_R14 + 0xe) = uVar24;
        cVar3 = *(char *)((int64_t)iVar32 + (int64_t)unaff_R14);
        puVar1 = (undefined *)((int64_t)unaff_R14 + (int64_t)iVar32 + 1);
        while (cVar3 == '0') {
            cVar3 = puVar1[-2];
            puVar1 = puVar1 + -1;
        }
        puVar35 = puVar1 + -1;
        if (puVar1[-1] != '.') {
            puVar35 = puVar1;
        }
        iVar44 = iVar44 + -1;
        uVar29 = 0x2b;
        if (iVar44 < 0) {
            uVar29 = 0x2d;
        }
        puVar35[1] = uVar29;
        puVar41 = (undefined2 *)(puVar35 + 2);
        *puVar35 = 0x65;
        iVar32 = -iVar44;
        if (0 < iVar44) {
            iVar32 = iVar44;
        }
        if (99 < iVar32) {
            *(char *)puVar41 = (char)(iVar32 / 100) + '0';
            puVar41 = (undefined2 *)(puVar35 + 3);
            iVar32 = iVar32 % 100;
        }
        *puVar41 = *(undefined2 *)((int64_t)(iVar32 * 2) + 0x180612590);
    }
    func_0x000180459870(arg_30h ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_180099080
// Address: 0x180099080
// Size: 182 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180099080(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = 10;
    iVar4 = 1;
    uVar3 = -arg2;
    if (0 < arg2) {
        uVar3 = arg2;
    }
    do {
        if (uVar3 < uVar1) break;
        iVar4 = iVar4 + 1;
        uVar1 = uVar1 * 10;
    } while (iVar4 < 0x13);
    iVar5 = iVar4;
    if (-1 < arg2) {
        iVar5 = iVar4 + -1;
    }
    *(undefined *)((int64_t)iVar5 + 1 + arg1) = 0;
    do {
        uVar1 = uVar3 / 10;
        iVar2 = (int64_t)iVar5;
        iVar5 = iVar5 + -1;
        *(char *)(iVar2 + arg1) = (char)uVar3 + (char)uVar1 * -10 + '0';
        uVar3 = uVar1;
    } while (uVar1 != 0);
    if (arg2 < 0) {
        *(undefined *)(iVar5 + arg1) = 0x2d;
    }
    iVar5 = iVar4 + 1;
    if (-1 < arg2) {
        iVar5 = iVar4;
    }
    return iVar5 + arg1;
}

// ============================================================
// Function: FUN_1800992c0
// Address: 0x1800992c0
// Size: 189 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.1800992c0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar3 = func_0x00018046b62c(arg1, &var_8h);
    *(undefined8 *)arg2 = uVar3;
    if (var_8h == arg1) {
        return false;
    }
    if ((*(char *)var_8h + 0xa8U & 0xdf) == 0) {
        uVar1 = func_0x00018046c694(arg1, &var_8h, 0x10);
        *(double *)arg2 = (double)(uint64_t)uVar1;
    }
    if (*(char *)var_8h == '\0') {
        return true;
    }
    iVar2 = func_0x00018046ce40(*(char *)var_8h);
    while (iVar2 != 0) {
        var_8h = var_8h + 1;
        iVar2 = func_0x00018046ce40(*(char *)var_8h);
    }
    return *(char *)var_8h == '\0';
}

// ============================================================
// Function: FUN_180099380
// Address: 0x180099380
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_238h
// WARNING: Variable defined which should be unmapped: var_230h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.180099380(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined auStackY_258 [32];
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_258;
    fcn.1800102c0();
    var_238h = 0;
    var_230h = arg3;
    fcn.180467554(0, arg3);
    puVar1 = *(undefined8 **)(arg1 + 0x40);
    uVar2 = fcn.180498cd0(&var_228h);
    uVar2 = fcn.18009a8e0(arg1, &var_228h, uVar2);
    *puVar1 = uVar2;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 6;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        fcn.1800934a0(arg1, 1);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180459870(var_28h ^ (uint64_t)auStackY_258);
    return;
}

// ============================================================
// Function: FUN_180099450
// Address: 0x180099450
// Size: 34 bytes
// ============================================================
void fcn.180099450(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    var_18h = arg3;
    var_20h = arg4;
    fcn.180099380(arg1, arg2, (int64_t)&var_18h);
    return;
}

// ============================================================
// Function: FUN_180099480
// Address: 0x180099480
// Size: 719 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_4621f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4621b8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46217ch because it doesn't fit into ProtoModel

int64_t fcn.180099480(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    char *pcVar1;
    char cVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined2 *puVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined4 *puVar9;
    undefined2 *puVar10;
    int64_t iVar11;
    int64_t var_8h;
    
    if (*(char *)arg3 == '=') {
        if (0x100 < (uint64_t)arg4) {
            uVar3 = *(undefined4 *)(arg3 + 5);
            uVar4 = *(undefined4 *)(arg3 + 9);
            uVar5 = *(undefined4 *)(arg3 + 0xd);
            *(undefined4 *)arg1 = *(undefined4 *)(arg3 + 1);
            *(undefined4 *)(arg1 + 4) = uVar3;
            *(undefined4 *)(arg1 + 8) = uVar4;
            *(undefined4 *)(arg1 + 0xc) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x15);
            uVar4 = *(undefined4 *)(arg3 + 0x19);
            uVar5 = *(undefined4 *)(arg3 + 0x1d);
            *(undefined4 *)(arg1 + 0x10) = *(undefined4 *)(arg3 + 0x11);
            *(undefined4 *)(arg1 + 0x14) = uVar3;
            *(undefined4 *)(arg1 + 0x18) = uVar4;
            *(undefined4 *)(arg1 + 0x1c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x25);
            uVar4 = *(undefined4 *)(arg3 + 0x29);
            uVar5 = *(undefined4 *)(arg3 + 0x2d);
            *(undefined4 *)(arg1 + 0x20) = *(undefined4 *)(arg3 + 0x21);
            *(undefined4 *)(arg1 + 0x24) = uVar3;
            *(undefined4 *)(arg1 + 0x28) = uVar4;
            *(undefined4 *)(arg1 + 0x2c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x35);
            uVar4 = *(undefined4 *)(arg3 + 0x39);
            uVar5 = *(undefined4 *)(arg3 + 0x3d);
            *(undefined4 *)(arg1 + 0x30) = *(undefined4 *)(arg3 + 0x31);
            *(undefined4 *)(arg1 + 0x34) = uVar3;
            *(undefined4 *)(arg1 + 0x38) = uVar4;
            *(undefined4 *)(arg1 + 0x3c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x45);
            uVar4 = *(undefined4 *)(arg3 + 0x49);
            uVar5 = *(undefined4 *)(arg3 + 0x4d);
            *(undefined4 *)(arg1 + 0x40) = *(undefined4 *)(arg3 + 0x41);
            *(undefined4 *)(arg1 + 0x44) = uVar3;
            *(undefined4 *)(arg1 + 0x48) = uVar4;
            *(undefined4 *)(arg1 + 0x4c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x55);
            uVar4 = *(undefined4 *)(arg3 + 0x59);
            uVar5 = *(undefined4 *)(arg3 + 0x5d);
            *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg3 + 0x51);
            *(undefined4 *)(arg1 + 0x54) = uVar3;
            *(undefined4 *)(arg1 + 0x58) = uVar4;
            *(undefined4 *)(arg1 + 0x5c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x65);
            uVar4 = *(undefined4 *)(arg3 + 0x69);
            uVar5 = *(undefined4 *)(arg3 + 0x6d);
            *(undefined4 *)(arg1 + 0x60) = *(undefined4 *)(arg3 + 0x61);
            *(undefined4 *)(arg1 + 100) = uVar3;
            *(undefined4 *)(arg1 + 0x68) = uVar4;
            *(undefined4 *)(arg1 + 0x6c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x75);
            uVar4 = *(undefined4 *)(arg3 + 0x79);
            uVar5 = *(undefined4 *)(arg3 + 0x7d);
            *(undefined4 *)(arg1 + 0x70) = *(undefined4 *)(arg3 + 0x71);
            *(undefined4 *)(arg1 + 0x74) = uVar3;
            *(undefined4 *)(arg1 + 0x78) = uVar4;
            *(undefined4 *)(arg1 + 0x7c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x85);
            uVar4 = *(undefined4 *)(arg3 + 0x89);
            uVar5 = *(undefined4 *)(arg3 + 0x8d);
            *(undefined4 *)(arg1 + 0x80) = *(undefined4 *)(arg3 + 0x81);
            *(undefined4 *)(arg1 + 0x84) = uVar3;
            *(undefined4 *)(arg1 + 0x88) = uVar4;
            *(undefined4 *)(arg1 + 0x8c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x95);
            uVar4 = *(undefined4 *)(arg3 + 0x99);
            uVar5 = *(undefined4 *)(arg3 + 0x9d);
            *(undefined4 *)(arg1 + 0x90) = *(undefined4 *)(arg3 + 0x91);
            *(undefined4 *)(arg1 + 0x94) = uVar3;
            *(undefined4 *)(arg1 + 0x98) = uVar4;
            *(undefined4 *)(arg1 + 0x9c) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0xa5);
            uVar4 = *(undefined4 *)(arg3 + 0xa9);
            uVar5 = *(undefined4 *)(arg3 + 0xad);
            *(undefined4 *)(arg1 + 0xa0) = *(undefined4 *)(arg3 + 0xa1);
            *(undefined4 *)(arg1 + 0xa4) = uVar3;
            *(undefined4 *)(arg1 + 0xa8) = uVar4;
            *(undefined4 *)(arg1 + 0xac) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0xb5);
            uVar4 = *(undefined4 *)(arg3 + 0xb9);
            uVar5 = *(undefined4 *)(arg3 + 0xbd);
            *(undefined4 *)(arg1 + 0xb0) = *(undefined4 *)(arg3 + 0xb1);
            *(undefined4 *)(arg1 + 0xb4) = uVar3;
            *(undefined4 *)(arg1 + 0xb8) = uVar4;
            *(undefined4 *)(arg1 + 0xbc) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0xc5);
            uVar4 = *(undefined4 *)(arg3 + 0xc9);
            uVar5 = *(undefined4 *)(arg3 + 0xcd);
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(arg3 + 0xc1);
            *(undefined4 *)(arg1 + 0xc4) = uVar3;
            *(undefined4 *)(arg1 + 200) = uVar4;
            *(undefined4 *)(arg1 + 0xcc) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0xd5);
            uVar4 = *(undefined4 *)(arg3 + 0xd9);
            uVar5 = *(undefined4 *)(arg3 + 0xdd);
            *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(arg3 + 0xd1);
            *(undefined4 *)(arg1 + 0xd4) = uVar3;
            *(undefined4 *)(arg1 + 0xd8) = uVar4;
            *(undefined4 *)(arg1 + 0xdc) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0xe5);
            uVar4 = *(undefined4 *)(arg3 + 0xe9);
            uVar5 = *(undefined4 *)(arg3 + 0xed);
            *(undefined4 *)(arg1 + 0xe0) = *(undefined4 *)(arg3 + 0xe1);
            *(undefined4 *)(arg1 + 0xe4) = uVar3;
            *(undefined4 *)(arg1 + 0xe8) = uVar4;
            *(undefined4 *)(arg1 + 0xec) = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0xf4);
            uVar4 = *(undefined4 *)(arg3 + 0xf8);
            uVar5 = *(undefined4 *)(arg3 + 0xfc);
            *(undefined4 *)(arg1 + 0xef) = *(undefined4 *)(arg3 + 0xf0);
            *(undefined4 *)(arg1 + 0xf3) = uVar3;
            *(undefined4 *)(arg1 + 0xf7) = uVar4;
            *(undefined4 *)(arg1 + 0xfb) = uVar5;
            *(undefined *)(arg1 + 0xff) = 0;
            return arg1;
        }
    } else {
        if (*(char *)arg3 != '@') {
            uVar7 = fcn.180461e90(arg3);
            *(undefined8 *)arg1 = 0x20676e697274735b;
            if (0xf1 < uVar7) {
                uVar7 = 0xf1;
            }
            *(undefined2 *)(arg1 + 8) = 0x22;
            if (*(char *)(uVar7 + arg3) == '\0') {
                iVar8 = arg1 + -1;
                do {
                    pcVar1 = (char *)(iVar8 + 1);
                    iVar8 = iVar8 + 1;
                } while (*pcVar1 != '\0');
                iVar11 = 0;
                do {
                    cVar2 = *(char *)(arg3 + iVar11);
                    *(char *)(iVar8 + iVar11) = cVar2;
                    iVar11 = iVar11 + 1;
                } while (cVar2 != '\0');
            } else {
                fcn.180498b20(arg1, arg3);
                puVar9 = (undefined4 *)(arg1 + -1);
                do {
                    pcVar1 = (char *)((int64_t)puVar9 + 1);
                    puVar9 = (undefined4 *)((int64_t)puVar9 + 1);
                } while (*pcVar1 != '\0');
                *puVar9 = 0x2e2e2e;
            }
            puVar6 = (undefined2 *)(arg1 + -1);
            do {
                puVar10 = puVar6;
                puVar6 = (undefined2 *)((int64_t)puVar10 + 1);
            } while (*(char *)((int64_t)puVar10 + 1) != '\0');
            *(undefined2 *)((int64_t)puVar10 + 1) = 0x5d22;
            *(undefined *)((int64_t)puVar10 + 3) = 0;
            return arg1;
        }
        if (0x100 < (uint64_t)arg4) {
            *(undefined2 *)arg1 = 0x2e2e;
            *(undefined *)(arg1 + 2) = 0x2e;
            puVar9 = (undefined4 *)(arg3 + -0xfc + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 3) = *puVar9;
            *(undefined4 *)(arg1 + 7) = uVar3;
            *(undefined4 *)(arg1 + 0xb) = uVar4;
            *(undefined4 *)(arg1 + 0xf) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0xec + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x13) = *puVar9;
            *(undefined4 *)(arg1 + 0x17) = uVar3;
            *(undefined4 *)(arg1 + 0x1b) = uVar4;
            *(undefined4 *)(arg1 + 0x1f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0xdc + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x23) = *puVar9;
            *(undefined4 *)(arg1 + 0x27) = uVar3;
            *(undefined4 *)(arg1 + 0x2b) = uVar4;
            *(undefined4 *)(arg1 + 0x2f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0xcc + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x33) = *puVar9;
            *(undefined4 *)(arg1 + 0x37) = uVar3;
            *(undefined4 *)(arg1 + 0x3b) = uVar4;
            *(undefined4 *)(arg1 + 0x3f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0xbc + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x43) = *puVar9;
            *(undefined4 *)(arg1 + 0x47) = uVar3;
            *(undefined4 *)(arg1 + 0x4b) = uVar4;
            *(undefined4 *)(arg1 + 0x4f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0xac + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x53) = *puVar9;
            *(undefined4 *)(arg1 + 0x57) = uVar3;
            *(undefined4 *)(arg1 + 0x5b) = uVar4;
            *(undefined4 *)(arg1 + 0x5f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x9c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 99) = *puVar9;
            *(undefined4 *)(arg1 + 0x67) = uVar3;
            *(undefined4 *)(arg1 + 0x6b) = uVar4;
            *(undefined4 *)(arg1 + 0x6f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x8c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x73) = *puVar9;
            *(undefined4 *)(arg1 + 0x77) = uVar3;
            *(undefined4 *)(arg1 + 0x7b) = uVar4;
            *(undefined4 *)(arg1 + 0x7f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x7c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x83) = *puVar9;
            *(undefined4 *)(arg1 + 0x87) = uVar3;
            *(undefined4 *)(arg1 + 0x8b) = uVar4;
            *(undefined4 *)(arg1 + 0x8f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x6c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0x93) = *puVar9;
            *(undefined4 *)(arg1 + 0x97) = uVar3;
            *(undefined4 *)(arg1 + 0x9b) = uVar4;
            *(undefined4 *)(arg1 + 0x9f) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x5c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0xa3) = *puVar9;
            *(undefined4 *)(arg1 + 0xa7) = uVar3;
            *(undefined4 *)(arg1 + 0xab) = uVar4;
            *(undefined4 *)(arg1 + 0xaf) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x4c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0xb3) = *puVar9;
            *(undefined4 *)(arg1 + 0xb7) = uVar3;
            *(undefined4 *)(arg1 + 0xbb) = uVar4;
            *(undefined4 *)(arg1 + 0xbf) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x3c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0xc3) = *puVar9;
            *(undefined4 *)(arg1 + 199) = uVar3;
            *(undefined4 *)(arg1 + 0xcb) = uVar4;
            *(undefined4 *)(arg1 + 0xcf) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x2c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0xd3) = *puVar9;
            *(undefined4 *)(arg1 + 0xd7) = uVar3;
            *(undefined4 *)(arg1 + 0xdb) = uVar4;
            *(undefined4 *)(arg1 + 0xdf) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x1c + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0xe3) = *puVar9;
            *(undefined4 *)(arg1 + 0xe7) = uVar3;
            *(undefined4 *)(arg1 + 0xeb) = uVar4;
            *(undefined4 *)(arg1 + 0xef) = uVar5;
            puVar9 = (undefined4 *)(arg3 + -0x10 + arg4);
            uVar3 = puVar9[1];
            uVar4 = puVar9[2];
            uVar5 = puVar9[3];
            *(undefined4 *)(arg1 + 0xef) = *puVar9;
            *(undefined4 *)(arg1 + 0xf3) = uVar3;
            *(undefined4 *)(arg1 + 0xf7) = uVar4;
            *(undefined4 *)(arg1 + 0xfb) = uVar5;
            *(undefined *)(arg1 + 0xff) = 0;
            return arg1;
        }
    }
    return arg3 + 1;
}

// ============================================================
// Function: FUN_180099750
// Address: 0x180099750
// Size: 36 bytes
// ============================================================
undefined8 fcn.180099750(int64_t arg1)
{
    undefined4 uVar1;
    
    uVar1 = fcn.18009a210();
    fcn.180086570(arg1, uVar1);
    return 1;
}

// ============================================================
// Function: FUN_180099780
// Address: 0x180099780
// Size: 285 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_356h
// WARNING: [rz-ghidra] Detected overlap for variable var_357h

void fcn.180099780(int64_t arg1, int64_t arg_30h)
{
    char *pcVar1;
    char cVar2;
    code *pcVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    char *pcVar10;
    int64_t *piVar11;
    double dVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_378 [32];
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_128h;
    int64_t var_f8h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_378;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar11 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        pcVar10 = "%c";
    } else {
        piVar6 = piVar9;
        if (piVar11 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x000180099bdd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar6 = piVar9;
            if (piVar11 <= piVar9) {
                piVar6 = *(int64_t **)0x180782430;
            }
        }
        pcVar10 = (char *)(*piVar6 + 0x18);
        if (pcVar10 == (char *)0x0) {
code_r0x000180099bdd:
            func_0x000180088470(arg1, 1, 6);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    piVar6 = piVar9 + 2;
    if (piVar11 <= piVar9 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_350h = func_0x000180467bd4(0);
    } else {
        dVar12 = (double)func_0x000180085ea0(arg1, 2);
        if ((int32_t)var_358h == 0) {
            func_0x000180088470(arg1, 2, 3);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        var_350h = (int64_t)dVar12;
    }
    if (*pcVar10 == '!') {
        iVar5 = func_0x00018046e5a8(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        pcVar10 = pcVar10 + 1;
code_r0x0001800998ff:
        iVar5 = (int32_t)var_358h;
        if (piVar9 != (int64_t *)0x0) {
            if (((*pcVar10 == '*') && (pcVar10[1] == 't')) && (pcVar10[2] == '\0')) {
                func_0x000180086fd0(arg1, 0, 9);
                func_0x0001800865e0(arg1, *(undefined4 *)piVar9);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e500);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 4));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063c814);
                func_0x0001800865e0(arg1, *(undefined4 *)(piVar9 + 1));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f8);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 0xc));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f4);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 2) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4ec);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x14) + 0x76c);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e51c);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 3) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e514);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x1c) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e50c);
                if (-1 < *(int32_t *)(piVar9 + 4)) {
                    func_0x000180086b20(arg1);
                    func_0x000180087370(arg1, 0xfffffffe, 0x18063e504);
                }
            } else {
                cVar2 = *pcVar10;
                var_348h = (int64_t)&var_328h;
                var_358h._0_4_ = CONCAT31(var_358h._1_3_, 0x25);
                uVar4 = (int32_t)var_358h;
                var_340h = (int64_t)&var_128h;
                var_358h._0_2_ = (uint16_t)uVar4;
                var_358h._0_3_ = (unkuint3)(uint16_t)var_358h;
                var_330h = 0;
                var_338h = arg1;
                while (cVar2 != '\0') {
                    if (cVar2 == '%') {
                        if (pcVar10[1] == '\0') goto code_r0x000180099b46;
                        iVar7 = func_0x00018045b928(0x18063e548, (int32_t)pcVar10[1]);
                        if (iVar7 == 0) {
                            func_0x000180088380(arg1, 1, 0x18063e528);
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        var_358h._0_2_ = CONCAT11(pcVar10[1], (undefined)var_358h);
                        uVar8 = func_0x000180461dc0(&var_f8h, 200, &var_358h, piVar9);
                        if ((uint64_t)(var_340h - var_348h) < uVar8) {
                            func_0x0001800890e0(&var_348h, (uVar8 - var_340h) + var_348h, 0xffffffff);
                        }
                        fcn.180498030(var_348h, &var_f8h, uVar8);
                        var_348h = var_348h + uVar8;
                        pcVar10 = pcVar10 + 1;
                    } else {
code_r0x000180099b46:
                        if (((uint64_t)var_340h <= (uint64_t)var_348h) && (var_340h == var_348h)) {
                            func_0x0001800890e0(&var_348h, var_348h + (1 - var_340h), 0xffffffff);
                        }
                        *(char *)var_348h = *pcVar10;
                        var_348h = var_348h + 1;
                    }
                    pcVar1 = pcVar10 + 1;
                    pcVar10 = pcVar10 + 1;
                    cVar2 = *pcVar1;
                }
                func_0x0001800892d0(&var_348h);
            }
            goto code_r0x000180099bae;
        }
    } else if (-1 < var_350h) {
        iVar5 = func_0x000180461990(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        goto code_r0x0001800998ff;
    }
    func_0x000180086510(arg1);
code_r0x000180099bae:
    fcn.180459870(var_28h ^ (uint64_t)auStack_378);
    return;
}

// ============================================================
// Function: FUN_18009989d
// Address: 0x18009989d
// Size: 832 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_356h
// WARNING: [rz-ghidra] Detected overlap for variable var_357h

void fcn.180099780(int64_t arg1, int64_t arg_30h)
{
    char *pcVar1;
    char cVar2;
    code *pcVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    char *pcVar10;
    int64_t *piVar11;
    double dVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_378 [32];
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_128h;
    int64_t var_f8h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_378;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar11 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        pcVar10 = "%c";
    } else {
        piVar6 = piVar9;
        if (piVar11 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x000180099bdd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar6 = piVar9;
            if (piVar11 <= piVar9) {
                piVar6 = *(int64_t **)0x180782430;
            }
        }
        pcVar10 = (char *)(*piVar6 + 0x18);
        if (pcVar10 == (char *)0x0) {
code_r0x000180099bdd:
            func_0x000180088470(arg1, 1, 6);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    piVar6 = piVar9 + 2;
    if (piVar11 <= piVar9 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_350h = func_0x000180467bd4(0);
    } else {
        dVar12 = (double)func_0x000180085ea0(arg1, 2);
        if ((int32_t)var_358h == 0) {
            func_0x000180088470(arg1, 2, 3);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        var_350h = (int64_t)dVar12;
    }
    if (*pcVar10 == '!') {
        iVar5 = func_0x00018046e5a8(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        pcVar10 = pcVar10 + 1;
code_r0x0001800998ff:
        iVar5 = (int32_t)var_358h;
        if (piVar9 != (int64_t *)0x0) {
            if (((*pcVar10 == '*') && (pcVar10[1] == 't')) && (pcVar10[2] == '\0')) {
                func_0x000180086fd0(arg1, 0, 9);
                func_0x0001800865e0(arg1, *(undefined4 *)piVar9);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e500);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 4));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063c814);
                func_0x0001800865e0(arg1, *(undefined4 *)(piVar9 + 1));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f8);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 0xc));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f4);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 2) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4ec);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x14) + 0x76c);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e51c);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 3) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e514);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x1c) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e50c);
                if (-1 < *(int32_t *)(piVar9 + 4)) {
                    func_0x000180086b20(arg1);
                    func_0x000180087370(arg1, 0xfffffffe, 0x18063e504);
                }
            } else {
                cVar2 = *pcVar10;
                var_348h = (int64_t)&var_328h;
                var_358h._0_4_ = CONCAT31(var_358h._1_3_, 0x25);
                uVar4 = (int32_t)var_358h;
                var_340h = (int64_t)&var_128h;
                var_358h._0_2_ = (uint16_t)uVar4;
                var_358h._0_3_ = (unkuint3)(uint16_t)var_358h;
                var_330h = 0;
                var_338h = arg1;
                while (cVar2 != '\0') {
                    if (cVar2 == '%') {
                        if (pcVar10[1] == '\0') goto code_r0x000180099b46;
                        iVar7 = func_0x00018045b928(0x18063e548, (int32_t)pcVar10[1]);
                        if (iVar7 == 0) {
                            func_0x000180088380(arg1, 1, 0x18063e528);
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        var_358h._0_2_ = CONCAT11(pcVar10[1], (undefined)var_358h);
                        uVar8 = func_0x000180461dc0(&var_f8h, 200, &var_358h, piVar9);
                        if ((uint64_t)(var_340h - var_348h) < uVar8) {
                            func_0x0001800890e0(&var_348h, (uVar8 - var_340h) + var_348h, 0xffffffff);
                        }
                        fcn.180498030(var_348h, &var_f8h, uVar8);
                        var_348h = var_348h + uVar8;
                        pcVar10 = pcVar10 + 1;
                    } else {
code_r0x000180099b46:
                        if (((uint64_t)var_340h <= (uint64_t)var_348h) && (var_340h == var_348h)) {
                            func_0x0001800890e0(&var_348h, var_348h + (1 - var_340h), 0xffffffff);
                        }
                        *(char *)var_348h = *pcVar10;
                        var_348h = var_348h + 1;
                    }
                    pcVar1 = pcVar10 + 1;
                    pcVar10 = pcVar10 + 1;
                    cVar2 = *pcVar1;
                }
                func_0x0001800892d0(&var_348h);
            }
            goto code_r0x000180099bae;
        }
    } else if (-1 < var_350h) {
        iVar5 = func_0x000180461990(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        goto code_r0x0001800998ff;
    }
    func_0x000180086510(arg1);
code_r0x000180099bae:
    fcn.180459870(var_28h ^ (uint64_t)auStack_378);
    return;
}

// ============================================================
// Function: FUN_180099bdd
// Address: 0x180099bdd
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_356h
// WARNING: [rz-ghidra] Detected overlap for variable var_357h

void fcn.180099780(int64_t arg1, int64_t arg_30h)
{
    char *pcVar1;
    char cVar2;
    code *pcVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    char *pcVar10;
    int64_t *piVar11;
    double dVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_378 [32];
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_128h;
    int64_t var_f8h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_378;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar11 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        pcVar10 = "%c";
    } else {
        piVar6 = piVar9;
        if (piVar11 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x000180099bdd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar6 = piVar9;
            if (piVar11 <= piVar9) {
                piVar6 = *(int64_t **)0x180782430;
            }
        }
        pcVar10 = (char *)(*piVar6 + 0x18);
        if (pcVar10 == (char *)0x0) {
code_r0x000180099bdd:
            func_0x000180088470(arg1, 1, 6);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    piVar6 = piVar9 + 2;
    if (piVar11 <= piVar9 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_350h = func_0x000180467bd4(0);
    } else {
        dVar12 = (double)func_0x000180085ea0(arg1, 2);
        if ((int32_t)var_358h == 0) {
            func_0x000180088470(arg1, 2, 3);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        var_350h = (int64_t)dVar12;
    }
    if (*pcVar10 == '!') {
        iVar5 = func_0x00018046e5a8(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        pcVar10 = pcVar10 + 1;
code_r0x0001800998ff:
        iVar5 = (int32_t)var_358h;
        if (piVar9 != (int64_t *)0x0) {
            if (((*pcVar10 == '*') && (pcVar10[1] == 't')) && (pcVar10[2] == '\0')) {
                func_0x000180086fd0(arg1, 0, 9);
                func_0x0001800865e0(arg1, *(undefined4 *)piVar9);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e500);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 4));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063c814);
                func_0x0001800865e0(arg1, *(undefined4 *)(piVar9 + 1));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f8);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 0xc));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f4);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 2) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4ec);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x14) + 0x76c);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e51c);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 3) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e514);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x1c) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e50c);
                if (-1 < *(int32_t *)(piVar9 + 4)) {
                    func_0x000180086b20(arg1);
                    func_0x000180087370(arg1, 0xfffffffe, 0x18063e504);
                }
            } else {
                cVar2 = *pcVar10;
                var_348h = (int64_t)&var_328h;
                var_358h._0_4_ = CONCAT31(var_358h._1_3_, 0x25);
                uVar4 = (int32_t)var_358h;
                var_340h = (int64_t)&var_128h;
                var_358h._0_2_ = (uint16_t)uVar4;
                var_358h._0_3_ = (unkuint3)(uint16_t)var_358h;
                var_330h = 0;
                var_338h = arg1;
                while (cVar2 != '\0') {
                    if (cVar2 == '%') {
                        if (pcVar10[1] == '\0') goto code_r0x000180099b46;
                        iVar7 = func_0x00018045b928(0x18063e548, (int32_t)pcVar10[1]);
                        if (iVar7 == 0) {
                            func_0x000180088380(arg1, 1, 0x18063e528);
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        var_358h._0_2_ = CONCAT11(pcVar10[1], (undefined)var_358h);
                        uVar8 = func_0x000180461dc0(&var_f8h, 200, &var_358h, piVar9);
                        if ((uint64_t)(var_340h - var_348h) < uVar8) {
                            func_0x0001800890e0(&var_348h, (uVar8 - var_340h) + var_348h, 0xffffffff);
                        }
                        fcn.180498030(var_348h, &var_f8h, uVar8);
                        var_348h = var_348h + uVar8;
                        pcVar10 = pcVar10 + 1;
                    } else {
code_r0x000180099b46:
                        if (((uint64_t)var_340h <= (uint64_t)var_348h) && (var_340h == var_348h)) {
                            func_0x0001800890e0(&var_348h, var_348h + (1 - var_340h), 0xffffffff);
                        }
                        *(char *)var_348h = *pcVar10;
                        var_348h = var_348h + 1;
                    }
                    pcVar1 = pcVar10 + 1;
                    pcVar10 = pcVar10 + 1;
                    cVar2 = *pcVar1;
                }
                func_0x0001800892d0(&var_348h);
            }
            goto code_r0x000180099bae;
        }
    } else if (-1 < var_350h) {
        iVar5 = func_0x000180461990(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        goto code_r0x0001800998ff;
    }
    func_0x000180086510(arg1);
code_r0x000180099bae:
    fcn.180459870(var_28h ^ (uint64_t)auStack_378);
    return;
}

// ============================================================
// Function: FUN_180099c05
// Address: 0x180099c05
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_356h
// WARNING: [rz-ghidra] Detected overlap for variable var_357h

void fcn.180099780(int64_t arg1, int64_t arg_30h)
{
    char *pcVar1;
    char cVar2;
    code *pcVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t *piVar9;
    char *pcVar10;
    int64_t *piVar11;
    double dVar12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_378 [32];
    int64_t var_358h;
    int64_t var_350h;
    int64_t var_348h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_128h;
    int64_t var_f8h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_378;
    piVar9 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar9;
    if (piVar11 <= piVar9) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        pcVar10 = "%c";
    } else {
        piVar6 = piVar9;
        if (piVar11 <= piVar9) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar5 = func_0x0001800a8360(arg1);
            if (iVar5 == 0) goto code_r0x000180099bdd;
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar9 = *(int64_t **)(arg1 + 0x28);
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar6 = piVar9;
            if (piVar11 <= piVar9) {
                piVar6 = *(int64_t **)0x180782430;
            }
        }
        pcVar10 = (char *)(*piVar6 + 0x18);
        if (pcVar10 == (char *)0x0) {
code_r0x000180099bdd:
            func_0x000180088470(arg1, 1, 6);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
    }
    piVar6 = piVar9 + 2;
    if (piVar11 <= piVar9 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) < 1)) {
        var_350h = func_0x000180467bd4(0);
    } else {
        dVar12 = (double)func_0x000180085ea0(arg1, 2);
        if ((int32_t)var_358h == 0) {
            func_0x000180088470(arg1, 2, 3);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        var_350h = (int64_t)dVar12;
    }
    if (*pcVar10 == '!') {
        iVar5 = func_0x00018046e5a8(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        pcVar10 = pcVar10 + 1;
code_r0x0001800998ff:
        iVar5 = (int32_t)var_358h;
        if (piVar9 != (int64_t *)0x0) {
            if (((*pcVar10 == '*') && (pcVar10[1] == 't')) && (pcVar10[2] == '\0')) {
                func_0x000180086fd0(arg1, 0, 9);
                func_0x0001800865e0(arg1, *(undefined4 *)piVar9);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e500);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 4));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063c814);
                func_0x0001800865e0(arg1, *(undefined4 *)(piVar9 + 1));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f8);
                func_0x0001800865e0(arg1, *(undefined4 *)((int64_t)piVar9 + 0xc));
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4f4);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 2) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e4ec);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x14) + 0x76c);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e51c);
                func_0x0001800865e0(arg1, *(int32_t *)(piVar9 + 3) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e514);
                func_0x0001800865e0(arg1, *(int32_t *)((int64_t)piVar9 + 0x1c) + 1);
                func_0x000180087370(arg1, 0xfffffffe, 0x18063e50c);
                if (-1 < *(int32_t *)(piVar9 + 4)) {
                    func_0x000180086b20(arg1);
                    func_0x000180087370(arg1, 0xfffffffe, 0x18063e504);
                }
            } else {
                cVar2 = *pcVar10;
                var_348h = (int64_t)&var_328h;
                var_358h._0_4_ = CONCAT31(var_358h._1_3_, 0x25);
                uVar4 = (int32_t)var_358h;
                var_340h = (int64_t)&var_128h;
                var_358h._0_2_ = (uint16_t)uVar4;
                var_358h._0_3_ = (unkuint3)(uint16_t)var_358h;
                var_330h = 0;
                var_338h = arg1;
                while (cVar2 != '\0') {
                    if (cVar2 == '%') {
                        if (pcVar10[1] == '\0') goto code_r0x000180099b46;
                        iVar7 = func_0x00018045b928(0x18063e548, (int32_t)pcVar10[1]);
                        if (iVar7 == 0) {
                            func_0x000180088380(arg1, 1, 0x18063e528);
                            pcVar3 = (code *)swi(3);
                            (*pcVar3)();
                            return;
                        }
                        var_358h._0_2_ = CONCAT11(pcVar10[1], (undefined)var_358h);
                        uVar8 = func_0x000180461dc0(&var_f8h, 200, &var_358h, piVar9);
                        if ((uint64_t)(var_340h - var_348h) < uVar8) {
                            func_0x0001800890e0(&var_348h, (uVar8 - var_340h) + var_348h, 0xffffffff);
                        }
                        fcn.180498030(var_348h, &var_f8h, uVar8);
                        var_348h = var_348h + uVar8;
                        pcVar10 = pcVar10 + 1;
                    } else {
code_r0x000180099b46:
                        if (((uint64_t)var_340h <= (uint64_t)var_348h) && (var_340h == var_348h)) {
                            func_0x0001800890e0(&var_348h, var_348h + (1 - var_340h), 0xffffffff);
                        }
                        *(char *)var_348h = *pcVar10;
                        var_348h = var_348h + 1;
                    }
                    pcVar1 = pcVar10 + 1;
                    pcVar10 = pcVar10 + 1;
                    cVar2 = *pcVar1;
                }
                func_0x0001800892d0(&var_348h);
            }
            goto code_r0x000180099bae;
        }
    } else if (-1 < var_350h) {
        iVar5 = func_0x000180461990(&var_128h, &var_350h);
        piVar9 = &var_128h;
        if (iVar5 != 0) {
            piVar9 = (int64_t *)0x0;
        }
        goto code_r0x0001800998ff;
    }
    func_0x000180086510(arg1);
code_r0x000180099bae:
    fcn.180459870(var_28h ^ (uint64_t)auStack_378);
    return;
}

// ============================================================
// Function: FUN_180099c20
// Address: 0x180099c20
// Size: 430 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180099c20(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar9 = *(uint64_t *)(arg1 + 0x28);
    uVar11 = uVar9;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar9) {
        uVar11 = *(uint64_t *)0x180782430;
    }
    if ((uVar11 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar11 + 0xc) < 1)) {
        iVar13 = func_0x000180467bd4(0);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar9) {
            uVar9 = *(uint64_t *)0x180782430;
        }
        if ((uVar9 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar9 + 0xc) != 7)) {
            func_0x000180088470(arg1, 1, 7);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        func_0x0001800858c0(arg1, 1);
        func_0x000180086e00(arg1);
        iVar13 = -1;
        iVar2 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar2 == 0) {
            iVar2 = 0;
        } else {
            iVar2 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar3 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar3 == 0) {
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar4 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar4 == 0) {
            iVar4 = 0xc;
        } else {
            iVar4 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar5 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar5 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e4f4);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar5 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar6 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar6 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e4ec);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar6 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar7 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar7 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e51c);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar6 = iVar6 + -1;
        iVar7 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar8 = (uint32_t)(iVar6 % 0xc < 2) - iVar6 / 0xc;
        iVar7 = (iVar7 - iVar8) + 0x12c0;
        iVar5 = ((iVar7 / 400 + ((iVar6 + iVar8 * 0xc) * 0x99 + -0x130) / 5 + iVar7 * 0x16d) - iVar7 / 100) + -0x7d2d +
                iVar5 + ((int32_t)(iVar7 + (iVar7 >> 0x1f & 3U)) >> 2);
        if ((0x253d8b < iVar5) &&
           (iVar12 = (((int64_t)iVar4 + (int64_t)iVar5 * 0x18) * 0x3c + (int64_t)iVar3) * 0x3c + (int64_t)iVar2,
           0x3118a411ff < iVar12)) {
            iVar13 = iVar12 + -0x3118a41200;
        }
    }
    if (iVar13 == -1) {
        func_0x000180086510();
    } else {
        fcn.180086570(arg1, (double)iVar13);
    }
    return 1;
}

// ============================================================
// Function: FUN_180099dce
// Address: 0x180099dce
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180099c20(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar9 = *(uint64_t *)(arg1 + 0x28);
    uVar11 = uVar9;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar9) {
        uVar11 = *(uint64_t *)0x180782430;
    }
    if ((uVar11 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar11 + 0xc) < 1)) {
        iVar13 = func_0x000180467bd4(0);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar9) {
            uVar9 = *(uint64_t *)0x180782430;
        }
        if ((uVar9 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar9 + 0xc) != 7)) {
            func_0x000180088470(arg1, 1, 7);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        func_0x0001800858c0(arg1, 1);
        func_0x000180086e00(arg1);
        iVar13 = -1;
        iVar2 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar2 == 0) {
            iVar2 = 0;
        } else {
            iVar2 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar3 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar3 == 0) {
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar4 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar4 == 0) {
            iVar4 = 0xc;
        } else {
            iVar4 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar5 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar5 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e4f4);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar5 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar6 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar6 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e4ec);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar6 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar7 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar7 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e51c);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar6 = iVar6 + -1;
        iVar7 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar8 = (uint32_t)(iVar6 % 0xc < 2) - iVar6 / 0xc;
        iVar7 = (iVar7 - iVar8) + 0x12c0;
        iVar5 = ((iVar7 / 400 + ((iVar6 + iVar8 * 0xc) * 0x99 + -0x130) / 5 + iVar7 * 0x16d) - iVar7 / 100) + -0x7d2d +
                iVar5 + ((int32_t)(iVar7 + (iVar7 >> 0x1f & 3U)) >> 2);
        if ((0x253d8b < iVar5) &&
           (iVar12 = (((int64_t)iVar4 + (int64_t)iVar5 * 0x18) * 0x3c + (int64_t)iVar3) * 0x3c + (int64_t)iVar2,
           0x3118a411ff < iVar12)) {
            iVar13 = iVar12 + -0x3118a41200;
        }
    }
    if (iVar13 == -1) {
        func_0x000180086510();
    } else {
        fcn.180086570(arg1, (double)iVar13);
    }
    return 1;
}

// ============================================================
// Function: FUN_180099e9e
// Address: 0x180099e9e
// Size: 212 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180099c20(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar9 = *(uint64_t *)(arg1 + 0x28);
    uVar11 = uVar9;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar9) {
        uVar11 = *(uint64_t *)0x180782430;
    }
    if ((uVar11 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar11 + 0xc) < 1)) {
        iVar13 = func_0x000180467bd4(0);
    } else {
        if (*(uint64_t *)(arg1 + 0x40) <= uVar9) {
            uVar9 = *(uint64_t *)0x180782430;
        }
        if ((uVar9 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar9 + 0xc) != 7)) {
            func_0x000180088470(arg1, 1, 7);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        func_0x0001800858c0(arg1, 1);
        func_0x000180086e00(arg1);
        iVar13 = -1;
        iVar2 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar2 == 0) {
            iVar2 = 0;
        } else {
            iVar2 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar3 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar3 == 0) {
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar4 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar4 == 0) {
            iVar4 = 0xc;
        } else {
            iVar4 = func_0x000180085f50(arg1, 0xffffffff, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar5 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar5 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e4f4);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar5 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar6 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar6 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e4ec);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar6 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        iVar7 = func_0x000180085d50(arg1, 0xffffffff);
        if (iVar7 == 0) {
            func_0x000180088560(arg1, 0x18063e4c8, 0x18063e51c);
            pcVar1 = (code *)swi(3);
            uVar10 = (*pcVar1)();
            return uVar10;
        }
        iVar6 = iVar6 + -1;
        iVar7 = func_0x000180085f50(arg1, 0xffffffff, 0);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        func_0x000180086e00(arg1);
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        iVar8 = (uint32_t)(iVar6 % 0xc < 2) - iVar6 / 0xc;
        iVar7 = (iVar7 - iVar8) + 0x12c0;
        iVar5 = ((iVar7 / 400 + ((iVar6 + iVar8 * 0xc) * 0x99 + -0x130) / 5 + iVar7 * 0x16d) - iVar7 / 100) + -0x7d2d +
                iVar5 + ((int32_t)(iVar7 + (iVar7 >> 0x1f & 3U)) >> 2);
        if ((0x253d8b < iVar5) &&
           (iVar12 = (((int64_t)iVar4 + (int64_t)iVar5 * 0x18) * 0x3c + (int64_t)iVar3) * 0x3c + (int64_t)iVar2,
           0x3118a411ff < iVar12)) {
            iVar13 = iVar12 + -0x3118a41200;
        }
    }
    if (iVar13 == -1) {
        func_0x000180086510();
    } else {
        fcn.180086570(arg1, (double)iVar13);
    }
    return 1;
}

// ============================================================
// Function: FUN_180099f80
// Address: 0x180099f80
// Size: 189 bytes
// ============================================================
undefined8 fcn.180099f80(int64_t arg1)
{
    code *pcVar1;
    double dVar2;
    undefined8 uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    double dVar6;
    int64_t var_8h;
    int64_t var_18h;
    
    uVar4 = *(int64_t *)(arg1 + 0x28) + 0x10;
    if (*(uint64_t *)(arg1 + 0x40) <= uVar4) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) < 1)) {
        dVar6 = 0.0;
    } else {
        dVar6 = (double)func_0x000180085ea0(arg1, 2, &var_8h);
        if ((int32_t)var_8h == 0) {
            func_0x000180088470(arg1, 2, 3);
            pcVar1 = (code *)swi(3);
            uVar3 = (*pcVar1)();
            return uVar3;
        }
    }
    dVar2 = (double)func_0x000180085ea0(arg1, 1, &var_8h);
    if ((int32_t)var_8h == 0) {
        func_0x000180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    uVar5 = func_0x00018046e200((int64_t)dVar2, (int64_t)dVar6);
    fcn.180086570(arg1, uVar5);
    return 1;
}

// ============================================================
// Function: FUN_18009a040
// Address: 0x18009a040
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

undefined8 fcn.18009a040(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    undefined4 *puVar7;
    undefined8 *puVar8;
    uint32_t uVar9;
    int64_t unaff_RDI;
    int64_t arg3;
    uint64_t arg4;
    int64_t var_38h;
    
    puVar8 = (undefined8 *)0x180612a10;
    uVar9 = 0;
    piVar3 = (int64_t *)0x180612a10;
    do {
        uVar9 = uVar9 + 1;
        piVar3 = piVar3 + 2;
    } while (*piVar3 != 0);
    func_0x000180088ce0(arg1, 0xffffd8f0, 0x18063da18, 1);
    func_0x000180086cc0(arg1, 0xffffffff, 0x180625f24);
    iVar4 = *(int64_t *)(arg1 + 0x40) + -0x10;
    if ((iVar4 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 7)) {
        arg4 = (uint64_t)uVar9;
        *(int64_t *)(arg1 + 0x40) = iVar4;
        arg3 = 0x180625f24;
        iVar4 = func_0x000180088ce0(arg1, 0xffffd8ee);
        if (iVar4 != 0) {
            func_0x000180088560(arg1, 0x18063da68, 0x180625f24);
            pcVar1 = (code *)swi(3);
            uVar6 = (*pcVar1)();
            return uVar6;
        }
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar2 = fcn.180085510(unaff_RDI), iVar2 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0, arg3, arg4);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            uVar6 = (*pcVar1)();
            return uVar6;
        }
        puVar5 = *(undefined4 **)(arg1 + 0x40);
        *puVar5 = puVar5[-4];
        puVar5[1] = puVar5[-3];
        puVar5[2] = puVar5[-2];
        puVar5[3] = puVar5[-1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        func_0x000180087370(arg1, 0xfffffffd, 0x180625f24);
    }
    puVar7 = *(undefined4 **)(arg1 + 0x40);
    puVar5 = puVar7 + -4;
    if (puVar5 < puVar7) {
        do {
            puVar5[-4] = *puVar5;
            puVar5[-3] = puVar5[1];
            puVar5[-2] = puVar5[2];
            puVar5[-1] = puVar5[3];
            puVar7 = *(undefined4 **)(arg1 + 0x40);
            puVar5 = puVar5 + 4;
        } while (puVar5 < puVar7);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar7 + -4;
    iVar4 = 0x18063c29c;
    do {
        func_0x0001800869f0(arg1, puVar8[1], iVar4, 0, 0);
        func_0x000180087370(arg1, 0xfffffffe, *puVar8);
        iVar4 = puVar8[2];
        puVar8 = puVar8 + 2;
    } while (iVar4 != 0);
    return 1;
}

// ============================================================
// Function: FUN_18009a210
// Address: 0x18009a210
// Size: 167 bytes
// ============================================================
double fcn.18009a210(void)
{
    int64_t unaff_GS_OFFSET;
    int64_t var_8h;
    
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x180782a18) {
        fcn.180459d18(0x180782a18);
        if (*(int32_t *)0x180782a18 == -1) {
            var_8h = 0;
            (*(code *)0x699e5a)(&var_8h);
            *(double *)0x180782a10 = 1.0 / (double)var_8h;
            fcn.180459cac(0x180782a18);
        }
    }
    var_8h = 0;
    (*(code *)0x699e76)(&var_8h);
    return (double)var_8h * *(double *)0x180782a10;
}

// ============================================================
// Function: FUN_18009a2c0
// Address: 0x18009a2c0
// Size: 479 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18009a2c0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    iVar2 = fcn.180098670(arg2, 0x140, *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x78) = iVar2;
    *(int64_t *)(arg1 + 0x18) = iVar2;
    *(int64_t *)(arg1 + 0x70) = iVar2 + 0x118;
    *(undefined4 *)(arg1 + 100) = 8;
    iVar2 = fcn.180098670(arg2, 0x2d0, *(undefined *)arg1);
    *(int64_t *)(arg1 + 0x38) = iVar2;
    piVar1 = (int32_t *)(arg1 + 0x60);
    *piVar1 = (int32_t)piVar1 + 0x2d;
    *(undefined4 *)(iVar2 + 0xc) = 0;
    *(undefined4 *)(iVar2 + 0x1c) = 0;
    *(undefined4 *)(iVar2 + 0x2c) = 0;
    *(undefined4 *)(iVar2 + 0x3c) = 0;
    *(undefined4 *)(iVar2 + 0x4c) = 0;
    *(undefined4 *)(iVar2 + 0x5c) = 0;
    *(undefined4 *)(iVar2 + 0x6c) = 0;
    *(undefined4 *)(iVar2 + 0x7c) = 0;
    *(undefined4 *)(iVar2 + 0x8c) = 0;
    *(undefined4 *)(iVar2 + 0x9c) = 0;
    *(undefined4 *)(iVar2 + 0xac) = 0;
    *(undefined4 *)(iVar2 + 0xbc) = 0;
    *(undefined4 *)(iVar2 + 0xcc) = 0;
    *(undefined4 *)(iVar2 + 0xdc) = 0;
    *(undefined4 *)(iVar2 + 0xec) = 0;
    *(undefined4 *)(iVar2 + 0xfc) = 0;
    *(undefined4 *)(iVar2 + 0x10c) = 0;
    *(undefined4 *)(iVar2 + 0x11c) = 0;
    *(undefined4 *)(iVar2 + 300) = 0;
    *(undefined4 *)(iVar2 + 0x13c) = 0;
    *(undefined4 *)(iVar2 + 0x14c) = 0;
    *(undefined4 *)(iVar2 + 0x15c) = 0;
    *(undefined4 *)(iVar2 + 0x16c) = 0;
    *(undefined4 *)(iVar2 + 0x17c) = 0;
    *(undefined4 *)(iVar2 + 0x18c) = 0;
    *(undefined4 *)(iVar2 + 0x19c) = 0;
    *(undefined4 *)(iVar2 + 0x1ac) = 0;
    *(undefined4 *)(iVar2 + 0x1bc) = 0;
    *(undefined4 *)(iVar2 + 0x1cc) = 0;
    *(undefined4 *)(iVar2 + 0x1dc) = 0;
    *(undefined4 *)(iVar2 + 0x1ec) = 0;
    *(undefined4 *)(iVar2 + 0x1fc) = 0;
    *(undefined4 *)(iVar2 + 0x20c) = 0;
    *(undefined4 *)(iVar2 + 0x21c) = 0;
    *(undefined4 *)(iVar2 + 0x22c) = 0;
    *(undefined4 *)(iVar2 + 0x23c) = 0;
    *(undefined4 *)(iVar2 + 0x24c) = 0;
    *(undefined4 *)(iVar2 + 0x25c) = 0;
    *(undefined4 *)(iVar2 + 0x26c) = 0;
    *(undefined4 *)(iVar2 + 0x27c) = 0;
    *(undefined4 *)(iVar2 + 0x28c) = 0;
    *(undefined4 *)(iVar2 + 0x29c) = 0;
    *(undefined4 *)(iVar2 + 0x2ac) = 0;
    *(undefined4 *)(iVar2 + 700) = 0;
    *(undefined4 *)(iVar2 + 0x2cc) = 0;
    *(int64_t *)(arg1 + 0x40) = iVar2;
    *(int64_t *)(arg1 + 0x30) = (int64_t)((*piVar1 - (int32_t)piVar1) + -5) * 0x10 + iVar2;
    *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 8) = iVar2;
    *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    *(undefined8 *)(*(int64_t *)(arg1 + 0x18) + 0x10) = *(undefined8 *)(arg1 + 0x40);
    *(int64_t *)(arg1 + 0x28) = (*(int64_t **)(arg1 + 0x18))[2];
    **(int64_t **)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x40) + 0x140;
    return;
}

// ============================================================
// Function: FUN_18009a4a0
// Address: 0x18009a4a0
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18009a4a0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    func_0x000180094340(arg1, *(undefined8 *)(arg1 + 0x38));
    if ((*(char *)0x180777df8 != '\0') && (iVar5 = *(int64_t *)(arg1 + 0x18), iVar5 != *(int64_t *)(arg1 + 0x78))) {
        do {
            ppiVar1 = (int64_t **)(iVar5 + 8);
            iVar5 = iVar5 + -0x28;
            piVar2 = (int64_t *)(**ppiVar1 + 8);
            *piVar2 = *piVar2 + -1;
        } while (iVar5 != *(int64_t *)(arg1 + 0x78));
    }
    iVar5 = *(int64_t *)(arg1 + 0x38);
    piVar2 = *(int64_t **)(arg1 + 0x78);
    piVar2[2] = iVar5 + 0x10;
    *piVar2 = iVar5 + 0x150;
    piVar2[1] = iVar5;
    *(undefined4 *)(iVar5 + 0xc) = 0;
    *(int64_t **)(arg1 + 0x18) = piVar2;
    if (*(int32_t *)(arg1 + 100) != 8) {
        func_0x0001800933e0(arg1, 8);
    }
    piVar3 = (int32_t *)(arg1 + 0x60);
    *(undefined *)(arg1 + 3) = 0;
    *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(*(int64_t *)(arg1 + 0x18) + 0x10);
    *(undefined8 *)(arg1 + 0x40) = *(undefined8 *)(*(int64_t *)(arg1 + 0x18) + 0x10);
    *(undefined4 *)(arg1 + 0x68) = 0;
    iVar6 = (int32_t)piVar3;
    if (*piVar3 - iVar6 != 0x2d) {
        func_0x000180093240(arg1, 0x28, 0);
    }
    iVar4 = 0;
    if (0 < *piVar3 - iVar6) {
        do {
            iVar5 = (int64_t)iVar4;
            iVar4 = iVar4 + 1;
            *(undefined4 *)(*(int64_t *)(arg1 + 0x38) + 0xc + iVar5 * 0x10) = 0;
        } while (iVar4 < *piVar3 - iVar6);
    }
    return;
}

// ============================================================
// Function: FUN_18009a5a0
// Address: 0x18009a5a0
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.18009a5a0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int64_t var_8h;
    
    uVar6 = 0;
    uVar5 = 0;
    uVar4 = arg2 & 0xffffffff;
    if (0x1f < (uint64_t)arg2) {
        do {
            uVar3 = (int32_t)uVar4 + *(int32_t *)(arg1 + 8);
            arg2 = arg2 - 0xc;
            iVar2 = *(int32_t *)arg1;
            piVar1 = (int32_t *)(arg1 + 4);
            arg1 = arg1 + 0xc;
            uVar6 = (uVar6 + iVar2 ^ uVar3) - (uVar3 >> 0xe | uVar3 * 0x40000);
            uVar5 = (uVar5 + *piVar1 ^ uVar6) - (uVar6 >> 0xb | uVar6 * 0x200000);
            uVar4 = (uint64_t)((uVar3 ^ uVar5) - (uVar5 >> 0x19 | uVar5 * 0x80));
        } while (0x1f < (uint64_t)arg2);
    }
    for (; arg2 != 0; arg2 = arg2 - 1) {
        uVar4 = (uint64_t)
                ((uint32_t)uVar4 ^
                (uint32_t)*(uint8_t *)(arg1 + (arg2 - 1U)) + (uint32_t)uVar4 * 0x20 + (int32_t)(uVar4 >> 2));
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18009a630
// Address: 0x18009a630
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18009a630(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    uVar10 = (uint64_t)iVar8;
    if (0x1fffffffffffffff < uVar10) {
        fcn.180098420();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar5 = fcn.180098670(arg1, uVar10 * 8, 0);
    piVar1 = *(int64_t **)(arg1 + 0x20);
    if (0 < iVar8) {
        func_0x0001804986e0(iVar5, 0, uVar10 * 8);
    }
    iVar4 = *(int32_t *)((int64_t)piVar1 + 0xc);
    iVar11 = 0;
    if (0 < iVar4) {
        do {
            iVar6 = *(int64_t *)(*piVar1 + (int64_t)iVar11 * 8);
            if (iVar6 != 0) {
                do {
                    iVar2 = *(int64_t *)(iVar6 + 8);
                    uVar9 = (int64_t)(*(int32_t *)(iVar6 + 0x10) + (int32_t)iVar6) + 0x10U & uVar10 - 1;
                    *(undefined8 *)(iVar6 + 8) = *(undefined8 *)(iVar5 + uVar9 * 8);
                    *(int64_t *)(iVar5 + uVar9 * 8) = iVar6;
                    *(undefined2 *)(iVar6 + 4) = 0xffff;
                    iVar6 = iVar2;
                } while (iVar2 != 0);
            }
            iVar4 = *(int32_t *)((int64_t)piVar1 + 0xc);
            iVar11 = iVar11 + 1;
        } while (iVar11 < iVar4);
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar7 = (int64_t)iVar4;
    iVar6 = iVar7 * 8;
    if ((iVar6 - 1U < 0x400) && (-1 < *(char *)(iVar6 + 0x180777990))) {
        func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar6 + 0x180777990), *piVar1);
    } else {
        (**(code **)(iVar2 + 0x48))(*(undefined8 *)(iVar2 + 0x50), *piVar1, iVar6, 0);
    }
    *(int64_t *)(iVar2 + 0x30) = *(int64_t *)(iVar2 + 0x30) + iVar7 * -8;
    *(int64_t *)(iVar2 + 0x2c30) = *(int64_t *)(iVar2 + 0x2c30) + iVar7 * -8;
    *piVar1 = iVar5;
    *(int32_t *)((int64_t)piVar1 + 0xc) = iVar8;
    return;
}

// ============================================================
// Function: FUN_18009a652
// Address: 0x18009a652
// Size: 280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18009a630(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    uVar10 = (uint64_t)iVar8;
    if (0x1fffffffffffffff < uVar10) {
        fcn.180098420();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar5 = fcn.180098670(arg1, uVar10 * 8, 0);
    piVar1 = *(int64_t **)(arg1 + 0x20);
    if (0 < iVar8) {
        func_0x0001804986e0(iVar5, 0, uVar10 * 8);
    }
    iVar4 = *(int32_t *)((int64_t)piVar1 + 0xc);
    iVar11 = 0;
    if (0 < iVar4) {
        do {
            iVar6 = *(int64_t *)(*piVar1 + (int64_t)iVar11 * 8);
            if (iVar6 != 0) {
                do {
                    iVar2 = *(int64_t *)(iVar6 + 8);
                    uVar9 = (int64_t)(*(int32_t *)(iVar6 + 0x10) + (int32_t)iVar6) + 0x10U & uVar10 - 1;
                    *(undefined8 *)(iVar6 + 8) = *(undefined8 *)(iVar5 + uVar9 * 8);
                    *(int64_t *)(iVar5 + uVar9 * 8) = iVar6;
                    *(undefined2 *)(iVar6 + 4) = 0xffff;
                    iVar6 = iVar2;
                } while (iVar2 != 0);
            }
            iVar4 = *(int32_t *)((int64_t)piVar1 + 0xc);
            iVar11 = iVar11 + 1;
        } while (iVar11 < iVar4);
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar7 = (int64_t)iVar4;
    iVar6 = iVar7 * 8;
    if ((iVar6 - 1U < 0x400) && (-1 < *(char *)(iVar6 + 0x180777990))) {
        func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar6 + 0x180777990), *piVar1);
    } else {
        (**(code **)(iVar2 + 0x48))(*(undefined8 *)(iVar2 + 0x50), *piVar1, iVar6, 0);
    }
    *(int64_t *)(iVar2 + 0x30) = *(int64_t *)(iVar2 + 0x30) + iVar7 * -8;
    *(int64_t *)(iVar2 + 0x2c30) = *(int64_t *)(iVar2 + 0x2c30) + iVar7 * -8;
    *piVar1 = iVar5;
    *(int32_t *)((int64_t)piVar1 + 0xc) = iVar8;
    return;
}

// ============================================================
// Function: FUN_18009a76a
// Address: 0x18009a76a
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.18009a630(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    uVar10 = (uint64_t)iVar8;
    if (0x1fffffffffffffff < uVar10) {
        fcn.180098420();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar5 = fcn.180098670(arg1, uVar10 * 8, 0);
    piVar1 = *(int64_t **)(arg1 + 0x20);
    if (0 < iVar8) {
        func_0x0001804986e0(iVar5, 0, uVar10 * 8);
    }
    iVar4 = *(int32_t *)((int64_t)piVar1 + 0xc);
    iVar11 = 0;
    if (0 < iVar4) {
        do {
            iVar6 = *(int64_t *)(*piVar1 + (int64_t)iVar11 * 8);
            if (iVar6 != 0) {
                do {
                    iVar2 = *(int64_t *)(iVar6 + 8);
                    uVar9 = (int64_t)(*(int32_t *)(iVar6 + 0x10) + (int32_t)iVar6) + 0x10U & uVar10 - 1;
                    *(undefined8 *)(iVar6 + 8) = *(undefined8 *)(iVar5 + uVar9 * 8);
                    *(int64_t *)(iVar5 + uVar9 * 8) = iVar6;
                    *(undefined2 *)(iVar6 + 4) = 0xffff;
                    iVar6 = iVar2;
                } while (iVar2 != 0);
            }
            iVar4 = *(int32_t *)((int64_t)piVar1 + 0xc);
            iVar11 = iVar11 + 1;
        } while (iVar11 < iVar4);
    }
    iVar2 = *(int64_t *)(arg1 + 0x20);
    iVar7 = (int64_t)iVar4;
    iVar6 = iVar7 * 8;
    if ((iVar6 - 1U < 0x400) && (-1 < *(char *)(iVar6 + 0x180777990))) {
        func_0x0001800985c0(arg1, (int32_t)*(char *)(iVar6 + 0x180777990), *piVar1);
    } else {
        (**(code **)(iVar2 + 0x48))(*(undefined8 *)(iVar2 + 0x50), *piVar1, iVar6, 0);
    }
    *(int64_t *)(iVar2 + 0x30) = *(int64_t *)(iVar2 + 0x30) + iVar7 * -8;
    *(int64_t *)(iVar2 + 0x2c30) = *(int64_t *)(iVar2 + 0x2c30) + iVar7 * -8;
    *piVar1 = iVar5;
    *(int32_t *)((int64_t)piVar1 + 0xc) = iVar8;
    return;
}

// ============================================================
// Function: FUN_18009a770
// Address: 0x18009a770
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18009a770(int64_t arg1, int64_t arg2)
{
    uint8_t uVar1;
    code *pcVar2;
    undefined *puVar3;
    int64_t var_8h;
    
    if ((uint64_t)arg2 < 0x40000001) {
        puVar3 = (undefined *)fcn.180098710(arg1, arg2 + 0x19, *(undefined *)(arg1 + 4));
        uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
        puVar3[2] = 6;
        puVar3[1] = uVar1 & 3;
        *puVar3 = *(undefined *)(arg1 + 4);
        *(undefined4 *)(puVar3 + 4) = 0x8000ffff;
        *(int32_t *)(puVar3 + 0x10) = -((int32_t)puVar3 + 0x10);
        *(int32_t *)(puVar3 + 0x14) = (int32_t)arg2;
        *(undefined8 *)(puVar3 + 8) = 0;
        return;
    }
    fcn.180098420();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18009a7e0
// Address: 0x18009a7e0
// Size: 248 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

int64_t fcn.18009a7e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    uint64_t arg2_00;
    
    uVar2 = *(uint32_t *)(arg2 + 0x14);
    arg2_00 = (uint64_t)uVar2;
    uVar5 = fcn.18009a5a0(arg2 + 0x18, arg2_00);
    piVar3 = *(int64_t **)(arg1 + 0x20);
    iVar1 = (int64_t)(int32_t)(*(int32_t *)((int64_t)piVar3 + 0xc) - 1U & uVar5) * 8;
    iVar4 = *(int64_t *)(iVar1 + *piVar3);
    while( true ) {
        if (iVar4 == 0) {
            *(int32_t *)(arg2 + 0x10) = uVar5 - (int32_t)(int32_t *)(arg2 + 0x10);
            *(undefined *)(arg2_00 + 0x18 + arg2) = 0;
            *(undefined2 *)(arg2 + 6) = 0x8000;
            *(undefined8 *)(arg2 + 8) = *(undefined8 *)(iVar1 + *piVar3);
            *(int64_t *)(iVar1 + *piVar3) = arg2;
            *(int32_t *)(piVar3 + 1) = *(int32_t *)(piVar3 + 1) + 1;
            uVar2 = *(uint32_t *)((int64_t)piVar3 + 0xc);
            if ((uVar2 < *(uint32_t *)(piVar3 + 1)) && ((int32_t)uVar2 < 0x40000000)) {
                fcn.18009a630(arg1, (uint64_t)(uVar2 * 2));
            }
            *(undefined2 *)(arg2 + 4) = 0xffff;
            return arg2;
        }
        if ((*(uint32_t *)(iVar4 + 0x14) == uVar2) &&
           (iVar6 = fcn.180497f30(iVar4 + 0x18, arg2 + 0x18, arg2_00), iVar6 == 0)) break;
        iVar4 = *(int64_t *)(iVar4 + 8);
    }
    if (((~*(uint8_t *)(piVar3 + 0xb) & 3 ^ *(uint8_t *)(iVar4 + 1)) & 0xb) == 0) {
        *(uint8_t *)(iVar4 + 1) = *(uint8_t *)(iVar4 + 1) ^ 3;
    }
    *(undefined2 *)(iVar4 + 4) = 0xffff;
    return iVar4;
}

// ============================================================
// Function: FUN_18009a8e0
// Address: 0x18009a8e0
// Size: 345 bytes
// ============================================================
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined * fcn.18009a8e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    uint8_t uVar2;
    int64_t *piVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    undefined *puVar7;
    int64_t var_4h;
    int64_t var_20h;
    
    uVar5 = fcn.18009a5a0(arg2, arg3);
    piVar3 = *(int64_t **)(arg1 + 0x20);
    puVar7 = *(undefined **)(*piVar3 + (int64_t)(int32_t)(*(int32_t *)((int64_t)piVar3 + 0xc) - 1U & uVar5) * 8);
    while( true ) {
        if (puVar7 == (undefined *)0x0) {
            if (0x40000000 < (uint64_t)arg3) {
                fcn.180098420(arg1);
                pcVar4 = (code *)swi(3);
                puVar7 = (undefined *)(*pcVar4)();
                return puVar7;
            }
            puVar7 = (undefined *)fcn.180098710(arg1, arg3 + 0x19, *(undefined *)(arg1 + 4));
            uVar2 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
            puVar7[2] = 6;
            puVar7[1] = uVar2 & 3;
            *puVar7 = *(undefined *)(arg1 + 4);
            *(undefined4 *)(puVar7 + 4) = 0x8000ffff;
            *(uint32_t *)(puVar7 + 0x10) = uVar5 - (int32_t)(puVar7 + 0x10);
            *(int32_t *)(puVar7 + 0x14) = (int32_t)arg3;
            fcn.180498030(puVar7 + 0x18, arg2, arg3);
            puVar7[arg3 + 0x18] = 0;
            piVar3 = *(int64_t **)(arg1 + 0x20);
            iVar1 = (uint64_t)(*(int32_t *)((int64_t)piVar3 + 0xc) - 1U & uVar5) * 8;
            *(undefined8 *)(puVar7 + 8) = *(undefined8 *)(iVar1 + *piVar3);
            *(undefined **)(iVar1 + *piVar3) = puVar7;
            *(int32_t *)(piVar3 + 1) = *(int32_t *)(piVar3 + 1) + 1;
            uVar5 = *(uint32_t *)((int64_t)piVar3 + 0xc);
            if ((uVar5 < *(uint32_t *)(piVar3 + 1)) && ((int32_t)uVar5 < 0x40000000)) {
                fcn.18009a630(arg1, (uint64_t)(uVar5 * 2));
            }
            return puVar7;
        }
        if (((uint64_t)*(uint32_t *)(puVar7 + 0x14) == arg3) &&
           (iVar6 = fcn.180497f30(arg2, puVar7 + 0x18, arg3), iVar6 == 0)) break;
        puVar7 = *(undefined **)(puVar7 + 8);
    }
    if (((~*(uint8_t *)(piVar3 + 0xb) & 3 ^ puVar7[1]) & 0xb) == 0) {
        puVar7[1] = puVar7[1] ^ 3;
    }
    *(undefined2 *)(puVar7 + 4) = 0xffff;
    return puVar7;
}

// ============================================================
// Function: FUN_18009aa40
// Address: 0x18009aa40
// Size: 167 bytes
// ============================================================
undefined8 fcn.18009aa40(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009aad3;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar4 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar4 != -0x18) {
        func_0x0001800865e0(arg1, *(undefined4 *)(*piVar4 + 0x14));
        return 1;
    }
code_r0x00018009aad3:
    func_0x000180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_18009aaf0
// Address: 0x18009aaf0
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18009aaf0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009ac41;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar7 + 0x18;
    if (iVar8 == 0) {
code_r0x00018009ac41:
        func_0x000180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar2 = *(int32_t *)(*piVar7 + 0x14);
    uVar3 = func_0x000180088860(arg1, 2);
    if ((int32_t)uVar3 < 0) {
        uVar3 = uVar3 + 1 + iVar2;
    }
    uVar9 = 0;
    if (-1 < (int32_t)uVar3) {
        uVar9 = uVar3;
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = -1;
    } else {
        iVar4 = func_0x000180088860(arg1, 3);
        if (-1 < iVar4) goto code_r0x00018009abe7;
    }
    iVar4 = iVar4 + 1 + iVar2;
code_r0x00018009abe7:
    iVar6 = 0;
    if (-1 < iVar4) {
        iVar6 = iVar4;
    }
    if ((int32_t)uVar9 < 1) {
        uVar9 = 1;
    }
    if (iVar2 < iVar6) {
        iVar6 = iVar2;
    }
    if (iVar6 < (int32_t)uVar9) {
        iVar8 = 0x1805aadb1;
        iVar10 = 0;
    } else {
        iVar8 = ((uint64_t)uVar9 - 1) + iVar8;
        iVar10 = (int64_t)(int32_t)((iVar6 - uVar9) + 1);
    }
    func_0x0001800867f0(arg1, iVar8, iVar10);
    return 1;
}

// ============================================================
// Function: FUN_18009ab7f
// Address: 0x18009ab7f
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18009aaf0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009ac41;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar7 + 0x18;
    if (iVar8 == 0) {
code_r0x00018009ac41:
        func_0x000180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar2 = *(int32_t *)(*piVar7 + 0x14);
    uVar3 = func_0x000180088860(arg1, 2);
    if ((int32_t)uVar3 < 0) {
        uVar3 = uVar3 + 1 + iVar2;
    }
    uVar9 = 0;
    if (-1 < (int32_t)uVar3) {
        uVar9 = uVar3;
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = -1;
    } else {
        iVar4 = func_0x000180088860(arg1, 3);
        if (-1 < iVar4) goto code_r0x00018009abe7;
    }
    iVar4 = iVar4 + 1 + iVar2;
code_r0x00018009abe7:
    iVar6 = 0;
    if (-1 < iVar4) {
        iVar6 = iVar4;
    }
    if ((int32_t)uVar9 < 1) {
        uVar9 = 1;
    }
    if (iVar2 < iVar6) {
        iVar6 = iVar2;
    }
    if (iVar6 < (int32_t)uVar9) {
        iVar8 = 0x1805aadb1;
        iVar10 = 0;
    } else {
        iVar8 = ((uint64_t)uVar9 - 1) + iVar8;
        iVar10 = (int64_t)(int32_t)((iVar6 - uVar9) + 1);
    }
    func_0x0001800867f0(arg1, iVar8, iVar10);
    return 1;
}

// ============================================================
// Function: FUN_18009ac06
// Address: 0x18009ac06
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18009aaf0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009ac41;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar7 + 0x18;
    if (iVar8 == 0) {
code_r0x00018009ac41:
        func_0x000180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar2 = *(int32_t *)(*piVar7 + 0x14);
    uVar3 = func_0x000180088860(arg1, 2);
    if ((int32_t)uVar3 < 0) {
        uVar3 = uVar3 + 1 + iVar2;
    }
    uVar9 = 0;
    if (-1 < (int32_t)uVar3) {
        uVar9 = uVar3;
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = -1;
    } else {
        iVar4 = func_0x000180088860(arg1, 3);
        if (-1 < iVar4) goto code_r0x00018009abe7;
    }
    iVar4 = iVar4 + 1 + iVar2;
code_r0x00018009abe7:
    iVar6 = 0;
    if (-1 < iVar4) {
        iVar6 = iVar4;
    }
    if ((int32_t)uVar9 < 1) {
        uVar9 = 1;
    }
    if (iVar2 < iVar6) {
        iVar6 = iVar2;
    }
    if (iVar6 < (int32_t)uVar9) {
        iVar8 = 0x1805aadb1;
        iVar10 = 0;
    } else {
        iVar8 = ((uint64_t)uVar9 - 1) + iVar8;
        iVar10 = (int64_t)(int32_t)((iVar6 - uVar9) + 1);
    }
    func_0x0001800867f0(arg1, iVar8, iVar10);
    return 1;
}

// ============================================================
// Function: FUN_18009ac41
// Address: 0x18009ac41
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18009aaf0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t *piVar7;
    int64_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x00018009ac41;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar7 + 0x18;
    if (iVar8 == 0) {
code_r0x00018009ac41:
        func_0x000180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar5 = (*pcVar1)();
        return uVar5;
    }
    iVar2 = *(int32_t *)(*piVar7 + 0x14);
    uVar3 = func_0x000180088860(arg1, 2);
    if ((int32_t)uVar3 < 0) {
        uVar3 = uVar3 + 1 + iVar2;
    }
    uVar9 = 0;
    if (-1 < (int32_t)uVar3) {
        uVar9 = uVar3;
    }
    piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) < 1)) {
        iVar4 = -1;
    } else {
        iVar4 = func_0x000180088860(arg1, 3);
        if (-1 < iVar4) goto code_r0x00018009abe7;
    }
    iVar4 = iVar4 + 1 + iVar2;
code_r0x00018009abe7:
    iVar6 = 0;
    if (-1 < iVar4) {
        iVar6 = iVar4;
    }
    if ((int32_t)uVar9 < 1) {
        uVar9 = 1;
    }
    if (iVar2 < iVar6) {
        iVar6 = iVar2;
    }
    if (iVar6 < (int32_t)uVar9) {
        iVar8 = 0x1805aadb1;
        iVar10 = 0;
    } else {
        iVar8 = ((uint64_t)uVar9 - 1) + iVar8;
        iVar10 = (int64_t)(int32_t)((iVar6 - uVar9) + 1);
    }
    func_0x0001800867f0(arg1, iVar8, iVar10);
    return 1;
}

// ============================================================
// Function: FUN_18009ac60
// Address: 0x18009ac60
// Size: 171 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18009ac60(int64_t arg1)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t arg2;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_258 [24];
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    uint64_t auStack_18 [2];
    int64_t var_8h;
    
    auStack_18[0] = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_258;
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009ae2d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar7;
    if (iVar2 == -0x18) {
code_r0x00018009ae2d:
        func_0x000180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar8 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
    var_238h = (int64_t)&var_218h;
    var_230h = (int64_t)auStack_18;
    var_220h = 0;
    var_228h = arg1;
    if (uVar8 < 0x201) {
        var_238h = (int64_t)&var_218h;
        if (uVar8 == 0) goto code_r0x00018009ad7d;
    } else {
        var_238h = func_0x0001800890e0(&var_238h, uVar8 - 0x200, 0xffffffff);
    }
    do {
        puVar1 = (undefined *)(iVar2 + 0x17 + uVar8);
        uVar8 = uVar8 - 1;
        *(undefined *)var_238h = *puVar1;
        var_238h = var_238h + 1;
    } while (uVar8 != 0);
code_r0x00018009ad7d:
    arg2 = var_220h;
    iVar2 = var_228h;
    if (var_220h == 0) {
        func_0x0001800867f0(var_228h, &var_218h, (undefined *)(var_238h + (-0x20 - (int64_t)&var_238h)));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_228h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_228h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_228h, 1);
        }
        iVar3 = *(int64_t *)(iVar2 + 0x40);
        if (var_238h == var_230h) {
            uVar6 = fcn.18009a7e0(iVar2, arg2);
            *(undefined8 *)(iVar3 + -0x10) = uVar6;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar6 = fcn.18009a8e0(iVar2, arg2 + 0x18, (var_238h - arg2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar6;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    fcn.180459870(auStack_18[0] ^ (uint64_t)auStack_258);
    return;
}

// ============================================================
// Function: FUN_18009ad0b
// Address: 0x18009ad0b
// Size: 290 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18009ac60(int64_t arg1)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t arg2;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_258 [24];
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    uint64_t auStack_18 [2];
    int64_t var_8h;
    
    auStack_18[0] = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_258;
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009ae2d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar7;
    if (iVar2 == -0x18) {
code_r0x00018009ae2d:
        func_0x000180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar8 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
    var_238h = (int64_t)&var_218h;
    var_230h = (int64_t)auStack_18;
    var_220h = 0;
    var_228h = arg1;
    if (uVar8 < 0x201) {
        var_238h = (int64_t)&var_218h;
        if (uVar8 == 0) goto code_r0x00018009ad7d;
    } else {
        var_238h = func_0x0001800890e0(&var_238h, uVar8 - 0x200, 0xffffffff);
    }
    do {
        puVar1 = (undefined *)(iVar2 + 0x17 + uVar8);
        uVar8 = uVar8 - 1;
        *(undefined *)var_238h = *puVar1;
        var_238h = var_238h + 1;
    } while (uVar8 != 0);
code_r0x00018009ad7d:
    arg2 = var_220h;
    iVar2 = var_228h;
    if (var_220h == 0) {
        func_0x0001800867f0(var_228h, &var_218h, (undefined *)(var_238h + (-0x20 - (int64_t)&var_238h)));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_228h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_228h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_228h, 1);
        }
        iVar3 = *(int64_t *)(iVar2 + 0x40);
        if (var_238h == var_230h) {
            uVar6 = fcn.18009a7e0(iVar2, arg2);
            *(undefined8 *)(iVar3 + -0x10) = uVar6;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar6 = fcn.18009a8e0(iVar2, arg2 + 0x18, (var_238h - arg2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar6;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    fcn.180459870(auStack_18[0] ^ (uint64_t)auStack_258);
    return;
}

// ============================================================
// Function: FUN_18009ae2d
// Address: 0x18009ae2d
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18009ac60(int64_t arg1)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t arg2;
    int32_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    uint64_t uVar8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_258 [24];
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    uint64_t auStack_18 [2];
    int64_t var_8h;
    
    auStack_18[0] = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_258;
    piVar7 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009ae2d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar2 = *piVar7;
    if (iVar2 == -0x18) {
code_r0x00018009ae2d:
        func_0x000180088470(arg1, 1, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar8 = (uint64_t)*(uint32_t *)(iVar2 + 0x14);
    var_238h = (int64_t)&var_218h;
    var_230h = (int64_t)auStack_18;
    var_220h = 0;
    var_228h = arg1;
    if (uVar8 < 0x201) {
        var_238h = (int64_t)&var_218h;
        if (uVar8 == 0) goto code_r0x00018009ad7d;
    } else {
        var_238h = func_0x0001800890e0(&var_238h, uVar8 - 0x200, 0xffffffff);
    }
    do {
        puVar1 = (undefined *)(iVar2 + 0x17 + uVar8);
        uVar8 = uVar8 - 1;
        *(undefined *)var_238h = *puVar1;
        var_238h = var_238h + 1;
    } while (uVar8 != 0);
code_r0x00018009ad7d:
    arg2 = var_220h;
    iVar2 = var_228h;
    if (var_220h == 0) {
        func_0x0001800867f0(var_228h, &var_218h, (undefined *)(var_238h + (-0x20 - (int64_t)&var_238h)));
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_228h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_228h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_228h, 1);
        }
        iVar3 = *(int64_t *)(iVar2 + 0x40);
        if (var_238h == var_230h) {
            uVar6 = fcn.18009a7e0(iVar2, arg2);
            *(undefined8 *)(iVar3 + -0x10) = uVar6;
            *(undefined4 *)(iVar3 + -4) = 6;
        } else {
            uVar6 = fcn.18009a8e0(iVar2, arg2 + 0x18, (var_238h - arg2) + -0x18);
            *(undefined8 *)(iVar3 + -0x10) = uVar6;
            *(undefined4 *)(iVar3 + -4) = 6;
        }
    }
    fcn.180459870(auStack_18[0] ^ (uint64_t)auStack_258);
    return;
}

// ============================================================
// Function: FUN_18009ae50
// Address: 0x18009ae50
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009ae50(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b041;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b041:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009af87;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x000180460320(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009af87:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009aeed
// Address: 0x18009aeed
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009ae50(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b041;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b041:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009af87;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x000180460320(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009af87:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009af9c
// Address: 0x18009af9c
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009ae50(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b041;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b041:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009af87;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x000180460320(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009af87:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b041
// Address: 0x18009b041
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009ae50(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b041;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b041:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009af87;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x000180460320(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009af87:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b060
// Address: 0x18009b060
// Size: 157 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009b060(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b251;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b251:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009b197;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x00018046034c(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009b197:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b0fd
// Address: 0x18009b0fd
// Size: 175 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009b060(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b251;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b251:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009b197;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x00018046034c(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009b197:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b1ac
// Address: 0x18009b1ac
// Size: 165 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009b060(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b251;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b251:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009b197;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x00018046034c(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009b197:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b251
// Address: 0x18009b251
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18009b060(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t arg2;
    undefined uVar4;
    int32_t iVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_468h;
    undefined auStack_268 [32];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar5 = func_0x0001800a8360(arg1);
        if (iVar5 == 0) goto code_r0x00018009b251;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar6 + 0x18;
    if (iVar1 == 0) {
code_r0x00018009b251:
        func_0x000180088470(arg1, 1, 6);
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    var_248h = (int64_t)&var_228h;
    uVar8 = (uint64_t)*(uint32_t *)(*piVar6 + 0x14);
    var_240h = (int64_t)&var_28h;
    var_230h = 0;
    var_238h = arg1;
    if (uVar8 < 0x201) {
        uVar9 = 0;
        piVar6 = &var_228h;
        if (uVar8 == 0) goto code_r0x00018009b197;
    } else {
        piVar6 = (int64_t *)func_0x0001800890e0(&var_248h, uVar8 - 0x200, 0xffffffff);
        uVar9 = 0;
    }
    do {
        uVar4 = func_0x00018046034c(*(undefined *)(iVar1 + uVar9));
        uVar9 = uVar9 + 1;
        *(undefined *)piVar6 = uVar4;
        piVar6 = (int64_t *)((int64_t)piVar6 + 1);
    } while (uVar9 < uVar8);
code_r0x00018009b197:
    arg2 = var_230h;
    iVar1 = var_238h;
    var_248h = var_248h + uVar8;
    if (var_230h == 0) {
        func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
    } else {
        if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30))
        {
            (**(code **)0x180782658)(var_238h, 1);
        }
        iVar2 = *(int64_t *)(iVar1 + 0x40);
        if (var_248h == var_240h) {
            uVar7 = fcn.18009a7e0(iVar1, arg2);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        } else {
            uVar7 = fcn.18009a8e0(iVar1, arg2 + 0x18, (var_248h - arg2) + -0x18);
            *(undefined8 *)(iVar2 + -0x10) = uVar7;
            *(undefined4 *)(iVar2 + -4) = 6;
        }
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_268);
    return;
}

// ============================================================
// Function: FUN_18009b270
// Address: 0x18009b270
// Size: 155 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b270(int64_t arg1)
{
    int64_t iVar1;
    undefined auVar2 [16];
    code *pcVar3;
    int64_t arg2;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_268 [24];
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009b4da;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar5 + 0x18;
    if (iVar8 != 0) {
        uVar7 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
        iVar4 = func_0x000180088860(arg1);
        if (iVar4 < 1) {
            func_0x0001800867f0(arg1, 0x1805aadb1, 0);
        } else {
            uVar10 = (uint64_t)iVar4;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar10;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x40000000)) / auVar2, 0) < uVar7) {
                func_0x000180088560(arg1, 0x18063e588);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            var_248h = (int64_t)&var_228h;
            uVar9 = uVar10 * uVar7;
            var_240h = (int64_t)&var_28h;
            var_230h = 0;
            var_238h = arg1;
            if (uVar9 < 0x201) {
                piVar5 = &var_228h;
            } else {
                piVar5 = (int64_t *)func_0x0001800890e0(&var_248h, uVar9 - 0x200, 0xffffffff);
            }
            fcn.180498030(piVar5, iVar8, uVar7);
            uVar10 = (uVar10 - 1) * uVar7;
            iVar8 = uVar7 + (int64_t)piVar5;
            if (uVar7 < uVar10) {
                do {
                    fcn.180498030(iVar8, piVar5, uVar7);
                    iVar8 = iVar8 + uVar7;
                    uVar10 = uVar10 - uVar7;
                    uVar7 = uVar7 * 2;
                } while (uVar7 < uVar10);
            }
            fcn.180498030(iVar8, piVar5, uVar10);
            arg2 = var_230h;
            iVar8 = var_238h;
            var_248h = var_248h + uVar9;
            if (var_230h == 0) {
                func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
            } else {
                if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(var_238h, 1);
                }
                iVar1 = *(int64_t *)(iVar8 + 0x40);
                if (var_248h == var_240h) {
                    uVar6 = fcn.18009a7e0(iVar8, arg2);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                } else {
                    uVar6 = fcn.18009a8e0(iVar8, arg2 + 0x18, (var_248h - arg2) + -0x18);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                }
            }
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_268);
        return;
    }
code_r0x00018009b4da:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18009b30b
// Address: 0x18009b30b
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b270(int64_t arg1)
{
    int64_t iVar1;
    undefined auVar2 [16];
    code *pcVar3;
    int64_t arg2;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_268 [24];
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009b4da;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar5 + 0x18;
    if (iVar8 != 0) {
        uVar7 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
        iVar4 = func_0x000180088860(arg1);
        if (iVar4 < 1) {
            func_0x0001800867f0(arg1, 0x1805aadb1, 0);
        } else {
            uVar10 = (uint64_t)iVar4;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar10;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x40000000)) / auVar2, 0) < uVar7) {
                func_0x000180088560(arg1, 0x18063e588);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            var_248h = (int64_t)&var_228h;
            uVar9 = uVar10 * uVar7;
            var_240h = (int64_t)&var_28h;
            var_230h = 0;
            var_238h = arg1;
            if (uVar9 < 0x201) {
                piVar5 = &var_228h;
            } else {
                piVar5 = (int64_t *)func_0x0001800890e0(&var_248h, uVar9 - 0x200, 0xffffffff);
            }
            fcn.180498030(piVar5, iVar8, uVar7);
            uVar10 = (uVar10 - 1) * uVar7;
            iVar8 = uVar7 + (int64_t)piVar5;
            if (uVar7 < uVar10) {
                do {
                    fcn.180498030(iVar8, piVar5, uVar7);
                    iVar8 = iVar8 + uVar7;
                    uVar10 = uVar10 - uVar7;
                    uVar7 = uVar7 * 2;
                } while (uVar7 < uVar10);
            }
            fcn.180498030(iVar8, piVar5, uVar10);
            arg2 = var_230h;
            iVar8 = var_238h;
            var_248h = var_248h + uVar9;
            if (var_230h == 0) {
                func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
            } else {
                if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(var_238h, 1);
                }
                iVar1 = *(int64_t *)(iVar8 + 0x40);
                if (var_248h == var_240h) {
                    uVar6 = fcn.18009a7e0(iVar8, arg2);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                } else {
                    uVar6 = fcn.18009a8e0(iVar8, arg2 + 0x18, (var_248h - arg2) + -0x18);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                }
            }
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_268);
        return;
    }
code_r0x00018009b4da:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18009b340
// Address: 0x18009b340
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b270(int64_t arg1)
{
    int64_t iVar1;
    undefined auVar2 [16];
    code *pcVar3;
    int64_t arg2;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_268 [24];
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009b4da;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar5 + 0x18;
    if (iVar8 != 0) {
        uVar7 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
        iVar4 = func_0x000180088860(arg1);
        if (iVar4 < 1) {
            func_0x0001800867f0(arg1, 0x1805aadb1, 0);
        } else {
            uVar10 = (uint64_t)iVar4;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar10;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x40000000)) / auVar2, 0) < uVar7) {
                func_0x000180088560(arg1, 0x18063e588);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            var_248h = (int64_t)&var_228h;
            uVar9 = uVar10 * uVar7;
            var_240h = (int64_t)&var_28h;
            var_230h = 0;
            var_238h = arg1;
            if (uVar9 < 0x201) {
                piVar5 = &var_228h;
            } else {
                piVar5 = (int64_t *)func_0x0001800890e0(&var_248h, uVar9 - 0x200, 0xffffffff);
            }
            fcn.180498030(piVar5, iVar8, uVar7);
            uVar10 = (uVar10 - 1) * uVar7;
            iVar8 = uVar7 + (int64_t)piVar5;
            if (uVar7 < uVar10) {
                do {
                    fcn.180498030(iVar8, piVar5, uVar7);
                    iVar8 = iVar8 + uVar7;
                    uVar10 = uVar10 - uVar7;
                    uVar7 = uVar7 * 2;
                } while (uVar7 < uVar10);
            }
            fcn.180498030(iVar8, piVar5, uVar10);
            arg2 = var_230h;
            iVar8 = var_238h;
            var_248h = var_248h + uVar9;
            if (var_230h == 0) {
                func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
            } else {
                if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(var_238h, 1);
                }
                iVar1 = *(int64_t *)(iVar8 + 0x40);
                if (var_248h == var_240h) {
                    uVar6 = fcn.18009a7e0(iVar8, arg2);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                } else {
                    uVar6 = fcn.18009a8e0(iVar8, arg2 + 0x18, (var_248h - arg2) + -0x18);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                }
            }
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_268);
        return;
    }
code_r0x00018009b4da:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18009b369
// Address: 0x18009b369
// Size: 198 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b270(int64_t arg1)
{
    int64_t iVar1;
    undefined auVar2 [16];
    code *pcVar3;
    int64_t arg2;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_268 [24];
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009b4da;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar5 + 0x18;
    if (iVar8 != 0) {
        uVar7 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
        iVar4 = func_0x000180088860(arg1);
        if (iVar4 < 1) {
            func_0x0001800867f0(arg1, 0x1805aadb1, 0);
        } else {
            uVar10 = (uint64_t)iVar4;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar10;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x40000000)) / auVar2, 0) < uVar7) {
                func_0x000180088560(arg1, 0x18063e588);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            var_248h = (int64_t)&var_228h;
            uVar9 = uVar10 * uVar7;
            var_240h = (int64_t)&var_28h;
            var_230h = 0;
            var_238h = arg1;
            if (uVar9 < 0x201) {
                piVar5 = &var_228h;
            } else {
                piVar5 = (int64_t *)func_0x0001800890e0(&var_248h, uVar9 - 0x200, 0xffffffff);
            }
            fcn.180498030(piVar5, iVar8, uVar7);
            uVar10 = (uVar10 - 1) * uVar7;
            iVar8 = uVar7 + (int64_t)piVar5;
            if (uVar7 < uVar10) {
                do {
                    fcn.180498030(iVar8, piVar5, uVar7);
                    iVar8 = iVar8 + uVar7;
                    uVar10 = uVar10 - uVar7;
                    uVar7 = uVar7 * 2;
                } while (uVar7 < uVar10);
            }
            fcn.180498030(iVar8, piVar5, uVar10);
            arg2 = var_230h;
            iVar8 = var_238h;
            var_248h = var_248h + uVar9;
            if (var_230h == 0) {
                func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
            } else {
                if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(var_238h, 1);
                }
                iVar1 = *(int64_t *)(iVar8 + 0x40);
                if (var_248h == var_240h) {
                    uVar6 = fcn.18009a7e0(iVar8, arg2);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                } else {
                    uVar6 = fcn.18009a8e0(iVar8, arg2 + 0x18, (var_248h - arg2) + -0x18);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                }
            }
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_268);
        return;
    }
code_r0x00018009b4da:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18009b42f
// Address: 0x18009b42f
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b270(int64_t arg1)
{
    int64_t iVar1;
    undefined auVar2 [16];
    code *pcVar3;
    int64_t arg2;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_268 [24];
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009b4da;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar5 + 0x18;
    if (iVar8 != 0) {
        uVar7 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
        iVar4 = func_0x000180088860(arg1);
        if (iVar4 < 1) {
            func_0x0001800867f0(arg1, 0x1805aadb1, 0);
        } else {
            uVar10 = (uint64_t)iVar4;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar10;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x40000000)) / auVar2, 0) < uVar7) {
                func_0x000180088560(arg1, 0x18063e588);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            var_248h = (int64_t)&var_228h;
            uVar9 = uVar10 * uVar7;
            var_240h = (int64_t)&var_28h;
            var_230h = 0;
            var_238h = arg1;
            if (uVar9 < 0x201) {
                piVar5 = &var_228h;
            } else {
                piVar5 = (int64_t *)func_0x0001800890e0(&var_248h, uVar9 - 0x200, 0xffffffff);
            }
            fcn.180498030(piVar5, iVar8, uVar7);
            uVar10 = (uVar10 - 1) * uVar7;
            iVar8 = uVar7 + (int64_t)piVar5;
            if (uVar7 < uVar10) {
                do {
                    fcn.180498030(iVar8, piVar5, uVar7);
                    iVar8 = iVar8 + uVar7;
                    uVar10 = uVar10 - uVar7;
                    uVar7 = uVar7 * 2;
                } while (uVar7 < uVar10);
            }
            fcn.180498030(iVar8, piVar5, uVar10);
            arg2 = var_230h;
            iVar8 = var_238h;
            var_248h = var_248h + uVar9;
            if (var_230h == 0) {
                func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
            } else {
                if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(var_238h, 1);
                }
                iVar1 = *(int64_t *)(iVar8 + 0x40);
                if (var_248h == var_240h) {
                    uVar6 = fcn.18009a7e0(iVar8, arg2);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                } else {
                    uVar6 = fcn.18009a8e0(iVar8, arg2 + 0x18, (var_248h - arg2) + -0x18);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                }
            }
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_268);
        return;
    }
code_r0x00018009b4da:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_18009b4b3
// Address: 0x18009b4b3
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18009b270(int64_t arg1)
{
    int64_t iVar1;
    undefined auVar2 [16];
    code *pcVar3;
    int64_t arg2;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_268 [24];
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x00018009b4da;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar5 + 0x18;
    if (iVar8 != 0) {
        uVar7 = (uint64_t)*(uint32_t *)(*piVar5 + 0x14);
        iVar4 = func_0x000180088860(arg1);
        if (iVar4 < 1) {
            func_0x0001800867f0(arg1, 0x1805aadb1, 0);
        } else {
            uVar10 = (uint64_t)iVar4;
            auVar2._8_8_ = 0;
            auVar2._0_8_ = uVar10;
            if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0x40000000)) / auVar2, 0) < uVar7) {
                func_0x000180088560(arg1, 0x18063e588);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            var_248h = (int64_t)&var_228h;
            uVar9 = uVar10 * uVar7;
            var_240h = (int64_t)&var_28h;
            var_230h = 0;
            var_238h = arg1;
            if (uVar9 < 0x201) {
                piVar5 = &var_228h;
            } else {
                piVar5 = (int64_t *)func_0x0001800890e0(&var_248h, uVar9 - 0x200, 0xffffffff);
            }
            fcn.180498030(piVar5, iVar8, uVar7);
            uVar10 = (uVar10 - 1) * uVar7;
            iVar8 = uVar7 + (int64_t)piVar5;
            if (uVar7 < uVar10) {
                do {
                    fcn.180498030(iVar8, piVar5, uVar7);
                    iVar8 = iVar8 + uVar7;
                    uVar10 = uVar10 - uVar7;
                    uVar7 = uVar7 * 2;
                } while (uVar7 < uVar10);
            }
            fcn.180498030(iVar8, piVar5, uVar10);
            arg2 = var_230h;
            iVar8 = var_238h;
            var_248h = var_248h + uVar9;
            if (var_230h == 0) {
                func_0x0001800867f0(var_238h, &var_228h, (var_248h - (int64_t)&var_248h) + -0x20);
            } else {
                if (*(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x28) <=
                    *(uint64_t *)(*(int64_t *)(var_238h + 0x20) + 0x30)) {
                    (**(code **)0x180782658)(var_238h, 1);
                }
                iVar1 = *(int64_t *)(iVar8 + 0x40);
                if (var_248h == var_240h) {
                    uVar6 = fcn.18009a7e0(iVar8, arg2);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                } else {
                    uVar6 = fcn.18009a8e0(iVar8, arg2 + 0x18, (var_248h - arg2) + -0x18);
                    *(undefined8 *)(iVar1 + -0x10) = uVar6;
                    *(undefined4 *)(iVar1 + -4) = 6;
                }
            }
        }
        fcn.180459870(var_28h ^ (uint64_t)auStack_268);
        return;
    }
code_r0x00018009b4da:
    func_0x000180088470(arg1, 1, 6);
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

