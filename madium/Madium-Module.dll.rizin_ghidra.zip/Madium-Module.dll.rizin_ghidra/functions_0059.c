// Chunk 59 - 50 functions

// ============================================================
// Function: FUN_1800c1750
// Address: 0x1800c1750
// Size: 122 bytes
// ============================================================
void fcn.1800c1750(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 4) * 0x10;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                uVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c17b7;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c17d0
// Address: 0x1800c17d0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c17d0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = *(undefined8 **)arg1;
    if (puVar5 != (undefined8 *)0x0) {
        puVar1 = *(undefined8 **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 9) {
            (**(code **)*puVar5)(puVar5, 0);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar6 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_28, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_20;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c1872;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c17e9
// Address: 0x1800c17e9
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c17d0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = *(undefined8 **)arg1;
    if (puVar5 != (undefined8 *)0x0) {
        puVar1 = *(undefined8 **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 9) {
            (**(code **)*puVar5)(puVar5, 0);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar6 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_28, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_20;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c1872;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c1849
// Address: 0x1800c1849
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c17d0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = *(undefined8 **)arg1;
    if (puVar5 != (undefined8 *)0x0) {
        puVar1 = *(undefined8 **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 9) {
            (**(code **)*puVar5)(puVar5, 0);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar6 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_28, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_20;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800c1872;
        func_0x000180459c3c(iVar4);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c1890
// Address: 0x1800c1890
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c1890(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar1 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0x28) {
            func_0x000180004e40(iVar4 + 8);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0x28) * 0x28)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_28;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c192e;
        func_0x000180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c18a9
// Address: 0x1800c18a9
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c1890(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar1 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0x28) {
            func_0x000180004e40(iVar4 + 8);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0x28) * 0x28)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_28;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c192e;
        func_0x000180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c1908
// Address: 0x1800c1908
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c1890(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t iVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar4 = *(int64_t *)arg1;
    if (iVar4 != 0) {
        iVar1 = *(int64_t *)(arg1 + 8);
        for (; iVar4 != iVar1; iVar4 = iVar4 + 0x28) {
            func_0x000180004e40(iVar4 + 8);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0x28) * 0x28)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_28;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c192e;
        func_0x000180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c1950
// Address: 0x1800c1950
// Size: 121 bytes
// ============================================================
void fcn.1800c1950(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                uVar3 = 5;
                pcVar2 = (code *)swi(0x29);
                (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800c19b6;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800c19d0
// Address: 0x1800c19d0
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 *
fcn.1800c19d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    iVar1 = *(int64_t *)arg1;
    iVar14 = (*(int64_t *)(arg1 + 8) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    if (iVar14 == 0x492492492492492) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        puVar9 = (undefined4 *)(*pcVar2)();
        return puVar9;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar7 >> 1);
    if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
        uVar6 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar6;
        if (uVar6 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x492492492492493) {
            uVar7 = uVar13 * 0x38;
            if (uVar7 == 0) {
                puVar9 = (undefined4 *)0x0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar9 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1b6c;
                iVar14 = func_0x000180459890(uVar7 + 0x27);
                if (iVar14 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar14 = (*pcVar2)(5);
                    puVar10 = auStack_30;
                }
                puVar9 = (undefined4 *)(iVar14 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar9 + -2) = iVar14;
                puVar11 = puVar10;
            }
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            puVar12 = puVar9 + ((arg2 - iVar1) / 0x38) * 0xe;
            *puVar12 = *(undefined4 *)arg3;
            puVar12[1] = uVar3;
            puVar12[2] = uVar4;
            puVar12[3] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x14);
            uVar4 = *(undefined4 *)(arg3 + 0x18);
            uVar5 = *(undefined4 *)(arg3 + 0x1c);
            puVar12[4] = *(undefined4 *)(arg3 + 0x10);
            puVar12[5] = uVar3;
            puVar12[6] = uVar4;
            puVar12[7] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x24);
            uVar4 = *(undefined4 *)(arg3 + 0x28);
            uVar5 = *(undefined4 *)(arg3 + 0x2c);
            puVar12[8] = *(undefined4 *)(arg3 + 0x20);
            puVar12[9] = uVar3;
            puVar12[10] = uVar4;
            puVar12[0xb] = uVar5;
            *(undefined8 *)(puVar12 + 0xc) = *(undefined8 *)(arg3 + 0x30);
            iVar1 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar14 = *(int64_t *)(arg1 + 8) - iVar1;
                puVar8 = puVar9;
                arg2 = iVar1;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800c1b21;
                func_0x000180498030(puVar9, iVar1, arg2 - iVar1);
                puVar8 = puVar12 + 0xe;
                iVar14 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b34;
            func_0x000180498030(puVar8, arg2, iVar14);
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b45;
            func_0x0001800c2090(arg1, puVar9, uVar6, uVar13);
            return puVar12;
        }
    }
code_r0x0001800c1b6c:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    puVar9 = (undefined4 *)(*pcVar2)();
    return puVar9;
}

// ============================================================
// Function: FUN_1800c1a1d
// Address: 0x1800c1a1d
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 *
fcn.1800c19d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    iVar1 = *(int64_t *)arg1;
    iVar14 = (*(int64_t *)(arg1 + 8) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    if (iVar14 == 0x492492492492492) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        puVar9 = (undefined4 *)(*pcVar2)();
        return puVar9;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar7 >> 1);
    if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
        uVar6 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar6;
        if (uVar6 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x492492492492493) {
            uVar7 = uVar13 * 0x38;
            if (uVar7 == 0) {
                puVar9 = (undefined4 *)0x0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar9 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1b6c;
                iVar14 = func_0x000180459890(uVar7 + 0x27);
                if (iVar14 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar14 = (*pcVar2)(5);
                    puVar10 = auStack_30;
                }
                puVar9 = (undefined4 *)(iVar14 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar9 + -2) = iVar14;
                puVar11 = puVar10;
            }
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            puVar12 = puVar9 + ((arg2 - iVar1) / 0x38) * 0xe;
            *puVar12 = *(undefined4 *)arg3;
            puVar12[1] = uVar3;
            puVar12[2] = uVar4;
            puVar12[3] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x14);
            uVar4 = *(undefined4 *)(arg3 + 0x18);
            uVar5 = *(undefined4 *)(arg3 + 0x1c);
            puVar12[4] = *(undefined4 *)(arg3 + 0x10);
            puVar12[5] = uVar3;
            puVar12[6] = uVar4;
            puVar12[7] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x24);
            uVar4 = *(undefined4 *)(arg3 + 0x28);
            uVar5 = *(undefined4 *)(arg3 + 0x2c);
            puVar12[8] = *(undefined4 *)(arg3 + 0x20);
            puVar12[9] = uVar3;
            puVar12[10] = uVar4;
            puVar12[0xb] = uVar5;
            *(undefined8 *)(puVar12 + 0xc) = *(undefined8 *)(arg3 + 0x30);
            iVar1 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar14 = *(int64_t *)(arg1 + 8) - iVar1;
                puVar8 = puVar9;
                arg2 = iVar1;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800c1b21;
                func_0x000180498030(puVar9, iVar1, arg2 - iVar1);
                puVar8 = puVar12 + 0xe;
                iVar14 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b34;
            func_0x000180498030(puVar8, arg2, iVar14);
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b45;
            func_0x0001800c2090(arg1, puVar9, uVar6, uVar13);
            return puVar12;
        }
    }
code_r0x0001800c1b6c:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    puVar9 = (undefined4 *)(*pcVar2)();
    return puVar9;
}

// ============================================================
// Function: FUN_1800c1a2d
// Address: 0x1800c1a2d
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 *
fcn.1800c19d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    iVar1 = *(int64_t *)arg1;
    iVar14 = (*(int64_t *)(arg1 + 8) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    if (iVar14 == 0x492492492492492) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        puVar9 = (undefined4 *)(*pcVar2)();
        return puVar9;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar7 >> 1);
    if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
        uVar6 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar6;
        if (uVar6 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x492492492492493) {
            uVar7 = uVar13 * 0x38;
            if (uVar7 == 0) {
                puVar9 = (undefined4 *)0x0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar9 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1b6c;
                iVar14 = func_0x000180459890(uVar7 + 0x27);
                if (iVar14 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar14 = (*pcVar2)(5);
                    puVar10 = auStack_30;
                }
                puVar9 = (undefined4 *)(iVar14 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar9 + -2) = iVar14;
                puVar11 = puVar10;
            }
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            puVar12 = puVar9 + ((arg2 - iVar1) / 0x38) * 0xe;
            *puVar12 = *(undefined4 *)arg3;
            puVar12[1] = uVar3;
            puVar12[2] = uVar4;
            puVar12[3] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x14);
            uVar4 = *(undefined4 *)(arg3 + 0x18);
            uVar5 = *(undefined4 *)(arg3 + 0x1c);
            puVar12[4] = *(undefined4 *)(arg3 + 0x10);
            puVar12[5] = uVar3;
            puVar12[6] = uVar4;
            puVar12[7] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x24);
            uVar4 = *(undefined4 *)(arg3 + 0x28);
            uVar5 = *(undefined4 *)(arg3 + 0x2c);
            puVar12[8] = *(undefined4 *)(arg3 + 0x20);
            puVar12[9] = uVar3;
            puVar12[10] = uVar4;
            puVar12[0xb] = uVar5;
            *(undefined8 *)(puVar12 + 0xc) = *(undefined8 *)(arg3 + 0x30);
            iVar1 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar14 = *(int64_t *)(arg1 + 8) - iVar1;
                puVar8 = puVar9;
                arg2 = iVar1;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800c1b21;
                func_0x000180498030(puVar9, iVar1, arg2 - iVar1);
                puVar8 = puVar12 + 0xe;
                iVar14 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b34;
            func_0x000180498030(puVar8, arg2, iVar14);
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b45;
            func_0x0001800c2090(arg1, puVar9, uVar6, uVar13);
            return puVar12;
        }
    }
code_r0x0001800c1b6c:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    puVar9 = (undefined4 *)(*pcVar2)();
    return puVar9;
}

// ============================================================
// Function: FUN_1800c1b66
// Address: 0x1800c1b66
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 *
fcn.1800c19d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    iVar1 = *(int64_t *)arg1;
    iVar14 = (*(int64_t *)(arg1 + 8) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    if (iVar14 == 0x492492492492492) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        puVar9 = (undefined4 *)(*pcVar2)();
        return puVar9;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar7 >> 1);
    if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
        uVar6 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar6;
        if (uVar6 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x492492492492493) {
            uVar7 = uVar13 * 0x38;
            if (uVar7 == 0) {
                puVar9 = (undefined4 *)0x0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar9 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1b6c;
                iVar14 = func_0x000180459890(uVar7 + 0x27);
                if (iVar14 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar14 = (*pcVar2)(5);
                    puVar10 = auStack_30;
                }
                puVar9 = (undefined4 *)(iVar14 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar9 + -2) = iVar14;
                puVar11 = puVar10;
            }
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            puVar12 = puVar9 + ((arg2 - iVar1) / 0x38) * 0xe;
            *puVar12 = *(undefined4 *)arg3;
            puVar12[1] = uVar3;
            puVar12[2] = uVar4;
            puVar12[3] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x14);
            uVar4 = *(undefined4 *)(arg3 + 0x18);
            uVar5 = *(undefined4 *)(arg3 + 0x1c);
            puVar12[4] = *(undefined4 *)(arg3 + 0x10);
            puVar12[5] = uVar3;
            puVar12[6] = uVar4;
            puVar12[7] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x24);
            uVar4 = *(undefined4 *)(arg3 + 0x28);
            uVar5 = *(undefined4 *)(arg3 + 0x2c);
            puVar12[8] = *(undefined4 *)(arg3 + 0x20);
            puVar12[9] = uVar3;
            puVar12[10] = uVar4;
            puVar12[0xb] = uVar5;
            *(undefined8 *)(puVar12 + 0xc) = *(undefined8 *)(arg3 + 0x30);
            iVar1 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar14 = *(int64_t *)(arg1 + 8) - iVar1;
                puVar8 = puVar9;
                arg2 = iVar1;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800c1b21;
                func_0x000180498030(puVar9, iVar1, arg2 - iVar1);
                puVar8 = puVar12 + 0xe;
                iVar14 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b34;
            func_0x000180498030(puVar8, arg2, iVar14);
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b45;
            func_0x0001800c2090(arg1, puVar9, uVar6, uVar13);
            return puVar12;
        }
    }
code_r0x0001800c1b6c:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    puVar9 = (undefined4 *)(*pcVar2)();
    return puVar9;
}

// ============================================================
// Function: FUN_1800c1b6c
// Address: 0x1800c1b6c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined4 *
fcn.1800c19d0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined4 *puVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    undefined *puVar11;
    undefined4 *puVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar10 = auStack_38;
    puVar11 = auStack_38;
    iVar1 = *(int64_t *)arg1;
    iVar14 = (*(int64_t *)(arg1 + 8) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    if (iVar14 == 0x492492492492492) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        puVar9 = (undefined4 *)(*pcVar2)();
        return puVar9;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar1 >> 3) * 0x6db6db6db6db6db7;
    uVar6 = 0x492492492492492 - (uVar7 >> 1);
    if (uVar7 < uVar6 || uVar7 - uVar6 == 0) {
        uVar6 = iVar14 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar6;
        if (uVar6 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x492492492492493) {
            uVar7 = uVar13 * 0x38;
            if (uVar7 == 0) {
                puVar9 = (undefined4 *)0x0;
                puVar11 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar9 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1b6c;
                iVar14 = func_0x000180459890(uVar7 + 0x27);
                if (iVar14 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar14 = (*pcVar2)(5);
                    puVar10 = auStack_30;
                }
                puVar9 = (undefined4 *)(iVar14 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar9 + -2) = iVar14;
                puVar11 = puVar10;
            }
            uVar3 = *(undefined4 *)(arg3 + 4);
            uVar4 = *(undefined4 *)(arg3 + 8);
            uVar5 = *(undefined4 *)(arg3 + 0xc);
            puVar12 = puVar9 + ((arg2 - iVar1) / 0x38) * 0xe;
            *puVar12 = *(undefined4 *)arg3;
            puVar12[1] = uVar3;
            puVar12[2] = uVar4;
            puVar12[3] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x14);
            uVar4 = *(undefined4 *)(arg3 + 0x18);
            uVar5 = *(undefined4 *)(arg3 + 0x1c);
            puVar12[4] = *(undefined4 *)(arg3 + 0x10);
            puVar12[5] = uVar3;
            puVar12[6] = uVar4;
            puVar12[7] = uVar5;
            uVar3 = *(undefined4 *)(arg3 + 0x24);
            uVar4 = *(undefined4 *)(arg3 + 0x28);
            uVar5 = *(undefined4 *)(arg3 + 0x2c);
            puVar12[8] = *(undefined4 *)(arg3 + 0x20);
            puVar12[9] = uVar3;
            puVar12[10] = uVar4;
            puVar12[0xb] = uVar5;
            *(undefined8 *)(puVar12 + 0xc) = *(undefined8 *)(arg3 + 0x30);
            iVar1 = *(int64_t *)arg1;
            if (arg2 == *(int64_t *)(arg1 + 8)) {
                iVar14 = *(int64_t *)(arg1 + 8) - iVar1;
                puVar8 = puVar9;
                arg2 = iVar1;
            } else {
                *(undefined8 *)(puVar11 + -8) = 0x1800c1b21;
                func_0x000180498030(puVar9, iVar1, arg2 - iVar1);
                puVar8 = puVar12 + 0xe;
                iVar14 = *(int64_t *)(arg1 + 8) - arg2;
            }
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b34;
            func_0x000180498030(puVar8, arg2, iVar14);
            *(undefined8 *)(puVar11 + -8) = 0x1800c1b45;
            func_0x0001800c2090(arg1, puVar9, uVar6, uVar13);
            return puVar12;
        }
    }
code_r0x0001800c1b6c:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    puVar9 = (undefined4 *)(*pcVar2)();
    return puVar9;
}

// ============================================================
// Function: FUN_1800c1b80
// Address: 0x1800c1b80
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.1800c1b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined8 *unaff_RDI;
    int64_t iVar12;
    int64_t unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    iVar9 = *(int64_t *)arg1;
    iVar12 = (*(int64_t *)(arg1 + 8) - iVar9 >> 4) * -0x5555555555555555;
    if (iVar12 == 0x555555555555555) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) * -0x5555555555555555;
    uVar5 = 0x555555555555555 - (uVar7 >> 1);
    if (uVar5 <= uVar7 && uVar7 - uVar5 != 0) {
code_r0x0001800c1dd1:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = uVar7 + (uVar7 >> 1);
    uVar5 = iVar12 + 1;
    uVar8 = uVar5;
    if (uVar5 <= uVar7) {
        uVar8 = uVar7;
    }
    if (0x555555555555555 < uVar8) goto code_r0x0001800c1dd1;
    uVar7 = uVar8 * 0x30;
    if (uVar7 == 0) {
        unaff_RDI = (undefined8 *)0x0;
code_r0x0001800c1c63:
        iVar9 = (arg2 - iVar9) / 6 + (arg2 - iVar9 >> 0x3f);
        unaff_R12 = (iVar9 >> 3) - (iVar9 >> 0x3f);
        puVar10 = unaff_RDI + unaff_R12 * 6;
        *puVar10 = *(undefined8 *)arg3;
        puVar10[1] = *(undefined8 *)(arg3 + 8);
        *(undefined *)(puVar10 + 2) = *(undefined *)(arg3 + 0x10);
        *(undefined *)((int64_t)puVar10 + 0x11) = *(undefined *)(arg3 + 0x11);
        uVar1 = *(undefined8 *)(arg3 + 0x28);
        uVar2 = *(undefined8 *)(arg3 + 0x20);
        uVar3 = *(undefined8 *)(arg3 + 0x18);
        *(undefined8 *)(arg3 + 0x28) = 0;
        *(undefined8 *)(arg3 + 0x20) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0;
        puVar10[3] = uVar3;
        puVar10[4] = uVar2;
        puVar10[5] = uVar1;
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar12 = *(int64_t *)arg1;
        puVar6 = unaff_RDI;
        if (arg2 != iVar9) {
            func_0x0001800c2300(*(int64_t *)arg1, arg2, unaff_RDI);
            iVar9 = *(int64_t *)(arg1 + 8);
            puVar6 = puVar10 + 6;
            iVar12 = arg2;
        }
        func_0x0001800c2300(iVar12, iVar9, puVar6);
        iVar9 = *(int64_t *)arg1;
        if (iVar9 == 0) goto code_r0x0001800c1d88;
        iVar12 = *(int64_t *)(arg1 + 8);
        for (; iVar9 != iVar12; iVar9 = iVar9 + 0x30) {
            func_0x00018000ace0(iVar9 + 0x18);
        }
        iVar9 = *(int64_t *)arg1;
        iVar12 = iVar9;
        puVar11 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) << 4)) &&
           (iVar12 = *(int64_t *)(iVar9 + -8), puVar11 = auStack_48, 0x1f < (iVar9 - iVar12) - 8U))
        goto code_r0x0001800c1d76;
    } else {
        if (uVar7 < 0x1000) {
            unaff_RDI = (undefined8 *)func_0x000180459890(uVar7);
            goto code_r0x0001800c1c63;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1dd1;
        iVar12 = func_0x000180459890();
        if (iVar12 != 0) {
            unaff_RDI = (undefined8 *)(iVar12 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar12;
            goto code_r0x0001800c1c63;
        }
code_r0x0001800c1d76:
        iVar12 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar11 = auStack_40;
    }
    *(undefined8 *)(puVar11 + -8) = 0x1800c1d88;
    func_0x000180459c3c(iVar12);
code_r0x0001800c1d88:
    *(undefined8 **)arg1 = unaff_RDI;
    *(undefined8 **)(arg1 + 8) = unaff_RDI + uVar5 * 6;
    *(undefined8 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return unaff_RDI + unaff_R12 * 6;
}

// ============================================================
// Function: FUN_1800c1bc9
// Address: 0x1800c1bc9
// Size: 514 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.1800c1b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined8 *unaff_RDI;
    int64_t iVar12;
    int64_t unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    iVar9 = *(int64_t *)arg1;
    iVar12 = (*(int64_t *)(arg1 + 8) - iVar9 >> 4) * -0x5555555555555555;
    if (iVar12 == 0x555555555555555) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) * -0x5555555555555555;
    uVar5 = 0x555555555555555 - (uVar7 >> 1);
    if (uVar5 <= uVar7 && uVar7 - uVar5 != 0) {
code_r0x0001800c1dd1:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = uVar7 + (uVar7 >> 1);
    uVar5 = iVar12 + 1;
    uVar8 = uVar5;
    if (uVar5 <= uVar7) {
        uVar8 = uVar7;
    }
    if (0x555555555555555 < uVar8) goto code_r0x0001800c1dd1;
    uVar7 = uVar8 * 0x30;
    if (uVar7 == 0) {
        unaff_RDI = (undefined8 *)0x0;
code_r0x0001800c1c63:
        iVar9 = (arg2 - iVar9) / 6 + (arg2 - iVar9 >> 0x3f);
        unaff_R12 = (iVar9 >> 3) - (iVar9 >> 0x3f);
        puVar10 = unaff_RDI + unaff_R12 * 6;
        *puVar10 = *(undefined8 *)arg3;
        puVar10[1] = *(undefined8 *)(arg3 + 8);
        *(undefined *)(puVar10 + 2) = *(undefined *)(arg3 + 0x10);
        *(undefined *)((int64_t)puVar10 + 0x11) = *(undefined *)(arg3 + 0x11);
        uVar1 = *(undefined8 *)(arg3 + 0x28);
        uVar2 = *(undefined8 *)(arg3 + 0x20);
        uVar3 = *(undefined8 *)(arg3 + 0x18);
        *(undefined8 *)(arg3 + 0x28) = 0;
        *(undefined8 *)(arg3 + 0x20) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0;
        puVar10[3] = uVar3;
        puVar10[4] = uVar2;
        puVar10[5] = uVar1;
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar12 = *(int64_t *)arg1;
        puVar6 = unaff_RDI;
        if (arg2 != iVar9) {
            func_0x0001800c2300(*(int64_t *)arg1, arg2, unaff_RDI);
            iVar9 = *(int64_t *)(arg1 + 8);
            puVar6 = puVar10 + 6;
            iVar12 = arg2;
        }
        func_0x0001800c2300(iVar12, iVar9, puVar6);
        iVar9 = *(int64_t *)arg1;
        if (iVar9 == 0) goto code_r0x0001800c1d88;
        iVar12 = *(int64_t *)(arg1 + 8);
        for (; iVar9 != iVar12; iVar9 = iVar9 + 0x30) {
            func_0x00018000ace0(iVar9 + 0x18);
        }
        iVar9 = *(int64_t *)arg1;
        iVar12 = iVar9;
        puVar11 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) << 4)) &&
           (iVar12 = *(int64_t *)(iVar9 + -8), puVar11 = auStack_48, 0x1f < (iVar9 - iVar12) - 8U))
        goto code_r0x0001800c1d76;
    } else {
        if (uVar7 < 0x1000) {
            unaff_RDI = (undefined8 *)func_0x000180459890(uVar7);
            goto code_r0x0001800c1c63;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1dd1;
        iVar12 = func_0x000180459890();
        if (iVar12 != 0) {
            unaff_RDI = (undefined8 *)(iVar12 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar12;
            goto code_r0x0001800c1c63;
        }
code_r0x0001800c1d76:
        iVar12 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar11 = auStack_40;
    }
    *(undefined8 *)(puVar11 + -8) = 0x1800c1d88;
    func_0x000180459c3c(iVar12);
code_r0x0001800c1d88:
    *(undefined8 **)arg1 = unaff_RDI;
    *(undefined8 **)(arg1 + 8) = unaff_RDI + uVar5 * 6;
    *(undefined8 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return unaff_RDI + unaff_R12 * 6;
}

// ============================================================
// Function: FUN_1800c1dcb
// Address: 0x1800c1dcb
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.1800c1b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined8 *unaff_RDI;
    int64_t iVar12;
    int64_t unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    iVar9 = *(int64_t *)arg1;
    iVar12 = (*(int64_t *)(arg1 + 8) - iVar9 >> 4) * -0x5555555555555555;
    if (iVar12 == 0x555555555555555) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) * -0x5555555555555555;
    uVar5 = 0x555555555555555 - (uVar7 >> 1);
    if (uVar5 <= uVar7 && uVar7 - uVar5 != 0) {
code_r0x0001800c1dd1:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = uVar7 + (uVar7 >> 1);
    uVar5 = iVar12 + 1;
    uVar8 = uVar5;
    if (uVar5 <= uVar7) {
        uVar8 = uVar7;
    }
    if (0x555555555555555 < uVar8) goto code_r0x0001800c1dd1;
    uVar7 = uVar8 * 0x30;
    if (uVar7 == 0) {
        unaff_RDI = (undefined8 *)0x0;
code_r0x0001800c1c63:
        iVar9 = (arg2 - iVar9) / 6 + (arg2 - iVar9 >> 0x3f);
        unaff_R12 = (iVar9 >> 3) - (iVar9 >> 0x3f);
        puVar10 = unaff_RDI + unaff_R12 * 6;
        *puVar10 = *(undefined8 *)arg3;
        puVar10[1] = *(undefined8 *)(arg3 + 8);
        *(undefined *)(puVar10 + 2) = *(undefined *)(arg3 + 0x10);
        *(undefined *)((int64_t)puVar10 + 0x11) = *(undefined *)(arg3 + 0x11);
        uVar1 = *(undefined8 *)(arg3 + 0x28);
        uVar2 = *(undefined8 *)(arg3 + 0x20);
        uVar3 = *(undefined8 *)(arg3 + 0x18);
        *(undefined8 *)(arg3 + 0x28) = 0;
        *(undefined8 *)(arg3 + 0x20) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0;
        puVar10[3] = uVar3;
        puVar10[4] = uVar2;
        puVar10[5] = uVar1;
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar12 = *(int64_t *)arg1;
        puVar6 = unaff_RDI;
        if (arg2 != iVar9) {
            func_0x0001800c2300(*(int64_t *)arg1, arg2, unaff_RDI);
            iVar9 = *(int64_t *)(arg1 + 8);
            puVar6 = puVar10 + 6;
            iVar12 = arg2;
        }
        func_0x0001800c2300(iVar12, iVar9, puVar6);
        iVar9 = *(int64_t *)arg1;
        if (iVar9 == 0) goto code_r0x0001800c1d88;
        iVar12 = *(int64_t *)(arg1 + 8);
        for (; iVar9 != iVar12; iVar9 = iVar9 + 0x30) {
            func_0x00018000ace0(iVar9 + 0x18);
        }
        iVar9 = *(int64_t *)arg1;
        iVar12 = iVar9;
        puVar11 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) << 4)) &&
           (iVar12 = *(int64_t *)(iVar9 + -8), puVar11 = auStack_48, 0x1f < (iVar9 - iVar12) - 8U))
        goto code_r0x0001800c1d76;
    } else {
        if (uVar7 < 0x1000) {
            unaff_RDI = (undefined8 *)func_0x000180459890(uVar7);
            goto code_r0x0001800c1c63;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1dd1;
        iVar12 = func_0x000180459890();
        if (iVar12 != 0) {
            unaff_RDI = (undefined8 *)(iVar12 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar12;
            goto code_r0x0001800c1c63;
        }
code_r0x0001800c1d76:
        iVar12 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar11 = auStack_40;
    }
    *(undefined8 *)(puVar11 + -8) = 0x1800c1d88;
    func_0x000180459c3c(iVar12);
code_r0x0001800c1d88:
    *(undefined8 **)arg1 = unaff_RDI;
    *(undefined8 **)(arg1 + 8) = unaff_RDI + uVar5 * 6;
    *(undefined8 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return unaff_RDI + unaff_R12 * 6;
}

// ============================================================
// Function: FUN_1800c1dd1
// Address: 0x1800c1dd1
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 * fcn.1800c1b80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined *puVar11;
    undefined8 *unaff_RDI;
    int64_t iVar12;
    int64_t unaff_R12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    int64_t var_28h;
    
    iVar9 = *(int64_t *)arg1;
    iVar12 = (*(int64_t *)(arg1 + 8) - iVar9 >> 4) * -0x5555555555555555;
    if (iVar12 == 0x555555555555555) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) * -0x5555555555555555;
    uVar5 = 0x555555555555555 - (uVar7 >> 1);
    if (uVar5 <= uVar7 && uVar7 - uVar5 != 0) {
code_r0x0001800c1dd1:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined8 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = uVar7 + (uVar7 >> 1);
    uVar5 = iVar12 + 1;
    uVar8 = uVar5;
    if (uVar5 <= uVar7) {
        uVar8 = uVar7;
    }
    if (0x555555555555555 < uVar8) goto code_r0x0001800c1dd1;
    uVar7 = uVar8 * 0x30;
    if (uVar7 == 0) {
        unaff_RDI = (undefined8 *)0x0;
code_r0x0001800c1c63:
        iVar9 = (arg2 - iVar9) / 6 + (arg2 - iVar9 >> 0x3f);
        unaff_R12 = (iVar9 >> 3) - (iVar9 >> 0x3f);
        puVar10 = unaff_RDI + unaff_R12 * 6;
        *puVar10 = *(undefined8 *)arg3;
        puVar10[1] = *(undefined8 *)(arg3 + 8);
        *(undefined *)(puVar10 + 2) = *(undefined *)(arg3 + 0x10);
        *(undefined *)((int64_t)puVar10 + 0x11) = *(undefined *)(arg3 + 0x11);
        uVar1 = *(undefined8 *)(arg3 + 0x28);
        uVar2 = *(undefined8 *)(arg3 + 0x20);
        uVar3 = *(undefined8 *)(arg3 + 0x18);
        *(undefined8 *)(arg3 + 0x28) = 0;
        *(undefined8 *)(arg3 + 0x20) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0;
        puVar10[3] = uVar3;
        puVar10[4] = uVar2;
        puVar10[5] = uVar1;
        iVar9 = *(int64_t *)(arg1 + 8);
        iVar12 = *(int64_t *)arg1;
        puVar6 = unaff_RDI;
        if (arg2 != iVar9) {
            func_0x0001800c2300(*(int64_t *)arg1, arg2, unaff_RDI);
            iVar9 = *(int64_t *)(arg1 + 8);
            puVar6 = puVar10 + 6;
            iVar12 = arg2;
        }
        func_0x0001800c2300(iVar12, iVar9, puVar6);
        iVar9 = *(int64_t *)arg1;
        if (iVar9 == 0) goto code_r0x0001800c1d88;
        iVar12 = *(int64_t *)(arg1 + 8);
        for (; iVar9 != iVar12; iVar9 = iVar9 + 0x30) {
            func_0x00018000ace0(iVar9 + 0x18);
        }
        iVar9 = *(int64_t *)arg1;
        iVar12 = iVar9;
        puVar11 = auStack_48;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar9 >> 4) << 4)) &&
           (iVar12 = *(int64_t *)(iVar9 + -8), puVar11 = auStack_48, 0x1f < (iVar9 - iVar12) - 8U))
        goto code_r0x0001800c1d76;
    } else {
        if (uVar7 < 0x1000) {
            unaff_RDI = (undefined8 *)func_0x000180459890(uVar7);
            goto code_r0x0001800c1c63;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800c1dd1;
        iVar12 = func_0x000180459890();
        if (iVar12 != 0) {
            unaff_RDI = (undefined8 *)(iVar12 + 0x27U & 0xffffffffffffffe0);
            unaff_RDI[-1] = iVar12;
            goto code_r0x0001800c1c63;
        }
code_r0x0001800c1d76:
        iVar12 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar11 = auStack_40;
    }
    *(undefined8 *)(puVar11 + -8) = 0x1800c1d88;
    func_0x000180459c3c(iVar12);
code_r0x0001800c1d88:
    *(undefined8 **)arg1 = unaff_RDI;
    *(undefined8 **)(arg1 + 8) = unaff_RDI + uVar5 * 6;
    *(undefined8 **)(arg1 + 0x10) = unaff_RDI + uVar8 * 6;
    return unaff_RDI + unaff_R12 * 6;
}

// ============================================================
// Function: FUN_1800c1de0
// Address: 0x1800c1de0
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c1de0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg1 != arg2) {
        do {
            fcn.18002ee50(arg1 + 0x20);
            fcn.18002ee50(arg1 + 8);
            arg1 = arg1 + 0x38;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800c1e20
// Address: 0x1800c1e20
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c1e20(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_10h;
    
    if (arg1 != arg2) {
        do {
            fcn.180004e40(arg1 + 0x88);
            fcn.18002ee50(arg1 + 0x70);
            fcn.180004e40(arg1 + 0x50);
            fcn.180004e40(arg1 + 0x30);
            fcn.180004e40(arg1);
            arg1 = arg1 + 0xa8;
        } while (arg1 != arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800c1e90
// Address: 0x1800c1e90
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800c1e90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_88h)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t **ppiVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (arg2 == arg3) {
        return arg3;
    }
    iVar1 = *(int64_t *)(arg1 + 0x18);
    ppiVar2 = *(int64_t ***)(arg2 + 8);
    ppiVar3 = *(int64_t ***)(arg1 + 8);
    iVar7 = ((((((uint64_t)*(uint8_t *)(arg2 + 0x10) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
               (uint64_t)*(uint8_t *)(arg2 + 0x11)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x12)) *
              0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
    ppiVar6 = (int64_t **)(iVar7 + iVar1);
    ppiVar8 = (int64_t **)(iVar7 + 8 + iVar1);
    piVar4 = *ppiVar6;
    ppiVar5 = (int64_t **)*ppiVar8;
    ppiVar10 = (int64_t **)arg2;
    do {
        ppiVar11 = (int64_t **)*ppiVar10;
        func_0x000180459c3c(ppiVar10, 0x20);
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
        if (ppiVar10 == ppiVar5) {
            ppiVar5 = ppiVar2;
            if (piVar4 == (int64_t *)arg2) {
                *ppiVar6 = (int64_t *)ppiVar3;
                ppiVar5 = ppiVar3;
            }
            *ppiVar8 = (int64_t *)ppiVar5;
            while (ppiVar11 != (int64_t **)arg3) {
                uVar9 = (((((uint64_t)*(uint8_t *)(ppiVar11 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x11)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x12)) * 0x100000001b3 ^
                        (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar5 = *(int64_t ***)(iVar1 + 8 + uVar9 * 0x10);
                ppiVar6 = (int64_t **)(iVar1 + uVar9 * 0x10);
                ppiVar10 = ppiVar11;
                while( true ) {
                    ppiVar11 = (int64_t **)*ppiVar10;
                    func_0x000180459c3c(ppiVar10, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar10 == ppiVar5) break;
                    ppiVar10 = ppiVar11;
                    if (ppiVar11 == (int64_t **)arg3) goto code_r0x0001800c2046;
                }
                *ppiVar6 = (int64_t *)ppiVar3;
                *(int64_t ***)(iVar1 + uVar9 * 0x10 + 8) = ppiVar3;
            }
            goto code_r0x0001800c2049;
        }
        ppiVar10 = ppiVar11;
    } while (ppiVar11 != (int64_t **)arg3);
    if (piVar4 == (int64_t *)arg2) {
code_r0x0001800c2046:
        *ppiVar6 = (int64_t *)ppiVar11;
    }
code_r0x0001800c2049:
    *ppiVar2 = (int64_t *)ppiVar11;
    ppiVar11[1] = (int64_t *)ppiVar2;
    return arg3;
}

// ============================================================
// Function: FUN_1800c1eb9
// Address: 0x1800c1eb9
// Size: 433 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800c1e90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_88h)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t **ppiVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (arg2 == arg3) {
        return arg3;
    }
    iVar1 = *(int64_t *)(arg1 + 0x18);
    ppiVar2 = *(int64_t ***)(arg2 + 8);
    ppiVar3 = *(int64_t ***)(arg1 + 8);
    iVar7 = ((((((uint64_t)*(uint8_t *)(arg2 + 0x10) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
               (uint64_t)*(uint8_t *)(arg2 + 0x11)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x12)) *
              0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
    ppiVar6 = (int64_t **)(iVar7 + iVar1);
    ppiVar8 = (int64_t **)(iVar7 + 8 + iVar1);
    piVar4 = *ppiVar6;
    ppiVar5 = (int64_t **)*ppiVar8;
    ppiVar10 = (int64_t **)arg2;
    do {
        ppiVar11 = (int64_t **)*ppiVar10;
        func_0x000180459c3c(ppiVar10, 0x20);
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
        if (ppiVar10 == ppiVar5) {
            ppiVar5 = ppiVar2;
            if (piVar4 == (int64_t *)arg2) {
                *ppiVar6 = (int64_t *)ppiVar3;
                ppiVar5 = ppiVar3;
            }
            *ppiVar8 = (int64_t *)ppiVar5;
            while (ppiVar11 != (int64_t **)arg3) {
                uVar9 = (((((uint64_t)*(uint8_t *)(ppiVar11 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x11)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x12)) * 0x100000001b3 ^
                        (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar5 = *(int64_t ***)(iVar1 + 8 + uVar9 * 0x10);
                ppiVar6 = (int64_t **)(iVar1 + uVar9 * 0x10);
                ppiVar10 = ppiVar11;
                while( true ) {
                    ppiVar11 = (int64_t **)*ppiVar10;
                    func_0x000180459c3c(ppiVar10, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar10 == ppiVar5) break;
                    ppiVar10 = ppiVar11;
                    if (ppiVar11 == (int64_t **)arg3) goto code_r0x0001800c2046;
                }
                *ppiVar6 = (int64_t *)ppiVar3;
                *(int64_t ***)(iVar1 + uVar9 * 0x10 + 8) = ppiVar3;
            }
            goto code_r0x0001800c2049;
        }
        ppiVar10 = ppiVar11;
    } while (ppiVar11 != (int64_t **)arg3);
    if (piVar4 == (int64_t *)arg2) {
code_r0x0001800c2046:
        *ppiVar6 = (int64_t *)ppiVar11;
    }
code_r0x0001800c2049:
    *ppiVar2 = (int64_t *)ppiVar11;
    ppiVar11[1] = (int64_t *)ppiVar2;
    return arg3;
}

// ============================================================
// Function: FUN_1800c206a
// Address: 0x1800c206a
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800c1e90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_88h)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t **ppiVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (arg2 == arg3) {
        return arg3;
    }
    iVar1 = *(int64_t *)(arg1 + 0x18);
    ppiVar2 = *(int64_t ***)(arg2 + 8);
    ppiVar3 = *(int64_t ***)(arg1 + 8);
    iVar7 = ((((((uint64_t)*(uint8_t *)(arg2 + 0x10) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
               (uint64_t)*(uint8_t *)(arg2 + 0x11)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x12)) *
              0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
    ppiVar6 = (int64_t **)(iVar7 + iVar1);
    ppiVar8 = (int64_t **)(iVar7 + 8 + iVar1);
    piVar4 = *ppiVar6;
    ppiVar5 = (int64_t **)*ppiVar8;
    ppiVar10 = (int64_t **)arg2;
    do {
        ppiVar11 = (int64_t **)*ppiVar10;
        func_0x000180459c3c(ppiVar10, 0x20);
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
        if (ppiVar10 == ppiVar5) {
            ppiVar5 = ppiVar2;
            if (piVar4 == (int64_t *)arg2) {
                *ppiVar6 = (int64_t *)ppiVar3;
                ppiVar5 = ppiVar3;
            }
            *ppiVar8 = (int64_t *)ppiVar5;
            while (ppiVar11 != (int64_t **)arg3) {
                uVar9 = (((((uint64_t)*(uint8_t *)(ppiVar11 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x11)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x12)) * 0x100000001b3 ^
                        (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar5 = *(int64_t ***)(iVar1 + 8 + uVar9 * 0x10);
                ppiVar6 = (int64_t **)(iVar1 + uVar9 * 0x10);
                ppiVar10 = ppiVar11;
                while( true ) {
                    ppiVar11 = (int64_t **)*ppiVar10;
                    func_0x000180459c3c(ppiVar10, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar10 == ppiVar5) break;
                    ppiVar10 = ppiVar11;
                    if (ppiVar11 == (int64_t **)arg3) goto code_r0x0001800c2046;
                }
                *ppiVar6 = (int64_t *)ppiVar3;
                *(int64_t ***)(iVar1 + uVar9 * 0x10 + 8) = ppiVar3;
            }
            goto code_r0x0001800c2049;
        }
        ppiVar10 = ppiVar11;
    } while (ppiVar11 != (int64_t **)arg3);
    if (piVar4 == (int64_t *)arg2) {
code_r0x0001800c2046:
        *ppiVar6 = (int64_t *)ppiVar11;
    }
code_r0x0001800c2049:
    *ppiVar2 = (int64_t *)ppiVar11;
    ppiVar11[1] = (int64_t *)ppiVar2;
    return arg3;
}

// ============================================================
// Function: FUN_1800c2076
// Address: 0x1800c2076
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.1800c1e90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_88h)
{
    int64_t iVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    int64_t **ppiVar8;
    uint64_t uVar9;
    int64_t **ppiVar10;
    int64_t **ppiVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (arg2 == arg3) {
        return arg3;
    }
    iVar1 = *(int64_t *)(arg1 + 0x18);
    ppiVar2 = *(int64_t ***)(arg2 + 8);
    ppiVar3 = *(int64_t ***)(arg1 + 8);
    iVar7 = ((((((uint64_t)*(uint8_t *)(arg2 + 0x10) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
               (uint64_t)*(uint8_t *)(arg2 + 0x11)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x12)) *
              0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30)) * 0x10;
    ppiVar6 = (int64_t **)(iVar7 + iVar1);
    ppiVar8 = (int64_t **)(iVar7 + 8 + iVar1);
    piVar4 = *ppiVar6;
    ppiVar5 = (int64_t **)*ppiVar8;
    ppiVar10 = (int64_t **)arg2;
    do {
        ppiVar11 = (int64_t **)*ppiVar10;
        func_0x000180459c3c(ppiVar10, 0x20);
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
        if (ppiVar10 == ppiVar5) {
            ppiVar5 = ppiVar2;
            if (piVar4 == (int64_t *)arg2) {
                *ppiVar6 = (int64_t *)ppiVar3;
                ppiVar5 = ppiVar3;
            }
            *ppiVar8 = (int64_t *)ppiVar5;
            while (ppiVar11 != (int64_t **)arg3) {
                uVar9 = (((((uint64_t)*(uint8_t *)(ppiVar11 + 2) ^ 0xcbf29ce484222325) * 0x100000001b3 ^
                          (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x11)) * 0x100000001b3 ^
                         (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x12)) * 0x100000001b3 ^
                        (uint64_t)*(uint8_t *)((int64_t)ppiVar11 + 0x13)) * 0x100000001b3 & *(uint64_t *)(arg1 + 0x30);
                ppiVar5 = *(int64_t ***)(iVar1 + 8 + uVar9 * 0x10);
                ppiVar6 = (int64_t **)(iVar1 + uVar9 * 0x10);
                ppiVar10 = ppiVar11;
                while( true ) {
                    ppiVar11 = (int64_t **)*ppiVar10;
                    func_0x000180459c3c(ppiVar10, 0x20);
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + -1;
                    if (ppiVar10 == ppiVar5) break;
                    ppiVar10 = ppiVar11;
                    if (ppiVar11 == (int64_t **)arg3) goto code_r0x0001800c2046;
                }
                *ppiVar6 = (int64_t *)ppiVar3;
                *(int64_t ***)(iVar1 + uVar9 * 0x10 + 8) = ppiVar3;
            }
            goto code_r0x0001800c2049;
        }
        ppiVar10 = ppiVar11;
    } while (ppiVar11 != (int64_t **)arg3);
    if (piVar4 == (int64_t *)arg2) {
code_r0x0001800c2046:
        *ppiVar6 = (int64_t *)ppiVar11;
    }
code_r0x0001800c2049:
    *ppiVar2 = (int64_t *)ppiVar11;
    ppiVar11[1] = (int64_t *)ppiVar2;
    return arg3;
}

// ============================================================
// Function: FUN_1800c2090
// Address: 0x1800c2090
// Size: 139 bytes
// ============================================================
void fcn.1800c2090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800c20f9;
        func_0x000180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x38 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x38 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800c2120
// Address: 0x1800c2120
// Size: 123 bytes
// ============================================================
void fcn.1800c2120(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800c217f;
        func_0x000180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 8;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 8;
    return;
}

// ============================================================
// Function: FUN_1800c21e0
// Address: 0x1800c21e0
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c21e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x1fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 8;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = func_0x000180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = func_0x000180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800c21f8
// Address: 0x1800c21f8
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c21e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x1fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 8;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = func_0x000180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = func_0x000180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800c2263
// Address: 0x1800c2263
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c21e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x1fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 8;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = func_0x000180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = func_0x000180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800c2269
// Address: 0x1800c2269
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c21e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x1fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 8;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = func_0x000180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            func_0x000180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = func_0x000180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800c2300
// Address: 0x1800c2300
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1800c2300(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    if (arg1 != arg2) {
        puVar5 = (undefined8 *)(arg1 + 0x18);
        do {
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            *(undefined8 *)(arg3 + 8) = *(undefined8 *)(arg1 + 8);
            *(undefined *)(arg3 + 0x10) = *(undefined *)(arg1 + 0x10);
            puVar1 = (undefined *)(arg1 + 0x11);
            arg1 = arg1 + 0x30;
            *(undefined *)(arg3 + 0x11) = *puVar1;
            uVar2 = puVar5[2];
            uVar3 = puVar5[1];
            uVar4 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x18) = uVar4;
            *(undefined8 *)(arg3 + 0x20) = uVar3;
            *(undefined8 *)(arg3 + 0x28) = uVar2;
            arg3 = arg3 + 0x30;
            puVar5 = puVar5 + 6;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_1800c230f
// Address: 0x1800c230f
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1800c2300(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    if (arg1 != arg2) {
        puVar5 = (undefined8 *)(arg1 + 0x18);
        do {
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            *(undefined8 *)(arg3 + 8) = *(undefined8 *)(arg1 + 8);
            *(undefined *)(arg3 + 0x10) = *(undefined *)(arg1 + 0x10);
            puVar1 = (undefined *)(arg1 + 0x11);
            arg1 = arg1 + 0x30;
            *(undefined *)(arg3 + 0x11) = *puVar1;
            uVar2 = puVar5[2];
            uVar3 = puVar5[1];
            uVar4 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x18) = uVar4;
            *(undefined8 *)(arg3 + 0x20) = uVar3;
            *(undefined8 *)(arg3 + 0x28) = uVar2;
            arg3 = arg3 + 0x30;
            puVar5 = puVar5 + 6;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_1800c2379
// Address: 0x1800c2379
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.1800c2300(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    
    if (arg1 != arg2) {
        puVar5 = (undefined8 *)(arg1 + 0x18);
        do {
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            *(undefined8 *)(arg3 + 8) = *(undefined8 *)(arg1 + 8);
            *(undefined *)(arg3 + 0x10) = *(undefined *)(arg1 + 0x10);
            puVar1 = (undefined *)(arg1 + 0x11);
            arg1 = arg1 + 0x30;
            *(undefined *)(arg3 + 0x11) = *puVar1;
            uVar2 = puVar5[2];
            uVar3 = puVar5[1];
            uVar4 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x18) = uVar4;
            *(undefined8 *)(arg3 + 0x20) = uVar3;
            *(undefined8 *)(arg3 + 0x28) = uVar2;
            arg3 = arg3 + 0x30;
            puVar5 = puVar5 + 6;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_1800c2390
// Address: 0x1800c2390
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c2390(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)(arg1 + 8);
    for (puVar2 = *(undefined8 **)arg1; puVar2 != puVar1; puVar2 = puVar2 + 9) {
        (**(code **)*puVar2)(puVar2, 0);
    }
    return;
}

// ============================================================
// Function: FUN_1800c23d0
// Address: 0x1800c23d0
// Size: 121 bytes
// ============================================================
void fcn.1800c23d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        iVar3 = iVar1;
        puVar4 = auStack_48;
        if ((0xfff < (*(int64_t *)(arg1 + 0x10) - iVar1 & 0xfffffffffffffff0U)) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_48, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_40;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800c2427;
        func_0x000180459c3c(iVar3);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x10 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x10 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800c2450
// Address: 0x1800c2450
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c2450(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if ((uint64_t)arg2 < 0x2000000000000000) {
        uVar1 = arg2 * 8;
        if (uVar1 == 0) {
            uVar4 = 0;
        } else if (uVar1 < 0x1000) {
            uVar4 = func_0x000180459890(uVar1);
        } else {
            if (uVar1 + 0x27 <= uVar1) goto code_r0x0001800c24d2;
            iVar3 = func_0x000180459890();
            iVar5 = iVar3;
            if (iVar3 == 0) {
                iVar5 = 5;
                pcVar2 = (code *)swi(0x29);
                iVar3 = (*pcVar2)();
            }
            uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar4 - 8) = iVar5;
        }
        *(uint64_t *)arg1 = uVar4;
        *(uint64_t *)(arg1 + 8) = uVar4;
        *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
        return;
    }
code_r0x0001800c24d2:
    func_0x000180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800c24e0
// Address: 0x1800c24e0
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800c24e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t arg2_00;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    fcn.1800c2610();
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    arg2_00 = *(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x28) >> 3;
    if (arg2_00 != 0) {
        if (0x1fffffffffffffff < arg2_00) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.1800c2450(arg1 + 0x28, arg2_00);
        iVar2 = *(int64_t *)(arg1 + 0x28);
        iVar3 = *(int64_t *)(arg2 + 0x30) - *(int64_t *)(arg2 + 0x28);
        fcn.180498030(iVar2, *(int64_t *)(arg2 + 0x28), iVar3);
        *(int64_t *)(arg1 + 0x30) = iVar2 + (iVar3 >> 3) * 8;
    }
    *(undefined8 *)(arg1 + 0x40) = *(undefined8 *)(arg2 + 0x40);
    return arg1;
}

// ============================================================
// Function: FUN_1800c25a0
// Address: 0x1800c25a0
// Size: 42 bytes
// ============================================================
void fcn.1800c25a0(int64_t arg1)
{
    fcn.180004e40(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    if (*(char *)(arg1 + 0x10) != '\0') {
        fcn.180460d90(*(undefined8 *)(arg1 + 8));
    }
    *(undefined *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800c25d0
// Address: 0x1800c25d0
// Size: 61 bytes
// ============================================================
void fcn.1800c25d0(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    fcn.180004e40(arg1 + 0x88);
    fcn.18002ee50(arg1 + 0x70);
    fcn.180004e40(arg1 + 0x50);
    fcn.180004e40(arg1 + 0x30);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_1800c2610
// Address: 0x1800c2610
// Size: 127 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c2610(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = *(undefined8 *)(arg2 + 0x10);
    *(undefined8 *)(arg1 + 0x18) = *(undefined8 *)(arg2 + 0x18);
    if (*(int64_t *)(arg2 + 8) != 0) {
        uVar6 = func_0x000180459890(*(int64_t *)(arg2 + 8) << 4);
        *(undefined8 *)arg1 = uVar6;
        uVar7 = 0;
        if (*(int64_t *)(arg2 + 8) != 0) {
            do {
                uVar8 = uVar7 + 1;
                puVar1 = (undefined4 *)(*(int64_t *)arg2 + uVar7 * 0x10);
                uVar3 = puVar1[1];
                uVar4 = puVar1[2];
                uVar5 = puVar1[3];
                puVar2 = (undefined4 *)(*(int64_t *)arg1 + uVar7 * 0x10);
                *puVar2 = *puVar1;
                puVar2[1] = uVar3;
                puVar2[2] = uVar4;
                puVar2[3] = uVar5;
                *(uint64_t *)(arg1 + 8) = uVar8;
                uVar7 = uVar8;
            } while (uVar8 < *(uint64_t *)(arg2 + 8));
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c2690
// Address: 0x1800c2690
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800c2690(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x180640168;
    uVar1 = *(undefined4 *)(arg2 + 0x1c);
    uVar2 = *(undefined4 *)(arg2 + 0x20);
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x1c) = uVar1;
    *(undefined4 *)(arg1 + 0x20) = uVar2;
    *(undefined4 *)(arg1 + 0x24) = uVar3;
    fcn.18000b4d0(arg1 + 0x28, arg2 + 0x28);
    return arg1;
}

// ============================================================
// Function: FUN_1800c2700
// Address: 0x1800c2700
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800c2700(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180004e40(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    fcn.18045b56c(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x48);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800c2750
// Address: 0x1800c2750
// Size: 340 bytes
// ============================================================
bool fcn.1800c2750(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    
    // switch table (7 cases) at 0x1800c2888
    switch(*(int32_t *)arg1 + -1) {
    case 0:
        return *(int32_t *)arg2 == 1;
    case 1:
        if ((*(int32_t *)arg2 == 2) && (*(char *)(arg1 + 8) == *(char *)(arg2 + 8))) {
            return true;
        }
        break;
    case 2:
        if ((*(int32_t *)arg2 == 3) && (*(double *)(arg1 + 8) == *(double *)(arg2 + 8))) {
            return true;
        }
        break;
    case 3:
        if (((*(char *)0x180778580 != '\0') && (*(int32_t *)arg2 == 4)) &&
           (*(int64_t *)(arg1 + 8) == *(int64_t *)(arg2 + 8))) {
            return true;
        }
        break;
    case 4:
        if (((*(int32_t *)arg2 == 5) && (*(float *)(arg1 + 8) == *(float *)(arg2 + 8))) &&
           ((*(float *)(arg1 + 0xc) == *(float *)(arg2 + 0xc) &&
            ((*(float *)(arg1 + 0x10) == *(float *)(arg2 + 0x10) && (*(float *)(arg1 + 0x14) == *(float *)(arg2 + 0x14))
             ))))) {
            return true;
        }
        break;
    case 5:
        if (((*(int32_t *)arg2 == 6) && (*(int32_t *)(arg1 + 4) == *(int32_t *)(arg2 + 4))) &&
           (iVar1 = fcn.180497f30(*(undefined8 *)(arg1 + 8), *(undefined8 *)(arg2 + 8), *(int32_t *)(arg1 + 4)),
           iVar1 == 0)) {
            return true;
        }
        break;
    case 6:
        if (((*(char *)0x180778018 != '\0') && (*(int32_t *)arg2 == 7)) &&
           (*(int64_t *)(arg1 + 8) == *(int64_t *)(arg2 + 8))) {
            return true;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1800c28b0
// Address: 0x1800c28b0
// Size: 2952 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_9h
// WARNING: Variable defined which should be unmapped: var_11h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_29h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_31h

void fcn.1800c28b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    double dVar1;
    code *pcVar2;
    double dVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    bool bVar6;
    undefined auVar7 [16];
    uint8_t uVar8;
    undefined uVar9;
    int32_t iVar10;
    int64_t iVar11;
    undefined *puVar12;
    undefined *puVar13;
    uint64_t uVar14;
    float fVar15;
    float fVar16;
    undefined4 uVar17;
    undefined8 uVar18;
    int64_t var_10h;
    undefined8 in_stack_00000028;
    undefined auStack_b8 [8];
    undefined auStack_b0 [24];
    int64_t var_98h;
    undefined uStack_88;
    undefined8 uStack_80;
    undefined auStack_78 [16];
    int64_t iStack_68;
    uint64_t uStack_60;
    uint64_t uStack_58;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_29h;
    int64_t var_21h;
    int64_t var_11h;
    int64_t var_9h;
    
    if (0xf < (uint32_t)arg2) {
        return;
    }
    uStack_58 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    // switch table (16 cases) at 0x1800c33f8
    switch((uint32_t)arg2) {
    case 0:
        if (*(int32_t *)arg3 == 3) {
            puVar12 = auStack_b8;
            if (*(int32_t *)arg4 == 3) {
                *(undefined4 *)arg1 = 3;
                *(double *)(arg1 + 8) = *(double *)(arg4 + 8) + *(double *)(arg3 + 8);
                puVar12 = auStack_b8;
            }
        } else {
            puVar12 = auStack_b8;
            if ((*(int32_t *)arg3 == 5) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 5)) {
                *(undefined4 *)arg1 = 5;
                *(float *)(arg1 + 8) = *(float *)(arg4 + 8) + *(float *)(arg3 + 8);
                *(float *)(arg1 + 0xc) = *(float *)(arg4 + 0xc) + *(float *)(arg3 + 0xc);
                *(float *)(arg1 + 0x10) = *(float *)(arg4 + 0x10) + *(float *)(arg3 + 0x10);
                *(float *)(arg1 + 0x14) = *(float *)(arg4 + 0x14) + *(float *)(arg3 + 0x14);
                puVar12 = auStack_b8;
            }
        }
        break;
    case 1:
        if (*(int32_t *)arg3 == 3) {
            puVar12 = auStack_b8;
            if (*(int32_t *)arg4 == 3) {
                *(undefined4 *)arg1 = 3;
                *(double *)(arg1 + 8) = *(double *)(arg3 + 8) - *(double *)(arg4 + 8);
                puVar12 = auStack_b8;
            }
        } else {
            puVar12 = auStack_b8;
            if ((*(int32_t *)arg3 == 5) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 5)) {
                *(undefined4 *)arg1 = 5;
                *(float *)(arg1 + 8) = *(float *)(arg3 + 8) - *(float *)(arg4 + 8);
                *(float *)(arg1 + 0xc) = *(float *)(arg3 + 0xc) - *(float *)(arg4 + 0xc);
                *(float *)(arg1 + 0x10) = *(float *)(arg3 + 0x10) - *(float *)(arg4 + 0x10);
                *(float *)(arg1 + 0x14) = *(float *)(arg3 + 0x14) - *(float *)(arg4 + 0x14);
                puVar12 = auStack_b8;
            }
        }
        break;
    case 2:
        iVar10 = *(int32_t *)arg3;
        if (iVar10 == 3) {
            if (*(int32_t *)arg4 == 3) {
                *(undefined4 *)arg1 = 3;
                *(double *)(arg1 + 8) = *(double *)(arg4 + 8) * *(double *)(arg3 + 8);
                puVar12 = auStack_b8;
                break;
            }
code_r0x0001800c2abd:
            if (iVar10 == 3) {
                puVar12 = auStack_b8;
                if (*(int32_t *)arg4 == 5) {
                    fVar15 = (float)*(double *)(arg3 + 8) * *(float *)(arg4 + 0x14);
                    if ((fVar15 == 0.0) || (puVar12 = auStack_b8, *(float *)(arg4 + 0x14) != 0.0)) {
                        *(undefined4 *)arg1 = 5;
                        *(float *)(arg1 + 8) = (float)*(double *)(arg3 + 8) * *(float *)(arg4 + 8);
                        *(float *)(arg1 + 0xc) = (float)*(double *)(arg3 + 8) * *(float *)(arg4 + 0xc);
                        *(float *)(arg1 + 0x10) = (float)*(double *)(arg3 + 8) * *(float *)(arg4 + 0x10);
                        *(float *)(arg1 + 0x14) = fVar15;
                        puVar12 = auStack_b8;
                    }
                }
                break;
            }
code_r0x0001800c2b52:
            puVar12 = auStack_b8;
            if ((iVar10 != 5) || (puVar12 = auStack_b8, *(int32_t *)arg4 != 3)) break;
            fVar15 = (float)*(double *)(arg4 + 8) * *(float *)(arg3 + 0x14);
            if ((fVar15 != 0.0) && (puVar12 = auStack_b8, *(float *)(arg3 + 0x14) == 0.0)) break;
            *(undefined4 *)arg1 = 5;
            *(float *)(arg1 + 8) = (float)*(double *)(arg4 + 8) * *(float *)(arg3 + 8);
            *(float *)(arg1 + 0xc) = (float)*(double *)(arg4 + 8) * *(float *)(arg3 + 0xc);
            fVar16 = (float)*(double *)(arg4 + 8);
        } else {
            if (iVar10 != 5) goto code_r0x0001800c2abd;
            if (*(int32_t *)arg4 != 5) goto code_r0x0001800c2b52;
            if (*(float *)(arg3 + 0x14) == 0.0) {
                fVar15 = *(float *)(arg4 + 0x14);
                if (fVar15 != 0.0) goto code_r0x0001800c2a75;
                bVar6 = false;
            } else {
                fVar15 = *(float *)(arg4 + 0x14);
code_r0x0001800c2a75:
                bVar6 = true;
            }
            fVar15 = *(float *)(arg3 + 0x14) * fVar15;
            if ((fVar15 != 0.0) && (puVar12 = auStack_b8, !bVar6)) break;
            *(undefined4 *)arg1 = 5;
            *(float *)(arg1 + 8) = *(float *)(arg4 + 8) * *(float *)(arg3 + 8);
            *(float *)(arg1 + 0xc) = *(float *)(arg4 + 0xc) * *(float *)(arg3 + 0xc);
            fVar16 = *(float *)(arg4 + 0x10);
        }
        *(float *)(arg1 + 0x10) = fVar16 * *(float *)(arg3 + 0x10);
        *(float *)(arg1 + 0x14) = fVar15;
        puVar12 = auStack_b8;
        break;
    case 3:
        iVar10 = *(int32_t *)arg3;
        if (iVar10 == 3) {
            if (*(int32_t *)arg4 == 3) {
                *(undefined4 *)arg1 = 3;
                *(double *)(arg1 + 8) = *(double *)(arg3 + 8) / *(double *)(arg4 + 8);
                puVar12 = auStack_b8;
                break;
            }
code_r0x0001800c2c9d:
            if (iVar10 == 3) {
                puVar12 = auStack_b8;
                if (*(int32_t *)arg4 == 5) {
                    fVar15 = (float)*(double *)(arg3 + 8) / *(float *)(arg4 + 0x14);
                    if ((fVar15 == 0.0) || (puVar12 = auStack_b8, *(float *)(arg4 + 0x14) != 0.0)) {
                        *(undefined4 *)arg1 = 5;
                        *(float *)(arg1 + 8) = (float)*(double *)(arg3 + 8) / *(float *)(arg4 + 8);
                        *(float *)(arg1 + 0xc) = (float)*(double *)(arg3 + 8) / *(float *)(arg4 + 0xc);
                        *(float *)(arg1 + 0x10) = (float)*(double *)(arg3 + 8) / *(float *)(arg4 + 0x10);
                        *(float *)(arg1 + 0x14) = fVar15;
                        puVar12 = auStack_b8;
                    }
                }
                break;
            }
        } else {
            if (iVar10 != 5) goto code_r0x0001800c2c9d;
            if (*(int32_t *)arg4 == 5) {
                if ((*(float *)(arg3 + 0x14) == 0.0) && (*(float *)(arg4 + 0x14) == 0.0)) {
                    bVar6 = false;
                } else {
                    bVar6 = true;
                }
                fVar15 = *(float *)(arg3 + 0x14) / *(float *)(arg4 + 0x14);
                if ((fVar15 == 0.0) || (puVar12 = auStack_b8, bVar6)) {
                    *(undefined4 *)arg1 = 5;
                    *(float *)(arg1 + 8) = *(float *)(arg3 + 8) / *(float *)(arg4 + 8);
                    *(float *)(arg1 + 0xc) = *(float *)(arg3 + 0xc) / *(float *)(arg4 + 0xc);
                    *(float *)(arg1 + 0x10) = *(float *)(arg3 + 0x10) / *(float *)(arg4 + 0x10);
                    *(float *)(arg1 + 0x14) = fVar15;
                    puVar12 = auStack_b8;
                }
                break;
            }
        }
        puVar12 = auStack_b8;
        if ((iVar10 == 5) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            fVar15 = *(float *)(arg3 + 0x14) / (float)*(double *)(arg4 + 8);
            if ((fVar15 == 0.0) || (puVar12 = auStack_b8, *(float *)(arg3 + 0x14) != 0.0)) {
                *(undefined4 *)arg1 = 5;
                *(float *)(arg1 + 8) = *(float *)(arg3 + 8) / (float)*(double *)(arg4 + 8);
                *(float *)(arg1 + 0xc) = *(float *)(arg3 + 0xc) / (float)*(double *)(arg4 + 8);
                *(float *)(arg1 + 0x10) = *(float *)(arg3 + 0x10) / (float)*(double *)(arg4 + 8);
                *(float *)(arg1 + 0x14) = fVar15;
                puVar12 = auStack_b8;
            }
        }
        break;
    case 4:
        iVar10 = *(int32_t *)arg3;
        if (iVar10 == 3) {
            if (*(int32_t *)arg4 == 3) {
                *(undefined4 *)arg1 = 3;
                uVar18 = func_0x0001804909e0(SUB84(*(double *)(arg3 + 8) / *(double *)(arg4 + 8), 0));
                *(undefined8 *)(arg1 + 8) = uVar18;
                puVar12 = auStack_b8;
                break;
            }
code_r0x0001800c2ea5:
            if (iVar10 == 3) {
                puVar12 = auStack_b8;
                if (*(int32_t *)arg4 == 5) {
                    fVar15 = *(float *)(arg4 + 0x14);
                    fVar16 = (float)func_0x000180490aa0((float)*(double *)(arg3 + 8) / fVar15);
                    if ((fVar16 == 0.0) || (puVar12 = auStack_b8, fVar15 != 0.0)) {
                        *(undefined4 *)arg1 = 5;
                        uVar17 = func_0x000180490aa0((float)*(double *)(arg3 + 8) / *(float *)(arg4 + 8));
                        *(undefined4 *)(arg1 + 8) = uVar17;
                        uVar17 = func_0x000180490aa0((float)*(double *)(arg3 + 8) / *(float *)(arg4 + 0xc));
                        *(undefined4 *)(arg1 + 0xc) = uVar17;
                        uVar17 = func_0x000180490aa0((float)*(double *)(arg3 + 8) / *(float *)(arg4 + 0x10));
                        *(undefined4 *)(arg1 + 0x10) = uVar17;
                        *(float *)(arg1 + 0x14) = fVar16;
                        puVar12 = auStack_b8;
                    }
                }
                break;
            }
        } else {
            if (iVar10 != 5) goto code_r0x0001800c2ea5;
            if (*(int32_t *)arg4 == 5) {
                if ((*(float *)(arg3 + 0x14) == 0.0) && (*(float *)(arg4 + 0x14) == 0.0)) {
                    bVar6 = false;
                } else {
                    bVar6 = true;
                }
                fVar15 = (float)func_0x000180490aa0(*(float *)(arg3 + 0x14) / *(float *)(arg4 + 0x14));
                if ((fVar15 == 0.0) || (puVar12 = auStack_b8, bVar6)) {
                    *(undefined4 *)arg1 = 5;
                    uVar17 = func_0x000180490aa0(*(float *)(arg3 + 8) / *(float *)(arg4 + 8));
                    *(undefined4 *)(arg1 + 8) = uVar17;
                    uVar17 = func_0x000180490aa0(*(float *)(arg3 + 0xc) / *(float *)(arg4 + 0xc));
                    *(undefined4 *)(arg1 + 0xc) = uVar17;
                    uVar17 = func_0x000180490aa0(*(float *)(arg3 + 0x10) / *(float *)(arg4 + 0x10));
                    *(undefined4 *)(arg1 + 0x10) = uVar17;
                    *(float *)(arg1 + 0x14) = fVar15;
                    puVar12 = auStack_b8;
                }
                break;
            }
        }
        puVar12 = auStack_b8;
        if ((iVar10 == 5) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            fVar15 = *(float *)(arg3 + 0x14);
            fVar16 = (float)func_0x000180490aa0(fVar15 / (float)*(double *)(arg4 + 8));
            if ((fVar16 == 0.0) || (puVar12 = auStack_b8, fVar15 != 0.0)) {
                *(undefined4 *)arg1 = 5;
                uVar17 = func_0x000180490aa0(*(float *)(arg3 + 8) / (float)*(double *)(arg4 + 8));
                *(undefined4 *)(arg1 + 8) = uVar17;
                uVar17 = func_0x000180490aa0(*(float *)(arg3 + 0xc) / (float)*(double *)(arg4 + 8));
                *(undefined4 *)(arg1 + 0xc) = uVar17;
                uVar17 = func_0x000180490aa0(*(float *)(arg3 + 0x10) / (float)*(double *)(arg4 + 8));
                *(undefined4 *)(arg1 + 0x10) = uVar17;
                uVar17 = func_0x000180490aa0(*(float *)(arg3 + 0x14) / (float)*(double *)(arg4 + 8));
                *(undefined4 *)(arg1 + 0x14) = uVar17;
                puVar12 = auStack_b8;
            }
        }
        break;
    case 5:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 == 3) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            *(undefined4 *)arg1 = 3;
            dVar1 = *(double *)(arg3 + 8);
            dVar3 = (double)func_0x0001804909e0(SUB84(dVar1 / *(double *)(arg4 + 8), 0));
            *(double *)(arg1 + 8) = dVar1 - dVar3 * *(double *)(arg4 + 8);
            puVar12 = auStack_b8;
        }
        break;
    case 6:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 == 3) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            *(undefined4 *)arg1 = 3;
            uVar18 = func_0x000180491d70((int32_t)*(undefined8 *)(arg3 + 8), *(undefined8 *)(arg4 + 8));
            *(undefined8 *)(arg1 + 8) = uVar18;
            puVar12 = auStack_b8;
        }
        break;
    case 7:
        puVar12 = auStack_b8;
        if (((*(int32_t *)arg3 == 6) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 6)) &&
           (puVar12 = auStack_b8, (uint32_t)(*(int32_t *)(arg3 + 4) + *(int32_t *)(arg4 + 4)) < 0x1001)) {
            *(undefined4 *)arg1 = 6;
            iVar10 = *(int32_t *)(arg4 + 4) + *(int32_t *)(arg3 + 4);
            *(int32_t *)(arg1 + 4) = iVar10;
            if (*(int32_t *)(arg3 + 4) == 0) {
                *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg4 + 8);
                puVar12 = auStack_b8;
            } else if (*(int32_t *)(arg4 + 4) == 0) {
                *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg3 + 8);
                puVar12 = auStack_b8;
            } else {
                iStack_68 = 0;
                uStack_60 = 0xf;
                auStack_78._1_15_ = SUB1615(ZEXT816(0), 1);
                auVar7[15] = 0;
                auVar7._0_15_ = auStack_78._1_15_;
                auStack_78 = auVar7 << 8;
                func_0x00018000b240(auStack_78, iVar10 + 1);
                uVar14 = (uint64_t)*(uint32_t *)(arg3 + 4);
                if (uStack_60 - iStack_68 < uVar14) {
                    var_98h = uVar14;
                    func_0x00018000ee80(auStack_78, uVar14, uStack_88);
                } else {
                    puVar12 = auStack_78;
                    if (0xf < uStack_60) {
                        puVar12 = (undefined *)auStack_78._0_8_;
                    }
                    puVar12 = puVar12 + iStack_68;
                    iStack_68 = iStack_68 + uVar14;
                    fcn.180498030(puVar12, *(undefined8 *)(arg3 + 8), uVar14);
                    puVar12[uVar14] = 0;
                }
                uVar14 = (uint64_t)*(uint32_t *)(arg4 + 4);
                if (uStack_60 - iStack_68 < uVar14) {
                    var_98h = uVar14;
                    func_0x00018000ee80(auStack_78, uVar14, uStack_88);
                } else {
                    puVar12 = auStack_78;
                    if (0xf < uStack_60) {
                        puVar12 = (undefined *)auStack_78._0_8_;
                    }
                    puVar12 = puVar12 + iStack_68;
                    iStack_68 = iStack_68 + uVar14;
                    fcn.180498030(puVar12, *(undefined8 *)(arg4 + 8), uVar14);
                    puVar12[uVar14] = 0;
                }
                puVar13 = auStack_b8;
                puVar12 = auStack_78;
                if (0xf < uStack_60) {
                    puVar12 = (undefined *)auStack_78._0_8_;
                }
                func_0x0001800d6f20(in_stack_00000028, &uStack_80, puVar12, *(undefined4 *)(arg1 + 4));
                *(undefined8 *)(arg1 + 8) = uStack_80;
                puVar12 = auStack_b8;
                if (0xf < uStack_60) {
                    iVar11 = auStack_78._0_8_;
                    if (0xfff < uStack_60 + 1) {
                        if ((auStack_78._0_8_ - *(int64_t *)(auStack_78._0_8_ + -8)) - 8U < 0x20) {
                            fcn.180459c3c(*(int64_t *)(auStack_78._0_8_ + -8), uStack_60 + 0x28);
                            puVar12 = auStack_b8;
                            break;
                        }
                        pcVar2 = (code *)swi(0x29);
                        iVar11 = (*pcVar2)(5);
                        puVar13 = auStack_b0;
                    }
                    *(undefined8 *)(puVar13 + -8) = 0x1800c3242;
                    fcn.180459c3c(iVar11);
                    puVar12 = puVar13;
                }
            }
        }
        break;
    case 8:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 != 0) && (puVar12 = auStack_b8, *(int32_t *)arg4 != 0)) {
            *(undefined4 *)arg1 = 2;
            uVar8 = fcn.1800c2750(arg3, arg4);
            *(uint8_t *)(arg1 + 8) = uVar8 ^ 1;
            puVar12 = auStack_b8;
        }
        break;
    case 9:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 != 0) && (puVar12 = auStack_b8, *(int32_t *)arg4 != 0)) {
            *(undefined4 *)arg1 = 2;
            uVar9 = fcn.1800c2750(arg3, arg4);
            *(undefined *)(arg1 + 8) = uVar9;
            puVar12 = auStack_b8;
        }
        break;
    case 10:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 == 3) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            *(undefined4 *)arg1 = 2;
            *(bool *)(arg1 + 8) =
                 *(double *)(arg3 + 8) <= *(double *)(arg4 + 8) && *(double *)(arg4 + 8) != *(double *)(arg3 + 8);
            puVar12 = auStack_b8;
        }
        break;
    case 0xb:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 == 3) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            *(undefined4 *)arg1 = 2;
            *(bool *)(arg1 + 8) = *(double *)(arg3 + 8) <= *(double *)(arg4 + 8);
            puVar12 = auStack_b8;
        }
        break;
    case 0xc:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 == 3) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            *(undefined4 *)arg1 = 2;
            *(bool *)(arg1 + 8) =
                 *(double *)(arg4 + 8) <= *(double *)(arg3 + 8) && *(double *)(arg3 + 8) != *(double *)(arg4 + 8);
            puVar12 = auStack_b8;
        }
        break;
    case 0xd:
        puVar12 = auStack_b8;
        if ((*(int32_t *)arg3 == 3) && (puVar12 = auStack_b8, *(int32_t *)arg4 == 3)) {
            *(undefined4 *)arg1 = 2;
            *(bool *)(arg1 + 8) = *(double *)(arg4 + 8) <= *(double *)(arg3 + 8);
            puVar12 = auStack_b8;
        }
        break;
    case 0xe:
        iVar10 = *(int32_t *)arg3;
        puVar12 = auStack_b8;
        if (iVar10 == 0) break;
        if ((iVar10 == 1) || ((iVar10 == 2 && (*(char *)(arg3 + 8) == '\0')))) {
            bVar6 = false;
        } else {
            bVar6 = true;
        }
        if (bVar6) {
            arg3 = arg4;
        }
        uVar17 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg3;
        *(undefined4 *)(arg1 + 4) = uVar17;
        *(undefined4 *)(arg1 + 8) = uVar4;
        *(undefined4 *)(arg1 + 0xc) = uVar5;
        uVar18 = *(undefined8 *)(arg3 + 0x10);
        goto code_r0x0001800c33c0;
    case 0xf:
        iVar10 = *(int32_t *)arg3;
        puVar12 = auStack_b8;
        if (iVar10 == 0) break;
        if ((iVar10 == 1) || ((iVar10 == 2 && (*(char *)(arg3 + 8) == '\0')))) {
            bVar6 = false;
        } else {
            bVar6 = true;
        }
        if (bVar6) {
            arg4 = arg3;
        }
        uVar17 = *(undefined4 *)(arg4 + 4);
        uVar4 = *(undefined4 *)(arg4 + 8);
        uVar5 = *(undefined4 *)(arg4 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg4;
        *(undefined4 *)(arg1 + 4) = uVar17;
        *(undefined4 *)(arg1 + 8) = uVar4;
        *(undefined4 *)(arg1 + 0xc) = uVar5;
        uVar18 = *(undefined8 *)(arg4 + 0x10);
code_r0x0001800c33c0:
        *(undefined8 *)(arg1 + 0x10) = uVar18;
        puVar12 = auStack_b8;
    }
    *(undefined8 *)(puVar12 + -8) = 0x1800c33d1;
    func_0x000180459870(uStack_58 ^ (uint64_t)puVar12);
    return;
}

// ============================================================
// Function: FUN_1800c3440
// Address: 0x1800c3440
// Size: 763 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1800c3440(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int32_t iVar2;
    char cVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    while( true ) {
        while( true ) {
            iVar2 = *(int32_t *)(arg2 + 8);
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar5 = arg2;
            }
            if (iVar5 == 0) break;
            arg2 = *(int64_t *)(iVar5 + 0x20);
        }
        if (iVar2 == *(int32_t *)0x180782670) {
            return true;
        }
        if (iVar2 == *(int32_t *)0x1807826cc) {
            return true;
        }
        if (iVar2 == *(int32_t *)0x1807826b4) {
            return true;
        }
        if (iVar2 == *(int32_t *)0x18078271c) {
            return true;
        }
        if (iVar2 == *(int32_t *)0x18078273c) {
            return true;
        }
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x180782728) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 8), iVar5 + 0x20);
            piVar6 = (int32_t *)(iVar5 + 8);
            if (iVar5 == 0) {
                piVar6 = (int32_t *)0x0;
            }
            if (piVar6 == (int32_t *)0x0) {
                return false;
            }
            return *piVar6 == 1;
        }
        if (iVar2 == *(int32_t *)0x180782738) {
            return false;
        }
        if (iVar2 == *(int32_t *)0x1807826b8) {
            return false;
        }
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x180782740) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            return false;
        }
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x18078269c) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            iVar4 = 0;
            if (*(int32_t *)(*(int64_t *)(iVar5 + 0x20) + 8) == *(int32_t *)0x180782728) {
                iVar4 = *(int64_t *)(iVar5 + 0x20);
            }
            if (iVar4 == 0) {
                return false;
            }
            iVar5 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 8), iVar4 + 0x20);
            piVar6 = (int32_t *)(iVar5 + 8);
            if (iVar5 == 0) {
                piVar6 = (int32_t *)0x0;
            }
            if (piVar6 == (int32_t *)0x0) {
                return false;
            }
            return *piVar6 == 0;
        }
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x180782730) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) break;
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x1807826a0) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            return false;
        }
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x180782758) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            return false;
        }
        iVar5 = 0;
        if (iVar2 == *(int32_t *)0x180782768) {
            iVar5 = arg2;
        }
        if (iVar5 == 0) {
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x180782668) {
                iVar5 = arg2;
            }
            if (iVar5 != 0) {
                cVar3 = fcn.1800c3440(arg1, *(int64_t *)(iVar5 + 0x28));
                if (cVar3 == '\0') {
                    return false;
                }
                iVar5 = *(int64_t *)(iVar5 + 0x30);
                goto code_r0x0001800c366b;
            }
            iVar5 = 0;
            if (iVar2 == *(int32_t *)0x180782708) {
                iVar5 = arg2;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x18078270c) {
                    iVar5 = arg2;
                }
                if (iVar5 != 0) {
                    cVar3 = fcn.1800c3440(arg1, *(int64_t *)(iVar5 + 0x20));
                    if (cVar3 == '\0') {
                        return false;
                    }
                    cVar3 = fcn.1800c3440(arg1, *(int64_t *)(iVar5 + 0x30));
                    if (cVar3 == '\0') {
                        return false;
                    }
                    iVar5 = *(int64_t *)(iVar5 + 0x40);
                    goto code_r0x0001800c366b;
                }
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x18078275c) {
                    iVar5 = arg2;
                }
                if (iVar5 != 0) {
                    piVar7 = *(int64_t **)(iVar5 + 0x30);
                    piVar1 = piVar7 + *(int64_t *)(iVar5 + 0x38);
                    while( true ) {
                        if (piVar7 == piVar1) {
                            return true;
                        }
                        cVar3 = fcn.1800c3440(arg1, *piVar7);
                        if (cVar3 == '\0') break;
                        piVar7 = piVar7 + 1;
                    }
                    return false;
                }
                iVar5 = 0;
                if (iVar2 == *(int32_t *)0x180782674) {
                    iVar5 = arg2;
                }
                if (iVar5 == 0) {
                    return false;
                }
                arg2 = *(int64_t *)(iVar5 + 0x20);
            } else {
                arg2 = *(int64_t *)(iVar5 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar5 + 0x28);
        }
    }
    iVar4 = 0;
    if (*(int32_t *)(*(int64_t *)(iVar5 + 0x20) + 8) == *(int32_t *)0x180782728) {
        iVar4 = *(int64_t *)(iVar5 + 0x20);
    }
    if (iVar4 == 0) {
        return false;
    }
    iVar4 = func_0x0001800ac7f0(*(undefined8 *)(arg1 + 8), iVar4 + 0x20);
    piVar6 = (int32_t *)(iVar4 + 8);
    if (iVar4 == 0) {
        piVar6 = (int32_t *)0x0;
    }
    if (piVar6 == (int32_t *)0x0) {
        return false;
    }
    if (*piVar6 != 0) {
        return false;
    }
    iVar5 = *(int64_t *)(iVar5 + 0x28);
code_r0x0001800c366b:
    cVar3 = fcn.1800c3440(arg1, iVar5);
    if (cVar3 == '\0') {
        return false;
    }
    return true;
}

// ============================================================
// Function: FUN_1800c3740
// Address: 0x1800c3740
// Size: 227 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1800c3740(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    char cVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782758) {
        iVar3 = arg2;
    }
    do {
        if (iVar3 != 0) {
            iVar4 = *(int64_t *)(iVar3 + 0x20);
            iVar3 = iVar4 + *(int64_t *)(iVar3 + 0x28) * 0x18;
            while( true ) {
                if (iVar4 == iVar3) {
                    return 1;
                }
                if (((*(int64_t *)(iVar4 + 8) != 0) &&
                    (cVar2 = fcn.1800c3440(arg1, *(int64_t *)(iVar4 + 8)), cVar2 == '\0')) ||
                   (cVar2 = fcn.1800c3440(arg1, *(int64_t *)(iVar4 + 0x10)), cVar2 == '\0')) break;
                iVar4 = iVar4 + 0x18;
            }
            return 0;
        }
        iVar1 = *(int32_t *)(arg2 + 8);
        iVar3 = 0;
        if (iVar1 == *(int32_t *)0x1807826c0) {
            iVar3 = arg2;
        }
        if (iVar3 == 0) {
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar3 = arg2;
            }
            if (iVar3 == 0) {
                if (iVar1 == *(int32_t *)0x180782674) {
                    iVar3 = arg2;
                }
                if (iVar3 == 0) {
                    return 0;
                }
            }
        }
        arg2 = *(int64_t *)(iVar3 + 0x20);
        iVar3 = 0;
        if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782758) {
            iVar3 = arg2;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1800c3830
// Address: 0x1800c3830
// Size: 252 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1800c3830(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    char cVar2;
    int64_t iVar3;
    int64_t var_8h;
    
    while( true ) {
        while( true ) {
            while( true ) {
                iVar1 = *(int32_t *)(arg2 + 8);
                iVar3 = 0;
                if (iVar1 == *(int32_t *)0x1807826c0) {
                    iVar3 = arg2;
                }
                if (iVar3 == 0) break;
                arg2 = *(int64_t *)(iVar3 + 0x20);
            }
            iVar3 = 0;
            if (iVar1 == *(int32_t *)0x180782708) {
                iVar3 = arg2;
            }
            if (iVar3 == 0) break;
            arg2 = *(int64_t *)(iVar3 + 0x20);
        }
        iVar3 = 0;
        if (iVar1 == *(int32_t *)0x180782674) {
            iVar3 = arg2;
        }
        if (iVar3 == 0) break;
        arg2 = *(int64_t *)(iVar3 + 0x20);
    }
    iVar3 = 0;
    if (iVar1 == *(int32_t *)0x18078270c) {
        iVar3 = arg2;
    }
    if (iVar3 == 0) {
        iVar3 = 0;
        if (iVar1 == *(int32_t *)0x180782668) {
            iVar3 = arg2;
        }
        if ((iVar3 == 0) || (1 < *(int32_t *)(iVar3 + 0x20) - 0xeU)) {
            return iVar1 == *(int32_t *)0x180782728;
        }
        cVar2 = fcn.1800c3830(arg1, *(int64_t *)(iVar3 + 0x28));
        if (cVar2 != '\0') {
            return true;
        }
        iVar3 = *(int64_t *)(iVar3 + 0x30);
    } else {
        cVar2 = fcn.1800c3830(arg1, *(int64_t *)(iVar3 + 0x30));
        if (cVar2 != '\0') {
            return true;
        }
        iVar3 = *(int64_t *)(iVar3 + 0x40);
    }
    cVar2 = fcn.1800c3830(arg1, iVar3);
    if (cVar2 != '\0') {
        return true;
    }
    return false;
}

// ============================================================
// Function: FUN_1800c3930
// Address: 0x1800c3930
// Size: 952 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800c3930(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    char in_R8B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    while( true ) {
        while( true ) {
            iVar1 = *(int32_t *)(arg2 + 8);
            iVar5 = 0;
            if (iVar1 == *(int32_t *)0x1807826c0) {
                iVar5 = arg2;
            }
            if (iVar5 == 0) break;
            arg2 = *(int64_t *)(iVar5 + 0x20);
        }
        if (iVar1 == *(int32_t *)0x180782670) {
            return;
        }
        if (iVar1 == *(int32_t *)0x1807826cc) {
            return;
        }
        if (iVar1 == *(int32_t *)0x1807826b4) {
            return;
        }
        if (iVar1 == *(int32_t *)0x18078271c) {
            return;
        }
        if (iVar1 == *(int32_t *)0x18078273c) {
            return;
        }
        iVar5 = 0;
        if (iVar1 == *(int32_t *)0x180782728) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            var_10h = *(uint64_t *)(iVar5 + 0x20);
            if (((in_R8B != '\0') && (piVar2 = *(int64_t **)(arg1 + 8), piVar2[2] != 0)) && (var_10h != piVar2[3])) {
                uVar7 = ((uint64_t)var_10h >> 5 ^ var_10h) >> 4;
                uVar6 = 0;
                while( true ) {
                    uVar7 = uVar7 & piVar2[1] - 1U;
                    uVar3 = *(uint64_t *)(*piVar2 + uVar7 * 0x10);
                    if (uVar3 == var_10h) {
                        puVar4 = (undefined4 *)func_0x0001800ac540(piVar2, &var_10h);
                        *puVar4 = 2;
                        return;
                    }
                    if (uVar3 == piVar2[3]) break;
                    uVar7 = uVar7 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                    if (piVar2[1] - 1U < uVar6) {
                        return;
                    }
                }
                return;
            }
            return;
        }
        if (iVar1 == *(int32_t *)0x180782738) {
            return;
        }
        if (iVar1 == *(int32_t *)0x1807826b8) break;
        iVar5 = 0;
        if (iVar1 == *(int32_t *)0x180782740) {
            iVar5 = arg2;
        }
        if (iVar5 != 0) {
            fcn.1800c3930(arg1, *(int64_t *)(iVar5 + 0x20));
            uVar7 = 0;
            if (*(int64_t *)(iVar5 + 0x40) == 0) {
                return;
            }
            do {
                iVar9 = *(int64_t *)(*(int64_t *)(iVar5 + 0x38) + uVar7 * 8);
                fcn.1800c3830(arg1, iVar9);
                fcn.1800c3930(arg1, iVar9);
                uVar7 = uVar7 + 1;
            } while (uVar7 < *(uint64_t *)(iVar5 + 0x40));
            return;
        }
        iVar5 = 0;
        if (iVar1 == *(int32_t *)0x18078269c) {
            iVar5 = arg2;
        }
        if (iVar5 == 0) {
            iVar5 = 0;
            if (iVar1 == *(int32_t *)0x180782730) {
                iVar5 = arg2;
            }
            if (iVar5 == 0) {
                iVar5 = 0;
                if (iVar1 == *(int32_t *)0x1807826a0) {
                    iVar5 = arg2;
                }
                if (iVar5 != 0) {
    // WARNING: Could not recover jumptable at 0x0001800c3be5. Too many branches
    // WARNING: Treating indirect jump as call
                    (**(code **)**(undefined8 **)(iVar5 + 0x90))(*(undefined8 **)(iVar5 + 0x90), arg1);
                    return;
                }
                iVar5 = 0;
                if (iVar1 == *(int32_t *)0x180782758) {
                    iVar5 = arg2;
                }
                if (iVar5 != 0) {
                    iVar9 = *(int64_t *)(iVar5 + 0x20);
                    iVar5 = iVar9 + *(int64_t *)(iVar5 + 0x28) * 0x18;
                    if (iVar9 == iVar5) {
                        return;
                    }
                    do {
                        if (*(int64_t *)(iVar9 + 8) != 0) {
                            fcn.1800c3930(arg1, *(int64_t *)(iVar9 + 8));
                        }
                        fcn.1800c3830(arg1, *(int64_t *)(iVar9 + 0x10));
                        fcn.1800c3930(arg1, *(int64_t *)(iVar9 + 0x10));
                        iVar9 = iVar9 + 0x18;
                    } while (iVar9 != iVar5);
                    return;
                }
                iVar5 = 0;
                if (iVar1 == *(int32_t *)0x180782768) {
                    iVar5 = arg2;
                }
                if (iVar5 == 0) {
                    iVar5 = 0;
                    if (iVar1 == *(int32_t *)0x180782668) {
                        iVar5 = arg2;
                    }
                    if (iVar5 == 0) {
                        iVar5 = 0;
                        if (iVar1 == *(int32_t *)0x180782708) {
                            iVar5 = arg2;
                        }
                        if (iVar5 == 0) {
                            iVar5 = 0;
                            if (iVar1 == *(int32_t *)0x18078270c) {
                                iVar5 = arg2;
                            }
                            if (iVar5 == 0) {
                                iVar5 = 0;
                                if (iVar1 == *(int32_t *)0x18078275c) {
                                    iVar5 = arg2;
                                }
                                if (iVar5 != 0) {
                                    piVar8 = *(int64_t **)(iVar5 + 0x30);
                                    piVar2 = piVar8 + *(int64_t *)(iVar5 + 0x38);
                                    if (piVar8 == piVar2) {
                                        return;
                                    }
                                    do {
                                        fcn.1800c3930(arg1, *piVar8);
                                        piVar8 = piVar8 + 1;
                                    } while (piVar8 != piVar2);
                                    return;
                                }
                                iVar5 = 0;
                                if (iVar1 == *(int32_t *)0x180782674) {
                                    iVar5 = arg2;
                                }
                                if (iVar5 == 0) {
                                    return;
                                }
                                arg2 = *(int64_t *)(iVar5 + 0x20);
                            } else {
                                fcn.1800c3930(arg1, *(int64_t *)(iVar5 + 0x20));
                                fcn.1800c3930(arg1, *(int64_t *)(iVar5 + 0x30));
                                arg2 = *(int64_t *)(iVar5 + 0x40);
                            }
                        } else {
                            arg2 = *(int64_t *)(iVar5 + 0x20);
                        }
                    } else {
                        in_R8B = *(int32_t *)(iVar5 + 0x20) - 0xeU < 2;
                        fcn.1800c3930(arg1, *(int64_t *)(iVar5 + 0x28));
                        arg2 = *(int64_t *)(iVar5 + 0x30);
                    }
                } else {
                    arg2 = *(int64_t *)(iVar5 + 0x28);
                    in_R8B = '\0';
                }
            } else {
                fcn.1800c3930(arg1, *(int64_t *)(iVar5 + 0x28));
                arg2 = *(int64_t *)(iVar5 + 0x20);
            }
        } else {
            arg2 = *(int64_t *)(iVar5 + 0x20);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800c3cf0
// Address: 0x1800c3cf0
// Size: 19 bytes
// ============================================================
undefined fcn.1800c3cf0(int64_t arg1, int64_t arg2)
{
    fcn.1800c3930(arg1, arg2);
    return 0;
}

// ============================================================
// Function: FUN_1800c3d10
// Address: 0x1800c3d10
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800c3d10(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int32_t iVar2;
    int64_t arg2_00;
    int64_t *piVar3;
    uint64_t uVar4;
    char cVar5;
    char *pcVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar11 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = (uint64_t *)(arg2 + 0x40);
    if (uVar11 != 0) {
        uVar13 = 0;
        do {
            if (*puVar1 <= uVar13) break;
            uVar11 = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar13 * 8);
            arg2_00 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar13 * 8);
            piVar3 = *(int64_t **)(arg1 + 0x10);
            if ((piVar3[2] != 0) && (uVar11 != piVar3[3])) {
                uVar9 = (uVar11 >> 5 ^ uVar11) >> 4;
                uVar12 = 0;
                do {
                    uVar9 = uVar9 & piVar3[1] - 1U;
                    iVar8 = *piVar3 + uVar9 * 0x18;
                    uVar4 = *(uint64_t *)(*piVar3 + uVar9 * 0x18);
                    if (uVar4 == uVar11) goto code_r0x0001800c3dd9;
                    if (uVar4 == piVar3[3]) break;
                    uVar9 = uVar9 + 1 + uVar12;
                    uVar12 = uVar12 + 1;
                } while (uVar12 <= piVar3[1] - 1U);
            }
            iVar8 = 0;
code_r0x0001800c3dd9:
            pcVar6 = (char *)(iVar8 + 0x10);
            if (iVar8 == 0) {
                pcVar6 = (char *)0x8;
            }
            if (*pcVar6 == '\0') {
                iVar2 = *(int32_t *)(arg2_00 + 8);
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782758) {
                    iVar8 = arg2_00;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x1807826c0) {
                        iVar8 = arg2_00;
                    }
                    if (iVar8 == 0) {
                        if (iVar2 == *(int32_t *)0x180782708) {
                            iVar8 = arg2_00;
                        }
                        if (iVar8 != 0) goto code_r0x0001800c3e95;
                        if (iVar2 == *(int32_t *)0x180782674) {
                            iVar8 = arg2_00;
                        }
                        if (iVar8 != 0) goto code_r0x0001800c3e95;
                    } else {
code_r0x0001800c3e95:
                        cVar5 = fcn.1800c3740(arg1, *(int64_t *)(iVar8 + 0x20));
                        if (cVar5 != '\0') goto code_r0x0001800c3e52;
                    }
code_r0x0001800c3eab:
                    cVar5 = fcn.1800c3440(arg1, arg2_00);
                    if (cVar5 != '\0') {
                        puVar7 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8));
                        *puVar7 = 1;
                    }
                } else {
                    iVar10 = *(int64_t *)(iVar8 + 0x20);
                    iVar8 = iVar10 + *(int64_t *)(iVar8 + 0x28) * 0x18;
                    for (; iVar10 != iVar8; iVar10 = iVar10 + 0x18) {
                        if (((*(int64_t *)(iVar10 + 8) != 0) &&
                            (cVar5 = fcn.1800c3440(arg1, *(int64_t *)(iVar10 + 8)), cVar5 == '\0')) ||
                           (cVar5 = fcn.1800c3440(arg1, *(int64_t *)(iVar10 + 0x10)), cVar5 == '\0'))
                        goto code_r0x0001800c3eab;
                    }
code_r0x0001800c3e52:
                    puVar7 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8));
                    *puVar7 = 0;
                }
            }
            piVar3 = *(int64_t **)(arg1 + 8);
            if ((piVar3[2] != 0) && (uVar11 != piVar3[3])) {
                uVar9 = (uVar11 >> 5 ^ uVar11) >> 4;
                uVar12 = 0;
                do {
                    uVar9 = uVar9 & piVar3[1] - 1U;
                    uVar4 = *(uint64_t *)(*piVar3 + uVar9 * 0x10);
                    if (uVar4 == uVar11) goto code_r0x0001800c400b;
                    if (uVar4 == piVar3[3]) break;
                    uVar9 = uVar9 + 1 + uVar12;
                    uVar12 = uVar12 + 1;
                } while (uVar12 <= piVar3[1] - 1U);
            }
            iVar2 = *(int32_t *)(arg2_00 + 8);
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar8 = arg2_00;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar8 = arg2_00;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar8 = arg2_00;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar8 = arg2_00;
                        }
                        if (iVar8 == 0) {
                            iVar8 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar8 = arg2_00;
                            }
                            if (((iVar8 != 0) && (*(int32_t *)(iVar8 + 0x20) - 0xeU < 2)) &&
                               (cVar5 = fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x28)), cVar5 == '\0')) {
                                iVar8 = *(int64_t *)(iVar8 + 0x30);
                                goto code_r0x0001800c3fb2;
                            }
                        } else {
                            cVar5 = fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x30));
                            if (cVar5 == '\0') {
                                iVar8 = *(int64_t *)(iVar8 + 0x40);
code_r0x0001800c3fb2:
                                fcn.1800c3830(arg1, iVar8);
                            }
                        }
                    } else {
                        fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x20));
                    }
                } else {
                    fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x20));
                }
            } else {
                fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x20));
            }
            fcn.1800c3930(arg1, arg2_00);
code_r0x0001800c400b:
            uVar11 = *(uint64_t *)(arg2 + 0x30);
            uVar13 = uVar13 + 1;
        } while (uVar13 < uVar11);
    }
    if (uVar11 < *puVar1) {
        do {
            fcn.1800c3930(arg1, *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar11 * 8));
            uVar11 = uVar11 + 1;
        } while (uVar11 < *puVar1);
    }
    return arg2 + 0x38U & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800c3d21
// Address: 0x1800c3d21
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

uint64_t fcn.1800c3d10(int64_t arg1, int64_t arg2)
{
    uint64_t *puVar1;
    int32_t iVar2;
    int64_t arg2_00;
    int64_t *piVar3;
    uint64_t uVar4;
    char cVar5;
    char *pcVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    uVar11 = *(uint64_t *)(arg2 + 0x30);
    puVar1 = (uint64_t *)(arg2 + 0x40);
    if (uVar11 != 0) {
        uVar13 = 0;
        do {
            if (*puVar1 <= uVar13) break;
            uVar11 = *(uint64_t *)(*(int64_t *)(arg2 + 0x28) + uVar13 * 8);
            arg2_00 = *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar13 * 8);
            piVar3 = *(int64_t **)(arg1 + 0x10);
            if ((piVar3[2] != 0) && (uVar11 != piVar3[3])) {
                uVar9 = (uVar11 >> 5 ^ uVar11) >> 4;
                uVar12 = 0;
                do {
                    uVar9 = uVar9 & piVar3[1] - 1U;
                    iVar8 = *piVar3 + uVar9 * 0x18;
                    uVar4 = *(uint64_t *)(*piVar3 + uVar9 * 0x18);
                    if (uVar4 == uVar11) goto code_r0x0001800c3dd9;
                    if (uVar4 == piVar3[3]) break;
                    uVar9 = uVar9 + 1 + uVar12;
                    uVar12 = uVar12 + 1;
                } while (uVar12 <= piVar3[1] - 1U);
            }
            iVar8 = 0;
code_r0x0001800c3dd9:
            pcVar6 = (char *)(iVar8 + 0x10);
            if (iVar8 == 0) {
                pcVar6 = (char *)0x8;
            }
            if (*pcVar6 == '\0') {
                iVar2 = *(int32_t *)(arg2_00 + 8);
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782758) {
                    iVar8 = arg2_00;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x1807826c0) {
                        iVar8 = arg2_00;
                    }
                    if (iVar8 == 0) {
                        if (iVar2 == *(int32_t *)0x180782708) {
                            iVar8 = arg2_00;
                        }
                        if (iVar8 != 0) goto code_r0x0001800c3e95;
                        if (iVar2 == *(int32_t *)0x180782674) {
                            iVar8 = arg2_00;
                        }
                        if (iVar8 != 0) goto code_r0x0001800c3e95;
                    } else {
code_r0x0001800c3e95:
                        cVar5 = fcn.1800c3740(arg1, *(int64_t *)(iVar8 + 0x20));
                        if (cVar5 != '\0') goto code_r0x0001800c3e52;
                    }
code_r0x0001800c3eab:
                    cVar5 = fcn.1800c3440(arg1, arg2_00);
                    if (cVar5 != '\0') {
                        puVar7 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8));
                        *puVar7 = 1;
                    }
                } else {
                    iVar10 = *(int64_t *)(iVar8 + 0x20);
                    iVar8 = iVar10 + *(int64_t *)(iVar8 + 0x28) * 0x18;
                    for (; iVar10 != iVar8; iVar10 = iVar10 + 0x18) {
                        if (((*(int64_t *)(iVar10 + 8) != 0) &&
                            (cVar5 = fcn.1800c3440(arg1, *(int64_t *)(iVar10 + 8)), cVar5 == '\0')) ||
                           (cVar5 = fcn.1800c3440(arg1, *(int64_t *)(iVar10 + 0x10)), cVar5 == '\0'))
                        goto code_r0x0001800c3eab;
                    }
code_r0x0001800c3e52:
                    puVar7 = (undefined4 *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8));
                    *puVar7 = 0;
                }
            }
            piVar3 = *(int64_t **)(arg1 + 8);
            if ((piVar3[2] != 0) && (uVar11 != piVar3[3])) {
                uVar9 = (uVar11 >> 5 ^ uVar11) >> 4;
                uVar12 = 0;
                do {
                    uVar9 = uVar9 & piVar3[1] - 1U;
                    uVar4 = *(uint64_t *)(*piVar3 + uVar9 * 0x10);
                    if (uVar4 == uVar11) goto code_r0x0001800c400b;
                    if (uVar4 == piVar3[3]) break;
                    uVar9 = uVar9 + 1 + uVar12;
                    uVar12 = uVar12 + 1;
                } while (uVar12 <= piVar3[1] - 1U);
            }
            iVar2 = *(int32_t *)(arg2_00 + 8);
            iVar8 = 0;
            if (iVar2 == *(int32_t *)0x1807826c0) {
                iVar8 = arg2_00;
            }
            if (iVar8 == 0) {
                iVar8 = 0;
                if (iVar2 == *(int32_t *)0x180782708) {
                    iVar8 = arg2_00;
                }
                if (iVar8 == 0) {
                    iVar8 = 0;
                    if (iVar2 == *(int32_t *)0x180782674) {
                        iVar8 = arg2_00;
                    }
                    if (iVar8 == 0) {
                        iVar8 = 0;
                        if (iVar2 == *(int32_t *)0x18078270c) {
                            iVar8 = arg2_00;
                        }
                        if (iVar8 == 0) {
                            iVar8 = 0;
                            if (iVar2 == *(int32_t *)0x180782668) {
                                iVar8 = arg2_00;
                            }
                            if (((iVar8 != 0) && (*(int32_t *)(iVar8 + 0x20) - 0xeU < 2)) &&
                               (cVar5 = fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x28)), cVar5 == '\0')) {
                                iVar8 = *(int64_t *)(iVar8 + 0x30);
                                goto code_r0x0001800c3fb2;
                            }
                        } else {
                            cVar5 = fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x30));
                            if (cVar5 == '\0') {
                                iVar8 = *(int64_t *)(iVar8 + 0x40);
code_r0x0001800c3fb2:
                                fcn.1800c3830(arg1, iVar8);
                            }
                        }
                    } else {
                        fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x20));
                    }
                } else {
                    fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x20));
                }
            } else {
                fcn.1800c3830(arg1, *(int64_t *)(iVar8 + 0x20));
            }
            fcn.1800c3930(arg1, arg2_00);
code_r0x0001800c400b:
            uVar11 = *(uint64_t *)(arg2 + 0x30);
            uVar13 = uVar13 + 1;
        } while (uVar13 < uVar11);
    }
    if (uVar11 < *puVar1) {
        do {
            fcn.1800c3930(arg1, *(int64_t *)(*(int64_t *)(arg2 + 0x38) + uVar11 * 8));
            uVar11 = uVar11 + 1;
        } while (uVar11 < *puVar1);
    }
    return arg2 + 0x38U & 0xffffffffffffff00;
}

