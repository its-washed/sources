// Chunk 152 - 50 functions

// ============================================================
// Function: FUN_180201630
// Address: 0x180201630
// Size: 446 bytes
// ============================================================
void fcn.180201630(int64_t arg_28h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180201642;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_28h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar2);
    iVar4 = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180201672;
    iVar1 = func_0x00018021be60();
    if (iVar1 == 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180201692;
        piVar3 = (int64_t *)func_0x000180224d60(0x20, 0x1804b9908, 0x77);
        if (piVar3 == (int64_t *)0x0) goto code_r0x0001802017d1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802016b0;
        iVar4 = func_0x0001802119f0(in_RCX, 0x1804b88d0, in_RDX);
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802016c1;
            iVar5 = func_0x000180211490();
            *piVar3 = iVar5;
            if (iVar5 != 0) {
                *(undefined8 *)((int64_t)&var_8h + iVar2) = 0;
                *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802016e9;
                iVar1 = func_0x0001802128f0(iVar5, iVar4, (int64_t)&var_18h + iVar2, 0);
                if (iVar1 != 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802016f9;
                    func_0x000180211a40(iVar4);
                    iVar4 = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18020170e;
                    uVar6 = func_0x000180229130(0x1802007d0, 0x1802007c0);
                    *(undefined8 *)((int64_t)&var_8h + iVar2) = 0x180195290;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180201737;
                    iVar5 = func_0x000180229290(uVar6, 0x1801952b0, 0x180195290, 0x1801952b0);
                    piVar3[1] = iVar5;
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180201753;
                        uVar6 = func_0x000180229130(0x180201180, 0x180201150);
                        *(undefined8 *)((int64_t)&var_8h + iVar2) = 0x180195290;
                        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x180201775;
                        iVar5 = func_0x000180229290(uVar6, 0x1801952b0, 0x180195290, 0x1801952b0);
                        piVar3[2] = iVar5;
                        if (iVar5 != 0) goto code_r0x0001802017d1;
                    }
                }
            }
        }
        iVar5 = piVar3[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x18020178c;
        func_0x000180228ec0(iVar5);
        iVar5 = piVar3[1];
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802017a1;
            func_0x000180228c50(iVar5, 0x180201970);
            iVar5 = piVar3[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802017aa;
            func_0x000180228ec0(iVar5);
        }
        iVar5 = *piVar3;
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802017b2;
        func_0x000180211410(iVar5);
        *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802017c7;
        func_0x000180224990(piVar3, 0x1804b9908, 0xb0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802017cf;
    func_0x000180211a40(iVar4);
code_r0x0001802017d1:
    *(undefined8 *)((int64_t)&uStack_20 + iVar2) = 0x1802017de;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar2) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802017f0
// Address: 0x1802017f0
// Size: 236 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1802017f0(int64_t arg_48h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180201802;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_48h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3);
    if ((*(uint8_t *)(in_RCX + 0x18) & 1) == 0) {
        uVar1 = *(undefined8 *)(in_RCX + 8);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180201835;
        iVar4 = func_0x000180229240(uVar1, (int64_t)&var_8h + iVar3);
        iVar6 = 0;
        if (iVar4 != 0) {
            while (iVar5 = iVar4, *(uint64_t *)(iVar5 + 0x18) != in_R8) {
                if ((*(uint64_t *)(iVar5 + 0x18) < in_R8) ||
                   (iVar4 = *(int64_t *)(iVar5 + 8), iVar6 = iVar5, *(int64_t *)(iVar5 + 8) == 0))
                goto code_r0x000180201856;
            }
            if (iVar6 == 0) {
                uVar1 = *(undefined8 *)(in_RCX + 8);
                if (*(int64_t *)(iVar5 + 8) == 0) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802018a4;
                    func_0x000180228b10(uVar1, iVar5);
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x18020188a;
                    func_0x000180228fb0();
                    uVar1 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180201896;
                    iVar2 = func_0x0001802018e0(in_RCX, uVar1);
                    if (iVar2 == 0) goto code_r0x000180201856;
                }
            } else {
                *(undefined8 *)(iVar6 + 8) = *(undefined8 *)(iVar5 + 8);
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802018b9;
            iVar2 = func_0x0001802019d0(in_RCX, iVar5);
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x1802018d2;
                func_0x000180224990(iVar5, 0x1804b9908, 0x19b);
            }
        }
    }
code_r0x000180201856:
    *(undefined8 *)((int64_t)&uStack_20 + iVar3) = 0x180201863;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_48h + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1802018e0
// Address: 0x1802018e0
// Size: 53 bytes
// ============================================================
undefined8 fcn.1802018e0(int64_t param_1, undefined8 param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802018ec;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x1802018fa;
    iVar1 = fcn.180228e00(param_2);
    if (iVar1 != 0) {
        *(uint32_t *)(param_1 + 0x18) = *(uint32_t *)(param_1 + 0x18) | 1;
        return 0;
    }
    return 1;
}

// ============================================================
// Function: FUN_180201920
// Address: 0x180201920
// Size: 76 bytes
// ============================================================
bool fcn.180201920(int64_t arg_38h, int64_t arg_78h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020192c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined4 *)((int64_t)&var_18h + iVar2) = 0x10;
    *(undefined4 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180201950;
    iVar1 = fcn.180212930(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)((int64_t)&arg_38h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
    if (iVar1 != 0) {
        return *(int32_t *)((int64_t)&arg_38h + iVar2) == 0x10;
    }
    return false;
}

// ============================================================
// Function: FUN_180201970
// Address: 0x180201970
// Size: 27 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001802019a1: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001802019a6)
// WARNING: Removing unreachable block (ram,0x0001802019ae)

void fcn.180201970(int64_t arg_28h, int64_t arg_78h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined *puVar6;
    undefined8 uVar7;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020197c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(in_RCX + 8);
    if (iVar4 == 0) {
        uVar7 = 0xa1;
        puVar6 = auStackX_20 + iVar3;
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        unaff_RBX = *(undefined8 *)(iVar4 + 8);
        uVar7 = 0x9e;
        puVar6 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802019a6;
        in_RCX = iVar4;
    }
    *(undefined8 *)(puVar6 + -8) = 0x18022499a;
    iVar4 = fcn.18045a350(in_RCX, 0x1804b9908, uVar7);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (in_RCX != 0) {
            *(undefined8 *)(puVar6 + iVar4 + 0x20) = unaff_RBX;
            *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, in_RCX);
            if (iVar1 == 0) {
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca4d;
                uVar2 = func_0x00018046b63c(uVar2);
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca54;
                puVar5 = (undefined4 *)func_0x00018046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_18020198b
// Address: 0x18020198b
// Size: 40 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001802019a1: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001802019a6)
// WARNING: Removing unreachable block (ram,0x0001802019ae)

void fcn.180201970(int64_t arg_28h, int64_t arg_78h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined *puVar6;
    undefined8 uVar7;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020197c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(in_RCX + 8);
    if (iVar4 == 0) {
        uVar7 = 0xa1;
        puVar6 = auStackX_20 + iVar3;
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        unaff_RBX = *(undefined8 *)(iVar4 + 8);
        uVar7 = 0x9e;
        puVar6 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802019a6;
        in_RCX = iVar4;
    }
    *(undefined8 *)(puVar6 + -8) = 0x18022499a;
    iVar4 = fcn.18045a350(in_RCX, 0x1804b9908, uVar7);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (in_RCX != 0) {
            *(undefined8 *)(puVar6 + iVar4 + 0x20) = unaff_RBX;
            *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, in_RCX);
            if (iVar1 == 0) {
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca4d;
                uVar2 = func_0x00018046b63c(uVar2);
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca54;
                puVar5 = (undefined4 *)func_0x00018046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1802019b3
// Address: 0x1802019b3
// Size: 26 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001802019a1: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001802019a6)
// WARNING: Removing unreachable block (ram,0x0001802019ae)

void fcn.180201970(int64_t arg_28h, int64_t arg_78h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined *puVar6;
    undefined8 uVar7;
    undefined auStackX_20 [8];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020197c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(in_RCX + 8);
    if (iVar4 == 0) {
        uVar7 = 0xa1;
        puVar6 = auStackX_20 + iVar3;
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        unaff_RBX = *(undefined8 *)(iVar4 + 8);
        uVar7 = 0x9e;
        puVar6 = (undefined *)((int64_t)&uStack_10 + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802019a6;
        in_RCX = iVar4;
    }
    *(undefined8 *)(puVar6 + -8) = 0x18022499a;
    iVar4 = fcn.18045a350(in_RCX, 0x1804b9908, uVar7);
    iVar4 = -iVar4;
    if (*(code **)0x1806a0030 == (code *)0x180224990) {
        if (in_RCX != 0) {
            *(undefined8 *)(puVar6 + iVar4 + 0x20) = unaff_RBX;
            *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, in_RCX);
            if (iVar1 == 0) {
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca4d;
                uVar2 = func_0x00018046b63c(uVar2);
                *(undefined8 *)(puVar6 + iVar4 + -8) = 0x18047ca54;
                puVar5 = (undefined4 *)func_0x00018046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1802019d0
// Address: 0x1802019d0
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1802019d0(int64_t arg_28h)
{
    undefined8 uVar1;
    int64_t **ppiVar2;
    int64_t **ppiVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t **ppiVar6;
    int64_t in_RCX;
    int64_t **in_RDX;
    int64_t var_8h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802019e0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802019f2;
    ppiVar6 = (int64_t **)fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar5));
    if (ppiVar6 == in_RDX) {
        if (*in_RDX == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180201a31;
            fcn.180228b10(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                          *(int64_t *)(&stack0x00000038 + iVar5));
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180201a0b;
        fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)(&stack0x00000030 + iVar5), 
                      *(int64_t *)(&stack0x00000038 + iVar5));
        uVar1 = *(undefined8 *)(in_RCX + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180201a14;
        iVar4 = fcn.180228e00(uVar1);
        if (iVar4 != 0) {
            *(uint32_t *)(in_RCX + 0x18) = *(uint32_t *)(in_RCX + 0x18) | 1;
            return 0;
        }
    } else {
        ppiVar3 = (int64_t **)*ppiVar6;
        while (ppiVar2 = ppiVar3, ppiVar2 != in_RDX) {
            ppiVar6 = ppiVar2;
            ppiVar3 = (int64_t **)*ppiVar2;
        }
        *ppiVar6 = *in_RDX;
    }
    return 1;
}

// ============================================================
// Function: FUN_180201a80
// Address: 0x180201a80
// Size: 81 bytes
// ============================================================
void fcn.180201a80(int64_t param_1)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x180201a8c;
    iVar5 = fcn.18045a350();
    pcVar1 = *(code **)(param_1 + 0x28);
    if (pcVar1 != (code *)0x0) {
        uVar2 = *(undefined8 *)(param_1 + 0x30);
        uVar3 = *(undefined8 *)(param_1 + 0x40);
        uVar4 = *(undefined8 *)(param_1 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 - iVar5) = 0x180201aa9;
        (*pcVar1)(uVar4, uVar3, uVar2);
        *(undefined4 *)(param_1 + 0x54) = 0xffffffff;
        *(undefined8 *)(param_1 + 0x28) = 0;
        *(undefined8 *)(param_1 + 0x20) = 0;
        *(undefined8 *)(param_1 + 0x40) = 0;
        return;
    }
    *(undefined4 *)(param_1 + 0x54) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180201b10
// Address: 0x180201b10
// Size: 23 bytes
// ============================================================
void fcn.180201b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x180201b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *in_RCX;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
        do {
            pcVar1 = *(code **)(iVar7 + 0x28);
            iVar2 = *(int64_t *)(iVar7 + 0x18);
            if (pcVar1 != (code *)0x0) {
                uVar3 = *(undefined8 *)(iVar7 + 0x30);
                uVar4 = *(undefined8 *)(iVar7 + 0x40);
                uVar5 = *(undefined8 *)(iVar7 + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201b4e;
                (*pcVar1)(uVar5, uVar4, uVar3);
                *(undefined8 *)(iVar7 + 0x28) = 0;
                *(undefined8 *)(iVar7 + 0x20) = 0;
                *(undefined8 *)(iVar7 + 0x40) = 0;
            }
            *(undefined4 *)(iVar7 + 0x54) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201b76;
            fcn.180224990(iVar7, 0x1804b9920, 199);
            iVar7 = iVar2;
        } while (iVar2 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_180201b27
// Address: 0x180201b27
// Size: 97 bytes
// ============================================================
void fcn.180201b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x180201b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *in_RCX;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
        do {
            pcVar1 = *(code **)(iVar7 + 0x28);
            iVar2 = *(int64_t *)(iVar7 + 0x18);
            if (pcVar1 != (code *)0x0) {
                uVar3 = *(undefined8 *)(iVar7 + 0x30);
                uVar4 = *(undefined8 *)(iVar7 + 0x40);
                uVar5 = *(undefined8 *)(iVar7 + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201b4e;
                (*pcVar1)(uVar5, uVar4, uVar3);
                *(undefined8 *)(iVar7 + 0x28) = 0;
                *(undefined8 *)(iVar7 + 0x20) = 0;
                *(undefined8 *)(iVar7 + 0x40) = 0;
            }
            *(undefined4 *)(iVar7 + 0x54) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201b76;
            fcn.180224990(iVar7, 0x1804b9920, 199);
            iVar7 = iVar2;
        } while (iVar2 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_180201b88
// Address: 0x180201b88
// Size: 6 bytes
// ============================================================
void fcn.180201b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    int64_t iVar7;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    uStack_10 = 0x180201b1c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *in_RCX;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RDI;
        do {
            pcVar1 = *(code **)(iVar7 + 0x28);
            iVar2 = *(int64_t *)(iVar7 + 0x18);
            if (pcVar1 != (code *)0x0) {
                uVar3 = *(undefined8 *)(iVar7 + 0x30);
                uVar4 = *(undefined8 *)(iVar7 + 0x40);
                uVar5 = *(undefined8 *)(iVar7 + 0x20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201b4e;
                (*pcVar1)(uVar5, uVar4, uVar3);
                *(undefined8 *)(iVar7 + 0x28) = 0;
                *(undefined8 *)(iVar7 + 0x20) = 0;
                *(undefined8 *)(iVar7 + 0x40) = 0;
            }
            *(undefined4 *)(iVar7 + 0x54) = 0xffffffff;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180201b76;
            fcn.180224990(iVar7, 0x1804b9920, 199);
            iVar7 = iVar2;
        } while (iVar2 != 0);
    }
    return;
}

// ============================================================
// Function: FUN_180201b90
// Address: 0x180201b90
// Size: 251 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180201b90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    code *in_R8;
    bool bVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180201bae;
    iVar2 = fcn.18045a350();
    iVar3 = 0;
    iVar4 = *in_RCX;
    if (*in_RCX == 0) {
        in_RCX[1] = in_RDX;
        *in_RCX = in_RDX;
        *(undefined8 *)(in_RDX + 0x18) = 0;
        *(undefined8 *)(in_RDX + 0x10) = 0;
    } else {
        do {
            *(undefined8 *)((int64_t)&uStack_20 - iVar2) = 0x180201be9;
            iVar1 = (*in_R8)(iVar4, in_RDX);
            iVar5 = iVar4;
            if (-1 < iVar1) break;
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            iVar3 = iVar4;
            iVar4 = iVar5;
        } while (iVar5 != 0);
        if (iVar5 == 0) {
            *(int64_t *)(in_RDX + 0x10) = in_RCX[1];
            *(undefined8 *)(in_RDX + 0x18) = 0;
            in_RCX[1] = in_RDX;
            if (*(int64_t *)(in_RDX + 0x10) != 0) {
                *(int64_t *)(*(int64_t *)(in_RDX + 0x10) + 0x18) = in_RDX;
            }
            if (*in_RCX == 0) {
                *in_RCX = in_RDX;
            }
        } else {
            if (iVar3 == 0) {
                *(int64_t *)(in_RDX + 0x18) = *in_RCX;
                *(undefined8 *)(in_RDX + 0x10) = 0;
                *in_RCX = in_RDX;
                if (*(int64_t *)(in_RDX + 0x18) != 0) {
                    *(int64_t *)(*(int64_t *)(in_RDX + 0x18) + 0x10) = in_RDX;
                }
                bVar6 = in_RCX[1] == 0;
            } else {
                *(int64_t *)(in_RDX + 0x10) = iVar3;
                *(undefined8 *)(in_RDX + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                if (*(int64_t *)(iVar3 + 0x18) != 0) {
                    *(int64_t *)(*(int64_t *)(iVar3 + 0x18) + 0x10) = in_RDX;
                }
                *(int64_t *)(iVar3 + 0x18) = in_RDX;
                bVar6 = in_RCX[1] == iVar3;
            }
            if (bVar6) {
                in_RCX[1] = in_RDX;
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180201cf0
// Address: 0x180201cf0
// Size: 317 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180201cf0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined4 in_EDX;
    undefined4 in_R8D;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180201d0e;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    iVar2 = *(int64_t *)(in_RCX + 0x20);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180201d40;
        iVar2 = func_0x000180224d60(0x58, 0x1804b9920, 0xdd);
        if (iVar2 == 0) {
            return 0;
        }
        *(undefined4 *)(iVar2 + 0x54) = 0xffffffff;
        *(undefined8 *)(iVar2 + 0x10) = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)(iVar2 + 0x18) = 0;
        *(int64_t *)(in_RCX + 0x28) = iVar2;
        if (*(int64_t *)(iVar2 + 0x10) != 0) {
            *(int64_t *)(*(int64_t *)(iVar2 + 0x10) + 0x18) = iVar2;
        }
        if (*(int64_t *)(in_RCX + 0x20) == 0) {
            *(int64_t *)(in_RCX + 0x20) = iVar2;
        }
    }
    *(undefined8 *)(iVar2 + 0x20) = *(undefined8 *)((int64_t)&arg_50h + iVar1);
    *(undefined8 *)(iVar2 + 0x40) = *(undefined8 *)((int64_t)&arg_58h + iVar1);
    *(undefined8 *)(iVar2 + 0x28) = *(undefined8 *)((int64_t)&arg_60h + iVar1);
    *(undefined8 *)(iVar2 + 0x30) = *(undefined8 *)((int64_t)&arg_68h + iVar1);
    *(undefined4 *)(iVar2 + 0x50) = *(undefined4 *)((int64_t)&arg_48h + iVar1);
    *(undefined4 *)(iVar2 + 0x48) = in_EDX;
    *(undefined8 *)(iVar2 + 0x38) = in_R9;
    *(undefined4 *)(iVar2 + 0x4c) = in_R8D;
    *(undefined4 *)(iVar2 + 0x54) = 0;
    if (*(int64_t *)(in_RCX + 0x20) == iVar2) {
        *(undefined8 *)(in_RCX + 0x20) = *(undefined8 *)(iVar2 + 0x18);
    }
    if (*(int64_t *)(in_RCX + 0x28) == iVar2) {
        *(undefined8 *)(in_RCX + 0x28) = *(undefined8 *)(iVar2 + 0x10);
    }
    if (*(int64_t *)(iVar2 + 0x10) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar2 + 0x10) + 0x18) = *(undefined8 *)(iVar2 + 0x18);
    }
    if (*(int64_t *)(iVar2 + 0x18) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar2 + 0x18) + 0x10) = *(undefined8 *)(iVar2 + 0x10);
    }
    *(undefined8 *)(iVar2 + 0x18) = 0;
    *(undefined8 *)(iVar2 + 0x10) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar1) = 0x180201e0f;
    fcn.180201b90(*(int64_t *)((int64_t)&var_8h + iVar1), *(int64_t *)((int64_t)&var_10h + iVar1), 
                  *(int64_t *)((int64_t)&var_18h + iVar1));
    return iVar2;
}

// ============================================================
// Function: FUN_180201e30
// Address: 0x180201e30
// Size: 72 bytes
// ============================================================
void fcn.180201e30(int64_t arg1)
{
    int64_t iVar1;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180201e40;
        iVar1 = fcn.18045a350();
        iVar1 = -iVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180201e4b;
        fcn.180201b10(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180201e54;
        fcn.180201b10(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180201e5d;
        fcn.180201b10(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180201e72;
        fcn.180224990(arg1, 0x1804b9920, 0xd3);
    }
    return;
}

// ============================================================
// Function: FUN_180201ee0
// Address: 0x180201ee0
// Size: 220 bytes
// ============================================================
void fcn.180201ee0(int64_t *param_1, int64_t param_2, int32_t param_3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t *piVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 unaff_RDI;
    code *pcVar11;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    bool bVar12;
    int64_t iStack_10;
    
    iStack_10 = 0x180201eec;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar4 = *(int32_t *)(param_2 + 0x54);
    if ((*(uint8_t *)(param_2 + 0x50) & 1) != 0) {
        piVar8 = param_1;
        if (iVar4 != 0) {
            if (iVar4 != 1) {
                return;
            }
            piVar8 = param_1 + 2;
        }
        *(undefined8 *)((int64_t)&iStack_10 + iVar7) = 0x180201f19;
        iVar5 = param_2;
        func_0x000180201c90(piVar8);
        *(int64_t *)(iVar5 + 0x10) = param_1[5];
        *(undefined8 *)(iVar5 + 0x18) = 0;
        param_1[5] = param_2;
        if (*(int64_t *)(iVar5 + 0x10) != 0) {
            *(int64_t *)(*(int64_t *)(iVar5 + 0x10) + 0x18) = param_2;
        }
        if (param_1[4] == 0) {
            param_1[4] = param_2;
        }
        *(undefined8 *)(&stack0x00000018 + iVar7) = *(undefined8 *)(&stack0x00000018 + iVar7);
        *(undefined8 *)(&stack0x00000010 + iVar7) = 0x180201a8c;
        iVar5 = fcn.18045a350();
        pcVar11 = *(code **)(param_2 + 0x28);
        if (pcVar11 != (code *)0x0) {
            uVar1 = *(undefined8 *)(param_2 + 0x30);
            uVar2 = *(undefined8 *)(param_2 + 0x40);
            uVar3 = *(undefined8 *)(param_2 + 0x20);
            *(undefined8 *)(&stack0x00000010 + (iVar7 - iVar5)) = 0x180201aa9;
            (*pcVar11)(uVar3, uVar2, uVar1);
            *(undefined4 *)(param_2 + 0x54) = 0xffffffff;
            *(undefined8 *)(param_2 + 0x28) = 0;
            *(undefined8 *)(param_2 + 0x20) = 0;
            *(undefined8 *)(param_2 + 0x40) = 0;
            return;
        }
        *(undefined4 *)(param_2 + 0x54) = 0xffffffff;
        return;
    }
    if (iVar4 == 0) {
        if ((param_3 != -1) && (param_3 != *(int32_t *)(param_2 + 0x48))) {
            *(undefined8 *)((int64_t)&iStack_10 + iVar7) = 0x180201f9e;
            func_0x000180201c90(param_1);
            *(int32_t *)(param_2 + 0x48) = param_3;
            pcVar11 = (code *)0x180201ae0;
            *(undefined8 *)(&stack0x00000028 + iVar7) = *(undefined8 *)(&stack0x00000018 + iVar7);
            *(undefined8 *)(&stack0x00000030 + iVar7) = unaff_RBP;
            *(undefined8 *)(&stack0x00000038 + iVar7) = unaff_RSI;
            *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RDI;
            *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R14;
            *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R15;
            *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = 0x180201bae;
            iVar6 = fcn.18045a350();
            iVar5 = 0;
            iVar9 = *param_1;
            if (*param_1 == 0) {
                param_1[1] = param_2;
                *param_1 = param_2;
                *(undefined8 *)(param_2 + 0x18) = 0;
                *(undefined8 *)(param_2 + 0x10) = 0;
            } else {
                do {
                    *(undefined8 *)(&stack0x00000020 + (iVar7 - iVar6) + -0x20) = 0x180201be9;
                    iVar4 = (*pcVar11)(iVar9, param_2);
                    iVar10 = iVar9;
                    if (-1 < iVar4) break;
                    iVar10 = *(int64_t *)(iVar9 + 0x18);
                    iVar5 = iVar9;
                    iVar9 = iVar10;
                } while (iVar10 != 0);
                if (iVar10 == 0) {
                    *(int64_t *)(param_2 + 0x10) = param_1[1];
                    *(undefined8 *)(param_2 + 0x18) = 0;
                    param_1[1] = param_2;
                    if (*(int64_t *)(param_2 + 0x10) != 0) {
                        *(int64_t *)(*(int64_t *)(param_2 + 0x10) + 0x18) = param_2;
                    }
                    if (*param_1 == 0) {
                        *param_1 = param_2;
                    }
                } else {
                    if (iVar5 == 0) {
                        *(int64_t *)(param_2 + 0x18) = *param_1;
                        *(undefined8 *)(param_2 + 0x10) = 0;
                        *param_1 = param_2;
                        if (*(int64_t *)(param_2 + 0x18) != 0) {
                            *(int64_t *)(*(int64_t *)(param_2 + 0x18) + 0x10) = param_2;
                        }
                        bVar12 = param_1[1] == 0;
                    } else {
                        *(int64_t *)(param_2 + 0x10) = iVar5;
                        *(undefined8 *)(param_2 + 0x18) = *(undefined8 *)(iVar5 + 0x18);
                        if (*(int64_t *)(iVar5 + 0x18) != 0) {
                            *(int64_t *)(*(int64_t *)(iVar5 + 0x18) + 0x10) = param_2;
                        }
                        *(int64_t *)(iVar5 + 0x18) = param_2;
                        bVar12 = param_1[1] == iVar5;
                    }
                    if (bVar12) {
                        param_1[1] = param_2;
                    }
                }
            }
            return;
        }
    } else if (iVar4 == 1) {
        if (param_3 != -1) {
            *(int32_t *)(param_2 + 0x48) = param_3;
        }
        *(undefined8 *)((int64_t)&iStack_10 + iVar7) = 0x180201f6e;
        func_0x000180201c90(param_1 + 2);
        *(undefined8 *)((int64_t)&iStack_10 + iVar7) = 0x180201f7d;
        fcn.180201b90(*(int64_t *)(&stack0x00000018 + iVar7), *(int64_t *)(&stack0x00000020 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        *(undefined4 *)(param_2 + 0x54) = 0;
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180202050
// Address: 0x180202050
// Size: 40 bytes
// ============================================================
int64_t fcn.180202050(int64_t arg_30h, int64_t arg_50h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    uVar4 = 0x30;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1) = 0x180224d70;
    iVar2 = fcn.18045a350(0x30, 0x1804b9920, 0xab);
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d7b;
    iVar3 = fcn.1802248d0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar1), *(int64_t *)(&stack0x00000048 + iVar2 + iVar1)
                         );
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar2 + iVar1) = 0x180224d90;
        fcn.1804986e0(iVar3, 0, uVar4);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_180202080
// Address: 0x180202080
// Size: 103 bytes
// ============================================================
void fcn.180202080(int64_t param_1, int64_t param_2)
{
    code *pcVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 auStackX_18 [2];
    undefined8 uStack_8;
    
    uStack_8 = 0x18020208a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar5 = param_1;
    if (*(int32_t *)(param_2 + 0x54) != 0) {
        if (*(int32_t *)(param_2 + 0x54) != 1) {
            return;
        }
        iVar5 = param_1 + 0x10;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x1802020aa;
    func_0x000180201c90(iVar5);
    *(undefined8 *)(param_2 + 0x10) = *(undefined8 *)(param_1 + 0x28);
    *(undefined8 *)(param_2 + 0x18) = 0;
    *(int64_t *)(param_1 + 0x28) = param_2;
    if (*(int64_t *)(param_2 + 0x10) != 0) {
        *(int64_t *)(*(int64_t *)(param_2 + 0x10) + 0x18) = param_2;
    }
    if (*(int64_t *)(param_1 + 0x20) == 0) {
        *(int64_t *)(param_1 + 0x20) = param_2;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar6 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar6) = 0x180201a8c;
    iVar5 = fcn.18045a350();
    pcVar1 = *(code **)(param_2 + 0x28);
    if (pcVar1 == (code *)0x0) {
        *(undefined4 *)(param_2 + 0x54) = 0xffffffff;
        return;
    }
    uVar2 = *(undefined8 *)(param_2 + 0x30);
    uVar3 = *(undefined8 *)(param_2 + 0x40);
    uVar4 = *(undefined8 *)(param_2 + 0x20);
    *(undefined8 *)((int64_t)auStackX_18 + (iVar6 - iVar5)) = 0x180201aa9;
    (*pcVar1)(uVar4, uVar3, uVar2);
    *(undefined4 *)(param_2 + 0x54) = 0xffffffff;
    *(undefined8 *)(param_2 + 0x28) = 0;
    *(undefined8 *)(param_2 + 0x20) = 0;
    *(undefined8 *)(param_2 + 0x40) = 0;
    return;
}

// ============================================================
// Function: FUN_1802020f0
// Address: 0x1802020f0
// Size: 421 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1802020f0(int64_t arg_68h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_120h, int64_t arg_150h)
{
    uint64_t **ppuVar1;
    undefined8 uVar2;
    code *pcVar3;
    uint64_t *puVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    uint64_t **ppuVar14;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_8h;
    
    uStack_40 = 0x18020210a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&var_10h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    iVar11 = (int64_t)in_EDX;
    ppuVar1 = (uint64_t **)(&stack0xffffffffffffffe8 + iVar7);
    uVar2 = *(undefined8 *)(in_RCX + 0x100);
    *(undefined8 *)(&stack0xffffffffffffffe8 + iVar7) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18020213f;
    func_0x0001801de220(uVar2, &stack0xfffffffffffffff0 + iVar7);
    uVar12 = *(uint64_t *)(&stack0xfffffffffffffff0 + iVar7);
    uVar13 = *(uint64_t *)((int64_t)&var_8h + iVar7);
    *(undefined8 *)(in_RCX + 0x150 + iVar11 * 8) = 0;
    if (uVar12 < uVar13) {
        uVar12 = *(uint64_t *)((int64_t)&var_8h + iVar7);
    }
    if (uVar12 < 0x1c71c71c71c71c72) {
        uVar12 = uVar12 * 9 >> 3;
        if (uVar12 < 0xf4241) {
            uVar12 = 1000000;
        }
    } else {
        uVar12 = 0x1fffffffffffffff;
    }
    pcVar3 = *(code **)(in_RCX + 0xf0);
    uVar2 = *(undefined8 *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18020219b;
    uVar8 = (*pcVar3)(uVar2);
    uVar13 = 0;
    if (uVar12 <= uVar8) {
        uVar13 = uVar8 - uVar12;
    }
    ppuVar14 = (uint64_t **)(iVar11 * 0x30 + in_RCX);
    puVar4 = *ppuVar14;
    while (puVar6 = puVar4, puVar6 != (uint64_t *)0x0) {
        uVar8 = *(uint64_t *)(in_RCX + 0x120 + iVar11 * 8);
        puVar4 = (uint64_t *)puVar6[9];
        if (*puVar6 <= uVar8) {
            uVar5 = puVar6[2];
            if ((uVar13 < uVar5) && (uVar8 < *puVar6 + 3)) {
                uVar8 = *(uint64_t *)(in_RCX + 0x150 + iVar11 * 8);
                if (uVar8 == 0) {
                    iVar10 = -1;
                    if (uVar12 <= ~uVar5) {
                        iVar10 = uVar5 + uVar12;
                    }
                    *(int64_t *)(in_RCX + 0x150 + iVar11 * 8) = iVar10;
                } else {
                    uVar9 = 0xffffffffffffffff;
                    if (uVar12 <= ~uVar5) {
                        uVar9 = uVar5 + uVar12;
                    }
                    if (uVar8 < uVar9) {
                        uVar9 = uVar8;
                    }
                    *(uint64_t *)(in_RCX + 0x150 + iVar11 * 8) = uVar9;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18020224c;
                func_0x000180203930(ppuVar14);
                *ppuVar1 = puVar6;
                ppuVar1 = (uint64_t **)(puVar6 + 0xc);
                *ppuVar1 = (uint64_t *)0x0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18020227d;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_10h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_1802022a0
// Address: 0x1802022a0
// Size: 513 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

void fcn.1802022a0(int64_t arg_28h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_118h, int64_t arg_138h,
                  int64_t arg_198h, int64_t arg_1a0h, int64_t arg_1a8h, int64_t arg_1c8h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    undefined auVar5 [16];
    int64_t iVar6;
    uint64_t uVar7;
    uint32_t uVar8;
    int64_t in_RCX;
    uint32_t *in_RDX;
    uint64_t uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    uint64_t *puVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1802022bc;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&var_18h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    uVar2 = *(undefined8 *)(in_RCX + 0x100);
    uVar14 = 0;
    uVar9 = 0xffffffffffffffff;
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1802022f2;
    func_0x0001801de220(uVar2, (int64_t)&var_8h + iVar6);
    if (*(uint64_t *)((int64_t)auStackX_8 + iVar6) < 0x4000000000000000) {
        uVar7 = *(uint64_t *)((int64_t)auStackX_8 + iVar6) * 4;
        if (uVar7 < 0xf4241) {
            uVar7 = 1000000;
        }
    } else {
        uVar7 = 0xffffffffffffffff;
    }
    uVar10 = 0xffffffffffffffff;
    if (uVar7 <= -*(int64_t *)((int64_t)&var_8h + iVar6) - 1U) {
        uVar10 = uVar7 + *(int64_t *)((int64_t)&var_8h + iVar6);
    }
    uVar1 = *(uint32_t *)(in_RCX + 0x118);
    uVar11 = 0x10;
    if (uVar1 < 0x10) {
        uVar11 = uVar1;
    }
    uVar7 = 1LL << ((uint8_t)uVar11 & 0x3f);
    auVar4._8_8_ = 0;
    auVar4._0_8_ = uVar7;
    if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar4, 0) < uVar10) {
        uVar7 = 0xffffffffffffffff;
    } else {
        uVar7 = uVar7 * uVar10;
    }
    if (*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) == 0) {
        *in_RDX = (uint32_t)(*(char *)(in_RCX + 0x1cb) != '\0');
        pcVar3 = *(code **)(in_RCX + 0xf0);
        uVar2 = *(undefined8 *)(in_RCX + 0xf8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18020239e;
        (*pcVar3)(uVar2);
    } else {
        puVar12 = (uint64_t *)(in_RCX + 0x138);
        uVar11 = uVar14;
        do {
            if ((puVar12[0xc] != 0) || ((*(char *)(in_RCX + 0x1c8) != '\x01' && (*(char *)(in_RCX + 0x1c9) != '\x01'))))
            {
                if (uVar11 == 2) {
                    if (*(char *)(in_RCX + 0x1c8) == '\0') break;
                    uVar10 = *(uint64_t *)(in_RCX + 0x930);
                    if (uVar10 != 0xffffffffffffffff) {
                        uVar8 = 0x10;
                        if (uVar1 < 0x10) {
                            uVar8 = uVar1;
                        }
                        uVar13 = 1LL << ((uint8_t)uVar8 & 0x3f);
                        auVar5._8_8_ = 0;
                        auVar5._0_8_ = uVar13;
                        if (SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar5, 0) < uVar10) {
                            uVar10 = 0xffffffffffffffff;
                        } else {
                            uVar10 = uVar10 * uVar13;
                        }
                        if (~uVar7 < uVar10) {
                            uVar7 = 0xffffffffffffffff;
                        } else {
                            uVar7 = uVar7 + uVar10;
                        }
                    }
                }
                uVar10 = *puVar12;
                if (uVar10 != 0) {
                    uVar13 = 0xffffffffffffffff;
                    if (uVar7 <= ~uVar10) {
                        uVar13 = uVar10 + uVar7;
                    }
                    if (uVar13 < uVar9) {
                        uVar9 = uVar13;
                        uVar14 = uVar11;
                    }
                }
            }
            uVar11 = uVar11 + 1;
            puVar12 = puVar12 + 1;
        } while ((int32_t)uVar11 < 3);
        *in_RDX = uVar14;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180202488;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_18h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802024b0
// Address: 0x1802024b0
// Size: 76 bytes
// ============================================================
void fcn.1802024b0(int64_t param_1, int32_t param_2, undefined8 param_3)
{
    fcn.18045a350();
    *(undefined8 *)(param_1 + 0x918 + (int64_t)param_2 * 8) = param_3;
    if (*(code **)(param_1 + 0x950) != (code *)0x0) {
        if (*(char *)((int64_t)param_2 + 0x1ce + param_1) != '\0') {
            param_3 = 0;
        }
    // WARNING: Could not recover jumptable at 0x0001802024f4. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(param_1 + 0x950))(param_3);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180202500
// Address: 0x180202500
// Size: 231 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

undefined8 fcn.180202500(int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    uint64_t uVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18020250c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = *(uint64_t *)(in_RCX + 0x150);
    if ((((uVar5 == 0) || (*(uint64_t *)(in_RCX + 0x158) < uVar5)) &&
        (uVar5 = *(uint64_t *)(in_RCX + 0x158), uVar5 == 0)) || (*(uint64_t *)(in_RCX + 0x160) < uVar5)) {
        uVar5 = *(uint64_t *)(in_RCX + 0x160);
        *(undefined4 *)((int64_t)&arg_28h + iVar3) = 2;
        if (uVar5 == 0) {
            if ((*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) != 0) ||
               (*(char *)(in_RCX + 0x1ca) == '\0')) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180202595;
                uVar4 = fcn.1802022a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)(&stack0x000000e0 + iVar3)
                                      , *(int64_t *)(&stack0x000000e8 + iVar3), *(int64_t *)(&stack0x00000108 + iVar3), 
                                      *(int64_t *)(&stack0x00000128 + iVar3), *(int64_t *)(&stack0x00000188 + iVar3), 
                                      *(int64_t *)(&stack0x00000190 + iVar3), *(int64_t *)(&stack0x00000198 + iVar3), 
                                      *(int64_t *)(&stack0x000001b8 + iVar3));
                pcVar1 = *(code **)(in_RCX + 0x940);
                *(undefined8 *)(in_RCX + 0x168) = uVar4;
                if (pcVar1 == (code *)0x0) {
                    return 1;
                }
                uVar2 = *(undefined8 *)(in_RCX + 0x948);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802025b5;
                (*pcVar1)(uVar4, uVar2);
                return 1;
            }
            *(undefined8 *)(in_RCX + 0x168) = 0;
            pcVar1 = *(code **)(in_RCX + 0x940);
            goto joined_r0x000180202584;
        }
    }
    pcVar1 = *(code **)(in_RCX + 0x940);
    *(uint64_t *)(in_RCX + 0x168) = uVar5;
joined_r0x000180202584:
    if (pcVar1 != (code *)0x0) {
        uVar4 = *(undefined8 *)(in_RCX + 0x948);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802025dc;
        (*pcVar1)(uVar5, uVar4);
    }
    return 1;
}

// ============================================================
// Function: FUN_1802025f0
// Address: 0x1802025f0
// Size: 205 bytes
// ============================================================
void fcn.1802025f0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180202604;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if ((*(undefined (*) [16])(arg1 + 0x1c0))[0xb] == '\0') {
            uVar1 = *(undefined8 *)(*(undefined (*) [16])(arg1 + 0x10) + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020261c;
            func_0x000180228ec0(uVar1);
            *(undefined8 *)(*(undefined (*) [16])(arg1 + 0x10) + 8) = 0;
            *(undefined (*) [16])arg1 = ZEXT816(0);
            *(undefined8 *)*(undefined (*) [16])(arg1 + 0x10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020263c;
            func_0x00018020afb0((undefined (*) [16])(arg1 + 0x90));
        }
        if ((*(undefined (*) [16])(arg1 + 0x1c0))[0xc] == '\0') {
            uVar1 = *(undefined8 *)(*(undefined (*) [16])(arg1 + 0x40) + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020264e;
            func_0x000180228ec0(uVar1);
            *(undefined8 *)(*(undefined (*) [16])(arg1 + 0x40) + 8) = 0;
            *(undefined (*) [16])(arg1 + 0x30) = ZEXT816(0);
            *(undefined8 *)*(undefined (*) [16])(arg1 + 0x40) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020266f;
            func_0x00018020afb0((undefined (*) [16])(arg1 + 0xb0));
        }
        if ((*(undefined (*) [16])(arg1 + 0x1c0))[0xd] == '\0') {
            uVar1 = *(undefined8 *)(*(undefined (*) [16])(arg1 + 0x70) + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180202681;
            func_0x000180228ec0(uVar1);
            *(undefined8 *)(*(undefined (*) [16])(arg1 + 0x70) + 8) = 0;
            *(undefined (*) [16])(arg1 + 0x60) = ZEXT816(0);
            *(undefined8 *)*(undefined (*) [16])(arg1 + 0x70) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802026a2;
            func_0x00018020afb0((undefined (*) [16])(arg1 + 0xd0));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802026b7;
        fcn.180224990(arg1, 0x1804b9938, 0x446);
    }
    return;
}

// ============================================================
// Function: FUN_1802026f0
// Address: 0x1802026f0
// Size: 345 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t * fcn.1802026f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    int64_t iVar5;
    uint64_t in_RDX;
    undefined8 *puVar6;
    int64_t iVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020270a;
    iVar3 = fcn.18045a350();
    iVar7 = (int64_t)(int32_t)in_RDX;
    piVar8 = (int64_t *)(in_RCX + 0x1e8 + iVar7 * 0x38);
    pcVar1 = *(code **)(in_RCX + 0xf0);
    uVar2 = *(undefined8 *)(in_RCX + 0xf8);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180202731;
    uVar4 = (*pcVar1)(uVar2);
    uVar11 = 0;
    iVar5 = *(int64_t *)(iVar7 * 0x20 + 0x98 + in_RCX);
    uVar9 = uVar11;
    if (iVar5 != 0) {
        puVar6 = (undefined8 *)(iVar7 * 0x200 + 0x298 + in_RCX);
        do {
            if (2 < uVar9) break;
            uVar9 = uVar9 + 1;
            puVar6[-1] = *(undefined8 *)(iVar5 + 0x10);
            *puVar6 = *(undefined8 *)(iVar5 + 0x18);
            puVar6 = puVar6 + 2;
            iVar5 = *(int64_t *)(iVar5 + 8);
        } while (iVar5 != 0);
    }
    piVar8[1] = uVar9;
    *piVar8 = iVar7 * 0x200 + 0x290 + in_RCX;
    uVar9 = *(uint64_t *)(in_RCX + 0x8a8 + iVar7 * 8);
    uVar10 = uVar11;
    if (((uVar9 != 0) && (uVar9 < uVar4)) && ((int32_t)in_RDX == 2)) {
        uVar10 = uVar4 - uVar9;
    }
    piVar8[2] = uVar10;
    piVar8[3] = *(int64_t *)(in_RCX + 0x8c0 + iVar7 * 8);
    piVar8[4] = *(int64_t *)(in_RCX + 0x8d8 + iVar7 * 8);
    iVar5 = *(int64_t *)(in_RCX + 0x8f0 + iVar7 * 8);
    *(uint32_t *)(piVar8 + 6) = *(uint32_t *)(piVar8 + 6) | 1;
    piVar8[5] = iVar5;
    *(undefined4 *)(in_RCX + 0x908 + iVar7 * 4) = 0;
    *(undefined *)(iVar7 + 0x1d1 + in_RCX) = 1;
    *(undefined *)(iVar7 + 0x1ce + in_RCX) = 0;
    *(undefined8 *)(in_RCX + 0x918 + iVar7 * 8) = 0xffffffffffffffff;
    pcVar1 = *(code **)(in_RCX + 0x950);
    if (pcVar1 != (code *)0x0) {
        uVar2 = *(undefined8 *)(in_RCX + 0x958);
        uVar9 = 0xffffffffffffffff;
        if (*(char *)(iVar7 + 0x1ce + in_RCX) != '\0') {
            uVar9 = uVar11;
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x180202831;
        (*pcVar1)(uVar9, in_RDX & 0xffffffff, uVar2);
    }
    return piVar8;
}

// ============================================================
// Function: FUN_180202870
// Address: 0x180202870
// Size: 196 bytes
// ============================================================
void fcn.180202870(int64_t arg_28h, int64_t arg_38h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t uVar3;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020287c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_38h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    uVar1 = *(undefined8 *)(in_RCX + 0x100);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802028a2;
    func_0x0001801de220(uVar1, (int64_t)&var_18h + iVar2);
    if (*(uint64_t *)((int64_t)&arg_28h + iVar2) < 0x4000000000000000) {
        uVar3 = *(uint64_t *)((int64_t)&arg_28h + iVar2) * 4;
        if (uVar3 < 0xf4241) {
            uVar3 = 1000000;
        }
    } else {
        uVar3 = 0xffffffffffffffff;
    }
    if (-*(int64_t *)((int64_t)&var_18h + iVar2) - 1U < uVar3) {
        uVar3 = 0xffffffffffffffff;
    } else {
        uVar3 = *(int64_t *)((int64_t)&var_18h + iVar2) + uVar3;
    }
    if ((*(uint64_t *)(in_RCX + 0x930) != 0xffffffffffffffff) && (*(uint64_t *)(in_RCX + 0x930) <= ~uVar3)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180202918;
        func_0x000180459870(*(uint64_t *)((int64_t)&arg_38h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
        return;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18020292e;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_38h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180202940
// Address: 0x180202940
// Size: 82 bytes
// ============================================================
undefined8 fcn.180202940(int64_t param_1, int32_t param_2)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020294c;
    iVar4 = fcn.18045a350();
    if (*(char *)((int64_t)param_2 + 0x1ce + param_1) != '\0') {
        return 1;
    }
    uVar1 = *(uint64_t *)(param_1 + 0x918 + (int64_t)param_2 * 8);
    if (uVar1 != 0xffffffffffffffff) {
        pcVar2 = *(code **)(param_1 + 0xf0);
        uVar3 = *(undefined8 *)(param_1 + 0xf8);
        *(undefined8 *)((int64_t)&uStack_10 - iVar4) = 0x18020297a;
        uVar5 = (*pcVar2)(uVar3);
        if (uVar1 <= uVar5) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802029a0
// Address: 0x1802029a0
// Size: 62 bytes
// ============================================================
undefined8 fcn.1802029a0(int64_t param_1, uint64_t param_2, int32_t param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802029aa;
    iVar2 = fcn.18045a350();
    if (*(uint64_t *)(param_1 + (int64_t)param_3 * 0x20 + 0xa8) <= param_2) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x1802029c9;
        iVar1 = fcn.18020b370();
        if (iVar1 == 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802029e0
// Address: 0x1802029e0
// Size: 249 bytes
// ============================================================
void fcn.1802029e0(int64_t arg_88h, int64_t arg_a8h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 *puVar6;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802029ee;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&arg_a8h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5);
    *(undefined8 *)((int64_t)&var_18h + iVar5) = in_R8;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180202a27;
    puVar6 = (undefined8 *)fcn.180229240(*(int64_t *)((int64_t)&iStackX_10 + iVar5));
    if (puVar6 != (undefined8 *)0x0) {
        uVar2 = *puVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180202a3e;
        func_0x000180203930((int64_t)in_EDX * 0x30 + in_RCX, uVar2);
        puVar6[0xc] = 0;
        *(undefined (*) [16])((int64_t)&iStackX_10 + iVar5 + -8) = ZEXT816(0);
        do {
            puVar3 = (undefined8 *)puVar6[0xc];
            if ((*(uint8_t *)(puVar6 + 4) & 4) != 0) {
                *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - puVar6[1];
                if ((*(uint32_t *)(puVar6 + 4) & 8) != 0) {
                    piVar1 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(puVar6 + 4) & 3) * 8);
                    *piVar1 = *piVar1 - puVar6[1];
                }
            }
            pcVar4 = (code *)puVar6[5];
            uVar2 = puVar6[8];
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180202a86;
            (*pcVar4)(uVar2);
            puVar6 = puVar3;
        } while (puVar3 != (undefined8 *)0x0);
        uVar2 = *(undefined8 *)(in_RCX + 0x100);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180202aa2;
        func_0x0001801de220(uVar2, (int64_t)&arg_88h + iVar5);
        uVar2 = *(undefined8 *)(in_RCX + 0x110);
        pcVar4 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180202ab9;
        (*pcVar4)(uVar2, 0);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x180202ace;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_a8h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe8 + iVar5));
    return;
}

// ============================================================
// Function: FUN_180202ae0
// Address: 0x180202ae0
// Size: 521 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

int64_t fcn.180202ae0(int64_t arg1, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                     int64_t arg_68h)
{
    undefined uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 *puVar9;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    undefined8 in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    undefined8 *puVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    int64_t var_20h;
    
    uStack_28 = 0x180202af6;
    var_8h = arg1;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202b19;
    iVar6 = fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000028 + iVar5));
    if (iVar6 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBX;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
    puVar9 = (undefined8 *)(iVar6 + 0x28);
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = unaff_R14;
    puVar11 = (undefined8 *)(iVar6 + 0x918);
    uVar10 = uVar8;
    do {
        puVar11[-0xff] = 0xffffffffffffffff;
        *puVar11 = 0xffffffffffffffff;
        *(undefined (*) [16])(puVar9 + -5) = ZEXT816(0);
        puVar9[-3] = 0;
        puVar9[-1] = 0;
        *puVar9 = 0;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202b8b;
        fcn.180229130(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + -0x18), *(int64_t *)((int64_t)&var_8h + iVar5));
        *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -0x18) = 0x180195290;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202bb4;
        iVar7 = fcn.180229290(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + -0x18));
        puVar9[-2] = iVar7;
        if (iVar7 == 0) {
            iVar4 = (int32_t)uVar8 + -1;
            iVar7 = (int64_t)iVar4;
            if (-1 < iVar4) {
                puVar9 = (undefined8 *)(iVar7 * 0x30 + 0x18 + iVar6);
                do {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202c98;
                    fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_18 + iVar5 + -0x18), 
                                  *(int64_t *)((int64_t)&var_8h + iVar5), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar5 + -8), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)(&stack0x00000030 + iVar5));
                    *puVar9 = 0;
                    iVar7 = iVar7 + -1;
                    *(undefined (*) [16])(puVar9 + -3) = ZEXT816(0);
                    puVar9[-1] = 0;
                    puVar9 = puVar9 + -6;
                } while (-1 < iVar7);
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202cc7;
            fcn.180224990(iVar6, 0x1804b9938, 0x435);
            return 0;
        }
        uVar8 = (uint64_t)((int32_t)uVar8 + 1);
        uVar10 = uVar10 + 1;
        puVar11 = puVar11 + 1;
        puVar9 = puVar9 + 6;
    } while ((int64_t)uVar10 < 3);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202be9;
    fcn.18020b000(iVar6 + 0x90);
    *(undefined8 *)(iVar6 + 0xa8) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202bfe;
    fcn.18020b000(iVar6 + 0xb0);
    *(undefined8 *)(iVar6 + 200) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180202c11;
    fcn.18020b000(iVar6 + 0xd0);
    uVar2 = *(undefined8 *)((int64_t)&arg_60h + iVar5);
    uVar3 = *(undefined8 *)((int64_t)&arg_40h + iVar5);
    *(undefined8 *)(iVar6 + 0xe8) = 0;
    *(undefined8 *)(iVar6 + 0x110) = uVar2;
    uVar1 = *(undefined *)((int64_t)&arg_68h + iVar5);
    *(undefined8 *)(iVar6 + 0xf0) = uVar3;
    *(undefined *)(iVar6 + 0x1c9) = uVar1;
    *(undefined8 *)(iVar6 + 0xf8) = in_RDX;
    *(undefined8 *)(iVar6 + 0x100) = in_R8;
    *(undefined8 *)(iVar6 + 0x108) = in_R9;
    *(undefined8 *)(iVar6 + 0x930) = 25000000;
    *(undefined8 *)(iVar6 + 0x938) = 25000000;
    return iVar6;
}

// ============================================================
// Function: FUN_180202cf0
// Address: 0x180202cf0
// Size: 42 bytes
// ============================================================
undefined8 fcn.180202cf0(int64_t param_1)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180202cfa;
    iVar1 = fcn.18045a350();
    *(undefined *)(param_1 + 0x1c8) = 1;
    *(undefined *)(param_1 + 0x1ca) = 1;
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180202d10;
    fcn.180202500(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    return 1;
}

// ============================================================
// Function: FUN_180202d20
// Address: 0x180202d20
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180202d20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int32_t in_EDX;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined (*pauVar8) [16];
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180202d33;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar7 = (int64_t)in_EDX;
    if (*(char *)(iVar7 + 0x1cb + in_RCX) == '\0') {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (in_EDX == 1) {
            *(undefined *)(in_RCX + 0x1ca) = 1;
        }
        pauVar8 = (undefined (*) [16])(iVar7 * 0x30 + in_RCX);
        iVar5 = *(int64_t *)*pauVar8;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            do {
                iVar1 = *(int64_t *)(iVar5 + 0x48);
                if ((*(uint8_t *)(iVar5 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar5 + 8);
                    iVar6 = iVar6 + *(int64_t *)(iVar5 + 8);
                }
                pcVar2 = *(code **)(iVar5 + 0x38);
                uVar3 = *(undefined8 *)(iVar5 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202da5;
                (*pcVar2)(uVar3);
                iVar5 = iVar1;
            } while (iVar1 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202dbb;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)(pauVar8[1] + 8) = 0;
        *pauVar8 = ZEXT816(0);
        *(undefined8 *)pauVar8[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202de2;
        fcn.18020afb0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar6 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x110);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x60);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e04;
            (*pcVar2)(uVar3, iVar6);
        }
        *(undefined8 *)(in_RCX + 0x138 + iVar7 * 8) = 0;
        *(undefined8 *)(in_RCX + 0x150 + iVar7 * 8) = 0;
        *(undefined4 *)(in_RCX + 0x118) = 0;
        *(undefined *)(iVar7 + 0x1cb + in_RCX) = 1;
        *(undefined8 *)(in_RCX + 0x198 + iVar7 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e33;
        fcn.180202500(*(int64_t *)((int64_t)aiStackX_8 + iVar4));
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180202d5a
// Address: 0x180202d5a
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180202d20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int32_t in_EDX;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined (*pauVar8) [16];
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180202d33;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar7 = (int64_t)in_EDX;
    if (*(char *)(iVar7 + 0x1cb + in_RCX) == '\0') {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (in_EDX == 1) {
            *(undefined *)(in_RCX + 0x1ca) = 1;
        }
        pauVar8 = (undefined (*) [16])(iVar7 * 0x30 + in_RCX);
        iVar5 = *(int64_t *)*pauVar8;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            do {
                iVar1 = *(int64_t *)(iVar5 + 0x48);
                if ((*(uint8_t *)(iVar5 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar5 + 8);
                    iVar6 = iVar6 + *(int64_t *)(iVar5 + 8);
                }
                pcVar2 = *(code **)(iVar5 + 0x38);
                uVar3 = *(undefined8 *)(iVar5 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202da5;
                (*pcVar2)(uVar3);
                iVar5 = iVar1;
            } while (iVar1 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202dbb;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)(pauVar8[1] + 8) = 0;
        *pauVar8 = ZEXT816(0);
        *(undefined8 *)pauVar8[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202de2;
        fcn.18020afb0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar6 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x110);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x60);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e04;
            (*pcVar2)(uVar3, iVar6);
        }
        *(undefined8 *)(in_RCX + 0x138 + iVar7 * 8) = 0;
        *(undefined8 *)(in_RCX + 0x150 + iVar7 * 8) = 0;
        *(undefined4 *)(in_RCX + 0x118) = 0;
        *(undefined *)(iVar7 + 0x1cb + in_RCX) = 1;
        *(undefined8 *)(in_RCX + 0x198 + iVar7 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e33;
        fcn.180202500(*(int64_t *)((int64_t)aiStackX_8 + iVar4));
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180202d7d
// Address: 0x180202d7d
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180202d20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int32_t in_EDX;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined (*pauVar8) [16];
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180202d33;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar7 = (int64_t)in_EDX;
    if (*(char *)(iVar7 + 0x1cb + in_RCX) == '\0') {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (in_EDX == 1) {
            *(undefined *)(in_RCX + 0x1ca) = 1;
        }
        pauVar8 = (undefined (*) [16])(iVar7 * 0x30 + in_RCX);
        iVar5 = *(int64_t *)*pauVar8;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            do {
                iVar1 = *(int64_t *)(iVar5 + 0x48);
                if ((*(uint8_t *)(iVar5 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar5 + 8);
                    iVar6 = iVar6 + *(int64_t *)(iVar5 + 8);
                }
                pcVar2 = *(code **)(iVar5 + 0x38);
                uVar3 = *(undefined8 *)(iVar5 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202da5;
                (*pcVar2)(uVar3);
                iVar5 = iVar1;
            } while (iVar1 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202dbb;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)(pauVar8[1] + 8) = 0;
        *pauVar8 = ZEXT816(0);
        *(undefined8 *)pauVar8[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202de2;
        fcn.18020afb0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar6 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x110);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x60);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e04;
            (*pcVar2)(uVar3, iVar6);
        }
        *(undefined8 *)(in_RCX + 0x138 + iVar7 * 8) = 0;
        *(undefined8 *)(in_RCX + 0x150 + iVar7 * 8) = 0;
        *(undefined4 *)(in_RCX + 0x118) = 0;
        *(undefined *)(iVar7 + 0x1cb + in_RCX) = 1;
        *(undefined8 *)(in_RCX + 0x198 + iVar7 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e33;
        fcn.180202500(*(int64_t *)((int64_t)aiStackX_8 + iVar4));
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180202db2
// Address: 0x180202db2
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180202d20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int32_t in_EDX;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined (*pauVar8) [16];
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180202d33;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar7 = (int64_t)in_EDX;
    if (*(char *)(iVar7 + 0x1cb + in_RCX) == '\0') {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (in_EDX == 1) {
            *(undefined *)(in_RCX + 0x1ca) = 1;
        }
        pauVar8 = (undefined (*) [16])(iVar7 * 0x30 + in_RCX);
        iVar5 = *(int64_t *)*pauVar8;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            do {
                iVar1 = *(int64_t *)(iVar5 + 0x48);
                if ((*(uint8_t *)(iVar5 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar5 + 8);
                    iVar6 = iVar6 + *(int64_t *)(iVar5 + 8);
                }
                pcVar2 = *(code **)(iVar5 + 0x38);
                uVar3 = *(undefined8 *)(iVar5 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202da5;
                (*pcVar2)(uVar3);
                iVar5 = iVar1;
            } while (iVar1 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202dbb;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)(pauVar8[1] + 8) = 0;
        *pauVar8 = ZEXT816(0);
        *(undefined8 *)pauVar8[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202de2;
        fcn.18020afb0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar6 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x110);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x60);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e04;
            (*pcVar2)(uVar3, iVar6);
        }
        *(undefined8 *)(in_RCX + 0x138 + iVar7 * 8) = 0;
        *(undefined8 *)(in_RCX + 0x150 + iVar7 * 8) = 0;
        *(undefined4 *)(in_RCX + 0x118) = 0;
        *(undefined *)(iVar7 + 0x1cb + in_RCX) = 1;
        *(undefined8 *)(in_RCX + 0x198 + iVar7 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e33;
        fcn.180202500(*(int64_t *)((int64_t)aiStackX_8 + iVar4));
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180202dec
// Address: 0x180202dec
// Size: 90 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180202d20(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t iVar5;
    int32_t in_EDX;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t iVar7;
    undefined8 unaff_R15;
    undefined (*pauVar8) [16];
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180202d33;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar6 = 0;
    iVar7 = (int64_t)in_EDX;
    if (*(char *)(iVar7 + 0x1cb + in_RCX) == '\0') {
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R15;
        if (in_EDX == 1) {
            *(undefined *)(in_RCX + 0x1ca) = 1;
        }
        pauVar8 = (undefined (*) [16])(iVar7 * 0x30 + in_RCX);
        iVar5 = *(int64_t *)*pauVar8;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
            do {
                iVar1 = *(int64_t *)(iVar5 + 0x48);
                if ((*(uint8_t *)(iVar5 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar5 + 8);
                    iVar6 = iVar6 + *(int64_t *)(iVar5 + 8);
                }
                pcVar2 = *(code **)(iVar5 + 0x38);
                uVar3 = *(undefined8 *)(iVar5 + 0x40);
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202da5;
                (*pcVar2)(uVar3);
                iVar5 = iVar1;
            } while (iVar1 != 0);
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202dbb;
        fcn.180228ec0(*(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)(pauVar8[1] + 8) = 0;
        *pauVar8 = ZEXT816(0);
        *(undefined8 *)pauVar8[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202de2;
        fcn.18020afb0(*(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar6 != 0) {
            uVar3 = *(undefined8 *)(in_RCX + 0x110);
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x60);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e04;
            (*pcVar2)(uVar3, iVar6);
        }
        *(undefined8 *)(in_RCX + 0x138 + iVar7 * 8) = 0;
        *(undefined8 *)(in_RCX + 0x150 + iVar7 * 8) = 0;
        *(undefined4 *)(in_RCX + 0x118) = 0;
        *(undefined *)(iVar7 + 0x1cb + in_RCX) = 1;
        *(undefined8 *)(in_RCX + 0x198 + iVar7 * 8) = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180202e33;
        fcn.180202500(*(int64_t *)((int64_t)aiStackX_8 + iVar4));
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180202e50
// Address: 0x180202e50
// Size: 1024 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180202e50(int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_98h, int64_t arg_100h)
{
    int64_t **ppiVar1;
    uint32_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    undefined8 uVar5;
    code *pcVar6;
    int64_t iVar7;
    uint64_t *puVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t *in_RDX;
    uint64_t **ppuVar13;
    int64_t *piVar14;
    int32_t in_R8D;
    int64_t iVar15;
    int64_t iVar16;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_8h;
    
    uStack_40 = 0x180202e6a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_98h + iVar7) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7);
    iVar15 = (int64_t)in_R8D;
    piVar14 = (int64_t *)0x0;
    *(undefined4 *)((int64_t)&var_18h + iVar7) = 0;
    uVar10 = *(uint64_t *)(in_RCX + 0x120 + iVar15 * 8);
    uVar11 = *(uint64_t *)(*in_RDX + 8);
    if ((uVar10 != 0xffffffffffffffff) && (uVar11 < uVar10)) {
        uVar11 = uVar10;
    }
    *(uint64_t *)(in_RCX + 0x120 + iVar15 * 8) = uVar11;
    if ((*(char *)(in_RCX + 0x1ca) == '\0') && (in_R8D == 1)) {
        *(undefined *)(in_RCX + 0x1ca) = 1;
        *(undefined4 *)((int64_t)&var_18h + iVar7) = 1;
    }
    iVar12 = *in_RDX;
    iVar16 = iVar15 * 0x30 + in_RCX;
    *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
    ppuVar13 = (uint64_t **)((int64_t)&arg_68h + iVar7);
    *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)(iVar12 + 8);
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180202f0a;
    puVar8 = (uint64_t *)fcn.180229240(*(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
    if ((puVar8 != (uint64_t *)0x0) || (puVar8 = *(uint64_t **)(iVar16 + 8), puVar8 != (uint64_t *)0x0)) {
        do {
            puVar3 = (uint64_t *)puVar8[10];
            iVar12 = (int64_t)piVar14 << 4;
            while( true ) {
                if ((int64_t *)in_RDX[1] <= piVar14) goto code_r0x000180202f78;
                iVar4 = *in_RDX;
                uVar10 = *puVar8;
                if (*(uint64_t *)(iVar4 + iVar12) <= uVar10) break;
                if (*(uint64_t *)(iVar4 + 8 + iVar12) < uVar10) goto code_r0x000180202f70;
                piVar14 = (int64_t *)((int64_t)piVar14 + 1);
                iVar12 = iVar12 + 0x10;
            }
            if (uVar10 <= *(uint64_t *)(iVar4 + 8 + iVar12)) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180202f60;
                func_0x000180203930(iVar16);
                *ppuVar13 = puVar8;
                ppuVar13 = (uint64_t **)(puVar8 + 0xb);
                *ppuVar13 = (uint64_t *)0x0;
            }
code_r0x000180202f70:
            puVar8 = puVar3;
        } while (puVar3 != (uint64_t *)0x0);
code_r0x000180202f78:
        piVar14 = *(int64_t **)((int64_t)&arg_68h + iVar7);
    }
    if (piVar14 == (int64_t *)0x0) {
        if (*(int32_t *)((int64_t)&var_18h + iVar7) == 0) goto code_r0x0001802031bb;
    } else {
        piVar9 = piVar14;
        if (*piVar14 == *(int64_t *)(*in_RDX + 8)) {
            do {
                if ((*(uint8_t *)(piVar9 + 4) & 8) != 0) {
                    pcVar6 = *(code **)(in_RCX + 0xf0);
                    uVar5 = *(undefined8 *)(in_RCX + 0xf8);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802031fb;
                    uVar10 = (*pcVar6)(uVar5);
                    if (*(int64_t *)(in_RCX + 0x188) == 0) {
                        *(uint64_t *)(in_RCX + 0x188) = uVar10;
                    }
                    uVar11 = in_RDX[2];
                    if ((*(char *)(in_RCX + 0x1c8) != '\0') && (*(uint64_t *)(in_RCX + 0x930) <= uVar11)) {
                        uVar11 = *(uint64_t *)(in_RCX + 0x930);
                    }
                    iVar12 = uVar10 - piVar14[2];
                    uVar5 = *(undefined8 *)(in_RCX + 0x100);
                    if (uVar10 < (uint64_t)piVar14[2]) {
                        iVar12 = 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18020324b;
                    func_0x0001801de270(uVar5, uVar11, iVar12);
                    break;
                }
                ppiVar1 = (int64_t **)(piVar9 + 0xb);
                piVar9 = *ppiVar1;
            } while (*ppiVar1 != (int64_t *)0x0);
        }
        if (((*(uint8_t *)(in_RDX + 6) & 1) != 0) && (*(uint64_t *)(in_RCX + 0x1b0 + iVar15 * 8) < (uint64_t)in_RDX[5]))
        {
            *(int64_t *)(in_RCX + 0x1b0 + iVar15 * 8) = in_RDX[5];
            *(undefined8 *)((int64_t)&var_8h + iVar7) = *(undefined8 *)(*in_RDX + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180202ff8;
            iVar15 = fcn.180229240(*(int64_t *)(&stack0xfffffffffffffff0 + iVar7));
            if (iVar15 != 0) {
                uVar5 = *(undefined8 *)(in_RCX + 0x110);
                *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(iVar15 + 0x10);
                pcVar6 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x68);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180203026;
                (*pcVar6)(uVar5, (int64_t)&arg_68h + iVar7);
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180203031;
        iVar15 = fcn.1802020f0(*(int64_t *)(&stack0x00000028 + iVar7), *(int64_t *)(&stack0x000000b0 + iVar7), 
                               *(int64_t *)(&stack0x000000b8 + iVar7), *(int64_t *)(&stack0x000000e0 + iVar7), 
                               *(int64_t *)(&stack0x00000110 + iVar7));
        if (iVar15 != 0) {
            *(undefined (*) [16])((int64_t)&arg_68h + iVar7) = ZEXT816(0);
            do {
                iVar12 = *(int64_t *)(iVar15 + 0x60);
                if ((*(uint8_t *)(iVar15 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar15 + 8);
                    if ((*(uint32_t *)(iVar15 + 0x20) & 8) != 0) {
                        piVar9 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(iVar15 + 0x20) & 3) * 8);
                        *piVar9 = *piVar9 - *(int64_t *)(iVar15 + 8);
                    }
                    uVar5 = *(undefined8 *)(in_RCX + 0x110);
                    *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(iVar15 + 0x10);
                    *(undefined8 *)((int64_t)&arg_70h + iVar7) = *(undefined8 *)(iVar15 + 8);
                    pcVar6 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802030b1;
                    (*pcVar6)(uVar5, (int64_t)&arg_68h + iVar7);
                }
                pcVar6 = *(code **)(iVar15 + 0x28);
                uVar5 = *(undefined8 *)(iVar15 + 0x40);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802030bb;
                (*pcVar6)(uVar5);
                iVar15 = iVar12;
            } while (iVar12 != 0);
            uVar5 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802030d7;
            func_0x0001801de220(uVar5, (int64_t)&arg_78h + iVar7);
            uVar5 = *(undefined8 *)(in_RCX + 0x110);
            pcVar6 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802030ee;
            (*pcVar6)(uVar5, 0);
        }
        *(undefined (*) [16])((int64_t)&arg_68h + iVar7) = ZEXT816(0);
        do {
            if ((*(uint8_t *)(piVar14 + 4) & 4) != 0) {
                *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - piVar14[1];
                if ((*(uint32_t *)(piVar14 + 4) & 8) != 0) {
                    piVar9 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(piVar14 + 4) & 3) * 8);
                    *piVar9 = *piVar9 - piVar14[1];
                }
                iVar15 = piVar14[3];
                if (iVar15 != -1) {
                    uVar2 = *(uint32_t *)(piVar14 + 4);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x18020314e;
                    func_0x0001802038b0((uint64_t)(uVar2 & 3) * 0x20 + 0x90 + in_RCX, iVar15 + 1);
                }
            }
            *(int64_t *)((int64_t)&arg_68h + iVar7) = piVar14[2];
            *(int64_t *)((int64_t)&arg_70h + iVar7) = piVar14[1];
            pcVar6 = (code *)piVar14[6];
            iVar15 = piVar14[8];
            piVar9 = (int64_t *)piVar14[0xb];
            *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180203174;
            (*pcVar6)(iVar15);
            if ((*(uint8_t *)(piVar14 + 4) & 4) != 0) {
                uVar5 = *(undefined8 *)(in_RCX + 0x110);
                pcVar6 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x48);
                *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x180203197;
                (*pcVar6)(uVar5, (int64_t)&arg_68h + iVar7);
            }
            piVar14 = piVar9;
        } while (piVar9 != (int64_t *)0x0);
        if (*(char *)(in_RCX + 0x1ca) != '\0') {
            *(undefined4 *)(in_RCX + 0x118) = 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802031bb;
    fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar7));
code_r0x0001802031bb:
    *(undefined8 *)((int64_t)&uStack_40 + iVar7) = 0x1802031d0;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_98h + iVar7) ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar7));
    return;
}

// ============================================================
// Function: FUN_180203250
// Address: 0x180203250
// Size: 288 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_918h because it doesn't fit into ProtoModel

void fcn.180203250(int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    uint64_t *in_RDX;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    undefined8 unaff_RDI;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180203267;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_18h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    piVar13 = (int64_t *)(in_RCX + 0x90 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 0x20);
    if ((uint64_t)piVar13[3] <= *in_RDX) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802032a8;
        iVar5 = fcn.18020b370(piVar13);
        if (iVar5 == 0) {
            if (*(uint64_t *)(in_RCX + 0x890 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) < *in_RDX) {
                *(uint64_t *)(in_RCX + 0x890 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) = *in_RDX;
                *(uint64_t *)(in_RCX + 0x8a8 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) = in_RDX[1];
            }
            uVar16 = 0;
            uVar14 = *in_RDX;
            iVar15 = (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 0x38;
            bVar4 = false;
            if ((*(int64_t *)(iVar15 + 0x1f0 + in_RCX) != 0) &&
               (puVar9 = *(uint64_t **)(iVar15 + 0x1e8 + in_RCX), uVar14 <= puVar9[1])) {
                uVar12 = *(uint64_t *)(iVar15 + 0x1f0 + in_RCX);
                uVar11 = uVar16;
                if (uVar12 != 0) {
                    do {
                        if ((*puVar9 <= uVar14) && (uVar14 <= puVar9[1])) goto code_r0x00018020333a;
                        uVar11 = uVar11 + 1;
                        puVar9 = puVar9 + 2;
                    } while (uVar11 < uVar12);
                }
                bVar4 = true;
            }
code_r0x00018020333a:
            uVar12 = 0xffffffffffffffff;
            *(uint64_t *)((int64_t)&var_8h + iVar8) = uVar14;
            *(uint64_t *)(&stack0x00000000 + iVar8) = uVar14;
            if ((uint64_t)piVar13[3] <= uVar14) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180203362;
                iVar5 = func_0x00018020b010(piVar13, (int64_t)&var_8h + iVar8);
                if (iVar5 != 1) goto code_r0x000180203546;
                uVar14 = piVar13[2];
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = unaff_RDI;
                uVar11 = 0xffffffffffffffff;
                if (0x20 < uVar14) {
                    do {
                        uVar14 = *(uint64_t *)(*piVar13 + 0x18);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8) = *(undefined8 *)(*piVar13 + 0x10);
                        *(uint64_t *)((int64_t)auStackX_8 + iVar8 + 8) = uVar14;
                        if ((uVar11 != 0xffffffffffffffff) && (uVar14 < uVar11)) {
                            uVar14 = uVar11;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802033b9;
                        func_0x00018020b3b0(piVar13, (int64_t)auStackX_8 + iVar8);
                        uVar11 = uVar14;
                    } while (0x20 < (uint64_t)piVar13[2]);
                    if (uVar14 != 0xffffffffffffffff) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802033d1;
                        func_0x0001802038b0(piVar13, uVar14 + 1);
                    }
                }
            }
            if ((*(uint32_t *)(in_RDX + 2) & 4) != 0) {
                uVar14 = in_RDX[1];
                uVar6 = *(uint32_t *)(in_RDX + 2) & 3;
                uVar11 = (uint64_t)uVar6;
                if (*(char *)((uint64_t)uVar6 + 0x1ce + in_RCX) == '\0') {
                    uVar7 = *(int32_t *)(in_RCX + 0x908 + (uint64_t)uVar6 * 4) + 1;
                    *(uint32_t *)(in_RCX + 0x908 + uVar11 * 4) = uVar7;
                    if ((((*(char *)(uVar11 + 0x1d1 + in_RCX) == '\0') || (bVar4)) || (1 < uVar7)) ||
                       (((*(int64_t *)((uint64_t)uVar6 * 0x20 + 0xa0 + in_RCX) != 0 &&
                         (*(int64_t *)(uVar11 * 0x38 + 0x1f0 + in_RCX) != 0)) &&
                        ((iVar15 = *(int64_t *)((uint64_t)uVar6 * 0x20 + 0x98 + in_RCX),
                         uVar1 = *(uint64_t *)(iVar15 + 0x10), uVar1 == *(uint64_t *)(iVar15 + 0x18) &&
                         (*(int64_t *)(*(int64_t *)(uVar11 * 0x38 + 0x1e8 + in_RCX) + 8) + 1U < uVar1)))))) {
                        *(undefined *)(uVar11 + 0x1ce + in_RCX) = 1;
                        *(undefined8 *)(in_RCX + 0x918 + uVar11 * 8) = 0xffffffffffffffff;
                        pcVar2 = *(code **)(in_RCX + 0x950);
                        if (pcVar2 != (code *)0x0) {
                            uVar3 = *(undefined8 *)(in_RCX + 0x958);
                            if (*(char *)(uVar11 + 0x1ce + in_RCX) != '\0') {
                                uVar12 = uVar16;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034ff;
                            (*pcVar2)(uVar12, uVar11, uVar3);
                        }
                    } else {
                        uVar1 = *(uint64_t *)(in_RCX + 0x918 + uVar11 * 8);
                        uVar10 = *(uint64_t *)(in_RCX + 0x938);
                        if (uVar6 < 2) {
                            uVar10 = uVar16;
                        }
                        if (uVar1 < 0xffffffffffffffff) {
                            if ((~uVar14 < uVar10) || (uVar16 = uVar14 + uVar10, uVar1 < uVar14 + uVar10)) {
                                uVar16 = uVar1;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034ab;
                            fcn.1802024b0(in_RCX, uVar11, uVar16);
                        } else {
                            if (uVar10 <= ~uVar14) {
                                uVar12 = uVar14 + uVar10;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034c8;
                            fcn.1802024b0(in_RCX, uVar11, uVar12);
                        }
                    }
                }
            }
            uVar6 = *(uint32_t *)(in_RDX + 2);
            uVar7 = uVar6 >> 3 & 3;
            if (uVar7 == 1) {
                piVar13 = (int64_t *)(in_RCX + 0x8d8 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            } else if (uVar7 == 2) {
                piVar13 = (int64_t *)(in_RCX + 0x8c0 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            } else if (uVar7 == 3) {
                piVar13 = (int64_t *)(in_RCX + 0x8f0 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            }
        }
    }
code_r0x000180203546:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180203553;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_18h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180203370
// Address: 0x180203370
// Size: 105 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_918h because it doesn't fit into ProtoModel

void fcn.180203250(int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    uint64_t *in_RDX;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    undefined8 unaff_RDI;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180203267;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_18h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    piVar13 = (int64_t *)(in_RCX + 0x90 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 0x20);
    if ((uint64_t)piVar13[3] <= *in_RDX) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802032a8;
        iVar5 = fcn.18020b370(piVar13);
        if (iVar5 == 0) {
            if (*(uint64_t *)(in_RCX + 0x890 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) < *in_RDX) {
                *(uint64_t *)(in_RCX + 0x890 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) = *in_RDX;
                *(uint64_t *)(in_RCX + 0x8a8 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) = in_RDX[1];
            }
            uVar16 = 0;
            uVar14 = *in_RDX;
            iVar15 = (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 0x38;
            bVar4 = false;
            if ((*(int64_t *)(iVar15 + 0x1f0 + in_RCX) != 0) &&
               (puVar9 = *(uint64_t **)(iVar15 + 0x1e8 + in_RCX), uVar14 <= puVar9[1])) {
                uVar12 = *(uint64_t *)(iVar15 + 0x1f0 + in_RCX);
                uVar11 = uVar16;
                if (uVar12 != 0) {
                    do {
                        if ((*puVar9 <= uVar14) && (uVar14 <= puVar9[1])) goto code_r0x00018020333a;
                        uVar11 = uVar11 + 1;
                        puVar9 = puVar9 + 2;
                    } while (uVar11 < uVar12);
                }
                bVar4 = true;
            }
code_r0x00018020333a:
            uVar12 = 0xffffffffffffffff;
            *(uint64_t *)((int64_t)&var_8h + iVar8) = uVar14;
            *(uint64_t *)(&stack0x00000000 + iVar8) = uVar14;
            if ((uint64_t)piVar13[3] <= uVar14) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180203362;
                iVar5 = func_0x00018020b010(piVar13, (int64_t)&var_8h + iVar8);
                if (iVar5 != 1) goto code_r0x000180203546;
                uVar14 = piVar13[2];
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = unaff_RDI;
                uVar11 = 0xffffffffffffffff;
                if (0x20 < uVar14) {
                    do {
                        uVar14 = *(uint64_t *)(*piVar13 + 0x18);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8) = *(undefined8 *)(*piVar13 + 0x10);
                        *(uint64_t *)((int64_t)auStackX_8 + iVar8 + 8) = uVar14;
                        if ((uVar11 != 0xffffffffffffffff) && (uVar14 < uVar11)) {
                            uVar14 = uVar11;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802033b9;
                        func_0x00018020b3b0(piVar13, (int64_t)auStackX_8 + iVar8);
                        uVar11 = uVar14;
                    } while (0x20 < (uint64_t)piVar13[2]);
                    if (uVar14 != 0xffffffffffffffff) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802033d1;
                        func_0x0001802038b0(piVar13, uVar14 + 1);
                    }
                }
            }
            if ((*(uint32_t *)(in_RDX + 2) & 4) != 0) {
                uVar14 = in_RDX[1];
                uVar6 = *(uint32_t *)(in_RDX + 2) & 3;
                uVar11 = (uint64_t)uVar6;
                if (*(char *)((uint64_t)uVar6 + 0x1ce + in_RCX) == '\0') {
                    uVar7 = *(int32_t *)(in_RCX + 0x908 + (uint64_t)uVar6 * 4) + 1;
                    *(uint32_t *)(in_RCX + 0x908 + uVar11 * 4) = uVar7;
                    if ((((*(char *)(uVar11 + 0x1d1 + in_RCX) == '\0') || (bVar4)) || (1 < uVar7)) ||
                       (((*(int64_t *)((uint64_t)uVar6 * 0x20 + 0xa0 + in_RCX) != 0 &&
                         (*(int64_t *)(uVar11 * 0x38 + 0x1f0 + in_RCX) != 0)) &&
                        ((iVar15 = *(int64_t *)((uint64_t)uVar6 * 0x20 + 0x98 + in_RCX),
                         uVar1 = *(uint64_t *)(iVar15 + 0x10), uVar1 == *(uint64_t *)(iVar15 + 0x18) &&
                         (*(int64_t *)(*(int64_t *)(uVar11 * 0x38 + 0x1e8 + in_RCX) + 8) + 1U < uVar1)))))) {
                        *(undefined *)(uVar11 + 0x1ce + in_RCX) = 1;
                        *(undefined8 *)(in_RCX + 0x918 + uVar11 * 8) = 0xffffffffffffffff;
                        pcVar2 = *(code **)(in_RCX + 0x950);
                        if (pcVar2 != (code *)0x0) {
                            uVar3 = *(undefined8 *)(in_RCX + 0x958);
                            if (*(char *)(uVar11 + 0x1ce + in_RCX) != '\0') {
                                uVar12 = uVar16;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034ff;
                            (*pcVar2)(uVar12, uVar11, uVar3);
                        }
                    } else {
                        uVar1 = *(uint64_t *)(in_RCX + 0x918 + uVar11 * 8);
                        uVar10 = *(uint64_t *)(in_RCX + 0x938);
                        if (uVar6 < 2) {
                            uVar10 = uVar16;
                        }
                        if (uVar1 < 0xffffffffffffffff) {
                            if ((~uVar14 < uVar10) || (uVar16 = uVar14 + uVar10, uVar1 < uVar14 + uVar10)) {
                                uVar16 = uVar1;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034ab;
                            fcn.1802024b0(in_RCX, uVar11, uVar16);
                        } else {
                            if (uVar10 <= ~uVar14) {
                                uVar12 = uVar14 + uVar10;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034c8;
                            fcn.1802024b0(in_RCX, uVar11, uVar12);
                        }
                    }
                }
            }
            uVar6 = *(uint32_t *)(in_RDX + 2);
            uVar7 = uVar6 >> 3 & 3;
            if (uVar7 == 1) {
                piVar13 = (int64_t *)(in_RCX + 0x8d8 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            } else if (uVar7 == 2) {
                piVar13 = (int64_t *)(in_RCX + 0x8c0 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            } else if (uVar7 == 3) {
                piVar13 = (int64_t *)(in_RCX + 0x8f0 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            }
        }
    }
code_r0x000180203546:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180203553;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_18h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_1802033d9
// Address: 0x1802033d9
// Size: 399 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_890h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_908h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_950h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_958h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_938h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_918h because it doesn't fit into ProtoModel

void fcn.180203250(int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    code *pcVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t iVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t in_RCX;
    uint64_t *in_RDX;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    undefined8 unaff_RDI;
    uint64_t uVar14;
    int64_t iVar15;
    uint64_t uVar16;
    uint64_t auStackX_8 [2];
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180203267;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    *(uint64_t *)((int64_t)&var_18h + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    piVar13 = (int64_t *)(in_RCX + 0x90 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 0x20);
    if ((uint64_t)piVar13[3] <= *in_RDX) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802032a8;
        iVar5 = fcn.18020b370(piVar13);
        if (iVar5 == 0) {
            if (*(uint64_t *)(in_RCX + 0x890 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) < *in_RDX) {
                *(uint64_t *)(in_RCX + 0x890 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) = *in_RDX;
                *(uint64_t *)(in_RCX + 0x8a8 + (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 8) = in_RDX[1];
            }
            uVar16 = 0;
            uVar14 = *in_RDX;
            iVar15 = (uint64_t)(*(uint32_t *)(in_RDX + 2) & 3) * 0x38;
            bVar4 = false;
            if ((*(int64_t *)(iVar15 + 0x1f0 + in_RCX) != 0) &&
               (puVar9 = *(uint64_t **)(iVar15 + 0x1e8 + in_RCX), uVar14 <= puVar9[1])) {
                uVar12 = *(uint64_t *)(iVar15 + 0x1f0 + in_RCX);
                uVar11 = uVar16;
                if (uVar12 != 0) {
                    do {
                        if ((*puVar9 <= uVar14) && (uVar14 <= puVar9[1])) goto code_r0x00018020333a;
                        uVar11 = uVar11 + 1;
                        puVar9 = puVar9 + 2;
                    } while (uVar11 < uVar12);
                }
                bVar4 = true;
            }
code_r0x00018020333a:
            uVar12 = 0xffffffffffffffff;
            *(uint64_t *)((int64_t)&var_8h + iVar8) = uVar14;
            *(uint64_t *)(&stack0x00000000 + iVar8) = uVar14;
            if ((uint64_t)piVar13[3] <= uVar14) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180203362;
                iVar5 = func_0x00018020b010(piVar13, (int64_t)&var_8h + iVar8);
                if (iVar5 != 1) goto code_r0x000180203546;
                uVar14 = piVar13[2];
                *(undefined8 *)((int64_t)&arg_68h + iVar8) = unaff_RDI;
                uVar11 = 0xffffffffffffffff;
                if (0x20 < uVar14) {
                    do {
                        uVar14 = *(uint64_t *)(*piVar13 + 0x18);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8) = *(undefined8 *)(*piVar13 + 0x10);
                        *(uint64_t *)((int64_t)auStackX_8 + iVar8 + 8) = uVar14;
                        if ((uVar11 != 0xffffffffffffffff) && (uVar14 < uVar11)) {
                            uVar14 = uVar11;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802033b9;
                        func_0x00018020b3b0(piVar13, (int64_t)auStackX_8 + iVar8);
                        uVar11 = uVar14;
                    } while (0x20 < (uint64_t)piVar13[2]);
                    if (uVar14 != 0xffffffffffffffff) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802033d1;
                        func_0x0001802038b0(piVar13, uVar14 + 1);
                    }
                }
            }
            if ((*(uint32_t *)(in_RDX + 2) & 4) != 0) {
                uVar14 = in_RDX[1];
                uVar6 = *(uint32_t *)(in_RDX + 2) & 3;
                uVar11 = (uint64_t)uVar6;
                if (*(char *)((uint64_t)uVar6 + 0x1ce + in_RCX) == '\0') {
                    uVar7 = *(int32_t *)(in_RCX + 0x908 + (uint64_t)uVar6 * 4) + 1;
                    *(uint32_t *)(in_RCX + 0x908 + uVar11 * 4) = uVar7;
                    if ((((*(char *)(uVar11 + 0x1d1 + in_RCX) == '\0') || (bVar4)) || (1 < uVar7)) ||
                       (((*(int64_t *)((uint64_t)uVar6 * 0x20 + 0xa0 + in_RCX) != 0 &&
                         (*(int64_t *)(uVar11 * 0x38 + 0x1f0 + in_RCX) != 0)) &&
                        ((iVar15 = *(int64_t *)((uint64_t)uVar6 * 0x20 + 0x98 + in_RCX),
                         uVar1 = *(uint64_t *)(iVar15 + 0x10), uVar1 == *(uint64_t *)(iVar15 + 0x18) &&
                         (*(int64_t *)(*(int64_t *)(uVar11 * 0x38 + 0x1e8 + in_RCX) + 8) + 1U < uVar1)))))) {
                        *(undefined *)(uVar11 + 0x1ce + in_RCX) = 1;
                        *(undefined8 *)(in_RCX + 0x918 + uVar11 * 8) = 0xffffffffffffffff;
                        pcVar2 = *(code **)(in_RCX + 0x950);
                        if (pcVar2 != (code *)0x0) {
                            uVar3 = *(undefined8 *)(in_RCX + 0x958);
                            if (*(char *)(uVar11 + 0x1ce + in_RCX) != '\0') {
                                uVar12 = uVar16;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034ff;
                            (*pcVar2)(uVar12, uVar11, uVar3);
                        }
                    } else {
                        uVar1 = *(uint64_t *)(in_RCX + 0x918 + uVar11 * 8);
                        uVar10 = *(uint64_t *)(in_RCX + 0x938);
                        if (uVar6 < 2) {
                            uVar10 = uVar16;
                        }
                        if (uVar1 < 0xffffffffffffffff) {
                            if ((~uVar14 < uVar10) || (uVar16 = uVar14 + uVar10, uVar1 < uVar14 + uVar10)) {
                                uVar16 = uVar1;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034ab;
                            fcn.1802024b0(in_RCX, uVar11, uVar16);
                        } else {
                            if (uVar10 <= ~uVar14) {
                                uVar12 = uVar14 + uVar10;
                            }
                            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x1802034c8;
                            fcn.1802024b0(in_RCX, uVar11, uVar12);
                        }
                    }
                }
            }
            uVar6 = *(uint32_t *)(in_RDX + 2);
            uVar7 = uVar6 >> 3 & 3;
            if (uVar7 == 1) {
                piVar13 = (int64_t *)(in_RCX + 0x8d8 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            } else if (uVar7 == 2) {
                piVar13 = (int64_t *)(in_RCX + 0x8c0 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            } else if (uVar7 == 3) {
                piVar13 = (int64_t *)(in_RCX + 0x8f0 + (uint64_t)(uVar6 & 3) * 8);
                *piVar13 = *piVar13 + 1;
            }
        }
    }
code_r0x000180203546:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x180203553;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_18h + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180203570
// Address: 0x180203570
// Size: 105 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

void fcn.180203570(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020357c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar7 = *(uint64_t *)(in_RCX + 0x150);
    if (((((uVar7 == 0) || (*(uint64_t *)(in_RCX + 0x158) < uVar7)) &&
         (uVar7 = *(uint64_t *)(in_RCX + 0x158), uVar7 == 0)) || (*(uint64_t *)(in_RCX + 0x160) < uVar7)) &&
       (iVar8 = *(int64_t *)(in_RCX + 0x160), *(undefined4 *)((int64_t)&var_18h + iVar6) = 2, iVar8 == 0)) {
        if (*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) == 0) {
            if (*(char *)(in_RCX + 0x1cb) == '\0') {
                *(int32_t *)(in_RCX + 0x1d4) = *(int32_t *)(in_RCX + 0x1d4) + 1;
            } else {
                *(int32_t *)(in_RCX + 0x1d8) = *(int32_t *)(in_RCX + 0x1d8) + 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036e2;
            fcn.1802022a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                          *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000108 + iVar6), 
                          *(int64_t *)(&stack0x00000128 + iVar6), *(int64_t *)(&stack0x00000188 + iVar6), 
                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x00000198 + iVar6), 
                          *(int64_t *)(&stack0x000001b8 + iVar6));
            piVar2 = (int32_t *)(in_RCX + 0x1dc + (int64_t)*(int32_t *)((int64_t)&var_18h + iVar6) * 4);
            *piVar2 = *piVar2 + 1;
        }
        *(int32_t *)(in_RCX + 0x118) = *(int32_t *)(in_RCX + 0x118) + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036fc;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802035e6;
        iVar8 = fcn.1802020f0(*(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                              *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000110 + iVar6), 
                              *(int64_t *)(&stack0x00000140 + iVar6));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined (*) [16])((int64_t)&var_20h + iVar6) = ZEXT816(0);
            do {
                iVar3 = *(int64_t *)(iVar8 + 0x60);
                if ((*(uint8_t *)(iVar8 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar8 + 8);
                    if ((*(uint32_t *)(iVar8 + 0x20) & 8) != 0) {
                        piVar1 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(iVar8 + 0x20) & 3) * 8);
                        *piVar1 = *piVar1 - *(int64_t *)(iVar8 + 8);
                    }
                    uVar4 = *(undefined8 *)(in_RCX + 0x110);
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)(iVar8 + 0x10);
                    *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(iVar8 + 8);
                    pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203658;
                    (*pcVar5)(uVar4, (int64_t)&var_20h + iVar6);
                }
                pcVar5 = *(code **)(iVar8 + 0x28);
                uVar4 = *(undefined8 *)(iVar8 + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203662;
                (*pcVar5)(uVar4);
                iVar8 = iVar3;
            } while (iVar3 != 0);
            uVar4 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203680;
            func_0x0001801de220(uVar4, (int64_t)&arg_30h + iVar6);
            uVar4 = *(undefined8 *)(in_RCX + 0x110);
            pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203697;
            (*pcVar5)(uVar4, 0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020369f;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020370e;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802035d9
// Address: 0x1802035d9
// Size: 28 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

void fcn.180203570(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020357c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar7 = *(uint64_t *)(in_RCX + 0x150);
    if (((((uVar7 == 0) || (*(uint64_t *)(in_RCX + 0x158) < uVar7)) &&
         (uVar7 = *(uint64_t *)(in_RCX + 0x158), uVar7 == 0)) || (*(uint64_t *)(in_RCX + 0x160) < uVar7)) &&
       (iVar8 = *(int64_t *)(in_RCX + 0x160), *(undefined4 *)((int64_t)&var_18h + iVar6) = 2, iVar8 == 0)) {
        if (*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) == 0) {
            if (*(char *)(in_RCX + 0x1cb) == '\0') {
                *(int32_t *)(in_RCX + 0x1d4) = *(int32_t *)(in_RCX + 0x1d4) + 1;
            } else {
                *(int32_t *)(in_RCX + 0x1d8) = *(int32_t *)(in_RCX + 0x1d8) + 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036e2;
            fcn.1802022a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                          *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000108 + iVar6), 
                          *(int64_t *)(&stack0x00000128 + iVar6), *(int64_t *)(&stack0x00000188 + iVar6), 
                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x00000198 + iVar6), 
                          *(int64_t *)(&stack0x000001b8 + iVar6));
            piVar2 = (int32_t *)(in_RCX + 0x1dc + (int64_t)*(int32_t *)((int64_t)&var_18h + iVar6) * 4);
            *piVar2 = *piVar2 + 1;
        }
        *(int32_t *)(in_RCX + 0x118) = *(int32_t *)(in_RCX + 0x118) + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036fc;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802035e6;
        iVar8 = fcn.1802020f0(*(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                              *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000110 + iVar6), 
                              *(int64_t *)(&stack0x00000140 + iVar6));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined (*) [16])((int64_t)&var_20h + iVar6) = ZEXT816(0);
            do {
                iVar3 = *(int64_t *)(iVar8 + 0x60);
                if ((*(uint8_t *)(iVar8 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar8 + 8);
                    if ((*(uint32_t *)(iVar8 + 0x20) & 8) != 0) {
                        piVar1 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(iVar8 + 0x20) & 3) * 8);
                        *piVar1 = *piVar1 - *(int64_t *)(iVar8 + 8);
                    }
                    uVar4 = *(undefined8 *)(in_RCX + 0x110);
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)(iVar8 + 0x10);
                    *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(iVar8 + 8);
                    pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203658;
                    (*pcVar5)(uVar4, (int64_t)&var_20h + iVar6);
                }
                pcVar5 = *(code **)(iVar8 + 0x28);
                uVar4 = *(undefined8 *)(iVar8 + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203662;
                (*pcVar5)(uVar4);
                iVar8 = iVar3;
            } while (iVar3 != 0);
            uVar4 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203680;
            func_0x0001801de220(uVar4, (int64_t)&arg_30h + iVar6);
            uVar4 = *(undefined8 *)(in_RCX + 0x110);
            pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203697;
            (*pcVar5)(uVar4, 0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020369f;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020370e;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802035f5
// Address: 0x1802035f5
// Size: 159 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

void fcn.180203570(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020357c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar7 = *(uint64_t *)(in_RCX + 0x150);
    if (((((uVar7 == 0) || (*(uint64_t *)(in_RCX + 0x158) < uVar7)) &&
         (uVar7 = *(uint64_t *)(in_RCX + 0x158), uVar7 == 0)) || (*(uint64_t *)(in_RCX + 0x160) < uVar7)) &&
       (iVar8 = *(int64_t *)(in_RCX + 0x160), *(undefined4 *)((int64_t)&var_18h + iVar6) = 2, iVar8 == 0)) {
        if (*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) == 0) {
            if (*(char *)(in_RCX + 0x1cb) == '\0') {
                *(int32_t *)(in_RCX + 0x1d4) = *(int32_t *)(in_RCX + 0x1d4) + 1;
            } else {
                *(int32_t *)(in_RCX + 0x1d8) = *(int32_t *)(in_RCX + 0x1d8) + 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036e2;
            fcn.1802022a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                          *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000108 + iVar6), 
                          *(int64_t *)(&stack0x00000128 + iVar6), *(int64_t *)(&stack0x00000188 + iVar6), 
                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x00000198 + iVar6), 
                          *(int64_t *)(&stack0x000001b8 + iVar6));
            piVar2 = (int32_t *)(in_RCX + 0x1dc + (int64_t)*(int32_t *)((int64_t)&var_18h + iVar6) * 4);
            *piVar2 = *piVar2 + 1;
        }
        *(int32_t *)(in_RCX + 0x118) = *(int32_t *)(in_RCX + 0x118) + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036fc;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802035e6;
        iVar8 = fcn.1802020f0(*(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                              *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000110 + iVar6), 
                              *(int64_t *)(&stack0x00000140 + iVar6));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined (*) [16])((int64_t)&var_20h + iVar6) = ZEXT816(0);
            do {
                iVar3 = *(int64_t *)(iVar8 + 0x60);
                if ((*(uint8_t *)(iVar8 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar8 + 8);
                    if ((*(uint32_t *)(iVar8 + 0x20) & 8) != 0) {
                        piVar1 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(iVar8 + 0x20) & 3) * 8);
                        *piVar1 = *piVar1 - *(int64_t *)(iVar8 + 8);
                    }
                    uVar4 = *(undefined8 *)(in_RCX + 0x110);
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)(iVar8 + 0x10);
                    *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(iVar8 + 8);
                    pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203658;
                    (*pcVar5)(uVar4, (int64_t)&var_20h + iVar6);
                }
                pcVar5 = *(code **)(iVar8 + 0x28);
                uVar4 = *(undefined8 *)(iVar8 + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203662;
                (*pcVar5)(uVar4);
                iVar8 = iVar3;
            } while (iVar3 != 0);
            uVar4 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203680;
            func_0x0001801de220(uVar4, (int64_t)&arg_30h + iVar6);
            uVar4 = *(undefined8 *)(in_RCX + 0x110);
            pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203697;
            (*pcVar5)(uVar4, 0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020369f;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020370e;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180203694
// Address: 0x180203694
// Size: 21 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

void fcn.180203570(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020357c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar7 = *(uint64_t *)(in_RCX + 0x150);
    if (((((uVar7 == 0) || (*(uint64_t *)(in_RCX + 0x158) < uVar7)) &&
         (uVar7 = *(uint64_t *)(in_RCX + 0x158), uVar7 == 0)) || (*(uint64_t *)(in_RCX + 0x160) < uVar7)) &&
       (iVar8 = *(int64_t *)(in_RCX + 0x160), *(undefined4 *)((int64_t)&var_18h + iVar6) = 2, iVar8 == 0)) {
        if (*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) == 0) {
            if (*(char *)(in_RCX + 0x1cb) == '\0') {
                *(int32_t *)(in_RCX + 0x1d4) = *(int32_t *)(in_RCX + 0x1d4) + 1;
            } else {
                *(int32_t *)(in_RCX + 0x1d8) = *(int32_t *)(in_RCX + 0x1d8) + 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036e2;
            fcn.1802022a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                          *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000108 + iVar6), 
                          *(int64_t *)(&stack0x00000128 + iVar6), *(int64_t *)(&stack0x00000188 + iVar6), 
                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x00000198 + iVar6), 
                          *(int64_t *)(&stack0x000001b8 + iVar6));
            piVar2 = (int32_t *)(in_RCX + 0x1dc + (int64_t)*(int32_t *)((int64_t)&var_18h + iVar6) * 4);
            *piVar2 = *piVar2 + 1;
        }
        *(int32_t *)(in_RCX + 0x118) = *(int32_t *)(in_RCX + 0x118) + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036fc;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802035e6;
        iVar8 = fcn.1802020f0(*(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                              *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000110 + iVar6), 
                              *(int64_t *)(&stack0x00000140 + iVar6));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined (*) [16])((int64_t)&var_20h + iVar6) = ZEXT816(0);
            do {
                iVar3 = *(int64_t *)(iVar8 + 0x60);
                if ((*(uint8_t *)(iVar8 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar8 + 8);
                    if ((*(uint32_t *)(iVar8 + 0x20) & 8) != 0) {
                        piVar1 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(iVar8 + 0x20) & 3) * 8);
                        *piVar1 = *piVar1 - *(int64_t *)(iVar8 + 8);
                    }
                    uVar4 = *(undefined8 *)(in_RCX + 0x110);
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)(iVar8 + 0x10);
                    *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(iVar8 + 8);
                    pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203658;
                    (*pcVar5)(uVar4, (int64_t)&var_20h + iVar6);
                }
                pcVar5 = *(code **)(iVar8 + 0x28);
                uVar4 = *(undefined8 *)(iVar8 + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203662;
                (*pcVar5)(uVar4);
                iVar8 = iVar3;
            } while (iVar3 != 0);
            uVar4 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203680;
            func_0x0001801de220(uVar4, (int64_t)&arg_30h + iVar6);
            uVar4 = *(undefined8 *)(in_RCX + 0x110);
            pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203697;
            (*pcVar5)(uVar4, 0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020369f;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020370e;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1802036a9
// Address: 0x1802036a9
// Size: 107 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_930h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_1c9h
// WARNING: [rz-ghidra] Detected overlap for variable arg_1cbh

void fcn.180203570(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020357c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    uVar7 = *(uint64_t *)(in_RCX + 0x150);
    if (((((uVar7 == 0) || (*(uint64_t *)(in_RCX + 0x158) < uVar7)) &&
         (uVar7 = *(uint64_t *)(in_RCX + 0x158), uVar7 == 0)) || (*(uint64_t *)(in_RCX + 0x160) < uVar7)) &&
       (iVar8 = *(int64_t *)(in_RCX + 0x160), *(undefined4 *)((int64_t)&var_18h + iVar6) = 2, iVar8 == 0)) {
        if (*(int64_t *)(in_RCX + 0x1a8) + *(int64_t *)(in_RCX + 0x1a0) + *(int64_t *)(in_RCX + 0x198) == 0) {
            if (*(char *)(in_RCX + 0x1cb) == '\0') {
                *(int32_t *)(in_RCX + 0x1d4) = *(int32_t *)(in_RCX + 0x1d4) + 1;
            } else {
                *(int32_t *)(in_RCX + 0x1d8) = *(int32_t *)(in_RCX + 0x1d8) + 1;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036e2;
            fcn.1802022a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                          *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000108 + iVar6), 
                          *(int64_t *)(&stack0x00000128 + iVar6), *(int64_t *)(&stack0x00000188 + iVar6), 
                          *(int64_t *)(&stack0x00000190 + iVar6), *(int64_t *)(&stack0x00000198 + iVar6), 
                          *(int64_t *)(&stack0x000001b8 + iVar6));
            piVar2 = (int32_t *)(in_RCX + 0x1dc + (int64_t)*(int32_t *)((int64_t)&var_18h + iVar6) * 4);
            *piVar2 = *piVar2 + 1;
        }
        *(int32_t *)(in_RCX + 0x118) = *(int32_t *)(in_RCX + 0x118) + 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802036fc;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&arg_78h + iVar6) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802035e6;
        iVar8 = fcn.1802020f0(*(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)(&stack0x000000e0 + iVar6), 
                              *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x00000110 + iVar6), 
                              *(int64_t *)(&stack0x00000140 + iVar6));
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&arg_70h + iVar6) = unaff_RSI;
            *(undefined (*) [16])((int64_t)&var_20h + iVar6) = ZEXT816(0);
            do {
                iVar3 = *(int64_t *)(iVar8 + 0x60);
                if ((*(uint8_t *)(iVar8 + 0x20) & 4) != 0) {
                    *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) - *(int64_t *)(iVar8 + 8);
                    if ((*(uint32_t *)(iVar8 + 0x20) & 8) != 0) {
                        piVar1 = (int64_t *)(in_RCX + 0x198 + (uint64_t)(*(uint32_t *)(iVar8 + 0x20) & 3) * 8);
                        *piVar1 = *piVar1 - *(int64_t *)(iVar8 + 8);
                    }
                    uVar4 = *(undefined8 *)(in_RCX + 0x110);
                    *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)(iVar8 + 0x10);
                    *(undefined8 *)((int64_t)&arg_28h + iVar6) = *(undefined8 *)(iVar8 + 8);
                    pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x50);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203658;
                    (*pcVar5)(uVar4, (int64_t)&var_20h + iVar6);
                }
                pcVar5 = *(code **)(iVar8 + 0x28);
                uVar4 = *(undefined8 *)(iVar8 + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203662;
                (*pcVar5)(uVar4);
                iVar8 = iVar3;
            } while (iVar3 != 0);
            uVar4 = *(undefined8 *)(in_RCX + 0x100);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203680;
            func_0x0001801de220(uVar4, (int64_t)&arg_30h + iVar6);
            uVar4 = *(undefined8 *)(in_RCX + 0x110);
            pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203697;
            (*pcVar5)(uVar4, 0);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020369f;
        fcn.180202500(*(int64_t *)((int64_t)&var_18h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020370e;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180203720
// Address: 0x180203720
// Size: 367 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180203720(int64_t arg_28h, int64_t arg_30h)
{
    int64_t *piVar1;
    uint32_t uVar2;
    uint64_t *puVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    uint64_t **in_RDX;
    uint64_t **ppuVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180203735;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar2 = *(uint32_t *)(in_RDX + 4);
    ppuVar8 = (uint64_t **)((uint64_t)(uVar2 & 3) * 0x30 + in_RCX);
    if (((((in_RDX[2] != (uint64_t *)0x0) && (*(uint64_t **)(in_RCX + 0x138 + (uint64_t)(uVar2 & 3) * 8) <= in_RDX[2]))
         && (in_RDX[1] != (uint64_t *)0x0)) && (((uVar2 & 4) != 0 || ((uVar2 & 8) == 0)))) && (ppuVar8[4] <= *in_RDX)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802037a3;
        iVar7 = fcn.180229240(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
        if (((iVar7 == 0) && (in_RDX[9] == (uint64_t *)0x0)) && (in_RDX[10] == (uint64_t *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1802037cc;
            fcn.180228fb0(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)(&stack0x00000038 + iVar6));
            if (ppuVar8[1] != (uint64_t *)0x0) {
                ppuVar8[1][9] = (uint64_t)in_RDX;
            }
            in_RDX[10] = ppuVar8[1];
            in_RDX[9] = (uint64_t *)0x0;
            ppuVar8[1] = (uint64_t *)in_RDX;
            if (*ppuVar8 == (uint64_t *)0x0) {
                *ppuVar8 = (uint64_t *)in_RDX;
            }
            ppuVar8[2] = (uint64_t *)((int64_t)ppuVar8[2] + 1);
            ppuVar8[4] = (uint64_t *)((int64_t)*in_RDX + 1);
            ppuVar8[5] = *in_RDX;
            uVar2 = *(uint32_t *)(in_RDX + 4);
            if ((uVar2 & 4) != 0) {
                if ((uVar2 & 8) != 0) {
                    *(uint64_t **)(in_RCX + 0x138 + (uint64_t)(uVar2 & 3) * 8) = in_RDX[2];
                    piVar1 = (int64_t *)(in_RCX + (uint64_t)(*(uint32_t *)(in_RDX + 4) & 3) * 8 + 0x198);
                    *piVar1 = *piVar1 + (int64_t)in_RDX[1];
                }
                *(int64_t *)(in_RCX + 400) = *(int64_t *)(in_RCX + 400) + (int64_t)in_RDX[1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x18020384f;
                fcn.180202500(*(int64_t *)((int64_t)aiStackX_18 + iVar6));
                puVar3 = in_RDX[1];
                uVar4 = *(undefined8 *)(in_RCX + 0x110);
                pcVar5 = *(code **)(*(int64_t *)(in_RCX + 0x108) + 0x40);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180203868;
                (*pcVar5)(uVar4, puVar3);
            }
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802038b0
// Address: 0x1802038b0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1802038b0(int64_t arg_28h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802038c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_28h + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    if (*(uint64_t *)(in_RCX + 0x18) < in_RDX) {
        *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
        *(uint64_t *)((int64_t)&var_20h + iVar2) = in_RDX - 1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802038fa;
        iVar1 = func_0x00018020b3b0();
        if (iVar1 == 1) {
            *(uint64_t *)(in_RCX + 0x18) = in_RDX;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180203919;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_28h + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180203930
// Address: 0x180203930
// Size: 164 bytes
// ============================================================
undefined8 fcn.180203930(int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    undefined8 in_RDX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18020393c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_88h + iVar1) = in_RDX;
    *(undefined8 *)((int64_t)&iStackX_20 + iVar1 + -8) = in_RDX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18020395d;
    iVar2 = fcn.180229240(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    if (*in_RCX == iVar2) {
        *in_RCX = *(int64_t *)(iVar2 + 0x48);
    }
    if (in_RCX[1] == iVar2) {
        in_RCX[1] = *(int64_t *)(iVar2 + 0x50);
    }
    if (*(int64_t *)(iVar2 + 0x50) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar2 + 0x50) + 0x48) = *(undefined8 *)(iVar2 + 0x48);
    }
    if (*(int64_t *)(iVar2 + 0x48) != 0) {
        *(undefined8 *)(*(int64_t *)(iVar2 + 0x48) + 0x50) = *(undefined8 *)(iVar2 + 0x50);
    }
    in_RCX[2] = in_RCX[2] + -1;
    *(undefined (*) [16])(iVar2 + 0x48) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802039c6;
    fcn.180228b10(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1));
    return 1;
}

// ============================================================
// Function: FUN_180203a40
// Address: 0x180203a40
// Size: 23 bytes
// ============================================================
void fcn.180203a40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180203a54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        iVar4 = *(int64_t *)arg1;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            do {
                uVar1 = *(undefined8 *)(iVar4 + 0x90);
                iVar2 = *(int64_t *)(iVar4 + 0x88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203a90;
                fcn.180224990(uVar1, 0x1804b9950, 0x33);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203aa5;
                fcn.180224990(iVar4, 0x1804b9950, 0x34);
                iVar4 = iVar2;
            } while (iVar2 != 0);
        }
        *(int64_t *)(arg1 + 8) = 0;
        *(int64_t *)arg1 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203ad0;
        fcn.180224990(arg1, 0x1804b9950, 0x41);
    }
    return;
}

// ============================================================
// Function: FUN_180203a57
// Address: 0x180203a57
// Size: 16 bytes
// ============================================================
void fcn.180203a40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180203a54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        iVar4 = *(int64_t *)arg1;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            do {
                uVar1 = *(undefined8 *)(iVar4 + 0x90);
                iVar2 = *(int64_t *)(iVar4 + 0x88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203a90;
                fcn.180224990(uVar1, 0x1804b9950, 0x33);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203aa5;
                fcn.180224990(iVar4, 0x1804b9950, 0x34);
                iVar4 = iVar2;
            } while (iVar2 != 0);
        }
        *(int64_t *)(arg1 + 8) = 0;
        *(int64_t *)arg1 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203ad0;
        fcn.180224990(arg1, 0x1804b9950, 0x41);
    }
    return;
}

// ============================================================
// Function: FUN_180203a67
// Address: 0x180203a67
// Size: 75 bytes
// ============================================================
void fcn.180203a40(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_60h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t iVar4;
    undefined8 unaff_RDI;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180203a54;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        iVar4 = *(int64_t *)arg1;
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RDI;
            do {
                uVar1 = *(undefined8 *)(iVar4 + 0x90);
                iVar2 = *(int64_t *)(iVar4 + 0x88);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203a90;
                fcn.180224990(uVar1, 0x1804b9950, 0x33);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203aa5;
                fcn.180224990(iVar4, 0x1804b9950, 0x34);
                iVar4 = iVar2;
            } while (iVar2 != 0);
        }
        *(int64_t *)(arg1 + 8) = 0;
        *(int64_t *)arg1 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180203ad0;
        fcn.180224990(arg1, 0x1804b9950, 0x41);
    }
    return;
}

