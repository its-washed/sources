// Chunk 147 - 50 functions

// ============================================================
// Function: FUN_1801f2b17
// Address: 0x1801f2b17
// Size: 199 bytes
// ============================================================
undefined8 fcn.1801f2b17(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    
    iVar1 = func_0x000180222010();
    iVar5 = 0;
    if (0 < iVar1) {
        do {
            iVar3 = func_0x000180222340();
            if ((iVar3 == 0) || (iVar2 = func_0x0001802446f0(), iVar2 == 0)) {
                func_0x000180229480();
                uVar4 = 0x1f8;
                goto code_r0x0001801f2b9f;
            }
            iVar5 = iVar5 + 1;
        } while (iVar5 < iVar1);
    }
    iVar1 = func_0x000180244000();
    if (((iVar1 != 0) && (iVar1 = func_0x0001802446f0(), iVar1 != 0)) && (iVar1 = func_0x000180244000(), iVar1 != 0)) {
        return 1;
    }
    func_0x000180229480();
    uVar4 = 0x200;
code_r0x0001801f2b9f:
    func_0x0001802295a0(0x1804b7ba0, uVar4, 0x1804b7d48);
    func_0x00018019b5e0();
    return 0;
}

// ============================================================
// Function: FUN_1801f2bde
// Address: 0x1801f2bde
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_30h
// WARNING: Variable defined which should be unmapped: arg_38h

undefined8 fcn.1801f2b17(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    
    iVar1 = func_0x000180222010();
    iVar5 = 0;
    if (0 < iVar1) {
        do {
            iVar3 = func_0x000180222340();
            if ((iVar3 == 0) || (iVar2 = func_0x0001802446f0(), iVar2 == 0)) {
                func_0x000180229480();
                uVar4 = 0x1f8;
                goto code_r0x0001801f2b9f;
            }
            iVar5 = iVar5 + 1;
        } while (iVar5 < iVar1);
    }
    iVar1 = func_0x000180244000();
    if (((iVar1 != 0) && (iVar1 = func_0x0001802446f0(), iVar1 != 0)) && (iVar1 = func_0x000180244000(), iVar1 != 0)) {
        return 1;
    }
    func_0x000180229480();
    uVar4 = 0x200;
code_r0x0001801f2b9f:
    func_0x0001802295a0(0x1804b7ba0, uVar4, 0x1804b7d48);
    func_0x00018019b5e0();
    return 0;
}

// ============================================================
// Function: FUN_1801f2bf1
// Address: 0x1801f2bf1
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801f2bf1(int64_t arg_40h, int64_t arg_48h)
{
    int64_t in_stack_00000020;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t in_stack_00000038;
    int64_t in_stack_00000050;
    
    fcn.180229480(in_stack_00000020, in_stack_00000028);
    fcn.1802295a0(in_stack_00000020, in_stack_00000028, in_stack_00000030, in_stack_00000038, in_stack_00000050);
    fcn.18019b5e0(arg_40h);
    return 0;
}

// ============================================================
// Function: FUN_1801f2c40
// Address: 0x1801f2c40
// Size: 94 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2c9e
// Address: 0x1801f2c9e
// Size: 130 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2d20
// Address: 0x1801f2d20
// Size: 256 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2e20
// Address: 0x1801f2e20
// Size: 23 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2e37
// Address: 0x1801f2e37
// Size: 220 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2f13
// Address: 0x1801f2f13
// Size: 58 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2f4d
// Address: 0x1801f2f4d
// Size: 71 bytes
// ============================================================
undefined8 fcn.1801f2c40(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    uint8_t uVar1;
    uint8_t uVar2;
    uint8_t *puVar3;
    int64_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t in_RCX;
    uint8_t **in_RDX;
    undefined8 unaff_RBX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    uint64_t uVar11;
    undefined8 unaff_RSI;
    uint8_t *puVar12;
    uint8_t *puVar13;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_18;
    
    uStack_18 = 0x1801f2c4e;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (*(int32_t *)(in_RCX + 0x4d8) == 0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c65;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c7d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2c90;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar12 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + -8) = unaff_R15;
    if (puVar12 < (uint8_t *)0x2) {
code_r0x0001801f2f4d:
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f52;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f6a;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f80;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    puVar3 = *in_RDX;
    puVar13 = puVar12 + -2;
    uVar1 = *puVar3;
    uVar2 = puVar3[1];
    *in_RDX = puVar3 + 2;
    in_RDX[1] = puVar13;
    if ((puVar13 != (uint8_t *)(uint64_t)CONCAT11(uVar1, uVar2)) || (puVar13 == (uint8_t *)0x0))
    goto code_r0x0001801f2f4d;
    uVar1 = puVar3[2];
    in_RDX[1] = puVar12 + -3;
    *in_RDX = puVar3 + 3;
    uVar11 = (uint64_t)uVar1;
    if (puVar12 + -3 != (uint8_t *)(uint64_t)uVar1) goto code_r0x0001801f2f4d;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = unaff_RBX;
    uVar10 = *(uint64_t *)(in_RCX + 0xaf8);
    if (0x7fffffffffffffff < uVar10) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f18;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f30;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                      *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                      *(int64_t *)((int64_t)&arg_40h + iVar6));
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f46;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RSI;
    puVar12 = *(uint8_t **)(in_RCX + 0xaf0);
    do {
        do {
            if (uVar10 == 0) {
code_r0x0001801f2efd:
                *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2f02;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar6));
                goto code_r0x0001801f2df7;
            }
            uVar7 = (uint64_t)*puVar12;
            puVar13 = puVar12 + 1;
            if (uVar10 - 1 < uVar7) goto code_r0x0001801f2efd;
            uVar10 = (uVar10 - 1) - uVar7;
            puVar12 = puVar13 + uVar7;
        } while (uVar7 != uVar11);
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d63;
        iVar5 = fcn.180497f30(puVar3 + 3, puVar13, uVar11);
    } while (iVar5 != 0);
    uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d80;
    fcn.180224990(uVar9, 0x1804b7ba0, 0x6b2);
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2d95;
    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    *(int64_t *)(in_RCX + 0x4b8) = iVar8;
    if (iVar8 == 0) {
        *(undefined8 *)(in_RCX + 0x4c0) = 0;
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2daf;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2de2;
        iVar5 = fcn.1801b4900(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2deb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
code_r0x0001801f2df7:
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e03;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                          *(int64_t *)((int64_t)&arg_40h + iVar6));
            goto code_r0x0001801f2e0e;
        }
        iVar8 = *(int64_t *)(in_RCX + 0x8f8);
        *(uint64_t *)(in_RCX + 0x4c0) = uVar11;
        iVar4 = *(int64_t *)(iVar8 + 0x340);
        if ((iVar4 == 0) || (*(uint64_t *)(iVar8 + 0x348) != uVar11)) {
code_r0x0001801f2e6f:
            *(undefined4 *)(in_RCX + 0xb1c) = 0;
        } else {
            uVar9 = *(undefined8 *)(in_RCX + 0x4b8);
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e6b;
            iVar5 = fcn.180497f30(iVar4, uVar9, uVar11);
            if (iVar5 != 0) goto code_r0x0001801f2e6f;
        }
        if (*(int32_t *)(in_RCX + 0x508) != 0) {
            return 1;
        }
        if (*(int64_t *)(iVar8 + 0x340) == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2eb1;
            uVar9 = fcn.180223170(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8));
            *(undefined8 *)(*(int64_t *)(in_RCX + 0x8f8) + 0x340) = uVar9;
            iVar8 = *(int64_t *)(in_RCX + 0x8f8);
            if (*(int64_t *)(iVar8 + 0x340) != 0) {
                *(undefined8 *)(iVar8 + 0x348) = *(undefined8 *)(in_RCX + 0x4c0);
                return 1;
            }
            *(undefined8 *)(iVar8 + 0x348) = 0;
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2edb;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e8b;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6));
        }
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2dc7;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6 + -8), *(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6), 
                  *(int64_t *)((int64_t)&arg_40h + iVar6));
code_r0x0001801f2e0e:
    *(undefined8 *)((int64_t)&uStack_18 + iVar6) = 0x1801f2e19;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f2fa0
// Address: 0x1801f2fa0
// Size: 87 bytes
// ============================================================
undefined8 fcn.1801f2fa0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2fac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fbe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fd6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fec;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb51) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f301b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3033;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3049;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1590);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3067;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f307f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3095;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x1598);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30b0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30ba;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30d2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30e8;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb50) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f2ff7
// Address: 0x1801f2ff7
// Size: 95 bytes
// ============================================================
undefined8 fcn.1801f2fa0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2fac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fbe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fd6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fec;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb51) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f301b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3033;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3049;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1590);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3067;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f307f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3095;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x1598);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30b0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30ba;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30d2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30e8;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb50) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f3056
// Address: 0x1801f3056
// Size: 76 bytes
// ============================================================
undefined8 fcn.1801f2fa0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2fac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fbe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fd6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fec;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb51) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f301b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3033;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3049;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1590);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3067;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f307f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3095;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x1598);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30b0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30ba;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30d2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30e8;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb50) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f30a2
// Address: 0x1801f30a2
// Size: 83 bytes
// ============================================================
undefined8 fcn.1801f2fa0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2fac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fbe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fd6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fec;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb51) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f301b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3033;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3049;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1590);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3067;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f307f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3095;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x1598);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30b0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30ba;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30d2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30e8;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb50) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f30f5
// Address: 0x1801f30f5
// Size: 23 bytes
// ============================================================
undefined8 fcn.1801f2fa0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f2fac;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fbe;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fd6;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f2fec;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb51) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f301b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3033;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3049;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x1590);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3067;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f307f;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f3095;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x1598);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30b0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30ba;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30d2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f30e8;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb50) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f3110
// Address: 0x1801f3110
// Size: 291 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801f3110(int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 *in_RDX;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f3125;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar5 = (undefined *)*in_RDX;
    uVar1 = in_RDX[1];
    uVar7 = in_RDX[1];
    *(undefined **)((int64_t)&var_18h + iVar6) = puVar5;
    *(undefined8 *)((int64_t)&var_20h + iVar6) = uVar1;
    if (1 < uVar7) {
        uVar7 = uVar7 - 2;
        uVar9 = (uint64_t)CONCAT11(*puVar5, puVar5[1]);
        if (uVar9 <= uVar7) {
            iVar8 = uVar7 - uVar9;
            *(undefined **)((int64_t)&var_18h + iVar6) = puVar5 + uVar9 + 2;
            *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
            if (iVar8 == 0) {
                uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar6 + 4);
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar6);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar6 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar6);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar2;
                *(undefined4 *)(in_RDX + 1) = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar4;
                uVar1 = *(undefined8 *)(in_RCX + 0xb20);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3199;
                fcn.180224990(uVar1, 0x1804a9450, 0x1d9);
                *(undefined8 *)(in_RCX + 0xb20) = 0;
                *(undefined8 *)(in_RCX + 0xb28) = 0;
                if (uVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f31c6;
                    iVar8 = fcn.180223170(*(int64_t *)((int64_t)&var_18h + iVar6));
                    *(int64_t *)(in_RCX + 0xb20) = iVar8;
                    if (iVar8 == 0) goto code_r0x0001801f31ee;
                    *(uint64_t *)(in_RCX + 0xb28) = uVar9;
                }
                return 1;
            }
        }
    }
code_r0x0001801f31ee:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f31f3;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f320b;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3221;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f3240
// Address: 0x1801f3240
// Size: 418 bytes
// ============================================================
undefined8 fcn.1801f3240(int64_t param_1, int64_t *param_2, int32_t param_3)
{
    uint64_t uVar1;
    undefined *puVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f324c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = param_2[1];
    if (param_3 != 0x2000) {
        if (uVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f334a;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f3362;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f3378;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
            return 0;
        }
        if ((*(int32_t *)(param_1 + 0xb1c) != 0) && (*(int32_t *)(param_1 + 0x508) != 0)) {
            *(undefined4 *)(param_1 + 0xb18) = 2;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f33ac;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f33c4;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
code_r0x0001801f33ca:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f33da;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
        return 0;
    }
    if (3 < uVar1) {
        puVar2 = (undefined *)*param_2;
        iVar4 = CONCAT31(CONCAT21(CONCAT11(*puVar2, puVar2[1]), puVar2[2]), puVar2[3]);
        *param_2 = (int64_t)(puVar2 + 4);
        param_2[1] = uVar1 - 4;
        if (uVar1 - 4 == 0) {
            *(int32_t *)(*(int64_t *)(param_1 + 0x8f8) + 0x338) = iVar4;
            if ((*(uint32_t *)(param_1 + 0x160) & 0x2000) == 0) {
                return 1;
            }
            if (iVar4 == -1) {
                return 1;
            }
            *(undefined4 *)(*(int64_t *)(param_1 + 0x8f8) + 0x338) = 1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f32e2;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f32fa;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
            goto code_r0x0001801f33ca;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f330a;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f3322;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)(&stack0x00000048 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f3338;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_1801f33f0
// Address: 0x1801f33f0
// Size: 390 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1801f33f0(int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    uint8_t *puVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint8_t *puVar7;
    int64_t iVar8;
    uint8_t **in_RDX;
    uint8_t *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f3405;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar5 = *in_RDX;
    puVar9 = in_RDX[1];
    puVar7 = in_RDX[1];
    *(uint8_t **)((int64_t)&var_18h + iVar6) = puVar5;
    *(uint8_t **)((int64_t)&var_20h + iVar6) = puVar9;
    if (puVar7 != (uint8_t *)0x0) {
        puVar7 = puVar7 + -1;
        puVar9 = (uint8_t *)(uint64_t)*puVar5;
        if (puVar9 <= puVar7) {
            iVar8 = (int64_t)puVar7 - (int64_t)puVar9;
            *(uint8_t **)((int64_t)&var_18h + iVar6) = puVar9 + (int64_t)(puVar5 + 1);
            *(int64_t *)((int64_t)&var_20h + iVar6) = iVar8;
            if (iVar8 == 0) {
                uVar2 = *(undefined4 *)((int64_t)&var_18h + iVar6 + 4);
                uVar3 = *(undefined4 *)((int64_t)&var_20h + iVar6);
                uVar4 = *(undefined4 *)((int64_t)&var_20h + iVar6 + 4);
                *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_18h + iVar6);
                *(undefined4 *)((int64_t)in_RDX + 4) = uVar2;
                *(undefined4 *)(in_RDX + 1) = uVar3;
                *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar4;
                if (*(int32_t *)(in_RCX + 0x508) != 0) {
                    return 1;
                }
                if (puVar9 == (uint8_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f346e;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3486;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                } else {
                    uVar1 = *(undefined8 *)(in_RCX + 0xa80);
                    *(undefined8 *)(in_RCX + 0xa78) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f34b5;
                    fcn.180224990(uVar1, 0x1804b7ba0, 0x5a6);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f34ca;
                    iVar8 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(int64_t *)(in_RCX + 0xa80) = iVar8;
                    if (iVar8 != 0) {
                        *(uint8_t **)(in_RCX + 0xa78) = puVar9;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f351c;
                        fcn.180498030(iVar8, puVar5 + 1, puVar9);
                        return 1;
                    }
                    *(undefined8 *)(in_RCX + 0xa78) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f34e2;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f34fa;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                }
                goto code_r0x0001801f3559;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3536;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f354e;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
code_r0x0001801f3559:
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3564;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f3600
// Address: 0x1801f3600
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f3600(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined *puVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint16_t *puVar13;
    uint64_t uVar14;
    int64_t *in_RDX;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    uint64_t uVar18;
    uint32_t uVar19;
    undefined8 unaff_RSI;
    int64_t *piVar20;
    undefined8 unaff_RDI;
    uint32_t in_R8D;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801f360e;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    if ((*(int64_t *)(in_RCX + 0x308) == 0) || (*(int64_t *)(in_RCX + 0x4e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b6b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b83;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b99;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    if ((uint64_t)in_RDX[1] < 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b2e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b46;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b5c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    puVar4 = (undefined *)*in_RDX;
    iVar15 = in_RDX[1] - 2;
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = unaff_RDI;
    uVar18 = 0;
    uVar2 = *puVar4;
    uVar3 = puVar4[1];
    uVar7 = CONCAT11(uVar2, uVar3);
    uVar19 = (uint32_t)uVar7;
    in_RDX[1] = iVar15;
    *in_RDX = (int64_t)(puVar4 + 2);
    if ((in_R8D >> 0xb & 1) == 0) {
        if (*(uint64_t *)(in_RCX + 0x338) != 0) {
            puVar13 = (uint16_t *)(in_RCX + 0x330);
            do {
                if (*puVar13 == uVar19) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x310 + uVar18 * 8);
                    *(undefined8 *)(in_RCX + 0x308) = uVar5;
                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                    if (uVar7 != 0) {
                        iVar15 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        } else if (uVar19 != *(uint32_t *)(iVar15 + 0x304)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38cf;
                            iVar15 = func_0x00018019dc20(iVar15, 0);
                            if (iVar15 == 0) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38dc;
                                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38f4;
                                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12), 
                                              *(int64_t *)((int64_t)&var_20h + iVar12), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                              *(int64_t *)(&stack0x00000040 + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f390a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                                return 0;
                            }
                            uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f391d;
                            func_0x00018019c980(uVar6);
                            *(int64_t *)(in_RCX + 0x8f8) = iVar15;
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        }
                        uVar6 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3936;
                        iVar15 = func_0x0001801ab700(uVar6, CONCAT11(uVar2, uVar3));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3943;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f395b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3971;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        puVar4 = (undefined *)*in_RDX;
                        iVar17 = in_RDX[1];
                        uVar18 = in_RDX[1];
                        *(undefined8 *)((int64_t)&arg_30h + iVar12) = unaff_R15;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar4;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (uVar18 < 2) {
code_r0x0001801f3af4:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3af9;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b11;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b27;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        uVar18 = uVar18 - 2;
                        puVar1 = puVar4 + 2;
                        uVar16 = (uint64_t)CONCAT11(*puVar4, puVar4[1]);
                        if (uVar18 < uVar16) goto code_r0x0001801f3af4;
                        iVar17 = uVar18 - uVar16;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar1 + uVar16;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (iVar17 != 0) goto code_r0x0001801f3af4;
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar12 + 4);
                        uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar12);
                        uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar12 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar12);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                        *(undefined4 *)(in_RDX + 1) = uVar9;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                        if (uVar16 == 0) goto code_r0x0001801f3af4;
                        if (*(char *)(iVar15 + 0x30) != '\0') {
                            *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 1;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3ae2;
                            iVar11 = func_0x0001801c5bf0(in_RCX, uVar5, puVar1, uVar16);
                            if (iVar11 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f39f0;
                        iVar15 = func_0x00018022fd80();
                        if (iVar15 == 0) {
code_r0x0001801f3a70:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a75;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a8d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a03;
                            iVar11 = func_0x00018022e6c0(iVar15, uVar5);
                            if (iVar11 < 1) goto code_r0x0001801f3a70;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a15;
                            iVar11 = func_0x0001801aa310(iVar15, puVar1, uVar16);
                            if (0 < iVar11) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a57;
                                iVar11 = func_0x0001801c5dc0(in_RCX, uVar5, iVar15, 1);
                                if (iVar11 != 0) {
                                    *(int64_t *)(in_RCX + 0x4e0) = iVar15;
                                    *(undefined *)(in_RCX + 0x4dd) = 1;
                                    return 1;
                                }
                                goto code_r0x0001801f3aa3;
                            }
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a1e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a36;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aa3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
code_r0x0001801f3aa3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aab;
                        func_0x00018022ecc0(iVar15);
                        return 0;
                    }
                    break;
                }
                uVar18 = uVar18 + 1;
                puVar13 = puVar13 + 1;
            } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3858;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3870;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3886;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0;
        if (iVar15 == 0) {
            if (*(uint64_t *)(in_RCX + 0x338) != 0) {
                puVar13 = (uint16_t *)(in_RCX + 0x330);
                uVar16 = uVar18;
                do {
                    if (*puVar13 == uVar19) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3760;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3778;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                      *(int64_t *)(&stack0x00000040 + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f378e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                        return 0;
                    }
                    uVar16 = uVar16 + 1;
                    puVar13 = puVar13 + 1;
                } while (uVar16 < *(uint64_t *)(in_RCX + 0x338));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36fa;
            func_0x0001801ab620(in_RCX, (int64_t)&arg_50h + iVar12, (int64_t)&var_20h + iVar12);
            uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar12);
            if (uVar16 != 0) {
                uVar14 = uVar18;
                do {
                    if (uVar19 == *(uint16_t *)(*(int64_t *)((int64_t)&arg_50h + iVar12) + uVar14 * 2)) {
                        if (uVar14 < uVar16) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ab;
                            iVar11 = func_0x0001801ada30(in_RCX, CONCAT11(uVar2, uVar3), 0x20004);
                            if (iVar11 != 0) {
                                *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
                                *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 0;
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37d0;
                                iVar11 = func_0x0001801adc80(in_RCX, CONCAT11(uVar2, uVar3), 0x304);
                                if (iVar11 != 0) {
                                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                                    if (*(int64_t *)(in_RCX + 0x338) != 0) {
                                        piVar20 = (int64_t *)(in_RCX + 0x310);
                                        do {
                                            if (*piVar20 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ff;
                                                func_0x00018022ecc0();
                                                *piVar20 = 0;
                                            }
                                            uVar18 = uVar18 + 1;
                                            piVar20 = piVar20 + 1;
                                        } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
                                    }
                                    *(undefined8 *)(in_RCX + 0x338) = 0;
                                    *(undefined8 *)(in_RCX + 0x308) = 0;
                                    return 1;
                                }
                            }
                        }
                        break;
                    }
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar16);
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3726;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f373e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3754;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f368a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36b8;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f3648
// Address: 0x1801f3648
// Size: 824 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f3600(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined *puVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint16_t *puVar13;
    uint64_t uVar14;
    int64_t *in_RDX;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    uint64_t uVar18;
    uint32_t uVar19;
    undefined8 unaff_RSI;
    int64_t *piVar20;
    undefined8 unaff_RDI;
    uint32_t in_R8D;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801f360e;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    if ((*(int64_t *)(in_RCX + 0x308) == 0) || (*(int64_t *)(in_RCX + 0x4e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b6b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b83;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b99;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    if ((uint64_t)in_RDX[1] < 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b2e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b46;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b5c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    puVar4 = (undefined *)*in_RDX;
    iVar15 = in_RDX[1] - 2;
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = unaff_RDI;
    uVar18 = 0;
    uVar2 = *puVar4;
    uVar3 = puVar4[1];
    uVar7 = CONCAT11(uVar2, uVar3);
    uVar19 = (uint32_t)uVar7;
    in_RDX[1] = iVar15;
    *in_RDX = (int64_t)(puVar4 + 2);
    if ((in_R8D >> 0xb & 1) == 0) {
        if (*(uint64_t *)(in_RCX + 0x338) != 0) {
            puVar13 = (uint16_t *)(in_RCX + 0x330);
            do {
                if (*puVar13 == uVar19) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x310 + uVar18 * 8);
                    *(undefined8 *)(in_RCX + 0x308) = uVar5;
                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                    if (uVar7 != 0) {
                        iVar15 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        } else if (uVar19 != *(uint32_t *)(iVar15 + 0x304)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38cf;
                            iVar15 = func_0x00018019dc20(iVar15, 0);
                            if (iVar15 == 0) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38dc;
                                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38f4;
                                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12), 
                                              *(int64_t *)((int64_t)&var_20h + iVar12), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                              *(int64_t *)(&stack0x00000040 + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f390a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                                return 0;
                            }
                            uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f391d;
                            func_0x00018019c980(uVar6);
                            *(int64_t *)(in_RCX + 0x8f8) = iVar15;
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        }
                        uVar6 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3936;
                        iVar15 = func_0x0001801ab700(uVar6, CONCAT11(uVar2, uVar3));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3943;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f395b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3971;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        puVar4 = (undefined *)*in_RDX;
                        iVar17 = in_RDX[1];
                        uVar18 = in_RDX[1];
                        *(undefined8 *)((int64_t)&arg_30h + iVar12) = unaff_R15;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar4;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (uVar18 < 2) {
code_r0x0001801f3af4:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3af9;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b11;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b27;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        uVar18 = uVar18 - 2;
                        puVar1 = puVar4 + 2;
                        uVar16 = (uint64_t)CONCAT11(*puVar4, puVar4[1]);
                        if (uVar18 < uVar16) goto code_r0x0001801f3af4;
                        iVar17 = uVar18 - uVar16;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar1 + uVar16;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (iVar17 != 0) goto code_r0x0001801f3af4;
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar12 + 4);
                        uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar12);
                        uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar12 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar12);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                        *(undefined4 *)(in_RDX + 1) = uVar9;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                        if (uVar16 == 0) goto code_r0x0001801f3af4;
                        if (*(char *)(iVar15 + 0x30) != '\0') {
                            *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 1;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3ae2;
                            iVar11 = func_0x0001801c5bf0(in_RCX, uVar5, puVar1, uVar16);
                            if (iVar11 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f39f0;
                        iVar15 = func_0x00018022fd80();
                        if (iVar15 == 0) {
code_r0x0001801f3a70:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a75;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a8d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a03;
                            iVar11 = func_0x00018022e6c0(iVar15, uVar5);
                            if (iVar11 < 1) goto code_r0x0001801f3a70;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a15;
                            iVar11 = func_0x0001801aa310(iVar15, puVar1, uVar16);
                            if (0 < iVar11) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a57;
                                iVar11 = func_0x0001801c5dc0(in_RCX, uVar5, iVar15, 1);
                                if (iVar11 != 0) {
                                    *(int64_t *)(in_RCX + 0x4e0) = iVar15;
                                    *(undefined *)(in_RCX + 0x4dd) = 1;
                                    return 1;
                                }
                                goto code_r0x0001801f3aa3;
                            }
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a1e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a36;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aa3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
code_r0x0001801f3aa3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aab;
                        func_0x00018022ecc0(iVar15);
                        return 0;
                    }
                    break;
                }
                uVar18 = uVar18 + 1;
                puVar13 = puVar13 + 1;
            } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3858;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3870;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3886;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0;
        if (iVar15 == 0) {
            if (*(uint64_t *)(in_RCX + 0x338) != 0) {
                puVar13 = (uint16_t *)(in_RCX + 0x330);
                uVar16 = uVar18;
                do {
                    if (*puVar13 == uVar19) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3760;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3778;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                      *(int64_t *)(&stack0x00000040 + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f378e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                        return 0;
                    }
                    uVar16 = uVar16 + 1;
                    puVar13 = puVar13 + 1;
                } while (uVar16 < *(uint64_t *)(in_RCX + 0x338));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36fa;
            func_0x0001801ab620(in_RCX, (int64_t)&arg_50h + iVar12, (int64_t)&var_20h + iVar12);
            uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar12);
            if (uVar16 != 0) {
                uVar14 = uVar18;
                do {
                    if (uVar19 == *(uint16_t *)(*(int64_t *)((int64_t)&arg_50h + iVar12) + uVar14 * 2)) {
                        if (uVar14 < uVar16) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ab;
                            iVar11 = func_0x0001801ada30(in_RCX, CONCAT11(uVar2, uVar3), 0x20004);
                            if (iVar11 != 0) {
                                *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
                                *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 0;
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37d0;
                                iVar11 = func_0x0001801adc80(in_RCX, CONCAT11(uVar2, uVar3), 0x304);
                                if (iVar11 != 0) {
                                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                                    if (*(int64_t *)(in_RCX + 0x338) != 0) {
                                        piVar20 = (int64_t *)(in_RCX + 0x310);
                                        do {
                                            if (*piVar20 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ff;
                                                func_0x00018022ecc0();
                                                *piVar20 = 0;
                                            }
                                            uVar18 = uVar18 + 1;
                                            piVar20 = piVar20 + 1;
                                        } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
                                    }
                                    *(undefined8 *)(in_RCX + 0x338) = 0;
                                    *(undefined8 *)(in_RCX + 0x308) = 0;
                                    return 1;
                                }
                            }
                        }
                        break;
                    }
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar16);
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3726;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f373e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3754;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f368a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36b8;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f3980
// Address: 0x1801f3980
// Size: 306 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f3600(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined *puVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint16_t *puVar13;
    uint64_t uVar14;
    int64_t *in_RDX;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    uint64_t uVar18;
    uint32_t uVar19;
    undefined8 unaff_RSI;
    int64_t *piVar20;
    undefined8 unaff_RDI;
    uint32_t in_R8D;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801f360e;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    if ((*(int64_t *)(in_RCX + 0x308) == 0) || (*(int64_t *)(in_RCX + 0x4e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b6b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b83;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b99;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    if ((uint64_t)in_RDX[1] < 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b2e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b46;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b5c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    puVar4 = (undefined *)*in_RDX;
    iVar15 = in_RDX[1] - 2;
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = unaff_RDI;
    uVar18 = 0;
    uVar2 = *puVar4;
    uVar3 = puVar4[1];
    uVar7 = CONCAT11(uVar2, uVar3);
    uVar19 = (uint32_t)uVar7;
    in_RDX[1] = iVar15;
    *in_RDX = (int64_t)(puVar4 + 2);
    if ((in_R8D >> 0xb & 1) == 0) {
        if (*(uint64_t *)(in_RCX + 0x338) != 0) {
            puVar13 = (uint16_t *)(in_RCX + 0x330);
            do {
                if (*puVar13 == uVar19) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x310 + uVar18 * 8);
                    *(undefined8 *)(in_RCX + 0x308) = uVar5;
                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                    if (uVar7 != 0) {
                        iVar15 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        } else if (uVar19 != *(uint32_t *)(iVar15 + 0x304)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38cf;
                            iVar15 = func_0x00018019dc20(iVar15, 0);
                            if (iVar15 == 0) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38dc;
                                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38f4;
                                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12), 
                                              *(int64_t *)((int64_t)&var_20h + iVar12), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                              *(int64_t *)(&stack0x00000040 + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f390a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                                return 0;
                            }
                            uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f391d;
                            func_0x00018019c980(uVar6);
                            *(int64_t *)(in_RCX + 0x8f8) = iVar15;
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        }
                        uVar6 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3936;
                        iVar15 = func_0x0001801ab700(uVar6, CONCAT11(uVar2, uVar3));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3943;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f395b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3971;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        puVar4 = (undefined *)*in_RDX;
                        iVar17 = in_RDX[1];
                        uVar18 = in_RDX[1];
                        *(undefined8 *)((int64_t)&arg_30h + iVar12) = unaff_R15;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar4;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (uVar18 < 2) {
code_r0x0001801f3af4:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3af9;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b11;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b27;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        uVar18 = uVar18 - 2;
                        puVar1 = puVar4 + 2;
                        uVar16 = (uint64_t)CONCAT11(*puVar4, puVar4[1]);
                        if (uVar18 < uVar16) goto code_r0x0001801f3af4;
                        iVar17 = uVar18 - uVar16;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar1 + uVar16;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (iVar17 != 0) goto code_r0x0001801f3af4;
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar12 + 4);
                        uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar12);
                        uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar12 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar12);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                        *(undefined4 *)(in_RDX + 1) = uVar9;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                        if (uVar16 == 0) goto code_r0x0001801f3af4;
                        if (*(char *)(iVar15 + 0x30) != '\0') {
                            *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 1;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3ae2;
                            iVar11 = func_0x0001801c5bf0(in_RCX, uVar5, puVar1, uVar16);
                            if (iVar11 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f39f0;
                        iVar15 = func_0x00018022fd80();
                        if (iVar15 == 0) {
code_r0x0001801f3a70:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a75;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a8d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a03;
                            iVar11 = func_0x00018022e6c0(iVar15, uVar5);
                            if (iVar11 < 1) goto code_r0x0001801f3a70;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a15;
                            iVar11 = func_0x0001801aa310(iVar15, puVar1, uVar16);
                            if (0 < iVar11) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a57;
                                iVar11 = func_0x0001801c5dc0(in_RCX, uVar5, iVar15, 1);
                                if (iVar11 != 0) {
                                    *(int64_t *)(in_RCX + 0x4e0) = iVar15;
                                    *(undefined *)(in_RCX + 0x4dd) = 1;
                                    return 1;
                                }
                                goto code_r0x0001801f3aa3;
                            }
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a1e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a36;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aa3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
code_r0x0001801f3aa3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aab;
                        func_0x00018022ecc0(iVar15);
                        return 0;
                    }
                    break;
                }
                uVar18 = uVar18 + 1;
                puVar13 = puVar13 + 1;
            } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3858;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3870;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3886;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0;
        if (iVar15 == 0) {
            if (*(uint64_t *)(in_RCX + 0x338) != 0) {
                puVar13 = (uint16_t *)(in_RCX + 0x330);
                uVar16 = uVar18;
                do {
                    if (*puVar13 == uVar19) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3760;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3778;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                      *(int64_t *)(&stack0x00000040 + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f378e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                        return 0;
                    }
                    uVar16 = uVar16 + 1;
                    puVar13 = puVar13 + 1;
                } while (uVar16 < *(uint64_t *)(in_RCX + 0x338));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36fa;
            func_0x0001801ab620(in_RCX, (int64_t)&arg_50h + iVar12, (int64_t)&var_20h + iVar12);
            uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar12);
            if (uVar16 != 0) {
                uVar14 = uVar18;
                do {
                    if (uVar19 == *(uint16_t *)(*(int64_t *)((int64_t)&arg_50h + iVar12) + uVar14 * 2)) {
                        if (uVar14 < uVar16) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ab;
                            iVar11 = func_0x0001801ada30(in_RCX, CONCAT11(uVar2, uVar3), 0x20004);
                            if (iVar11 != 0) {
                                *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
                                *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 0;
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37d0;
                                iVar11 = func_0x0001801adc80(in_RCX, CONCAT11(uVar2, uVar3), 0x304);
                                if (iVar11 != 0) {
                                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                                    if (*(int64_t *)(in_RCX + 0x338) != 0) {
                                        piVar20 = (int64_t *)(in_RCX + 0x310);
                                        do {
                                            if (*piVar20 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ff;
                                                func_0x00018022ecc0();
                                                *piVar20 = 0;
                                            }
                                            uVar18 = uVar18 + 1;
                                            piVar20 = piVar20 + 1;
                                        } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
                                    }
                                    *(undefined8 *)(in_RCX + 0x338) = 0;
                                    *(undefined8 *)(in_RCX + 0x308) = 0;
                                    return 1;
                                }
                            }
                        }
                        break;
                    }
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar16);
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3726;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f373e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3754;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f368a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36b8;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f3ab2
// Address: 0x1801f3ab2
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f3600(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined *puVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint16_t *puVar13;
    uint64_t uVar14;
    int64_t *in_RDX;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    uint64_t uVar18;
    uint32_t uVar19;
    undefined8 unaff_RSI;
    int64_t *piVar20;
    undefined8 unaff_RDI;
    uint32_t in_R8D;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801f360e;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    if ((*(int64_t *)(in_RCX + 0x308) == 0) || (*(int64_t *)(in_RCX + 0x4e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b6b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b83;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b99;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    if ((uint64_t)in_RDX[1] < 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b2e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b46;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b5c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    puVar4 = (undefined *)*in_RDX;
    iVar15 = in_RDX[1] - 2;
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = unaff_RDI;
    uVar18 = 0;
    uVar2 = *puVar4;
    uVar3 = puVar4[1];
    uVar7 = CONCAT11(uVar2, uVar3);
    uVar19 = (uint32_t)uVar7;
    in_RDX[1] = iVar15;
    *in_RDX = (int64_t)(puVar4 + 2);
    if ((in_R8D >> 0xb & 1) == 0) {
        if (*(uint64_t *)(in_RCX + 0x338) != 0) {
            puVar13 = (uint16_t *)(in_RCX + 0x330);
            do {
                if (*puVar13 == uVar19) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x310 + uVar18 * 8);
                    *(undefined8 *)(in_RCX + 0x308) = uVar5;
                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                    if (uVar7 != 0) {
                        iVar15 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        } else if (uVar19 != *(uint32_t *)(iVar15 + 0x304)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38cf;
                            iVar15 = func_0x00018019dc20(iVar15, 0);
                            if (iVar15 == 0) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38dc;
                                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38f4;
                                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12), 
                                              *(int64_t *)((int64_t)&var_20h + iVar12), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                              *(int64_t *)(&stack0x00000040 + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f390a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                                return 0;
                            }
                            uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f391d;
                            func_0x00018019c980(uVar6);
                            *(int64_t *)(in_RCX + 0x8f8) = iVar15;
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        }
                        uVar6 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3936;
                        iVar15 = func_0x0001801ab700(uVar6, CONCAT11(uVar2, uVar3));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3943;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f395b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3971;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        puVar4 = (undefined *)*in_RDX;
                        iVar17 = in_RDX[1];
                        uVar18 = in_RDX[1];
                        *(undefined8 *)((int64_t)&arg_30h + iVar12) = unaff_R15;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar4;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (uVar18 < 2) {
code_r0x0001801f3af4:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3af9;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b11;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b27;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        uVar18 = uVar18 - 2;
                        puVar1 = puVar4 + 2;
                        uVar16 = (uint64_t)CONCAT11(*puVar4, puVar4[1]);
                        if (uVar18 < uVar16) goto code_r0x0001801f3af4;
                        iVar17 = uVar18 - uVar16;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar1 + uVar16;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (iVar17 != 0) goto code_r0x0001801f3af4;
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar12 + 4);
                        uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar12);
                        uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar12 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar12);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                        *(undefined4 *)(in_RDX + 1) = uVar9;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                        if (uVar16 == 0) goto code_r0x0001801f3af4;
                        if (*(char *)(iVar15 + 0x30) != '\0') {
                            *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 1;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3ae2;
                            iVar11 = func_0x0001801c5bf0(in_RCX, uVar5, puVar1, uVar16);
                            if (iVar11 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f39f0;
                        iVar15 = func_0x00018022fd80();
                        if (iVar15 == 0) {
code_r0x0001801f3a70:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a75;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a8d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a03;
                            iVar11 = func_0x00018022e6c0(iVar15, uVar5);
                            if (iVar11 < 1) goto code_r0x0001801f3a70;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a15;
                            iVar11 = func_0x0001801aa310(iVar15, puVar1, uVar16);
                            if (0 < iVar11) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a57;
                                iVar11 = func_0x0001801c5dc0(in_RCX, uVar5, iVar15, 1);
                                if (iVar11 != 0) {
                                    *(int64_t *)(in_RCX + 0x4e0) = iVar15;
                                    *(undefined *)(in_RCX + 0x4dd) = 1;
                                    return 1;
                                }
                                goto code_r0x0001801f3aa3;
                            }
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a1e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a36;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aa3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
code_r0x0001801f3aa3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aab;
                        func_0x00018022ecc0(iVar15);
                        return 0;
                    }
                    break;
                }
                uVar18 = uVar18 + 1;
                puVar13 = puVar13 + 1;
            } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3858;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3870;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3886;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0;
        if (iVar15 == 0) {
            if (*(uint64_t *)(in_RCX + 0x338) != 0) {
                puVar13 = (uint16_t *)(in_RCX + 0x330);
                uVar16 = uVar18;
                do {
                    if (*puVar13 == uVar19) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3760;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3778;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                      *(int64_t *)(&stack0x00000040 + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f378e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                        return 0;
                    }
                    uVar16 = uVar16 + 1;
                    puVar13 = puVar13 + 1;
                } while (uVar16 < *(uint64_t *)(in_RCX + 0x338));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36fa;
            func_0x0001801ab620(in_RCX, (int64_t)&arg_50h + iVar12, (int64_t)&var_20h + iVar12);
            uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar12);
            if (uVar16 != 0) {
                uVar14 = uVar18;
                do {
                    if (uVar19 == *(uint16_t *)(*(int64_t *)((int64_t)&arg_50h + iVar12) + uVar14 * 2)) {
                        if (uVar14 < uVar16) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ab;
                            iVar11 = func_0x0001801ada30(in_RCX, CONCAT11(uVar2, uVar3), 0x20004);
                            if (iVar11 != 0) {
                                *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
                                *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 0;
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37d0;
                                iVar11 = func_0x0001801adc80(in_RCX, CONCAT11(uVar2, uVar3), 0x304);
                                if (iVar11 != 0) {
                                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                                    if (*(int64_t *)(in_RCX + 0x338) != 0) {
                                        piVar20 = (int64_t *)(in_RCX + 0x310);
                                        do {
                                            if (*piVar20 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ff;
                                                func_0x00018022ecc0();
                                                *piVar20 = 0;
                                            }
                                            uVar18 = uVar18 + 1;
                                            piVar20 = piVar20 + 1;
                                        } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
                                    }
                                    *(undefined8 *)(in_RCX + 0x338) = 0;
                                    *(undefined8 *)(in_RCX + 0x308) = 0;
                                    return 1;
                                }
                            }
                        }
                        break;
                    }
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar16);
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3726;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f373e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3754;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f368a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36b8;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f3ac9
// Address: 0x1801f3ac9
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f3600(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined *puVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint16_t *puVar13;
    uint64_t uVar14;
    int64_t *in_RDX;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    uint64_t uVar18;
    uint32_t uVar19;
    undefined8 unaff_RSI;
    int64_t *piVar20;
    undefined8 unaff_RDI;
    uint32_t in_R8D;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801f360e;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    if ((*(int64_t *)(in_RCX + 0x308) == 0) || (*(int64_t *)(in_RCX + 0x4e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b6b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b83;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b99;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    if ((uint64_t)in_RDX[1] < 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b2e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b46;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b5c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    puVar4 = (undefined *)*in_RDX;
    iVar15 = in_RDX[1] - 2;
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = unaff_RDI;
    uVar18 = 0;
    uVar2 = *puVar4;
    uVar3 = puVar4[1];
    uVar7 = CONCAT11(uVar2, uVar3);
    uVar19 = (uint32_t)uVar7;
    in_RDX[1] = iVar15;
    *in_RDX = (int64_t)(puVar4 + 2);
    if ((in_R8D >> 0xb & 1) == 0) {
        if (*(uint64_t *)(in_RCX + 0x338) != 0) {
            puVar13 = (uint16_t *)(in_RCX + 0x330);
            do {
                if (*puVar13 == uVar19) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x310 + uVar18 * 8);
                    *(undefined8 *)(in_RCX + 0x308) = uVar5;
                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                    if (uVar7 != 0) {
                        iVar15 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        } else if (uVar19 != *(uint32_t *)(iVar15 + 0x304)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38cf;
                            iVar15 = func_0x00018019dc20(iVar15, 0);
                            if (iVar15 == 0) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38dc;
                                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38f4;
                                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12), 
                                              *(int64_t *)((int64_t)&var_20h + iVar12), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                              *(int64_t *)(&stack0x00000040 + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f390a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                                return 0;
                            }
                            uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f391d;
                            func_0x00018019c980(uVar6);
                            *(int64_t *)(in_RCX + 0x8f8) = iVar15;
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        }
                        uVar6 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3936;
                        iVar15 = func_0x0001801ab700(uVar6, CONCAT11(uVar2, uVar3));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3943;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f395b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3971;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        puVar4 = (undefined *)*in_RDX;
                        iVar17 = in_RDX[1];
                        uVar18 = in_RDX[1];
                        *(undefined8 *)((int64_t)&arg_30h + iVar12) = unaff_R15;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar4;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (uVar18 < 2) {
code_r0x0001801f3af4:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3af9;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b11;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b27;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        uVar18 = uVar18 - 2;
                        puVar1 = puVar4 + 2;
                        uVar16 = (uint64_t)CONCAT11(*puVar4, puVar4[1]);
                        if (uVar18 < uVar16) goto code_r0x0001801f3af4;
                        iVar17 = uVar18 - uVar16;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar1 + uVar16;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (iVar17 != 0) goto code_r0x0001801f3af4;
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar12 + 4);
                        uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar12);
                        uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar12 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar12);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                        *(undefined4 *)(in_RDX + 1) = uVar9;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                        if (uVar16 == 0) goto code_r0x0001801f3af4;
                        if (*(char *)(iVar15 + 0x30) != '\0') {
                            *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 1;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3ae2;
                            iVar11 = func_0x0001801c5bf0(in_RCX, uVar5, puVar1, uVar16);
                            if (iVar11 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f39f0;
                        iVar15 = func_0x00018022fd80();
                        if (iVar15 == 0) {
code_r0x0001801f3a70:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a75;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a8d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a03;
                            iVar11 = func_0x00018022e6c0(iVar15, uVar5);
                            if (iVar11 < 1) goto code_r0x0001801f3a70;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a15;
                            iVar11 = func_0x0001801aa310(iVar15, puVar1, uVar16);
                            if (0 < iVar11) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a57;
                                iVar11 = func_0x0001801c5dc0(in_RCX, uVar5, iVar15, 1);
                                if (iVar11 != 0) {
                                    *(int64_t *)(in_RCX + 0x4e0) = iVar15;
                                    *(undefined *)(in_RCX + 0x4dd) = 1;
                                    return 1;
                                }
                                goto code_r0x0001801f3aa3;
                            }
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a1e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a36;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aa3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
code_r0x0001801f3aa3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aab;
                        func_0x00018022ecc0(iVar15);
                        return 0;
                    }
                    break;
                }
                uVar18 = uVar18 + 1;
                puVar13 = puVar13 + 1;
            } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3858;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3870;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3886;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0;
        if (iVar15 == 0) {
            if (*(uint64_t *)(in_RCX + 0x338) != 0) {
                puVar13 = (uint16_t *)(in_RCX + 0x330);
                uVar16 = uVar18;
                do {
                    if (*puVar13 == uVar19) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3760;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3778;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                      *(int64_t *)(&stack0x00000040 + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f378e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                        return 0;
                    }
                    uVar16 = uVar16 + 1;
                    puVar13 = puVar13 + 1;
                } while (uVar16 < *(uint64_t *)(in_RCX + 0x338));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36fa;
            func_0x0001801ab620(in_RCX, (int64_t)&arg_50h + iVar12, (int64_t)&var_20h + iVar12);
            uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar12);
            if (uVar16 != 0) {
                uVar14 = uVar18;
                do {
                    if (uVar19 == *(uint16_t *)(*(int64_t *)((int64_t)&arg_50h + iVar12) + uVar14 * 2)) {
                        if (uVar14 < uVar16) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ab;
                            iVar11 = func_0x0001801ada30(in_RCX, CONCAT11(uVar2, uVar3), 0x20004);
                            if (iVar11 != 0) {
                                *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
                                *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 0;
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37d0;
                                iVar11 = func_0x0001801adc80(in_RCX, CONCAT11(uVar2, uVar3), 0x304);
                                if (iVar11 != 0) {
                                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                                    if (*(int64_t *)(in_RCX + 0x338) != 0) {
                                        piVar20 = (int64_t *)(in_RCX + 0x310);
                                        do {
                                            if (*piVar20 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ff;
                                                func_0x00018022ecc0();
                                                *piVar20 = 0;
                                            }
                                            uVar18 = uVar18 + 1;
                                            piVar20 = piVar20 + 1;
                                        } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
                                    }
                                    *(undefined8 *)(in_RCX + 0x338) = 0;
                                    *(undefined8 *)(in_RCX + 0x308) = 0;
                                    return 1;
                                }
                            }
                        }
                        break;
                    }
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar16);
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3726;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f373e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3754;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f368a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36b8;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f3b29
// Address: 0x1801f3b29
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f3600(int64_t arg_28h, int64_t arg_30h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined *puVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint16_t uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    uint16_t *puVar13;
    uint64_t uVar14;
    int64_t *in_RDX;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t iVar17;
    undefined8 unaff_RBP;
    uint64_t uVar18;
    uint32_t uVar19;
    undefined8 unaff_RSI;
    int64_t *piVar20;
    undefined8 unaff_RDI;
    uint32_t in_R8D;
    undefined8 unaff_R15;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    int64_t var_10h;
    
    uStack_18 = 0x1801f360e;
    iVar12 = fcn.18045a350();
    iVar12 = -iVar12;
    if ((*(int64_t *)(in_RCX + 0x308) == 0) || (*(int64_t *)(in_RCX + 0x4e0) != 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b6b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b83;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b99;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    if ((uint64_t)in_RDX[1] < 2) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b2e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b46;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b5c;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        return 0;
    }
    puVar4 = (undefined *)*in_RDX;
    iVar15 = in_RDX[1] - 2;
    *(undefined8 *)((int64_t)&arg_60h + iVar12) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_58h + iVar12) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar12) = unaff_RDI;
    uVar18 = 0;
    uVar2 = *puVar4;
    uVar3 = puVar4[1];
    uVar7 = CONCAT11(uVar2, uVar3);
    uVar19 = (uint32_t)uVar7;
    in_RDX[1] = iVar15;
    *in_RDX = (int64_t)(puVar4 + 2);
    if ((in_R8D >> 0xb & 1) == 0) {
        if (*(uint64_t *)(in_RCX + 0x338) != 0) {
            puVar13 = (uint16_t *)(in_RCX + 0x330);
            do {
                if (*puVar13 == uVar19) {
                    uVar5 = *(undefined8 *)(in_RCX + 0x310 + uVar18 * 8);
                    *(undefined8 *)(in_RCX + 0x308) = uVar5;
                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                    if (uVar7 != 0) {
                        iVar15 = *(int64_t *)(in_RCX + 0x8f8);
                        if (*(int32_t *)(in_RCX + 0x508) == 0) {
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        } else if (uVar19 != *(uint32_t *)(iVar15 + 0x304)) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38cf;
                            iVar15 = func_0x00018019dc20(iVar15, 0);
                            if (iVar15 == 0) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38dc;
                                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f38f4;
                                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                              *(int64_t *)((int64_t)&var_18h + iVar12), 
                                              *(int64_t *)((int64_t)&var_20h + iVar12), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                              *(int64_t *)(&stack0x00000040 + iVar12));
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f390a;
                                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                                return 0;
                            }
                            uVar6 = *(undefined8 *)(in_RCX + 0x8f8);
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f391d;
                            func_0x00018019c980(uVar6);
                            *(int64_t *)(in_RCX + 0x8f8) = iVar15;
                            *(uint32_t *)(iVar15 + 0x304) = uVar19;
                        }
                        uVar6 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3936;
                        iVar15 = func_0x0001801ab700(uVar6, CONCAT11(uVar2, uVar3));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3943;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f395b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3971;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        puVar4 = (undefined *)*in_RDX;
                        iVar17 = in_RDX[1];
                        uVar18 = in_RDX[1];
                        *(undefined8 *)((int64_t)&arg_30h + iVar12) = unaff_R15;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar4;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (uVar18 < 2) {
code_r0x0001801f3af4:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3af9;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b11;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3b27;
                            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                            return 0;
                        }
                        uVar18 = uVar18 - 2;
                        puVar1 = puVar4 + 2;
                        uVar16 = (uint64_t)CONCAT11(*puVar4, puVar4[1]);
                        if (uVar18 < uVar16) goto code_r0x0001801f3af4;
                        iVar17 = uVar18 - uVar16;
                        *(undefined **)((int64_t)&var_20h + iVar12) = puVar1 + uVar16;
                        *(int64_t *)((int64_t)&arg_28h + iVar12) = iVar17;
                        if (iVar17 != 0) goto code_r0x0001801f3af4;
                        uVar8 = *(undefined4 *)((int64_t)&var_20h + iVar12 + 4);
                        uVar9 = *(undefined4 *)((int64_t)&arg_28h + iVar12);
                        uVar10 = *(undefined4 *)((int64_t)&arg_28h + iVar12 + 4);
                        *(undefined4 *)in_RDX = *(undefined4 *)((int64_t)&var_20h + iVar12);
                        *(undefined4 *)((int64_t)in_RDX + 4) = uVar8;
                        *(undefined4 *)(in_RDX + 1) = uVar9;
                        *(undefined4 *)((int64_t)in_RDX + 0xc) = uVar10;
                        if (uVar16 == 0) goto code_r0x0001801f3af4;
                        if (*(char *)(iVar15 + 0x30) != '\0') {
                            *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 1;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3ae2;
                            iVar11 = func_0x0001801c5bf0(in_RCX, uVar5, puVar1, uVar16);
                            if (iVar11 == 0) {
                                return 0;
                            }
                            *(undefined *)(in_RCX + 0x4dd) = 1;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f39f0;
                        iVar15 = func_0x00018022fd80();
                        if (iVar15 == 0) {
code_r0x0001801f3a70:
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a75;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a8d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        } else {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a03;
                            iVar11 = func_0x00018022e6c0(iVar15, uVar5);
                            if (iVar11 < 1) goto code_r0x0001801f3a70;
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a15;
                            iVar11 = func_0x0001801aa310(iVar15, puVar1, uVar16);
                            if (0 < iVar11) {
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a57;
                                iVar11 = func_0x0001801c5dc0(in_RCX, uVar5, iVar15, 1);
                                if (iVar11 != 0) {
                                    *(int64_t *)(in_RCX + 0x4e0) = iVar15;
                                    *(undefined *)(in_RCX + 0x4dd) = 1;
                                    return 1;
                                }
                                goto code_r0x0001801f3aa3;
                            }
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a1e;
                            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12));
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3a36;
                            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                          *(int64_t *)((int64_t)&var_18h + iVar12), 
                                          *(int64_t *)((int64_t)&var_20h + iVar12), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                          *(int64_t *)(&stack0x00000040 + iVar12));
                        }
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aa3;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
code_r0x0001801f3aa3:
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3aab;
                        func_0x00018022ecc0(iVar15);
                        return 0;
                    }
                    break;
                }
                uVar18 = uVar18 + 1;
                puVar13 = puVar13 + 1;
            } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
        }
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3858;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3870;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                      *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                      *(int64_t *)(&stack0x00000040 + iVar12));
        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3886;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
    } else {
        *(undefined8 *)((int64_t)&arg_50h + iVar12) = 0;
        if (iVar15 == 0) {
            if (*(uint64_t *)(in_RCX + 0x338) != 0) {
                puVar13 = (uint16_t *)(in_RCX + 0x330);
                uVar16 = uVar18;
                do {
                    if (*puVar13 == uVar19) {
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3760;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3778;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), 
                                      *(int64_t *)((int64_t)&var_18h + iVar12), *(int64_t *)((int64_t)&var_20h + iVar12)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar12), 
                                      *(int64_t *)(&stack0x00000040 + iVar12));
                        *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f378e;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
                        return 0;
                    }
                    uVar16 = uVar16 + 1;
                    puVar13 = puVar13 + 1;
                } while (uVar16 < *(uint64_t *)(in_RCX + 0x338));
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36fa;
            func_0x0001801ab620(in_RCX, (int64_t)&arg_50h + iVar12, (int64_t)&var_20h + iVar12);
            uVar16 = *(uint64_t *)((int64_t)&var_20h + iVar12);
            if (uVar16 != 0) {
                uVar14 = uVar18;
                do {
                    if (uVar19 == *(uint16_t *)(*(int64_t *)((int64_t)&arg_50h + iVar12) + uVar14 * 2)) {
                        if (uVar14 < uVar16) {
                            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ab;
                            iVar11 = func_0x0001801ada30(in_RCX, CONCAT11(uVar2, uVar3), 0x20004);
                            if (iVar11 != 0) {
                                *(undefined8 *)((int64_t)&var_18h + iVar12) = 0;
                                *(undefined4 *)((int64_t)&iStackX_10 + iVar12) = 0;
                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37d0;
                                iVar11 = func_0x0001801adc80(in_RCX, CONCAT11(uVar2, uVar3), 0x304);
                                if (iVar11 != 0) {
                                    *(uint16_t *)(in_RCX + 0x4de) = uVar7;
                                    if (*(int64_t *)(in_RCX + 0x338) != 0) {
                                        piVar20 = (int64_t *)(in_RCX + 0x310);
                                        do {
                                            if (*piVar20 != 0) {
                                                *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f37ff;
                                                func_0x00018022ecc0();
                                                *piVar20 = 0;
                                            }
                                            uVar18 = uVar18 + 1;
                                            piVar20 = piVar20 + 1;
                                        } while (uVar18 < *(uint64_t *)(in_RCX + 0x338));
                                    }
                                    *(undefined8 *)(in_RCX + 0x338) = 0;
                                    *(undefined8 *)(in_RCX + 0x308) = 0;
                                    return 1;
                                }
                            }
                        }
                        break;
                    }
                    uVar14 = uVar14 + 1;
                } while (uVar14 < uVar16);
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3726;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f373e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f3754;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f368a;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36a2;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar12), *(int64_t *)((int64_t)&var_18h + iVar12), 
                          *(int64_t *)((int64_t)&var_20h + iVar12), *(int64_t *)((int64_t)&arg_28h + iVar12), 
                          *(int64_t *)(&stack0x00000040 + iVar12));
            *(undefined8 *)((int64_t)&uStack_18 + iVar12) = 0x1801f36b8;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_30h + iVar12));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f3bb0
// Address: 0x1801f3bb0
// Size: 219 bytes
// ============================================================
undefined8 fcn.1801f3bb0(int64_t param_1, uint8_t **param_2)
{
    uint8_t uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f3bbc;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_2[1] != (uint8_t *)0x1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3c55;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3c6d;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3c83;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    uVar1 = **param_2;
    *param_2 = *param_2 + 1;
    param_2[1] = (uint8_t *)0x0;
    if (uVar1 - 1 < 4) {
        if (uVar1 == *(uint8_t *)(param_1 + 0xb34)) {
            *(uint8_t *)(*(int64_t *)(param_1 + 0x8f8) + 0x350) = uVar1;
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3bf6;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3c49;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3c0e;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                  *(int64_t *)(&stack0x00000048 + iVar2));
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f3c24;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_1801f3c90
// Address: 0x1801f3c90
// Size: 534 bytes
// ============================================================
undefined8 fcn.1801f3c90(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_98h)
{
    undefined auVar1 [16];
    code *pcVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined8 *in_RDX;
    uint64_t uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f3c9c;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar7 = *(int64_t *)(in_RCX + 8);
    if ((*(int64_t *)(in_RCX + 0x260) != 0) && (*(int64_t *)(in_RCX + 0x2e8) != 0)) {
        return 1;
    }
    pcVar2 = *(code **)(iVar7 + 0x2f0);
    if (pcVar2 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3cd2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3cea;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3cfd;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
        return 0;
    }
    iVar8 = in_RDX[1];
    uVar10 = *(undefined4 *)in_RDX;
    uVar11 = *(undefined4 *)((int64_t)in_RDX + 4);
    if (iVar8 == 0) {
code_r0x0001801f3d7f:
        uVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)((int64_t)&var_20h + iVar6) = *(undefined8 *)(iVar7 + 0x2f8);
        uVar4 = *in_RDX;
        *(undefined4 *)((int64_t)&var_18h + iVar6) = *(undefined4 *)(in_RDX + 1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3da7;
        iVar5 = (*pcVar2)(uVar3, (int64_t)&arg_28h + iVar6, (int64_t)&arg_48h + iVar6, uVar4);
        if ((iVar5 == 0) && (*(char *)((int64_t)&arg_48h + iVar6) != '\0')) {
            uVar3 = *(undefined8 *)(in_RCX + 0xb00);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3dd2;
            fcn.180224990(uVar3, 0x1804b7ba0, 0x674);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3de9;
            iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(int64_t *)(in_RCX + 0xb00) = iVar7;
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e4a;
                fcn.180498030(iVar7, *(undefined8 *)((int64_t)&arg_28h + iVar6), 
                              *(undefined *)((int64_t)&arg_48h + iVar6));
                *(uint64_t *)(in_RCX + 0xb08) = (uint64_t)*(uint8_t *)((int64_t)&arg_48h + iVar6);
                *(undefined4 *)(in_RCX + 0x4b4) = 1;
                return 1;
            }
            *(undefined8 *)(in_RCX + 0xb08) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e01;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e19;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)((int64_t)&arg_48h + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e2f;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e70;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e88;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
    } else {
        while (iVar8 != 0) {
            uVar9 = (uint64_t)*(uint8_t *)CONCAT44(uVar11, uVar10);
            if (iVar8 - 1U < uVar9) break;
            iVar8 = (iVar8 - 1U) - uVar9;
            *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar8;
            *(uint8_t **)((int64_t)&arg_28h + iVar6) = (uint8_t *)CONCAT44(uVar11, uVar10) + uVar9 + 1;
            auVar1 = *(undefined (*) [16])((int64_t)&arg_28h + iVar6);
            uVar10 = auVar1._0_4_;
            uVar11 = auVar1._4_4_;
            if (uVar9 == 0) break;
            if (iVar8 == 0) goto code_r0x0001801f3d7f;
            iVar8 = auVar1._8_8_;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3d5d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3d75;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f3e9e;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f3eb0
// Address: 0x1801f3eb0
// Size: 470 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f3eb0(int64_t arg_28h)
{
    int64_t iVar1;
    undefined *puVar2;
    undefined8 uVar3;
    uint16_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f3ec0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (1 < (uint64_t)in_RDX[1]) {
        puVar2 = (undefined *)*in_RDX;
        uVar4 = CONCAT11(*puVar2, puVar2[1]);
        *in_RDX = (int64_t)(puVar2 + 2);
        iVar1 = in_RDX[1] - 2;
        in_RDX[1] = iVar1;
        if (iVar1 == 0) {
            if ((uint32_t)uVar4 < *(uint32_t *)(in_RCX + 0xb38)) {
                if ((uVar4 == 0) && ((*(int64_t *)(in_RCX + 0x900) == 0 || (*(uint32_t *)(in_RCX + 0xb38) == 2)))) {
                    *(undefined4 *)(in_RCX + 0x508) = 1;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f3f58;
                    func_0x00018019c980();
                    *(undefined8 *)(in_RCX + 0x900) = 0;
                    return 1;
                }
                iVar1 = *(int64_t *)(in_RCX + 0x900);
                if (iVar1 != 0) {
                    if ((((*(int32_t *)(in_RCX + 0xf0) != 3) && (*(int32_t *)(in_RCX + 0xf0) != 7)) ||
                        (*(int32_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x338) != 0)) || (*(int32_t *)(iVar1 + 0x338) == 0)
                       ) {
                        uVar5 = *(undefined4 *)(iVar1 + 0x14);
                        uVar6 = *(undefined4 *)(iVar1 + 0x18);
                        uVar7 = *(undefined4 *)(iVar1 + 0x1c);
                        *(undefined4 *)(in_RCX + 0x574) = *(undefined4 *)(iVar1 + 0x10);
                        *(undefined4 *)(in_RCX + 0x578) = uVar5;
                        *(undefined4 *)(in_RCX + 0x57c) = uVar6;
                        *(undefined4 *)(in_RCX + 0x580) = uVar7;
                        uVar5 = *(undefined4 *)(iVar1 + 0x24);
                        uVar6 = *(undefined4 *)(iVar1 + 0x28);
                        uVar7 = *(undefined4 *)(iVar1 + 0x2c);
                        *(undefined4 *)(in_RCX + 0x584) = *(undefined4 *)(iVar1 + 0x20);
                        *(undefined4 *)(in_RCX + 0x588) = uVar5;
                        *(undefined4 *)(in_RCX + 0x58c) = uVar6;
                        *(undefined4 *)(in_RCX + 0x590) = uVar7;
                        uVar5 = *(undefined4 *)(iVar1 + 0x34);
                        uVar6 = *(undefined4 *)(iVar1 + 0x38);
                        uVar7 = *(undefined4 *)(iVar1 + 0x3c);
                        *(undefined4 *)(in_RCX + 0x594) = *(undefined4 *)(iVar1 + 0x30);
                        *(undefined4 *)(in_RCX + 0x598) = uVar5;
                        *(undefined4 *)(in_RCX + 0x59c) = uVar6;
                        *(undefined4 *)(in_RCX + 0x5a0) = uVar7;
                        uVar5 = *(undefined4 *)(iVar1 + 0x44);
                        uVar6 = *(undefined4 *)(iVar1 + 0x48);
                        uVar7 = *(undefined4 *)(iVar1 + 0x4c);
                        *(undefined4 *)(in_RCX + 0x5a4) = *(undefined4 *)(iVar1 + 0x40);
                        *(undefined4 *)(in_RCX + 0x5a8) = uVar5;
                        *(undefined4 *)(in_RCX + 0x5ac) = uVar6;
                        *(undefined4 *)(in_RCX + 0x5b0) = uVar7;
                    }
                    uVar3 = *(undefined8 *)(in_RCX + 0x8f8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f400b;
                    func_0x00018019c980(uVar3);
                    *(undefined8 *)(in_RCX + 0x8f8) = *(undefined8 *)(in_RCX + 0x900);
                    *(undefined8 *)(in_RCX + 0x900) = 0;
                    *(undefined4 *)(in_RCX + 0x508) = 1;
                    if (uVar4 != 0) {
                        *(undefined4 *)(in_RCX + 0xb1c) = 0;
                    }
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f3f82;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f3f9a;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f3f0c;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f3f24;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                              *(int64_t *)(&stack0x00000048 + iVar8));
            }
            goto code_r0x0001801f406e;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f404b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f4063;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar8), *(int64_t *)((int64_t)aiStackX_18 + iVar8 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar8), *(int64_t *)(&stack0x00000030 + iVar8), 
                  *(int64_t *)(&stack0x00000048 + iVar8));
code_r0x0001801f406e:
    *(undefined8 *)((int64_t)&uStack_10 + iVar8) = 0x1801f4079;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar8));
    return 0;
}

// ============================================================
// Function: FUN_1801f4090
// Address: 0x1801f4090
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f4090(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    uint8_t **in_RDX;
    undefined8 unaff_RDI;
    uint8_t *puVar7;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f40a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (uint8_t *)(*(int64_t *)(in_RCX + 0x4a8) + *(int64_t *)(in_RCX + 0x460));
    if ((puVar2 != (uint8_t *)0x0) && ((*(int64_t *)(in_RCX + 0x460) == 0 || (*(int64_t *)(in_RCX + 0x4a8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40cf;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40fd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar7 = in_RDX[1] + -1;
    puVar6 = (uint8_t *)(uint64_t)**in_RDX;
    puVar1 = *in_RDX + 1;
    *in_RDX = puVar1;
    in_RDX[1] = puVar7;
    if (puVar7 != puVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f413a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4152;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4168;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (puVar6 != puVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4184;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f419c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41b2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar2 = *(uint8_t **)(in_RCX + 0x460);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    if (puVar2 <= puVar7) {
        puVar6 = puVar1 + (int64_t)puVar2;
        puVar7 = puVar7 + -(int64_t)puVar2;
        *in_RDX = puVar6;
        in_RDX[1] = puVar7;
        uVar3 = *(undefined8 *)(in_RCX + 0x460);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41fd;
        iVar4 = fcn.180497f30(puVar1, in_RCX + 0x420, uVar3);
        if (iVar4 == 0) {
            puVar2 = *(uint8_t **)(in_RCX + 0x4a8);
            if (puVar2 <= puVar7) {
                *in_RDX = puVar6 + (int64_t)puVar2;
                in_RDX[1] = puVar7 + -(int64_t)puVar2;
                uVar3 = *(undefined8 *)(in_RCX + 0x4a8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4235;
                iVar4 = fcn.180497f30(puVar6, in_RCX + 0x468, uVar3);
                if (iVar4 == 0) {
                    *(undefined4 *)(in_RCX + 0x4b0) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f424f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            goto code_r0x0001801f425b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4299;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
code_r0x0001801f425b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f427d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f410a
// Address: 0x1801f410a
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f4090(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    uint8_t **in_RDX;
    undefined8 unaff_RDI;
    uint8_t *puVar7;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f40a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (uint8_t *)(*(int64_t *)(in_RCX + 0x4a8) + *(int64_t *)(in_RCX + 0x460));
    if ((puVar2 != (uint8_t *)0x0) && ((*(int64_t *)(in_RCX + 0x460) == 0 || (*(int64_t *)(in_RCX + 0x4a8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40cf;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40fd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar7 = in_RDX[1] + -1;
    puVar6 = (uint8_t *)(uint64_t)**in_RDX;
    puVar1 = *in_RDX + 1;
    *in_RDX = puVar1;
    in_RDX[1] = puVar7;
    if (puVar7 != puVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f413a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4152;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4168;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (puVar6 != puVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4184;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f419c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41b2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar2 = *(uint8_t **)(in_RCX + 0x460);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    if (puVar2 <= puVar7) {
        puVar6 = puVar1 + (int64_t)puVar2;
        puVar7 = puVar7 + -(int64_t)puVar2;
        *in_RDX = puVar6;
        in_RDX[1] = puVar7;
        uVar3 = *(undefined8 *)(in_RCX + 0x460);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41fd;
        iVar4 = fcn.180497f30(puVar1, in_RCX + 0x420, uVar3);
        if (iVar4 == 0) {
            puVar2 = *(uint8_t **)(in_RCX + 0x4a8);
            if (puVar2 <= puVar7) {
                *in_RDX = puVar6 + (int64_t)puVar2;
                in_RDX[1] = puVar7 + -(int64_t)puVar2;
                uVar3 = *(undefined8 *)(in_RCX + 0x4a8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4235;
                iVar4 = fcn.180497f30(puVar6, in_RCX + 0x468, uVar3);
                if (iVar4 == 0) {
                    *(undefined4 *)(in_RCX + 0x4b0) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f424f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            goto code_r0x0001801f425b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4299;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
code_r0x0001801f425b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f427d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f417a
// Address: 0x1801f417a
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f4090(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    uint8_t **in_RDX;
    undefined8 unaff_RDI;
    uint8_t *puVar7;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f40a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (uint8_t *)(*(int64_t *)(in_RCX + 0x4a8) + *(int64_t *)(in_RCX + 0x460));
    if ((puVar2 != (uint8_t *)0x0) && ((*(int64_t *)(in_RCX + 0x460) == 0 || (*(int64_t *)(in_RCX + 0x4a8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40cf;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40fd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar7 = in_RDX[1] + -1;
    puVar6 = (uint8_t *)(uint64_t)**in_RDX;
    puVar1 = *in_RDX + 1;
    *in_RDX = puVar1;
    in_RDX[1] = puVar7;
    if (puVar7 != puVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f413a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4152;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4168;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (puVar6 != puVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4184;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f419c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41b2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar2 = *(uint8_t **)(in_RCX + 0x460);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    if (puVar2 <= puVar7) {
        puVar6 = puVar1 + (int64_t)puVar2;
        puVar7 = puVar7 + -(int64_t)puVar2;
        *in_RDX = puVar6;
        in_RDX[1] = puVar7;
        uVar3 = *(undefined8 *)(in_RCX + 0x460);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41fd;
        iVar4 = fcn.180497f30(puVar1, in_RCX + 0x420, uVar3);
        if (iVar4 == 0) {
            puVar2 = *(uint8_t **)(in_RCX + 0x4a8);
            if (puVar2 <= puVar7) {
                *in_RDX = puVar6 + (int64_t)puVar2;
                in_RDX[1] = puVar7 + -(int64_t)puVar2;
                uVar3 = *(undefined8 *)(in_RCX + 0x4a8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4235;
                iVar4 = fcn.180497f30(puVar6, in_RCX + 0x468, uVar3);
                if (iVar4 == 0) {
                    *(undefined4 *)(in_RCX + 0x4b0) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f424f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            goto code_r0x0001801f425b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4299;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
code_r0x0001801f425b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f427d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f41c4
// Address: 0x1801f41c4
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f4090(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    uint8_t **in_RDX;
    undefined8 unaff_RDI;
    uint8_t *puVar7;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f40a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (uint8_t *)(*(int64_t *)(in_RCX + 0x4a8) + *(int64_t *)(in_RCX + 0x460));
    if ((puVar2 != (uint8_t *)0x0) && ((*(int64_t *)(in_RCX + 0x460) == 0 || (*(int64_t *)(in_RCX + 0x4a8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40cf;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40fd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar7 = in_RDX[1] + -1;
    puVar6 = (uint8_t *)(uint64_t)**in_RDX;
    puVar1 = *in_RDX + 1;
    *in_RDX = puVar1;
    in_RDX[1] = puVar7;
    if (puVar7 != puVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f413a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4152;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4168;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (puVar6 != puVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4184;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f419c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41b2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar2 = *(uint8_t **)(in_RCX + 0x460);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    if (puVar2 <= puVar7) {
        puVar6 = puVar1 + (int64_t)puVar2;
        puVar7 = puVar7 + -(int64_t)puVar2;
        *in_RDX = puVar6;
        in_RDX[1] = puVar7;
        uVar3 = *(undefined8 *)(in_RCX + 0x460);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41fd;
        iVar4 = fcn.180497f30(puVar1, in_RCX + 0x420, uVar3);
        if (iVar4 == 0) {
            puVar2 = *(uint8_t **)(in_RCX + 0x4a8);
            if (puVar2 <= puVar7) {
                *in_RDX = puVar6 + (int64_t)puVar2;
                in_RDX[1] = puVar7 + -(int64_t)puVar2;
                uVar3 = *(undefined8 *)(in_RCX + 0x4a8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4235;
                iVar4 = fcn.180497f30(puVar6, in_RCX + 0x468, uVar3);
                if (iVar4 == 0) {
                    *(undefined4 *)(in_RCX + 0x4b0) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f424f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            goto code_r0x0001801f425b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4299;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
code_r0x0001801f425b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f427d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f4294
// Address: 0x1801f4294
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f4090(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    uint8_t **in_RDX;
    undefined8 unaff_RDI;
    uint8_t *puVar7;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f40a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (uint8_t *)(*(int64_t *)(in_RCX + 0x4a8) + *(int64_t *)(in_RCX + 0x460));
    if ((puVar2 != (uint8_t *)0x0) && ((*(int64_t *)(in_RCX + 0x460) == 0 || (*(int64_t *)(in_RCX + 0x4a8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40cf;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40fd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar7 = in_RDX[1] + -1;
    puVar6 = (uint8_t *)(uint64_t)**in_RDX;
    puVar1 = *in_RDX + 1;
    *in_RDX = puVar1;
    in_RDX[1] = puVar7;
    if (puVar7 != puVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f413a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4152;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4168;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (puVar6 != puVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4184;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f419c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41b2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar2 = *(uint8_t **)(in_RCX + 0x460);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    if (puVar2 <= puVar7) {
        puVar6 = puVar1 + (int64_t)puVar2;
        puVar7 = puVar7 + -(int64_t)puVar2;
        *in_RDX = puVar6;
        in_RDX[1] = puVar7;
        uVar3 = *(undefined8 *)(in_RCX + 0x460);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41fd;
        iVar4 = fcn.180497f30(puVar1, in_RCX + 0x420, uVar3);
        if (iVar4 == 0) {
            puVar2 = *(uint8_t **)(in_RCX + 0x4a8);
            if (puVar2 <= puVar7) {
                *in_RDX = puVar6 + (int64_t)puVar2;
                in_RDX[1] = puVar7 + -(int64_t)puVar2;
                uVar3 = *(undefined8 *)(in_RCX + 0x4a8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4235;
                iVar4 = fcn.180497f30(puVar6, in_RCX + 0x468, uVar3);
                if (iVar4 == 0) {
                    *(undefined4 *)(in_RCX + 0x4b0) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f424f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            goto code_r0x0001801f425b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4299;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
code_r0x0001801f425b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f427d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f42a7
// Address: 0x1801f42a7
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801f4090(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    uint8_t **in_RDX;
    undefined8 unaff_RDI;
    uint8_t *puVar7;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f40a0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar2 = (uint8_t *)(*(int64_t *)(in_RCX + 0x4a8) + *(int64_t *)(in_RCX + 0x460));
    if ((puVar2 != (uint8_t *)0x0) && ((*(int64_t *)(in_RCX + 0x460) == 0 || (*(int64_t *)(in_RCX + 0x4a8) == 0)))) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40cf;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f40fd;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = unaff_RDI;
    if (in_RDX[1] == (uint8_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42ac;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42c4;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f42da;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar7 = in_RDX[1] + -1;
    puVar6 = (uint8_t *)(uint64_t)**in_RDX;
    puVar1 = *in_RDX + 1;
    *in_RDX = puVar1;
    in_RDX[1] = puVar7;
    if (puVar7 != puVar6) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f413a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4152;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4168;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    if (puVar6 != puVar2) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4184;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f419c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41b2;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
        return 0;
    }
    puVar2 = *(uint8_t **)(in_RCX + 0x460);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_R14;
    if (puVar2 <= puVar7) {
        puVar6 = puVar1 + (int64_t)puVar2;
        puVar7 = puVar7 + -(int64_t)puVar2;
        *in_RDX = puVar6;
        in_RDX[1] = puVar7;
        uVar3 = *(undefined8 *)(in_RCX + 0x460);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f41fd;
        iVar4 = fcn.180497f30(puVar1, in_RCX + 0x420, uVar3);
        if (iVar4 == 0) {
            puVar2 = *(uint8_t **)(in_RCX + 0x4a8);
            if (puVar2 <= puVar7) {
                *in_RDX = puVar6 + (int64_t)puVar2;
                in_RDX[1] = puVar7 + -(int64_t)puVar2;
                uVar3 = *(undefined8 *)(in_RCX + 0x4a8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4235;
                iVar4 = fcn.180497f30(puVar6, in_RCX + 0x468, uVar3);
                if (iVar4 == 0) {
                    *(undefined4 *)(in_RCX + 0x4b0) = 1;
                    return 1;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f424f;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
            goto code_r0x0001801f425b;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4299;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5));
code_r0x0001801f425b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f4267;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar5 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar5), 
                  *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                  *(int64_t *)(&stack0x00000048 + iVar5));
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801f427d;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    return 0;
}

// ============================================================
// Function: FUN_1801f42f0
// Address: 0x1801f42f0
// Size: 473 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.1801f42f0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    uint64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f430a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((int32_t)in_R8 != 0x4000) {
        if (*(int64_t *)(in_RCX + 0xb68) == 0) {
            iVar5 = *(int64_t *)(in_RCX + 0x878);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f443f;
            iVar5 = func_0x00018019aba0(iVar5 + 0x80, ~(uint32_t)((in_R8 & 0xffffffff) >> 7) & 2, 0x12, 0);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4449;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4461;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4474;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                return false;
            }
            uVar1 = *in_RDX;
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_68h + iVar4);
            uVar2 = in_RDX[1];
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_R9;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar2;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f44a3;
            iVar3 = func_0x00018019ac50(in_RCX, in_R8 & 0xffffffff, 0x12, uVar1);
            return iVar3 != 0;
        }
        iVar5 = in_RDX[1];
        uVar1 = *(undefined8 *)(in_RCX + 0xa28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4351;
        fcn.180224990(uVar1, 0x1804b7ba0, 0x60d);
        *(int16_t *)(in_RCX + 0xa30) = (int16_t)iVar5;
        *(undefined8 *)(in_RCX + 0xa28) = 0;
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f437f;
            iVar5 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(int64_t *)(in_RCX + 0xa28) = iVar5;
            if (iVar5 == 0) {
                *(undefined2 *)(in_RCX + 0xa30) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4397;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f43af;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f43c5;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                return false;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f43da;
            iVar3 = fcn.1801b4900(*(int64_t *)((int64_t)&var_18h + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f43e7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f43ff;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4415;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
                return false;
            }
        }
    }
    return true;
}

// ============================================================
// Function: FUN_1801f44d0
// Address: 0x1801f44d0
// Size: 87 bytes
// ============================================================
undefined8 fcn.1801f44d0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f44dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f44ee;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4506;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f451c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb53) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f454b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4563;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4579;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x15a0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4597;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45af;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45c5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x15a8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45e0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45ea;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4602;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4618;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb52) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f4527
// Address: 0x1801f4527
// Size: 95 bytes
// ============================================================
undefined8 fcn.1801f44d0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f44dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f44ee;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4506;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f451c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb53) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f454b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4563;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4579;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x15a0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4597;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45af;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45c5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x15a8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45e0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45ea;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4602;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4618;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb52) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f4586
// Address: 0x1801f4586
// Size: 76 bytes
// ============================================================
undefined8 fcn.1801f44d0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f44dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f44ee;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4506;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f451c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb53) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f454b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4563;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4579;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x15a0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4597;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45af;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45c5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x15a8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45e0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45ea;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4602;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4618;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb52) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f45d2
// Address: 0x1801f45d2
// Size: 83 bytes
// ============================================================
undefined8 fcn.1801f44d0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f44dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f44ee;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4506;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f451c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb53) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f454b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4563;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4579;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x15a0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4597;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45af;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45c5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x15a8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45e0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45ea;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4602;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4618;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb52) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f4625
// Address: 0x1801f4625
// Size: 23 bytes
// ============================================================
undefined8 fcn.1801f44d0(int64_t arg_28h)
{
    undefined uVar1;
    undefined *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 *in_RDX;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f44dc;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX[1] != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f44ee;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4506;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f451c;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    puVar2 = (undefined *)*in_RDX;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RDI;
    uVar1 = *puVar2;
    *in_RDX = puVar2 + 1;
    in_RDX[1] = 0;
    if (*(char *)(in_RCX + 0xb53) != '\x01') {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f454b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4563;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4579;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    iVar5 = *(int64_t *)(in_RCX + 0x15a0);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4597;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45af;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45c5;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    uVar3 = *(undefined8 *)(in_RCX + 0x15a8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45e0;
    iVar5 = fcn.180498a80(iVar5, uVar1, uVar3);
    if (iVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f45ea;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4602;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)(&stack0x00000048 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f4618;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0;
    }
    *(undefined *)(in_RCX + 0xb52) = uVar1;
    return 1;
}

// ============================================================
// Function: FUN_1801f4640
// Address: 0x1801f4640
// Size: 244 bytes
// ============================================================
undefined8 fcn.1801f4640(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f464c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0xa18) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4663;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f467b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4691;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    if (*(int64_t *)(in_RDX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46a5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46bd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46d3;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    if (*(int32_t *)(in_RCX + 0x508) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x8f8);
        if (*(int64_t *)(iVar1 + 0x318) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46fe;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4716;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f472c;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f474e;
        uVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        *(undefined8 *)(iVar1 + 0x318) = uVar3;
        if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x318) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4770;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4788;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f479e;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f4734
// Address: 0x1801f4734
// Size: 55 bytes
// ============================================================
undefined8 fcn.1801f4640(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f464c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0xa18) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4663;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f467b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4691;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    if (*(int64_t *)(in_RDX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46a5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46bd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46d3;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    if (*(int32_t *)(in_RCX + 0x508) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x8f8);
        if (*(int64_t *)(iVar1 + 0x318) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46fe;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4716;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f472c;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f474e;
        uVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        *(undefined8 *)(iVar1 + 0x318) = uVar3;
        if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x318) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4770;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4788;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f479e;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f476b
// Address: 0x1801f476b
// Size: 70 bytes
// ============================================================
undefined8 fcn.1801f4640(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f464c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*(int64_t *)(in_RCX + 0xa18) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4663;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f467b;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4691;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    if (*(int64_t *)(in_RDX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46a5;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46bd;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46d3;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    if (*(int32_t *)(in_RCX + 0x508) == 0) {
        iVar1 = *(int64_t *)(in_RCX + 0x8f8);
        if (*(int64_t *)(iVar1 + 0x318) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f46fe;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4716;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f472c;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f474e;
        uVar3 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar2));
        *(undefined8 *)(iVar1 + 0x318) = uVar3;
        if (*(int64_t *)(*(int64_t *)(in_RCX + 0x8f8) + 0x318) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4770;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f4788;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f479e;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar2));
            return 0;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f47c0
// Address: 0x1801f47c0
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801f47c0(int64_t arg_28h)
{
    undefined4 uVar1;
    code *pcVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    undefined8 *in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f47d0;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar2 = *(code **)(in_RCX + 0xad0);
    if (pcVar2 != (code *)0x0) {
        uVar3 = *(undefined8 *)(in_RCX + 0xad8);
        uVar4 = *(undefined8 *)(in_RCX + 0x40);
        uVar1 = *(undefined4 *)(in_RDX + 1);
        uVar5 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f47f9;
        iVar6 = (*pcVar2)(uVar4, uVar5, uVar1, uVar3);
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4802;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f481a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar7));
            goto code_r0x0001801f481f;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4845;
    iVar6 = fcn.1801adc40(in_RCX);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f484e;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4866;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4879;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar7));
        return 0;
    }
    if (in_RDX[1] == 0) {
        *(undefined4 *)(in_RCX + 0xa60) = 1;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4891;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f48a9;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar7), *(int64_t *)((int64_t)aiStackX_18 + iVar7 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
code_r0x0001801f481f:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4830;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801f48d0
// Address: 0x1801f48d0
// Size: 262 bytes
// ============================================================
undefined8 fcn.1801f48d0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    int32_t *piVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    uint32_t uVar12;
    char **in_RDX;
    undefined8 unaff_RBP;
    char *pcVar13;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R8D;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f48dc;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    if (in_R8D == 0x4000) {
        return 1;
    }
    if (*(int32_t *)(in_RCX + 0xa20) != 1) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x1801f4900;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar11 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar11 + 0x10));
        *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x1801f4918;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar11 + 8), 
                      *(int64_t *)((int64_t)aiStackX_10 + iVar11 + 0x10), *(int64_t *)(&stack0x00000028 + iVar11), 
                      *(int64_t *)(&stack0x00000030 + iVar11), *(int64_t *)((int64_t)&arg_48h + iVar11));
        *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x1801f492b;
        fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar11));
        return 0;
    }
    piVar5 = *(int32_t **)(in_RCX + 0x18);
    uVar12 = *(uint32_t *)(*(int64_t *)(piVar5 + 0x36) + 0x50) & 8;
    if (((uVar12 != 0) || (*piVar5 < 0x304)) || (*piVar5 == 0x10000)) {
        if (in_RDX[1] != (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x1801f4962;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_10 + iVar11 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar11 + 0x10));
            *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x1801f497a;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_10 + iVar11 + 8), 
                          *(int64_t *)((int64_t)aiStackX_10 + iVar11 + 0x10), *(int64_t *)(&stack0x00000028 + iVar11), 
                          *(int64_t *)(&stack0x00000030 + iVar11), *(int64_t *)((int64_t)&arg_48h + iVar11));
            *(undefined8 *)((int64_t)&uStack_10 + iVar11) = 0x1801f4990;
            fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar11));
            return 0;
        }
        if (uVar12 != 0) goto code_r0x0001801f49c1;
    }
    if ((*piVar5 < 0x304) || (*piVar5 == 0x10000)) {
code_r0x0001801f49c1:
        *(undefined4 *)(in_RCX + 0xa34) = 1;
        return 1;
    }
    uVar9 = *(undefined8 *)((int64_t)&arg_48h + iVar11);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar11 + 8) = *(undefined8 *)((int64_t)aiStackX_10 + iVar11 + 8);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar11) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar11 + -8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar11 + -0x10) = 0x1801d0f2f;
    iVar7 = fcn.18045a350(in_RCX, uVar9);
    iVar7 = -iVar7;
    if (in_RDX[1] == (char *)0x0) {
code_r0x0001801d11c0:
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d11c5;
        fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), *(int64_t *)(&stack0x00000030 + iVar7 + iVar11));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d11dd;
        fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                      *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d11f3;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar11));
        return 0;
    }
    cVar1 = **in_RDX;
    *in_RDX = *in_RDX + 1;
    in_RDX[1] = in_RDX[1] + -1;
    if (cVar1 != '\x01') goto code_r0x0001801d11c0;
    uVar9 = *(undefined8 *)(in_RCX + 0xa48);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d0f80;
    fcn.180224990(uVar9, 0x1804b3b98, 0xb69);
    iVar8 = *(int64_t *)(in_RCX + 0xa58);
    *(undefined8 *)(in_RCX + 0xa48) = 0;
    *(undefined8 *)(in_RCX + 0xa50) = 0;
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d0fa1;
        iVar8 = fcn.180221f20();
        *(int64_t *)(in_RCX + 0xa58) = iVar8;
    }
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) != 0) ||
        (iVar6 = **(int32_t **)(in_RCX + 0x18), iVar6 < 0x304)) || (iVar6 == 0x10000)) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d0fd8;
        fcn.180222290(iVar8, 0x180196ec0);
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d0fe7;
        fcn.180222050(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                      *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                      *(int64_t *)(&stack0x00000060 + iVar7 + iVar11));
        *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d0fec;
        uVar9 = fcn.180221f20();
        *(undefined8 *)(in_RCX + 0xa58) = uVar9;
    }
    pcVar4 = in_RDX[1];
    *(undefined8 *)((int64_t)&arg_48h + iVar7 + iVar11) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar11) = unaff_RSI;
    if (pcVar4 == (char *)0x0) {
        return 1;
    }
    if ((char *)0x2 < pcVar4) {
        pcVar13 = *in_RDX;
        cVar1 = *pcVar13;
        cVar2 = pcVar13[1];
        cVar3 = pcVar13[2];
        *in_RDX = pcVar13 + 3;
        pcVar13 = (char *)(uint64_t)CONCAT21(CONCAT11(cVar1, cVar2), cVar3);
        in_RDX[1] = pcVar4 + -3;
        if (pcVar4 + -3 == pcVar13) {
            if (pcVar13 == (char *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1067;
            iVar8 = fcn.1802248d0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000030 + iVar7 + iVar11));
            if (iVar8 == 0) {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1074;
                fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar11));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d108c;
                fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                              *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11));
            } else {
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d10c5;
                iVar6 = fcn.1801b4900(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11));
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d10ce;
                    fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000030 + iVar7 + iVar11));
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d10e6;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11));
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d10fc;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar11));
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1111;
                    fcn.180224990(iVar8, 0x1804b3b98, 0xb89);
                    return 0;
                }
                *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11) = iVar8;
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1127;
                iVar10 = fcn.18023f280(*(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                                       *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), 
                                       *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                                       *(int64_t *)((int64_t)&arg_48h + iVar7 + iVar11), 
                                       *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar11), 
                                       *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11), 
                                       *(int64_t *)(&stack0x00000060 + iVar7 + iVar11), 
                                       *(int64_t *)(&stack0x00000070 + iVar7 + iVar11), 
                                       *(int64_t *)(&stack0x00000078 + iVar7 + iVar11), 
                                       *(int64_t *)(&stack0x00000090 + iVar7 + iVar11));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d113f;
                fcn.180224990(iVar8, 0x1804b3b98, 0xb8e);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1186;
                    fcn.180221da0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                                  *(int64_t *)(&stack0x00000038 + iVar7 + iVar11));
                    return 1;
                }
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1149;
                fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar11));
                *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1161;
                fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), 
                              *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                              *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11));
            }
            goto code_r0x0001801d109a;
        }
    }
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d1195;
    fcn.180229480(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), *(int64_t *)(&stack0x00000030 + iVar7 + iVar11));
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d11ad;
    fcn.1802295a0(*(int64_t *)(&stack0x00000028 + iVar7 + iVar11), *(int64_t *)(&stack0x00000030 + iVar7 + iVar11), 
                  *(int64_t *)(&stack0x00000038 + iVar7 + iVar11), *(int64_t *)(&stack0x00000040 + iVar7 + iVar11), 
                  *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar11));
code_r0x0001801d109a:
    *(undefined8 *)((int64_t)aiStackX_10 + iVar7 + iVar11 + -0x10) = 0x1801d10a2;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_48h + iVar7 + iVar11));
    return 0;
}

// ============================================================
// Function: FUN_1801f49e0
// Address: 0x1801f49e0
// Size: 302 bytes
// ============================================================
undefined8 fcn.1801f49e0(int64_t param_1, int64_t *param_2, int32_t param_3)
{
    int64_t iVar1;
    undefined uVar2;
    undefined uVar3;
    undefined *puVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f49ec;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (1 < (uint64_t)param_2[1]) {
        puVar4 = (undefined *)*param_2;
        uVar2 = puVar4[1];
        uVar3 = *puVar4;
        *param_2 = (int64_t)(puVar4 + 2);
        iVar1 = param_2[1] - 2;
        param_2[1] = iVar1;
        if (iVar1 == 0) {
            if (CONCAT11(uVar3, uVar2) != 0x304) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4a36;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4a4e;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4a64;
                fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                return 0;
            }
            if (param_3 != 0x800) {
                *(undefined4 *)(param_1 + 0x48) = 0x304;
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4a94;
                iVar5 = fcn.1801a5230(param_1, 0x304);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4a9d;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4ab5;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), *(int64_t *)(&stack0x00000028 + iVar6)
                                  , *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4acb;
                    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
                    return 0;
                }
            }
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4ad8;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4af0;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8), 
                  *(int64_t *)(&stack0x00000028 + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                  *(int64_t *)(&stack0x00000048 + iVar6));
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801f4b06;
    fcn.18019b5e0(*(int64_t *)(&stack0x00000038 + iVar6));
    return 0;
}

// ============================================================
// Function: FUN_1801f4b10
// Address: 0x1801f4b10
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_b90h because it doesn't fit into ProtoModel

undefined8 fcn.1801f4b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    char *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    char **in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f4b20;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar4 = in_RDX[1];
    if ((char *)0x1 < pcVar4) {
        pcVar5 = *in_RDX;
        cVar1 = *pcVar5;
        cVar2 = pcVar5[1];
        *in_RDX = pcVar5 + 2;
        in_RDX[1] = pcVar4 + -2;
        if ((CONCAT11(cVar1, cVar2) == 2) && ((char *)0x1 < pcVar4 + -2)) {
            cVar1 = pcVar5[2];
            cVar2 = pcVar5[3];
            *in_RDX = pcVar5 + 4;
            in_RDX[1] = pcVar4 + -4;
            if (pcVar4 + -4 != (char *)0x0) {
                cVar3 = pcVar5[4];
                *in_RDX = pcVar5 + 5;
                in_RDX[1] = pcVar4 + -5;
                if (pcVar4 + -5 == (char *)0x0) {
                    if (cVar3 != '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bb1;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bc9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bdf;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bf9;
                    iVar8 = fcn.18020bb40(in_RCX);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
                        iVar10 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c55;
                        iVar6 = fcn.180222010(iVar8);
                        if (0 < iVar6) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c6a;
                                iVar9 = fcn.180222340(iVar8, iVar10);
                                if (*(uint32_t *)(iVar9 + 8) == (uint32_t)CONCAT11(cVar1, cVar2)) {
                                    *(int64_t *)(in_RCX + 0xb98) = iVar9;
                                    return 1;
                                }
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c79;
                                iVar6 = fcn.180222010(iVar8);
                            } while (iVar10 < iVar6);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c82;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c9a;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cb0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c06;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c1e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000048 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c34;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cda;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cf2;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4d08;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801f4bef
// Address: 0x1801f4bef
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_b90h because it doesn't fit into ProtoModel

undefined8 fcn.1801f4b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    char *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    char **in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f4b20;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar4 = in_RDX[1];
    if ((char *)0x1 < pcVar4) {
        pcVar5 = *in_RDX;
        cVar1 = *pcVar5;
        cVar2 = pcVar5[1];
        *in_RDX = pcVar5 + 2;
        in_RDX[1] = pcVar4 + -2;
        if ((CONCAT11(cVar1, cVar2) == 2) && ((char *)0x1 < pcVar4 + -2)) {
            cVar1 = pcVar5[2];
            cVar2 = pcVar5[3];
            *in_RDX = pcVar5 + 4;
            in_RDX[1] = pcVar4 + -4;
            if (pcVar4 + -4 != (char *)0x0) {
                cVar3 = pcVar5[4];
                *in_RDX = pcVar5 + 5;
                in_RDX[1] = pcVar4 + -5;
                if (pcVar4 + -5 == (char *)0x0) {
                    if (cVar3 != '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bb1;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bc9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bdf;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bf9;
                    iVar8 = fcn.18020bb40(in_RCX);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
                        iVar10 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c55;
                        iVar6 = fcn.180222010(iVar8);
                        if (0 < iVar6) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c6a;
                                iVar9 = fcn.180222340(iVar8, iVar10);
                                if (*(uint32_t *)(iVar9 + 8) == (uint32_t)CONCAT11(cVar1, cVar2)) {
                                    *(int64_t *)(in_RCX + 0xb98) = iVar9;
                                    return 1;
                                }
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c79;
                                iVar6 = fcn.180222010(iVar8);
                            } while (iVar10 < iVar6);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c82;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c9a;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cb0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c06;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c1e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000048 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c34;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cda;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cf2;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4d08;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801f4c46
// Address: 0x1801f4c46
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_b90h because it doesn't fit into ProtoModel

undefined8 fcn.1801f4b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    char *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    char **in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f4b20;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar4 = in_RDX[1];
    if ((char *)0x1 < pcVar4) {
        pcVar5 = *in_RDX;
        cVar1 = *pcVar5;
        cVar2 = pcVar5[1];
        *in_RDX = pcVar5 + 2;
        in_RDX[1] = pcVar4 + -2;
        if ((CONCAT11(cVar1, cVar2) == 2) && ((char *)0x1 < pcVar4 + -2)) {
            cVar1 = pcVar5[2];
            cVar2 = pcVar5[3];
            *in_RDX = pcVar5 + 4;
            in_RDX[1] = pcVar4 + -4;
            if (pcVar4 + -4 != (char *)0x0) {
                cVar3 = pcVar5[4];
                *in_RDX = pcVar5 + 5;
                in_RDX[1] = pcVar4 + -5;
                if (pcVar4 + -5 == (char *)0x0) {
                    if (cVar3 != '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bb1;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bc9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bdf;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bf9;
                    iVar8 = fcn.18020bb40(in_RCX);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
                        iVar10 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c55;
                        iVar6 = fcn.180222010(iVar8);
                        if (0 < iVar6) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c6a;
                                iVar9 = fcn.180222340(iVar8, iVar10);
                                if (*(uint32_t *)(iVar9 + 8) == (uint32_t)CONCAT11(cVar1, cVar2)) {
                                    *(int64_t *)(in_RCX + 0xb98) = iVar9;
                                    return 1;
                                }
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c79;
                                iVar6 = fcn.180222010(iVar8);
                            } while (iVar10 < iVar6);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c82;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c9a;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cb0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c06;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c1e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000048 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c34;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cda;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cf2;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4d08;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801f4cc7
// Address: 0x1801f4cc7
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_b90h because it doesn't fit into ProtoModel

undefined8 fcn.1801f4b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    char *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    char **in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f4b20;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar4 = in_RDX[1];
    if ((char *)0x1 < pcVar4) {
        pcVar5 = *in_RDX;
        cVar1 = *pcVar5;
        cVar2 = pcVar5[1];
        *in_RDX = pcVar5 + 2;
        in_RDX[1] = pcVar4 + -2;
        if ((CONCAT11(cVar1, cVar2) == 2) && ((char *)0x1 < pcVar4 + -2)) {
            cVar1 = pcVar5[2];
            cVar2 = pcVar5[3];
            *in_RDX = pcVar5 + 4;
            in_RDX[1] = pcVar4 + -4;
            if (pcVar4 + -4 != (char *)0x0) {
                cVar3 = pcVar5[4];
                *in_RDX = pcVar5 + 5;
                in_RDX[1] = pcVar4 + -5;
                if (pcVar4 + -5 == (char *)0x0) {
                    if (cVar3 != '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bb1;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bc9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bdf;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bf9;
                    iVar8 = fcn.18020bb40(in_RCX);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
                        iVar10 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c55;
                        iVar6 = fcn.180222010(iVar8);
                        if (0 < iVar6) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c6a;
                                iVar9 = fcn.180222340(iVar8, iVar10);
                                if (*(uint32_t *)(iVar9 + 8) == (uint32_t)CONCAT11(cVar1, cVar2)) {
                                    *(int64_t *)(in_RCX + 0xb98) = iVar9;
                                    return 1;
                                }
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c79;
                                iVar6 = fcn.180222010(iVar8);
                            } while (iVar10 < iVar6);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c82;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c9a;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cb0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c06;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c1e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000048 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c34;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cda;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cf2;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4d08;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1801f4cd5
// Address: 0x1801f4cd5
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_b90h because it doesn't fit into ProtoModel

undefined8 fcn.1801f4b10(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char cVar1;
    char cVar2;
    char cVar3;
    char *pcVar4;
    char *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t in_RCX;
    char **in_RDX;
    int32_t iVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f4b20;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    pcVar4 = in_RDX[1];
    if ((char *)0x1 < pcVar4) {
        pcVar5 = *in_RDX;
        cVar1 = *pcVar5;
        cVar2 = pcVar5[1];
        *in_RDX = pcVar5 + 2;
        in_RDX[1] = pcVar4 + -2;
        if ((CONCAT11(cVar1, cVar2) == 2) && ((char *)0x1 < pcVar4 + -2)) {
            cVar1 = pcVar5[2];
            cVar2 = pcVar5[3];
            *in_RDX = pcVar5 + 4;
            in_RDX[1] = pcVar4 + -4;
            if (pcVar4 + -4 != (char *)0x0) {
                cVar3 = pcVar5[4];
                *in_RDX = pcVar5 + 5;
                in_RDX[1] = pcVar4 + -5;
                if (pcVar4 + -5 == (char *)0x0) {
                    if (cVar3 != '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bb1;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bc9;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bdf;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar7) = unaff_RDI;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4bf9;
                    iVar8 = fcn.18020bb40(in_RCX);
                    if (iVar8 != 0) {
                        *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
                        iVar10 = 0;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c55;
                        iVar6 = fcn.180222010(iVar8);
                        if (0 < iVar6) {
                            do {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c6a;
                                iVar9 = fcn.180222340(iVar8, iVar10);
                                if (*(uint32_t *)(iVar9 + 8) == (uint32_t)CONCAT11(cVar1, cVar2)) {
                                    *(int64_t *)(in_RCX + 0xb98) = iVar9;
                                    return 1;
                                }
                                iVar10 = iVar10 + 1;
                                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c79;
                                iVar6 = fcn.180222010(iVar8);
                            } while (iVar10 < iVar6);
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c82;
                        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c9a;
                        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cb0;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c06;
                    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c1e;
                    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7), *(int64_t *)(&stack0x00000048 + iVar7));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4c34;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                    return 0;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cda;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4cf2;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar7), 
                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                  *(int64_t *)(&stack0x00000048 + iVar7));
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1801f4d08;
    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

