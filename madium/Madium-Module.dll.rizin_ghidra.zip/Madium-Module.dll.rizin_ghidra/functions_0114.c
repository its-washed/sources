// Chunk 114 - 50 functions

// ============================================================
// Function: FUN_18018a740
// Address: 0x18018a740
// Size: 4622 bytes
// ============================================================
void fcn.18018a740(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    uint32_t uVar22;
    uint32_t uVar23;
    uint32_t uVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_84h;
    int64_t var_74h;
    int64_t var_6ch;
    int64_t var_58h;
    
    uVar19 = *(uint32_t *)arg1;
    uVar6 = *(uint32_t *)(arg1 + 8);
    uVar2 = *(uint32_t *)(arg1 + 0xc);
    uVar11 = *(uint32_t *)(arg1 + 4);
    uVar3 = *(uint32_t *)arg2;
    uVar10 = *(uint32_t *)(arg2 + 0x10);
    uVar14 = *(uint32_t *)(arg2 + 0x14);
    uVar1 = uVar11 >> 2 | uVar11 << 0x1e;
    uVar25 = *(uint32_t *)(arg2 + 4);
    uVar9 = uVar25 >> 0x18 | (uVar25 & 0xff0000) >> 8 | (uVar25 & 0xff00) << 8 | uVar25 << 0x18;
    uVar5 = uVar3 >> 0x18 | (uVar3 & 0xff0000) >> 8 | (uVar3 & 0xff00) << 8 | uVar3 << 0x18;
    uVar25 = uVar10 >> 0x18 | (uVar10 & 0xff0000) >> 8 | (uVar10 & 0xff00) << 8 | uVar10 << 0x18;
    uVar26 = uVar14 >> 0x18 | (uVar14 & 0xff0000) >> 8 | (uVar14 & 0xff00) << 8 | uVar14 << 0x18;
    uVar11 = uVar5 + 0x5a827999 +
             ((uVar2 ^ uVar6) & uVar11 ^ uVar2) + (uVar19 >> 0x1b | uVar19 << 5) + *(int32_t *)(arg1 + 0x10);
    uVar14 = uVar9 + 0x5a827999 + ((uVar6 ^ uVar1) & uVar19 ^ uVar6) + (uVar11 >> 0x1b | uVar11 * 0x20) + uVar2;
    uVar2 = *(uint32_t *)(arg2 + 8);
    uVar10 = uVar19 >> 2 | uVar19 << 0x1e;
    uVar19 = *(uint32_t *)(arg2 + 0xc);
    uVar12 = uVar11 >> 2 | uVar11 * 0x40000000;
    uVar18 = uVar2 >> 0x18 | (uVar2 & 0xff0000) >> 8 | (uVar2 & 0xff00) << 8 | uVar2 << 0x18;
    uVar3 = uVar19 >> 0x18 | (uVar19 & 0xff0000) >> 8 | (uVar19 & 0xff00) << 8 | uVar19 << 0x18;
    uVar19 = uVar18 + 0x5a827999 + ((uVar10 ^ uVar1) & uVar11 ^ uVar1) + (uVar14 >> 0x1b | uVar14 * 0x20) + uVar6;
    uVar15 = uVar14 >> 2 | uVar14 * 0x40000000;
    uVar11 = uVar1 + 0x5a827999 + ((uVar12 ^ uVar10) & uVar14 ^ uVar10) + (uVar19 >> 0x1b | uVar19 * 0x20) + uVar3;
    uVar1 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar14 = uVar10 + 0x5a827999 + ((uVar15 ^ uVar12) & uVar19 ^ uVar12) + (uVar11 >> 0x1b | uVar11 * 0x20) + uVar25;
    uVar19 = *(uint32_t *)(arg2 + 0x18);
    uVar6 = *(uint32_t *)(arg2 + 0x20);
    uVar10 = uVar11 >> 2 | uVar11 * 0x40000000;
    uVar2 = *(uint32_t *)(arg2 + 0x1c);
    uVar11 = uVar26 + 0x5a827999 + ((uVar1 ^ uVar15) & uVar11 ^ uVar15) + (uVar14 >> 0x1b | uVar14 * 0x20) + uVar12;
    uVar7 = uVar14 >> 2 | uVar14 * 0x40000000;
    uVar13 = uVar2 >> 0x18 | (uVar2 & 0xff0000) >> 8 | (uVar2 & 0xff00) << 8 | uVar2 << 0x18;
    uVar23 = uVar19 >> 0x18 | (uVar19 & 0xff0000) >> 8 | (uVar19 & 0xff00) << 8 | uVar19 << 0x18;
    uVar24 = uVar6 >> 0x18 | (uVar6 & 0xff0000) >> 8 | (uVar6 & 0xff00) << 8 | uVar6 << 0x18;
    uVar14 = uVar23 + 0x5a827999 + ((uVar1 ^ uVar10) & uVar14 ^ uVar1) + (uVar11 >> 0x1b | uVar11 * 0x20) + uVar15;
    uVar2 = uVar11 >> 2 | uVar11 * 0x40000000;
    uVar19 = *(uint32_t *)(arg2 + 0x28);
    uVar6 = *(uint32_t *)(arg2 + 0x24);
    uVar12 = uVar13 + 0x5a827999 + ((uVar7 ^ uVar10) & uVar11 ^ uVar10) + (uVar14 >> 0x1b | uVar14 * 0x20) + uVar1;
    uVar11 = uVar14 >> 2 | uVar14 * 0x40000000;
    uVar10 = uVar10 + 0x5a827999 + ((uVar2 ^ uVar7) & uVar14 ^ uVar7) + (uVar12 >> 0x1b | uVar12 * 0x20) + uVar24;
    uVar14 = uVar12 >> 2 | uVar12 * 0x40000000;
    uVar20 = uVar6 >> 0x18 | (uVar6 & 0xff0000) >> 8 | (uVar6 & 0xff00) << 8 | uVar6 << 0x18;
    uVar1 = uVar19 >> 0x18 | (uVar19 & 0xff0000) >> 8 | (uVar19 & 0xff00) << 8 | uVar19 << 0x18;
    uVar7 = uVar20 + (uVar10 >> 0x1b | uVar10 * 0x20) + ((uVar11 ^ uVar2) & uVar12 ^ uVar2) + 0x5a827999 + uVar7;
    uVar16 = uVar10 >> 2 | uVar10 * 0x40000000;
    uVar19 = *(uint32_t *)(arg2 + 0x2c);
    uVar2 = uVar1 + 0x5a827999 + ((uVar14 ^ uVar11) & uVar10 ^ uVar11) + (uVar7 >> 0x1b | uVar7 * 0x20) + uVar2;
    uVar12 = uVar19 >> 0x18 | (uVar19 & 0xff0000) >> 8 | (uVar19 & 0xff00) << 8 | uVar19 << 0x18;
    uVar19 = *(uint32_t *)(arg2 + 0x34);
    uVar21 = uVar7 >> 2 | uVar7 * 0x40000000;
    uVar6 = *(uint32_t *)(arg2 + 0x30);
    uVar10 = uVar12 + 0x5a827999 + ((uVar14 ^ uVar16) & uVar7 ^ uVar14) + (uVar2 >> 0x1b | uVar2 * 0x20) + uVar11;
    uVar15 = uVar6 >> 0x18 | (uVar6 & 0xff0000) >> 8 | (uVar6 & 0xff00) << 8 | uVar6 << 0x18;
    uVar6 = *(uint32_t *)(arg2 + 0x38);
    uVar11 = uVar2 >> 2 | uVar2 * 0x40000000;
    uVar2 = uVar15 + 0x5a827999 + ((uVar21 ^ uVar16) & uVar2 ^ uVar16) + (uVar10 >> 0x1b | uVar10 * 0x20) + uVar14;
    uVar14 = uVar10 >> 2 | uVar10 * 0x40000000;
    uVar4 = uVar6 >> 0x18 | (uVar6 & 0xff0000) >> 8 | (uVar6 & 0xff00) << 8 | uVar6 << 0x18;
    uVar8 = uVar19 >> 0x18 | (uVar19 & 0xff0000) >> 8 | (uVar19 & 0xff00) << 8 | uVar19 << 0x18;
    uVar16 = uVar16 + ((uVar11 ^ uVar21) & uVar10 ^ uVar21) + (uVar2 >> 0x1b | uVar2 * 0x20) + 0x5a827999 + uVar8;
    uVar7 = uVar2 >> 2 | uVar2 * 0x40000000;
    uVar19 = *(uint32_t *)(arg2 + 0x3c);
    uVar10 = uVar21 + 0x5a827999 + ((uVar14 ^ uVar11) & uVar2 ^ uVar11) + (uVar16 >> 0x1b | uVar16 * 0x20) + uVar4;
    uVar6 = uVar18 ^ uVar5 ^ uVar24 ^ uVar8;
    uVar2 = uVar6 >> 0x1f | uVar6 << 1;
    uVar17 = uVar16 >> 2 | uVar16 * 0x40000000;
    uVar6 = uVar19 >> 0x18 | (uVar19 & 0xff0000) >> 8 | (uVar19 & 0xff00) << 8 | uVar19 << 0x18;
    uVar19 = uVar6 + 0x5a827999 + ((uVar7 ^ uVar14) & uVar16 ^ uVar14) + (uVar10 >> 0x1b | uVar10 * 0x20) + uVar11;
    uVar5 = uVar2 + 0x5a827999 + ((uVar7 ^ uVar17) & uVar10 ^ uVar7) + (uVar19 >> 0x1b | uVar19 * 0x20) + uVar14;
    uVar10 = uVar10 >> 2 | uVar10 * 0x40000000;
    uVar14 = uVar9 ^ uVar4 ^ uVar3 ^ uVar20;
    uVar11 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar21 = uVar14 >> 0x1f | uVar14 << 1;
    uVar7 = uVar21 + 0x5a827999 + ((uVar10 ^ uVar17) & uVar19 ^ uVar17) + (uVar5 >> 0x1b | uVar5 * 0x20) + uVar7;
    uVar19 = uVar18 ^ uVar1 ^ uVar25 ^ uVar6;
    uVar9 = uVar19 >> 0x1f | uVar19 << 1;
    uVar14 = uVar5 >> 2 | uVar5 * 0x40000000;
    uVar19 = uVar3 ^ uVar26 ^ uVar12 ^ uVar2;
    uVar18 = uVar17 + 0x5a827999 + ((uVar11 ^ uVar10) & uVar5 ^ uVar10) + (uVar7 >> 0x1b | uVar7 * 0x20) + uVar9;
    uVar16 = uVar19 >> 0x1f | uVar19 << 1;
    uVar17 = uVar7 >> 2 | uVar7 * 0x40000000;
    uVar3 = uVar10 + 0x5a827999 + ((uVar14 ^ uVar11) & uVar7 ^ uVar11) + (uVar18 >> 0x1b | uVar18 * 0x20) + uVar16;
    uVar25 = uVar15 ^ uVar23 ^ uVar21 ^ uVar25;
    uVar5 = uVar25 >> 0x1f | uVar25 << 1;
    uVar22 = uVar18 >> 2 | uVar18 * 0x40000000;
    uVar19 = uVar5 + 0x6ed9eba1 + (uVar17 ^ uVar14 ^ uVar18) + (uVar3 >> 0x1b | uVar3 * 0x20) + uVar11;
    uVar11 = uVar13 ^ uVar26 ^ uVar9 ^ uVar8;
    uVar11 = uVar11 >> 0x1f | uVar11 << 1;
    uVar18 = uVar3 >> 2 | uVar3 * 0x40000000;
    uVar10 = uVar11 + 0x6ed9eba1 + (uVar17 ^ uVar3 ^ uVar22) + (uVar19 >> 0x1b | uVar19 * 0x20) + uVar14;
    uVar25 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar3 = uVar4 ^ uVar23 ^ uVar16 ^ uVar24;
    uVar3 = uVar3 >> 0x1f | uVar3 << 1;
    uVar14 = uVar3 + 0x6ed9eba1 + (uVar19 ^ uVar18 ^ uVar22) + (uVar10 >> 0x1b | uVar10 * 0x20) + uVar17;
    uVar19 = uVar13 ^ uVar5 ^ uVar20 ^ uVar6;
    uVar7 = uVar19 >> 0x1f | uVar19 << 1;
    uVar13 = uVar10 >> 2 | uVar10 * 0x40000000;
    uVar22 = uVar22 + (uVar25 ^ uVar10 ^ uVar18) + (uVar14 >> 0x1b | uVar14 * 0x20) + uVar7 + 0x6ed9eba1;
    uVar19 = uVar11 ^ uVar24 ^ uVar2 ^ uVar1;
    uVar10 = uVar19 >> 0x1f | uVar19 << 1;
    uVar23 = uVar14 >> 2 | uVar14 * 0x40000000;
    uVar18 = uVar18 + (uVar13 ^ uVar25 ^ uVar14) + (uVar22 >> 0x1b | uVar22 * 0x20) + uVar10 + 0x6ed9eba1;
    uVar19 = uVar3 ^ uVar20 ^ uVar21 ^ uVar12;
    uVar14 = uVar19 >> 0x1f | uVar19 << 1;
    uVar1 = uVar15 ^ uVar7 ^ uVar9 ^ uVar1;
    uVar24 = uVar22 >> 2 | uVar22 * 0x40000000;
    uVar19 = uVar14 + 0x6ed9eba1 + (uVar23 ^ uVar13 ^ uVar22) + (uVar18 >> 0x1b | uVar18 * 0x20) + uVar25;
    uVar25 = uVar1 >> 0x1f | uVar1 << 1;
    uVar20 = uVar18 >> 2 | uVar18 * 0x40000000;
    uVar18 = uVar25 + 0x6ed9eba1 + (uVar23 ^ uVar18 ^ uVar24) + (uVar19 >> 0x1b | uVar19 * 0x20) + uVar13;
    uVar1 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar12 = uVar10 ^ uVar16 ^ uVar12 ^ uVar8;
    uVar17 = uVar12 >> 0x1f | uVar12 << 1;
    uVar23 = uVar17 + 0x6ed9eba1 + (uVar19 ^ uVar20 ^ uVar24) + (uVar18 >> 0x1b | uVar18 * 0x20) + uVar23;
    uVar19 = uVar15 ^ uVar14 ^ uVar4 ^ uVar5;
    uVar13 = uVar19 >> 0x1f | uVar19 << 1;
    uVar12 = uVar18 >> 2 | uVar18 * 0x40000000;
    uVar24 = uVar24 + (uVar1 ^ uVar18 ^ uVar20) + (uVar23 >> 0x1b | uVar23 * 0x20) + uVar13 + 0x6ed9eba1;
    uVar19 = uVar25 ^ uVar11 ^ uVar8 ^ uVar6;
    uVar8 = uVar19 >> 0x1f | uVar19 << 1;
    uVar18 = uVar23 >> 2 | uVar23 * 0x40000000;
    uVar20 = uVar20 + (uVar12 ^ uVar1 ^ uVar23) + (uVar24 >> 0x1b | uVar24 * 0x20) + uVar8 + 0x6ed9eba1;
    uVar19 = uVar17 ^ uVar3 ^ uVar4 ^ uVar2;
    uVar19 = uVar19 >> 0x1f | uVar19 << 1;
    uVar22 = uVar24 >> 2 | uVar24 * 0x40000000;
    uVar1 = uVar19 + 0x6ed9eba1 + (uVar18 ^ uVar12 ^ uVar24) + (uVar20 >> 0x1b | uVar20 * 0x20) + uVar1;
    uVar6 = uVar13 ^ uVar7 ^ uVar21 ^ uVar6;
    uVar21 = uVar19 ^ uVar14 ^ uVar16 ^ uVar21;
    uVar6 = uVar6 >> 0x1f | uVar6 << 1;
    uVar23 = uVar20 >> 2 | uVar20 * 0x40000000;
    uVar26 = uVar21 >> 0x1f | uVar21 << 1;
    uVar4 = uVar6 + 0x6ed9eba1 + (uVar18 ^ uVar20 ^ uVar22) + (uVar1 >> 0x1b | uVar1 * 0x20) + uVar12;
    uVar2 = uVar8 ^ uVar10 ^ uVar9 ^ uVar2;
    uVar12 = uVar1 >> 2 | uVar1 * 0x40000000;
    uVar2 = uVar2 >> 0x1f | uVar2 << 1;
    uVar9 = uVar6 ^ uVar25 ^ uVar5 ^ uVar9;
    uVar15 = uVar9 >> 0x1f | uVar9 << 1;
    uVar1 = uVar2 + 0x6ed9eba1 + (uVar1 ^ uVar23 ^ uVar22) + (uVar4 >> 0x1b | uVar4 * 0x20) + uVar18;
    uVar9 = uVar4 >> 2 | uVar4 * 0x40000000;
    uVar22 = uVar22 + (uVar12 ^ uVar4 ^ uVar23) + (uVar1 >> 0x1b | uVar1 * 0x20) + uVar26 + 0x6ed9eba1;
    uVar21 = uVar1 >> 2 | uVar1 * 0x40000000;
    uVar23 = uVar23 + (uVar9 ^ uVar12 ^ uVar1) + (uVar22 >> 0x1b | uVar22 * 0x20) + uVar15 + 0x6ed9eba1;
    uVar16 = uVar2 ^ uVar17 ^ uVar11 ^ uVar16;
    uVar4 = uVar16 >> 0x1f | uVar16 << 1;
    uVar12 = uVar4 + 0x6ed9eba1 + (uVar21 ^ uVar9 ^ uVar22) + (uVar23 >> 0x1b | uVar23 * 0x20) + uVar12;
    uVar22 = uVar22 >> 2 | uVar22 * 0x40000000;
    uVar20 = uVar23 >> 2 | uVar23 * 0x40000000;
    uVar5 = uVar26 ^ uVar13 ^ uVar3 ^ uVar5;
    uVar1 = uVar5 >> 0x1f | uVar5 << 1;
    uVar11 = uVar15 ^ uVar8 ^ uVar7 ^ uVar11;
    uVar9 = uVar1 + 0x6ed9eba1 + (uVar21 ^ uVar23 ^ uVar22) + (uVar12 >> 0x1b | uVar12 * 0x20) + uVar9;
    uVar11 = uVar11 >> 0x1f | uVar11 << 1;
    uVar5 = uVar12 >> 2 | uVar12 * 0x40000000;
    uVar21 = uVar11 + 0x6ed9eba1 + (uVar12 ^ uVar20 ^ uVar22) + (uVar9 >> 0x1b | uVar9 * 0x20) + uVar21;
    uVar3 = uVar4 ^ uVar19 ^ uVar10 ^ uVar3;
    uVar16 = uVar9 >> 2 | uVar9 * 0x40000000;
    uVar3 = uVar3 >> 0x1f | uVar3 << 1;
    uVar22 = uVar22 + (uVar5 ^ uVar9 ^ uVar20) + (uVar21 >> 0x1b | uVar21 * 0x20) + uVar3 + 0x6ed9eba1;
    uVar7 = uVar1 ^ uVar6 ^ uVar14 ^ uVar7;
    uVar12 = uVar7 >> 0x1f | uVar7 << 1;
    uVar18 = uVar21 >> 2 | uVar21 * 0x40000000;
    uVar20 = uVar20 + (uVar16 ^ uVar5 ^ uVar21) + (uVar22 >> 0x1b | uVar22 * 0x20) + uVar12 + 0x6ed9eba1;
    uVar10 = uVar11 ^ uVar2 ^ uVar25 ^ uVar10;
    uVar10 = uVar10 >> 0x1f | uVar10 << 1;
    uVar24 = uVar22 >> 2 | uVar22 * 0x40000000;
    uVar14 = uVar3 ^ uVar26 ^ uVar17 ^ uVar14;
    uVar5 = uVar10 + (uVar20 >> 0x1b | uVar20 * 0x20) +
            ((uVar18 | uVar22) & uVar16 | uVar18 & uVar22) + uVar5 + -0x70e44324;
    uVar14 = uVar14 >> 0x1f | uVar14 << 1;
    uVar23 = uVar20 >> 2 | uVar20 * 0x40000000;
    uVar25 = uVar12 ^ uVar15 ^ uVar13 ^ uVar25;
    uVar9 = (uVar5 >> 0x1b | uVar5 * 0x20) + uVar14 + -0x70e44324 +
            ((uVar20 | uVar24) & uVar18 | uVar20 & uVar24) + uVar16;
    uVar25 = uVar25 >> 0x1f | uVar25 << 1;
    uVar17 = uVar10 ^ uVar4 ^ uVar8 ^ uVar17;
    uVar16 = uVar17 >> 0x1f | uVar17 << 1;
    uVar7 = uVar5 >> 2 | uVar5 * 0x40000000;
    uVar17 = (uVar9 >> 0x1b | uVar9 * 0x20) + uVar25 + -0x70e44324 +
             ((uVar5 | uVar23) & uVar24 | uVar5 & uVar23) + uVar18;
    uVar21 = uVar9 >> 2 | uVar9 * 0x40000000;
    uVar18 = uVar24 + (uVar17 >> 0x1b | uVar17 * 0x20) +
             ((uVar7 | uVar9) & uVar23 | uVar7 & uVar9) + uVar16 + 0x8f1bbcdc;
    uVar13 = uVar14 ^ uVar1 ^ uVar19 ^ uVar13;
    uVar9 = uVar13 >> 0x1f | uVar13 << 1;
    uVar5 = uVar9 + (uVar18 >> 0x1b | uVar18 * 0x20) +
            ((uVar21 | uVar17) & uVar7 | uVar21 & uVar17) + uVar23 + 0x8f1bbcdc;
    uVar8 = uVar25 ^ uVar11 ^ uVar6 ^ uVar8;
    uVar13 = uVar17 >> 2 | uVar17 * 0x40000000;
    uVar17 = uVar18 >> 2 | uVar18 * 0x40000000;
    uVar23 = uVar8 >> 0x1f | uVar8 << 1;
    uVar8 = uVar23 + (uVar5 >> 0x1b | uVar5 * 0x20) +
            ((uVar18 | uVar13) & uVar21 | uVar18 & uVar13) + uVar7 + 0x8f1bbcdc;
    uVar19 = uVar16 ^ uVar3 ^ uVar2 ^ uVar19;
    uVar22 = uVar19 >> 0x1f | uVar19 << 1;
    uVar19 = uVar5 >> 2 | uVar5 * 0x40000000;
    uVar5 = uVar22 + (uVar8 >> 0x1b | uVar8 * 0x20) +
            ((uVar5 | uVar17) & uVar13 | uVar5 & uVar17) + uVar21 + -0x70e44324;
    uVar6 = uVar12 ^ uVar26 ^ uVar6 ^ uVar9;
    uVar7 = uVar6 >> 0x1f | uVar6 << 1;
    uVar21 = uVar8 >> 2 | uVar8 * 0x40000000;
    uVar6 = uVar7 + (uVar5 >> 0x1b | uVar5 * 0x20) + ((uVar8 | uVar19) & uVar17 | uVar8 & uVar19) + uVar13 + -0x70e44324
    ;
    uVar2 = uVar10 ^ uVar15 ^ uVar2 ^ uVar23;
    uVar8 = uVar2 >> 0x1f | uVar2 << 1;
    uVar17 = uVar17 + (uVar6 >> 0x1b | uVar6 * 0x20) + ((uVar21 | uVar5) & uVar19 | uVar21 & uVar5) + 0x8f1bbcdc + uVar8
    ;
    uVar2 = uVar5 >> 2 | uVar5 * 0x40000000;
    uVar5 = uVar14 ^ uVar4 ^ uVar26 ^ uVar22;
    uVar5 = uVar5 >> 0x1f | uVar5 << 1;
    uVar15 = uVar25 ^ uVar1 ^ uVar15 ^ uVar7;
    uVar24 = uVar15 >> 0x1f | uVar15 << 1;
    uVar15 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar19 = (uVar17 >> 0x1b | uVar17 * 0x20) + uVar19 + ((uVar2 | uVar6) & uVar21 | uVar2 & uVar6) + 0x8f1bbcdc + uVar5
    ;
    uVar6 = uVar16 ^ uVar11 ^ uVar4 ^ uVar8;
    uVar13 = uVar6 >> 0x1f | uVar6 << 1;
    uVar18 = uVar17 >> 2 | uVar17 * 0x40000000;
    uVar4 = uVar24 + (uVar19 >> 0x1b | uVar19 * 0x20) +
            ((uVar15 | uVar17) & uVar2 | uVar15 & uVar17) + uVar21 + -0x70e44324;
    uVar6 = uVar3 ^ uVar1 ^ uVar5 ^ uVar9;
    uVar21 = uVar6 >> 0x1f | uVar6 << 1;
    uVar6 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar2 = uVar13 + (uVar4 >> 0x1b | uVar4 * 0x20) +
            ((uVar19 | uVar18) & uVar15 | uVar19 & uVar18) + uVar2 + -0x70e44324;
    uVar20 = uVar4 >> 2 | uVar4 * 0x40000000;
    uVar17 = uVar21 + (uVar2 >> 0x1b | uVar2 * 0x20) + ((uVar4 | uVar6) & uVar18 | uVar4 & uVar6) + uVar15 + -0x70e44324
    ;
    uVar19 = uVar12 ^ uVar11 ^ uVar24 ^ uVar23;
    uVar15 = uVar19 >> 0x1f | uVar19 << 1;
    uVar19 = uVar10 ^ uVar3 ^ uVar13 ^ uVar22;
    uVar4 = uVar2 >> 2 | uVar2 * 0x40000000;
    uVar3 = uVar19 >> 0x1f | uVar19 << 1;
    uVar19 = uVar25 ^ uVar10 ^ uVar15 ^ uVar8;
    uVar1 = uVar19 >> 0x1f | uVar19 << 1;
    uVar2 = uVar18 + (uVar17 >> 0x1b | uVar17 * 0x20) +
            ((uVar20 | uVar2) & uVar6 | uVar20 & uVar2) + 0x8f1bbcdc + uVar15;
    uVar19 = uVar14 ^ uVar12 ^ uVar21 ^ uVar7;
    uVar18 = uVar17 >> 2 | uVar17 * 0x40000000;
    uVar10 = uVar19 >> 0x1f | uVar19 << 1;
    uVar19 = (uVar2 >> 0x1b | uVar2 * 0x20) + uVar6 + ((uVar4 | uVar17) & uVar20 | uVar4 & uVar17) + 0x8f1bbcdc + uVar3;
    uVar17 = uVar2 >> 2 | uVar2 * 0x40000000;
    uVar6 = (uVar19 >> 0x1b | uVar19 * 0x20) + uVar10 +
            ((uVar18 | uVar2) & uVar4 | uVar18 & uVar2) + uVar20 + 0x8f1bbcdc;
    uVar11 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar2 = uVar16 ^ uVar14 ^ uVar3 ^ uVar5;
    uVar14 = (uVar6 >> 0x1b | uVar6 * 0x20) + uVar1 +
             ((uVar19 | uVar17) & uVar18 | uVar19 & uVar17) + uVar4 + -0x70e44324;
    uVar4 = uVar2 >> 0x1f | uVar2 << 1;
    uVar19 = uVar16 ^ uVar1 ^ uVar13 ^ uVar23;
    uVar12 = uVar19 >> 0x1f | uVar19 << 1;
    uVar2 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar19 = uVar25 ^ uVar10 ^ uVar24 ^ uVar9;
    uVar6 = uVar4 + (uVar14 >> 0x1b | uVar14 * 0x20) +
            ((uVar6 | uVar11) & uVar17 | uVar6 & uVar11) + uVar18 + -0x70e44324;
    uVar19 = uVar19 >> 0x1f | uVar19 << 1;
    uVar25 = uVar14 >> 2 | uVar14 * 0x40000000;
    uVar9 = uVar4 ^ uVar21 ^ uVar22 ^ uVar9;
    uVar18 = uVar17 + (uVar6 >> 0x1b | uVar6 * 0x20) +
             ((uVar2 | uVar14) & uVar11 | uVar2 & uVar14) + 0x8f1bbcdc + uVar19;
    uVar9 = uVar9 >> 0x1f | uVar9 << 1;
    uVar16 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar20 = uVar18 >> 2 | uVar18 * 0x40000000;
    uVar14 = uVar11 + (uVar18 >> 0x1b | uVar18 * 0x20) +
             ((uVar25 | uVar6) & uVar2 | uVar25 & uVar6) + uVar12 + -0x70e44324;
    uVar23 = uVar19 ^ uVar15 ^ uVar7 ^ uVar23;
    uVar17 = uVar23 >> 0x1f | uVar23 << 1;
    uVar6 = (uVar14 >> 0x1b | uVar14 * 0x20) + uVar9 + (uVar16 ^ uVar25 ^ uVar18) + 0xca62c1d6 + uVar2;
    uVar11 = uVar17 + (uVar6 >> 0x1b | uVar6 * 0x20) + (uVar16 ^ uVar14 ^ uVar20) + uVar25 + -0x359d3e2a;
    uVar22 = uVar12 ^ uVar3 ^ uVar8 ^ uVar22;
    uVar7 = uVar9 ^ uVar10 ^ uVar5 ^ uVar7;
    uVar2 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar23 = uVar14 >> 2 | uVar14 * 0x40000000;
    uVar25 = uVar22 >> 0x1f | uVar22 << 1;
    uVar14 = uVar7 >> 0x1f | uVar7 << 1;
    uVar6 = uVar25 + (uVar11 >> 0x1b | uVar11 * 0x20) + (uVar6 ^ uVar23 ^ uVar20) + uVar16 + -0x359d3e2a;
    uVar16 = uVar11 >> 2 | uVar11 * 0x40000000;
    uVar8 = uVar17 ^ uVar1 ^ uVar24 ^ uVar8;
    uVar20 = uVar20 + (uVar6 >> 0x1b | uVar6 * 0x20) + (uVar2 ^ uVar11 ^ uVar23) + 0xca62c1d6 + uVar14;
    uVar7 = uVar8 >> 0x1f | uVar8 << 1;
    uVar18 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar23 = uVar23 + (uVar20 >> 0x1b | uVar20 * 0x20) + (uVar16 ^ uVar2 ^ uVar6) + 0xca62c1d6 + uVar7;
    uVar5 = uVar25 ^ uVar4 ^ uVar13 ^ uVar5;
    uVar11 = uVar5 >> 0x1f | uVar5 << 1;
    uVar22 = uVar20 >> 2 | uVar20 * 0x40000000;
    uVar24 = uVar14 ^ uVar19 ^ uVar21 ^ uVar24;
    uVar24 = uVar24 >> 0x1f | uVar24 << 1;
    uVar6 = uVar11 + (uVar23 >> 0x1b | uVar23 * 0x20) + (uVar18 ^ uVar16 ^ uVar20) + uVar2 + -0x359d3e2a;
    uVar8 = uVar24 + (uVar6 >> 0x1b | uVar6 * 0x20) + (uVar18 ^ uVar23 ^ uVar22) + uVar16 + -0x359d3e2a;
    uVar23 = uVar23 >> 2 | uVar23 * 0x40000000;
    uVar13 = uVar7 ^ uVar12 ^ uVar15 ^ uVar13;
    uVar2 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar20 = uVar13 >> 0x1f | uVar13 << 1;
    uVar21 = uVar11 ^ uVar9 ^ uVar3 ^ uVar21;
    uVar15 = uVar24 ^ uVar17 ^ uVar10 ^ uVar15;
    uVar3 = uVar20 ^ uVar25 ^ uVar1 ^ uVar3;
    uVar16 = uVar21 >> 0x1f | uVar21 << 1;
    uVar5 = uVar15 >> 0x1f | uVar15 << 1;
    uVar26 = uVar3 >> 0x1f | uVar3 << 1;
    uVar10 = uVar16 ^ uVar14 ^ uVar4 ^ uVar10;
    uVar6 = (uVar8 >> 0x1b | uVar8 * 0x20) + uVar20 + (uVar6 ^ uVar23 ^ uVar22) + uVar18 + -0x359d3e2a;
    uVar18 = uVar10 >> 0x1f | uVar10 << 1;
    uVar15 = uVar8 >> 2 | uVar8 * 0x40000000;
    uVar10 = uVar22 + (uVar6 >> 0x1b | uVar6 * 0x20) + (uVar2 ^ uVar8 ^ uVar23) + 0xca62c1d6 + uVar16;
    uVar13 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar3 = (uVar10 >> 0x1b | uVar10 * 0x20) + uVar23 + (uVar15 ^ uVar2 ^ uVar6) + 0xca62c1d6 + uVar5;
    uVar21 = uVar10 >> 2 | uVar10 * 0x40000000;
    uVar6 = uVar26 + (uVar3 >> 0x1b | uVar3 * 0x20) + (uVar13 ^ uVar15 ^ uVar10) + uVar2 + -0x359d3e2a;
    uVar10 = uVar3 >> 2 | uVar3 * 0x40000000;
    uVar8 = (uVar6 >> 0x1b | uVar6 * 0x20) + uVar18 + (uVar13 ^ uVar3 ^ uVar21) + 0xca62c1d6 + uVar15;
    uVar1 = uVar5 ^ uVar7 ^ uVar19 ^ uVar1;
    uVar3 = uVar1 >> 0x1f | uVar1 << 1;
    uVar2 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar4 = uVar26 ^ uVar11 ^ uVar12 ^ uVar4;
    uVar13 = (uVar8 >> 0x1b | uVar8 * 0x20) + uVar3 + (uVar6 ^ uVar10 ^ uVar21) + uVar13 + -0x359d3e2a;
    uVar19 = uVar18 ^ uVar24 ^ uVar9 ^ uVar19;
    uVar6 = uVar4 >> 0x1f | uVar4 << 1;
    uVar4 = uVar8 >> 2 | uVar8 * 0x40000000;
    uVar15 = uVar19 >> 0x1f | uVar19 << 1;
    uVar9 = uVar6 ^ uVar16 ^ uVar25 ^ uVar9;
    uVar12 = uVar3 ^ uVar20 ^ uVar17 ^ uVar12;
    uVar3 = uVar12 >> 0x1f | uVar12 << 1;
    uVar6 = (uVar13 >> 0x1b | uVar13 * 0x20) + uVar21 + (uVar2 ^ uVar8 ^ uVar10) + 0xca62c1d6 + uVar6;
    uVar1 = uVar9 >> 0x1f | uVar9 << 1;
    uVar12 = uVar13 >> 2 | uVar13 * 0x40000000;
    uVar19 = uVar10 + (uVar6 >> 0x1b | uVar6 * 0x20) + (uVar4 ^ uVar2 ^ uVar13) + 0xca62c1d6 + uVar15;
    uVar17 = uVar15 ^ uVar5 ^ uVar14 ^ uVar17;
    uVar10 = uVar6 >> 2 | uVar6 * 0x40000000;
    uVar5 = (uVar19 >> 0x1b | uVar19 * 0x20) + uVar3 + (uVar12 ^ uVar4 ^ uVar6) + uVar2 + 0xca62c1d6;
    uVar6 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar19 = uVar1 + (uVar5 >> 0x1b | uVar5 * 0x20) + (uVar12 ^ uVar19 ^ uVar10) + uVar4 + -0x359d3e2a;
    uVar2 = uVar12 + (uVar17 >> 0x1f | uVar17 << 1) + (uVar19 >> 0x1b | uVar19 * 0x20) +
            (uVar5 ^ uVar6 ^ uVar10) + 0xca62c1d6;
    uVar12 = uVar5 >> 2 | uVar5 * 0x40000000;
    uVar25 = uVar3 ^ uVar26 ^ uVar7 ^ uVar25;
    uVar14 = uVar1 ^ uVar18 ^ uVar11 ^ uVar14;
    uVar11 = uVar19 >> 2 | uVar19 * 0x40000000;
    uVar19 = (uVar2 >> 0x1b | uVar2 * 0x20) + uVar10 + (uVar25 >> 0x1f | uVar25 << 1) +
             (uVar12 ^ uVar19 ^ uVar6) + 0xca62c1d6;
    *(int32_t *)(arg1 + 4) = *(int32_t *)(arg1 + 4) + uVar19;
    *(int32_t *)(arg1 + 0xc) = *(int32_t *)(arg1 + 0xc) + uVar11;
    *(int32_t *)(arg1 + 8) = *(int32_t *)(arg1 + 8) + (uVar2 >> 2 | uVar2 * 0x40000000);
    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + uVar12;
    *(uint32_t *)arg1 =
         uVar6 + 0xca62c1d6 + (uVar14 >> 0x1f | uVar14 << 1) + (uVar19 >> 0x1b | uVar19 * 0x20) +
         (uVar11 ^ uVar12 ^ uVar2) + *(int32_t *)arg1;
    return;
}

// ============================================================
// Function: FUN_18018b950
// Address: 0x18018b950
// Size: 175 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018018b9a3: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018018b9a8)
// WARNING: Removing unreachable block (ram,0x00018018b9bb)
// WARNING: Removing unreachable block (ram,0x00018018b9c0)
// WARNING: Removing unreachable block (ram,0x00018018b9d7)
// WARNING: [rz-ghidra] Removing arg arg_5a827999h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.18018b950(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    undefined uVar2;
    undefined2 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined4 uVar13;
    undefined4 uVar14;
    uint32_t uVar15;
    undefined (*pauVar16) [32];
    undefined (*pauVar17) [32];
    undefined (*pauVar18) [32];
    undefined4 *puVar19;
    undefined4 *puVar20;
    undefined (*pauVar21) [32];
    undefined (*pauVar22) [32];
    undefined4 *puVar23;
    uint32_t uVar24;
    int64_t unaff_RSI;
    uint64_t unaff_RDI;
    uint64_t uVar25;
    uint64_t uVar26;
    uint32_t uVar27;
    int64_t iVar28;
    undefined4 uVar29;
    undefined4 uVar31;
    undefined4 uVar32;
    undefined4 uVar33;
    undefined auVar30 [32];
    undefined auVar34 [32];
    undefined auVar35 [32];
    undefined auVar36 [32];
    undefined auVar37 [32];
    undefined auVar38 [32];
    undefined8 auStack_50 [6];
    
    uVar27 = *(uint32_t *)(arg1 + 0x14);
    uVar24 = (uint32_t)arg3;
    uVar15 = uVar27 + uVar24 * 8;
    *(uint32_t *)(arg1 + 0x14) = uVar15;
    if (uVar15 < uVar27) {
        *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) + 1;
    }
    uVar27 = uVar27 >> 3 & 0x3f;
    *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) + (int32_t)((arg3 & 0xffffffffU) >> 0x1d);
    if (uVar27 + uVar24 < 0x40) {
        pauVar16 = (undefined (*) [32])((uint64_t)uVar27 + arg1 + 0x1c);
    } else {
        uVar24 = 0x40 - uVar27;
        pauVar16 = (undefined (*) [32])((uint64_t)uVar27 + 0x1c + arg1);
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
        auStack_50[0] = 0x18018b9a8;
        unaff_RSI = arg1;
        unaff_RDI = arg3 & 0xffffffffU;
    }
    uVar25 = (uint64_t)uVar24;
    // switch table (16 cases) at 0x180650960
    switch(uVar25) {
    case 0:
        return;
    case 1:
        (*pauVar16)[0] = *(undefined *)arg2;
        return;
    case 2:
        *(undefined2 *)*pauVar16 = *(undefined2 *)arg2;
        return;
    case 3:
        uVar2 = *(undefined *)(arg2 + 2);
        *(undefined2 *)*pauVar16 = *(undefined2 *)arg2;
        (*pauVar16)[2] = uVar2;
        return;
    case 4:
        *(undefined4 *)*pauVar16 = *(undefined4 *)arg2;
        return;
    case 5:
        uVar2 = *(undefined *)(arg2 + 4);
        *(undefined4 *)*pauVar16 = *(undefined4 *)arg2;
        (*pauVar16)[4] = uVar2;
        return;
    case 6:
        uVar3 = *(undefined2 *)(arg2 + 4);
        *(undefined4 *)*pauVar16 = *(undefined4 *)arg2;
        *(undefined2 *)(*pauVar16 + 4) = uVar3;
        return;
    case 7:
        uVar3 = *(undefined2 *)(arg2 + 4);
        uVar2 = *(undefined *)(arg2 + 6);
        *(undefined4 *)*pauVar16 = *(undefined4 *)arg2;
        *(undefined2 *)(*pauVar16 + 4) = uVar3;
        (*pauVar16)[6] = uVar2;
        return;
    case 8:
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        return;
    case 9:
        uVar2 = *(undefined *)(arg2 + 8);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        (*pauVar16)[8] = uVar2;
        return;
    case 10:
        uVar3 = *(undefined2 *)(arg2 + 8);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        *(undefined2 *)(*pauVar16 + 8) = uVar3;
        return;
    case 0xb:
        uVar3 = *(undefined2 *)(arg2 + 8);
        uVar2 = *(undefined *)(arg2 + 10);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        *(undefined2 *)(*pauVar16 + 8) = uVar3;
        (*pauVar16)[10] = uVar2;
        return;
    case 0xc:
        uVar4 = *(undefined4 *)(arg2 + 8);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar16 + 8) = uVar4;
        return;
    case 0xd:
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar2 = *(undefined *)(arg2 + 0xc);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar16 + 8) = uVar4;
        (*pauVar16)[0xc] = uVar2;
        return;
    case 0xe:
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar3 = *(undefined2 *)(arg2 + 0xc);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar16 + 8) = uVar4;
        *(undefined2 *)(*pauVar16 + 0xc) = uVar3;
        return;
    case 0xf:
        uVar4 = *(undefined4 *)(arg2 + 8);
        uVar3 = *(undefined2 *)(arg2 + 0xc);
        uVar2 = *(undefined *)(arg2 + 0xe);
        *(undefined8 *)*pauVar16 = *(undefined8 *)arg2;
        *(undefined4 *)(*pauVar16 + 8) = uVar4;
        *(undefined2 *)(*pauVar16 + 0xc) = uVar3;
        (*pauVar16)[0xe] = uVar2;
        return;
    }
    if (uVar25 < 0x21) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        puVar19 = (undefined4 *)(arg2 + -0x10 + uVar25);
        uVar7 = *puVar19;
        uVar8 = puVar19[1];
        uVar9 = puVar19[2];
        uVar10 = puVar19[3];
        *(undefined4 *)*pauVar16 = *(undefined4 *)arg2;
        *(undefined4 *)(*pauVar16 + 4) = uVar4;
        *(undefined4 *)(*pauVar16 + 8) = uVar5;
        *(undefined4 *)(*pauVar16 + 0xc) = uVar6;
        puVar19 = (undefined4 *)(pauVar16[-1] + uVar25 + 0x10);
        *puVar19 = uVar7;
        puVar19[1] = uVar8;
        puVar19[2] = uVar9;
        puVar19[3] = uVar10;
        return;
    }
    pauVar17 = (undefined (*) [32])(arg2 + uVar25);
    if (pauVar16 <= (uint64_t)arg2) {
        pauVar17 = pauVar16;
    }
    if (pauVar16 < pauVar17) {
        uVar4 = *(undefined4 *)arg2;
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        arg2 = arg2 - (int64_t)pauVar16;
        puVar19 = (undefined4 *)((int64_t)pauVar16 + arg2 + (uVar25 - 0x10));
        uVar8 = puVar19[1];
        uVar9 = puVar19[2];
        uVar10 = puVar19[3];
        puVar20 = (undefined4 *)(pauVar16[-1] + uVar25 + 0x10);
        uVar26 = uVar25 - 0x10;
        puVar23 = puVar20;
        uVar29 = *puVar19;
        uVar31 = uVar8;
        uVar32 = uVar9;
        uVar33 = uVar10;
        if (((uint64_t)puVar20 & 0xf) != 0) {
            puVar23 = (undefined4 *)((uint64_t)puVar20 & 0xfffffffffffffff0);
            puVar1 = (undefined4 *)((int64_t)puVar23 + arg2);
            uVar29 = *puVar1;
            uVar31 = puVar1[1];
            uVar32 = puVar1[2];
            uVar33 = puVar1[3];
            *puVar20 = *puVar19;
            *(undefined4 *)(pauVar16[-1] + uVar25 + 0x14) = uVar8;
            *(undefined4 *)(pauVar16[-1] + uVar25 + 0x18) = uVar9;
            *(undefined4 *)(pauVar16[-1] + uVar25 + 0x1c) = uVar10;
            uVar26 = (int64_t)puVar23 - (int64_t)pauVar16;
        }
        uVar25 = uVar26 >> 7;
        if (uVar25 != 0) {
            *puVar23 = uVar29;
            puVar23[1] = uVar31;
            puVar23[2] = uVar32;
            puVar23[3] = uVar33;
            puVar19 = puVar23;
            while( true ) {
                puVar20 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x10);
                uVar8 = puVar20[1];
                uVar9 = puVar20[2];
                uVar10 = puVar20[3];
                puVar23 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x20);
                uVar29 = *puVar23;
                uVar31 = puVar23[1];
                uVar32 = puVar23[2];
                uVar33 = puVar23[3];
                puVar23 = puVar19 + -0x20;
                puVar19[-4] = *puVar20;
                puVar19[-3] = uVar8;
                puVar19[-2] = uVar9;
                puVar19[-1] = uVar10;
                puVar19[-8] = uVar29;
                puVar19[-7] = uVar31;
                puVar19[-6] = uVar32;
                puVar19[-5] = uVar33;
                puVar20 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x30);
                uVar8 = puVar20[1];
                uVar9 = puVar20[2];
                uVar10 = puVar20[3];
                puVar1 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x40);
                uVar29 = *puVar1;
                uVar31 = puVar1[1];
                uVar32 = puVar1[2];
                uVar33 = puVar1[3];
                uVar25 = uVar25 - 1;
                puVar19[-0xc] = *puVar20;
                puVar19[-0xb] = uVar8;
                puVar19[-10] = uVar9;
                puVar19[-9] = uVar10;
                puVar19[-0x10] = uVar29;
                puVar19[-0xf] = uVar31;
                puVar19[-0xe] = uVar32;
                puVar19[-0xd] = uVar33;
                puVar20 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x50);
                uVar8 = puVar20[1];
                uVar9 = puVar20[2];
                uVar10 = puVar20[3];
                puVar1 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x60);
                uVar29 = *puVar1;
                uVar31 = puVar1[1];
                uVar32 = puVar1[2];
                uVar33 = puVar1[3];
                puVar19[-0x14] = *puVar20;
                puVar19[-0x13] = uVar8;
                puVar19[-0x12] = uVar9;
                puVar19[-0x11] = uVar10;
                puVar19[-0x18] = uVar29;
                puVar19[-0x17] = uVar31;
                puVar19[-0x16] = uVar32;
                puVar19[-0x15] = uVar33;
                puVar1 = (undefined4 *)((int64_t)puVar19 + arg2 + -0x70);
                uVar8 = puVar1[1];
                uVar9 = puVar1[2];
                uVar10 = puVar1[3];
                puVar20 = (undefined4 *)((int64_t)puVar23 + arg2);
                uVar29 = *puVar20;
                uVar31 = puVar20[1];
                uVar32 = puVar20[2];
                uVar33 = puVar20[3];
                if (uVar25 == 0) break;
                puVar19[-0x1c] = *puVar1;
                puVar19[-0x1b] = uVar8;
                puVar19[-0x1a] = uVar9;
                puVar19[-0x19] = uVar10;
                *puVar23 = uVar29;
                puVar19[-0x1f] = uVar31;
                puVar19[-0x1e] = uVar32;
                puVar19[-0x1d] = uVar33;
                puVar19 = puVar23;
            }
            puVar19[-0x1c] = *puVar1;
            puVar19[-0x1b] = uVar8;
            puVar19[-0x1a] = uVar9;
            puVar19[-0x19] = uVar10;
            uVar26 = uVar26 & 0x7f;
        }
        for (uVar25 = uVar26 >> 4; uVar25 != 0; uVar25 = uVar25 - 1) {
            *puVar23 = uVar29;
            puVar23[1] = uVar31;
            puVar23[2] = uVar32;
            puVar23[3] = uVar33;
            puVar23 = puVar23 + -4;
            puVar19 = (undefined4 *)((int64_t)puVar23 + arg2);
            uVar29 = *puVar19;
            uVar31 = puVar19[1];
            uVar32 = puVar19[2];
            uVar33 = puVar19[3];
        }
        if ((uVar26 & 0xf) != 0) {
            *(undefined4 *)*pauVar16 = uVar4;
            *(undefined4 *)(*pauVar16 + 4) = uVar5;
            *(undefined4 *)(*pauVar16 + 8) = uVar6;
            *(undefined4 *)(*pauVar16 + 0xc) = uVar7;
        }
        *puVar23 = uVar29;
        puVar23[1] = uVar31;
        puVar23[2] = uVar32;
        puVar23[3] = uVar33;
        return;
    }
    if (*(uint32_t *)0x1806a3990 < 3) {
        if ((uVar25 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
            if (0x80 < uVar25) {
                iVar28 = ((uint64_t)pauVar16 & 0xf) - 0x10;
                puVar19 = (undefined4 *)((int64_t)pauVar16 - iVar28);
                puVar23 = (undefined4 *)(arg2 - iVar28);
                uVar25 = uVar25 + iVar28;
                if (0x80 < uVar25) {
                    do {
                        uVar4 = puVar23[1];
                        uVar5 = puVar23[2];
                        uVar6 = puVar23[3];
                        uVar7 = puVar23[4];
                        uVar8 = puVar23[5];
                        uVar9 = puVar23[6];
                        uVar10 = puVar23[7];
                        uVar29 = puVar23[8];
                        uVar31 = puVar23[9];
                        uVar32 = puVar23[10];
                        uVar33 = puVar23[0xb];
                        uVar11 = puVar23[0xc];
                        uVar12 = puVar23[0xd];
                        uVar13 = puVar23[0xe];
                        uVar14 = puVar23[0xf];
                        *puVar19 = *puVar23;
                        puVar19[1] = uVar4;
                        puVar19[2] = uVar5;
                        puVar19[3] = uVar6;
                        puVar19[4] = uVar7;
                        puVar19[5] = uVar8;
                        puVar19[6] = uVar9;
                        puVar19[7] = uVar10;
                        puVar19[8] = uVar29;
                        puVar19[9] = uVar31;
                        puVar19[10] = uVar32;
                        puVar19[0xb] = uVar33;
                        puVar19[0xc] = uVar11;
                        puVar19[0xd] = uVar12;
                        puVar19[0xe] = uVar13;
                        puVar19[0xf] = uVar14;
                        uVar4 = puVar23[0x11];
                        uVar5 = puVar23[0x12];
                        uVar6 = puVar23[0x13];
                        uVar7 = puVar23[0x14];
                        uVar8 = puVar23[0x15];
                        uVar9 = puVar23[0x16];
                        uVar10 = puVar23[0x17];
                        uVar29 = puVar23[0x18];
                        uVar31 = puVar23[0x19];
                        uVar32 = puVar23[0x1a];
                        uVar33 = puVar23[0x1b];
                        uVar11 = puVar23[0x1c];
                        uVar12 = puVar23[0x1d];
                        uVar13 = puVar23[0x1e];
                        uVar14 = puVar23[0x1f];
                        puVar19[0x10] = puVar23[0x10];
                        puVar19[0x11] = uVar4;
                        puVar19[0x12] = uVar5;
                        puVar19[0x13] = uVar6;
                        puVar19[0x14] = uVar7;
                        puVar19[0x15] = uVar8;
                        puVar19[0x16] = uVar9;
                        puVar19[0x17] = uVar10;
                        puVar19[0x18] = uVar29;
                        puVar19[0x19] = uVar31;
                        puVar19[0x1a] = uVar32;
                        puVar19[0x1b] = uVar33;
                        puVar19[0x1c] = uVar11;
                        puVar19[0x1d] = uVar12;
                        puVar19[0x1e] = uVar13;
                        puVar19[0x1f] = uVar14;
                        puVar19 = puVar19 + 0x20;
                        puVar23 = puVar23 + 0x20;
                        uVar25 = uVar25 - 0x80;
                    } while (0x7f < uVar25);
                }
            }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
            (*(code *)((uint64_t)*(uint32_t *)((uVar25 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
            return;
        }
code_r0x000180498020:
        *(uint64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
        *(int64_t *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
        for (; uVar25 != 0; uVar25 = uVar25 - 1) {
            (*pauVar16)[0] = *(undefined *)arg2;
            arg2 = (int64_t)(arg2 + 1);
            pauVar16 = (undefined (*) [32])(*pauVar16 + 1);
        }
        return;
    }
    if ((0x2000 < uVar25) && (uVar25 < 0x180001)) {
        pauVar17 = pauVar16 + 2;
        if ((uint64_t)arg2 < pauVar16) {
            pauVar17 = (undefined (*) [32])arg2;
        }
        if ((pauVar17 <= (uint64_t)arg2) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
    }
    auVar30 = vmovdqu_avx(*(undefined (*) [32])arg2);
    auVar38 = vmovdqu_avx(*(undefined (*) [32])(arg2 + -0x20 + uVar25));
    if (0x100 < uVar25) {
        iVar28 = ((uint64_t)pauVar16 & 0x1f) - 0x20;
        pauVar17 = (undefined (*) [32])((int64_t)pauVar16 - iVar28);
        pauVar21 = (undefined (*) [32])(arg2 - iVar28);
        uVar25 = uVar25 + iVar28;
        if (0x100 < uVar25) {
            if (0x180000 < uVar25) {
                do {
                    uVar26 = uVar25;
                    pauVar22 = pauVar21;
                    pauVar18 = pauVar17;
                    auVar34 = vmovdqu_avx(*pauVar22);
                    auVar36 = vmovdqu_avx(pauVar22[1]);
                    auVar35 = vmovdqu_avx(pauVar22[2]);
                    auVar37 = vmovdqu_avx(pauVar22[3]);
                    auVar34 = vmovntdq_avx(auVar34);
                    *pauVar18 = auVar34;
                    auVar34 = vmovntdq_avx(auVar36);
                    pauVar18[1] = auVar34;
                    auVar34 = vmovntdq_avx(auVar35);
                    pauVar18[2] = auVar34;
                    auVar34 = vmovntdq_avx(auVar37);
                    pauVar18[3] = auVar34;
                    auVar34 = vmovdqu_avx(pauVar22[4]);
                    auVar36 = vmovdqu_avx(pauVar22[5]);
                    auVar35 = vmovdqu_avx(pauVar22[6]);
                    auVar37 = vmovdqu_avx(pauVar22[7]);
                    auVar34 = vmovntdq_avx(auVar34);
                    pauVar18[4] = auVar34;
                    auVar34 = vmovntdq_avx(auVar36);
                    pauVar18[5] = auVar34;
                    auVar34 = vmovntdq_avx(auVar35);
                    pauVar18[6] = auVar34;
                    auVar34 = vmovntdq_avx(auVar37);
                    pauVar18[7] = auVar34;
                    pauVar17 = pauVar18 + 8;
                    pauVar21 = pauVar22 + 8;
                    uVar25 = uVar26 - 0x100;
                } while (0xff < uVar26 - 0x100);
                uVar25 = uVar26 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                switch(uVar26) {
                case 0x1e1:
                case 0x1e2:
                case 0x1e3:
                case 0x1e4:
                case 0x1e5:
                case 0x1e6:
                case 0x1e7:
                case 0x1e8:
                case 0x1e9:
                case 0x1ea:
                case 0x1eb:
                case 0x1ec:
                case 0x1ed:
                case 0x1ee:
                case 0x1ef:
                case 0x1f0:
                case 0x1f1:
                case 0x1f2:
                case 499:
                case 500:
                case 0x1f5:
                case 0x1f6:
                case 0x1f7:
                case 0x1f8:
                case 0x1f9:
                case 0x1fa:
                case 0x1fb:
                case 0x1fc:
                case 0x1fd:
                case 0x1fe:
                case 0x1ff:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(*pauVar22 + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(*pauVar18 + uVar25) = auVar34;
                case 0x1c1:
                case 0x1c2:
                case 0x1c3:
                case 0x1c4:
                case 0x1c5:
                case 0x1c6:
                case 0x1c7:
                case 0x1c8:
                case 0x1c9:
                case 0x1ca:
                case 0x1cb:
                case 0x1cc:
                case 0x1cd:
                case 0x1ce:
                case 0x1cf:
                case 0x1d0:
                case 0x1d1:
                case 0x1d2:
                case 0x1d3:
                case 0x1d4:
                case 0x1d5:
                case 0x1d6:
                case 0x1d7:
                case 0x1d8:
                case 0x1d9:
                case 0x1da:
                case 0x1db:
                case 0x1dc:
                case 0x1dd:
                case 0x1de:
                case 0x1df:
                case 0x1e0:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar22[1] + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar18[1] + uVar25) = auVar34;
                case 0x1a1:
                case 0x1a2:
                case 0x1a3:
                case 0x1a4:
                case 0x1a5:
                case 0x1a6:
                case 0x1a7:
                case 0x1a8:
                case 0x1a9:
                case 0x1aa:
                case 0x1ab:
                case 0x1ac:
                case 0x1ad:
                case 0x1ae:
                case 0x1af:
                case 0x1b0:
                case 0x1b1:
                case 0x1b2:
                case 0x1b3:
                case 0x1b4:
                case 0x1b5:
                case 0x1b6:
                case 0x1b7:
                case 0x1b8:
                case 0x1b9:
                case 0x1ba:
                case 0x1bb:
                case 0x1bc:
                case 0x1bd:
                case 0x1be:
                case 0x1bf:
                case 0x1c0:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar22[2] + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar18[2] + uVar25) = auVar34;
                case 0x181:
                case 0x182:
                case 0x183:
                case 0x184:
                case 0x185:
                case 0x186:
                case 0x187:
                case 0x188:
                case 0x189:
                case 0x18a:
                case 0x18b:
                case 0x18c:
                case 0x18d:
                case 0x18e:
                case 399:
                case 400:
                case 0x191:
                case 0x192:
                case 0x193:
                case 0x194:
                case 0x195:
                case 0x196:
                case 0x197:
                case 0x198:
                case 0x199:
                case 0x19a:
                case 0x19b:
                case 0x19c:
                case 0x19d:
                case 0x19e:
                case 0x19f:
                case 0x1a0:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar22[3] + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar18[3] + uVar25) = auVar34;
                case 0x161:
                case 0x162:
                case 0x163:
                case 0x164:
                case 0x165:
                case 0x166:
                case 0x167:
                case 0x168:
                case 0x169:
                case 0x16a:
                case 0x16b:
                case 0x16c:
                case 0x16d:
                case 0x16e:
                case 0x16f:
                case 0x170:
                case 0x171:
                case 0x172:
                case 0x173:
                case 0x174:
                case 0x175:
                case 0x176:
                case 0x177:
                case 0x178:
                case 0x179:
                case 0x17a:
                case 0x17b:
                case 0x17c:
                case 0x17d:
                case 0x17e:
                case 0x17f:
                case 0x180:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar22[4] + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar18[4] + uVar25) = auVar34;
                case 0x141:
                case 0x142:
                case 0x143:
                case 0x144:
                case 0x145:
                case 0x146:
                case 0x147:
                case 0x148:
                case 0x149:
                case 0x14a:
                case 0x14b:
                case 0x14c:
                case 0x14d:
                case 0x14e:
                case 0x14f:
                case 0x150:
                case 0x151:
                case 0x152:
                case 0x153:
                case 0x154:
                case 0x155:
                case 0x156:
                case 0x157:
                case 0x158:
                case 0x159:
                case 0x15a:
                case 0x15b:
                case 0x15c:
                case 0x15d:
                case 0x15e:
                case 0x15f:
                case 0x160:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar22[5] + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar18[5] + uVar25) = auVar34;
                case 0x121:
                case 0x122:
                case 0x123:
                case 0x124:
                case 0x125:
                case 0x126:
                case 0x127:
                case 0x128:
                case 0x129:
                case 0x12a:
                case 299:
                case 300:
                case 0x12d:
                case 0x12e:
                case 0x12f:
                case 0x130:
                case 0x131:
                case 0x132:
                case 0x133:
                case 0x134:
                case 0x135:
                case 0x136:
                case 0x137:
                case 0x138:
                case 0x139:
                case 0x13a:
                case 0x13b:
                case 0x13c:
                case 0x13d:
                case 0x13e:
                case 0x13f:
                case 0x140:
                    auVar34 = vmovdqu_avx(*(undefined (*) [32])(pauVar22[6] + uVar25));
                    auVar34 = vmovntdq_avx(auVar34);
                    *(undefined (*) [32])(pauVar18[6] + uVar25) = auVar34;
                default:
                    auVar38 = vmovdqu_avx(auVar38);
                    *(undefined (*) [32])(pauVar18[-1] + uVar26) = auVar38;
                case 0x100:
                    auVar30 = vmovdqu_avx(auVar30);
                    *pauVar16 = auVar30;
                    return;
                }
            }
            do {
                auVar30 = vmovdqu_avx(*pauVar21);
                auVar38 = vmovdqu_avx(pauVar21[1]);
                auVar34 = vmovdqu_avx(pauVar21[2]);
                auVar36 = vmovdqu_avx(pauVar21[3]);
                *pauVar17 = auVar30;
                pauVar17[1] = auVar38;
                pauVar17[2] = auVar34;
                pauVar17[3] = auVar36;
                auVar30 = vmovdqu_avx(pauVar21[4]);
                auVar38 = vmovdqu_avx(pauVar21[5]);
                auVar34 = vmovdqu_avx(pauVar21[6]);
                auVar36 = vmovdqu_avx(pauVar21[7]);
                pauVar17[4] = auVar30;
                pauVar17[5] = auVar38;
                pauVar17[6] = auVar34;
                pauVar17[7] = auVar36;
                pauVar17 = pauVar17 + 8;
                pauVar21 = pauVar21 + 8;
                uVar25 = uVar25 - 0x100;
            } while (0xff < uVar25);
        }
    }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
    (*(code *)((uint64_t)*(uint32_t *)((uVar25 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
    return;
}

// ============================================================
// Function: FUN_18018ba00
// Address: 0x18018ba00
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18018ba00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    uint64_t uVar4;
    uint8_t uVar5;
    uint32_t uVar6;
    undefined uVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = 0;
    if ((arg2 & 0x10U) != 0) {
        uVar5 = 0x80;
    }
    *(uint8_t *)arg1 = (uint8_t)arg2 & 0xf | uVar5;
    uVar5 = 0;
    if ((arg2 & 0x20U) != 0) {
        uVar5 = 0x80;
    }
    uVar3 = (uint8_t)arg_28h;
    if ((uint64_t)arg_28h < 0x7e) {
        iVar8 = 2;
        *(uint8_t *)(arg1 + 1) = uVar3 | uVar5;
    } else {
        uVar7 = (undefined)((uint64_t)arg_28h >> 8);
        if ((uint64_t)arg_28h < 0x10000) {
            uVar5 = uVar5 | 0x7e;
            *(undefined *)(arg1 + 2) = uVar7;
            *(uint8_t *)(arg1 + 3) = uVar3;
            iVar8 = 4;
        } else {
            *(undefined *)(arg1 + 8) = uVar7;
            uVar5 = uVar5 | 0x7f;
            *(char *)(arg1 + 2) = (char)((uint64_t)arg_28h >> 0x38);
            iVar8 = 10;
            *(uint8_t *)(arg1 + 9) = uVar3;
            *(char *)(arg1 + 3) = (char)((uint64_t)arg_28h >> 0x30);
            *(char *)(arg1 + 4) = (char)((uint64_t)arg_28h >> 0x28);
            *(char *)(arg1 + 5) = (char)((uint64_t)arg_28h >> 0x20);
            *(char *)(arg1 + 6) = (char)((uint64_t)arg_28h >> 0x18);
            *(char *)(arg1 + 7) = (char)((uint64_t)arg_28h >> 0x10);
        }
        *(uint8_t *)(arg1 + 1) = uVar5;
    }
    if ((arg2 & 0x20U) != 0) {
        if (arg3 != 0) {
            *(undefined4 *)(iVar8 + arg1) = *(undefined4 *)arg3;
        }
        uVar4 = 0;
        if (arg_28h != 0) {
            do {
                uVar6 = (uint32_t)uVar4;
                iVar1 = arg1 + uVar4;
                puVar2 = (uint8_t *)(arg4 + uVar4);
                uVar4 = uVar4 + 1;
                *(uint8_t *)(iVar1 + 4 + iVar8) = *(uint8_t *)((uint64_t)(uVar6 & 3) + arg1 + iVar8) ^ *puVar2;
            } while (uVar4 < (uint64_t)arg_28h);
        }
        return arg_28h + 4 + iVar8;
    }
    func_0x000180498030(iVar8 + arg1, arg4, arg_28h);
    return iVar8 + arg_28h;
}

// ============================================================
// Function: FUN_18018ba18
// Address: 0x18018ba18
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18018ba00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    uint64_t uVar4;
    uint8_t uVar5;
    uint32_t uVar6;
    undefined uVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = 0;
    if ((arg2 & 0x10U) != 0) {
        uVar5 = 0x80;
    }
    *(uint8_t *)arg1 = (uint8_t)arg2 & 0xf | uVar5;
    uVar5 = 0;
    if ((arg2 & 0x20U) != 0) {
        uVar5 = 0x80;
    }
    uVar3 = (uint8_t)arg_28h;
    if ((uint64_t)arg_28h < 0x7e) {
        iVar8 = 2;
        *(uint8_t *)(arg1 + 1) = uVar3 | uVar5;
    } else {
        uVar7 = (undefined)((uint64_t)arg_28h >> 8);
        if ((uint64_t)arg_28h < 0x10000) {
            uVar5 = uVar5 | 0x7e;
            *(undefined *)(arg1 + 2) = uVar7;
            *(uint8_t *)(arg1 + 3) = uVar3;
            iVar8 = 4;
        } else {
            *(undefined *)(arg1 + 8) = uVar7;
            uVar5 = uVar5 | 0x7f;
            *(char *)(arg1 + 2) = (char)((uint64_t)arg_28h >> 0x38);
            iVar8 = 10;
            *(uint8_t *)(arg1 + 9) = uVar3;
            *(char *)(arg1 + 3) = (char)((uint64_t)arg_28h >> 0x30);
            *(char *)(arg1 + 4) = (char)((uint64_t)arg_28h >> 0x28);
            *(char *)(arg1 + 5) = (char)((uint64_t)arg_28h >> 0x20);
            *(char *)(arg1 + 6) = (char)((uint64_t)arg_28h >> 0x18);
            *(char *)(arg1 + 7) = (char)((uint64_t)arg_28h >> 0x10);
        }
        *(uint8_t *)(arg1 + 1) = uVar5;
    }
    if ((arg2 & 0x20U) != 0) {
        if (arg3 != 0) {
            *(undefined4 *)(iVar8 + arg1) = *(undefined4 *)arg3;
        }
        uVar4 = 0;
        if (arg_28h != 0) {
            do {
                uVar6 = (uint32_t)uVar4;
                iVar1 = arg1 + uVar4;
                puVar2 = (uint8_t *)(arg4 + uVar4);
                uVar4 = uVar4 + 1;
                *(uint8_t *)(iVar1 + 4 + iVar8) = *(uint8_t *)((uint64_t)(uVar6 & 3) + arg1 + iVar8) ^ *puVar2;
            } while (uVar4 < (uint64_t)arg_28h);
        }
        return arg_28h + 4 + iVar8;
    }
    func_0x000180498030(iVar8 + arg1, arg4, arg_28h);
    return iVar8 + arg_28h;
}

// ============================================================
// Function: FUN_18018bad8
// Address: 0x18018bad8
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18018ba00(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t iVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    uint64_t uVar4;
    uint8_t uVar5;
    uint32_t uVar6;
    undefined uVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = 0;
    if ((arg2 & 0x10U) != 0) {
        uVar5 = 0x80;
    }
    *(uint8_t *)arg1 = (uint8_t)arg2 & 0xf | uVar5;
    uVar5 = 0;
    if ((arg2 & 0x20U) != 0) {
        uVar5 = 0x80;
    }
    uVar3 = (uint8_t)arg_28h;
    if ((uint64_t)arg_28h < 0x7e) {
        iVar8 = 2;
        *(uint8_t *)(arg1 + 1) = uVar3 | uVar5;
    } else {
        uVar7 = (undefined)((uint64_t)arg_28h >> 8);
        if ((uint64_t)arg_28h < 0x10000) {
            uVar5 = uVar5 | 0x7e;
            *(undefined *)(arg1 + 2) = uVar7;
            *(uint8_t *)(arg1 + 3) = uVar3;
            iVar8 = 4;
        } else {
            *(undefined *)(arg1 + 8) = uVar7;
            uVar5 = uVar5 | 0x7f;
            *(char *)(arg1 + 2) = (char)((uint64_t)arg_28h >> 0x38);
            iVar8 = 10;
            *(uint8_t *)(arg1 + 9) = uVar3;
            *(char *)(arg1 + 3) = (char)((uint64_t)arg_28h >> 0x30);
            *(char *)(arg1 + 4) = (char)((uint64_t)arg_28h >> 0x28);
            *(char *)(arg1 + 5) = (char)((uint64_t)arg_28h >> 0x20);
            *(char *)(arg1 + 6) = (char)((uint64_t)arg_28h >> 0x18);
            *(char *)(arg1 + 7) = (char)((uint64_t)arg_28h >> 0x10);
        }
        *(uint8_t *)(arg1 + 1) = uVar5;
    }
    if ((arg2 & 0x20U) != 0) {
        if (arg3 != 0) {
            *(undefined4 *)(iVar8 + arg1) = *(undefined4 *)arg3;
        }
        uVar4 = 0;
        if (arg_28h != 0) {
            do {
                uVar6 = (uint32_t)uVar4;
                iVar1 = arg1 + uVar4;
                puVar2 = (uint8_t *)(arg4 + uVar4);
                uVar4 = uVar4 + 1;
                *(uint8_t *)(iVar1 + 4 + iVar8) = *(uint8_t *)((uint64_t)(uVar6 & 3) + arg1 + iVar8) ^ *puVar2;
            } while (uVar4 < (uint64_t)arg_28h);
        }
        return arg_28h + 4 + iVar8;
    }
    func_0x000180498030(iVar8 + arg1, arg4, arg_28h);
    return iVar8 + arg_28h;
}

// ============================================================
// Function: FUN_18018bb80
// Address: 0x18018bb80
// Size: 791 bytes
// ============================================================
int64_t fcn.18018bb80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    uint8_t *puVar10;
    int64_t iVar11;
    
    puVar1 = (uint8_t *)(arg3 + arg4);
    if ((uint8_t *)arg3 != puVar1) {
        iVar11 = 0;
        iVar9 = iVar11;
        puVar10 = (uint8_t *)arg3;
        do {
            iVar4 = *(int32_t *)arg1;
            if (iVar4 == 0) {
                *(undefined8 *)(arg1 + 0x20) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                *(undefined *)(arg1 + 0xc) = 0;
                uVar2 = *puVar10;
                *(uint32_t *)(arg1 + 4) = (int32_t)(char)uVar2 & 0xfU;
                if ((char)*puVar10 < '\0') {
                    *(uint32_t *)(arg1 + 4) = (int32_t)(char)uVar2 & 0xfU | 0x10;
                }
                *(undefined4 *)arg1 = 1;
code_r0x00018018be83:
                iVar9 = iVar9 + 1;
            } else {
                if (iVar4 == 1) {
                    uVar8 = (uint64_t)((int32_t)(char)*puVar10 & 0x7f);
                    *(uint64_t *)(arg1 + 0x10) = uVar8;
                    if ((char)*puVar10 < '\0') {
                        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 0x20;
                    }
                    if (uVar8 < 0x7e) {
                        if ((*(uint8_t *)(arg1 + 4) & 0x20) == 0) {
                            if (uVar8 == 0) {
                                *(undefined4 *)arg1 = 0;
                                if ((*(code **)arg2 != (code *)0x0) && (iVar4 = (**(code **)arg2)(arg1), iVar4 != 0))
                                goto code_r0x00018018bc7e;
                                pcVar5 = *(code **)(arg2 + 0x10);
                            } else {
                                *(undefined4 *)arg1 = 4;
                                *(uint64_t *)(arg1 + 0x18) = uVar8;
                                pcVar5 = *(code **)arg2;
                            }
                            if ((pcVar5 != (code *)0x0) && (iVar4 = (*pcVar5)(arg1), iVar4 != 0))
                            goto code_r0x00018018bc7e;
                        } else {
                            *(undefined4 *)arg1 = 3;
                            *(undefined8 *)(arg1 + 0x18) = 4;
                        }
                    } else {
                        uVar6 = 8;
                        if (uVar8 != 0x7f) {
                            uVar6 = 2;
                        }
                        *(undefined8 *)(arg1 + 0x18) = uVar6;
                        *(undefined8 *)(arg1 + 0x10) = 0;
                        *(undefined4 *)arg1 = 2;
                    }
                    goto code_r0x00018018be83;
                }
                if (iVar4 == 2) {
                    while ((puVar10 < puVar1 && (*(int64_t *)(arg1 + 0x18) != 0))) {
                        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) << 8;
                        iVar9 = iVar9 + 1;
                        uVar2 = *puVar10;
                        puVar10 = puVar10 + 1;
                        *(uint64_t *)(arg1 + 0x10) = *(uint64_t *)(arg1 + 0x10) | (uint64_t)uVar2;
                        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + -1;
                    }
                    puVar10 = puVar10 + -1;
                    if (*(int64_t *)(arg1 + 0x18) == 0) {
                        if ((*(uint8_t *)(arg1 + 4) & 0x20) == 0) {
                            if (*(int64_t *)(arg1 + 0x10) == 0) {
                                *(undefined4 *)arg1 = 0;
                                if ((*(code **)arg2 != (code *)0x0) && (iVar4 = (**(code **)arg2)(arg1), iVar4 != 0))
                                goto code_r0x00018018bc7e;
                                pcVar5 = *(code **)(arg2 + 0x10);
                            } else {
                                *(undefined4 *)arg1 = 4;
                                *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x10);
                                pcVar5 = *(code **)arg2;
                            }
code_r0x00018018bdb2:
                            if (pcVar5 != (code *)0x0) {
                                iVar4 = (*pcVar5)(arg1);
                                goto joined_r0x00018018bdc2;
                            }
                        } else {
                            *(undefined4 *)arg1 = 3;
                            *(undefined8 *)(arg1 + 0x18) = 4;
                        }
                    }
                } else if (iVar4 == 3) {
                    while ((puVar10 < puVar1 && (*(int64_t *)(arg1 + 0x18) != 0))) {
                        iVar9 = iVar9 + 1;
                        uVar2 = *puVar10;
                        puVar10 = puVar10 + 1;
                        *(uint8_t *)((arg1 - *(int64_t *)(arg1 + 0x18)) + 0xc) = uVar2;
                        *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + -1;
                    }
                    puVar10 = puVar10 + -1;
                    if (*(int64_t *)(arg1 + 0x18) == 0) {
                        if (*(int64_t *)(arg1 + 0x10) != 0) {
                            *(undefined4 *)arg1 = 4;
                            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x10);
                            pcVar5 = *(code **)arg2;
                            goto code_r0x00018018bdb2;
                        }
                        *(undefined4 *)arg1 = 0;
                        if ((*(code **)arg2 != (code *)0x0) && (iVar4 = (**(code **)arg2)(arg1), iVar4 != 0))
                        goto code_r0x00018018bc7e;
                        if (*(code **)(arg2 + 0x10) != (code *)0x0) {
                            iVar4 = (**(code **)(arg2 + 0x10))(arg1);
                            goto joined_r0x00018018bdc2;
                        }
                    }
                } else if (iVar4 == 4) {
                    if (*(int64_t *)(arg1 + 0x18) != 0) {
                        pcVar5 = *(code **)(arg2 + 8);
                        if (puVar1 < puVar10 + *(int64_t *)(arg1 + 0x18)) {
                            if ((pcVar5 != (code *)0x0) &&
                               (iVar4 = (*pcVar5)(arg1, puVar10, (int64_t)puVar1 - (int64_t)puVar10), iVar4 != 0))
                            goto code_r0x00018018bc7e;
                            *(uint8_t **)(arg1 + 0x18) =
                                 puVar10 + ((int64_t)*(uint8_t **)(arg1 + 0x18) - (int64_t)puVar1);
                            iVar7 = *(int64_t *)(arg1 + 0x18);
                            *(uint8_t **)(arg1 + 0x20) =
                                 puVar1 + (int64_t)(*(uint8_t **)(arg1 + 0x20) + (-arg3 - iVar9));
                            iVar9 = iVar11;
                            puVar10 = puVar1;
                        } else {
                            if ((pcVar5 != (code *)0x0) && (iVar4 = (*pcVar5)(arg1, puVar10), iVar4 != 0))
                            goto code_r0x00018018bc7e;
                            iVar3 = *(int64_t *)(arg1 + 0x18);
                            *(undefined8 *)(arg1 + 0x18) = 0;
                            iVar7 = iVar11;
                            iVar9 = (int64_t)(puVar10 + iVar3) - arg3;
                            puVar10 = puVar10 + iVar3;
                        }
                        puVar10 = puVar10 + -1;
                        if (iVar7 != 0) goto code_r0x00018018be86;
                    }
                    *(undefined4 *)arg1 = 0;
                    if (*(code **)(arg2 + 0x10) != (code *)0x0) {
                        iVar4 = (**(code **)(arg2 + 0x10))(arg1);
joined_r0x00018018bdc2:
                        if (iVar4 != 0) {
code_r0x00018018bc7e:
                            if (puVar10 == puVar1) {
                                return arg4;
                            }
                            return (int64_t)puVar10 - arg3;
                        }
                    }
                }
            }
code_r0x00018018be86:
            puVar10 = puVar10 + 1;
        } while (puVar10 != puVar1);
    }
    return arg4;
}

// ============================================================
// Function: FUN_18018bec0
// Address: 0x18018bec0
// Size: 31 bytes
// ============================================================
undefined8 fcn.18018bec0(int64_t arg1)
{
    int64_t in_stack_00000020;
    
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x34) = 2;
    fcn.18000d970(in_stack_00000020);
    return 0;
}

// ============================================================
// Function: FUN_18018bef0
// Address: 0x18018bef0
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18018bef0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t var_8h;
    int64_t var_10h;
    int64_t in_stack_00000020;
    
    iVar1 = *(int64_t *)(arg1 + 0x18);
    if (*(int32_t *)(iVar1 + 0x34) != 4) {
        fcn.18018cc60(iVar1);
    }
    *(undefined4 *)(iVar1 + 0x34) = 4;
    fcn.18000d970(in_stack_00000020);
    return 0;
}

// ============================================================
// Function: FUN_18018bf40
// Address: 0x18018bf40
// Size: 34 bytes
// ============================================================
undefined8 fcn.18018bf40(int64_t arg1)
{
    int64_t in_stack_00000020;
    
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x34) = 5;
    fcn.18000d970(in_stack_00000020);
    return 0;
}

// ============================================================
// Function: FUN_18018bf70
// Address: 0x18018bf70
// Size: 106 bytes
// ============================================================
undefined8 fcn.18018bf70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t unaff_retaddr;
    int64_t var_8h;
    int64_t iStackX_20;
    int64_t iStack_18;
    int64_t aiStack_10 [2];
    
    aiStack_10[0] = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x40);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x34) = 8;
    piVar1 = *(int64_t **)(aiStack_10[0] + 0x90);
    if (piVar1 != (int64_t *)0x0) {
        var_8h._0_4_ = 8;
        iStackX_20 = arg3;
        iStack_18 = arg2;
        (**(code **)(*piVar1 + 0x10))(piVar1, aiStack_10, &var_8h, &iStack_18, &iStackX_20);
        return 0;
    }
    fcn.18000d970(unaff_retaddr);
    return 0;
}

// ============================================================
// Function: FUN_18018bfe0
// Address: 0x18018bfe0
// Size: 89 bytes
// ============================================================
undefined8 fcn.18018bfe0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    undefined8 uStackX_10;
    undefined8 uStackX_18;
    int64_t iStackX_20;
    
    iStackX_20 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x40);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x34) = 1;
    piVar1 = *(int64_t **)(iStackX_20 + 0x90);
    if (piVar1 != (int64_t *)0x0) {
        uStackX_10 = 0;
        uStackX_18 = 0;
        var_8h._0_4_ = 1;
        (**(code **)(*piVar1 + 0x10))(piVar1, &iStackX_20, &var_8h, &uStackX_18, &uStackX_10);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018c040
// Address: 0x18018c040
// Size: 362 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ah

void fcn.18018c040(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined auVar4 [16];
    bool bVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined8 *puVar13;
    undefined *puVar14;
    undefined8 *puVar15;
    int64_t unaff_R12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar14 = auStack_a8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = *(int64_t *)(arg1 + 0x18);
    fcn.18018cc60(iVar2);
    bVar5 = false;
    *(undefined2 *)(*(int64_t *)(iVar2 + 0x40) + 0xc) = *(undefined2 *)(arg1 + 0x10);
    *(undefined2 *)(*(int64_t *)(iVar2 + 0x40) + 0xe) = *(undefined2 *)(arg1 + 0x12);
    iVar8 = *(int64_t *)(iVar2 + 0x40);
    if (*(int32_t *)(iVar8 + 8) == 0) {
        puVar15 = (undefined8 *)(iVar2 + 0x48);
        *(uint32_t *)(iVar8 + 0xe0) = (uint32_t)*(uint8_t *)(arg1 + 0x16);
        puVar9 = (undefined8 *)(iVar8 + 0xe8);
        if (puVar9 != puVar15) {
            if (*(uint64_t *)(iVar2 + 0x60) < 0x10) {
                func_0x00018000f180(puVar9, puVar15, *(undefined8 *)(iVar2 + 0x58));
            } else {
                func_0x00018000f180(puVar9, *puVar15, *(undefined8 *)(iVar2 + 0x58));
            }
        }
    } else if (*(int32_t *)(iVar8 + 8) == 1) {
        *(uint32_t *)(iVar8 + 0xe0) = (uint32_t)*(uint16_t *)(arg1 + 0x14);
        bVar5 = false;
        if ((*(uint8_t *)(iVar2 + 0x30) & 0x40) != 0) {
            bVar5 = true;
        }
    }
    iVar8 = *(int64_t *)(iVar2 + 0x40);
    var_48h = 0xc;
    var_40h = 0xf;
    var_50h._0_4_ = 0x65707974;
    var_58h = 0x2d746e65746e6f63;
    var_50h._4_4_ = 0;
    puVar9 = *(undefined8 **)(iVar8 + 0x10);
    puVar15 = (undefined8 *)puVar9[1];
    cVar1 = *(char *)((int64_t)puVar15 + 0x19);
    while (cVar1 == '\0') {
        piVar10 = puVar15 + 4;
        piVar11 = &var_58h;
        if (0xf < (uint64_t)var_40h) {
            piVar11 = (int64_t *)var_58h;
        }
        if (0xf < (uint64_t)puVar15[7]) {
            piVar10 = (int64_t *)*piVar10;
        }
        iVar6 = func_0x00018047b6d0(piVar10, piVar11);
        if (iVar6 < 0) {
            puVar13 = (undefined8 *)puVar15[2];
            puVar15 = puVar9;
        } else {
            puVar13 = (undefined8 *)*puVar15;
        }
        puVar9 = puVar15;
        puVar15 = puVar13;
        cVar1 = *(char *)((int64_t)puVar13 + 0x19);
    }
    if (*(char *)((int64_t)puVar9 + 0x19) == '\0') {
        piVar10 = puVar9 + 4;
        if (0xf < (uint64_t)puVar9[7]) {
            piVar10 = (int64_t *)*piVar10;
        }
        piVar11 = &var_58h;
        if (0xf < (uint64_t)var_40h) {
            piVar11 = (int64_t *)var_58h;
        }
        iVar6 = func_0x00018047b6d0(piVar11, piVar10);
        if (iVar6 < 0) goto code_r0x00018018c1a2;
    } else {
code_r0x00018018c1a2:
        puVar9 = *(undefined8 **)(iVar8 + 0x10);
    }
    if ((uint64_t)var_40h < 0x10) {
code_r0x00018018c1eb:
        iVar8 = *(int64_t *)(iVar2 + 0x40);
        unaff_R12 = 0;
        var_48h = 0;
        var_40h = 0xf;
        auVar4[15] = 0;
        auVar4._0_15_ = stack0xffffffffffffffa9;
        _var_58h = auVar4 << 8;
        if (puVar9 != *(undefined8 **)(iVar8 + 0x10)) {
            piVar10 = puVar9 + 8;
            if (0xf < (uint64_t)puVar9[0xb]) {
                piVar10 = (int64_t *)*piVar10;
            }
            uVar7 = func_0x000180185c10(piVar10);
            *(undefined4 *)(iVar8 + 0xa8) = uVar7;
        }
        iVar8 = *(int64_t *)(iVar2 + 0x40);
        var_50h._0_4_ = 0x676e656c;
        var_50h._4_2_ = 0x6874;
        var_48h = 0xe;
        var_40h = 0xf;
        var_50h = CONCAT26(0, SUB146(_var_58h, 8));
        var_58h = 0x2d746e65746e6f63;
        puVar9 = *(undefined8 **)(iVar8 + 0x10);
        puVar15 = (undefined8 *)puVar9[1];
        cVar1 = *(char *)((int64_t)puVar15 + 0x19);
        while (cVar1 == '\0') {
            piVar10 = puVar15 + 4;
            piVar11 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar11 = (int64_t *)var_58h;
            }
            if (0xf < (uint64_t)puVar15[7]) {
                piVar10 = (int64_t *)*piVar10;
            }
            iVar6 = func_0x00018047b6d0(piVar10, piVar11);
            if (iVar6 < 0) {
                puVar13 = (undefined8 *)puVar15[2];
                puVar15 = puVar9;
            } else {
                puVar13 = (undefined8 *)*puVar15;
            }
            puVar9 = puVar15;
            puVar15 = puVar13;
            cVar1 = *(char *)((int64_t)puVar13 + 0x19);
        }
        if (*(char *)((int64_t)puVar9 + 0x19) == '\0') {
            piVar10 = puVar9 + 4;
            if (0xf < (uint64_t)puVar9[7]) {
                piVar10 = (int64_t *)*piVar10;
            }
            piVar11 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar11 = (int64_t *)var_58h;
            }
            iVar6 = func_0x00018047b6d0(piVar11, piVar10);
            if (iVar6 < 0) goto code_r0x00018018c2d2;
        } else {
code_r0x00018018c2d2:
            puVar9 = *(undefined8 **)(iVar8 + 0x10);
        }
        if ((uint64_t)var_40h < 0x10) goto code_r0x00018018c316;
        iVar8 = var_58h;
        puVar14 = auStack_a8;
        if ((0xfff < var_40h + 1U) &&
           (iVar8 = *(int64_t *)(var_58h + -8), puVar14 = auStack_a8, 0x1f < (var_58h - *(int64_t *)(var_58h + -8)) - 8U
           )) goto code_r0x00018018c307;
    } else {
        uVar12 = var_40h + 1;
        iVar8 = var_58h;
        if (uVar12 < 0x1000) {
code_r0x00018018c1e6:
            func_0x000180459c3c(iVar8, uVar12);
            goto code_r0x00018018c1eb;
        }
        if ((var_58h - *(int64_t *)(var_58h + -8)) - 8U < 0x20) {
            uVar12 = var_40h + 0x28;
            iVar8 = *(int64_t *)(var_58h + -8);
            goto code_r0x00018018c1e6;
        }
code_r0x00018018c307:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        puVar14 = auStack_a0;
    }
    *(undefined8 *)(puVar14 + -8) = 0x18018c316;
    func_0x000180459c3c(iVar8);
code_r0x00018018c316:
    var_40h = 0xf;
    var_58h._0_1_ = (char)unaff_R12;
    var_48h = unaff_R12;
    if (puVar9 != *(undefined8 **)(*(int64_t *)(iVar2 + 0x40) + 0x10)) {
        piVar10 = puVar9 + 8;
        if (0xf < (uint64_t)puVar9[0xb]) {
            piVar10 = (int64_t *)*piVar10;
        }
        *(undefined8 *)(puVar14 + -8) = 0x18018c343;
        iVar8 = func_0x00018046eb8c(piVar10);
        *(int64_t *)(*(int64_t *)(iVar2 + 0x40) + 0xa0) = iVar8;
        uVar12 = 0x1000000;
        if (iVar8 + 1U < 0x1000000) {
            uVar12 = iVar8 + 1U;
        }
        if ((!bVar5) && (iVar8 = *(int64_t *)(iVar2 + 0x40), *(uint64_t *)(iVar8 + 0x50) < uVar12)) {
            *(undefined8 *)(puVar14 + -8) = 0x18018c375;
            func_0x00018000b240(iVar8 + 0x38);
        }
    }
    iVar8 = *(int64_t *)(iVar2 + 0x40);
    *(undefined4 *)(iVar2 + 0x34) = 6;
    if (*(int64_t *)(iVar8 + 0x90) != unaff_R12) {
        var_78h._0_4_ = 6;
        piVar10 = *(int64_t **)(iVar8 + 0x90);
        var_70h = unaff_R12;
        var_68h = unaff_R12;
        var_60h = iVar8;
        if (piVar10 == (int64_t *)0x0) {
            *(undefined8 *)(puVar14 + -8) = 0x18018c3f7;
            func_0x000180454690();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        iVar2 = *piVar10;
        *(int64_t **)(puVar14 + 0x20) = &var_70h;
        pcVar3 = *(code **)(iVar2 + 0x10);
        *(undefined8 *)(puVar14 + -8) = 0x18018c3c3;
        (*pcVar3)(piVar10, &var_60h, &var_78h, &var_68h);
    }
    *(undefined8 *)(puVar14 + -8) = 0x18018c3db;
    func_0x000180459870(var_38h ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_18018c1aa
// Address: 0x18018c1aa
// Size: 590 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ah

void fcn.18018c040(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined auVar4 [16];
    bool bVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined8 *puVar13;
    undefined *puVar14;
    undefined8 *puVar15;
    int64_t unaff_R12;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [8];
    undefined auStack_a0 [24];
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    puVar14 = auStack_a8;
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = *(int64_t *)(arg1 + 0x18);
    fcn.18018cc60(iVar2);
    bVar5 = false;
    *(undefined2 *)(*(int64_t *)(iVar2 + 0x40) + 0xc) = *(undefined2 *)(arg1 + 0x10);
    *(undefined2 *)(*(int64_t *)(iVar2 + 0x40) + 0xe) = *(undefined2 *)(arg1 + 0x12);
    iVar8 = *(int64_t *)(iVar2 + 0x40);
    if (*(int32_t *)(iVar8 + 8) == 0) {
        puVar15 = (undefined8 *)(iVar2 + 0x48);
        *(uint32_t *)(iVar8 + 0xe0) = (uint32_t)*(uint8_t *)(arg1 + 0x16);
        puVar9 = (undefined8 *)(iVar8 + 0xe8);
        if (puVar9 != puVar15) {
            if (*(uint64_t *)(iVar2 + 0x60) < 0x10) {
                func_0x00018000f180(puVar9, puVar15, *(undefined8 *)(iVar2 + 0x58));
            } else {
                func_0x00018000f180(puVar9, *puVar15, *(undefined8 *)(iVar2 + 0x58));
            }
        }
    } else if (*(int32_t *)(iVar8 + 8) == 1) {
        *(uint32_t *)(iVar8 + 0xe0) = (uint32_t)*(uint16_t *)(arg1 + 0x14);
        bVar5 = false;
        if ((*(uint8_t *)(iVar2 + 0x30) & 0x40) != 0) {
            bVar5 = true;
        }
    }
    iVar8 = *(int64_t *)(iVar2 + 0x40);
    var_48h = 0xc;
    var_40h = 0xf;
    var_50h._0_4_ = 0x65707974;
    var_58h = 0x2d746e65746e6f63;
    var_50h._4_4_ = 0;
    puVar9 = *(undefined8 **)(iVar8 + 0x10);
    puVar15 = (undefined8 *)puVar9[1];
    cVar1 = *(char *)((int64_t)puVar15 + 0x19);
    while (cVar1 == '\0') {
        piVar10 = puVar15 + 4;
        piVar11 = &var_58h;
        if (0xf < (uint64_t)var_40h) {
            piVar11 = (int64_t *)var_58h;
        }
        if (0xf < (uint64_t)puVar15[7]) {
            piVar10 = (int64_t *)*piVar10;
        }
        iVar6 = func_0x00018047b6d0(piVar10, piVar11);
        if (iVar6 < 0) {
            puVar13 = (undefined8 *)puVar15[2];
            puVar15 = puVar9;
        } else {
            puVar13 = (undefined8 *)*puVar15;
        }
        puVar9 = puVar15;
        puVar15 = puVar13;
        cVar1 = *(char *)((int64_t)puVar13 + 0x19);
    }
    if (*(char *)((int64_t)puVar9 + 0x19) == '\0') {
        piVar10 = puVar9 + 4;
        if (0xf < (uint64_t)puVar9[7]) {
            piVar10 = (int64_t *)*piVar10;
        }
        piVar11 = &var_58h;
        if (0xf < (uint64_t)var_40h) {
            piVar11 = (int64_t *)var_58h;
        }
        iVar6 = func_0x00018047b6d0(piVar11, piVar10);
        if (iVar6 < 0) goto code_r0x00018018c1a2;
    } else {
code_r0x00018018c1a2:
        puVar9 = *(undefined8 **)(iVar8 + 0x10);
    }
    if ((uint64_t)var_40h < 0x10) {
code_r0x00018018c1eb:
        iVar8 = *(int64_t *)(iVar2 + 0x40);
        unaff_R12 = 0;
        var_48h = 0;
        var_40h = 0xf;
        auVar4[15] = 0;
        auVar4._0_15_ = stack0xffffffffffffffa9;
        _var_58h = auVar4 << 8;
        if (puVar9 != *(undefined8 **)(iVar8 + 0x10)) {
            piVar10 = puVar9 + 8;
            if (0xf < (uint64_t)puVar9[0xb]) {
                piVar10 = (int64_t *)*piVar10;
            }
            uVar7 = func_0x000180185c10(piVar10);
            *(undefined4 *)(iVar8 + 0xa8) = uVar7;
        }
        iVar8 = *(int64_t *)(iVar2 + 0x40);
        var_50h._0_4_ = 0x676e656c;
        var_50h._4_2_ = 0x6874;
        var_48h = 0xe;
        var_40h = 0xf;
        var_50h = CONCAT26(0, SUB146(_var_58h, 8));
        var_58h = 0x2d746e65746e6f63;
        puVar9 = *(undefined8 **)(iVar8 + 0x10);
        puVar15 = (undefined8 *)puVar9[1];
        cVar1 = *(char *)((int64_t)puVar15 + 0x19);
        while (cVar1 == '\0') {
            piVar10 = puVar15 + 4;
            piVar11 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar11 = (int64_t *)var_58h;
            }
            if (0xf < (uint64_t)puVar15[7]) {
                piVar10 = (int64_t *)*piVar10;
            }
            iVar6 = func_0x00018047b6d0(piVar10, piVar11);
            if (iVar6 < 0) {
                puVar13 = (undefined8 *)puVar15[2];
                puVar15 = puVar9;
            } else {
                puVar13 = (undefined8 *)*puVar15;
            }
            puVar9 = puVar15;
            puVar15 = puVar13;
            cVar1 = *(char *)((int64_t)puVar13 + 0x19);
        }
        if (*(char *)((int64_t)puVar9 + 0x19) == '\0') {
            piVar10 = puVar9 + 4;
            if (0xf < (uint64_t)puVar9[7]) {
                piVar10 = (int64_t *)*piVar10;
            }
            piVar11 = &var_58h;
            if (0xf < (uint64_t)var_40h) {
                piVar11 = (int64_t *)var_58h;
            }
            iVar6 = func_0x00018047b6d0(piVar11, piVar10);
            if (iVar6 < 0) goto code_r0x00018018c2d2;
        } else {
code_r0x00018018c2d2:
            puVar9 = *(undefined8 **)(iVar8 + 0x10);
        }
        if ((uint64_t)var_40h < 0x10) goto code_r0x00018018c316;
        iVar8 = var_58h;
        puVar14 = auStack_a8;
        if ((0xfff < var_40h + 1U) &&
           (iVar8 = *(int64_t *)(var_58h + -8), puVar14 = auStack_a8, 0x1f < (var_58h - *(int64_t *)(var_58h + -8)) - 8U
           )) goto code_r0x00018018c307;
    } else {
        uVar12 = var_40h + 1;
        iVar8 = var_58h;
        if (uVar12 < 0x1000) {
code_r0x00018018c1e6:
            func_0x000180459c3c(iVar8, uVar12);
            goto code_r0x00018018c1eb;
        }
        if ((var_58h - *(int64_t *)(var_58h + -8)) - 8U < 0x20) {
            uVar12 = var_40h + 0x28;
            iVar8 = *(int64_t *)(var_58h + -8);
            goto code_r0x00018018c1e6;
        }
code_r0x00018018c307:
        pcVar3 = (code *)swi(0x29);
        iVar8 = (*pcVar3)(5);
        puVar14 = auStack_a0;
    }
    *(undefined8 *)(puVar14 + -8) = 0x18018c316;
    func_0x000180459c3c(iVar8);
code_r0x00018018c316:
    var_40h = 0xf;
    var_58h._0_1_ = (char)unaff_R12;
    var_48h = unaff_R12;
    if (puVar9 != *(undefined8 **)(*(int64_t *)(iVar2 + 0x40) + 0x10)) {
        piVar10 = puVar9 + 8;
        if (0xf < (uint64_t)puVar9[0xb]) {
            piVar10 = (int64_t *)*piVar10;
        }
        *(undefined8 *)(puVar14 + -8) = 0x18018c343;
        iVar8 = func_0x00018046eb8c(piVar10);
        *(int64_t *)(*(int64_t *)(iVar2 + 0x40) + 0xa0) = iVar8;
        uVar12 = 0x1000000;
        if (iVar8 + 1U < 0x1000000) {
            uVar12 = iVar8 + 1U;
        }
        if ((!bVar5) && (iVar8 = *(int64_t *)(iVar2 + 0x40), *(uint64_t *)(iVar8 + 0x50) < uVar12)) {
            *(undefined8 *)(puVar14 + -8) = 0x18018c375;
            func_0x00018000b240(iVar8 + 0x38);
        }
    }
    iVar8 = *(int64_t *)(iVar2 + 0x40);
    *(undefined4 *)(iVar2 + 0x34) = 6;
    if (*(int64_t *)(iVar8 + 0x90) != unaff_R12) {
        var_78h._0_4_ = 6;
        piVar10 = *(int64_t **)(iVar8 + 0x90);
        var_70h = unaff_R12;
        var_68h = unaff_R12;
        var_60h = iVar8;
        if (piVar10 == (int64_t *)0x0) {
            *(undefined8 *)(puVar14 + -8) = 0x18018c3f7;
            func_0x000180454690();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        iVar2 = *piVar10;
        *(int64_t **)(puVar14 + 0x20) = &var_70h;
        pcVar3 = *(code **)(iVar2 + 0x10);
        *(undefined8 *)(puVar14 + -8) = 0x18018c3c3;
        (*pcVar3)(piVar10, &var_60h, &var_78h, &var_68h);
    }
    *(undefined8 *)(puVar14 + -8) = 0x18018c3db;
    func_0x000180459870(var_38h ^ (uint64_t)puVar14);
    return;
}

// ============================================================
// Function: FUN_18018c400
// Address: 0x18018c400
// Size: 89 bytes
// ============================================================
undefined8 fcn.18018c400(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    undefined8 uStackX_10;
    undefined8 uStackX_18;
    int64_t iStackX_20;
    
    iStackX_20 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x40);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x34) = 10;
    piVar1 = *(int64_t **)(iStackX_20 + 0x90);
    if (piVar1 != (int64_t *)0x0) {
        uStackX_10 = 0;
        uStackX_18 = 0;
        var_8h._0_4_ = 10;
        (**(code **)(*piVar1 + 0x10))(piVar1, &iStackX_20, &var_8h, &uStackX_18, &uStackX_10);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018c460
// Address: 0x18018c460
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

undefined8 fcn.18018c460(int64_t arg1, int64_t arg_70h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int32_t iVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar1 = *(int32_t *)(arg1 + 8);
    iVar2 = *(int64_t *)(arg1 + 0x18);
    iVar4 = iVar1 + 1;
    iVar5 = 0x1000000;
    if (iVar4 < 0x1000000) {
        iVar5 = iVar4;
    }
    if (*(uint64_t *)(*(int64_t *)(iVar2 + 0x40) + 0x50) < (uint64_t)(int64_t)iVar5) {
        func_0x00018000b240();
    }
    var_20h = *(int64_t *)(iVar2 + 0x40);
    *(undefined4 *)(iVar2 + 0x34) = 7;
    piVar3 = *(int64_t **)(var_20h + 0x90);
    if (piVar3 != (int64_t *)0x0) {
        var_18h = 0;
        var_8h._0_4_ = 7;
        var_10h = (int64_t)iVar1;
        (**(code **)(*piVar3 + 0x10))(piVar3, &var_20h, &var_8h, &var_18h, &var_10h);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018c4f0
// Address: 0x18018c4f0
// Size: 89 bytes
// ============================================================
undefined8 fcn.18018c4f0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t var_8h;
    undefined8 uStackX_10;
    undefined8 uStackX_18;
    int64_t iStackX_20;
    
    iStackX_20 = *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x40);
    *(undefined4 *)(*(int64_t *)(arg1 + 0x18) + 0x34) = 9;
    piVar1 = *(int64_t **)(iStackX_20 + 0x90);
    if (piVar1 != (int64_t *)0x0) {
        uStackX_10 = 0;
        uStackX_18 = 0;
        var_8h._0_4_ = 9;
        (**(code **)(*piVar1 + 0x10))(piVar1, &iStackX_20, &var_8h, &uStackX_18, &uStackX_10);
    }
    return 0;
}

// ============================================================
// Function: FUN_18018c550
// Address: 0x18018c550
// Size: 713 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18018c550(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_a0;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    puVar9 = auStack_98;
    puVar10 = auStack_98;
    iVar8 = *(int64_t *)arg1;
    iVar5 = (*(int64_t *)(arg1 + 8) - iVar8) / 0xc0;
    uVar11 = 0x155555555555555;
    if (iVar5 == 0x155555555555555) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        iVar8 = (*pcVar4)();
        return iVar8;
    }
    uVar1 = iVar5 + 1;
    uVar13 = (*(int64_t *)(arg1 + 0x10) - iVar8) / 0xc0;
    if (0x155555555555555 - (uVar13 >> 1) < uVar13) {
        uVar6 = 0xffffffffffffffe7;
        uVar13 = 0xffffffffffffffc0;
    } else {
        uVar13 = uVar13 + (uVar13 >> 1);
        uVar11 = uVar1;
        if (uVar1 <= uVar13) {
            uVar11 = uVar13;
        }
        if (0x155555555555555 < uVar11) {
code_r0x00018018c813:
            func_0x000180004720();
            pcVar4 = (code *)swi(3);
            iVar8 = (*pcVar4)();
            return iVar8;
        }
        uVar13 = uVar11 * 0xc0;
        if (uVar13 == 0) {
            uVar6 = 0;
            puVar10 = auStack_98;
            goto code_r0x00018018c65a;
        }
        if (uVar13 < 0x1000) {
            uVar6 = func_0x000180459890(uVar13);
            goto code_r0x00018018c65a;
        }
        uVar6 = uVar13 + 0x27;
        if (uVar6 <= uVar13) goto code_r0x00018018c813;
    }
    iVar5 = func_0x000180459890(uVar6);
    if (iVar5 == 0) {
        pcVar4 = (code *)swi(0x29);
        iVar5 = (*pcVar4)(5);
        puVar9 = auStack_90;
    }
    uVar6 = iVar5 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar6 - 8) = iVar5;
    puVar10 = puVar9;
code_r0x00018018c65a:
    iVar8 = (arg2 - iVar8) / 6 + (arg2 - iVar8 >> 0x3f);
    iVar12 = (iVar8 >> 5) - (iVar8 >> 0x3f);
    iVar8 = iVar12 * 0xc0 + uVar6;
    *(int64_t *)(puVar10 + 0x38) = arg1;
    *(uint64_t *)(puVar10 + 0x40) = uVar6;
    *(uint64_t *)(puVar10 + 0x48) = uVar11;
    *(int64_t *)(puVar10 + 0x50) = iVar8 + 0xc0;
    *(int64_t *)(puVar10 + 0x58) = iVar8 + 0xc0;
    *(undefined8 *)(puVar10 + -8) = 0x18018c6b2;
    func_0x0001801756b0(iVar8, *(undefined8 *)(puVar10 + 0xb0));
    *(int64_t *)(puVar10 + 0x50) = iVar8;
    iVar8 = *(int64_t *)(arg1 + 8);
    iVar5 = *(int64_t *)arg1;
    iVar2 = *(int64_t *)(puVar10 + 0xa8);
    if (iVar2 == iVar8) {
        *(uint64_t *)(puVar10 + 0x20) = uVar6;
        *(uint64_t *)(puVar10 + 0x28) = uVar6;
        *(int64_t *)(puVar10 + 0x30) = arg1;
        uVar11 = uVar6;
        for (; iVar5 != iVar8; iVar5 = iVar5 + 0xc0) {
            *(undefined8 *)(puVar10 + -8) = 0x18018c6ed;
            func_0x0001801756b0(uVar11, iVar5);
            uVar11 = uVar11 + 0xc0;
            *(uint64_t *)(puVar10 + 0x28) = uVar11;
        }
    } else {
        *(undefined8 *)(puVar10 + -8) = 0x18018c720;
        func_0x000180174630(iVar5, iVar2, uVar6, arg1);
        *(uint64_t *)(puVar10 + 0x50) = uVar6;
        uVar3 = *(undefined8 *)(arg1 + 8);
        *(undefined8 *)(puVar10 + -8) = 0x18018c747;
        func_0x000180174630(iVar2, uVar3, iVar12 * 0xc0 + 0xc0 + uVar6, arg1);
    }
    iVar8 = *(int64_t *)arg1;
    if (iVar8 != 0) {
        iVar5 = *(int64_t *)(arg1 + 8);
        for (; iVar8 != iVar5; iVar8 = iVar8 + 0xc0) {
            *(undefined8 *)(puVar10 + -8) = 0x18018c768;
            func_0x000180175e80(iVar8);
        }
        uVar11 = *(uint64_t *)arg1;
        uVar7 = uVar11;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar11) / 0xc0) * 0xc0)) {
            uVar7 = *(uint64_t *)(uVar11 - 8);
            uVar11 = (uVar11 - uVar7) - 8;
            if (0x1f < uVar11) {
                pcVar4 = (code *)swi(0x29);
                uVar7 = uVar11;
                (*pcVar4)(5);
                puVar10 = puVar10 + 8;
            }
        }
        *(undefined8 *)(puVar10 + -8) = 0x18018c7d0;
        func_0x000180459c3c(uVar7);
    }
    *(uint64_t *)arg1 = uVar6;
    *(uint64_t *)(arg1 + 8) = uVar1 * 0xc0 + uVar6;
    *(uint64_t *)(arg1 + 0x10) = uVar13 + uVar6;
    return iVar12 * 0xc0 + uVar6;
}

// ============================================================
// Function: FUN_18018c820
// Address: 0x18018c820
// Size: 179 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18018c820(int64_t arg1)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a88d0;
    *(undefined (*) [16])(arg1 + 0x48) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x58) = 0;
    *(undefined8 *)(arg1 + 0x60) = 0xf;
    *(undefined *)(arg1 + 0x48) = 0;
    *(undefined (*) [16])(arg1 + 0x68) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0xf;
    *(undefined *)(arg1 + 0x68) = 0;
    *(undefined (*) [16])(arg1 + 0x88) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x98) = 0;
    *(undefined8 *)(arg1 + 0xa0) = 0xf;
    *(undefined *)(arg1 + 0x88) = 0;
    *(undefined (*) [16])(arg1 + 0xa8) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0xb8) = 0;
    *(undefined8 *)(arg1 + 0xc0) = 0xf;
    *(undefined *)(arg1 + 0xa8) = 0;
    fcn.180191680(arg1 + 0x10, 2);
    *(int64_t *)(arg1 + 0x28) = arg1;
    *(undefined8 *)(arg1 + 0x30) = 0;
    *(undefined8 *)(arg1 + 0x38) = 0;
    *(undefined8 *)(arg1 + 0x40) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_18018c8e0
// Address: 0x18018c8e0
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18018c8e0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a88d0;
    fcn.180004e40(arg1 + 0xa8);
    fcn.180004e40(arg1 + 0x88);
    fcn.180004e40(arg1 + 0x68);
    fcn.180004e40(arg1 + 0x48);
    *(undefined8 *)arg1 = 0x1804a8858;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 200);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18018c950
// Address: 0x18018c950
// Size: 43 bytes
// ============================================================
int64_t fcn.18018c950(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x1804a8858;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x10);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18018c9b0
// Address: 0x18018c9b0
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18018c9b0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined *puVar5;
    int64_t var_20h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar5 = auStack_68;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar4 = *(int64_t **)(arg1 + 0x38);
    if (piVar4 == (int64_t *)0x0) {
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)arg3 = 0;
        puVar5 = auStack_68;
    } else {
        uVar2 = (**(code **)(*piVar4 + 0x10))(piVar4, &var_48h, 1);
        piVar4 = (int64_t *)(arg1 + 0xa8);
        func_0x000180012c10(piVar4, uVar2);
        if (0xf < (uint64_t)var_30h) {
            iVar3 = var_48h;
            puVar5 = auStack_68;
            if ((0xfff < var_30h + 1U) &&
               (iVar3 = *(int64_t *)(var_48h + -8), puVar5 = auStack_68, 0x1f < (var_48h - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar5 = auStack_60;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18018ca55;
            fcn.180459c3c(iVar3);
        }
        *(undefined8 *)(arg1 + 0x38) = 0;
        if (0xf < *(uint64_t *)(arg1 + 0xc0)) {
            piVar4 = (int64_t *)*piVar4;
        }
        *(int64_t **)arg2 = piVar4;
        *(undefined8 *)arg3 = *(undefined8 *)(arg1 + 0xb8);
    }
    *(undefined8 *)(puVar5 + -8) = 0x18018ca8d;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x40) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_18018c9f2
// Address: 0x18018c9f2
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18018c9b0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined *puVar5;
    int64_t var_20h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar5 = auStack_68;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar4 = *(int64_t **)(arg1 + 0x38);
    if (piVar4 == (int64_t *)0x0) {
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)arg3 = 0;
        puVar5 = auStack_68;
    } else {
        uVar2 = (**(code **)(*piVar4 + 0x10))(piVar4, &var_48h, 1);
        piVar4 = (int64_t *)(arg1 + 0xa8);
        func_0x000180012c10(piVar4, uVar2);
        if (0xf < (uint64_t)var_30h) {
            iVar3 = var_48h;
            puVar5 = auStack_68;
            if ((0xfff < var_30h + 1U) &&
               (iVar3 = *(int64_t *)(var_48h + -8), puVar5 = auStack_68, 0x1f < (var_48h - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar5 = auStack_60;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18018ca55;
            fcn.180459c3c(iVar3);
        }
        *(undefined8 *)(arg1 + 0x38) = 0;
        if (0xf < *(uint64_t *)(arg1 + 0xc0)) {
            piVar4 = (int64_t *)*piVar4;
        }
        *(int64_t **)arg2 = piVar4;
        *(undefined8 *)arg3 = *(undefined8 *)(arg1 + 0xb8);
    }
    *(undefined8 *)(puVar5 + -8) = 0x18018ca8d;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x40) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_18018ca80
// Address: 0x18018ca80
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18018c9b0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t *piVar4;
    undefined *puVar5;
    int64_t var_20h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar5 = auStack_68;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar4 = *(int64_t **)(arg1 + 0x38);
    if (piVar4 == (int64_t *)0x0) {
        *(undefined8 *)arg2 = 0;
        *(undefined8 *)arg3 = 0;
        puVar5 = auStack_68;
    } else {
        uVar2 = (**(code **)(*piVar4 + 0x10))(piVar4, &var_48h, 1);
        piVar4 = (int64_t *)(arg1 + 0xa8);
        func_0x000180012c10(piVar4, uVar2);
        if (0xf < (uint64_t)var_30h) {
            iVar3 = var_48h;
            puVar5 = auStack_68;
            if ((0xfff < var_30h + 1U) &&
               (iVar3 = *(int64_t *)(var_48h + -8), puVar5 = auStack_68, 0x1f < (var_48h - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar5 = auStack_60;
            }
            *(undefined8 *)(puVar5 + -8) = 0x18018ca55;
            fcn.180459c3c(iVar3);
        }
        *(undefined8 *)(arg1 + 0x38) = 0;
        if (0xf < *(uint64_t *)(arg1 + 0xc0)) {
            piVar4 = (int64_t *)*piVar4;
        }
        *(int64_t **)arg2 = piVar4;
        *(undefined8 *)arg3 = *(undefined8 *)(arg1 + 0xb8);
    }
    *(undefined8 *)(puVar5 + -8) = 0x18018ca8d;
    func_0x000180459870(*(uint64_t *)(puVar5 + 0x40) ^ (uint64_t)puVar5);
    return;
}

// ============================================================
// Function: FUN_18018caa0
// Address: 0x18018caa0
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018caa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t var_8h;
    
    (**(code **)(*(int64_t *)arg2 + 8))(arg2);
    *(int64_t *)(arg1 + 0x40) = arg2;
    fcn.180191680(arg1 + 0x10, 0);
    puVar1 = (undefined8 *)(arg1 + 0x48);
    *(undefined4 *)(arg1 + 0x34) = 0;
    *(undefined8 *)(arg1 + 0x58) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x60)) {
        puVar1 = (undefined8 *)*puVar1;
    }
    *(undefined *)puVar1 = 0;
    puVar1 = (undefined8 *)(arg1 + 0x68);
    *(undefined8 *)(arg1 + 0x78) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x80)) {
        puVar1 = (undefined8 *)*puVar1;
    }
    *(undefined *)puVar1 = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0xa0)) {
        **(undefined **)(arg1 + 0x88) = 0;
        return 0;
    }
    *(undefined *)(arg1 + 0x88) = 0;
    return 0;
}

// ============================================================
// Function: FUN_18018cb30
// Address: 0x18018cb30
// Size: 143 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18018cb30(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t var_8h;
    
    (**(code **)(*(int64_t *)arg2 + 8))(arg2);
    *(int64_t *)(arg1 + 0x40) = arg2;
    fcn.180191680(arg1 + 0x10, 1);
    puVar1 = (undefined8 *)(arg1 + 0x48);
    *(undefined8 *)(arg1 + 0x58) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x60)) {
        puVar1 = (undefined8 *)*puVar1;
    }
    *(undefined *)puVar1 = 0;
    puVar1 = (undefined8 *)(arg1 + 0x68);
    *(undefined8 *)(arg1 + 0x78) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x80)) {
        puVar1 = (undefined8 *)*puVar1;
    }
    *(undefined *)puVar1 = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0xa0)) {
        **(undefined **)(arg1 + 0x88) = 0;
        return 0;
    }
    *(undefined *)(arg1 + 0x88) = 0;
    return 0;
}

// ============================================================
// Function: FUN_18018cbd0
// Address: 0x18018cbd0
// Size: 35 bytes
// ============================================================
void fcn.18018cbd0(int64_t arg1)
{
    (**(code **)(*(int64_t *)arg1 + 0x10))(arg1, 0, 0);
    // WARNING: Could not recover jumptable at 0x00018018cbef. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(*(int64_t *)arg1 + 0x30))(arg1);
    return;
}

// ============================================================
// Function: FUN_18018cc60
// Address: 0x18018cc60
// Size: 607 bytes
// ============================================================
void fcn.18018cc60(int64_t arg1)
{
    int64_t iVar1;
    int64_t arg2;
    char cVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 *puVar5;
    undefined8 *puVar6;
    undefined auStack_128 [32];
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_d8h;
    int64_t var_b8h;
    int64_t var_98h;
    int64_t var_78h;
    int64_t var_48h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_128;
    if (*(int64_t *)(arg1 + 0x78) == 0) goto code_r0x00018018cea2;
    puVar5 = (undefined8 *)(arg1 + 0x68);
    puVar6 = puVar5;
    if (0xf < *(uint64_t *)(arg1 + 0x80)) {
        puVar6 = (undefined8 *)*puVar5;
    }
    iVar3 = func_0x00018047b6d0(puVar6, 0x1804a8940);
    if (iVar3 == 0) {
code_r0x00018018cccf:
        func_0x000180175840(&var_f8h);
        puVar6 = (undefined8 *)(arg1 + 0x88);
        cVar2 = func_0x00018017b4c0(&var_f8h, puVar6);
        if (cVar2 != '\0') {
            iVar1 = *(int64_t *)(arg1 + 0x40);
            arg2 = *(int64_t *)(iVar1 + 0x28);
            if (arg2 == *(int64_t *)(iVar1 + 0x30)) {
                fcn.18018c550(iVar1 + 0x20, arg2, (int64_t)&var_f8h);
            } else {
                func_0x0001801756b0(arg2, &var_f8h);
                *(int64_t *)(iVar1 + 0x28) = *(int64_t *)(iVar1 + 0x28) + 0xc0;
            }
            *(undefined8 *)(arg1 + 0x78) = 0;
            if (0xf < *(uint64_t *)(arg1 + 0x80)) {
                puVar5 = (undefined8 *)*puVar5;
            }
            *(undefined *)puVar5 = 0;
            *(undefined8 *)(arg1 + 0x98) = 0;
            if (0xf < *(uint64_t *)(arg1 + 0xa0)) {
                puVar6 = (undefined8 *)*puVar6;
            }
            *(undefined *)puVar6 = 0;
            func_0x000180015170(&var_48h, &var_48h, *(undefined8 *)(var_48h + 8));
            fcn.180459c3c(var_48h, 0x60);
            fcn.180004e40(&var_78h);
            fcn.180004e40(&var_98h);
            fcn.180004e40(&var_b8h);
            fcn.180004e40(&var_d8h);
            fcn.180004e40(&var_f8h);
            goto code_r0x00018018cea2;
        }
        func_0x000180015170(&var_48h, &var_48h, *(undefined8 *)(var_48h + 8));
        fcn.180459c3c(var_48h, 0x60);
        fcn.180004e40(&var_78h);
        fcn.180004e40(&var_98h);
        fcn.180004e40(&var_b8h);
        fcn.180004e40(&var_d8h);
        fcn.180004e40(&var_f8h);
    } else {
        puVar6 = puVar5;
        if (0xf < *(uint64_t *)(arg1 + 0x80)) {
            puVar6 = (undefined8 *)*puVar5;
        }
        iVar3 = func_0x00018047b6d0(puVar6, 0x1804a6324);
        if (iVar3 == 0) goto code_r0x00018018cccf;
    }
    puVar5 = (undefined8 *)(arg1 + 0x88);
    piVar4 = (int64_t *)func_0x00018017c5b0(*(int64_t *)(arg1 + 0x40) + 0x10, &var_108h, arg1 + 0x68);
    if ((undefined8 *)(*piVar4 + 0x40) != puVar5) {
        puVar6 = puVar5;
        if (0xf < *(uint64_t *)(arg1 + 0xa0)) {
            puVar6 = (undefined8 *)*puVar5;
        }
        func_0x00018000f180((undefined8 *)(*piVar4 + 0x40), puVar6, *(undefined8 *)(arg1 + 0x98));
    }
    puVar6 = (undefined8 *)(arg1 + 0x68);
    *(undefined8 *)(arg1 + 0x78) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0x80)) {
        puVar6 = (undefined8 *)*puVar6;
    }
    *(undefined *)puVar6 = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    if (0xf < *(uint64_t *)(arg1 + 0xa0)) {
        puVar5 = (undefined8 *)*puVar5;
    }
    *(undefined *)puVar5 = 0;
code_r0x00018018cea2:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_128);
    return;
}

// ============================================================
// Function: FUN_18018cec0
// Address: 0x18018cec0
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18018cec0(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(char *)0x18077e258 == '\0') {
        iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0);
        if (iVar2 == 0) {
            return 0;
        }
    }
    piVar4 = (int64_t *)fcn.18046d050(0xa0);
    if (piVar4 == (int64_t *)0x0) {
        (*(code *)0x69a006)(8);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0xc;
        return 0;
    }
    iVar6 = (*(code *)0x69a016)(0xffffffffffffffff, 0, 0, 0);
    if (iVar6 == 0) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18018d4d0(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
        fcn.180460d90(piVar4);
        return 0;
    }
    *(undefined (*) [16])(piVar4 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0xf) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0x11) = ZEXT816(0);
    piVar4[0x13] = 0;
    *piVar4 = iVar6;
    piVar4[1] = 0;
    piVar1 = piVar4 + 2;
    *piVar1 = (int64_t)piVar1;
    piVar4[3] = (int64_t)piVar1;
    piVar1 = piVar4 + 4;
    *piVar1 = (int64_t)piVar1;
    piVar4[5] = (int64_t)piVar1;
    piVar1 = piVar4 + 6;
    *piVar1 = (int64_t)piVar1;
    piVar4[7] = (int64_t)piVar1;
    *(undefined (*) [16])(piVar4 + 8) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 10) = ZEXT816(0);
    piVar4[0xc] = 0;
    *(undefined4 *)(piVar4 + 0xd) = 0;
    (*(code *)0x699f00)(piVar4 + 0xe);
    (*(code *)0x69a094)(0x18077e250);
    iVar2 = fcn.18018eb20(0x18077e248, piVar4 + 8, iVar6);
    (*(code *)0x69a062)(0x18077e250);
    if (iVar2 < 0) {
        fcn.18018e120(piVar4);
        (*(code *)0x69a006)(0xb7);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0x11;
        return 0;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_18018cef2
// Address: 0x18018cef2
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18018cec0(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(char *)0x18077e258 == '\0') {
        iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0);
        if (iVar2 == 0) {
            return 0;
        }
    }
    piVar4 = (int64_t *)fcn.18046d050(0xa0);
    if (piVar4 == (int64_t *)0x0) {
        (*(code *)0x69a006)(8);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0xc;
        return 0;
    }
    iVar6 = (*(code *)0x69a016)(0xffffffffffffffff, 0, 0, 0);
    if (iVar6 == 0) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18018d4d0(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
        fcn.180460d90(piVar4);
        return 0;
    }
    *(undefined (*) [16])(piVar4 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0xf) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0x11) = ZEXT816(0);
    piVar4[0x13] = 0;
    *piVar4 = iVar6;
    piVar4[1] = 0;
    piVar1 = piVar4 + 2;
    *piVar1 = (int64_t)piVar1;
    piVar4[3] = (int64_t)piVar1;
    piVar1 = piVar4 + 4;
    *piVar1 = (int64_t)piVar1;
    piVar4[5] = (int64_t)piVar1;
    piVar1 = piVar4 + 6;
    *piVar1 = (int64_t)piVar1;
    piVar4[7] = (int64_t)piVar1;
    *(undefined (*) [16])(piVar4 + 8) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 10) = ZEXT816(0);
    piVar4[0xc] = 0;
    *(undefined4 *)(piVar4 + 0xd) = 0;
    (*(code *)0x699f00)(piVar4 + 0xe);
    (*(code *)0x69a094)(0x18077e250);
    iVar2 = fcn.18018eb20(0x18077e248, piVar4 + 8, iVar6);
    (*(code *)0x69a062)(0x18077e250);
    if (iVar2 < 0) {
        fcn.18018e120(piVar4);
        (*(code *)0x69a006)(0xb7);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0x11;
        return 0;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_18018cf3f
// Address: 0x18018cf3f
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18018cec0(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(char *)0x18077e258 == '\0') {
        iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0);
        if (iVar2 == 0) {
            return 0;
        }
    }
    piVar4 = (int64_t *)fcn.18046d050(0xa0);
    if (piVar4 == (int64_t *)0x0) {
        (*(code *)0x69a006)(8);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0xc;
        return 0;
    }
    iVar6 = (*(code *)0x69a016)(0xffffffffffffffff, 0, 0, 0);
    if (iVar6 == 0) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18018d4d0(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
        fcn.180460d90(piVar4);
        return 0;
    }
    *(undefined (*) [16])(piVar4 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0xf) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0x11) = ZEXT816(0);
    piVar4[0x13] = 0;
    *piVar4 = iVar6;
    piVar4[1] = 0;
    piVar1 = piVar4 + 2;
    *piVar1 = (int64_t)piVar1;
    piVar4[3] = (int64_t)piVar1;
    piVar1 = piVar4 + 4;
    *piVar1 = (int64_t)piVar1;
    piVar4[5] = (int64_t)piVar1;
    piVar1 = piVar4 + 6;
    *piVar1 = (int64_t)piVar1;
    piVar4[7] = (int64_t)piVar1;
    *(undefined (*) [16])(piVar4 + 8) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 10) = ZEXT816(0);
    piVar4[0xc] = 0;
    *(undefined4 *)(piVar4 + 0xd) = 0;
    (*(code *)0x699f00)(piVar4 + 0xe);
    (*(code *)0x69a094)(0x18077e250);
    iVar2 = fcn.18018eb20(0x18077e248, piVar4 + 8, iVar6);
    (*(code *)0x69a062)(0x18077e250);
    if (iVar2 < 0) {
        fcn.18018e120(piVar4);
        (*(code *)0x69a006)(0xb7);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0x11;
        return 0;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_18018cf90
// Address: 0x18018cf90
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18018cec0(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(char *)0x18077e258 == '\0') {
        iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0);
        if (iVar2 == 0) {
            return 0;
        }
    }
    piVar4 = (int64_t *)fcn.18046d050(0xa0);
    if (piVar4 == (int64_t *)0x0) {
        (*(code *)0x69a006)(8);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0xc;
        return 0;
    }
    iVar6 = (*(code *)0x69a016)(0xffffffffffffffff, 0, 0, 0);
    if (iVar6 == 0) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18018d4d0(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
        fcn.180460d90(piVar4);
        return 0;
    }
    *(undefined (*) [16])(piVar4 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0xf) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0x11) = ZEXT816(0);
    piVar4[0x13] = 0;
    *piVar4 = iVar6;
    piVar4[1] = 0;
    piVar1 = piVar4 + 2;
    *piVar1 = (int64_t)piVar1;
    piVar4[3] = (int64_t)piVar1;
    piVar1 = piVar4 + 4;
    *piVar1 = (int64_t)piVar1;
    piVar4[5] = (int64_t)piVar1;
    piVar1 = piVar4 + 6;
    *piVar1 = (int64_t)piVar1;
    piVar4[7] = (int64_t)piVar1;
    *(undefined (*) [16])(piVar4 + 8) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 10) = ZEXT816(0);
    piVar4[0xc] = 0;
    *(undefined4 *)(piVar4 + 0xd) = 0;
    (*(code *)0x699f00)(piVar4 + 0xe);
    (*(code *)0x69a094)(0x18077e250);
    iVar2 = fcn.18018eb20(0x18077e248, piVar4 + 8, iVar6);
    (*(code *)0x69a062)(0x18077e250);
    if (iVar2 < 0) {
        fcn.18018e120(piVar4);
        (*(code *)0x69a006)(0xb7);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0x11;
        return 0;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_18018d055
// Address: 0x18018d055
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18018cec0(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    if (*(char *)0x18077e258 == '\0') {
        iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0);
        if (iVar2 == 0) {
            return 0;
        }
    }
    piVar4 = (int64_t *)fcn.18046d050(0xa0);
    if (piVar4 == (int64_t *)0x0) {
        (*(code *)0x69a006)(8);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0xc;
        return 0;
    }
    iVar6 = (*(code *)0x69a016)(0xffffffffffffffff, 0, 0, 0);
    if (iVar6 == 0) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18018d4d0(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
        fcn.180460d90(piVar4);
        return 0;
    }
    *(undefined (*) [16])(piVar4 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0xf) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0x11) = ZEXT816(0);
    piVar4[0x13] = 0;
    *piVar4 = iVar6;
    piVar4[1] = 0;
    piVar1 = piVar4 + 2;
    *piVar1 = (int64_t)piVar1;
    piVar4[3] = (int64_t)piVar1;
    piVar1 = piVar4 + 4;
    *piVar1 = (int64_t)piVar1;
    piVar4[5] = (int64_t)piVar1;
    piVar1 = piVar4 + 6;
    *piVar1 = (int64_t)piVar1;
    piVar4[7] = (int64_t)piVar1;
    *(undefined (*) [16])(piVar4 + 8) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 10) = ZEXT816(0);
    piVar4[0xc] = 0;
    *(undefined4 *)(piVar4 + 0xd) = 0;
    (*(code *)0x699f00)(piVar4 + 0xe);
    (*(code *)0x69a094)(0x18077e250);
    iVar2 = fcn.18018eb20(0x18077e248, piVar4 + 8, iVar6);
    (*(code *)0x69a062)(0x18077e250);
    if (iVar2 < 0) {
        fcn.18018e120(piVar4);
        (*(code *)0x69a006)(0xb7);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = 0x11;
        return 0;
    }
    return iVar6;
}

// ============================================================
// Function: FUN_18018d070
// Address: 0x18018d070
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d070(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar6 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar6 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a094)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d0c7:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d0e6:
            (*(code *)0x69a062)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar8 = (undefined4 *)fcn.18046b77c();
            *puVar8 = 0x16;
            fcn.18018d9c0(unaff_RDI);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    fcn.18018ecd0(0x18077e248, puVar2);
                    LOCK();
                    *(int32_t *)(puVar2 + 5) = *(int32_t *)(puVar2 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a062)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    uVar9 = puVar2[-8];
                    puVar2[-8] = 0;
                    iVar6 = (*(code *)0x699d92)(uVar9);
                    if (iVar6 == 0) {
                        uVar7 = (*(code *)0x699ff6)();
                        uVar7 = fcn.18018d4d0(uVar7);
                        puVar8 = (undefined4 *)fcn.18046b77c();
                        *puVar8 = uVar7;
                    }
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    puVar1 = puVar2 + 5;
                    iVar6 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 0xfffffff;
                    UNLOCK();
                    if (((iVar6 - 1U & 0xfffffff) != 0) &&
                       (iVar6 = (**(code **)0x18077e238)(*(undefined8 *)0x18077e268, puVar2 + 5, 0, 0), iVar6 != 0)) {
                        fcn.180473b90();
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar1 = puVar2 + -8;
                    LOCK();
                    *(undefined4 *)(puVar2 + 5) = 0x300dead0;
                    UNLOCK();
                    iVar3 = puVar2[-7];
                    while (iVar3 != 0) {
                        func_0x00018018e500(puVar1, iVar3 + -0x40, 1);
                        iVar3 = puVar2[-7];
                    }
                    while (((undefined8 *)puVar2[-4] != puVar2 + -4 && (puVar2[-3] != 0))) {
                        func_0x00018018e500(puVar1, puVar2[-3] + -0x30, 1);
                    }
                    while (((undefined8 *)puVar2[-2] != puVar2 + -2 &&
                           (piVar4 = (int64_t *)puVar2[-1], piVar4 != (int64_t *)0x0))) {
                        (*(code *)0x699d92)(piVar4[2]);
                        *(int64_t *)(*piVar4 + 8) = piVar4[1];
                        *(int64_t *)piVar4[1] = *piVar4;
                        *piVar4 = (int64_t)piVar4;
                        piVar4[1] = (int64_t)piVar4;
                        fcn.180460d90(piVar4 + -1);
                    }
                    (*(code *)0x699f4c)(puVar2 + 6);
                    fcn.180460d90(puVar1);
                    return 0;
                }
                goto code_r0x00018018d0e6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d0c7;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d0b2
// Address: 0x18018d0b2
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d070(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar6 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar6 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a094)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d0c7:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d0e6:
            (*(code *)0x69a062)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar8 = (undefined4 *)fcn.18046b77c();
            *puVar8 = 0x16;
            fcn.18018d9c0(unaff_RDI);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    fcn.18018ecd0(0x18077e248, puVar2);
                    LOCK();
                    *(int32_t *)(puVar2 + 5) = *(int32_t *)(puVar2 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a062)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    uVar9 = puVar2[-8];
                    puVar2[-8] = 0;
                    iVar6 = (*(code *)0x699d92)(uVar9);
                    if (iVar6 == 0) {
                        uVar7 = (*(code *)0x699ff6)();
                        uVar7 = fcn.18018d4d0(uVar7);
                        puVar8 = (undefined4 *)fcn.18046b77c();
                        *puVar8 = uVar7;
                    }
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    puVar1 = puVar2 + 5;
                    iVar6 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 0xfffffff;
                    UNLOCK();
                    if (((iVar6 - 1U & 0xfffffff) != 0) &&
                       (iVar6 = (**(code **)0x18077e238)(*(undefined8 *)0x18077e268, puVar2 + 5, 0, 0), iVar6 != 0)) {
                        fcn.180473b90();
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar1 = puVar2 + -8;
                    LOCK();
                    *(undefined4 *)(puVar2 + 5) = 0x300dead0;
                    UNLOCK();
                    iVar3 = puVar2[-7];
                    while (iVar3 != 0) {
                        func_0x00018018e500(puVar1, iVar3 + -0x40, 1);
                        iVar3 = puVar2[-7];
                    }
                    while (((undefined8 *)puVar2[-4] != puVar2 + -4 && (puVar2[-3] != 0))) {
                        func_0x00018018e500(puVar1, puVar2[-3] + -0x30, 1);
                    }
                    while (((undefined8 *)puVar2[-2] != puVar2 + -2 &&
                           (piVar4 = (int64_t *)puVar2[-1], piVar4 != (int64_t *)0x0))) {
                        (*(code *)0x699d92)(piVar4[2]);
                        *(int64_t *)(*piVar4 + 8) = piVar4[1];
                        *(int64_t *)piVar4[1] = *piVar4;
                        *piVar4 = (int64_t)piVar4;
                        piVar4[1] = (int64_t)piVar4;
                        fcn.180460d90(piVar4 + -1);
                    }
                    (*(code *)0x699f4c)(puVar2 + 6);
                    fcn.180460d90(puVar1);
                    return 0;
                }
                goto code_r0x00018018d0e6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d0c7;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d121
// Address: 0x18018d121
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d070(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar6 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar6 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a094)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d0c7:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d0e6:
            (*(code *)0x69a062)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar8 = (undefined4 *)fcn.18046b77c();
            *puVar8 = 0x16;
            fcn.18018d9c0(unaff_RDI);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    fcn.18018ecd0(0x18077e248, puVar2);
                    LOCK();
                    *(int32_t *)(puVar2 + 5) = *(int32_t *)(puVar2 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a062)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    uVar9 = puVar2[-8];
                    puVar2[-8] = 0;
                    iVar6 = (*(code *)0x699d92)(uVar9);
                    if (iVar6 == 0) {
                        uVar7 = (*(code *)0x699ff6)();
                        uVar7 = fcn.18018d4d0(uVar7);
                        puVar8 = (undefined4 *)fcn.18046b77c();
                        *puVar8 = uVar7;
                    }
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    puVar1 = puVar2 + 5;
                    iVar6 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 0xfffffff;
                    UNLOCK();
                    if (((iVar6 - 1U & 0xfffffff) != 0) &&
                       (iVar6 = (**(code **)0x18077e238)(*(undefined8 *)0x18077e268, puVar2 + 5, 0, 0), iVar6 != 0)) {
                        fcn.180473b90();
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar1 = puVar2 + -8;
                    LOCK();
                    *(undefined4 *)(puVar2 + 5) = 0x300dead0;
                    UNLOCK();
                    iVar3 = puVar2[-7];
                    while (iVar3 != 0) {
                        func_0x00018018e500(puVar1, iVar3 + -0x40, 1);
                        iVar3 = puVar2[-7];
                    }
                    while (((undefined8 *)puVar2[-4] != puVar2 + -4 && (puVar2[-3] != 0))) {
                        func_0x00018018e500(puVar1, puVar2[-3] + -0x30, 1);
                    }
                    while (((undefined8 *)puVar2[-2] != puVar2 + -2 &&
                           (piVar4 = (int64_t *)puVar2[-1], piVar4 != (int64_t *)0x0))) {
                        (*(code *)0x699d92)(piVar4[2]);
                        *(int64_t *)(*piVar4 + 8) = piVar4[1];
                        *(int64_t *)piVar4[1] = *piVar4;
                        *piVar4 = (int64_t)piVar4;
                        piVar4[1] = (int64_t)piVar4;
                        fcn.180460d90(piVar4 + -1);
                    }
                    (*(code *)0x699f4c)(puVar2 + 6);
                    fcn.180460d90(puVar1);
                    return 0;
                }
                goto code_r0x00018018d0e6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d0c7;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d126
// Address: 0x18018d126
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d070(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar6 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar6 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a094)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d0c7:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d0e6:
            (*(code *)0x69a062)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar8 = (undefined4 *)fcn.18046b77c();
            *puVar8 = 0x16;
            fcn.18018d9c0(unaff_RDI);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    fcn.18018ecd0(0x18077e248, puVar2);
                    LOCK();
                    *(int32_t *)(puVar2 + 5) = *(int32_t *)(puVar2 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a062)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    uVar9 = puVar2[-8];
                    puVar2[-8] = 0;
                    iVar6 = (*(code *)0x699d92)(uVar9);
                    if (iVar6 == 0) {
                        uVar7 = (*(code *)0x699ff6)();
                        uVar7 = fcn.18018d4d0(uVar7);
                        puVar8 = (undefined4 *)fcn.18046b77c();
                        *puVar8 = uVar7;
                    }
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    puVar1 = puVar2 + 5;
                    iVar6 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 0xfffffff;
                    UNLOCK();
                    if (((iVar6 - 1U & 0xfffffff) != 0) &&
                       (iVar6 = (**(code **)0x18077e238)(*(undefined8 *)0x18077e268, puVar2 + 5, 0, 0), iVar6 != 0)) {
                        fcn.180473b90();
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar1 = puVar2 + -8;
                    LOCK();
                    *(undefined4 *)(puVar2 + 5) = 0x300dead0;
                    UNLOCK();
                    iVar3 = puVar2[-7];
                    while (iVar3 != 0) {
                        func_0x00018018e500(puVar1, iVar3 + -0x40, 1);
                        iVar3 = puVar2[-7];
                    }
                    while (((undefined8 *)puVar2[-4] != puVar2 + -4 && (puVar2[-3] != 0))) {
                        func_0x00018018e500(puVar1, puVar2[-3] + -0x30, 1);
                    }
                    while (((undefined8 *)puVar2[-2] != puVar2 + -2 &&
                           (piVar4 = (int64_t *)puVar2[-1], piVar4 != (int64_t *)0x0))) {
                        (*(code *)0x699d92)(piVar4[2]);
                        *(int64_t *)(*piVar4 + 8) = piVar4[1];
                        *(int64_t *)piVar4[1] = *piVar4;
                        *piVar4 = (int64_t)piVar4;
                        piVar4[1] = (int64_t)piVar4;
                        fcn.180460d90(piVar4 + -1);
                    }
                    (*(code *)0x699f4c)(puVar2 + 6);
                    fcn.180460d90(puVar1);
                    return 0;
                }
                goto code_r0x00018018d0e6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d0c7;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d1a8
// Address: 0x18018d1a8
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d070(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar6 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar6 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a094)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d0c7:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d0e6:
            (*(code *)0x69a062)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar8 = (undefined4 *)fcn.18046b77c();
            *puVar8 = 0x16;
            fcn.18018d9c0(unaff_RDI);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    fcn.18018ecd0(0x18077e248, puVar2);
                    LOCK();
                    *(int32_t *)(puVar2 + 5) = *(int32_t *)(puVar2 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a062)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    uVar9 = puVar2[-8];
                    puVar2[-8] = 0;
                    iVar6 = (*(code *)0x699d92)(uVar9);
                    if (iVar6 == 0) {
                        uVar7 = (*(code *)0x699ff6)();
                        uVar7 = fcn.18018d4d0(uVar7);
                        puVar8 = (undefined4 *)fcn.18046b77c();
                        *puVar8 = uVar7;
                    }
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    puVar1 = puVar2 + 5;
                    iVar6 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 0xfffffff;
                    UNLOCK();
                    if (((iVar6 - 1U & 0xfffffff) != 0) &&
                       (iVar6 = (**(code **)0x18077e238)(*(undefined8 *)0x18077e268, puVar2 + 5, 0, 0), iVar6 != 0)) {
                        fcn.180473b90();
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar1 = puVar2 + -8;
                    LOCK();
                    *(undefined4 *)(puVar2 + 5) = 0x300dead0;
                    UNLOCK();
                    iVar3 = puVar2[-7];
                    while (iVar3 != 0) {
                        func_0x00018018e500(puVar1, iVar3 + -0x40, 1);
                        iVar3 = puVar2[-7];
                    }
                    while (((undefined8 *)puVar2[-4] != puVar2 + -4 && (puVar2[-3] != 0))) {
                        func_0x00018018e500(puVar1, puVar2[-3] + -0x30, 1);
                    }
                    while (((undefined8 *)puVar2[-2] != puVar2 + -2 &&
                           (piVar4 = (int64_t *)puVar2[-1], piVar4 != (int64_t *)0x0))) {
                        (*(code *)0x699d92)(piVar4[2]);
                        *(int64_t *)(*piVar4 + 8) = piVar4[1];
                        *(int64_t *)piVar4[1] = *piVar4;
                        *piVar4 = (int64_t)piVar4;
                        piVar4[1] = (int64_t)piVar4;
                        fcn.180460d90(piVar4 + -1);
                    }
                    (*(code *)0x699f4c)(puVar2 + 6);
                    fcn.180460d90(puVar1);
                    return 0;
                }
                goto code_r0x00018018d0e6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d0c7;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d1e3
// Address: 0x18018d1e3
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d070(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    undefined4 uVar7;
    undefined4 *puVar8;
    undefined8 uVar9;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar6 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar6 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a094)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d0c7:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d0e6:
            (*(code *)0x69a062)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar8 = (undefined4 *)fcn.18046b77c();
            *puVar8 = 0x16;
            fcn.18018d9c0(unaff_RDI);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    fcn.18018ecd0(0x18077e248, puVar2);
                    LOCK();
                    *(int32_t *)(puVar2 + 5) = *(int32_t *)(puVar2 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a062)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    uVar9 = puVar2[-8];
                    puVar2[-8] = 0;
                    iVar6 = (*(code *)0x699d92)(uVar9);
                    if (iVar6 == 0) {
                        uVar7 = (*(code *)0x699ff6)();
                        uVar7 = fcn.18018d4d0(uVar7);
                        puVar8 = (undefined4 *)fcn.18046b77c();
                        *puVar8 = uVar7;
                    }
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    puVar1 = puVar2 + 5;
                    iVar6 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 0xfffffff;
                    UNLOCK();
                    if (((iVar6 - 1U & 0xfffffff) != 0) &&
                       (iVar6 = (**(code **)0x18077e238)(*(undefined8 *)0x18077e268, puVar2 + 5, 0, 0), iVar6 != 0)) {
                        fcn.180473b90();
                        pcVar5 = (code *)swi(3);
                        uVar9 = (*pcVar5)();
                        return uVar9;
                    }
                    puVar1 = puVar2 + -8;
                    LOCK();
                    *(undefined4 *)(puVar2 + 5) = 0x300dead0;
                    UNLOCK();
                    iVar3 = puVar2[-7];
                    while (iVar3 != 0) {
                        func_0x00018018e500(puVar1, iVar3 + -0x40, 1);
                        iVar3 = puVar2[-7];
                    }
                    while (((undefined8 *)puVar2[-4] != puVar2 + -4 && (puVar2[-3] != 0))) {
                        func_0x00018018e500(puVar1, puVar2[-3] + -0x30, 1);
                    }
                    while (((undefined8 *)puVar2[-2] != puVar2 + -2 &&
                           (piVar4 = (int64_t *)puVar2[-1], piVar4 != (int64_t *)0x0))) {
                        (*(code *)0x699d92)(piVar4[2]);
                        *(int64_t *)(*piVar4 + 8) = piVar4[1];
                        *(int64_t *)piVar4[1] = *piVar4;
                        *piVar4 = (int64_t)piVar4;
                        piVar4[1] = (int64_t)piVar4;
                        fcn.180460d90(piVar4 + -1);
                    }
                    (*(code *)0x699f4c)(puVar2 + 6);
                    fcn.180460d90(puVar1);
                    return 0;
                }
                goto code_r0x00018018d0e6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d0c7;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d1f0
// Address: 0x18018d1f0
// Size: 46 bytes
// ============================================================
int64_t fcn.18018d1f0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    undefined4 *puVar6;
    
    if ((int32_t)arg1 < 1) {
        (*(code *)0x69a006)(0x57);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = 0x16;
        return 0;
    }
    if (*(char *)0x18077e258 == '\0') {
        iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0);
        if (iVar2 == 0) {
            return 0;
        }
    }
    piVar4 = (int64_t *)fcn.18046d050(0xa0);
    if (piVar4 == (int64_t *)0x0) {
        (*(code *)0x69a006)(8);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = 0xc;
        return 0;
    }
    iVar5 = (*(code *)0x69a016)(0xffffffffffffffff, 0, 0, 0);
    if (iVar5 == 0) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18018d4d0(uVar3);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = uVar3;
        fcn.180460d90(piVar4);
        return 0;
    }
    *(undefined (*) [16])(piVar4 + 0xd) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0xf) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 0x11) = ZEXT816(0);
    piVar4[0x13] = 0;
    *piVar4 = iVar5;
    piVar4[1] = 0;
    piVar1 = piVar4 + 2;
    *piVar1 = (int64_t)piVar1;
    piVar4[3] = (int64_t)piVar1;
    piVar1 = piVar4 + 4;
    *piVar1 = (int64_t)piVar1;
    piVar4[5] = (int64_t)piVar1;
    piVar1 = piVar4 + 6;
    *piVar1 = (int64_t)piVar1;
    piVar4[7] = (int64_t)piVar1;
    *(undefined (*) [16])(piVar4 + 8) = ZEXT816(0);
    *(undefined (*) [16])(piVar4 + 10) = ZEXT816(0);
    piVar4[0xc] = 0;
    *(undefined4 *)(piVar4 + 0xd) = 0;
    (*(code *)0x699f00)(piVar4 + 0xe);
    (*(code *)0x69a094)(0x18077e250);
    iVar2 = fcn.18018eb20(0x18077e248, piVar4 + 8, iVar5);
    (*(code *)0x69a062)(0x18077e250);
    if (iVar2 < 0) {
        fcn.18018e120(piVar4);
        (*(code *)0x69a006)(0xb7);
        puVar6 = (undefined4 *)fcn.18046b77c();
        *puVar6 = 0x11;
        return 0;
    }
    return iVar5;
}

// ============================================================
// Function: FUN_18018d220
// Address: 0x18018d220
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d220(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar4 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar4 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a0ae)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d298:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d2b6:
            (*(code *)0x69a07c)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar6 = (undefined4 *)fcn.18046b77c();
            *puVar6 = 0x16;
code_r0x00018018d2d9:
            fcn.18018d9c0(unaff_R15);
            fcn.18018d9c0(unaff_R15);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    puVar1 = puVar2 + 5;
                    LOCK();
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    iVar5 = fcn.18018ddd0(puVar2 + -8, arg2 & 0xffffffff, arg3, arg4);
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    iVar4 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
                    UNLOCK();
                    if ((iVar4 == 0x10000001) &&
                       (iVar4 = (**(code **)0x18077e230)(*(undefined8 *)0x18077e268, puVar1, 0, 0), iVar4 != 0)) {
                        fcn.180473b90();
                        pcVar3 = (code *)swi(3);
                        uVar7 = (*pcVar3)();
                        return uVar7;
                    }
                    if (-1 < iVar5) {
                        return 0;
                    }
                    goto code_r0x00018018d2d9;
                }
                goto code_r0x00018018d2b6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d298;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d277
// Address: 0x18018d277
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d220(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar4 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar4 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a0ae)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d298:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d2b6:
            (*(code *)0x69a07c)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar6 = (undefined4 *)fcn.18046b77c();
            *puVar6 = 0x16;
code_r0x00018018d2d9:
            fcn.18018d9c0(unaff_R15);
            fcn.18018d9c0(unaff_R15);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    puVar1 = puVar2 + 5;
                    LOCK();
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    iVar5 = fcn.18018ddd0(puVar2 + -8, arg2 & 0xffffffff, arg3, arg4);
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    iVar4 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
                    UNLOCK();
                    if ((iVar4 == 0x10000001) &&
                       (iVar4 = (**(code **)0x18077e230)(*(undefined8 *)0x18077e268, puVar1, 0, 0), iVar4 != 0)) {
                        fcn.180473b90();
                        pcVar3 = (code *)swi(3);
                        uVar7 = (*pcVar3)();
                        return uVar7;
                    }
                    if (-1 < iVar5) {
                        return 0;
                    }
                    goto code_r0x00018018d2d9;
                }
                goto code_r0x00018018d2b6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d298;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d308
// Address: 0x18018d308
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d220(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar4 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar4 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a0ae)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d298:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d2b6:
            (*(code *)0x69a07c)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar6 = (undefined4 *)fcn.18046b77c();
            *puVar6 = 0x16;
code_r0x00018018d2d9:
            fcn.18018d9c0(unaff_R15);
            fcn.18018d9c0(unaff_R15);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    puVar1 = puVar2 + 5;
                    LOCK();
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    iVar5 = fcn.18018ddd0(puVar2 + -8, arg2 & 0xffffffff, arg3, arg4);
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    iVar4 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
                    UNLOCK();
                    if ((iVar4 == 0x10000001) &&
                       (iVar4 = (**(code **)0x18077e230)(*(undefined8 *)0x18077e268, puVar1, 0, 0), iVar4 != 0)) {
                        fcn.180473b90();
                        pcVar3 = (code *)swi(3);
                        uVar7 = (*pcVar3)();
                        return uVar7;
                    }
                    if (-1 < iVar5) {
                        return 0;
                    }
                    goto code_r0x00018018d2d9;
                }
                goto code_r0x00018018d2b6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d298;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d30d
// Address: 0x18018d30d
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d220(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar4 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar4 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a0ae)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d298:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d2b6:
            (*(code *)0x69a07c)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar6 = (undefined4 *)fcn.18046b77c();
            *puVar6 = 0x16;
code_r0x00018018d2d9:
            fcn.18018d9c0(unaff_R15);
            fcn.18018d9c0(unaff_R15);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    puVar1 = puVar2 + 5;
                    LOCK();
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    iVar5 = fcn.18018ddd0(puVar2 + -8, arg2 & 0xffffffff, arg3, arg4);
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    iVar4 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
                    UNLOCK();
                    if ((iVar4 == 0x10000001) &&
                       (iVar4 = (**(code **)0x18077e230)(*(undefined8 *)0x18077e268, puVar1, 0, 0), iVar4 != 0)) {
                        fcn.180473b90();
                        pcVar3 = (code *)swi(3);
                        uVar7 = (*pcVar3)();
                        return uVar7;
                    }
                    if (-1 < iVar5) {
                        return 0;
                    }
                    goto code_r0x00018018d2d9;
                }
                goto code_r0x00018018d2b6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d298;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d36a
// Address: 0x18018d36a
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18018d220(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    code *pcVar3;
    int32_t iVar4;
    int32_t iVar5;
    undefined4 *puVar6;
    undefined8 uVar7;
    int64_t unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    if ((*(char *)0x18077e258 == '\0') && (iVar4 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar4 == 0)) {
        return 0xffffffff;
    }
    (*(code *)0x69a0ae)(0x18077e250);
    puVar2 = *(undefined8 **)0x18077e248;
joined_r0x00018018d298:
    do {
        if (puVar2 == (undefined8 *)0x0) {
code_r0x00018018d2b6:
            (*(code *)0x69a07c)(0x18077e250);
            (*(code *)0x69a006)(0x57);
            puVar6 = (undefined4 *)fcn.18046b77c();
            *puVar6 = 0x16;
code_r0x00018018d2d9:
            fcn.18018d9c0(unaff_R15);
            fcn.18018d9c0(unaff_R15);
            return 0xffffffff;
        }
        if ((uint64_t)puVar2[3] <= (uint64_t)arg1) {
            if ((uint64_t)arg1 <= (uint64_t)puVar2[3]) {
                if (puVar2 != (undefined8 *)0x0) {
                    puVar1 = puVar2 + 5;
                    LOCK();
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    (*(code *)0x699f1c)(puVar2 + 6);
                    iVar5 = fcn.18018ddd0(puVar2 + -8, arg2 & 0xffffffff, arg3, arg4);
                    (*(code *)0x699f34)(puVar2 + 6);
                    LOCK();
                    iVar4 = *(int32_t *)puVar1;
                    *(int32_t *)puVar1 = *(int32_t *)puVar1 + -1;
                    UNLOCK();
                    if ((iVar4 == 0x10000001) &&
                       (iVar4 = (**(code **)0x18077e230)(*(undefined8 *)0x18077e268, puVar1, 0, 0), iVar4 != 0)) {
                        fcn.180473b90();
                        pcVar3 = (code *)swi(3);
                        uVar7 = (*pcVar3)();
                        return uVar7;
                    }
                    if (-1 < iVar5) {
                        return 0;
                    }
                    goto code_r0x00018018d2d9;
                }
                goto code_r0x00018018d2b6;
            }
            puVar2 = (undefined8 *)puVar2[1];
            goto joined_r0x00018018d298;
        }
        puVar2 = (undefined8 *)*puVar2;
    } while( true );
}

// ============================================================
// Function: FUN_18018d3a0
// Address: 0x18018d3a0
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.18018d3a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    
    if ((int32_t)arg3 < 1) {
        (*(code *)0x69a006)(0x57);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 0x16;
    } else if ((*(char *)0x18077e258 != '\0') ||
              (iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar2 != 0)) {
        (*(code *)0x69a0ae)(0x18077e250);
        puVar1 = *(undefined8 **)0x18077e248;
joined_r0x00018018d423:
        do {
            if (puVar1 == (undefined8 *)0x0) {
code_r0x00018018d43b:
                (*(code *)0x69a07c)(0x18077e250);
                (*(code *)0x69a006)(0x57);
                puVar3 = (undefined4 *)fcn.18046b77c();
                *puVar3 = 0x16;
code_r0x00018018d45e:
                fcn.18018d9c0(in_stack_ffffffffffffffd8);
                return -1;
            }
            if ((uint64_t)arg1 < (uint64_t)puVar1[3]) {
                puVar1 = (undefined8 *)*puVar1;
                goto joined_r0x00018018d423;
            }
            if ((uint64_t)arg1 <= (uint64_t)puVar1[3]) {
                if (puVar1 != (undefined8 *)0x0) {
                    LOCK();
                    *(int32_t *)(puVar1 + 5) = *(int32_t *)(puVar1 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    iVar2 = fcn.18018e200(in_stack_ffffffffffffffd8);
                    fcn.18018efd0(puVar1);
                    if (-1 < iVar2) {
                        return iVar2;
                    }
                    goto code_r0x00018018d45e;
                }
                goto code_r0x00018018d43b;
            }
            puVar1 = (undefined8 *)puVar1[1];
        } while( true );
    }
    return -1;
}

// ============================================================
// Function: FUN_18018d40e
// Address: 0x18018d40e
// Size: 108 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.18018d3a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    
    if ((int32_t)arg3 < 1) {
        (*(code *)0x69a006)(0x57);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 0x16;
    } else if ((*(char *)0x18077e258 != '\0') ||
              (iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar2 != 0)) {
        (*(code *)0x69a0ae)(0x18077e250);
        puVar1 = *(undefined8 **)0x18077e248;
joined_r0x00018018d423:
        do {
            if (puVar1 == (undefined8 *)0x0) {
code_r0x00018018d43b:
                (*(code *)0x69a07c)(0x18077e250);
                (*(code *)0x69a006)(0x57);
                puVar3 = (undefined4 *)fcn.18046b77c();
                *puVar3 = 0x16;
code_r0x00018018d45e:
                fcn.18018d9c0(in_stack_ffffffffffffffd8);
                return -1;
            }
            if ((uint64_t)arg1 < (uint64_t)puVar1[3]) {
                puVar1 = (undefined8 *)*puVar1;
                goto joined_r0x00018018d423;
            }
            if ((uint64_t)arg1 <= (uint64_t)puVar1[3]) {
                if (puVar1 != (undefined8 *)0x0) {
                    LOCK();
                    *(int32_t *)(puVar1 + 5) = *(int32_t *)(puVar1 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    iVar2 = fcn.18018e200(in_stack_ffffffffffffffd8);
                    fcn.18018efd0(puVar1);
                    if (-1 < iVar2) {
                        return iVar2;
                    }
                    goto code_r0x00018018d45e;
                }
                goto code_r0x00018018d43b;
            }
            puVar1 = (undefined8 *)puVar1[1];
        } while( true );
    }
    return -1;
}

// ============================================================
// Function: FUN_18018d47a
// Address: 0x18018d47a
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2028h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2060h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2058h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2040h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2050h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2048h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

int32_t fcn.18018d3a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 *puVar1;
    int32_t iVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    int64_t in_stack_ffffffffffffffd8;
    
    if ((int32_t)arg3 < 1) {
        (*(code *)0x69a006)(0x57);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 0x16;
    } else if ((*(char *)0x18077e258 != '\0') ||
              (iVar2 = (*(code *)0x69a0c6)(0x18077e260, 0x18018da30, 0, 0), iVar2 != 0)) {
        (*(code *)0x69a0ae)(0x18077e250);
        puVar1 = *(undefined8 **)0x18077e248;
joined_r0x00018018d423:
        do {
            if (puVar1 == (undefined8 *)0x0) {
code_r0x00018018d43b:
                (*(code *)0x69a07c)(0x18077e250);
                (*(code *)0x69a006)(0x57);
                puVar3 = (undefined4 *)fcn.18046b77c();
                *puVar3 = 0x16;
code_r0x00018018d45e:
                fcn.18018d9c0(in_stack_ffffffffffffffd8);
                return -1;
            }
            if ((uint64_t)arg1 < (uint64_t)puVar1[3]) {
                puVar1 = (undefined8 *)*puVar1;
                goto joined_r0x00018018d423;
            }
            if ((uint64_t)arg1 <= (uint64_t)puVar1[3]) {
                if (puVar1 != (undefined8 *)0x0) {
                    LOCK();
                    *(int32_t *)(puVar1 + 5) = *(int32_t *)(puVar1 + 5) + 1;
                    UNLOCK();
                    (*(code *)0x69a07c)(0x18077e250);
                    iVar2 = fcn.18018e200(in_stack_ffffffffffffffd8);
                    fcn.18018efd0(puVar1);
                    if (-1 < iVar2) {
                        return iVar2;
                    }
                    goto code_r0x00018018d45e;
                }
                goto code_r0x00018018d43b;
            }
            puVar1 = (undefined8 *)puVar1[1];
        } while( true );
    }
    return -1;
}

// ============================================================
// Function: FUN_18018d9c0
// Address: 0x18018d9c0
// Size: 57 bytes
// ============================================================
undefined8 fcn.18018d9c0(int64_t arg1, int64_t arg_28h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    
    if (arg1 == -1) {
        (*(code *)0x69a006)(6);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 9;
        return 0xffffffff;
    }
    iVar1 = (*(code *)0x699fde)(arg1, &var_8h);
    if (iVar1 == 0) {
        uVar2 = (*(code *)0x699ff6)();
        uVar2 = fcn.18018d4d0(uVar2);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = uVar2;
        return 0xffffffff;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018d9f9
// Address: 0x18018d9f9
// Size: 42 bytes
// ============================================================
undefined8 fcn.18018d9c0(int64_t arg1, int64_t arg_28h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    
    if (arg1 == -1) {
        (*(code *)0x69a006)(6);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 9;
        return 0xffffffff;
    }
    iVar1 = (*(code *)0x699fde)(arg1, &var_8h);
    if (iVar1 == 0) {
        uVar2 = (*(code *)0x699ff6)();
        uVar2 = fcn.18018d4d0(uVar2);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = uVar2;
        return 0xffffffff;
    }
    return 0;
}

// ============================================================
// Function: FUN_18018da23
// Address: 0x18018da23
// Size: 7 bytes
// ============================================================
undefined8 fcn.18018d9c0(int64_t arg1, int64_t arg_28h)
{
    int32_t iVar1;
    undefined4 uVar2;
    undefined4 *puVar3;
    int64_t var_8h;
    
    if (arg1 == -1) {
        (*(code *)0x69a006)(6);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = 9;
        return 0xffffffff;
    }
    iVar1 = (*(code *)0x699fde)(arg1, &var_8h);
    if (iVar1 == 0) {
        uVar2 = (*(code *)0x699ff6)();
        uVar2 = fcn.18018d4d0(uVar2);
        puVar3 = (undefined4 *)fcn.18046b77c();
        *puVar3 = uVar2;
        return 0xffffffff;
    }
    return 0;
}

