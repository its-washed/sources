// Chunk 159 - 50 functions

// ============================================================
// Function: FUN_180211920
// Address: 0x180211920
// Size: 60 bytes
// ============================================================
uint64_t fcn.180211920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211930;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX == 0) || (pcVar1 = *(code **)(*in_RCX + 0xf0), pcVar1 == (code *)0x0)) {
        return 0;
    }
    iVar5 = in_RCX[0x16];
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211963;
    uVar4 = (*pcVar1)(iVar5);
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021197d;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021198e;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119bf;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119d0;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
            return 0;
        }
        return uVar4 & 0xffffffff;
    }
    return uVar4 & 0xffffffff;
}

// ============================================================
// Function: FUN_18021195c
// Address: 0x18021195c
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180211920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211930;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX == 0) || (pcVar1 = *(code **)(*in_RCX + 0xf0), pcVar1 == (code *)0x0)) {
        return 0;
    }
    iVar5 = in_RCX[0x16];
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211963;
    uVar4 = (*pcVar1)(iVar5);
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021197d;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021198e;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119bf;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119d0;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
            return 0;
        }
        return uVar4 & 0xffffffff;
    }
    return uVar4 & 0xffffffff;
}

// ============================================================
// Function: FUN_180211970
// Address: 0x180211970
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180211920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211930;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX == 0) || (pcVar1 = *(code **)(*in_RCX + 0xf0), pcVar1 == (code *)0x0)) {
        return 0;
    }
    iVar5 = in_RCX[0x16];
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211963;
    uVar4 = (*pcVar1)(iVar5);
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021197d;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021198e;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119bf;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119d0;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
            return 0;
        }
        return uVar4 & 0xffffffff;
    }
    return uVar4 & 0xffffffff;
}

// ============================================================
// Function: FUN_1802119a0
// Address: 0x1802119a0
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180211920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211930;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX == 0) || (pcVar1 = *(code **)(*in_RCX + 0xf0), pcVar1 == (code *)0x0)) {
        return 0;
    }
    iVar5 = in_RCX[0x16];
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211963;
    uVar4 = (*pcVar1)(iVar5);
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021197d;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021198e;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119bf;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119d0;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
            return 0;
        }
        return uVar4 & 0xffffffff;
    }
    return uVar4 & 0xffffffff;
}

// ============================================================
// Function: FUN_1802119b0
// Address: 0x1802119b0
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180211920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211930;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX == 0) || (pcVar1 = *(code **)(*in_RCX + 0xf0), pcVar1 == (code *)0x0)) {
        return 0;
    }
    iVar5 = in_RCX[0x16];
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211963;
    uVar4 = (*pcVar1)(iVar5);
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021197d;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021198e;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119bf;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119d0;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
            return 0;
        }
        return uVar4 & 0xffffffff;
    }
    return uVar4 & 0xffffffff;
}

// ============================================================
// Function: FUN_1802119e1
// Address: 0x1802119e1
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180211920(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_R14;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211930;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX == 0) || (pcVar1 = *(code **)(*in_RCX + 0xf0), pcVar1 == (code *)0x0)) {
        return 0;
    }
    iVar5 = in_RCX[0x16];
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180211963;
    uVar4 = (*pcVar1)(iVar5);
    if ((int32_t)uVar4 < 1) {
        return uVar4;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021197d;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021198e;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)(in_RCX + 0xd) = 0xffffffff;
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119bf;
    iVar5 = fcn.18022ae60(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802119d0;
        iVar2 = fcn.180229fc0(*(int64_t *)(&stack0x00000060 + iVar3), *(int64_t *)(&stack0x00000068 + iVar3));
        if (iVar2 == 0) {
            *(undefined4 *)((int64_t)in_RCX + 0x6c) = 0xffffffff;
            return 0;
        }
        return uVar4 & 0xffffffff;
    }
    return uVar4 & 0xffffffff;
}

// ============================================================
// Function: FUN_1802119f0
// Address: 0x1802119f0
// Size: 70 bytes
// ============================================================
void fcn.1802119f0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802119fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180212e80;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180211b30;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180212f40;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180211a31;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180211a40
// Address: 0x180211a40
// Size: 101 bytes
// ============================================================
void fcn.180211a40(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180211a50;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        if (*(int32_t *)(arg1 + 0x14) == 0) {
            LOCK();
            piVar1 = (int32_t *)(arg1 + 0x78);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 < 2) {
                uVar3 = *(undefined8 *)(arg1 + 0x60);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180211a81;
                fcn.180224990(uVar3, 0x1804bb408, 0x843);
                uVar3 = *(undefined8 *)(arg1 + 0x70);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180211a8a;
                fcn.18027edb0(uVar3);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180211a9f;
                fcn.180224990(arg1, 0x1804bb408, 0x846);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180211ab0
// Address: 0x180211ab0
// Size: 47 bytes
// ============================================================
undefined8 fcn.180211ab0(int64_t param_1, undefined8 param_2)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if ((param_1 != 0) && (*(code **)(param_1 + 0xe0) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180211ad5. Too many branches
    // WARNING: Treating indirect jump as call
        uVar1 = (**(code **)(param_1 + 0xe0))(param_2);
        return uVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180211ae0
// Address: 0x180211ae0
// Size: 74 bytes
// ============================================================
undefined8 fcn.180211ae0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211aec;
    iVar1 = fcn.18045a350();
    if ((param_1 != 0) && (*(int64_t *)(param_1 + 0x100) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180211b06;
        uVar2 = func_0x00018020eec0();
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x180211b0e;
        uVar2 = func_0x00018027e810(uVar2);
    // WARNING: Could not recover jumptable at 0x000180211b1f. Too many branches
    // WARNING: Treating indirect jump as call
        uVar2 = (**(code **)(param_1 + 0x100))(0, uVar2, *(code **)(param_1 + 0x100));
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180211b40
// Address: 0x180211b40
// Size: 37 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180211b70
// Address: 0x180211b70
// Size: 55 bytes
// ============================================================
void fcn.180211b70(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180211b7a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = 0;
    *(undefined *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = *(undefined4 *)((int64_t)&arg_78h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180211ba2;
    fcn.180213460(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180211bb0
// Address: 0x180211bb0
// Size: 34 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211bd2
// Address: 0x180211bd2
// Size: 94 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211c30
// Address: 0x180211c30
// Size: 73 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211c79
// Address: 0x180211c79
// Size: 35 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211c9c
// Address: 0x180211c9c
// Size: 152 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211d34
// Address: 0x180211d34
// Size: 18 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211d46
// Address: 0x180211d46
// Size: 65 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211d87
// Address: 0x180211d87
// Size: 67 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211dca
// Address: 0x180211dca
// Size: 10 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180211de0
// Address: 0x180211de0
// Size: 22 bytes
// ============================================================
undefined8 fcn.180211de0(int64_t *param_1, undefined *param_2, int32_t *param_3)
{
    uint8_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar9;
    undefined8 unaff_RDI;
    undefined *puVar10;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar5) = 0x180211e0f;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (param_3 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180212159;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        return 0;
    }
    *(undefined8 *)(&stack0x00000050 + iVar6 + iVar5) = unaff_RBP;
    iVar4 = 0;
    *param_3 = 0;
    if (*(int32_t *)(param_1 + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        return 0;
    }
    iVar2 = *param_1;
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                      *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
        return 0;
    }
    if (*(int64_t *)(iVar2 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x18021204e;
        iVar4 = fcn.18020e950();
        if ((iVar4 < 1) || (pcVar3 = *(code **)(*param_1 + 0xa0), pcVar3 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            return 0;
        }
        iVar2 = param_1[0x16];
        if (iVar4 == 1) {
            iVar4 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180212085;
        uVar7 = (*pcVar3)(iVar2, param_2, &stack0x00000060 + iVar6 + iVar5, (int64_t)iVar4);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
        if (0x7fffffff < *(uint64_t *)(&stack0x00000060 + iVar6 + iVar5)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            return 0;
        }
        *param_3 = (int32_t)*(uint64_t *)(&stack0x00000060 + iVar6 + iVar5);
        return uVar7;
    }
    *(undefined8 *)(&stack0x00000058 + iVar6 + iVar5) = unaff_RSI;
    if ((*(uint32_t *)(iVar2 + 0x10) & 0x100000) == 0) {
        uVar8 = *(uint32_t *)(iVar2 + 4);
        uVar9 = (uint64_t)uVar8;
        if ((*(uint32_t *)(param_1 + 0xe) & 0x100) == 0) {
            if (1 < uVar8) {
                if ((*(int32_t *)((int64_t)param_1 + 0x14) == 0) && (*(int32_t *)(param_1 + 0x10) != 0)) {
                    if (0x20 < uVar8) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar8 - 1) + 0x88 + (int64_t)param_1);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar8)) {
                        uVar8 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar9 = (uint64_t)((int32_t)uVar9 - 1);
                                if (*(uint8_t *)(uVar9 + 0x88 + (int64_t)param_1) != uVar8) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                                    goto code_r0x000180211fdf;
                                }
                                iVar4 = iVar4 + 1;
                            } while (iVar4 < (int32_t)uVar8);
                        }
                        iVar4 = *(int32_t *)(*param_1 + 4) - uVar8;
                        iVar5 = (int64_t)iVar4;
                        if (0 < iVar4) {
                            puVar10 = param_2;
                            do {
                                *puVar10 = puVar10[(int64_t)param_1 + (0x88 - (int64_t)param_2)];
                                puVar10 = puVar10 + 1;
                                iVar5 = iVar5 + -1;
                            } while (iVar5 != 0);
                        }
                        *param_3 = iVar4;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000038 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), 
                                  *(int64_t *)(&stack0x00000060 + iVar6 + iVar5));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)param_1 + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar6 + iVar5), *(int64_t *)(&stack0x00000038 + iVar6 + iVar5)
                          , *(int64_t *)(&stack0x00000040 + iVar6 + iVar5), 
                          *(int64_t *)(&stack0x00000048 + iVar6 + iVar5), *(int64_t *)(&stack0x00000060 + iVar6 + iVar5)
                         );
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar6 + iVar5));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar7 = 1;
    } else {
        pcVar3 = *(code **)(iVar2 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar6 + iVar5) = 0x180211edd;
        iVar4 = (*pcVar3)();
        if (-1 < iVar4) {
            *param_3 = iVar4;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar7 = 0;
    }
    return uVar7;
}

// ============================================================
// Function: FUN_180211e00
// Address: 0x180211e00
// Size: 36 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180211e24
// Address: 0x180211e24
// Size: 78 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180211e72
// Address: 0x180211e72
// Size: 71 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180211eb9
// Address: 0x180211eb9
// Size: 10 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180211ec3
// Address: 0x180211ec3
// Size: 321 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180212004
// Address: 0x180212004
// Size: 14 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180212012
// Address: 0x180212012
// Size: 55 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180212049
// Address: 0x180212049
// Size: 145 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_1802120da
// Address: 0x1802120da
// Size: 17 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_1802120eb
// Address: 0x1802120eb
// Size: 63 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18021212a
// Address: 0x18021212a
// Size: 58 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180212170
// Address: 0x180212170
// Size: 48 bytes
// ============================================================
void fcn.180212170(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18021217a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = 0;
    *(undefined *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18021219b;
    fcn.180213460(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802121a0
// Address: 0x1802121a0
// Size: 58 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1802121da
// Address: 0x1802121da
// Size: 72 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180212222
// Address: 0x180212222
// Size: 918 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1802125b8
// Address: 0x1802125b8
// Size: 22 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1802125ce
// Address: 0x1802125ce
// Size: 24 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_1802125e6
// Address: 0x1802125e6
// Size: 63 bytes
// ============================================================
// WARNING: Type propagation algorithm not settling
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.180211bb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_78h, int64_t arg_80h, int64_t arg_98h,
                      int64_t arg_a0h, int64_t arg_100h)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    int32_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    uint64_t uVar12;
    int64_t var_7h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180211bbc;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)&arg_40h + iVar7) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = unaff_RSI;
        if (in_R8 == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d8c;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211da4;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211db6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211bf4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c0c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c1e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        iVar9 = *in_RCX;
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c3d;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c55;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c67;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
            return 0;
        }
        if (*(int64_t *)(iVar9 + 0x70) == 0) {
            *(undefined4 *)((int64_t)&var_18h + iVar7) = *(undefined4 *)((int64_t)&arg_58h + iVar7);
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211c8c;
            uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar7));
            return uVar8;
        }
        pcVar2 = *(code **)(iVar9 + 0x98);
        if (pcVar2 != (code *)0x0) {
            iVar4 = *(int32_t *)(iVar9 + 4);
            if (0 < iVar4) {
                iVar9 = in_RCX[0x16];
                if (iVar4 == 1) {
                    iVar4 = 0;
                }
                *(int64_t *)((int64_t)&var_20h + iVar7) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7);
                *(undefined8 *)((int64_t)&var_18h + iVar7) = in_R9;
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211ce1;
                uVar8 = (*pcVar2)(iVar9, in_RDX, (int64_t)&arg_38h + iVar7, 
                                  (int64_t)iVar4 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar7));
                if ((int32_t)uVar8 != 0) {
                    if (0x7fffffff < *(uint64_t *)((int64_t)&arg_38h + iVar7)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211cf8;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d10;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar7));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d22;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
                        return 0;
                    }
                    *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_38h + iVar7);
                }
                return uVar8;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d4b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d63;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)((int64_t)&arg_30h + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180211d75;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
        return 0;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_28h + iVar7);
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = in_R9;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = uVar11;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&var_7h + iVar7 + 1) = unaff_R13;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar7) = 0x1802121b8;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    uVar6 = *(uint32_t *)((int64_t)&arg_a0h + iVar9 + iVar7);
    uVar8 = (uint64_t)(int32_t)uVar6;
    if (in_R8 == (int32_t *)0x0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125eb;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212603;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212615;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_80h + iVar9 + iVar7) = unaff_RSI;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802121f1;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212209;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021221b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_40h + iVar9 + iVar7) = unaff_R15;
    iVar3 = *in_RCX;
    if (iVar3 == 0) {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212234;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021224c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
        uVar1 = *(uint32_t *)(iVar3 + 4);
        uVar12 = (uint64_t)uVar1;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021226e;
        iVar4 = fcn.18020ee60();
        uVar10 = uVar6;
        if (iVar4 != 0) {
            if ((int32_t)uVar6 < 1) {
                if (uVar6 == 0) {
                    uVar10 = 0;
                } else {
                    uVar10 = uVar6 & 0x80000007;
                    if ((int32_t)uVar10 < 0) {
                        uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                    }
                    iVar4 = uVar6 + ((int32_t)uVar6 >> 0x1f & 7U);
                    iVar5 = iVar4 >> 3;
                    if ((iVar5 < 0) ||
                       (((0 < iVar5 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar5)) || (iVar5 == 0)))) {
                        uVar10 = iVar5 + (uint32_t)(uVar10 != 0);
                    } else {
                        uVar10 = (iVar4 >> 0x1f & 1U) + 0x7fffffff;
                    }
                }
            } else if ((int32_t)uVar6 < 0x7ffffff7) {
                uVar10 = (int32_t)(((int32_t)(uVar6 + 7) >> 0x1f & 7U) + uVar6 + 7) >> 3;
            } else {
                uVar10 = (uint32_t)((uVar8 & 7) != 0) + (uVar6 >> 3);
            }
        }
        if ((*(uint32_t *)(*in_RCX + 0x10) & 0x100000) == 0) {
            if ((int32_t)uVar6 < 1) {
                *in_R8 = 0;
                return (uint64_t)(uVar6 == 0);
            }
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) != 0) {
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123cb;
                uVar8 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                return uVar8;
            }
            if (0x20 < uVar1) {
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802123ef;
                fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x4b4);
            }
            if (*(int32_t *)(in_RCX + 0x10) == 0) {
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 0;
code_r0x0001802124bf:
                *(uint32_t *)((int64_t)&var_20h + iVar9 + iVar7) = uVar6;
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124d9;
                iVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
                if (iVar4 == 0) {
                    return 0;
                }
                if ((uVar1 < 2) || (*(int32_t *)((int64_t)in_RCX + 0x14) != 0)) {
                    *(undefined4 *)(in_RCX + 0x10) = 0;
                } else {
                    *in_R8 = *in_R8 - uVar1;
                    *(undefined4 *)(in_RCX + 0x10) = 1;
                    iVar4 = *in_R8;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021250a;
                    fcn.180498030(in_RCX + 0x11, iVar4 + in_RDX, uVar12);
                }
                if (*(int32_t *)((int64_t)&arg_a0h + iVar9 + iVar7) != 0) {
                    *in_R8 = *in_R8 + uVar1;
                }
                return 1;
            }
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if ((in_RDX != iVar3) &&
               (in_RDX == iVar3 ||
                ((int32_t)uVar1 < 1 ||
                (uint64_t)(in_RDX - iVar3) <= (uint64_t)-(int64_t)(int32_t)uVar1 &&
                (uint64_t)(int64_t)(int32_t)uVar1 <= (uint64_t)(in_RDX - iVar3)))) {
                if (0x7fffffff - uVar1 < (-uVar1 & uVar6)) {
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212455;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021246d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
                    goto code_r0x0001802125a4;
                }
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021248f;
                fcn.180498030(in_RDX, in_RCX + 0x11, uVar12);
                in_RDX = in_RDX + uVar12;
                *(undefined4 *)((int64_t)&arg_a0h + iVar9 + iVar7) = 1;
                goto code_r0x0001802124bf;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802124a4;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = *(int64_t *)((int64_t)&arg_98h + iVar9 + iVar7);
            if (uVar1 != 1) {
code_r0x00018021236b:
                pcVar2 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021237d;
                iVar4 = (*pcVar2)(in_RCX, in_RDX, iVar3, uVar8);
                if (iVar4 < 0) {
                    *in_R8 = 0;
                    return 0;
                }
                *in_R8 = iVar4;
                return 1;
            }
            uVar6 = 0;
            if (in_RDX != iVar3) {
                uVar6 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - iVar3) ||
                        (uint64_t)(in_RDX - iVar3) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar6) == 0) goto code_r0x00018021236b;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212349;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212361;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    } else {
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021252d;
        uVar6 = fcn.18020e950();
        pcVar2 = *(code **)(*in_RCX + 0x98);
        if ((pcVar2 == (code *)0x0) || ((int32_t)uVar6 < 1)) {
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125d8;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        } else {
            iVar3 = in_RCX[0x16];
            if (uVar6 == 1) {
                uVar6 = 0;
            }
            *(uint64_t *)((int64_t)&arg_28h + iVar9 + iVar7) = uVar8;
            *(undefined8 *)((int64_t)&var_20h + iVar9 + iVar7) = in_R9;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021256e;
            uVar8 = (*pcVar2)(iVar3, in_RDX, (int64_t)&arg_30h + iVar9 + iVar7, (int64_t)(int32_t)uVar6 + uVar8);
            if ((int32_t)uVar8 == 0) {
                return uVar8;
            }
            uVar12 = *(uint64_t *)((int64_t)&arg_30h + iVar9 + iVar7);
            if (uVar12 < 0x80000000) {
                *in_R8 = (int32_t)uVar12;
                return uVar8;
            }
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x180212587;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7));
        }
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x18021259f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_28h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar7), 
                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar7));
    }
code_r0x0001802125a4:
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar9 + iVar7) = 0x1802125b1;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar9 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180212630
// Address: 0x180212630
// Size: 22 bytes
// ============================================================
undefined8 fcn.180212630(int64_t *param_1, undefined8 param_2, uint32_t *param_3)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
    iVar8 = fcn.18045a350();
    iVar4 = -iVar8;
    if (param_3 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212878;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212890;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar7), *(int64_t *)(&stack0x00000048 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802128a2;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar7));
        return 0;
    }
    *(undefined8 *)(&stack0x00000058 + iVar4 + iVar7) = unaff_R14;
    *param_3 = 0;
    if (*(int32_t *)(param_1 + 2) == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212689;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802126a1;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar7), *(int64_t *)(&stack0x00000048 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802126b3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar7));
        return 0;
    }
    *(undefined8 *)(&stack0x00000050 + iVar4 + iVar7) = unaff_RSI;
    iVar2 = *param_1;
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802126d4;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802126ec;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar7), *(int64_t *)(&stack0x00000048 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar7));
    } else if (*(int64_t *)(iVar2 + 0x70) == 0) {
        if ((*(uint32_t *)(iVar2 + 0x10) & 0x100000) != 0) {
            pcVar3 = *(code **)(iVar2 + 0x20);
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212715;
            uVar5 = (*pcVar3)();
            if ((int32_t)uVar5 < 0) {
                return 0;
            }
            *param_3 = uVar5;
            return 1;
        }
        uVar5 = *(uint32_t *)(iVar2 + 4);
        if ((uint32_t)iVar8 < uVar5) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212749;
            fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
        } else if (uVar5 == 1) {
            return 1;
        }
        uVar1 = *(uint32_t *)((int64_t)param_1 + 0x14);
        if ((*(uint32_t *)(param_1 + 0xe) & 0x100) == 0) {
            if (uVar1 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802127ab;
                fcn.1804986e0((uint64_t)uVar1 + 0x38 + (int64_t)param_1, uVar5 - uVar1, 
                              (int64_t)(int32_t)(uVar5 - uVar1));
            }
            pcVar3 = *(code **)(*param_1 + 0x20);
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802127c2;
            uVar9 = (*pcVar3)(param_1, param_2, param_1 + 7, uVar5);
            if ((int32_t)uVar9 != 0) {
                *param_3 = uVar5;
                return uVar9;
            }
            return uVar9;
        }
        if (uVar1 == 0) {
            *param_3 = 0;
            return 1;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212765;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x18021277d;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar7), *(int64_t *)(&stack0x00000048 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar7));
    } else {
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x1802127d3;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar3 = *(code **)(*param_1 + 0xa0), pcVar3 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212865;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7)
                         );
        } else {
            iVar8 = param_1[0x16];
            if (iVar6 == 1) {
                iVar6 = 0;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212807;
            uVar9 = (*pcVar3)(iVar8, param_2, &stack0x00000060 + iVar4 + iVar7, (int64_t)iVar6);
            if ((int32_t)uVar9 == 0) {
                return uVar9;
            }
            if (*(uint64_t *)(&stack0x00000060 + iVar4 + iVar7) < 0x80000000) {
                *param_3 = (uint32_t)*(uint64_t *)(&stack0x00000060 + iVar4 + iVar7);
                return uVar9;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x18021281e;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7)
                         );
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212836;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar4 + iVar7), *(int64_t *)(&stack0x00000038 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar4 + iVar7), *(int64_t *)(&stack0x00000048 + iVar4 + iVar7), 
                      *(int64_t *)(&stack0x00000060 + iVar4 + iVar7));
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + iVar7) = 0x180212848;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar4 + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180212650
// Address: 0x180212650
// Size: 35 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180212673
// Address: 0x180212673
// Size: 79 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_1802126c2
// Address: 0x1802126c2
// Size: 410 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_18021285c
// Address: 0x18021285c
// Size: 23 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180212873
// Address: 0x180212873
// Size: 57 bytes
// ============================================================
undefined8
fcn.180211b40(int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    undefined *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar11;
    undefined8 unaff_RDI;
    undefined *puVar12;
    uint32_t *in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_8 [4];
    
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RBP;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_RDI;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x18021265e;
        iVar9 = fcn.18045a350();
        iVar8 = -iVar9;
        if (in_R8 == (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212878;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212890;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802128a2;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_R14;
        *in_R8 = 0;
        if (*(int32_t *)(in_RCX + 2) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212689;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126a1;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126b3;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RSI;
        iVar3 = *in_RCX;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126d4;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802126ec;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else if (*(int64_t *)(iVar3 + 0x70) == 0) {
            if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) != 0) {
                pcVar4 = *(code **)(iVar3 + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212715;
                uVar5 = (*pcVar4)();
                if ((int32_t)uVar5 < 0) {
                    return 0;
                }
                *in_R8 = uVar5;
                return 1;
            }
            uVar5 = *(uint32_t *)(iVar3 + 4);
            if ((uint32_t)iVar9 < uVar5) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212749;
                fcn.18027bb50(0x1804bb530, 0x1804bb408, 1099);
            } else if (uVar5 == 1) {
                return 1;
            }
            uVar2 = *(uint32_t *)((int64_t)in_RCX + 0x14);
            if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
                if (uVar2 < uVar5) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127ab;
                    fcn.1804986e0((uint64_t)uVar2 + 0x38 + (int64_t)in_RCX, uVar5 - uVar2, 
                                  (int64_t)(int32_t)(uVar5 - uVar2));
                }
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127c2;
                uVar10 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, uVar5);
                if ((int32_t)uVar10 != 0) {
                    *in_R8 = uVar5;
                    return uVar10;
                }
                return uVar10;
            }
            if (uVar2 == 0) {
                *in_R8 = 0;
                return 1;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212765;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021277d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        } else {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802127d3;
            iVar6 = fcn.18020e950();
            if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212865;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            } else {
                iVar9 = in_RCX[0x16];
                if (iVar6 == 1) {
                    iVar6 = 0;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212807;
                uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
                if ((int32_t)uVar10 == 0) {
                    return uVar10;
                }
                uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
                if (uVar11 < 0x80000000) {
                    *in_R8 = (uint32_t)uVar11;
                    return uVar10;
                }
                *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021281e;
                fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212836;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212848;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x18) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 0x10) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7) = 0x180211e0f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    if (in_R8 == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021212f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212147;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212159;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar7) = unaff_RBP;
    iVar6 = 0;
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e38;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e50;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e62;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    iVar9 = *in_RCX;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e7f;
        fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211e97;
        fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ea9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
        return 0;
    }
    if (*(int64_t *)(iVar9 + 0x70) != 0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021204e;
        iVar6 = fcn.18020e950();
        if ((iVar6 < 1) || (pcVar4 = *(code **)(*in_RCX + 0xa0), pcVar4 == (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120f0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212108;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021211a;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        iVar9 = in_RCX[0x16];
        if (iVar6 == 1) {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212085;
        uVar10 = (*pcVar4)(iVar9, in_RDX, (int64_t)&arg_60h + iVar8 + iVar7, (int64_t)iVar6);
        if ((int32_t)uVar10 != 0) {
            uVar11 = *(uint64_t *)((int64_t)&arg_60h + iVar8 + iVar7);
            if (uVar11 < 0x80000000) {
                *in_R8 = (uint32_t)uVar11;
                return uVar10;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120a0;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120b8;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x1802120ca;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            return 0;
        }
        return uVar10;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar7) = unaff_RSI;
    if ((*(uint32_t *)(iVar9 + 0x10) & 0x100000) == 0) {
        uVar5 = *(uint32_t *)(iVar9 + 4);
        uVar11 = (uint64_t)uVar5;
        if ((*(uint32_t *)(in_RCX + 0xe) & 0x100) == 0) {
            if (1 < uVar5) {
                if ((*(int32_t *)((int64_t)in_RCX + 0x14) == 0) && (*(int32_t *)(in_RCX + 0x10) != 0)) {
                    if (0x20 < uVar5) {
                        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f62;
                        fcn.18027bb50(0x1804bb570, 0x1804bb408, 0x537);
                    }
                    uVar1 = *(uint8_t *)((uint64_t)(uVar5 - 1) + 0x88 + (int64_t)in_RCX);
                    if ((uVar1 != 0) && ((int32_t)(uint32_t)uVar1 <= (int32_t)uVar5)) {
                        uVar5 = (uint32_t)uVar1;
                        if (uVar1 != 0) {
                            do {
                                uVar11 = (uint64_t)((int32_t)uVar11 - 1);
                                if (*(uint8_t *)(uVar11 + 0x88 + (int64_t)in_RCX) != uVar5) {
                                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211fd3;
                                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                                    goto code_r0x000180211fdf;
                                }
                                iVar6 = iVar6 + 1;
                            } while (iVar6 < (int32_t)uVar5);
                        }
                        uVar5 = *(int32_t *)(*in_RCX + 4) - uVar5;
                        iVar7 = (int64_t)(int32_t)uVar5;
                        if (0 < (int32_t)uVar5) {
                            puVar12 = in_RDX;
                            do {
                                *puVar12 = puVar12[(int64_t)in_RCX + (0x88 - (int64_t)in_RDX)];
                                puVar12 = puVar12 + 1;
                                iVar7 = iVar7 + -1;
                            } while (iVar7 != 0);
                        }
                        *in_R8 = uVar5;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212017;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180211fdf:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211feb;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                } else {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x18021202a;
                    fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                    *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180212042;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
                }
                goto code_r0x000180211ff0;
            }
        } else if (*(int32_t *)((int64_t)in_RCX + 0x14) != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f08;
            fcn.180229480(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211f20;
            fcn.1802295a0(*(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000038 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_60h + iVar8 + iVar7));
code_r0x000180211ff0:
            *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211ffd;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_50h + iVar8 + iVar7));
            goto code_r0x000180211ffd;
        }
code_r0x000180211ee8:
        uVar10 = 1;
    } else {
        pcVar4 = *(code **)(iVar9 + 0x20);
        *(undefined8 *)((int64_t)auStackX_8 + iVar8 + iVar7) = 0x180211edd;
        uVar5 = (*pcVar4)();
        if (-1 < (int32_t)uVar5) {
            *in_R8 = uVar5;
            goto code_r0x000180211ee8;
        }
code_r0x000180211ffd:
        uVar10 = 0;
    }
    return uVar10;
}

// ============================================================
// Function: FUN_1802128b0
// Address: 0x1802128b0
// Size: 55 bytes
// ============================================================
void fcn.1802128b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802128ba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = 0;
    *(undefined *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802128e2;
    fcn.180213460(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802128f0
// Address: 0x1802128f0
// Size: 57 bytes
// ============================================================
void fcn.1802128f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_70h)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802128fa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180212924;
    fcn.180213460(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180212930
// Address: 0x180212930
// Size: 370 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

undefined8 fcn.180212930(int64_t arg_38h, int64_t arg_48h, int64_t arg_58h)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *in_RCX;
    int32_t iVar5;
    undefined8 in_RDX;
    undefined4 *in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180212940;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_R8 == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a6b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a83;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        goto code_r0x000180212a88;
    }
    *in_R8 = 0;
    if (*(int32_t *)(in_RCX + 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212966;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18021297e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        goto code_r0x000180212a88;
    }
    iVar1 = *in_RCX;
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212995;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802129ad;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        goto code_r0x000180212a88;
    }
    if (*(int64_t *)(iVar1 + 0x70) == 0) {
        *(undefined4 *)((int64_t)&var_18h + iVar3) = *(undefined4 *)((int64_t)&arg_58h + iVar3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802129cd;
        uVar4 = fcn.180212ab0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_38h + iVar3));
        return uVar4;
    }
    pcVar2 = *(code **)(iVar1 + 0x98);
    if (pcVar2 == (code *)0x0) {
code_r0x000180212a5a:
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a5f;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    } else {
        iVar5 = *(int32_t *)(iVar1 + 4);
        if (iVar5 < 1) goto code_r0x000180212a5a;
        if (iVar5 == 1) {
            iVar5 = 0;
        }
        iVar1 = in_RCX[0x16];
        *(int64_t *)((int64_t)&var_20h + iVar3) = (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar3);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a17;
        uVar4 = (*pcVar2)(iVar1, in_RDX, (int64_t)&arg_48h + iVar3, 
                          (int64_t)iVar5 + (int64_t)*(int32_t *)((int64_t)&arg_58h + iVar3));
        if ((int32_t)uVar4 == 0) {
            return uVar4;
        }
        if (*(uint64_t *)((int64_t)&arg_48h + iVar3) < 0x80000000) {
            *in_R8 = (int32_t)*(uint64_t *)((int64_t)&arg_48h + iVar3);
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a2e;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a46;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                  *(int64_t *)((int64_t)&arg_48h + iVar3));
code_r0x000180212a88:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180212a95;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180212ab0
// Address: 0x180212ab0
// Size: 891 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_29h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

bool fcn.180212ab0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint64_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    code *pcVar4;
    bool bVar5;
    int32_t iVar6;
    uint32_t uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint32_t uVar10;
    uint64_t uVar11;
    uint32_t *in_R8;
    int64_t in_R9;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_30 [7];
    int64_t var_29h;
    
    _auStack_30 = 0x180212ad2;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar7 = *(uint32_t *)((int64_t)&arg_48h + iVar8);
    uVar11 = (uint64_t)(int32_t)uVar7;
    *(undefined8 *)(auStack_30 + iVar8) = 0x180212af2;
    iVar6 = fcn.18020ee60();
    uVar10 = uVar7;
    if (iVar6 != 0) {
        if ((int32_t)uVar7 < 1) {
            if (uVar7 == 0) {
                uVar10 = 0;
            } else {
                uVar10 = uVar7 & 0x80000007;
                if ((int32_t)uVar10 < 0) {
                    uVar10 = (uVar10 - 1 | 0xfffffff8) + 1;
                }
                iVar6 = uVar7 + ((int32_t)uVar7 >> 0x1f & 7U);
                iVar9 = iVar6 >> 3;
                if ((iVar9 < 0) ||
                   (((0 < iVar9 && ((int32_t)(uint32_t)(uVar10 != 0) <= 0x7fffffff - iVar9)) || (iVar9 == 0)))) {
                    uVar10 = iVar9 + (uint32_t)(uVar10 != 0);
                } else {
                    uVar10 = (iVar6 >> 0x1f & 1U) + 0x7fffffff;
                }
            }
        } else if ((int32_t)uVar7 < 0x7ffffff7) {
            uVar10 = (int32_t)(((int32_t)(uVar7 + 7) >> 0x1f & 7U) + uVar7 + 7) >> 3;
        } else {
            uVar10 = (uint32_t)((uVar11 & 7) != 0) + (uVar7 >> 3);
        }
    }
    iVar3 = *in_RCX;
    uVar2 = *(uint32_t *)(iVar3 + 4);
    if ((*(uint32_t *)(iVar3 + 0x10) & 0x100000) == 0) {
        if ((int32_t)uVar7 < 1) {
            *in_R8 = 0;
            return uVar7 == 0;
        }
        iVar6 = *(int32_t *)((int64_t)in_RCX + 0x14);
        *(int64_t *)((int64_t)&arg_28h + iVar8) = (int64_t)iVar6;
        *(int32_t *)((int64_t)&arg_48h + iVar8) = iVar6;
        uVar1 = (iVar6 - in_R9) + in_RDX;
        if (0 < (int32_t)uVar10 &&
            (uVar1 != 0 && ((uint64_t)-(int64_t)(int32_t)uVar10 < uVar1 || uVar1 < (uint64_t)(int64_t)(int32_t)uVar10)))
        {
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212c75;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212c8d;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8));
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212c9f;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar8));
            return false;
        }
        if ((iVar6 == 0) && ((*(uint32_t *)((int64_t)in_RCX + 0x84) & uVar7) == 0)) {
            pcVar4 = *(code **)(iVar3 + 0x20);
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212cc6;
            iVar6 = (*pcVar4)(in_RCX, in_RDX, in_R9, uVar11);
            if (iVar6 == 0) {
                *in_R8 = 0;
                return false;
            }
            *in_R8 = uVar7;
        } else {
            if (0x20 < (int32_t)uVar2) {
                *(undefined8 *)(auStack_30 + iVar8) = 0x180212cfa;
                fcn.18027bb50(0x1804bb4d0, 0x1804bb408, 0x3a3);
                iVar6 = *(int32_t *)((int64_t)&arg_48h + iVar8);
            }
            uVar10 = 0;
            if (iVar6 != 0) {
                iVar9 = uVar2 - iVar6;
                if ((int32_t)uVar7 < iVar9) {
                    *(undefined8 *)(auStack_30 + iVar8) = 0x180212d2c;
                    fcn.180498030((int64_t)iVar6 + 0x38 + (int64_t)in_RCX, in_R9, uVar11);
                    *(int32_t *)((int64_t)in_RCX + 0x14) = *(int32_t *)((int64_t)in_RCX + 0x14) + uVar7;
                    *in_R8 = 0;
                    goto code_r0x000180212e09;
                }
                uVar7 = uVar7 - iVar9;
                if ((int32_t)(0x7fffffff - uVar2) < (int32_t)(-uVar2 & uVar7)) {
                    *(undefined8 *)(auStack_30 + iVar8) = 0x180212d4d;
                    fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8)
                                 );
                    *(undefined8 *)(auStack_30 + iVar8) = 0x180212d65;
                    fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8)
                                  , *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8));
                    *(undefined8 *)(auStack_30 + iVar8) = 0x180212d77;
                    fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar8));
                    return false;
                }
                *(undefined8 *)(auStack_30 + iVar8) = 0x180212d98;
                fcn.180498030(*(int64_t *)((int64_t)&arg_28h + iVar8) + 0x38 + (int64_t)in_RCX, in_R9, (int64_t)iVar9);
                in_R9 = in_R9 + iVar9;
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(auStack_30 + iVar8) = 0x180212db2;
                iVar6 = (*pcVar4)(in_RCX, in_RDX, in_RCX + 7, (int64_t)(int32_t)uVar2);
                if (iVar6 == 0) goto code_r0x000180212bf3;
                in_RDX = in_RDX + (int32_t)uVar2;
                uVar10 = uVar2;
            }
            *in_R8 = uVar10;
            uVar10 = uVar2 - 1 & uVar7;
            iVar6 = uVar7 - uVar10;
            if (0 < iVar6) {
                pcVar4 = *(code **)(*in_RCX + 0x20);
                *(undefined8 *)(auStack_30 + iVar8) = 0x180212de6;
                iVar9 = (*pcVar4)(in_RCX, in_RDX, in_R9, (int64_t)iVar6);
                if (iVar9 == 0) goto code_r0x000180212bf3;
                *in_R8 = *in_R8 + iVar6;
            }
            if (uVar10 != 0) {
                *(undefined8 *)(auStack_30 + iVar8) = 0x180212e05;
                fcn.180498030(in_RCX + 7, iVar6 + in_R9, (int64_t)(int32_t)uVar10);
            }
            *(uint32_t *)((int64_t)in_RCX + 0x14) = uVar10;
        }
code_r0x000180212e09:
        bVar5 = true;
    } else {
        if (uVar2 == 1) {
            uVar7 = 0;
            if (in_RDX != in_R9) {
                uVar7 = (uint32_t)
                        ((uint64_t)-(int64_t)(int32_t)uVar10 < (uint64_t)(in_RDX - in_R9) ||
                        (uint64_t)(in_RDX - in_R9) < (uint64_t)(int64_t)(int32_t)uVar10);
            }
            if ((0 < (int32_t)uVar10 & uVar7) == 0) goto code_r0x000180212bfa;
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212bc9;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8));
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212be1;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar8), *(int64_t *)(&stack0x00000000 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_8 + iVar8), *(int64_t *)((int64_t)&var_10h + iVar8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8));
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212bf3;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar8));
        } else {
code_r0x000180212bfa:
            pcVar4 = *(code **)(iVar3 + 0x20);
            *(undefined8 *)(auStack_30 + iVar8) = 0x180212c0c;
            uVar7 = (*pcVar4)(in_RCX, in_RDX, in_R9, uVar11);
            if (-1 < (int32_t)uVar7) {
                *in_R8 = uVar7;
                goto code_r0x000180212e09;
            }
        }
code_r0x000180212bf3:
        bVar5 = false;
    }
    return bVar5;
}

