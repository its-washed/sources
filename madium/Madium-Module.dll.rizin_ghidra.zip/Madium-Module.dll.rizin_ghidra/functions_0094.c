// Chunk 94 - 50 functions

// ============================================================
// Function: FUN_18013cd83
// Address: 0x18013cd83
// Size: 569 bytes
// ============================================================
void fcn.18013cd83(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_c0h,
                  int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h)
{
    undefined8 uVar1;
    char cVar2;
    undefined4 uVar3;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R10;
    undefined8 unaff_R12;
    float fVar4;
    float fVar5;
    float unaff_XMM6_Da;
    float unaff_XMM7_Da;
    float fVar6;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM10_Da;
    float unaff_XMM11_Da;
    float unaff_XMM12_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    float unaff_XMM15_Da;
    int64_t var_20h;
    
    cVar2 = func_0x000180108120(&arg_40h, &arg_48h);
    if (cVar2 != '\0') {
        *(uint32_t *)(in_R10 + 0x1fc0) = *(uint32_t *)(in_R10 + 0x1fc0) | 1;
    }
    *(float *)(unaff_RBP + 0x4c) = unaff_XMM15_Da + unaff_XMM6_Da;
    fVar6 = (float)(int32_t)((unaff_XMM12_Da + unaff_XMM6_Da) * 0.5 + unaff_XMM7_Da);
    fVar4 = (unaff_XMM8_Da - unaff_XMM11_Da) - *(float *)(unaff_RBP + 0x38);
    fVar5 = 0.0;
    if (0.0 <= fVar4) {
        fVar5 = fVar4;
    }
    fVar4 = ((fVar5 - unaff_XMM13_Da) - unaff_XMM10_Da) * *(float *)(unaff_RDI + 0xe98);
    fVar5 = 0.0;
    if (0.0 <= fVar4) {
        fVar5 = fVar4;
    }
    fVar5 = fVar5 + unaff_XMM14_Da + unaff_XMM11_Da;
    *(float *)(unaff_RBP + 0x48) = fVar5;
    *(float *)(unaff_RSI + 0x160) = fVar5 + unaff_XMM13_Da;
    arg_40h._0_4_ = *(float *)(in_R10 + 0x1080);
    arg_40h._4_4_ = *(float *)(in_R10 + 0x1084);
    arg_48h._0_4_ = *(undefined4 *)(in_R10 + 0x1088);
    arg_48h._4_4_ = *(float *)(in_R10 + 0x108c) * *(float *)(in_R10 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&arg_40h);
    if (unaff_XMM13_Da <= unaff_XMM10_Da) {
        if (*(char *)(unaff_RDI + 0x29f8) != (char)unaff_R12) {
            func_0x0001801124e0(0x180645aac);
        }
        if (unaff_XMM10_Da < unaff_XMM9_Da) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            *(float *)(unaff_RBP + 0x40) = unaff_XMM11_Da;
            *(float *)(unaff_RBP + 0x44) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            func_0x000180126300(uVar1, unaff_RBP + 0x40, unaff_RBP + 0x38, uVar3, var_20h);
        }
    } else {
        fVar5 = *(float *)(unaff_RBP + 0x48) - *(float *)(unaff_RDI + 0xdec);
        fVar4 = *(float *)(unaff_RBP + 0x48) + unaff_XMM13_Da + unaff_XMM10_Da + *(float *)(unaff_RDI + 0xdec);
        if ((unaff_XMM11_Da < fVar5) && (unaff_XMM10_Da < unaff_XMM9_Da)) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = fVar5;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            arg_40h._0_4_ = unaff_XMM11_Da;
            arg_40h._4_4_ = fVar6;
            func_0x000180126300(uVar1, &arg_40h, unaff_RBP + 0x38, uVar3, var_20h);
            in_R10 = *(int64_t *)0x180781f28;
        }
        if ((fVar4 < unaff_XMM8_Da) && (unaff_XMM10_Da < unaff_XMM9_Da)) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            arg_40h._0_4_ = fVar4;
            arg_40h._4_4_ = fVar6;
            func_0x000180126300(uVar1, &arg_40h, unaff_RBP + 0x38, uVar3, var_20h);
            in_R10 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(unaff_RDI + 0x29f8) != (char)unaff_R12) {
            *(undefined8 *)(in_R10 + 0x2a28) = unaff_R12;
            *(undefined8 *)(in_R10 + 0x2a20) = 0x180645aac;
        }
        fVar5 = *(float *)(unaff_RDI + 0xdf0);
        uVar1 = *(undefined8 *)(unaff_RSI + 800);
        *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
        *(float *)(unaff_RBP + 0x3c) = unaff_XMM12_Da + fVar5;
        func_0x0001800f7480(uVar1, unaff_RBP + 0x48, unaff_RBP + 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_18013cfbc
// Address: 0x18013cfbc
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_28h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.18013cd83(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_c0h,
                  int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h)
{
    undefined8 uVar1;
    char cVar2;
    undefined4 uVar3;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R10;
    undefined8 unaff_R12;
    float fVar4;
    float fVar5;
    float unaff_XMM6_Da;
    float unaff_XMM7_Da;
    float fVar6;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM10_Da;
    float unaff_XMM11_Da;
    float unaff_XMM12_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    float unaff_XMM15_Da;
    int64_t var_20h;
    
    cVar2 = func_0x000180108120(&arg_40h, &arg_48h);
    if (cVar2 != '\0') {
        *(uint32_t *)(in_R10 + 0x1fc0) = *(uint32_t *)(in_R10 + 0x1fc0) | 1;
    }
    *(float *)(unaff_RBP + 0x4c) = unaff_XMM15_Da + unaff_XMM6_Da;
    fVar6 = (float)(int32_t)((unaff_XMM12_Da + unaff_XMM6_Da) * 0.5 + unaff_XMM7_Da);
    fVar4 = (unaff_XMM8_Da - unaff_XMM11_Da) - *(float *)(unaff_RBP + 0x38);
    fVar5 = 0.0;
    if (0.0 <= fVar4) {
        fVar5 = fVar4;
    }
    fVar4 = ((fVar5 - unaff_XMM13_Da) - unaff_XMM10_Da) * *(float *)(unaff_RDI + 0xe98);
    fVar5 = 0.0;
    if (0.0 <= fVar4) {
        fVar5 = fVar4;
    }
    fVar5 = fVar5 + unaff_XMM14_Da + unaff_XMM11_Da;
    *(float *)(unaff_RBP + 0x48) = fVar5;
    *(float *)(unaff_RSI + 0x160) = fVar5 + unaff_XMM13_Da;
    arg_40h._0_4_ = *(float *)(in_R10 + 0x1080);
    arg_40h._4_4_ = *(float *)(in_R10 + 0x1084);
    arg_48h._0_4_ = *(undefined4 *)(in_R10 + 0x1088);
    arg_48h._4_4_ = *(float *)(in_R10 + 0x108c) * *(float *)(in_R10 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&arg_40h);
    if (unaff_XMM13_Da <= unaff_XMM10_Da) {
        if (*(char *)(unaff_RDI + 0x29f8) != (char)unaff_R12) {
            func_0x0001801124e0(0x180645aac);
        }
        if (unaff_XMM10_Da < unaff_XMM9_Da) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            *(float *)(unaff_RBP + 0x40) = unaff_XMM11_Da;
            *(float *)(unaff_RBP + 0x44) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            func_0x000180126300(uVar1, unaff_RBP + 0x40, unaff_RBP + 0x38, uVar3, var_20h);
        }
    } else {
        fVar5 = *(float *)(unaff_RBP + 0x48) - *(float *)(unaff_RDI + 0xdec);
        fVar4 = *(float *)(unaff_RBP + 0x48) + unaff_XMM13_Da + unaff_XMM10_Da + *(float *)(unaff_RDI + 0xdec);
        if ((unaff_XMM11_Da < fVar5) && (unaff_XMM10_Da < unaff_XMM9_Da)) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = fVar5;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            arg_40h._0_4_ = unaff_XMM11_Da;
            arg_40h._4_4_ = fVar6;
            func_0x000180126300(uVar1, &arg_40h, unaff_RBP + 0x38, uVar3, var_20h);
            in_R10 = *(int64_t *)0x180781f28;
        }
        if ((fVar4 < unaff_XMM8_Da) && (unaff_XMM10_Da < unaff_XMM9_Da)) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            arg_40h._0_4_ = fVar4;
            arg_40h._4_4_ = fVar6;
            func_0x000180126300(uVar1, &arg_40h, unaff_RBP + 0x38, uVar3, var_20h);
            in_R10 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(unaff_RDI + 0x29f8) != (char)unaff_R12) {
            *(undefined8 *)(in_R10 + 0x2a28) = unaff_R12;
            *(undefined8 *)(in_R10 + 0x2a20) = 0x180645aac;
        }
        fVar5 = *(float *)(unaff_RDI + 0xdf0);
        uVar1 = *(undefined8 *)(unaff_RSI + 800);
        *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
        *(float *)(unaff_RBP + 0x3c) = unaff_XMM12_Da + fVar5;
        func_0x0001800f7480(uVar1, unaff_RBP + 0x48, unaff_RBP + 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_18013d01b
// Address: 0x18013d01b
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: arg_28h
// WARNING: Variable defined which should be unmapped: arg_f0h
// WARNING: [rz-ghidra] Detected overlap for variable arg_4ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

void fcn.18013cd83(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_80h, int64_t arg_90h, int64_t arg_a0h, int64_t arg_b0h, int64_t arg_c0h,
                  int64_t arg_d0h, int64_t arg_e0h, int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h)
{
    undefined8 uVar1;
    char cVar2;
    undefined4 uVar3;
    int64_t unaff_RBP;
    int64_t unaff_RSI;
    int64_t unaff_RDI;
    int64_t in_R10;
    undefined8 unaff_R12;
    float fVar4;
    float fVar5;
    float unaff_XMM6_Da;
    float unaff_XMM7_Da;
    float fVar6;
    float unaff_XMM8_Da;
    float unaff_XMM9_Da;
    float unaff_XMM10_Da;
    float unaff_XMM11_Da;
    float unaff_XMM12_Da;
    float unaff_XMM13_Da;
    float unaff_XMM14_Da;
    float unaff_XMM15_Da;
    int64_t var_20h;
    
    cVar2 = func_0x000180108120(&arg_40h, &arg_48h);
    if (cVar2 != '\0') {
        *(uint32_t *)(in_R10 + 0x1fc0) = *(uint32_t *)(in_R10 + 0x1fc0) | 1;
    }
    *(float *)(unaff_RBP + 0x4c) = unaff_XMM15_Da + unaff_XMM6_Da;
    fVar6 = (float)(int32_t)((unaff_XMM12_Da + unaff_XMM6_Da) * 0.5 + unaff_XMM7_Da);
    fVar4 = (unaff_XMM8_Da - unaff_XMM11_Da) - *(float *)(unaff_RBP + 0x38);
    fVar5 = 0.0;
    if (0.0 <= fVar4) {
        fVar5 = fVar4;
    }
    fVar4 = ((fVar5 - unaff_XMM13_Da) - unaff_XMM10_Da) * *(float *)(unaff_RDI + 0xe98);
    fVar5 = 0.0;
    if (0.0 <= fVar4) {
        fVar5 = fVar4;
    }
    fVar5 = fVar5 + unaff_XMM14_Da + unaff_XMM11_Da;
    *(float *)(unaff_RBP + 0x48) = fVar5;
    *(float *)(unaff_RSI + 0x160) = fVar5 + unaff_XMM13_Da;
    arg_40h._0_4_ = *(float *)(in_R10 + 0x1080);
    arg_40h._4_4_ = *(float *)(in_R10 + 0x1084);
    arg_48h._0_4_ = *(undefined4 *)(in_R10 + 0x1088);
    arg_48h._4_4_ = *(float *)(in_R10 + 0x108c) * *(float *)(in_R10 + 0xd9c);
    uVar3 = func_0x0001800f5fa0(&arg_40h);
    if (unaff_XMM13_Da <= unaff_XMM10_Da) {
        if (*(char *)(unaff_RDI + 0x29f8) != (char)unaff_R12) {
            func_0x0001801124e0(0x180645aac);
        }
        if (unaff_XMM10_Da < unaff_XMM9_Da) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            *(float *)(unaff_RBP + 0x40) = unaff_XMM11_Da;
            *(float *)(unaff_RBP + 0x44) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            func_0x000180126300(uVar1, unaff_RBP + 0x40, unaff_RBP + 0x38, uVar3, var_20h);
        }
    } else {
        fVar5 = *(float *)(unaff_RBP + 0x48) - *(float *)(unaff_RDI + 0xdec);
        fVar4 = *(float *)(unaff_RBP + 0x48) + unaff_XMM13_Da + unaff_XMM10_Da + *(float *)(unaff_RDI + 0xdec);
        if ((unaff_XMM11_Da < fVar5) && (unaff_XMM10_Da < unaff_XMM9_Da)) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = fVar5;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            arg_40h._0_4_ = unaff_XMM11_Da;
            arg_40h._4_4_ = fVar6;
            func_0x000180126300(uVar1, &arg_40h, unaff_RBP + 0x38, uVar3, var_20h);
            in_R10 = *(int64_t *)0x180781f28;
        }
        if ((fVar4 < unaff_XMM8_Da) && (unaff_XMM10_Da < unaff_XMM9_Da)) {
            uVar1 = *(undefined8 *)(unaff_RSI + 800);
            *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
            *(float *)(unaff_RBP + 0x3c) = fVar6;
            var_20h = (int64_t)(uint32_t)unaff_XMM9_Da;
            arg_40h._0_4_ = fVar4;
            arg_40h._4_4_ = fVar6;
            func_0x000180126300(uVar1, &arg_40h, unaff_RBP + 0x38, uVar3, var_20h);
            in_R10 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(unaff_RDI + 0x29f8) != (char)unaff_R12) {
            *(undefined8 *)(in_R10 + 0x2a28) = unaff_R12;
            *(undefined8 *)(in_R10 + 0x2a20) = 0x180645aac;
        }
        fVar5 = *(float *)(unaff_RDI + 0xdf0);
        uVar1 = *(undefined8 *)(unaff_RSI + 800);
        *(float *)(unaff_RBP + 0x38) = unaff_XMM8_Da;
        *(float *)(unaff_RBP + 0x3c) = unaff_XMM12_Da + fVar5;
        func_0x0001800f7480(uVar1, unaff_RBP + 0x48, unaff_RBP + 0x38);
    }
    return;
}

// ============================================================
// Function: FUN_18013d0a0
// Address: 0x18013d0a0
// Size: 1600 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7fh
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h

void fcn.18013d0a0(void)
{
    char *pcVar1;
    float *pfVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    char cVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t *puVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    char *pcVar17;
    bool bVar18;
    float fVar19;
    undefined4 uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    float var_128h;
    float var_124h;
    int64_t var_120h;
    uint64_t uStack_118;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h;
    float var_fch;
    float var_f8h;
    float var_f4h;
    float var_f0h;
    int64_t var_ech;
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_40h;
    
    iVar11 = *(int64_t *)0x180781f28;
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    bVar18 = false;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar5 = *(int64_t *)(iVar11 + 0x15e0);
    uVar20 = *(undefined4 *)(iVar11 + 0x2008);
    *(undefined4 *)(iVar11 + 0x2008) = 0;
    if (*(char *)(iVar5 + 0x10e) != '\0') goto code_r0x00018013d93a;
    uVar8 = func_0x0001800f5a90(0x180645ba8, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    fVar23 = *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0x12f8);
    pcVar17 = "##v";
    while (*pcVar17 != '\0') {
        pcVar1 = pcVar17 + 1;
        if (((*pcVar17 == '#') && (*pcVar1 == '#')) || (pcVar17 = pcVar1, pcVar1 == (char *)0xffffffffffffffff)) break;
    }
    var_148h._0_4_ = 0xbf800000;
    func_0x0001800fe0a0(&var_120h, 0x180645ba8, pcVar17, 0);
    var_130h._0_4_ = *(float *)(iVar5 + 0x158);
    fVar22 = *(float *)(iVar11 + 0xde0);
    fVar21 = (float)var_120h;
    var_128h = (float)var_130h + fVar23;
    var_124h = fVar22 + fVar22 + var_120h._4_4_ + *(float *)(iVar5 + 0x15c);
    var_130h._4_4_ = *(float *)(iVar5 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_100h = 0.0;
    } else {
        var_100h = (float)var_120h + *(float *)(iVar11 + 0xdf4);
    }
    var_100h = var_128h + var_100h;
    var_fch = var_124h + 0.0;
    var_120h = CONCAT44(var_fch - var_130h._4_4_, var_100h - (float)var_130h);
    var_108h._0_4_ = (float)var_130h;
    var_108h._4_4_ = var_130h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar22);
    cVar7 = func_0x00018010b530(&var_108h, uVar8, &var_130h, 0);
    if (cVar7 == '\0') goto code_r0x00018013d93a;
    var_148h._0_4_ = 0;
    cVar7 = func_0x000180139d40(&var_130h, uVar8, &var_138h, &var_110h);
    puVar14 = (uint8_t *)0x180645ab1;
    uVar15 = 0x23;
    uVar16 = ~uVar8;
    do {
        if ((((char)uVar15 == '#') && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
            puVar14 = puVar14 + 2;
            uVar16 = ~uVar8;
        } else {
            uVar16 = uVar16 >> 8 ^ *(uint32_t *)(((uint64_t)uVar16 & 0xff ^ uVar15) * 4 + 0x180618620);
        }
        uVar3 = *puVar14;
        uVar15 = (uint64_t)uVar3;
        puVar14 = puVar14 + 1;
    } while (uVar3 != 0);
    uVar16 = ~uVar16;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(uint32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == uVar16)) {
        bVar18 = true;
    }
    if ((cVar7 == '\0') || (bVar18)) {
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
        if ((bVar18) || (iVar13 = 0x290, (char)var_138h != '\0')) goto code_r0x00018013d37b;
    } else {
        func_0x00018010d030(uVar16, 0);
        bVar18 = true;
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
code_r0x00018013d37b:
        iVar13 = 0x2a0;
    }
    pfVar2 = (float *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
    var_f8h = *pfVar2;
    var_f4h = pfVar2[1];
    var_f0h = pfVar2[2];
    var_ech._0_4_ = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_108h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    var_108h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    var_100h = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    var_fch = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar8 = func_0x0001800f5fa0(&var_108h);
    var_120h = CONCAT44(var_130h._4_4_, fVar22);
    var_140h._0_4_ = 0xa0;
    if (!NAN(fVar23)) {
        var_140h._0_4_ = 0xf0;
    }
    uVar9 = func_0x0001800f5fa0(&var_f8h);
    var_148h._0_4_ = *(undefined4 *)(iVar11 + 0xde4);
    func_0x000180126550(*(undefined8 *)(iVar5 + 800), &var_120h, &var_128h, uVar9);
    if ((fVar22 + fVar23) - *(float *)(iVar11 + 0xddc) <= var_128h) {
        iVar5 = *(int64_t *)(iVar5 + 800);
        fVar23 = *(float *)(*(int64_t *)(iVar5 + 0x38) + 0x20);
        fVar19 = fVar23 * 0.5;
        fVar23 = fVar23 * 0.4;
        fVar24 = *(float *)(iVar11 + 0xde0) + var_130h._4_4_ + fVar19;
        fVar19 = *(float *)(iVar11 + 0xde0) + fVar22 + fVar19;
        var_108h._0_4_ = fVar23 * 0.866 + fVar19;
        var_108h._4_4_ = fVar24 - fVar23 * 0.75;
        var_f8h = fVar19 - fVar23 * 0.866;
        var_120h._4_4_ = fVar23 * 0.75 + fVar24;
        var_120h._0_4_ = fVar23 * 0.0 + fVar19;
        var_f4h = var_108h._4_4_;
        if ((uVar8 & 0xff000000) != 0) {
            func_0x0001800f3b50(iVar5, &var_120h);
            func_0x0001800f3b50(iVar5, &var_f8h);
            func_0x0001800f3b50(iVar5, &var_108h);
            func_0x0001800f3bc0(iVar5, uVar8);
        }
    }
    func_0x0001800f7bc0(CONCAT44(var_130h._4_4_, (float)var_130h), CONCAT44(var_124h, var_128h), 
                        *(undefined4 *)(iVar11 + 0xde4));
    if (0.0 < fVar21) {
        func_0x0001800f6cb0(CONCAT44(var_130h._4_4_ + *(float *)(iVar11 + 0xde0), var_128h + *(float *)(iVar11 + 0xdf4))
                            , 0x180645ba8, pcVar17, 0);
    }
    iVar5 = *(int64_t *)0x180781f28;
    if (bVar18) {
        *(undefined4 *)(iVar11 + 0x2008) = uVar20;
        if ((*(int32_t *)(iVar5 + 0x2130) < *(int32_t *)(iVar5 + 0x2120)) &&
           (*(uint32_t *)((int64_t)*(int32_t *)(iVar5 + 0x2130) * 0x38 + *(int64_t *)(iVar5 + 0x2128)) == uVar16)) {
            uVar8 = *(uint32_t *)(iVar5 + 0x2008);
            fVar23 = var_128h - (float)var_130h;
            if ((uVar8 & 0x10) == 0) {
                if (((((uVar8 & 2) == 0) || (fVar22 = 0.0, *(float *)(iVar5 + 0x202c) <= 0.0)) &&
                    (fVar22 = fVar23, (uVar8 & 2) == 0)) || (uVar20 = 0x7f7fffff, *(float *)(iVar5 + 0x2030) <= 0.0)) {
                    uVar20 = func_0x00018013d050(0xffffffff);
                }
                *(uint32_t *)(iVar5 + 0x2008) = uVar8 | 0x10;
                *(float *)(iVar5 + 0x2050) = fVar22;
                *(undefined4 *)(iVar5 + 0x2054) = 0;
                *(undefined4 *)(iVar5 + 0x2058) = 0x7f7fffff;
                *(undefined4 *)(iVar5 + 0x205c) = uVar20;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
            } else {
                fVar22 = *(float *)(iVar5 + 0x2050);
                if (*(float *)(iVar5 + 0x2050) <= fVar23) {
                    fVar22 = fVar23;
                }
                *(float *)(iVar5 + 0x2050) = fVar22;
            }
            uVar15 = 0xffffffff;
            uVar8 = 0xffffffff;
            puVar14 = (uint8_t *)((int64_t)&var_ech + 5);
            while (var_ech._4_1_ != 0) {
                if (((var_ech._4_1_ == 0x23) && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
                    uVar15 = 0xffffffff;
                    puVar14 = puVar14 + 2;
                } else {
                    uVar15 = (uint64_t)
                             ((uint32_t)(uVar15 >> 8) ^
                             *(uint32_t *)((uVar15 & 0xff ^ (uint64_t)var_ech._4_1_) * 4 + 0x180618620));
                }
                uVar8 = (uint32_t)uVar15;
                var_ech._4_1_ = *puVar14;
                puVar14 = puVar14 + 1;
            }
            iVar11 = func_0x0001800f60f0(iVar5 + 0x15c0, ~uVar8);
            if ((iVar11 != 0) && (*(char *)(iVar11 + 0x10a) != '\0')) {
                auVar6._8_8_ = 0;
                auVar6._0_8_ = uStack_118;
                _var_120h = auVar6 << 0x40;
                iVar13 = iVar11;
                func_0x0001800ff150(iVar11, &var_108h, &var_120h);
                func_0x0001800ff2b0(&var_f8h, iVar13, &var_120h, 0xffffffff);
                func_0x0001800ff010(&var_108h, iVar11, &var_f8h);
                *(undefined4 *)(iVar11 + 0x124) = 3;
                func_0x00018010db00(&var_f8h, iVar11);
                iVar4 = *(int32_t *)(iVar11 + 0x124);
                iVar12 = -(uint32_t)(iVar4 != -1);
                _var_120h = *(undefined (*) [16])0x1806469d0;
                do {
                    iVar10 = iVar4;
                    if ((iVar12 == -1) ||
                       (iVar10 = *(int32_t *)((int64_t)&var_120h + (int64_t)iVar12 * 4), iVar10 != iVar4)) {
                        fVar23 = (float)var_130h;
                        fVar22 = var_124h;
                        if (iVar10 != 3) {
                            if (iVar10 == 1) {
code_r0x00018013d80f:
                                fVar22 = var_130h._4_4_ - var_108h._4_4_;
                            } else if (iVar10 == 0) {
                                fVar23 = var_128h - (float)var_108h;
                            } else {
                                fVar23 = 0.0;
                                fVar22 = 0.0;
                                if (iVar10 == 2) {
                                    fVar23 = var_128h - (float)var_108h;
                                    goto code_r0x00018013d80f;
                                }
                            }
                        }
                        if ((((var_f8h <= fVar23) && (var_f4h <= fVar22)) && ((float)var_108h + fVar23 <= var_f0h)) &&
                           (var_108h._4_4_ + fVar22 <= (float)var_ech)) {
                            *(int32_t *)(iVar11 + 0x124) = iVar10;
                            goto code_r0x00018013d880;
                        }
                    }
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 4);
                *(undefined4 *)(iVar11 + 0x124) = 0xffffffff;
                fVar23 = var_124h + var_108h._4_4_;
                if ((float)var_ech <= var_124h + var_108h._4_4_) {
                    fVar23 = (float)var_ech;
                }
                fVar21 = (float)var_108h + (float)var_130h;
                if (var_f0h <= (float)var_108h + (float)var_130h) {
                    fVar21 = var_f0h;
                }
                fVar22 = fVar23 - var_108h._4_4_;
                if (fVar23 - var_108h._4_4_ <= var_f4h) {
                    fVar22 = var_f4h;
                }
                fVar23 = fVar21 - (float)var_108h;
                if (fVar21 - (float)var_108h <= var_f8h) {
                    fVar23 = var_f8h;
                }
code_r0x00018013d880:
                iVar11 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 1;
                *(float *)(iVar11 + 0x201c) = fVar23;
                *(float *)(iVar11 + 0x2020) = fVar22;
                *(undefined8 *)(iVar11 + 0x2024) = 0;
                *(undefined4 *)(iVar11 + 0x200c) = 1;
                *(undefined *)(iVar11 + 0x204c) = 1;
            }
            func_0x0001800f68b0(2, *(undefined4 *)(iVar5 + 0xddc));
            cVar7 = func_0x0001801019f0((int64_t)&var_ech + 4, 0, 0x4000147);
            func_0x0001800f6a20(1);
            if (cVar7 == '\0') {
                func_0x00018010d5c0();
            } else {
                *(int32_t *)(iVar5 + 0x2790) = *(int32_t *)(iVar5 + 0x2790) + 1;
            }
        } else {
            *(undefined4 *)(iVar5 + 0x2008) = 0;
        }
    }
code_r0x00018013d93a:
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_18013d6e0
// Address: 0x18013d6e0
// Size: 510 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7fh
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h

void fcn.18013d0a0(void)
{
    char *pcVar1;
    float *pfVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    char cVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t *puVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    char *pcVar17;
    bool bVar18;
    float fVar19;
    undefined4 uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    float var_128h;
    float var_124h;
    int64_t var_120h;
    uint64_t uStack_118;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h;
    float var_fch;
    float var_f8h;
    float var_f4h;
    float var_f0h;
    int64_t var_ech;
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_40h;
    
    iVar11 = *(int64_t *)0x180781f28;
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    bVar18 = false;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar5 = *(int64_t *)(iVar11 + 0x15e0);
    uVar20 = *(undefined4 *)(iVar11 + 0x2008);
    *(undefined4 *)(iVar11 + 0x2008) = 0;
    if (*(char *)(iVar5 + 0x10e) != '\0') goto code_r0x00018013d93a;
    uVar8 = func_0x0001800f5a90(0x180645ba8, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    fVar23 = *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0x12f8);
    pcVar17 = "##v";
    while (*pcVar17 != '\0') {
        pcVar1 = pcVar17 + 1;
        if (((*pcVar17 == '#') && (*pcVar1 == '#')) || (pcVar17 = pcVar1, pcVar1 == (char *)0xffffffffffffffff)) break;
    }
    var_148h._0_4_ = 0xbf800000;
    func_0x0001800fe0a0(&var_120h, 0x180645ba8, pcVar17, 0);
    var_130h._0_4_ = *(float *)(iVar5 + 0x158);
    fVar22 = *(float *)(iVar11 + 0xde0);
    fVar21 = (float)var_120h;
    var_128h = (float)var_130h + fVar23;
    var_124h = fVar22 + fVar22 + var_120h._4_4_ + *(float *)(iVar5 + 0x15c);
    var_130h._4_4_ = *(float *)(iVar5 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_100h = 0.0;
    } else {
        var_100h = (float)var_120h + *(float *)(iVar11 + 0xdf4);
    }
    var_100h = var_128h + var_100h;
    var_fch = var_124h + 0.0;
    var_120h = CONCAT44(var_fch - var_130h._4_4_, var_100h - (float)var_130h);
    var_108h._0_4_ = (float)var_130h;
    var_108h._4_4_ = var_130h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar22);
    cVar7 = func_0x00018010b530(&var_108h, uVar8, &var_130h, 0);
    if (cVar7 == '\0') goto code_r0x00018013d93a;
    var_148h._0_4_ = 0;
    cVar7 = func_0x000180139d40(&var_130h, uVar8, &var_138h, &var_110h);
    puVar14 = (uint8_t *)0x180645ab1;
    uVar15 = 0x23;
    uVar16 = ~uVar8;
    do {
        if ((((char)uVar15 == '#') && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
            puVar14 = puVar14 + 2;
            uVar16 = ~uVar8;
        } else {
            uVar16 = uVar16 >> 8 ^ *(uint32_t *)(((uint64_t)uVar16 & 0xff ^ uVar15) * 4 + 0x180618620);
        }
        uVar3 = *puVar14;
        uVar15 = (uint64_t)uVar3;
        puVar14 = puVar14 + 1;
    } while (uVar3 != 0);
    uVar16 = ~uVar16;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(uint32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == uVar16)) {
        bVar18 = true;
    }
    if ((cVar7 == '\0') || (bVar18)) {
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
        if ((bVar18) || (iVar13 = 0x290, (char)var_138h != '\0')) goto code_r0x00018013d37b;
    } else {
        func_0x00018010d030(uVar16, 0);
        bVar18 = true;
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
code_r0x00018013d37b:
        iVar13 = 0x2a0;
    }
    pfVar2 = (float *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
    var_f8h = *pfVar2;
    var_f4h = pfVar2[1];
    var_f0h = pfVar2[2];
    var_ech._0_4_ = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_108h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    var_108h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    var_100h = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    var_fch = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar8 = func_0x0001800f5fa0(&var_108h);
    var_120h = CONCAT44(var_130h._4_4_, fVar22);
    var_140h._0_4_ = 0xa0;
    if (!NAN(fVar23)) {
        var_140h._0_4_ = 0xf0;
    }
    uVar9 = func_0x0001800f5fa0(&var_f8h);
    var_148h._0_4_ = *(undefined4 *)(iVar11 + 0xde4);
    func_0x000180126550(*(undefined8 *)(iVar5 + 800), &var_120h, &var_128h, uVar9);
    if ((fVar22 + fVar23) - *(float *)(iVar11 + 0xddc) <= var_128h) {
        iVar5 = *(int64_t *)(iVar5 + 800);
        fVar23 = *(float *)(*(int64_t *)(iVar5 + 0x38) + 0x20);
        fVar19 = fVar23 * 0.5;
        fVar23 = fVar23 * 0.4;
        fVar24 = *(float *)(iVar11 + 0xde0) + var_130h._4_4_ + fVar19;
        fVar19 = *(float *)(iVar11 + 0xde0) + fVar22 + fVar19;
        var_108h._0_4_ = fVar23 * 0.866 + fVar19;
        var_108h._4_4_ = fVar24 - fVar23 * 0.75;
        var_f8h = fVar19 - fVar23 * 0.866;
        var_120h._4_4_ = fVar23 * 0.75 + fVar24;
        var_120h._0_4_ = fVar23 * 0.0 + fVar19;
        var_f4h = var_108h._4_4_;
        if ((uVar8 & 0xff000000) != 0) {
            func_0x0001800f3b50(iVar5, &var_120h);
            func_0x0001800f3b50(iVar5, &var_f8h);
            func_0x0001800f3b50(iVar5, &var_108h);
            func_0x0001800f3bc0(iVar5, uVar8);
        }
    }
    func_0x0001800f7bc0(CONCAT44(var_130h._4_4_, (float)var_130h), CONCAT44(var_124h, var_128h), 
                        *(undefined4 *)(iVar11 + 0xde4));
    if (0.0 < fVar21) {
        func_0x0001800f6cb0(CONCAT44(var_130h._4_4_ + *(float *)(iVar11 + 0xde0), var_128h + *(float *)(iVar11 + 0xdf4))
                            , 0x180645ba8, pcVar17, 0);
    }
    iVar5 = *(int64_t *)0x180781f28;
    if (bVar18) {
        *(undefined4 *)(iVar11 + 0x2008) = uVar20;
        if ((*(int32_t *)(iVar5 + 0x2130) < *(int32_t *)(iVar5 + 0x2120)) &&
           (*(uint32_t *)((int64_t)*(int32_t *)(iVar5 + 0x2130) * 0x38 + *(int64_t *)(iVar5 + 0x2128)) == uVar16)) {
            uVar8 = *(uint32_t *)(iVar5 + 0x2008);
            fVar23 = var_128h - (float)var_130h;
            if ((uVar8 & 0x10) == 0) {
                if (((((uVar8 & 2) == 0) || (fVar22 = 0.0, *(float *)(iVar5 + 0x202c) <= 0.0)) &&
                    (fVar22 = fVar23, (uVar8 & 2) == 0)) || (uVar20 = 0x7f7fffff, *(float *)(iVar5 + 0x2030) <= 0.0)) {
                    uVar20 = func_0x00018013d050(0xffffffff);
                }
                *(uint32_t *)(iVar5 + 0x2008) = uVar8 | 0x10;
                *(float *)(iVar5 + 0x2050) = fVar22;
                *(undefined4 *)(iVar5 + 0x2054) = 0;
                *(undefined4 *)(iVar5 + 0x2058) = 0x7f7fffff;
                *(undefined4 *)(iVar5 + 0x205c) = uVar20;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
            } else {
                fVar22 = *(float *)(iVar5 + 0x2050);
                if (*(float *)(iVar5 + 0x2050) <= fVar23) {
                    fVar22 = fVar23;
                }
                *(float *)(iVar5 + 0x2050) = fVar22;
            }
            uVar15 = 0xffffffff;
            uVar8 = 0xffffffff;
            puVar14 = (uint8_t *)((int64_t)&var_ech + 5);
            while (var_ech._4_1_ != 0) {
                if (((var_ech._4_1_ == 0x23) && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
                    uVar15 = 0xffffffff;
                    puVar14 = puVar14 + 2;
                } else {
                    uVar15 = (uint64_t)
                             ((uint32_t)(uVar15 >> 8) ^
                             *(uint32_t *)((uVar15 & 0xff ^ (uint64_t)var_ech._4_1_) * 4 + 0x180618620));
                }
                uVar8 = (uint32_t)uVar15;
                var_ech._4_1_ = *puVar14;
                puVar14 = puVar14 + 1;
            }
            iVar11 = func_0x0001800f60f0(iVar5 + 0x15c0, ~uVar8);
            if ((iVar11 != 0) && (*(char *)(iVar11 + 0x10a) != '\0')) {
                auVar6._8_8_ = 0;
                auVar6._0_8_ = uStack_118;
                _var_120h = auVar6 << 0x40;
                iVar13 = iVar11;
                func_0x0001800ff150(iVar11, &var_108h, &var_120h);
                func_0x0001800ff2b0(&var_f8h, iVar13, &var_120h, 0xffffffff);
                func_0x0001800ff010(&var_108h, iVar11, &var_f8h);
                *(undefined4 *)(iVar11 + 0x124) = 3;
                func_0x00018010db00(&var_f8h, iVar11);
                iVar4 = *(int32_t *)(iVar11 + 0x124);
                iVar12 = -(uint32_t)(iVar4 != -1);
                _var_120h = *(undefined (*) [16])0x1806469d0;
                do {
                    iVar10 = iVar4;
                    if ((iVar12 == -1) ||
                       (iVar10 = *(int32_t *)((int64_t)&var_120h + (int64_t)iVar12 * 4), iVar10 != iVar4)) {
                        fVar23 = (float)var_130h;
                        fVar22 = var_124h;
                        if (iVar10 != 3) {
                            if (iVar10 == 1) {
code_r0x00018013d80f:
                                fVar22 = var_130h._4_4_ - var_108h._4_4_;
                            } else if (iVar10 == 0) {
                                fVar23 = var_128h - (float)var_108h;
                            } else {
                                fVar23 = 0.0;
                                fVar22 = 0.0;
                                if (iVar10 == 2) {
                                    fVar23 = var_128h - (float)var_108h;
                                    goto code_r0x00018013d80f;
                                }
                            }
                        }
                        if ((((var_f8h <= fVar23) && (var_f4h <= fVar22)) && ((float)var_108h + fVar23 <= var_f0h)) &&
                           (var_108h._4_4_ + fVar22 <= (float)var_ech)) {
                            *(int32_t *)(iVar11 + 0x124) = iVar10;
                            goto code_r0x00018013d880;
                        }
                    }
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 4);
                *(undefined4 *)(iVar11 + 0x124) = 0xffffffff;
                fVar23 = var_124h + var_108h._4_4_;
                if ((float)var_ech <= var_124h + var_108h._4_4_) {
                    fVar23 = (float)var_ech;
                }
                fVar21 = (float)var_108h + (float)var_130h;
                if (var_f0h <= (float)var_108h + (float)var_130h) {
                    fVar21 = var_f0h;
                }
                fVar22 = fVar23 - var_108h._4_4_;
                if (fVar23 - var_108h._4_4_ <= var_f4h) {
                    fVar22 = var_f4h;
                }
                fVar23 = fVar21 - (float)var_108h;
                if (fVar21 - (float)var_108h <= var_f8h) {
                    fVar23 = var_f8h;
                }
code_r0x00018013d880:
                iVar11 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 1;
                *(float *)(iVar11 + 0x201c) = fVar23;
                *(float *)(iVar11 + 0x2020) = fVar22;
                *(undefined8 *)(iVar11 + 0x2024) = 0;
                *(undefined4 *)(iVar11 + 0x200c) = 1;
                *(undefined *)(iVar11 + 0x204c) = 1;
            }
            func_0x0001800f68b0(2, *(undefined4 *)(iVar5 + 0xddc));
            cVar7 = func_0x0001801019f0((int64_t)&var_ech + 4, 0, 0x4000147);
            func_0x0001800f6a20(1);
            if (cVar7 == '\0') {
                func_0x00018010d5c0();
            } else {
                *(int32_t *)(iVar5 + 0x2790) = *(int32_t *)(iVar5 + 0x2790) + 1;
            }
        } else {
            *(undefined4 *)(iVar5 + 0x2008) = 0;
        }
    }
code_r0x00018013d93a:
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_18013d8de
// Address: 0x18013d8de
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7fh
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h

void fcn.18013d0a0(void)
{
    char *pcVar1;
    float *pfVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    char cVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t *puVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    char *pcVar17;
    bool bVar18;
    float fVar19;
    undefined4 uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    float var_128h;
    float var_124h;
    int64_t var_120h;
    uint64_t uStack_118;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h;
    float var_fch;
    float var_f8h;
    float var_f4h;
    float var_f0h;
    int64_t var_ech;
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_40h;
    
    iVar11 = *(int64_t *)0x180781f28;
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    bVar18 = false;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar5 = *(int64_t *)(iVar11 + 0x15e0);
    uVar20 = *(undefined4 *)(iVar11 + 0x2008);
    *(undefined4 *)(iVar11 + 0x2008) = 0;
    if (*(char *)(iVar5 + 0x10e) != '\0') goto code_r0x00018013d93a;
    uVar8 = func_0x0001800f5a90(0x180645ba8, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    fVar23 = *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0x12f8);
    pcVar17 = "##v";
    while (*pcVar17 != '\0') {
        pcVar1 = pcVar17 + 1;
        if (((*pcVar17 == '#') && (*pcVar1 == '#')) || (pcVar17 = pcVar1, pcVar1 == (char *)0xffffffffffffffff)) break;
    }
    var_148h._0_4_ = 0xbf800000;
    func_0x0001800fe0a0(&var_120h, 0x180645ba8, pcVar17, 0);
    var_130h._0_4_ = *(float *)(iVar5 + 0x158);
    fVar22 = *(float *)(iVar11 + 0xde0);
    fVar21 = (float)var_120h;
    var_128h = (float)var_130h + fVar23;
    var_124h = fVar22 + fVar22 + var_120h._4_4_ + *(float *)(iVar5 + 0x15c);
    var_130h._4_4_ = *(float *)(iVar5 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_100h = 0.0;
    } else {
        var_100h = (float)var_120h + *(float *)(iVar11 + 0xdf4);
    }
    var_100h = var_128h + var_100h;
    var_fch = var_124h + 0.0;
    var_120h = CONCAT44(var_fch - var_130h._4_4_, var_100h - (float)var_130h);
    var_108h._0_4_ = (float)var_130h;
    var_108h._4_4_ = var_130h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar22);
    cVar7 = func_0x00018010b530(&var_108h, uVar8, &var_130h, 0);
    if (cVar7 == '\0') goto code_r0x00018013d93a;
    var_148h._0_4_ = 0;
    cVar7 = func_0x000180139d40(&var_130h, uVar8, &var_138h, &var_110h);
    puVar14 = (uint8_t *)0x180645ab1;
    uVar15 = 0x23;
    uVar16 = ~uVar8;
    do {
        if ((((char)uVar15 == '#') && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
            puVar14 = puVar14 + 2;
            uVar16 = ~uVar8;
        } else {
            uVar16 = uVar16 >> 8 ^ *(uint32_t *)(((uint64_t)uVar16 & 0xff ^ uVar15) * 4 + 0x180618620);
        }
        uVar3 = *puVar14;
        uVar15 = (uint64_t)uVar3;
        puVar14 = puVar14 + 1;
    } while (uVar3 != 0);
    uVar16 = ~uVar16;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(uint32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == uVar16)) {
        bVar18 = true;
    }
    if ((cVar7 == '\0') || (bVar18)) {
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
        if ((bVar18) || (iVar13 = 0x290, (char)var_138h != '\0')) goto code_r0x00018013d37b;
    } else {
        func_0x00018010d030(uVar16, 0);
        bVar18 = true;
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
code_r0x00018013d37b:
        iVar13 = 0x2a0;
    }
    pfVar2 = (float *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
    var_f8h = *pfVar2;
    var_f4h = pfVar2[1];
    var_f0h = pfVar2[2];
    var_ech._0_4_ = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_108h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    var_108h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    var_100h = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    var_fch = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar8 = func_0x0001800f5fa0(&var_108h);
    var_120h = CONCAT44(var_130h._4_4_, fVar22);
    var_140h._0_4_ = 0xa0;
    if (!NAN(fVar23)) {
        var_140h._0_4_ = 0xf0;
    }
    uVar9 = func_0x0001800f5fa0(&var_f8h);
    var_148h._0_4_ = *(undefined4 *)(iVar11 + 0xde4);
    func_0x000180126550(*(undefined8 *)(iVar5 + 800), &var_120h, &var_128h, uVar9);
    if ((fVar22 + fVar23) - *(float *)(iVar11 + 0xddc) <= var_128h) {
        iVar5 = *(int64_t *)(iVar5 + 800);
        fVar23 = *(float *)(*(int64_t *)(iVar5 + 0x38) + 0x20);
        fVar19 = fVar23 * 0.5;
        fVar23 = fVar23 * 0.4;
        fVar24 = *(float *)(iVar11 + 0xde0) + var_130h._4_4_ + fVar19;
        fVar19 = *(float *)(iVar11 + 0xde0) + fVar22 + fVar19;
        var_108h._0_4_ = fVar23 * 0.866 + fVar19;
        var_108h._4_4_ = fVar24 - fVar23 * 0.75;
        var_f8h = fVar19 - fVar23 * 0.866;
        var_120h._4_4_ = fVar23 * 0.75 + fVar24;
        var_120h._0_4_ = fVar23 * 0.0 + fVar19;
        var_f4h = var_108h._4_4_;
        if ((uVar8 & 0xff000000) != 0) {
            func_0x0001800f3b50(iVar5, &var_120h);
            func_0x0001800f3b50(iVar5, &var_f8h);
            func_0x0001800f3b50(iVar5, &var_108h);
            func_0x0001800f3bc0(iVar5, uVar8);
        }
    }
    func_0x0001800f7bc0(CONCAT44(var_130h._4_4_, (float)var_130h), CONCAT44(var_124h, var_128h), 
                        *(undefined4 *)(iVar11 + 0xde4));
    if (0.0 < fVar21) {
        func_0x0001800f6cb0(CONCAT44(var_130h._4_4_ + *(float *)(iVar11 + 0xde0), var_128h + *(float *)(iVar11 + 0xdf4))
                            , 0x180645ba8, pcVar17, 0);
    }
    iVar5 = *(int64_t *)0x180781f28;
    if (bVar18) {
        *(undefined4 *)(iVar11 + 0x2008) = uVar20;
        if ((*(int32_t *)(iVar5 + 0x2130) < *(int32_t *)(iVar5 + 0x2120)) &&
           (*(uint32_t *)((int64_t)*(int32_t *)(iVar5 + 0x2130) * 0x38 + *(int64_t *)(iVar5 + 0x2128)) == uVar16)) {
            uVar8 = *(uint32_t *)(iVar5 + 0x2008);
            fVar23 = var_128h - (float)var_130h;
            if ((uVar8 & 0x10) == 0) {
                if (((((uVar8 & 2) == 0) || (fVar22 = 0.0, *(float *)(iVar5 + 0x202c) <= 0.0)) &&
                    (fVar22 = fVar23, (uVar8 & 2) == 0)) || (uVar20 = 0x7f7fffff, *(float *)(iVar5 + 0x2030) <= 0.0)) {
                    uVar20 = func_0x00018013d050(0xffffffff);
                }
                *(uint32_t *)(iVar5 + 0x2008) = uVar8 | 0x10;
                *(float *)(iVar5 + 0x2050) = fVar22;
                *(undefined4 *)(iVar5 + 0x2054) = 0;
                *(undefined4 *)(iVar5 + 0x2058) = 0x7f7fffff;
                *(undefined4 *)(iVar5 + 0x205c) = uVar20;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
            } else {
                fVar22 = *(float *)(iVar5 + 0x2050);
                if (*(float *)(iVar5 + 0x2050) <= fVar23) {
                    fVar22 = fVar23;
                }
                *(float *)(iVar5 + 0x2050) = fVar22;
            }
            uVar15 = 0xffffffff;
            uVar8 = 0xffffffff;
            puVar14 = (uint8_t *)((int64_t)&var_ech + 5);
            while (var_ech._4_1_ != 0) {
                if (((var_ech._4_1_ == 0x23) && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
                    uVar15 = 0xffffffff;
                    puVar14 = puVar14 + 2;
                } else {
                    uVar15 = (uint64_t)
                             ((uint32_t)(uVar15 >> 8) ^
                             *(uint32_t *)((uVar15 & 0xff ^ (uint64_t)var_ech._4_1_) * 4 + 0x180618620));
                }
                uVar8 = (uint32_t)uVar15;
                var_ech._4_1_ = *puVar14;
                puVar14 = puVar14 + 1;
            }
            iVar11 = func_0x0001800f60f0(iVar5 + 0x15c0, ~uVar8);
            if ((iVar11 != 0) && (*(char *)(iVar11 + 0x10a) != '\0')) {
                auVar6._8_8_ = 0;
                auVar6._0_8_ = uStack_118;
                _var_120h = auVar6 << 0x40;
                iVar13 = iVar11;
                func_0x0001800ff150(iVar11, &var_108h, &var_120h);
                func_0x0001800ff2b0(&var_f8h, iVar13, &var_120h, 0xffffffff);
                func_0x0001800ff010(&var_108h, iVar11, &var_f8h);
                *(undefined4 *)(iVar11 + 0x124) = 3;
                func_0x00018010db00(&var_f8h, iVar11);
                iVar4 = *(int32_t *)(iVar11 + 0x124);
                iVar12 = -(uint32_t)(iVar4 != -1);
                _var_120h = *(undefined (*) [16])0x1806469d0;
                do {
                    iVar10 = iVar4;
                    if ((iVar12 == -1) ||
                       (iVar10 = *(int32_t *)((int64_t)&var_120h + (int64_t)iVar12 * 4), iVar10 != iVar4)) {
                        fVar23 = (float)var_130h;
                        fVar22 = var_124h;
                        if (iVar10 != 3) {
                            if (iVar10 == 1) {
code_r0x00018013d80f:
                                fVar22 = var_130h._4_4_ - var_108h._4_4_;
                            } else if (iVar10 == 0) {
                                fVar23 = var_128h - (float)var_108h;
                            } else {
                                fVar23 = 0.0;
                                fVar22 = 0.0;
                                if (iVar10 == 2) {
                                    fVar23 = var_128h - (float)var_108h;
                                    goto code_r0x00018013d80f;
                                }
                            }
                        }
                        if ((((var_f8h <= fVar23) && (var_f4h <= fVar22)) && ((float)var_108h + fVar23 <= var_f0h)) &&
                           (var_108h._4_4_ + fVar22 <= (float)var_ech)) {
                            *(int32_t *)(iVar11 + 0x124) = iVar10;
                            goto code_r0x00018013d880;
                        }
                    }
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 4);
                *(undefined4 *)(iVar11 + 0x124) = 0xffffffff;
                fVar23 = var_124h + var_108h._4_4_;
                if ((float)var_ech <= var_124h + var_108h._4_4_) {
                    fVar23 = (float)var_ech;
                }
                fVar21 = (float)var_108h + (float)var_130h;
                if (var_f0h <= (float)var_108h + (float)var_130h) {
                    fVar21 = var_f0h;
                }
                fVar22 = fVar23 - var_108h._4_4_;
                if (fVar23 - var_108h._4_4_ <= var_f4h) {
                    fVar22 = var_f4h;
                }
                fVar23 = fVar21 - (float)var_108h;
                if (fVar21 - (float)var_108h <= var_f8h) {
                    fVar23 = var_f8h;
                }
code_r0x00018013d880:
                iVar11 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 1;
                *(float *)(iVar11 + 0x201c) = fVar23;
                *(float *)(iVar11 + 0x2020) = fVar22;
                *(undefined8 *)(iVar11 + 0x2024) = 0;
                *(undefined4 *)(iVar11 + 0x200c) = 1;
                *(undefined *)(iVar11 + 0x204c) = 1;
            }
            func_0x0001800f68b0(2, *(undefined4 *)(iVar5 + 0xddc));
            cVar7 = func_0x0001801019f0((int64_t)&var_ech + 4, 0, 0x4000147);
            func_0x0001800f6a20(1);
            if (cVar7 == '\0') {
                func_0x00018010d5c0();
            } else {
                *(int32_t *)(iVar5 + 0x2790) = *(int32_t *)(iVar5 + 0x2790) + 1;
            }
        } else {
            *(undefined4 *)(iVar5 + 0x2008) = 0;
        }
    }
code_r0x00018013d93a:
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_18013d919
// Address: 0x18013d919
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7fh
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h

void fcn.18013d0a0(void)
{
    char *pcVar1;
    float *pfVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    char cVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t *puVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    char *pcVar17;
    bool bVar18;
    float fVar19;
    undefined4 uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    float var_128h;
    float var_124h;
    int64_t var_120h;
    uint64_t uStack_118;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h;
    float var_fch;
    float var_f8h;
    float var_f4h;
    float var_f0h;
    int64_t var_ech;
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_40h;
    
    iVar11 = *(int64_t *)0x180781f28;
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    bVar18 = false;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar5 = *(int64_t *)(iVar11 + 0x15e0);
    uVar20 = *(undefined4 *)(iVar11 + 0x2008);
    *(undefined4 *)(iVar11 + 0x2008) = 0;
    if (*(char *)(iVar5 + 0x10e) != '\0') goto code_r0x00018013d93a;
    uVar8 = func_0x0001800f5a90(0x180645ba8, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    fVar23 = *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0x12f8);
    pcVar17 = "##v";
    while (*pcVar17 != '\0') {
        pcVar1 = pcVar17 + 1;
        if (((*pcVar17 == '#') && (*pcVar1 == '#')) || (pcVar17 = pcVar1, pcVar1 == (char *)0xffffffffffffffff)) break;
    }
    var_148h._0_4_ = 0xbf800000;
    func_0x0001800fe0a0(&var_120h, 0x180645ba8, pcVar17, 0);
    var_130h._0_4_ = *(float *)(iVar5 + 0x158);
    fVar22 = *(float *)(iVar11 + 0xde0);
    fVar21 = (float)var_120h;
    var_128h = (float)var_130h + fVar23;
    var_124h = fVar22 + fVar22 + var_120h._4_4_ + *(float *)(iVar5 + 0x15c);
    var_130h._4_4_ = *(float *)(iVar5 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_100h = 0.0;
    } else {
        var_100h = (float)var_120h + *(float *)(iVar11 + 0xdf4);
    }
    var_100h = var_128h + var_100h;
    var_fch = var_124h + 0.0;
    var_120h = CONCAT44(var_fch - var_130h._4_4_, var_100h - (float)var_130h);
    var_108h._0_4_ = (float)var_130h;
    var_108h._4_4_ = var_130h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar22);
    cVar7 = func_0x00018010b530(&var_108h, uVar8, &var_130h, 0);
    if (cVar7 == '\0') goto code_r0x00018013d93a;
    var_148h._0_4_ = 0;
    cVar7 = func_0x000180139d40(&var_130h, uVar8, &var_138h, &var_110h);
    puVar14 = (uint8_t *)0x180645ab1;
    uVar15 = 0x23;
    uVar16 = ~uVar8;
    do {
        if ((((char)uVar15 == '#') && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
            puVar14 = puVar14 + 2;
            uVar16 = ~uVar8;
        } else {
            uVar16 = uVar16 >> 8 ^ *(uint32_t *)(((uint64_t)uVar16 & 0xff ^ uVar15) * 4 + 0x180618620);
        }
        uVar3 = *puVar14;
        uVar15 = (uint64_t)uVar3;
        puVar14 = puVar14 + 1;
    } while (uVar3 != 0);
    uVar16 = ~uVar16;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(uint32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == uVar16)) {
        bVar18 = true;
    }
    if ((cVar7 == '\0') || (bVar18)) {
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
        if ((bVar18) || (iVar13 = 0x290, (char)var_138h != '\0')) goto code_r0x00018013d37b;
    } else {
        func_0x00018010d030(uVar16, 0);
        bVar18 = true;
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
code_r0x00018013d37b:
        iVar13 = 0x2a0;
    }
    pfVar2 = (float *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
    var_f8h = *pfVar2;
    var_f4h = pfVar2[1];
    var_f0h = pfVar2[2];
    var_ech._0_4_ = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_108h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    var_108h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    var_100h = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    var_fch = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar8 = func_0x0001800f5fa0(&var_108h);
    var_120h = CONCAT44(var_130h._4_4_, fVar22);
    var_140h._0_4_ = 0xa0;
    if (!NAN(fVar23)) {
        var_140h._0_4_ = 0xf0;
    }
    uVar9 = func_0x0001800f5fa0(&var_f8h);
    var_148h._0_4_ = *(undefined4 *)(iVar11 + 0xde4);
    func_0x000180126550(*(undefined8 *)(iVar5 + 800), &var_120h, &var_128h, uVar9);
    if ((fVar22 + fVar23) - *(float *)(iVar11 + 0xddc) <= var_128h) {
        iVar5 = *(int64_t *)(iVar5 + 800);
        fVar23 = *(float *)(*(int64_t *)(iVar5 + 0x38) + 0x20);
        fVar19 = fVar23 * 0.5;
        fVar23 = fVar23 * 0.4;
        fVar24 = *(float *)(iVar11 + 0xde0) + var_130h._4_4_ + fVar19;
        fVar19 = *(float *)(iVar11 + 0xde0) + fVar22 + fVar19;
        var_108h._0_4_ = fVar23 * 0.866 + fVar19;
        var_108h._4_4_ = fVar24 - fVar23 * 0.75;
        var_f8h = fVar19 - fVar23 * 0.866;
        var_120h._4_4_ = fVar23 * 0.75 + fVar24;
        var_120h._0_4_ = fVar23 * 0.0 + fVar19;
        var_f4h = var_108h._4_4_;
        if ((uVar8 & 0xff000000) != 0) {
            func_0x0001800f3b50(iVar5, &var_120h);
            func_0x0001800f3b50(iVar5, &var_f8h);
            func_0x0001800f3b50(iVar5, &var_108h);
            func_0x0001800f3bc0(iVar5, uVar8);
        }
    }
    func_0x0001800f7bc0(CONCAT44(var_130h._4_4_, (float)var_130h), CONCAT44(var_124h, var_128h), 
                        *(undefined4 *)(iVar11 + 0xde4));
    if (0.0 < fVar21) {
        func_0x0001800f6cb0(CONCAT44(var_130h._4_4_ + *(float *)(iVar11 + 0xde0), var_128h + *(float *)(iVar11 + 0xdf4))
                            , 0x180645ba8, pcVar17, 0);
    }
    iVar5 = *(int64_t *)0x180781f28;
    if (bVar18) {
        *(undefined4 *)(iVar11 + 0x2008) = uVar20;
        if ((*(int32_t *)(iVar5 + 0x2130) < *(int32_t *)(iVar5 + 0x2120)) &&
           (*(uint32_t *)((int64_t)*(int32_t *)(iVar5 + 0x2130) * 0x38 + *(int64_t *)(iVar5 + 0x2128)) == uVar16)) {
            uVar8 = *(uint32_t *)(iVar5 + 0x2008);
            fVar23 = var_128h - (float)var_130h;
            if ((uVar8 & 0x10) == 0) {
                if (((((uVar8 & 2) == 0) || (fVar22 = 0.0, *(float *)(iVar5 + 0x202c) <= 0.0)) &&
                    (fVar22 = fVar23, (uVar8 & 2) == 0)) || (uVar20 = 0x7f7fffff, *(float *)(iVar5 + 0x2030) <= 0.0)) {
                    uVar20 = func_0x00018013d050(0xffffffff);
                }
                *(uint32_t *)(iVar5 + 0x2008) = uVar8 | 0x10;
                *(float *)(iVar5 + 0x2050) = fVar22;
                *(undefined4 *)(iVar5 + 0x2054) = 0;
                *(undefined4 *)(iVar5 + 0x2058) = 0x7f7fffff;
                *(undefined4 *)(iVar5 + 0x205c) = uVar20;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
            } else {
                fVar22 = *(float *)(iVar5 + 0x2050);
                if (*(float *)(iVar5 + 0x2050) <= fVar23) {
                    fVar22 = fVar23;
                }
                *(float *)(iVar5 + 0x2050) = fVar22;
            }
            uVar15 = 0xffffffff;
            uVar8 = 0xffffffff;
            puVar14 = (uint8_t *)((int64_t)&var_ech + 5);
            while (var_ech._4_1_ != 0) {
                if (((var_ech._4_1_ == 0x23) && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
                    uVar15 = 0xffffffff;
                    puVar14 = puVar14 + 2;
                } else {
                    uVar15 = (uint64_t)
                             ((uint32_t)(uVar15 >> 8) ^
                             *(uint32_t *)((uVar15 & 0xff ^ (uint64_t)var_ech._4_1_) * 4 + 0x180618620));
                }
                uVar8 = (uint32_t)uVar15;
                var_ech._4_1_ = *puVar14;
                puVar14 = puVar14 + 1;
            }
            iVar11 = func_0x0001800f60f0(iVar5 + 0x15c0, ~uVar8);
            if ((iVar11 != 0) && (*(char *)(iVar11 + 0x10a) != '\0')) {
                auVar6._8_8_ = 0;
                auVar6._0_8_ = uStack_118;
                _var_120h = auVar6 << 0x40;
                iVar13 = iVar11;
                func_0x0001800ff150(iVar11, &var_108h, &var_120h);
                func_0x0001800ff2b0(&var_f8h, iVar13, &var_120h, 0xffffffff);
                func_0x0001800ff010(&var_108h, iVar11, &var_f8h);
                *(undefined4 *)(iVar11 + 0x124) = 3;
                func_0x00018010db00(&var_f8h, iVar11);
                iVar4 = *(int32_t *)(iVar11 + 0x124);
                iVar12 = -(uint32_t)(iVar4 != -1);
                _var_120h = *(undefined (*) [16])0x1806469d0;
                do {
                    iVar10 = iVar4;
                    if ((iVar12 == -1) ||
                       (iVar10 = *(int32_t *)((int64_t)&var_120h + (int64_t)iVar12 * 4), iVar10 != iVar4)) {
                        fVar23 = (float)var_130h;
                        fVar22 = var_124h;
                        if (iVar10 != 3) {
                            if (iVar10 == 1) {
code_r0x00018013d80f:
                                fVar22 = var_130h._4_4_ - var_108h._4_4_;
                            } else if (iVar10 == 0) {
                                fVar23 = var_128h - (float)var_108h;
                            } else {
                                fVar23 = 0.0;
                                fVar22 = 0.0;
                                if (iVar10 == 2) {
                                    fVar23 = var_128h - (float)var_108h;
                                    goto code_r0x00018013d80f;
                                }
                            }
                        }
                        if ((((var_f8h <= fVar23) && (var_f4h <= fVar22)) && ((float)var_108h + fVar23 <= var_f0h)) &&
                           (var_108h._4_4_ + fVar22 <= (float)var_ech)) {
                            *(int32_t *)(iVar11 + 0x124) = iVar10;
                            goto code_r0x00018013d880;
                        }
                    }
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 4);
                *(undefined4 *)(iVar11 + 0x124) = 0xffffffff;
                fVar23 = var_124h + var_108h._4_4_;
                if ((float)var_ech <= var_124h + var_108h._4_4_) {
                    fVar23 = (float)var_ech;
                }
                fVar21 = (float)var_108h + (float)var_130h;
                if (var_f0h <= (float)var_108h + (float)var_130h) {
                    fVar21 = var_f0h;
                }
                fVar22 = fVar23 - var_108h._4_4_;
                if (fVar23 - var_108h._4_4_ <= var_f4h) {
                    fVar22 = var_f4h;
                }
                fVar23 = fVar21 - (float)var_108h;
                if (fVar21 - (float)var_108h <= var_f8h) {
                    fVar23 = var_f8h;
                }
code_r0x00018013d880:
                iVar11 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 1;
                *(float *)(iVar11 + 0x201c) = fVar23;
                *(float *)(iVar11 + 0x2020) = fVar22;
                *(undefined8 *)(iVar11 + 0x2024) = 0;
                *(undefined4 *)(iVar11 + 0x200c) = 1;
                *(undefined *)(iVar11 + 0x204c) = 1;
            }
            func_0x0001800f68b0(2, *(undefined4 *)(iVar5 + 0xddc));
            cVar7 = func_0x0001801019f0((int64_t)&var_ech + 4, 0, 0x4000147);
            func_0x0001800f6a20(1);
            if (cVar7 == '\0') {
                func_0x00018010d5c0();
            } else {
                *(int32_t *)(iVar5 + 0x2790) = *(int32_t *)(iVar5 + 0x2790) + 1;
            }
        } else {
            *(undefined4 *)(iVar5 + 0x2008) = 0;
        }
    }
code_r0x00018013d93a:
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_18013d924
// Address: 0x18013d924
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_128h
// WARNING: [rz-ghidra] Detected overlap for variable var_124h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_7fh
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h

void fcn.18013d0a0(void)
{
    char *pcVar1;
    float *pfVar2;
    uint8_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined auVar6 [16];
    char cVar7;
    uint32_t uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    uint8_t *puVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    char *pcVar17;
    bool bVar18;
    float fVar19;
    undefined4 uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    undefined auStack_168 [32];
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    float var_128h;
    float var_124h;
    int64_t var_120h;
    uint64_t uStack_118;
    int64_t var_110h;
    int64_t var_108h;
    float var_100h;
    float var_fch;
    float var_f8h;
    float var_f4h;
    float var_f0h;
    int64_t var_ech;
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_40h;
    
    iVar11 = *(int64_t *)0x180781f28;
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    bVar18 = false;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar5 = *(int64_t *)(iVar11 + 0x15e0);
    uVar20 = *(undefined4 *)(iVar11 + 0x2008);
    *(undefined4 *)(iVar11 + 0x2008) = 0;
    if (*(char *)(iVar5 + 0x10e) != '\0') goto code_r0x00018013d93a;
    uVar8 = func_0x0001800f5a90(0x180645ba8, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(iVar5 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar5 + 0x148) * 4));
    fVar23 = *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0xde0) + *(float *)(iVar11 + 0x12f8);
    pcVar17 = "##v";
    while (*pcVar17 != '\0') {
        pcVar1 = pcVar17 + 1;
        if (((*pcVar17 == '#') && (*pcVar1 == '#')) || (pcVar17 = pcVar1, pcVar1 == (char *)0xffffffffffffffff)) break;
    }
    var_148h._0_4_ = 0xbf800000;
    func_0x0001800fe0a0(&var_120h, 0x180645ba8, pcVar17, 0);
    var_130h._0_4_ = *(float *)(iVar5 + 0x158);
    fVar22 = *(float *)(iVar11 + 0xde0);
    fVar21 = (float)var_120h;
    var_128h = (float)var_130h + fVar23;
    var_124h = fVar22 + fVar22 + var_120h._4_4_ + *(float *)(iVar5 + 0x15c);
    var_130h._4_4_ = *(float *)(iVar5 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_100h = 0.0;
    } else {
        var_100h = (float)var_120h + *(float *)(iVar11 + 0xdf4);
    }
    var_100h = var_128h + var_100h;
    var_fch = var_124h + 0.0;
    var_120h = CONCAT44(var_fch - var_130h._4_4_, var_100h - (float)var_130h);
    var_108h._0_4_ = (float)var_130h;
    var_108h._4_4_ = var_130h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar22);
    cVar7 = func_0x00018010b530(&var_108h, uVar8, &var_130h, 0);
    if (cVar7 == '\0') goto code_r0x00018013d93a;
    var_148h._0_4_ = 0;
    cVar7 = func_0x000180139d40(&var_130h, uVar8, &var_138h, &var_110h);
    puVar14 = (uint8_t *)0x180645ab1;
    uVar15 = 0x23;
    uVar16 = ~uVar8;
    do {
        if ((((char)uVar15 == '#') && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
            puVar14 = puVar14 + 2;
            uVar16 = ~uVar8;
        } else {
            uVar16 = uVar16 >> 8 ^ *(uint32_t *)(((uint64_t)uVar16 & 0xff ^ uVar15) * 4 + 0x180618620);
        }
        uVar3 = *puVar14;
        uVar15 = (uint64_t)uVar3;
        puVar14 = puVar14 + 1;
    } while (uVar3 != 0);
    uVar16 = ~uVar16;
    if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120)) &&
       (*(uint32_t *)
         ((int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2130) * 0x38 +
         *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) == uVar16)) {
        bVar18 = true;
    }
    if ((cVar7 == '\0') || (bVar18)) {
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
        if ((bVar18) || (iVar13 = 0x290, (char)var_138h != '\0')) goto code_r0x00018013d37b;
    } else {
        func_0x00018010d030(uVar16, 0);
        bVar18 = true;
        fVar22 = (float)var_130h;
        if ((float)var_130h <= var_128h - fVar23) {
            fVar22 = var_128h - fVar23;
        }
        func_0x0001800f7d00(&var_130h, uVar8, 0);
code_r0x00018013d37b:
        iVar13 = 0x2a0;
    }
    pfVar2 = (float *)(iVar13 + 0xd90 + *(int64_t *)0x180781f28);
    var_f8h = *pfVar2;
    var_f4h = pfVar2[1];
    var_f0h = pfVar2[2];
    var_ech._0_4_ = pfVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_108h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    var_108h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    var_100h = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    var_fch = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar8 = func_0x0001800f5fa0(&var_108h);
    var_120h = CONCAT44(var_130h._4_4_, fVar22);
    var_140h._0_4_ = 0xa0;
    if (!NAN(fVar23)) {
        var_140h._0_4_ = 0xf0;
    }
    uVar9 = func_0x0001800f5fa0(&var_f8h);
    var_148h._0_4_ = *(undefined4 *)(iVar11 + 0xde4);
    func_0x000180126550(*(undefined8 *)(iVar5 + 800), &var_120h, &var_128h, uVar9);
    if ((fVar22 + fVar23) - *(float *)(iVar11 + 0xddc) <= var_128h) {
        iVar5 = *(int64_t *)(iVar5 + 800);
        fVar23 = *(float *)(*(int64_t *)(iVar5 + 0x38) + 0x20);
        fVar19 = fVar23 * 0.5;
        fVar23 = fVar23 * 0.4;
        fVar24 = *(float *)(iVar11 + 0xde0) + var_130h._4_4_ + fVar19;
        fVar19 = *(float *)(iVar11 + 0xde0) + fVar22 + fVar19;
        var_108h._0_4_ = fVar23 * 0.866 + fVar19;
        var_108h._4_4_ = fVar24 - fVar23 * 0.75;
        var_f8h = fVar19 - fVar23 * 0.866;
        var_120h._4_4_ = fVar23 * 0.75 + fVar24;
        var_120h._0_4_ = fVar23 * 0.0 + fVar19;
        var_f4h = var_108h._4_4_;
        if ((uVar8 & 0xff000000) != 0) {
            func_0x0001800f3b50(iVar5, &var_120h);
            func_0x0001800f3b50(iVar5, &var_f8h);
            func_0x0001800f3b50(iVar5, &var_108h);
            func_0x0001800f3bc0(iVar5, uVar8);
        }
    }
    func_0x0001800f7bc0(CONCAT44(var_130h._4_4_, (float)var_130h), CONCAT44(var_124h, var_128h), 
                        *(undefined4 *)(iVar11 + 0xde4));
    if (0.0 < fVar21) {
        func_0x0001800f6cb0(CONCAT44(var_130h._4_4_ + *(float *)(iVar11 + 0xde0), var_128h + *(float *)(iVar11 + 0xdf4))
                            , 0x180645ba8, pcVar17, 0);
    }
    iVar5 = *(int64_t *)0x180781f28;
    if (bVar18) {
        *(undefined4 *)(iVar11 + 0x2008) = uVar20;
        if ((*(int32_t *)(iVar5 + 0x2130) < *(int32_t *)(iVar5 + 0x2120)) &&
           (*(uint32_t *)((int64_t)*(int32_t *)(iVar5 + 0x2130) * 0x38 + *(int64_t *)(iVar5 + 0x2128)) == uVar16)) {
            uVar8 = *(uint32_t *)(iVar5 + 0x2008);
            fVar23 = var_128h - (float)var_130h;
            if ((uVar8 & 0x10) == 0) {
                if (((((uVar8 & 2) == 0) || (fVar22 = 0.0, *(float *)(iVar5 + 0x202c) <= 0.0)) &&
                    (fVar22 = fVar23, (uVar8 & 2) == 0)) || (uVar20 = 0x7f7fffff, *(float *)(iVar5 + 0x2030) <= 0.0)) {
                    uVar20 = func_0x00018013d050(0xffffffff);
                }
                *(uint32_t *)(iVar5 + 0x2008) = uVar8 | 0x10;
                *(float *)(iVar5 + 0x2050) = fVar22;
                *(undefined4 *)(iVar5 + 0x2054) = 0;
                *(undefined4 *)(iVar5 + 0x2058) = 0x7f7fffff;
                *(undefined4 *)(iVar5 + 0x205c) = uVar20;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
            } else {
                fVar22 = *(float *)(iVar5 + 0x2050);
                if (*(float *)(iVar5 + 0x2050) <= fVar23) {
                    fVar22 = fVar23;
                }
                *(float *)(iVar5 + 0x2050) = fVar22;
            }
            uVar15 = 0xffffffff;
            uVar8 = 0xffffffff;
            puVar14 = (uint8_t *)((int64_t)&var_ech + 5);
            while (var_ech._4_1_ != 0) {
                if (((var_ech._4_1_ == 0x23) && (*puVar14 == 0x23)) && (puVar14[1] == 0x23)) {
                    uVar15 = 0xffffffff;
                    puVar14 = puVar14 + 2;
                } else {
                    uVar15 = (uint64_t)
                             ((uint32_t)(uVar15 >> 8) ^
                             *(uint32_t *)((uVar15 & 0xff ^ (uint64_t)var_ech._4_1_) * 4 + 0x180618620));
                }
                uVar8 = (uint32_t)uVar15;
                var_ech._4_1_ = *puVar14;
                puVar14 = puVar14 + 1;
            }
            iVar11 = func_0x0001800f60f0(iVar5 + 0x15c0, ~uVar8);
            if ((iVar11 != 0) && (*(char *)(iVar11 + 0x10a) != '\0')) {
                auVar6._8_8_ = 0;
                auVar6._0_8_ = uStack_118;
                _var_120h = auVar6 << 0x40;
                iVar13 = iVar11;
                func_0x0001800ff150(iVar11, &var_108h, &var_120h);
                func_0x0001800ff2b0(&var_f8h, iVar13, &var_120h, 0xffffffff);
                func_0x0001800ff010(&var_108h, iVar11, &var_f8h);
                *(undefined4 *)(iVar11 + 0x124) = 3;
                func_0x00018010db00(&var_f8h, iVar11);
                iVar4 = *(int32_t *)(iVar11 + 0x124);
                iVar12 = -(uint32_t)(iVar4 != -1);
                _var_120h = *(undefined (*) [16])0x1806469d0;
                do {
                    iVar10 = iVar4;
                    if ((iVar12 == -1) ||
                       (iVar10 = *(int32_t *)((int64_t)&var_120h + (int64_t)iVar12 * 4), iVar10 != iVar4)) {
                        fVar23 = (float)var_130h;
                        fVar22 = var_124h;
                        if (iVar10 != 3) {
                            if (iVar10 == 1) {
code_r0x00018013d80f:
                                fVar22 = var_130h._4_4_ - var_108h._4_4_;
                            } else if (iVar10 == 0) {
                                fVar23 = var_128h - (float)var_108h;
                            } else {
                                fVar23 = 0.0;
                                fVar22 = 0.0;
                                if (iVar10 == 2) {
                                    fVar23 = var_128h - (float)var_108h;
                                    goto code_r0x00018013d80f;
                                }
                            }
                        }
                        if ((((var_f8h <= fVar23) && (var_f4h <= fVar22)) && ((float)var_108h + fVar23 <= var_f0h)) &&
                           (var_108h._4_4_ + fVar22 <= (float)var_ech)) {
                            *(int32_t *)(iVar11 + 0x124) = iVar10;
                            goto code_r0x00018013d880;
                        }
                    }
                    iVar12 = iVar12 + 1;
                } while (iVar12 < 4);
                *(undefined4 *)(iVar11 + 0x124) = 0xffffffff;
                fVar23 = var_124h + var_108h._4_4_;
                if ((float)var_ech <= var_124h + var_108h._4_4_) {
                    fVar23 = (float)var_ech;
                }
                fVar21 = (float)var_108h + (float)var_130h;
                if (var_f0h <= (float)var_108h + (float)var_130h) {
                    fVar21 = var_f0h;
                }
                fVar22 = fVar23 - var_108h._4_4_;
                if (fVar23 - var_108h._4_4_ <= var_f4h) {
                    fVar22 = var_f4h;
                }
                fVar23 = fVar21 - (float)var_108h;
                if (fVar21 - (float)var_108h <= var_f8h) {
                    fVar23 = var_f8h;
                }
code_r0x00018013d880:
                iVar11 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 1;
                *(float *)(iVar11 + 0x201c) = fVar23;
                *(float *)(iVar11 + 0x2020) = fVar22;
                *(undefined8 *)(iVar11 + 0x2024) = 0;
                *(undefined4 *)(iVar11 + 0x200c) = 1;
                *(undefined *)(iVar11 + 0x204c) = 1;
            }
            func_0x0001800f68b0(2, *(undefined4 *)(iVar5 + 0xddc));
            cVar7 = func_0x0001801019f0((int64_t)&var_ech + 4, 0, 0x4000147);
            func_0x0001800f6a20(1);
            if (cVar7 == '\0') {
                func_0x00018010d5c0();
            } else {
                *(int32_t *)(iVar5 + 0x2790) = *(int32_t *)(iVar5 + 0x2790) + 1;
            }
        } else {
            *(undefined4 *)(iVar5 + 0x2008) = 0;
        }
    }
code_r0x00018013d93a:
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_168);
    return;
}

// ============================================================
// Function: FUN_18013da60
// Address: 0x18013da60
// Size: 457 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18013da60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint8_t uVar2;
    bool bVar3;
    uint8_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    uint8_t *puVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    uint64_t *puVar11;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_8h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar8 = (int32_t)arg2;
    puVar11 = (uint64_t *)((int64_t)iVar8 * 0x20 + 0x18061fc40);
    func_0x000180498030(&var_60h, arg3, *puVar11);
    for (; (cVar1 = *(char *)arg1, cVar1 == ' ' || (cVar1 == '\t')); arg1 = arg1 + 1) {
    }
    if (cVar1 == '\0') goto code_r0x00018013dc11;
    if (iVar8 - 8U < 2) {
        piVar10 = *(int64_t **)((int64_t)iVar8 * 0x20 + 0x18061fc58);
    } else {
        piVar10 = &var_58h;
        puVar7 = (uint8_t *)func_0x00018013f930(arg4);
        bVar3 = false;
        if ((uint64_t)arg4 < puVar7) {
            do {
                uVar2 = *(uint8_t *)arg4;
                arg4 = arg4 + 1;
                if (((bVar3) || (0x39 < uVar2)) || ((0x3ff480800000000U >> ((int64_t)(char)uVar2 & 0x3fU) & 1) == 0)) {
                    if (((uint8_t)(uVar2 + 0x9f) < 0x1a) || ((uint8_t)(uVar2 + 0xbf) < 0x1a)) {
                        uVar4 = 1;
                    } else {
                        uVar4 = 0;
                    }
                    bVar3 = (bool)(bVar3 | uVar4);
                    if ((0x3b < (uint8_t)((int32_t)(char)uVar2 - 0x24U)) ||
                       ((0x800000000000009U >> ((uint64_t)((int32_t)(char)uVar2 - 0x24U) & 0x3f) & 1) == 0)) {
                        *(uint8_t *)piVar10 = uVar2;
                        piVar10 = (int64_t *)((int64_t)piVar10 + 1);
                    }
                }
            } while ((uint64_t)arg4 < puVar7);
        }
        *(uint8_t *)piVar10 = 0;
        piVar10 = &var_58h;
    }
    var_68h._0_4_ = 0;
    piVar9 = &var_68h;
    if (3 < *puVar11) {
        piVar9 = (int64_t *)arg3;
    }
    iVar6 = func_0x0001800f3a40(arg1, piVar10, piVar9);
    if (iVar6 < 1) goto code_r0x00018013dc11;
    if (*puVar11 < 4) {
        uVar5 = (undefined)(int32_t)var_68h;
        if (iVar8 == 0) {
            if ((int32_t)var_68h < -0x80) {
                *(undefined *)arg3 = 0x80;
            } else {
                if (0x7f < (int32_t)var_68h) {
                    uVar5 = 0x7f;
                }
                *(undefined *)arg3 = uVar5;
            }
        } else if (iVar8 == 1) {
            if ((int32_t)var_68h < 0) {
                *(undefined *)arg3 = 0;
            } else {
                if (0xff < (int32_t)var_68h) {
                    uVar5 = 0xff;
                }
                *(undefined *)arg3 = uVar5;
            }
        } else {
            if (iVar8 == 2) {
                iVar8 = -0x8000;
                if ((-0x8001 < (int32_t)var_68h) && (iVar8 = (int32_t)var_68h, 0x7fff < (int32_t)var_68h)) {
                    iVar8 = 0x7fff;
                }
            } else {
                if (iVar8 != 3) goto code_r0x00018013dbf8;
                if ((int32_t)var_68h < 0) {
                    iVar8 = 0;
                } else {
                    iVar8 = (int32_t)var_68h;
                    if (0xffff < (int32_t)var_68h) {
                        iVar8 = 0xffff;
                    }
                }
            }
            *(int16_t *)arg3 = (int16_t)iVar8;
        }
    }
code_r0x00018013dbf8:
    func_0x000180497f30(&var_60h, arg3, *puVar11);
code_r0x00018013dc11:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18013dd70
// Address: 0x18013dd70
// Size: 5496 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_118h
// WARNING: Variable defined which should be unmapped: var_110h
// WARNING: Variable defined which should be unmapped: var_108h
// WARNING: Variable defined which should be unmapped: var_40h

undefined *
fcn.18013dd70(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             int64_t arg_40h, int64_t arg_48h)
{
    float *pfVar1;
    double dVar2;
    uint64_t uVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    int32_t iVar7;
    undefined *puVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int32_t iVar12;
    uint64_t uVar13;
    char *pcVar14;
    char *pcVar15;
    uint64_t uVar16;
    uint8_t uVar17;
    float extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    float extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    float extraout_XMM0_Da_03;
    float extraout_XMM0_Da_04;
    float fVar18;
    float extraout_XMM0_Da_05;
    double dVar19;
    float fVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    undefined4 uVar26;
    undefined4 uVar27;
    float fVar28;
    float fVar29;
    int64_t var_18h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_40h;
    
    iVar10 = *(int64_t *)0x180781f28;
    uVar13 = arg2 & 0xffffffff;
    if (9 < (uint32_t)arg3) {
        return &stack0x00000000;
    }
    iVar12 = (int32_t)arg2;
    // switch table (10 cases) at 0x18013f2c0
    switch((uint32_t)arg3) {
    case 0:
        var_18h._0_4_ = (float)(int32_t)*(char *)arg4;
        puVar8 = (undefined *)
                 func_0x00018014c6e0(arg1, uVar13, 4, &var_18h, (int32_t)*(char *)arg_28h, (int32_t)*(char *)arg_30h, 
                                     arg_38h);
        if ((char)puVar8 != '\0') {
            *(undefined *)arg4 = (undefined)var_18h;
        }
        break;
    case 1:
        var_18h._0_4_ = (float)(uint32_t)*(uint8_t *)arg4;
        puVar8 = (undefined *)
                 func_0x00018014ccf0(arg1, uVar13, 5, &var_18h, *(undefined *)arg_28h, *(undefined *)arg_30h, arg_38h);
        if ((char)puVar8 != '\0') {
            *(undefined *)arg4 = (undefined)var_18h;
        }
        break;
    case 2:
        var_18h._0_4_ = (float)(int32_t)*(int16_t *)arg4;
        puVar8 = (undefined *)
                 func_0x00018014c6e0(arg1, uVar13, 4, &var_18h, (int32_t)*(int16_t *)arg_28h, 
                                     (int32_t)*(int16_t *)arg_30h, arg_38h);
        if ((char)puVar8 != '\0') {
            *(undefined2 *)arg4 = (undefined2)var_18h;
        }
        break;
    case 3:
        var_18h._0_4_ = (float)(uint32_t)*(uint16_t *)arg4;
        puVar8 = (undefined *)
                 func_0x00018014ccf0(arg1, uVar13, 5, &var_18h, *(undefined2 *)arg_28h, *(undefined2 *)arg_30h, arg_38h)
        ;
        if ((char)puVar8 != '\0') {
            *(undefined2 *)arg4 = (undefined2)var_18h;
        }
        break;
    case 4:
        puVar8 = (undefined *)
                 func_0x00018014c6e0(arg1, arg2, 4, arg4, *(undefined4 *)arg_28h, *(undefined4 *)arg_30h, arg_38h);
        break;
    case 5:
        puVar8 = (undefined *)
                 func_0x00018014ccf0(arg1, arg2, 5, arg4, *(undefined4 *)arg_28h, *(undefined4 *)arg_30h, arg_38h);
        break;
    case 6:
        fVar18 = *(float *)(arg1 + 8);
        arg_30h = *(int64_t *)arg_30h;
        fVar29 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
        fVar28 = (fVar18 - *(float *)arg1) - 4.0;
        arg_28h = *(int64_t *)arg_28h;
        iVar9 = arg_30h - arg_28h;
        if (arg_30h <= arg_28h) {
            iVar9 = arg_28h - arg_30h;
        }
        fVar25 = (float)iVar9;
        fVar23 = fVar29;
        if ((0.0 <= fVar25) && (fVar23 = fVar28 / (fVar25 + 1.0), fVar23 <= fVar29)) {
            fVar23 = fVar29;
        }
        if (fVar28 <= fVar23) {
            fVar23 = fVar28;
        }
        fVar20 = fVar23 * 0.5;
        fVar29 = *(float *)arg1 + 2.0 + fVar20;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar12) {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) != 1) {
                if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
                    cVar5 = *(char *)(*(int64_t *)0x180781f28 + 0x1660);
                    pcVar14 = (char *)(*(int64_t *)0x180781f28 + 0x280c);
                    if (cVar5 == '\0') {
                        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
                    } else {
                        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                        *pcVar14 = '\0';
                        fVar23 = 0.0;
                    }
                    fVar21 = (float)func_0x00018010f200(0);
                    pcVar15 = pcVar14;
                    if (fVar21 != 0.0) {
                        iVar7 = *(int32_t *)(iVar10 + 0x2228);
                        uVar11 = 0x1000;
                        if (iVar7 == 3) {
                            uVar11 = 0x282;
                        }
                        cVar6 = func_0x000180107d30(uVar11, 0);
                        uVar11 = 0x2000;
                        if (iVar7 == 3) {
                            uVar11 = 0x283;
                        }
                        pcVar15 = pcVar14;
                        cVar4 = func_0x000180107d30(uVar11, 0);
                        if ((((-100.0 <= fVar25) && (fVar25 <= 100.0)) && (fVar25 != 0.0)) || (cVar6 != '\0')) {
                            if (0.0 <= extraout_XMM0_Da) {
                                fVar21 = 1.0 / fVar25;
                            } else {
                                fVar21 = -1.0 / fVar25;
                            }
                        } else {
                            fVar21 = extraout_XMM0_Da / 100.0;
                        }
                        if (cVar4 != '\0') {
                            fVar21 = fVar21 * 10.0;
                        }
                        pcVar14 = (char *)(iVar10 + 0x280c);
                        fVar23 = fVar23 + fVar21;
                        *pcVar14 = '\x01';
                        *(float *)(iVar10 + 0x2808) = fVar23;
                    }
                    if ((*(int32_t *)(iVar10 + 0x21f4) == iVar12) && (pcVar15 = pcVar14, cVar5 == '\0'))
                    goto code_r0x00018013e282;
                    if (*pcVar15 != '\0') {
                        fVar25 = (float)func_0x00018014df80(fVar21, *(undefined8 *)arg4, arg_28h, arg_30h, 0, 0);
                        if (((fVar25 < 1.0) || (fVar23 <= 0.0)) && ((0.0 < fVar25 || (0.0 <= fVar23)))) {
                            fVar21 = fVar25 + fVar23;
                            if (0.0 <= fVar21) {
                                fVar24 = 1.0;
                                if (fVar21 <= 1.0) {
                                    fVar24 = fVar21;
                                }
                            } else {
                                fVar24 = 0.0;
                            }
                            uVar11 = func_0x00018014e2f0(6, fVar24, arg_28h, arg_30h, 0, 0);
                            fVar21 = (float)func_0x00018014df80(extraout_XMM0_Da_00, uVar11, arg_28h, arg_30h, 0, 0);
                            fVar21 = fVar21 - fVar25;
                            if (fVar23 <= 0.0) {
                                if (fVar21 <= fVar23) {
                                    fVar21 = fVar23;
                                }
                            } else if (fVar23 <= fVar21) {
                                fVar21 = fVar23;
                            }
                            *(float *)(iVar10 + 0x2808) = fVar23 - fVar21;
                            *pcVar15 = '\0';
                            goto code_r0x00018013e36d;
                        }
                        *(undefined4 *)(iVar10 + 0x2808) = 0;
                        *pcVar15 = '\0';
                    }
                }
                goto code_r0x00018013e28b;
            }
            if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
code_r0x00018013e282:
                func_0x0001800f9f30(0, 0);
                goto code_r0x00018013e28b;
            }
            pfVar1 = (float *)(*(int64_t *)0x180781f28 + 0x118);
            if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2804) = 0;
            }
            fVar24 = 0.0;
            if (((0.0 < fVar28 - fVar23) &&
                (fVar23 = ((*pfVar1 - *(float *)(iVar10 + 0x2804)) - fVar29) / (fVar28 - fVar23), 0.0 <= fVar23)) &&
               (fVar24 = 1.0, fVar23 <= 1.0)) {
                fVar24 = fVar23;
            }
code_r0x00018013e36d:
            if (((*(uint32_t *)(iVar10 + 0x1fbc) & 0x800) != 0) ||
               (iVar10 = func_0x00018014e2f0(6, fVar24, arg_28h, arg_30h, 0, 0), *(int64_t *)arg4 == iVar10))
            goto code_r0x00018013e28b;
            *(int64_t *)arg4 = iVar10;
            puVar8 = (undefined *)0x1;
        } else {
code_r0x00018013e28b:
            puVar8 = (undefined *)0x0;
        }
        if (1.0 <= fVar28) {
            fVar25 = (float)func_0x00018014df80();
            fVar28 = *(float *)(arg1 + 0xc) - 2.0;
            fVar23 = *(float *)(arg1 + 4) + 2.0;
            fVar29 = fVar25 * (((fVar18 - 2.0) - fVar20) - fVar29) + fVar29;
            fVar18 = fVar29 - fVar20;
            fVar29 = fVar29 + fVar20;
        } else {
            fVar18 = *(float *)arg1;
            fVar28 = *(float *)(arg1 + 4);
            fVar23 = fVar28;
            fVar29 = fVar18;
        }
        *(float *)arg_48h = fVar18;
        *(float *)(arg_48h + 4) = fVar23;
        *(float *)(arg_48h + 8) = fVar29;
        *(float *)(arg_48h + 0xc) = fVar28;
        break;
    case 7:
        fVar18 = *(float *)(arg1 + 8);
        uVar13 = *(uint64_t *)arg_30h;
        fVar29 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
        fVar28 = (fVar18 - *(float *)arg1) - 4.0;
        uVar3 = *(uint64_t *)arg_28h;
        uVar16 = uVar13 - uVar3;
        if (uVar13 <= uVar3) {
            uVar16 = uVar3 - uVar13;
        }
        if ((int64_t)uVar16 < 0) {
            fVar23 = (float)(uVar16 >> 1 | (uint64_t)((uint32_t)uVar16 & 1));
            fVar23 = fVar23 + fVar23;
        } else {
            fVar23 = (float)uVar16;
        }
        fVar25 = fVar29;
        if (0.0 <= fVar23) {
            fVar23 = fVar23 + 1.0;
            fVar25 = fVar28 / fVar23;
            if (fVar28 / fVar23 <= fVar29) {
                fVar25 = fVar29;
            }
        }
        if (fVar28 <= fVar25) {
            fVar25 = fVar28;
        }
        uVar17 = 0;
        fVar20 = fVar25 * 0.5;
        fVar29 = *(float *)arg1 + 2.0 + fVar20;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar12) {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
                if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
                    fVar23 = (float)func_0x0001800f9f30(0, 0);
                } else {
                    fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                    if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2804) = 0;
                    }
                    fVar24 = 0.0;
                    if (((0.0 < fVar28 - fVar25) &&
                        (fVar23 = ((fVar23 - *(float *)(iVar10 + 0x2804)) - fVar29) / (fVar28 - fVar25), 0.0 <= fVar23))
                       && (fVar24 = 1.0, fVar23 <= 1.0)) {
                        fVar24 = fVar23;
                    }
code_r0x00018013e7ad:
                    uVar17 = 0;
                    if (((*(uint32_t *)(iVar10 + 0x1fbc) & 0x800) == 0) &&
                       (iVar10 = func_0x00018014e9f0(7, fVar24, uVar3, uVar13, 0, 0), fVar23 = extraout_XMM0_Da_03,
                       *(int64_t *)arg4 != iVar10)) {
                        *(int64_t *)arg4 = iVar10;
                        uVar17 = 1;
                    }
                }
            } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
                cVar5 = *(char *)(*(int64_t *)0x180781f28 + 0x1660);
                if (cVar5 == '\0') {
                    fVar25 = *(float *)(*(int64_t *)0x180781f28 + 0x2808);
                } else {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                    *(undefined *)(iVar10 + 0x280c) = 0;
                    fVar25 = 0.0;
                }
                fVar23 = (float)func_0x00018010f200(0);
                if (fVar23 != 0.0) {
                    iVar7 = *(int32_t *)(iVar10 + 0x2228);
                    uVar11 = 0x1000;
                    if (iVar7 == 3) {
                        uVar11 = 0x282;
                    }
                    cVar6 = func_0x000180107d30(uVar11, 0);
                    uVar11 = 0x2000;
                    if (iVar7 == 3) {
                        uVar11 = 0x283;
                    }
                    cVar4 = func_0x000180107d30(uVar11, 0);
                    if ((int64_t)uVar16 < 0) {
                        fVar23 = (float)(uVar16 >> 1 | (uint64_t)((uint32_t)uVar16 & 1));
                        fVar23 = fVar23 + fVar23;
                    } else {
                        fVar23 = (float)uVar16;
                    }
                    if ((((-100.0 <= fVar23) && (fVar23 <= 100.0)) && (fVar23 != 0.0)) || (cVar6 != '\0')) {
                        if (0.0 <= extraout_XMM0_Da_01) {
                            fVar23 = 1.0 / fVar23;
                        } else {
                            fVar23 = -1.0 / fVar23;
                        }
                    } else {
                        fVar23 = extraout_XMM0_Da_01 / 100.0;
                    }
                    if (cVar4 != '\0') {
                        fVar23 = fVar23 * 10.0;
                    }
                    *(undefined *)(iVar10 + 0x280c) = 1;
                    fVar25 = fVar25 + fVar23;
                    *(float *)(iVar10 + 0x2808) = fVar25;
                }
                uVar17 = 0;
                if ((*(int32_t *)(iVar10 + 0x21f4) == iVar12) && (cVar5 == '\0')) {
                    fVar23 = (float)func_0x0001800f9f30(0, 0);
                } else if (*(char *)(iVar10 + 0x280c) != '\0') {
                    fVar23 = (float)func_0x00018014e5c0(fVar23, *(undefined8 *)arg4, uVar3, uVar13, 0, 0);
                    if (((fVar23 < 1.0) || (fVar25 <= 0.0)) && ((0.0 < fVar23 || (0.0 <= fVar25)))) {
                        fVar21 = fVar25 + fVar23;
                        if (0.0 <= fVar21) {
                            fVar24 = 1.0;
                            if (fVar21 <= 1.0) {
                                fVar24 = fVar21;
                            }
                        } else {
                            fVar24 = 0.0;
                        }
                        uVar11 = func_0x00018014e9f0(7, fVar24, uVar3, uVar13, 0, 0);
                        fVar21 = (float)func_0x00018014e5c0(extraout_XMM0_Da_02, uVar11, uVar3, uVar13, 0, 0);
                        *(undefined *)(iVar10 + 0x280c) = 0;
                        fVar23 = fVar21 - fVar23;
                        if (fVar25 <= 0.0) {
                            if (fVar23 <= fVar25) {
                                fVar23 = fVar25;
                            }
                        } else if (fVar25 <= fVar23) {
                            fVar23 = fVar25;
                        }
                        *(float *)(iVar10 + 0x2808) = fVar25 - fVar23;
                        goto code_r0x00018013e7ad;
                    }
                    *(undefined4 *)(iVar10 + 0x2808) = 0;
                    *(undefined *)(iVar10 + 0x280c) = 0;
                }
            }
        }
        if (1.0 <= fVar28) {
            fVar25 = (float)func_0x00018014e5c0(fVar23, *(undefined8 *)arg4, uVar3, uVar13, 0, 0);
            fVar23 = *(float *)(arg1 + 4) + 2.0;
            fVar28 = *(float *)(arg1 + 0xc) - 2.0;
            fVar29 = fVar25 * (((fVar18 - 2.0) - fVar20) - fVar29) + fVar29;
            fVar18 = fVar20 + fVar29;
            fVar29 = fVar29 - fVar20;
        } else {
            fVar29 = *(float *)arg1;
            fVar28 = *(float *)(arg1 + 4);
            fVar23 = fVar28;
            fVar18 = fVar29;
        }
        *(float *)arg_48h = fVar29;
        *(float *)(arg_48h + 4) = fVar23;
        puVar8 = (undefined *)(uint64_t)uVar17;
        *(float *)(arg_48h + 8) = fVar18;
        *(float *)(arg_48h + 0xc) = fVar28;
        break;
    case 8:
        fVar18 = *(float *)arg_30h;
        fVar29 = *(float *)arg_28h;
        if (fVar18 <= fVar29) {
            fVar28 = fVar29 - fVar18;
        } else {
            fVar28 = fVar18 - fVar29;
        }
        uVar17 = 0;
        fVar25 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
        fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
        if (fVar25 <= *(float *)(*(int64_t *)0x180781f28 + 0xe20)) {
            fVar23 = fVar25;
        }
        fVar24 = fVar23 * 0.5;
        fVar21 = (*(float *)(arg1 + 8) - 2.0) - fVar24;
        fVar20 = *(float *)arg1 + 2.0 + fVar24;
        var_18h._0_4_ = fVar21;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar12) {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
                if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
                    func_0x0001800f9f30(0, 0);
                } else {
                    fVar28 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                    if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                        fVar21 = (float)func_0x00018014edf0(0x180000000, *(undefined4 *)arg4, fVar29, fVar18, 0, 0);
                        fVar21 = fVar21 * ((float)var_18h - fVar20) + fVar20;
                        if ((fVar28 < (fVar21 - fVar24) - 1.0) || (fVar24 + fVar21 + 1.0 < fVar28)) {
                            fVar21 = 0.0;
                        } else {
                            fVar21 = fVar28 - fVar21;
                        }
                        *(float *)(iVar10 + 0x2804) = fVar21;
                    }
                    fVar22 = 0.0;
                    if (((0.0 < fVar25 - fVar23) &&
                        (fVar28 = ((fVar28 - *(float *)(iVar10 + 0x2804)) - fVar20) / (fVar25 - fVar23), 0.0 <= fVar28))
                       && (fVar22 = 1.0, fVar28 <= 1.0)) {
                        fVar22 = fVar28;
                    }
code_r0x00018013ea55:
                    fVar21 = (float)var_18h;
                    if ((*(uint32_t *)(iVar10 + 0x1fbc) & 0x800) == 0) {
                        func_0x00018014f0d0(8, fVar22, fVar29, fVar18, 0, 0);
                        fVar18 = (float)func_0x00018014f340(arg_38h);
                        fVar21 = (float)var_18h;
                        if (*(float *)arg4 != fVar18) {
                            *(float *)arg4 = fVar18;
                            uVar17 = 1;
                        }
                    }
                }
            } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                    *(undefined *)(iVar10 + 0x280c) = 0;
                }
                fVar24 = (float)func_0x00018010f200(0);
                if (fVar24 != 0.0) {
                    iVar7 = *(int32_t *)(iVar10 + 0x2228);
                    uVar11 = 0x1000;
                    if (iVar7 == 3) {
                        uVar11 = 0x282;
                    }
                    cVar5 = func_0x000180107d30(uVar11, 0);
                    uVar11 = 0x2000;
                    if (iVar7 == 3) {
                        uVar11 = 0x283;
                    }
                    cVar6 = func_0x000180107d30(uVar11, 0);
                    iVar7 = func_0x00018013f990(arg_38h);
                    if (iVar7 < 1) {
                        if ((((-100.0 <= fVar28) && (fVar28 <= 100.0)) && (fVar28 != 0.0)) || (cVar5 != '\0')) {
                            if (0.0 <= extraout_XMM0_Da_04) {
                                fVar24 = 1.0 / fVar28;
                            } else {
                                fVar24 = -1.0 / fVar28;
                            }
                        } else {
                            fVar24 = extraout_XMM0_Da_04 / 100.0;
                        }
                    } else {
                        fVar24 = extraout_XMM0_Da_04 / 100.0;
                        if (cVar5 != '\0') {
                            fVar24 = fVar24 / 10.0;
                        }
                    }
                    if (cVar6 != '\0') {
                        fVar24 = fVar24 * 10.0;
                    }
                    fVar24 = fVar24 + *(float *)(iVar10 + 0x2808);
                    *(undefined *)(iVar10 + 0x280c) = 1;
                    *(float *)(iVar10 + 0x2808) = fVar24;
                }
                if ((*(int32_t *)(iVar10 + 0x21f4) == iVar12) && (*(char *)(iVar10 + 0x1660) == '\0')) {
                    func_0x0001800f9f30(0, 0);
                } else if (*(char *)(iVar10 + 0x280c) != '\0') {
                    fVar28 = *(float *)(iVar10 + 0x2808);
                    fVar24 = (float)func_0x00018014edf0(fVar24, *(undefined4 *)arg4, fVar29, fVar18, 0, 0);
                    if (((fVar24 < 1.0) || (fVar28 <= 0.0)) && ((0.0 < fVar24 || (0.0 <= fVar28)))) {
                        fVar21 = fVar24 + fVar28;
                        if (0.0 <= fVar21) {
                            fVar22 = 1.0;
                            if (fVar21 <= 1.0) {
                                fVar22 = fVar21;
                            }
                        } else {
                            fVar22 = 0.0;
                        }
                        func_0x00018014f0d0(8, fVar22, fVar29, fVar18, 0, 0);
                        uVar11 = func_0x00018014f340(arg_38h);
                        fVar21 = (float)func_0x00018014edf0((int32_t)uVar11, uVar11, fVar29, fVar18, 0, 0);
                        *(undefined *)(iVar10 + 0x280c) = 0;
                        fVar21 = fVar21 - fVar24;
                        if (fVar28 <= 0.0) {
                            if (fVar21 <= fVar28) {
                                fVar21 = fVar28;
                            }
                            *(float *)(iVar10 + 0x2808) = *(float *)(iVar10 + 0x2808) - fVar21;
                        } else {
                            if (fVar28 <= fVar21) {
                                fVar21 = fVar28;
                            }
                            *(float *)(iVar10 + 0x2808) = *(float *)(iVar10 + 0x2808) - fVar21;
                        }
                        goto code_r0x00018013ea55;
                    }
                    *(undefined4 *)(iVar10 + 0x2808) = 0;
                    *(undefined *)(iVar10 + 0x280c) = 0;
                }
            }
        }
        if (1.0 <= fVar25) {
            fVar18 = (float)func_0x00018014edf0();
            fVar28 = *(float *)(arg1 + 0xc) - 2.0;
            fVar29 = *(float *)(arg1 + 4) + 2.0;
            fVar20 = fVar18 * (fVar21 - fVar20) + fVar20;
            fVar18 = fVar23 * 0.5 + fVar20;
            fVar20 = fVar20 - fVar23 * 0.5;
        } else {
            fVar18 = *(float *)arg1;
            fVar29 = *(float *)(arg1 + 4);
            fVar20 = fVar18;
            fVar28 = fVar29;
        }
        *(float *)arg_48h = fVar20;
        *(float *)(arg_48h + 4) = fVar29;
        puVar8 = (undefined *)(uint64_t)uVar17;
        *(float *)(arg_48h + 8) = fVar18;
        *(float *)(arg_48h + 0xc) = fVar28;
        break;
    case 9:
        dVar19 = *(double *)arg_30h;
        uVar26 = SUB84(dVar19, 0);
        dVar2 = *(double *)arg_28h;
        uVar27 = SUB84(dVar2, 0);
        if (dVar19 <= dVar2) {
            dVar19 = dVar2 - dVar19;
        } else {
            dVar19 = dVar19 - dVar2;
        }
        uVar17 = 0;
        fVar29 = (*(float *)(arg1 + 8) - *(float *)arg1) - 4.0;
        fVar18 = *(float *)(*(int64_t *)0x180781f28 + 0xe20);
        if (fVar29 <= *(float *)(*(int64_t *)0x180781f28 + 0xe20)) {
            fVar18 = fVar29;
        }
        fVar25 = fVar18 * 0.5;
        fVar23 = (*(float *)(arg1 + 8) - 2.0) - fVar25;
        fVar28 = *(float *)arg1 + 2.0 + fVar25;
        var_18h._0_4_ = fVar23;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar12) {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) == 1) {
                if (*(char *)(*(int64_t *)0x180781f28 + 0x120) == '\0') {
                    func_0x0001800f9f30(0, 0);
                } else {
                    fVar23 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
                    if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                        fVar20 = (float)func_0x00018014f3d0(0x180000000, *(undefined8 *)arg4, uVar27, uVar26, 0, 0);
                        fVar20 = fVar20 * ((float)var_18h - fVar28) + fVar28;
                        if ((fVar23 < (fVar20 - fVar25) - 1.0) || (fVar20 + fVar25 + 1.0 < fVar23)) {
                            fVar20 = 0.0;
                        } else {
                            fVar20 = fVar23 - fVar20;
                        }
                        *(float *)(iVar10 + 0x2804) = fVar20;
                    }
                    fVar21 = 0.0;
                    if (((0.0 < fVar29 - fVar18) &&
                        (fVar23 = ((fVar23 - *(float *)(iVar10 + 0x2804)) - fVar28) / (fVar29 - fVar18), 0.0 <= fVar23))
                       && (fVar21 = 1.0, fVar23 <= 1.0)) {
                        fVar21 = fVar23;
                    }
code_r0x00018013ef31:
                    fVar23 = (float)var_18h;
                    if ((*(uint32_t *)(iVar10 + 0x1fbc) & 0x800) == 0) {
                        func_0x00018014f720(9, fVar21, uVar27, uVar26, 0, 0);
                        dVar19 = (double)func_0x00018014fa00(arg_38h);
                        fVar23 = (float)var_18h;
                        if (*(double *)arg4 != dVar19) {
                            *(double *)arg4 = dVar19;
                            uVar17 = 1;
                        }
                    }
                }
            } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1674) - 2U < 2) {
                if (*(char *)(*(int64_t *)0x180781f28 + 0x1660) != '\0') {
                    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2808) = 0;
                    *(undefined *)(iVar10 + 0x280c) = 0;
                }
                fVar25 = (float)func_0x00018010f200(0);
                if (fVar25 != 0.0) {
                    iVar7 = *(int32_t *)(iVar10 + 0x2228);
                    uVar11 = 0x1000;
                    if (iVar7 == 3) {
                        uVar11 = 0x282;
                    }
                    cVar5 = func_0x000180107d30(uVar11, 0);
                    uVar11 = 0x2000;
                    if (iVar7 == 3) {
                        uVar11 = 0x283;
                    }
                    cVar6 = func_0x000180107d30(uVar11, 0);
                    iVar7 = func_0x00018013f990(arg_38h);
                    if (iVar7 < 1) {
                        fVar25 = (float)dVar19;
                        if ((((-100.0 <= fVar25) && (fVar25 <= 100.0)) && (fVar25 != 0.0)) || (cVar5 != '\0')) {
                            if (0.0 <= extraout_XMM0_Da_05) {
                                fVar25 = 1.0 / fVar25;
                            } else {
                                fVar25 = -1.0 / fVar25;
                            }
                        } else {
                            fVar25 = extraout_XMM0_Da_05 / 100.0;
                        }
                    } else {
                        fVar25 = extraout_XMM0_Da_05 / 100.0;
                        if (cVar5 != '\0') {
                            fVar25 = fVar25 / 10.0;
                        }
                    }
                    if (cVar6 != '\0') {
                        fVar25 = fVar25 * 10.0;
                    }
                    fVar25 = fVar25 + *(float *)(iVar10 + 0x2808);
                    *(undefined *)(iVar10 + 0x280c) = 1;
                    *(float *)(iVar10 + 0x2808) = fVar25;
                }
                if ((*(int32_t *)(iVar10 + 0x21f4) == iVar12) && (*(char *)(iVar10 + 0x1660) == '\0')) {
                    func_0x0001800f9f30(0, 0);
                } else if (*(char *)(iVar10 + 0x280c) != '\0') {
                    fVar20 = *(float *)(iVar10 + 0x2808);
                    fVar25 = (float)func_0x00018014f3d0(fVar25, *(undefined8 *)arg4, uVar27, uVar26, 0, 0);
                    if (((fVar25 < 1.0) || (fVar20 <= 0.0)) && ((0.0 < fVar25 || (0.0 <= fVar20)))) {
                        fVar23 = fVar20 + fVar25;
                        if (0.0 <= fVar23) {
                            fVar21 = 1.0;
                            if (fVar23 <= 1.0) {
                                fVar21 = fVar23;
                            }
                        } else {
                            fVar21 = 0.0;
                        }
                        func_0x00018014f720(9, fVar21, uVar27, uVar26, 0, 0);
                        uVar11 = func_0x00018014fa00(arg_38h);
                        fVar23 = (float)func_0x00018014f3d0((int32_t)uVar11, uVar11, uVar27, uVar26, 0, 0);
                        *(undefined *)(iVar10 + 0x280c) = 0;
                        fVar23 = fVar23 - fVar25;
                        if (fVar20 <= 0.0) {
                            if (fVar23 <= fVar20) {
                                fVar23 = fVar20;
                            }
                            *(float *)(iVar10 + 0x2808) = *(float *)(iVar10 + 0x2808) - fVar23;
                        } else {
                            if (fVar20 <= fVar23) {
                                fVar23 = fVar20;
                            }
                            *(float *)(iVar10 + 0x2808) = *(float *)(iVar10 + 0x2808) - fVar23;
                        }
                        goto code_r0x00018013ef31;
                    }
                    *(undefined4 *)(iVar10 + 0x2808) = 0;
                    *(undefined *)(iVar10 + 0x280c) = 0;
                }
            }
        }
        if (1.0 <= fVar29) {
            fVar29 = (float)func_0x00018014f3d0();
            fVar20 = *(float *)(arg1 + 0xc) - 2.0;
            fVar25 = *(float *)(arg1 + 4) + 2.0;
            fVar28 = fVar29 * (fVar23 - fVar28) + fVar28;
            fVar29 = fVar18 * 0.5 + fVar28;
            fVar28 = fVar28 - fVar18 * 0.5;
        } else {
            fVar29 = *(float *)arg1;
            fVar25 = *(float *)(arg1 + 4);
            fVar28 = fVar29;
            fVar20 = fVar25;
        }
        *(float *)arg_48h = fVar28;
        *(float *)(arg_48h + 4) = fVar25;
        puVar8 = (undefined *)(uint64_t)uVar17;
        *(float *)(arg_48h + 8) = fVar29;
        *(float *)(arg_48h + 0xc) = fVar20;
    }
    return puVar8;
}

// ============================================================
// Function: FUN_18013f2f0
// Address: 0x18013f2f0
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_168h
// WARNING: Variable defined which should be unmapped: var_160h
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18013f2f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    float fVar6;
    char cVar7;
    uint8_t uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    char *pcVar13;
    int64_t iVar14;
    float fVar15;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    int64_t var_128h;
    int64_t var_120h;
    undefined var_118h [8];
    undefined8 var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined4 uStack_e8;
    float var_e4h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_88h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    var_e0h = arg_28h;
    var_128h._0_4_ = (uint32_t)arg2;
    iVar14 = (int64_t)(int32_t)(uint32_t)var_128h;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar5 + 0x15e0);
    var_f8h = arg_30h;
    var_100h = arg3;
    var_d8h = arg4;
    if (*(char *)(iVar3 + 0x10e) != '\0') goto code_r0x00018013f8f0;
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar3 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar3 + 0x148) * 4))
    ;
    var_130h = (float)func_0x00018010be10();
    if ((*(uint8_t *)(iVar5 + 0x1f80) & 0x20) == 0) {
        var_108h._0_4_ = 0;
    } else {
        var_108h._0_4_ = *(int32_t *)(iVar5 + 0x1fb4);
    }
    pcVar13 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar13 != '\0') {
            pcVar1 = pcVar13 + 1;
            if (((*pcVar13 == '#') && (*pcVar1 == '#')) || (pcVar13 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_168h = CONCAT44(var_168h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&var_120h, arg1, pcVar13, 0);
    fVar6 = (float)var_120h;
    var_138h._0_4_ = *(float *)(undefined8 *)(iVar3 + 0x158);
    fVar15 = *(float *)(iVar5 + 0xde0);
    var_130h = var_130h + (float)var_138h;
    var_12ch = fVar15 + fVar15 + var_120h._4_4_ + *(float *)(iVar3 + 0x15c);
    var_138h._4_4_ = *(float *)(iVar3 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_120h._0_4_ = 0.0;
    } else {
        var_120h._0_4_ = (float)var_120h + *(float *)(iVar5 + 0xdf4);
    }
    var_110h._0_4_ = var_130h + (float)var_120h;
    var_118h = (undefined  [8])*(undefined8 *)(iVar3 + 0x158);
    var_120h._0_4_ = (var_130h + (float)var_120h) - (float)var_138h;
    var_110h._4_4_ = var_12ch + 0.0;
    var_120h._4_4_ = (var_12ch + 0.0) - var_138h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar15);
    cVar7 = func_0x00018010b530(var_118h, uVar9, &var_138h, 0x100000);
    if (cVar7 == '\0') goto code_r0x00018013f8f0;
    if (arg_30h == 0) {
        var_f8h = *(int64_t *)(iVar14 * 0x20 + 0x18061fc50);
    }
    uVar8 = func_0x0001800fa440(&var_138h, uVar9, *(undefined4 *)(iVar5 + 0x1fbc));
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1654) == uVar9) &&
       (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x2780) == uVar9)) {
code_r0x00018013f5e0:
        var_150h = 0;
        var_158h = 0;
        var_160h = var_f8h;
        var_168h = var_100h;
        func_0x00018013fa80(&var_138h, uVar9, arg1, (uint32_t)var_128h);
    } else {
        iVar14 = *(int64_t *)0x180781f28;
        if ((uVar8 == 0) || (cVar7 = func_0x000180107ff0(0, 0, uVar9), cVar7 == '\0')) {
            if (*(uint32_t *)(iVar5 + 0x21ec) == uVar9) goto code_r0x00018013f565;
        } else {
            *(uint32_t *)(iVar14 + 0x1d90) = uVar9;
            *(uint32_t *)(iVar14 + 0x1d8c) = uVar9;
            *(undefined2 *)(iVar14 + 0x1d94) = 0;
            if (*(char *)(iVar5 + 0x138) == '\0') {
code_r0x00018013f565:
                bVar4 = false;
                if ((*(uint32_t *)(iVar5 + 0x21ec) == uVar9) && ((*(uint8_t *)(iVar5 + 0x21f8) & 1) != 0))
                goto code_r0x00018013f579;
            } else {
code_r0x00018013f579:
                bVar4 = true;
            }
            func_0x000180498030(iVar5 + 0x1690, var_100h, 
                                *(undefined8 *)((int64_t)(int32_t)(uint32_t)var_128h * 0x20 + 0x18061fc40));
            if (bVar4) goto code_r0x00018013f5e0;
            func_0x0001800f9f30(uVar9, iVar3);
            func_0x00018010e4a0(uVar9, iVar3);
            func_0x00018010e050(iVar3, 0);
            *(uint32_t *)(iVar5 + 0x1f68) = *(uint32_t *)(iVar5 + 0x1f68) | 3;
            iVar14 = *(int64_t *)0x180781f28;
        }
        if (*(uint32_t *)(iVar5 + 0x1654) == uVar9) {
            iVar12 = 0x1d0;
        } else {
            iVar12 = ((uint64_t)uVar8 + 0x1b) * 0x10;
        }
        puVar2 = (undefined4 *)(iVar12 + 0xd90 + iVar14);
        var_f0h._0_4_ = *puVar2;
        var_f0h._4_4_ = puVar2[1];
        uStack_e8 = puVar2[2];
        var_e4h = (float)puVar2[3] * *(float *)(iVar14 + 0xd9c);
        func_0x0001800f7d00(&var_138h, uVar9, 0);
        var_120h._0_4_ = var_130h;
        var_120h._4_4_ = var_12ch;
        var_118h._4_4_ = var_138h._4_4_;
        var_118h._0_4_ = (float)var_138h;
        iVar14 = *(int64_t *)0x180781f28;
        uVar10 = func_0x0001800f5fa0(&var_f0h);
        var_160h = (uint64_t)var_160h._4_4_ << 0x20;
        var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar14 + 0x15e0) + 800), var_118h, &var_120h, uVar10);
        if ((((int32_t)var_108h != 0) && (0.0 < *(float *)(iVar5 + 0xe78))) && ((float)var_138h + 1.0 < var_130h)) {
            fVar15 = (float)var_138h + *(float *)(*(int64_t *)0x180781f28 + 0xe78);
            if (var_130h <= fVar15) {
                fVar15 = var_130h;
            }
            iVar14 = *(int64_t *)0x180781f28;
            uVar10 = func_0x0001800f6610((int32_t)var_108h);
            var_160h = CONCAT44(var_160h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            var_168h = CONCAT44(var_168h._4_4_, fVar15);
            func_0x0001801306b0(*(undefined8 *)(*(int64_t *)(iVar14 + 0x15e0) + 800), &var_138h, uVar10);
        }
        func_0x0001800f7bc0(CONCAT44(var_138h._4_4_, (float)var_138h), CONCAT44(var_12ch, var_130h), 
                            *(undefined4 *)(iVar5 + 0xde4));
        iVar14 = var_f8h;
        var_148h = (int64_t)var_118h;
        var_158h = var_f8h;
        var_160h = var_e0h;
        var_168h = var_d8h;
        _var_118h = ZEXT816(0);
        cVar7 = fcn.18013dd70((int64_t)&var_138h, (uint64_t)uVar9, (uint64_t)(uint32_t)var_128h, var_100h, var_d8h, 
                              var_e0h, var_f8h, var_150h, var_148h);
        if (cVar7 != '\0') {
            func_0x0001800fa060(uVar9);
        }
        if ((float)var_118h._0_4_ < (float)var_110h) {
            iVar12 = 0x270;
            if (*(uint32_t *)(iVar5 + 0x1654) == uVar9) {
                iVar12 = 0x280;
            }
            puVar2 = (undefined4 *)(iVar12 + 0xd90 + *(int64_t *)0x180781f28);
            var_f0h._0_4_ = *puVar2;
            var_f0h._4_4_ = puVar2[1];
            uStack_e8 = puVar2[2];
            var_e4h = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            uVar10 = func_0x0001800f5fa0(&var_f0h);
            var_160h = var_160h & 0xffffffff00000000;
            var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(iVar5 + 0xe24));
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_118h, &var_110h, uVar10);
        }
        var_168h = iVar14;
        iVar11 = func_0x00018013d980(&var_c8h, 0x40, (uint32_t)var_128h, var_100h);
        iVar3 = *(int64_t *)0x180781f28;
        if (*(char *)(iVar5 + 0x29f8) != '\0') {
            *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180620384;
            *(undefined8 *)(iVar3 + 0x2a28) = 0x18061fecc;
        }
        var_160h = (int64_t)var_118h;
        var_158h = 0;
        var_168h = 0;
        var_118h = (undefined  [8])0x3f0000003f000000;
        func_0x0001800f7200(&var_138h, &var_130h, &var_c8h, (int64_t)&var_c8h + (int64_t)iVar11);
        if (0.0 < fVar6) {
            func_0x0001800f6cb0(CONCAT44(var_138h._4_4_ + *(float *)(iVar5 + 0xde0), 
                                         var_130h + *(float *)(iVar5 + 0xdf4)), arg1, pcVar13, 0);
        }
    }
code_r0x00018013f8f0:
    func_0x000180459870(var_88h ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_18013f386
// Address: 0x18013f386
// Size: 336 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_168h
// WARNING: Variable defined which should be unmapped: var_160h
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18013f2f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    float fVar6;
    char cVar7;
    uint8_t uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    char *pcVar13;
    int64_t iVar14;
    float fVar15;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    int64_t var_128h;
    int64_t var_120h;
    undefined var_118h [8];
    undefined8 var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined4 uStack_e8;
    float var_e4h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_88h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    var_e0h = arg_28h;
    var_128h._0_4_ = (uint32_t)arg2;
    iVar14 = (int64_t)(int32_t)(uint32_t)var_128h;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar5 + 0x15e0);
    var_f8h = arg_30h;
    var_100h = arg3;
    var_d8h = arg4;
    if (*(char *)(iVar3 + 0x10e) != '\0') goto code_r0x00018013f8f0;
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar3 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar3 + 0x148) * 4))
    ;
    var_130h = (float)func_0x00018010be10();
    if ((*(uint8_t *)(iVar5 + 0x1f80) & 0x20) == 0) {
        var_108h._0_4_ = 0;
    } else {
        var_108h._0_4_ = *(int32_t *)(iVar5 + 0x1fb4);
    }
    pcVar13 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar13 != '\0') {
            pcVar1 = pcVar13 + 1;
            if (((*pcVar13 == '#') && (*pcVar1 == '#')) || (pcVar13 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_168h = CONCAT44(var_168h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&var_120h, arg1, pcVar13, 0);
    fVar6 = (float)var_120h;
    var_138h._0_4_ = *(float *)(undefined8 *)(iVar3 + 0x158);
    fVar15 = *(float *)(iVar5 + 0xde0);
    var_130h = var_130h + (float)var_138h;
    var_12ch = fVar15 + fVar15 + var_120h._4_4_ + *(float *)(iVar3 + 0x15c);
    var_138h._4_4_ = *(float *)(iVar3 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_120h._0_4_ = 0.0;
    } else {
        var_120h._0_4_ = (float)var_120h + *(float *)(iVar5 + 0xdf4);
    }
    var_110h._0_4_ = var_130h + (float)var_120h;
    var_118h = (undefined  [8])*(undefined8 *)(iVar3 + 0x158);
    var_120h._0_4_ = (var_130h + (float)var_120h) - (float)var_138h;
    var_110h._4_4_ = var_12ch + 0.0;
    var_120h._4_4_ = (var_12ch + 0.0) - var_138h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar15);
    cVar7 = func_0x00018010b530(var_118h, uVar9, &var_138h, 0x100000);
    if (cVar7 == '\0') goto code_r0x00018013f8f0;
    if (arg_30h == 0) {
        var_f8h = *(int64_t *)(iVar14 * 0x20 + 0x18061fc50);
    }
    uVar8 = func_0x0001800fa440(&var_138h, uVar9, *(undefined4 *)(iVar5 + 0x1fbc));
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1654) == uVar9) &&
       (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x2780) == uVar9)) {
code_r0x00018013f5e0:
        var_150h = 0;
        var_158h = 0;
        var_160h = var_f8h;
        var_168h = var_100h;
        func_0x00018013fa80(&var_138h, uVar9, arg1, (uint32_t)var_128h);
    } else {
        iVar14 = *(int64_t *)0x180781f28;
        if ((uVar8 == 0) || (cVar7 = func_0x000180107ff0(0, 0, uVar9), cVar7 == '\0')) {
            if (*(uint32_t *)(iVar5 + 0x21ec) == uVar9) goto code_r0x00018013f565;
        } else {
            *(uint32_t *)(iVar14 + 0x1d90) = uVar9;
            *(uint32_t *)(iVar14 + 0x1d8c) = uVar9;
            *(undefined2 *)(iVar14 + 0x1d94) = 0;
            if (*(char *)(iVar5 + 0x138) == '\0') {
code_r0x00018013f565:
                bVar4 = false;
                if ((*(uint32_t *)(iVar5 + 0x21ec) == uVar9) && ((*(uint8_t *)(iVar5 + 0x21f8) & 1) != 0))
                goto code_r0x00018013f579;
            } else {
code_r0x00018013f579:
                bVar4 = true;
            }
            func_0x000180498030(iVar5 + 0x1690, var_100h, 
                                *(undefined8 *)((int64_t)(int32_t)(uint32_t)var_128h * 0x20 + 0x18061fc40));
            if (bVar4) goto code_r0x00018013f5e0;
            func_0x0001800f9f30(uVar9, iVar3);
            func_0x00018010e4a0(uVar9, iVar3);
            func_0x00018010e050(iVar3, 0);
            *(uint32_t *)(iVar5 + 0x1f68) = *(uint32_t *)(iVar5 + 0x1f68) | 3;
            iVar14 = *(int64_t *)0x180781f28;
        }
        if (*(uint32_t *)(iVar5 + 0x1654) == uVar9) {
            iVar12 = 0x1d0;
        } else {
            iVar12 = ((uint64_t)uVar8 + 0x1b) * 0x10;
        }
        puVar2 = (undefined4 *)(iVar12 + 0xd90 + iVar14);
        var_f0h._0_4_ = *puVar2;
        var_f0h._4_4_ = puVar2[1];
        uStack_e8 = puVar2[2];
        var_e4h = (float)puVar2[3] * *(float *)(iVar14 + 0xd9c);
        func_0x0001800f7d00(&var_138h, uVar9, 0);
        var_120h._0_4_ = var_130h;
        var_120h._4_4_ = var_12ch;
        var_118h._4_4_ = var_138h._4_4_;
        var_118h._0_4_ = (float)var_138h;
        iVar14 = *(int64_t *)0x180781f28;
        uVar10 = func_0x0001800f5fa0(&var_f0h);
        var_160h = (uint64_t)var_160h._4_4_ << 0x20;
        var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar14 + 0x15e0) + 800), var_118h, &var_120h, uVar10);
        if ((((int32_t)var_108h != 0) && (0.0 < *(float *)(iVar5 + 0xe78))) && ((float)var_138h + 1.0 < var_130h)) {
            fVar15 = (float)var_138h + *(float *)(*(int64_t *)0x180781f28 + 0xe78);
            if (var_130h <= fVar15) {
                fVar15 = var_130h;
            }
            iVar14 = *(int64_t *)0x180781f28;
            uVar10 = func_0x0001800f6610((int32_t)var_108h);
            var_160h = CONCAT44(var_160h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            var_168h = CONCAT44(var_168h._4_4_, fVar15);
            func_0x0001801306b0(*(undefined8 *)(*(int64_t *)(iVar14 + 0x15e0) + 800), &var_138h, uVar10);
        }
        func_0x0001800f7bc0(CONCAT44(var_138h._4_4_, (float)var_138h), CONCAT44(var_12ch, var_130h), 
                            *(undefined4 *)(iVar5 + 0xde4));
        iVar14 = var_f8h;
        var_148h = (int64_t)var_118h;
        var_158h = var_f8h;
        var_160h = var_e0h;
        var_168h = var_d8h;
        _var_118h = ZEXT816(0);
        cVar7 = fcn.18013dd70((int64_t)&var_138h, (uint64_t)uVar9, (uint64_t)(uint32_t)var_128h, var_100h, var_d8h, 
                              var_e0h, var_f8h, var_150h, var_148h);
        if (cVar7 != '\0') {
            func_0x0001800fa060(uVar9);
        }
        if ((float)var_118h._0_4_ < (float)var_110h) {
            iVar12 = 0x270;
            if (*(uint32_t *)(iVar5 + 0x1654) == uVar9) {
                iVar12 = 0x280;
            }
            puVar2 = (undefined4 *)(iVar12 + 0xd90 + *(int64_t *)0x180781f28);
            var_f0h._0_4_ = *puVar2;
            var_f0h._4_4_ = puVar2[1];
            uStack_e8 = puVar2[2];
            var_e4h = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            uVar10 = func_0x0001800f5fa0(&var_f0h);
            var_160h = var_160h & 0xffffffff00000000;
            var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(iVar5 + 0xe24));
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_118h, &var_110h, uVar10);
        }
        var_168h = iVar14;
        iVar11 = func_0x00018013d980(&var_c8h, 0x40, (uint32_t)var_128h, var_100h);
        iVar3 = *(int64_t *)0x180781f28;
        if (*(char *)(iVar5 + 0x29f8) != '\0') {
            *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180620384;
            *(undefined8 *)(iVar3 + 0x2a28) = 0x18061fecc;
        }
        var_160h = (int64_t)var_118h;
        var_158h = 0;
        var_168h = 0;
        var_118h = (undefined  [8])0x3f0000003f000000;
        func_0x0001800f7200(&var_138h, &var_130h, &var_c8h, (int64_t)&var_c8h + (int64_t)iVar11);
        if (0.0 < fVar6) {
            func_0x0001800f6cb0(CONCAT44(var_138h._4_4_ + *(float *)(iVar5 + 0xde0), 
                                         var_130h + *(float *)(iVar5 + 0xdf4)), arg1, pcVar13, 0);
        }
    }
code_r0x00018013f8f0:
    func_0x000180459870(var_88h ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_18013f4d6
// Address: 0x18013f4d6
// Size: 1099 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_168h
// WARNING: Variable defined which should be unmapped: var_160h
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_150h
// WARNING: Variable defined which should be unmapped: var_148h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_118h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_110h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.18013f2f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    char *pcVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    float fVar6;
    char cVar7;
    uint8_t uVar8;
    uint32_t uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    int64_t iVar12;
    char *pcVar13;
    int64_t iVar14;
    float fVar15;
    undefined auStackY_188 [32];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_138h;
    float var_130h;
    float var_12ch;
    int64_t var_128h;
    int64_t var_120h;
    undefined var_118h [8];
    undefined8 var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined4 uStack_e8;
    float var_e4h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    
    iVar5 = *(int64_t *)0x180781f28;
    var_88h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_188;
    var_e0h = arg_28h;
    var_128h._0_4_ = (uint32_t)arg2;
    iVar14 = (int64_t)(int32_t)(uint32_t)var_128h;
    *(undefined *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar3 = *(int64_t *)(iVar5 + 0x15e0);
    var_f8h = arg_30h;
    var_100h = arg3;
    var_d8h = arg4;
    if (*(char *)(iVar3 + 0x10e) != '\0') goto code_r0x00018013f8f0;
    uVar9 = func_0x0001800f5a90(arg1, 0, *(undefined4 *)
                                          (*(int64_t *)(iVar3 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar3 + 0x148) * 4))
    ;
    var_130h = (float)func_0x00018010be10();
    if ((*(uint8_t *)(iVar5 + 0x1f80) & 0x20) == 0) {
        var_108h._0_4_ = 0;
    } else {
        var_108h._0_4_ = *(int32_t *)(iVar5 + 0x1fb4);
    }
    pcVar13 = (char *)arg1;
    if (arg1 != -1) {
        while (*pcVar13 != '\0') {
            pcVar1 = pcVar13 + 1;
            if (((*pcVar13 == '#') && (*pcVar1 == '#')) || (pcVar13 = pcVar1, pcVar1 == (char *)0xffffffffffffffff))
            break;
        }
    }
    var_168h = CONCAT44(var_168h._4_4_, 0xbf800000);
    func_0x0001800fe0a0(&var_120h, arg1, pcVar13, 0);
    fVar6 = (float)var_120h;
    var_138h._0_4_ = *(float *)(undefined8 *)(iVar3 + 0x158);
    fVar15 = *(float *)(iVar5 + 0xde0);
    var_130h = var_130h + (float)var_138h;
    var_12ch = fVar15 + fVar15 + var_120h._4_4_ + *(float *)(iVar3 + 0x15c);
    var_138h._4_4_ = *(float *)(iVar3 + 0x15c);
    if ((float)var_120h <= 0.0) {
        var_120h._0_4_ = 0.0;
    } else {
        var_120h._0_4_ = (float)var_120h + *(float *)(iVar5 + 0xdf4);
    }
    var_110h._0_4_ = var_130h + (float)var_120h;
    var_118h = (undefined  [8])*(undefined8 *)(iVar3 + 0x158);
    var_120h._0_4_ = (var_130h + (float)var_120h) - (float)var_138h;
    var_110h._4_4_ = var_12ch + 0.0;
    var_120h._4_4_ = (var_12ch + 0.0) - var_138h._4_4_;
    func_0x00018010bbf0(&var_120h, fVar15);
    cVar7 = func_0x00018010b530(var_118h, uVar9, &var_138h, 0x100000);
    if (cVar7 == '\0') goto code_r0x00018013f8f0;
    if (arg_30h == 0) {
        var_f8h = *(int64_t *)(iVar14 * 0x20 + 0x18061fc50);
    }
    uVar8 = func_0x0001800fa440(&var_138h, uVar9, *(undefined4 *)(iVar5 + 0x1fbc));
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1654) == uVar9) &&
       (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x2780) == uVar9)) {
code_r0x00018013f5e0:
        var_150h = 0;
        var_158h = 0;
        var_160h = var_f8h;
        var_168h = var_100h;
        func_0x00018013fa80(&var_138h, uVar9, arg1, (uint32_t)var_128h);
    } else {
        iVar14 = *(int64_t *)0x180781f28;
        if ((uVar8 == 0) || (cVar7 = func_0x000180107ff0(0, 0, uVar9), cVar7 == '\0')) {
            if (*(uint32_t *)(iVar5 + 0x21ec) == uVar9) goto code_r0x00018013f565;
        } else {
            *(uint32_t *)(iVar14 + 0x1d90) = uVar9;
            *(uint32_t *)(iVar14 + 0x1d8c) = uVar9;
            *(undefined2 *)(iVar14 + 0x1d94) = 0;
            if (*(char *)(iVar5 + 0x138) == '\0') {
code_r0x00018013f565:
                bVar4 = false;
                if ((*(uint32_t *)(iVar5 + 0x21ec) == uVar9) && ((*(uint8_t *)(iVar5 + 0x21f8) & 1) != 0))
                goto code_r0x00018013f579;
            } else {
code_r0x00018013f579:
                bVar4 = true;
            }
            func_0x000180498030(iVar5 + 0x1690, var_100h, 
                                *(undefined8 *)((int64_t)(int32_t)(uint32_t)var_128h * 0x20 + 0x18061fc40));
            if (bVar4) goto code_r0x00018013f5e0;
            func_0x0001800f9f30(uVar9, iVar3);
            func_0x00018010e4a0(uVar9, iVar3);
            func_0x00018010e050(iVar3, 0);
            *(uint32_t *)(iVar5 + 0x1f68) = *(uint32_t *)(iVar5 + 0x1f68) | 3;
            iVar14 = *(int64_t *)0x180781f28;
        }
        if (*(uint32_t *)(iVar5 + 0x1654) == uVar9) {
            iVar12 = 0x1d0;
        } else {
            iVar12 = ((uint64_t)uVar8 + 0x1b) * 0x10;
        }
        puVar2 = (undefined4 *)(iVar12 + 0xd90 + iVar14);
        var_f0h._0_4_ = *puVar2;
        var_f0h._4_4_ = puVar2[1];
        uStack_e8 = puVar2[2];
        var_e4h = (float)puVar2[3] * *(float *)(iVar14 + 0xd9c);
        func_0x0001800f7d00(&var_138h, uVar9, 0);
        var_120h._0_4_ = var_130h;
        var_120h._4_4_ = var_12ch;
        var_118h._4_4_ = var_138h._4_4_;
        var_118h._0_4_ = (float)var_138h;
        iVar14 = *(int64_t *)0x180781f28;
        uVar10 = func_0x0001800f5fa0(&var_f0h);
        var_160h = (uint64_t)var_160h._4_4_ << 0x20;
        var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
        func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar14 + 0x15e0) + 800), var_118h, &var_120h, uVar10);
        if ((((int32_t)var_108h != 0) && (0.0 < *(float *)(iVar5 + 0xe78))) && ((float)var_138h + 1.0 < var_130h)) {
            fVar15 = (float)var_138h + *(float *)(*(int64_t *)0x180781f28 + 0xe78);
            if (var_130h <= fVar15) {
                fVar15 = var_130h;
            }
            iVar14 = *(int64_t *)0x180781f28;
            uVar10 = func_0x0001800f6610((int32_t)var_108h);
            var_160h = CONCAT44(var_160h._4_4_, *(undefined4 *)(iVar5 + 0xde4));
            var_168h = CONCAT44(var_168h._4_4_, fVar15);
            func_0x0001801306b0(*(undefined8 *)(*(int64_t *)(iVar14 + 0x15e0) + 800), &var_138h, uVar10);
        }
        func_0x0001800f7bc0(CONCAT44(var_138h._4_4_, (float)var_138h), CONCAT44(var_12ch, var_130h), 
                            *(undefined4 *)(iVar5 + 0xde4));
        iVar14 = var_f8h;
        var_148h = (int64_t)var_118h;
        var_158h = var_f8h;
        var_160h = var_e0h;
        var_168h = var_d8h;
        _var_118h = ZEXT816(0);
        cVar7 = fcn.18013dd70((int64_t)&var_138h, (uint64_t)uVar9, (uint64_t)(uint32_t)var_128h, var_100h, var_d8h, 
                              var_e0h, var_f8h, var_150h, var_148h);
        if (cVar7 != '\0') {
            func_0x0001800fa060(uVar9);
        }
        if ((float)var_118h._0_4_ < (float)var_110h) {
            iVar12 = 0x270;
            if (*(uint32_t *)(iVar5 + 0x1654) == uVar9) {
                iVar12 = 0x280;
            }
            puVar2 = (undefined4 *)(iVar12 + 0xd90 + *(int64_t *)0x180781f28);
            var_f0h._0_4_ = *puVar2;
            var_f0h._4_4_ = puVar2[1];
            uStack_e8 = puVar2[2];
            var_e4h = (float)puVar2[3] * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            uVar10 = func_0x0001800f5fa0(&var_f0h);
            var_160h = var_160h & 0xffffffff00000000;
            var_168h = CONCAT44(var_168h._4_4_, *(undefined4 *)(iVar5 + 0xe24));
            func_0x000180126550(*(undefined8 *)(iVar3 + 800), var_118h, &var_110h, uVar10);
        }
        var_168h = iVar14;
        iVar11 = func_0x00018013d980(&var_c8h, 0x40, (uint32_t)var_128h, var_100h);
        iVar3 = *(int64_t *)0x180781f28;
        if (*(char *)(iVar5 + 0x29f8) != '\0') {
            *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a20) = 0x180620384;
            *(undefined8 *)(iVar3 + 0x2a28) = 0x18061fecc;
        }
        var_160h = (int64_t)var_118h;
        var_158h = 0;
        var_168h = 0;
        var_118h = (undefined  [8])0x3f0000003f000000;
        func_0x0001800f7200(&var_138h, &var_130h, &var_c8h, (int64_t)&var_c8h + (int64_t)iVar11);
        if (0.0 < fVar6) {
            func_0x0001800f6cb0(CONCAT44(var_138h._4_4_ + *(float *)(iVar5 + 0xde0), 
                                         var_130h + *(float *)(iVar5 + 0xdf4)), arg1, pcVar13, 0);
        }
    }
code_r0x00018013f8f0:
    func_0x000180459870(var_88h ^ (uint64_t)auStackY_188);
    return;
}

// ============================================================
// Function: FUN_18013fa80
// Address: 0x18013fa80
// Size: 1392 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.18013fa80(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    float fVar3;
    double dVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    char cVar9;
    int32_t iVar10;
    char *pcVar11;
    double *pdVar12;
    char *pcVar13;
    int64_t *piVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    int64_t iVar17;
    int32_t iVar18;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    char cStack_81;
    int64_t var_80h;
    int64_t var_60h;
    int64_t var_38h;
    
    iVar7 = *(int64_t *)0x180781f28;
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    iVar17 = (int64_t)(int32_t)arg4 * 0x20;
    cVar9 = *(char *)arg_30h;
    while (cVar9 != '\0') {
        if (cVar9 == '%') {
            if (*(char *)(arg_30h + 1) != '%') break;
            arg_30h = arg_30h + 1;
        }
        pcVar11 = (char *)(arg_30h + 1);
        arg_30h = arg_30h + 1;
        cVar9 = *pcVar11;
    }
    var_b8h = arg1;
    var_a8h = arg3;
    if (*(char *)arg_30h == '%') {
        pcVar11 = (char *)func_0x00018013f930(arg_30h);
        if (*pcVar11 != '\0') {
            pcVar13 = (char *)0x20;
            if (pcVar11 + (1 - arg_30h) < (char *)0x20) {
                pcVar13 = pcVar11 + (1 - arg_30h);
            }
            if (pcVar13 != (char *)0x0) {
                if ((char *)0x1 < pcVar13) {
                    func_0x000180498d90(&var_80h, arg_30h, (int32_t)pcVar13 + -1);
                }
                (&cStack_81)[(int64_t)pcVar13] = '\0';
            }
            arg_30h = (int64_t)&var_80h;
            if ((char)var_80h == '\0') goto code_r0x00018013fb57;
        }
    } else {
code_r0x00018013fb57:
        arg_30h = *(int64_t *)(iVar17 + 0x18061fc50);
    }
    for (piVar14 = &var_a0h; (cVar9 = *(char *)piVar14, cVar9 == ' ' || (cVar9 == '\t'));
        piVar14 = (int64_t *)((int64_t)piVar14 + 1)) {
    }
    piVar16 = piVar14;
    piVar15 = piVar14;
    if (cVar9 != '\0') {
        do {
            piVar15 = (int64_t *)((int64_t)piVar15 + 1);
        } while (*(char *)piVar15 != '\0');
        do {
            piVar16 = piVar15;
            if (piVar16 <= piVar14) break;
            piVar15 = (int64_t *)((int64_t)piVar16 + -1);
        } while ((*(char *)((int64_t)piVar16 + -1) == ' ') || (*(char *)((int64_t)piVar16 + -1) == '\t'));
    }
    if (piVar14 != &var_a0h) {
        func_0x000180498030(&var_a0h, piVar14, (int64_t)piVar16 - (int64_t)piVar14);
    }
    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar7 + 0x1fbc) | 0x10000;
    *(char *)((int64_t)piVar16 + ((int64_t)&var_a0h - (int64_t)piVar14)) = '\0';
    iVar10 = *(int32_t *)(iVar7 + 0x2780);
    iVar5 = *(int64_t *)(iVar7 + 0x15e0);
    iVar18 = (int32_t)arg2;
    if (iVar10 != iVar18) {
        func_0x0001800f9f30(0, 0);
    }
    uVar1 = *(undefined4 *)(iVar5 + 0x158);
    uVar2 = *(undefined4 *)(iVar5 + 0x15c);
    *(undefined8 *)(iVar5 + 0x158) = *(undefined8 *)var_b8h;
    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar7 + 0x1fbc) | 0x20;
    var_c0h = 0;
    var_c8h = 0;
    var_d8h = (int64_t)&var_b8h;
    var_d0h._0_4_ = 0x18001000;
    var_b8h = CONCAT44(*(float *)(var_b8h + 0xc) - *(float *)(var_b8h + 4), *(float *)(var_b8h + 8) - *(float *)var_b8h)
    ;
    cVar9 = func_0x0001801431e0(var_a8h, 0, &var_a0h, 0x20);
    iVar8 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar18) {
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar18;
    }
    if (*(int32_t *)(iVar8 + 0x1684) == iVar18) {
        *(undefined *)(iVar8 + 0x168d) = 1;
    }
    if (iVar10 != iVar18) {
        *(undefined4 *)(iVar7 + 0x2780) = *(undefined4 *)(iVar7 + 0x1654);
    }
    if (*(int32_t *)(iVar7 + 0x1654) != iVar18) {
        *(undefined4 *)(iVar7 + 0x2780) = 0;
    }
    *(undefined4 *)(iVar5 + 0x158) = uVar1;
    *(undefined4 *)(iVar5 + 0x15c) = uVar2;
    if (cVar9 == '\0') goto code_r0x00018013ff93;
    uVar6 = *(undefined8 *)(iVar17 + 0x18061fc40);
    func_0x000180498030(&var_a8h, arg_28h, uVar6);
    fcn.18013da60((int64_t)&var_a0h, arg4 & 0xffffffff, arg_28h, arg_30h);
    pdVar12 = (double *)arg_38h;
    if (arg_38h == 0) {
        if (arg_40h != 0) goto code_r0x00018013fd41;
    } else {
        if ((arg_40h != 0) &&
           (iVar10 = func_0x00018013dc30(arg4 & 0xffffffff, arg_38h, arg_40h), pdVar12 = (double *)arg_38h, 0 < iVar10))
        {
            pdVar12 = (double *)arg_40h;
            arg_40h = arg_38h;
        }
code_r0x00018013fd41:
    // switch table (10 cases) at 0x18013ffc8
        switch((int32_t)arg4) {
        case 0:
            if ((pdVar12 == (double *)0x0) || (*(char *)pdVar12 <= *(char *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && (*(char *)arg_40h < *(char *)arg_28h)) {
                    *(char *)arg_28h = *(char *)arg_40h;
                }
            } else {
                *(char *)arg_28h = *(char *)pdVar12;
            }
            break;
        case 1:
            if ((pdVar12 == (double *)0x0) || (*(uint8_t *)pdVar12 <= *(uint8_t *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && (*(uint8_t *)arg_40h < *(uint8_t *)arg_28h)) {
                    *(uint8_t *)arg_28h = *(uint8_t *)arg_40h;
                }
            } else {
                *(uint8_t *)arg_28h = *(uint8_t *)pdVar12;
            }
            break;
        case 2:
            if ((pdVar12 == (double *)0x0) || (*(int16_t *)pdVar12 <= *(int16_t *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && (*(int16_t *)arg_40h < *(int16_t *)arg_28h)) {
                    *(int16_t *)arg_28h = *(int16_t *)arg_40h;
                }
            } else {
                *(int16_t *)arg_28h = *(int16_t *)pdVar12;
            }
            break;
        case 3:
            if ((pdVar12 == (double *)0x0) || (*(uint16_t *)pdVar12 <= *(uint16_t *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && (*(uint16_t *)arg_40h < *(uint16_t *)arg_28h)) {
                    *(uint16_t *)arg_28h = *(uint16_t *)arg_40h;
                }
            } else {
                *(uint16_t *)arg_28h = *(uint16_t *)pdVar12;
            }
            break;
        case 4:
            if ((pdVar12 == (double *)0x0) || ((int32_t)*(float *)pdVar12 <= *(int32_t *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && ((int32_t)*(float *)arg_40h < *(int32_t *)arg_28h)) {
                    *(float *)arg_28h = *(float *)arg_40h;
                }
            } else {
                *(float *)arg_28h = *(float *)pdVar12;
            }
            break;
        case 5:
            if ((pdVar12 == (double *)0x0) || ((uint32_t)*(float *)pdVar12 <= (uint32_t)*(float *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && ((uint32_t)*(float *)arg_40h < (uint32_t)*(float *)arg_28h))
                {
                    *(float *)arg_28h = *(float *)arg_40h;
                }
            } else {
                *(float *)arg_28h = *(float *)pdVar12;
            }
            break;
        case 6:
            if ((pdVar12 == (double *)0x0) || ((int64_t)*pdVar12 <= *(int64_t *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && ((int64_t)*(double *)arg_40h < *(int64_t *)arg_28h)) {
                    *(double *)arg_28h = *(double *)arg_40h;
                }
            } else {
                *(double *)arg_28h = *pdVar12;
            }
            break;
        case 7:
            if ((pdVar12 == (double *)0x0) || ((uint64_t)*pdVar12 <= (uint64_t)*(double *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) &&
                   ((uint64_t)*(double *)arg_40h < (uint64_t)*(double *)arg_28h)) {
                    *(double *)arg_28h = *(double *)arg_40h;
                }
            } else {
                *(double *)arg_28h = *pdVar12;
            }
            break;
        case 8:
            if ((pdVar12 == (double *)0x0) ||
               (fVar3 = *(float *)pdVar12, fVar3 < *(float *)arg_28h || fVar3 == *(float *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && (*(float *)arg_40h < *(float *)arg_28h)) {
                    *(float *)arg_28h = *(float *)arg_40h;
                }
            } else {
                *(float *)arg_28h = fVar3;
            }
            break;
        case 9:
            if ((pdVar12 == (double *)0x0) ||
               (dVar4 = *pdVar12, dVar4 < *(double *)arg_28h || dVar4 == *(double *)arg_28h)) {
                if (((double *)arg_40h != (double *)0x0) && (*(double *)arg_40h < *(double *)arg_28h)) {
                    *(double *)arg_28h = *(double *)arg_40h;
                }
            } else {
                *(double *)arg_28h = dVar4;
            }
        }
    }
    *(uint32_t *)(iVar7 + 0x1fbc) = *(uint32_t *)(iVar7 + 0x1fbc) & 0xfffeffff;
    iVar10 = func_0x000180497f30(&var_a8h, arg_28h, uVar6);
    iVar7 = *(int64_t *)0x180781f28;
    if ((iVar10 != 0) && ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 0x10000) == 0)) {
        if (((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar18) ||
            (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == 0)) &&
           (*(undefined2 *)(*(int64_t *)0x180781f28 + 0x1664) = 0x101, *(int32_t *)(iVar7 + 0x1684) == iVar18)) {
            *(undefined *)(iVar7 + 0x168c) = 1;
        }
        *(uint32_t *)(iVar7 + 0x1fc0) = *(uint32_t *)(iVar7 + 0x1fc0) | 4;
    }
code_r0x00018013ff93:
    func_0x000180459870(var_60h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_18013fff0
// Address: 0x18013fff0
// Size: 130 bytes
// ============================================================
float fcn.18013fff0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    float fVar2;
    int64_t var_10h;
    
    fcn.1800f5c80(&var_10h, (int64_t)(int32_t)arg2 + *(int64_t *)(arg1 + 0x20) + (int64_t)(int32_t)arg3, 
                  (int64_t)*(int32_t *)(arg1 + 0x18) + *(int64_t *)(arg1 + 0x20));
    if ((int16_t)(uint32_t)var_10h == 10) {
        return -1.0;
    }
    arg1 = *(int64_t *)arg1;
    piVar1 = *(int32_t **)(arg1 + 0x12f0);
    if ((int32_t)((uint32_t)var_10h & 0xffff) < *piVar1) {
        fVar2 = *(float *)(*(int64_t *)(piVar1 + 2) + ((uint64_t)(uint32_t)var_10h & 0xffff) * 4);
        if (0.0 <= fVar2) goto code_r0x000180140061;
    }
    fVar2 = (float)fcn.18012bbd0(piVar1);
code_r0x000180140061:
    return fVar2 * *(float *)(arg1 + 0x1300);
}

// ============================================================
// Function: FUN_180140080
// Address: 0x180140080
// Size: 630 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: Variable defined which should be unmapped: var_c0h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180140080(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    float fVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    char *pcVar6;
    char *pcVar7;
    char *pcVar8;
    char *pcVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_40h;
    
    var_18h._0_4_ = (int32_t)arg3;
    iVar4 = *(int64_t *)arg2;
    var_20h = *(int64_t *)(arg2 + 0x20);
    var_10h = *(int64_t *)(iVar4 + 0x12e8);
    fVar1 = *(float *)(iVar4 + 0x12f8);
    fVar12 = *(float *)(iVar4 + 0x26c8);
    pcVar7 = (char *)((int32_t)var_18h + var_20h);
    pcVar9 = (char *)(*(int32_t *)(arg2 + 0x18) + var_20h);
    iVar4 = var_10h;
    if (pcVar9 == (char *)0x0) {
        iVar4 = func_0x000180498cd0(pcVar7);
        pcVar9 = pcVar7 + iVar4;
        iVar4 = var_10h;
    }
    var_10h = iVar4;
    puVar5 = (uint32_t *)func_0x00018012ec80(iVar4, fVar1, 0xbf800000);
    fVar13 = 0.0;
    fVar2 = (float)puVar5[5];
    pcVar6 = (char *)0x0;
    fVar10 = 0.0;
    do {
        do {
            fVar11 = fVar10;
            pcVar8 = pcVar7;
            if (pcVar9 <= pcVar8) goto code_r0x000180140272;
            if (0.0 < fVar12) {
                if (pcVar6 == (char *)0x0) {
                    pcVar6 = (char *)func_0x00018012f4a0(iVar4, fVar1, pcVar8, pcVar9, fVar12 - fVar11, 6);
                }
                if (pcVar6 <= pcVar8) {
                    fVar12 = fVar11;
                    if (fVar11 <= 0.0) {
                        fVar12 = 0.0;
                    }
                    fVar13 = fVar1 + 0.0;
                    if ((pcVar8 < pcVar9) && (*pcVar8 == '\n')) {
                        pcVar8 = pcVar8 + 1;
                    }
                    pcVar7 = pcVar8;
                    fVar11 = 0.0;
                    if (0.0 <= fVar12) {
                        fVar11 = fVar12;
                    }
                    goto code_r0x000180140280;
                }
            }
            var_8h._0_4_ = (uint32_t)*pcVar8;
            if ((uint32_t)var_8h < 0x80) {
                iVar4 = 1;
            } else {
                iVar3 = fcn.1800f5c80(&var_8h, pcVar8, pcVar9);
                iVar4 = (int64_t)iVar3;
            }
            pcVar7 = pcVar8 + iVar4;
            if ((uint32_t)var_8h == 10) {
                fVar13 = fVar1 + 0.0;
                fVar12 = 0.0;
                if (0.0 <= fVar11) {
                    fVar12 = fVar11;
                }
                fVar11 = 0.0;
                if (0.0 <= fVar12) {
                    fVar11 = fVar12;
                }
                goto code_r0x000180140280;
            }
            fVar10 = fVar11;
            iVar4 = var_10h;
        } while ((uint32_t)var_8h == 0xd);
        if ((*puVar5 <= (uint32_t)var_8h) ||
           (fVar10 = *(float *)(*(int64_t *)(puVar5 + 2) + (uint64_t)(uint32_t)var_8h * 4), fVar10 < 0.0)) {
            fVar10 = (float)fcn.18012bbd0(puVar5);
        }
        fVar10 = fVar10 * (fVar1 / fVar2) + fVar11;
        iVar4 = var_10h;
    } while (fVar10 < 3.402823e+38);
code_r0x000180140272:
    iVar3 = (int32_t)pcVar8;
    if (fVar11 <= 0.0) {
        pcVar7 = pcVar8;
        fVar11 = 0.0;
code_r0x000180140280:
        iVar3 = (int32_t)pcVar7;
        if (fVar13 != 0.0) goto code_r0x00018014028d;
    }
    fVar13 = fVar13 + fVar1;
code_r0x00018014028d:
    *(float *)(arg1 + 8) = fVar13;
    *(float *)(arg1 + 0x10) = fVar13;
    *(int32_t *)(arg1 + 0x14) = (iVar3 - (int32_t)var_20h) - (int32_t)var_18h;
    *(float *)(arg1 + 4) = fVar11;
    *(undefined4 *)arg1 = 0;
    *(undefined4 *)(arg1 + 0xc) = 0;
    return;
}

// ============================================================
// Function: FUN_180140300
// Address: 0x180140300
// Size: 57 bytes
// ============================================================
int32_t fcn.180140300(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t var_10h;
    
    iVar1 = *(int32_t *)(arg1 + 0x18);
    iVar2 = (int32_t)arg2;
    if (iVar1 <= iVar2) {
        return iVar1 + 1;
    }
    iVar1 = fcn.1800f5c80(&var_10h, (int64_t)iVar2 + *(int64_t *)(arg1 + 0x20), 
                          (int64_t)iVar1 + *(int64_t *)(arg1 + 0x20));
    return iVar1 + iVar2;
}

// ============================================================
// Function: FUN_180140380
// Address: 0x180140380
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180140380(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int32_t *piVar7;
    int32_t *piVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < (int32_t)arg2)) {
        uVar2 = *(uint64_t *)(arg1 + 0x20);
        uVar9 = (int64_t)(int32_t)arg2 + uVar2;
        uVar10 = uVar9;
        do {
            uVar11 = uVar2;
            if (uVar10 <= uVar2) break;
            puVar1 = (uint8_t *)(uVar10 - 1);
            uVar10 = uVar10 - 1;
            uVar11 = uVar10;
        } while ((*puVar1 & 0xc0) == 0x80);
        fcn.1800f5c80(&var_18h, uVar9, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar2);
        fcn.1800f5c80(&var_8h, uVar11);
        if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        piVar7 = (int32_t *)0x180645bf0;
        piVar8 = (int32_t *)0x180645bf0;
        do {
            if ((int32_t)var_8h == *piVar8) {
                bVar4 = true;
                goto code_r0x000180140443;
            }
            piVar8 = piVar8 + 1;
        } while (piVar8 != (int32_t *)0x180645c64);
        bVar4 = false;
code_r0x000180140443:
        if ((((int32_t)var_18h == 0x20) || ((int32_t)var_18h == 9)) || ((int32_t)var_18h == 0x3000)) {
            bVar5 = true;
        } else {
            bVar5 = false;
        }
        do {
            if ((int32_t)var_18h == *piVar7) {
                bVar6 = true;
                goto code_r0x000180140474;
            }
            piVar7 = piVar7 + 1;
        } while (piVar7 != (int32_t *)0x180645c64);
        bVar6 = false;
code_r0x000180140474:
        if ((bVar3) || (bVar4)) {
            if (!bVar6) {
                if (!bVar5) {
                    return 1;
                }
                return 0;
            }
        } else if (!bVar6) {
            return 0;
        }
        if (!bVar4) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801403a8
// Address: 0x1801403a8
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180140380(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int32_t *piVar7;
    int32_t *piVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < (int32_t)arg2)) {
        uVar2 = *(uint64_t *)(arg1 + 0x20);
        uVar9 = (int64_t)(int32_t)arg2 + uVar2;
        uVar10 = uVar9;
        do {
            uVar11 = uVar2;
            if (uVar10 <= uVar2) break;
            puVar1 = (uint8_t *)(uVar10 - 1);
            uVar10 = uVar10 - 1;
            uVar11 = uVar10;
        } while ((*puVar1 & 0xc0) == 0x80);
        fcn.1800f5c80(&var_18h, uVar9, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar2);
        fcn.1800f5c80(&var_8h, uVar11);
        if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        piVar7 = (int32_t *)0x180645bf0;
        piVar8 = (int32_t *)0x180645bf0;
        do {
            if ((int32_t)var_8h == *piVar8) {
                bVar4 = true;
                goto code_r0x000180140443;
            }
            piVar8 = piVar8 + 1;
        } while (piVar8 != (int32_t *)0x180645c64);
        bVar4 = false;
code_r0x000180140443:
        if ((((int32_t)var_18h == 0x20) || ((int32_t)var_18h == 9)) || ((int32_t)var_18h == 0x3000)) {
            bVar5 = true;
        } else {
            bVar5 = false;
        }
        do {
            if ((int32_t)var_18h == *piVar7) {
                bVar6 = true;
                goto code_r0x000180140474;
            }
            piVar7 = piVar7 + 1;
        } while (piVar7 != (int32_t *)0x180645c64);
        bVar6 = false;
code_r0x000180140474:
        if ((bVar3) || (bVar4)) {
            if (!bVar6) {
                if (!bVar5) {
                    return 1;
                }
                return 0;
            }
        } else if (!bVar6) {
            return 0;
        }
        if (!bVar4) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180140409
// Address: 0x180140409
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180140380(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int32_t *piVar7;
    int32_t *piVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < (int32_t)arg2)) {
        uVar2 = *(uint64_t *)(arg1 + 0x20);
        uVar9 = (int64_t)(int32_t)arg2 + uVar2;
        uVar10 = uVar9;
        do {
            uVar11 = uVar2;
            if (uVar10 <= uVar2) break;
            puVar1 = (uint8_t *)(uVar10 - 1);
            uVar10 = uVar10 - 1;
            uVar11 = uVar10;
        } while ((*puVar1 & 0xc0) == 0x80);
        fcn.1800f5c80(&var_18h, uVar9, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar2);
        fcn.1800f5c80(&var_8h, uVar11);
        if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
            bVar3 = true;
        } else {
            bVar3 = false;
        }
        piVar7 = (int32_t *)0x180645bf0;
        piVar8 = (int32_t *)0x180645bf0;
        do {
            if ((int32_t)var_8h == *piVar8) {
                bVar4 = true;
                goto code_r0x000180140443;
            }
            piVar8 = piVar8 + 1;
        } while (piVar8 != (int32_t *)0x180645c64);
        bVar4 = false;
code_r0x000180140443:
        if ((((int32_t)var_18h == 0x20) || ((int32_t)var_18h == 9)) || ((int32_t)var_18h == 0x3000)) {
            bVar5 = true;
        } else {
            bVar5 = false;
        }
        do {
            if ((int32_t)var_18h == *piVar7) {
                bVar6 = true;
                goto code_r0x000180140474;
            }
            piVar7 = piVar7 + 1;
        } while (piVar7 != (int32_t *)0x180645c64);
        bVar6 = false;
code_r0x000180140474:
        if ((bVar3) || (bVar4)) {
            if (!bVar6) {
                if (!bVar5) {
                    return 1;
                }
                return 0;
            }
        } else if (!bVar6) {
            return 0;
        }
        if (!bVar4) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801404b0
// Address: 0x1801404b0
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint32_t fcn.1801404b0(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if ((int32_t)arg2 < 1) {
code_r0x000180140530:
        uVar5 = 0xffffffff;
    } else {
        uVar2 = *(uint64_t *)(arg1 + 0x20);
        uVar6 = (int64_t)(int32_t)arg2 + uVar2;
        do {
            uVar4 = uVar2;
            if (uVar6 <= uVar2) break;
            puVar1 = (uint8_t *)(uVar6 - 1);
            uVar6 = uVar6 - 1;
            uVar4 = uVar6;
        } while ((*puVar1 & 0xc0) == 0x80);
        uVar5 = (int32_t)uVar4 - *(int32_t *)(arg1 + 0x20);
        while ((-1 < (int32_t)uVar5 && (iVar3 = fcn.180140380(arg1, (uint64_t)uVar5), iVar3 == 0))) {
            if (uVar5 == 0) goto code_r0x000180140530;
            uVar2 = *(uint64_t *)(arg1 + 0x20);
            uVar6 = uVar5 + uVar2;
            do {
                uVar4 = uVar2;
                if (uVar6 <= uVar2) break;
                puVar1 = (uint8_t *)(uVar6 - 1);
                uVar6 = uVar6 - 1;
                uVar4 = uVar6;
            } while ((*puVar1 & 0xc0) == 0x80);
            uVar5 = (int32_t)uVar4 - *(int32_t *)(arg1 + 0x20);
        }
    }
    if ((int32_t)uVar5 < 0) {
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180140550
// Address: 0x180140550
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int32_t fcn.180140550(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    uint8_t *puVar1;
    int32_t iVar2;
    uint64_t uVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t *piVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar2 = *(int32_t *)(arg1 + 0x18);
    iVar11 = (int32_t)arg2;
    if (iVar11 < iVar2) {
        iVar8 = fcn.1800f5c80(&var_10h, (int64_t)iVar11 + *(int64_t *)(arg1 + 0x20), 
                              (int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        iVar11 = iVar11 + iVar8;
    } else {
        iVar11 = iVar2 + 1;
    }
    iVar8 = iVar11 - iVar2;
    if (iVar11 < iVar2) {
        do {
            if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < iVar11)) {
                uVar3 = *(uint64_t *)(arg1 + 0x20);
                uVar10 = uVar3 + (int64_t)iVar11;
                do {
                    if (uVar10 <= uVar3) break;
                    puVar1 = (uint8_t *)(uVar10 - 1);
                    uVar10 = uVar10 - 1;
                } while ((*puVar1 & 0xc0) == 0x80);
                fcn.1800f5c80(&var_10h, uVar3 + (int64_t)iVar11, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar3);
                fcn.1800f5c80(&var_8h);
                if ((((int32_t)var_10h == 0x20) || ((int32_t)var_10h == 9)) || ((int32_t)var_10h == 0x3000)) {
                    bVar4 = true;
                } else {
                    bVar4 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_10h == *piVar9) {
                        bVar6 = true;
                        goto code_r0x000180140655;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar6 = false;
code_r0x000180140655:
                if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
                    bVar5 = true;
                } else {
                    bVar5 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_8h == *piVar9) {
                        bVar7 = true;
                        goto code_r0x000180140687;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar7 = false;
code_r0x000180140687:
                if (bVar4) {
                    if (bVar7) {
code_r0x0001801406a0:
                        if (bVar6) goto code_r0x000180140694;
                    } else if (bVar5) goto code_r0x000180140694;
                    bVar4 = true;
                } else {
                    if (bVar7) goto code_r0x0001801406a0;
code_r0x000180140694:
                    bVar4 = false;
                }
                if (bVar4) break;
            }
            iVar8 = *(int32_t *)(arg1 + 0x18);
            if (iVar11 < iVar8) {
                iVar8 = fcn.1800f5c80(&var_18h, *(int64_t *)(arg1 + 0x20) + (int64_t)iVar11, 
                                      *(int64_t *)(arg1 + 0x20) + (int64_t)iVar8);
                iVar11 = iVar11 + iVar8;
            } else {
                iVar11 = iVar8 + 1;
            }
        } while (iVar11 < iVar2);
        iVar8 = iVar11 - iVar2;
    }
    if (iVar11 != iVar2 && SBORROW4(iVar11, iVar2) == iVar8 < 0) {
        iVar11 = iVar2;
    }
    return iVar11;
}

// ============================================================
// Function: FUN_180140595
// Address: 0x180140595
// Size: 346 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int32_t fcn.180140550(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    uint8_t *puVar1;
    int32_t iVar2;
    uint64_t uVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t *piVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar2 = *(int32_t *)(arg1 + 0x18);
    iVar11 = (int32_t)arg2;
    if (iVar11 < iVar2) {
        iVar8 = fcn.1800f5c80(&var_10h, (int64_t)iVar11 + *(int64_t *)(arg1 + 0x20), 
                              (int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        iVar11 = iVar11 + iVar8;
    } else {
        iVar11 = iVar2 + 1;
    }
    iVar8 = iVar11 - iVar2;
    if (iVar11 < iVar2) {
        do {
            if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < iVar11)) {
                uVar3 = *(uint64_t *)(arg1 + 0x20);
                uVar10 = uVar3 + (int64_t)iVar11;
                do {
                    if (uVar10 <= uVar3) break;
                    puVar1 = (uint8_t *)(uVar10 - 1);
                    uVar10 = uVar10 - 1;
                } while ((*puVar1 & 0xc0) == 0x80);
                fcn.1800f5c80(&var_10h, uVar3 + (int64_t)iVar11, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar3);
                fcn.1800f5c80(&var_8h);
                if ((((int32_t)var_10h == 0x20) || ((int32_t)var_10h == 9)) || ((int32_t)var_10h == 0x3000)) {
                    bVar4 = true;
                } else {
                    bVar4 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_10h == *piVar9) {
                        bVar6 = true;
                        goto code_r0x000180140655;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar6 = false;
code_r0x000180140655:
                if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
                    bVar5 = true;
                } else {
                    bVar5 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_8h == *piVar9) {
                        bVar7 = true;
                        goto code_r0x000180140687;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar7 = false;
code_r0x000180140687:
                if (bVar4) {
                    if (bVar7) {
code_r0x0001801406a0:
                        if (bVar6) goto code_r0x000180140694;
                    } else if (bVar5) goto code_r0x000180140694;
                    bVar4 = true;
                } else {
                    if (bVar7) goto code_r0x0001801406a0;
code_r0x000180140694:
                    bVar4 = false;
                }
                if (bVar4) break;
            }
            iVar8 = *(int32_t *)(arg1 + 0x18);
            if (iVar11 < iVar8) {
                iVar8 = fcn.1800f5c80(&var_18h, *(int64_t *)(arg1 + 0x20) + (int64_t)iVar11, 
                                      *(int64_t *)(arg1 + 0x20) + (int64_t)iVar8);
                iVar11 = iVar11 + iVar8;
            } else {
                iVar11 = iVar8 + 1;
            }
        } while (iVar11 < iVar2);
        iVar8 = iVar11 - iVar2;
    }
    if (iVar11 != iVar2 && SBORROW4(iVar11, iVar2) == iVar8 < 0) {
        iVar11 = iVar2;
    }
    return iVar11;
}

// ============================================================
// Function: FUN_1801406ef
// Address: 0x1801406ef
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h

int32_t fcn.180140550(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    uint8_t *puVar1;
    int32_t iVar2;
    uint64_t uVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t *piVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar2 = *(int32_t *)(arg1 + 0x18);
    iVar11 = (int32_t)arg2;
    if (iVar11 < iVar2) {
        iVar8 = fcn.1800f5c80(&var_10h, (int64_t)iVar11 + *(int64_t *)(arg1 + 0x20), 
                              (int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        iVar11 = iVar11 + iVar8;
    } else {
        iVar11 = iVar2 + 1;
    }
    iVar8 = iVar11 - iVar2;
    if (iVar11 < iVar2) {
        do {
            if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < iVar11)) {
                uVar3 = *(uint64_t *)(arg1 + 0x20);
                uVar10 = uVar3 + (int64_t)iVar11;
                do {
                    if (uVar10 <= uVar3) break;
                    puVar1 = (uint8_t *)(uVar10 - 1);
                    uVar10 = uVar10 - 1;
                } while ((*puVar1 & 0xc0) == 0x80);
                fcn.1800f5c80(&var_10h, uVar3 + (int64_t)iVar11, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar3);
                fcn.1800f5c80(&var_8h);
                if ((((int32_t)var_10h == 0x20) || ((int32_t)var_10h == 9)) || ((int32_t)var_10h == 0x3000)) {
                    bVar4 = true;
                } else {
                    bVar4 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_10h == *piVar9) {
                        bVar6 = true;
                        goto code_r0x000180140655;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar6 = false;
code_r0x000180140655:
                if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
                    bVar5 = true;
                } else {
                    bVar5 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_8h == *piVar9) {
                        bVar7 = true;
                        goto code_r0x000180140687;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar7 = false;
code_r0x000180140687:
                if (bVar4) {
                    if (bVar7) {
code_r0x0001801406a0:
                        if (bVar6) goto code_r0x000180140694;
                    } else if (bVar5) goto code_r0x000180140694;
                    bVar4 = true;
                } else {
                    if (bVar7) goto code_r0x0001801406a0;
code_r0x000180140694:
                    bVar4 = false;
                }
                if (bVar4) break;
            }
            iVar8 = *(int32_t *)(arg1 + 0x18);
            if (iVar11 < iVar8) {
                iVar8 = fcn.1800f5c80(&var_18h, *(int64_t *)(arg1 + 0x20) + (int64_t)iVar11, 
                                      *(int64_t *)(arg1 + 0x20) + (int64_t)iVar8);
                iVar11 = iVar11 + iVar8;
            } else {
                iVar11 = iVar8 + 1;
            }
        } while (iVar11 < iVar2);
        iVar8 = iVar11 - iVar2;
    }
    if (iVar11 != iVar2 && SBORROW4(iVar11, iVar2) == iVar8 < 0) {
        iVar11 = iVar2;
    }
    return iVar11;
}

// ============================================================
// Function: FUN_180140710
// Address: 0x180140710
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint32_t fcn.180140710(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    uint64_t uVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t *piVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    uint32_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar8 = (int32_t)arg2;
    if (*(char *)(*(int64_t *)arg1 + 0x8d) == '\0') {
        iVar7 = *(int32_t *)(arg1 + 0x18);
        if (iVar8 < iVar7) {
            iVar7 = fcn.1800f5c80(&var_8h, (int64_t)iVar8 + *(int64_t *)(arg1 + 0x20), 
                                  (int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
            uVar10 = iVar8 + iVar7;
        } else {
            uVar10 = iVar7 + 1;
        }
        uVar12 = *(uint32_t *)(arg1 + 0x18);
        iVar8 = uVar10 - uVar12;
        if ((int32_t)uVar10 < (int32_t)uVar12) {
            do {
                iVar8 = fcn.180140380(arg1, (uint64_t)uVar10);
                if (iVar8 != 0) break;
                iVar8 = *(int32_t *)(arg1 + 0x18);
                if ((int32_t)uVar10 < iVar8) {
                    iVar8 = fcn.1800f5c80(&var_8h, (int64_t)(int32_t)uVar10 + *(int64_t *)(arg1 + 0x20), 
                                          (int64_t)iVar8 + *(int64_t *)(arg1 + 0x20));
                    uVar10 = uVar10 + iVar8;
                } else {
                    uVar10 = iVar8 + 1;
                }
            } while ((int32_t)uVar10 < (int32_t)uVar12);
            iVar8 = uVar10 - uVar12;
        }
        if (uVar10 != uVar12 && SBORROW4(uVar10, uVar12) == iVar8 < 0) {
            uVar10 = uVar12;
        }
        return uVar10;
    }
    uVar10 = *(uint32_t *)(arg1 + 0x18);
    if (iVar8 < (int32_t)uVar10) {
        iVar7 = fcn.1800f5c80(&var_10h, (int64_t)iVar8 + *(int64_t *)(arg1 + 0x20), 
                              (int64_t)(int32_t)uVar10 + *(int64_t *)(arg1 + 0x20));
        uVar12 = iVar8 + iVar7;
    } else {
        uVar12 = uVar10 + 1;
    }
    iVar8 = uVar12 - uVar10;
    if ((int32_t)uVar12 < (int32_t)uVar10) {
        do {
            if (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) && (0 < (int32_t)uVar12)) {
                uVar2 = *(uint64_t *)(arg1 + 0x20);
                uVar11 = uVar2 + (int64_t)(int32_t)uVar12;
                do {
                    if (uVar11 <= uVar2) break;
                    puVar1 = (uint8_t *)(uVar11 - 1);
                    uVar11 = uVar11 - 1;
                } while ((*puVar1 & 0xc0) == 0x80);
                fcn.1800f5c80(&var_10h, uVar2 + (int64_t)(int32_t)uVar12, (int64_t)*(int32_t *)(arg1 + 0x18) + uVar2);
                fcn.1800f5c80(&var_8h);
                if ((((int32_t)var_10h == 0x20) || ((int32_t)var_10h == 9)) || ((int32_t)var_10h == 0x3000)) {
                    bVar3 = true;
                } else {
                    bVar3 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_10h == *piVar9) {
                        bVar5 = true;
                        goto code_r0x000180140655;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar5 = false;
code_r0x000180140655:
                if ((((int32_t)var_8h == 0x20) || ((int32_t)var_8h == 9)) || ((int32_t)var_8h == 0x3000)) {
                    bVar4 = true;
                } else {
                    bVar4 = false;
                }
                piVar9 = (int32_t *)0x180645bf0;
                do {
                    if ((int32_t)var_8h == *piVar9) {
                        bVar6 = true;
                        goto code_r0x000180140687;
                    }
                    piVar9 = piVar9 + 1;
                } while (piVar9 != (int32_t *)0x180645c64);
                bVar6 = false;
code_r0x000180140687:
                if (bVar3) {
                    if (bVar6) {
code_r0x0001801406a0:
                        if (bVar5) goto code_r0x000180140694;
                    } else if (bVar4) goto code_r0x000180140694;
                    bVar3 = true;
                } else {
                    if (bVar6) goto code_r0x0001801406a0;
code_r0x000180140694:
                    bVar3 = false;
                }
                if (bVar3) break;
            }
            iVar8 = *(int32_t *)(arg1 + 0x18);
            if ((int32_t)uVar12 < iVar8) {
                iVar8 = fcn.1800f5c80(&var_18h, *(int64_t *)(arg1 + 0x20) + (int64_t)(int32_t)uVar12, 
                                      *(int64_t *)(arg1 + 0x20) + (int64_t)iVar8);
                uVar12 = uVar12 + iVar8;
            } else {
                uVar12 = iVar8 + 1;
            }
        } while ((int32_t)uVar12 < (int32_t)uVar10);
        iVar8 = uVar12 - uVar10;
    }
    if (uVar12 != uVar10 && SBORROW4(uVar12, uVar10) == iVar8 < 0) {
        uVar12 = uVar10;
    }
    return uVar12;
}

// ============================================================
// Function: FUN_1801407d0
// Address: 0x1801407d0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801407d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    char *pcVar2;
    uint64_t uVar3;
    char *pcVar4;
    char *pcVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar9;
    char *pcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar8;
    
    uVar9 = (uint64_t)(int32_t)arg3;
    if (*(char *)(arg2 + 0x17) != '\0') {
        return 0;
    }
    if (0.0 < *(float *)(arg1 + 0x68)) {
        pcVar2 = *(char **)(arg1 + 0x20) + uVar9;
        pcVar5 = pcVar2;
        do {
            pcVar4 = pcVar5;
            pcVar10 = pcVar4;
            if (pcVar4 <= *(char **)(arg1 + 0x20)) break;
            pcVar5 = pcVar4 + -1;
        } while (pcVar4[-1] != '\n');
        do {
            pcVar5 = (char *)fcn.18012f4a0(CONCAT44(var_38h._4_4_, *(undefined4 *)(arg1 + 0x68)), 
                                           CONCAT44(var_30h._4_4_, 2));
            if (pcVar10 == pcVar2) {
code_r0x000180140944:
                return (uint64_t)(uint32_t)((int32_t)pcVar4 - *(int32_t *)(arg1 + 0x20));
            }
            if (pcVar5 == pcVar2) {
                if (*(char *)(uVar9 + *(int64_t *)(arg1 + 0x30)) == '\n') goto code_r0x00018014093d;
                if (*(char *)(arg1 + 0x76) == '\0') goto code_r0x000180140944;
            }
            if (pcVar2 <= pcVar5) {
code_r0x00018014093d:
                return (uint64_t)(uint32_t)((int32_t)pcVar10 - *(int32_t *)(arg1 + 0x20));
            }
            pcVar10 = pcVar5 + 1;
            if (*pcVar5 != '\n') {
                pcVar10 = pcVar5;
            }
        } while (pcVar4 <= pcVar10);
    }
    if (0 < (int32_t)arg3) {
        uVar3 = *(uint64_t *)(arg1 + 0x20);
        do {
            uVar7 = (uVar9 & 0xffffffff) + uVar3;
            do {
                uVar8 = uVar3;
                if (uVar7 <= uVar3) break;
                puVar1 = (uint8_t *)(uVar7 - 1);
                uVar7 = uVar7 - 1;
                uVar8 = uVar7;
            } while ((*puVar1 & 0xc0) == 0x80);
            uVar6 = (int32_t)uVar8 - (int32_t)uVar3;
        } while ((*(char *)((int64_t)(int32_t)uVar6 + uVar3) != '\n') && (uVar9 = (uint64_t)uVar6, 0 < (int32_t)uVar6));
    }
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_1801407f7
// Address: 0x1801407f7
// Size: 326 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801407d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    char *pcVar2;
    uint64_t uVar3;
    char *pcVar4;
    char *pcVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar9;
    char *pcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar8;
    
    uVar9 = (uint64_t)(int32_t)arg3;
    if (*(char *)(arg2 + 0x17) != '\0') {
        return 0;
    }
    if (0.0 < *(float *)(arg1 + 0x68)) {
        pcVar2 = *(char **)(arg1 + 0x20) + uVar9;
        pcVar5 = pcVar2;
        do {
            pcVar4 = pcVar5;
            pcVar10 = pcVar4;
            if (pcVar4 <= *(char **)(arg1 + 0x20)) break;
            pcVar5 = pcVar4 + -1;
        } while (pcVar4[-1] != '\n');
        do {
            pcVar5 = (char *)fcn.18012f4a0(CONCAT44(var_38h._4_4_, *(undefined4 *)(arg1 + 0x68)), 
                                           CONCAT44(var_30h._4_4_, 2));
            if (pcVar10 == pcVar2) {
code_r0x000180140944:
                return (uint64_t)(uint32_t)((int32_t)pcVar4 - *(int32_t *)(arg1 + 0x20));
            }
            if (pcVar5 == pcVar2) {
                if (*(char *)(uVar9 + *(int64_t *)(arg1 + 0x30)) == '\n') goto code_r0x00018014093d;
                if (*(char *)(arg1 + 0x76) == '\0') goto code_r0x000180140944;
            }
            if (pcVar2 <= pcVar5) {
code_r0x00018014093d:
                return (uint64_t)(uint32_t)((int32_t)pcVar10 - *(int32_t *)(arg1 + 0x20));
            }
            pcVar10 = pcVar5 + 1;
            if (*pcVar5 != '\n') {
                pcVar10 = pcVar5;
            }
        } while (pcVar4 <= pcVar10);
    }
    if (0 < (int32_t)arg3) {
        uVar3 = *(uint64_t *)(arg1 + 0x20);
        do {
            uVar7 = (uVar9 & 0xffffffff) + uVar3;
            do {
                uVar8 = uVar3;
                if (uVar7 <= uVar3) break;
                puVar1 = (uint8_t *)(uVar7 - 1);
                uVar7 = uVar7 - 1;
                uVar8 = uVar7;
            } while ((*puVar1 & 0xc0) == 0x80);
            uVar6 = (int32_t)uVar8 - (int32_t)uVar3;
        } while ((*(char *)((int64_t)(int32_t)uVar6 + uVar3) != '\n') && (uVar9 = (uint64_t)uVar6, 0 < (int32_t)uVar6));
    }
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_18014093d
// Address: 0x18014093d
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801407d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    char *pcVar2;
    uint64_t uVar3;
    char *pcVar4;
    char *pcVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar9;
    char *pcVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uVar8;
    
    uVar9 = (uint64_t)(int32_t)arg3;
    if (*(char *)(arg2 + 0x17) != '\0') {
        return 0;
    }
    if (0.0 < *(float *)(arg1 + 0x68)) {
        pcVar2 = *(char **)(arg1 + 0x20) + uVar9;
        pcVar5 = pcVar2;
        do {
            pcVar4 = pcVar5;
            pcVar10 = pcVar4;
            if (pcVar4 <= *(char **)(arg1 + 0x20)) break;
            pcVar5 = pcVar4 + -1;
        } while (pcVar4[-1] != '\n');
        do {
            pcVar5 = (char *)fcn.18012f4a0(CONCAT44(var_38h._4_4_, *(undefined4 *)(arg1 + 0x68)), 
                                           CONCAT44(var_30h._4_4_, 2));
            if (pcVar10 == pcVar2) {
code_r0x000180140944:
                return (uint64_t)(uint32_t)((int32_t)pcVar4 - *(int32_t *)(arg1 + 0x20));
            }
            if (pcVar5 == pcVar2) {
                if (*(char *)(uVar9 + *(int64_t *)(arg1 + 0x30)) == '\n') goto code_r0x00018014093d;
                if (*(char *)(arg1 + 0x76) == '\0') goto code_r0x000180140944;
            }
            if (pcVar2 <= pcVar5) {
code_r0x00018014093d:
                return (uint64_t)(uint32_t)((int32_t)pcVar10 - *(int32_t *)(arg1 + 0x20));
            }
            pcVar10 = pcVar5 + 1;
            if (*pcVar5 != '\n') {
                pcVar10 = pcVar5;
            }
        } while (pcVar4 <= pcVar10);
    }
    if (0 < (int32_t)arg3) {
        uVar3 = *(uint64_t *)(arg1 + 0x20);
        do {
            uVar7 = (uVar9 & 0xffffffff) + uVar3;
            do {
                uVar8 = uVar3;
                if (uVar7 <= uVar3) break;
                puVar1 = (uint8_t *)(uVar7 - 1);
                uVar7 = uVar7 - 1;
                uVar8 = uVar7;
            } while ((*puVar1 & 0xc0) == 0x80);
            uVar6 = (int32_t)uVar8 - (int32_t)uVar3;
        } while ((*(char *)((int64_t)(int32_t)uVar6 + uVar3) != '\n') && (uVar9 = (uint64_t)uVar6, 0 < (int32_t)uVar6));
    }
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_180140950
// Address: 0x180140950
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180140950(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    char *pcVar2;
    char *pcVar3;
    int32_t iVar4;
    char *pcVar5;
    char *pcVar6;
    int32_t iVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined4 in_stack_ffffffffffffffe4;
    
    uVar1 = *(uint32_t *)(arg1 + 0x18);
    uVar9 = (uint64_t)(int32_t)arg3;
    if (*(char *)(arg2 + 0x17) != '\0') {
        return (uint64_t)uVar1;
    }
    if (0.0 < *(float *)(arg1 + 0x68)) {
        pcVar2 = *(char **)(arg1 + 0x20);
        pcVar6 = pcVar2 + uVar9;
        pcVar3 = pcVar6;
        do {
            pcVar5 = pcVar3;
            if (pcVar5 <= pcVar2) break;
            pcVar3 = pcVar5 + -1;
        } while (pcVar5[-1] != '\n');
        while (pcVar5 < pcVar2 + (int32_t)uVar1) {
            pcVar5 = (char *)fcn.18012f4a0(CONCAT44(var_28h._4_4_, *(undefined4 *)(arg1 + 0x68)), 
                                           CONCAT44(in_stack_ffffffffffffffe4, 2));
            uVar9 = (uint64_t)(uint32_t)((int32_t)pcVar5 - *(int32_t *)(arg1 + 0x20));
            if ((pcVar5 == pcVar6) && (*(char *)(arg1 + 0x76) != '\0')) break;
            if (pcVar6 < pcVar5) goto code_r0x000180140a50;
            if (*pcVar5 == '\n') {
                pcVar5 = pcVar5 + 1;
            }
        }
    }
    uVar8 = (uint32_t)uVar9;
    while ((int32_t)uVar8 < (int32_t)uVar1) {
        iVar7 = (int32_t)uVar9;
        pcVar6 = (char *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
        if (*pcVar6 == '\n') break;
        iVar4 = *(int32_t *)(arg1 + 0x18);
        if (iVar7 < iVar4) {
            iVar4 = fcn.1800f5c80(&var_8h, pcVar6, *(int64_t *)(arg1 + 0x20) + (int64_t)iVar4);
            uVar8 = iVar7 + iVar4;
        } else {
            uVar8 = iVar4 + 1;
        }
        uVar9 = (uint64_t)uVar8;
    }
code_r0x000180140a50:
    return uVar9 & 0xffffffff;
}

// ============================================================
// Function: FUN_180140a70
// Address: 0x180140a70
// Size: 264 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.180140a70(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint32_t uVar7;
    int64_t var_8h;
    
    uVar2 = *(uint32_t *)(arg1 + 0x18);
    iVar3 = (int32_t)arg4;
    uVar6 = (uint32_t)arg2;
    uVar7 = *(uint32_t *)(arg1 + 0x10) & 0x400000;
    if (uVar7 == 0) {
        iVar5 = *(int32_t *)(arg1 + 0x58) + ~uVar2;
        if (iVar5 < iVar3) {
            iVar3 = func_0x0001800f5ec0(arg3, arg3 + iVar3, iVar5 + arg3);
            iVar3 = iVar3 - (int32_t)arg3;
        }
    }
    if (iVar3 == 0) {
        return 0;
    }
    if ((*(int32_t *)(arg1 + 0x28) < (int32_t)(uVar2 + 1 + iVar3)) && (uVar7 != 0)) {
        iVar5 = iVar3;
        if (iVar3 < 0x101) {
            iVar5 = 0x100;
        }
        if (iVar3 < 0x20) {
            iVar4 = 0x20;
        } else {
            iVar4 = iVar3;
            if (iVar5 < iVar3) {
                iVar4 = iVar5;
            }
        }
        func_0x00018011f640(arg1 + 0x28, uVar2 + 1 + iVar4);
        *(undefined8 *)(arg1 + 0x20) = *(undefined8 *)(arg1 + 0x30);
    }
    iVar1 = (int64_t)(int32_t)uVar6 + *(int64_t *)(arg1 + 0x30);
    if (uVar6 != uVar2) {
        func_0x000180498030((int64_t)(int32_t)uVar6 + *(int64_t *)(arg1 + 0x30) + (int64_t)iVar3, iVar1, 
                            (int64_t)(int32_t)(uVar2 - uVar6));
    }
    func_0x000180498030(iVar1, arg3, (int64_t)iVar3);
    *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) + iVar3;
    *(undefined2 *)(arg1 + 0x73) = 0x101;
    *(undefined *)((int64_t)*(int32_t *)(arg1 + 0x18) + *(int64_t *)(arg1 + 0x30)) = 0;
    return iVar3;
}

// ============================================================
// Function: FUN_180140b80
// Address: 0x180140b80
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

uint64_t fcn.180140b80(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    float fVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    float var_60h;
    undefined8 var_5ch;
    int64_t var_54h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = *(uint32_t *)(arg1 + 0x18);
    uVar3 = 0;
    var_68h = 0;
    var_5ch = 0;
    fVar9 = 0.0;
    var_54h._0_4_ = 0;
    *(undefined4 *)arg4 = 0;
    if (0 < (int32_t)uVar6) {
        do {
            iVar4 = (int32_t)uVar3;
            fcn.180140080((int64_t)&var_68h, arg1, uVar3);
            iVar2 = (int32_t)var_54h;
            if ((int32_t)var_54h < 1) goto code_r0x000180140c1d;
            if ((iVar4 == 0) && (in_XMM2_Da < (float)var_5ch + fVar9)) {
                return 0;
            }
            if (in_XMM2_Da < var_5ch._4_4_ + fVar9) {
                if (iVar4 < (int32_t)uVar6) {
                    if (in_XMM1_Da < (float)var_68h) {
                        return uVar3;
                    }
                    if ((in_XMM1_Da < var_68h._4_4_) && (uVar6 = 0, fVar9 = (float)var_68h, 0 < (int32_t)var_54h)) {
                        do {
                            fVar8 = (float)fcn.18013fff0(arg1, uVar3, (uint64_t)uVar6);
                            uVar5 = uVar6 + iVar4;
                            if (in_XMM1_Da < fVar8 + fVar9) {
                                *(uint32_t *)arg4 = (uint32_t)(uVar6 != 0);
                                if (in_XMM1_Da < fVar8 * 0.5 + fVar9) {
                                    return (uint64_t)uVar5;
                                }
                                uVar3 = fcn.180140300(arg1, (uint64_t)uVar5);
                                return uVar3;
                            }
                            iVar7 = *(int32_t *)(arg1 + 0x18);
                            if ((int32_t)uVar5 < iVar7) {
                                iVar7 = fcn.1800f5c80(&var_8h, (int64_t)(int32_t)uVar5 + *(int64_t *)(arg1 + 0x20), 
                                                      (int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                                iVar7 = iVar7 + uVar5;
                            } else {
                                iVar7 = iVar7 + 1;
                            }
                            uVar6 = iVar7 - iVar4;
                            fVar9 = fVar8 + fVar9;
                        } while ((int32_t)uVar6 < iVar2);
                    }
                    iVar1 = *(int64_t *)(arg1 + 0x20);
                    uVar6 = iVar2 + iVar4;
                    *(undefined4 *)arg4 = 1;
                    if (*(char *)(iVar1 + -1 + (int64_t)(int32_t)uVar6) == '\n') {
                        uVar6 = uVar6 - 1;
                    }
                    return (uint64_t)uVar6;
                }
                break;
            }
            fVar9 = fVar9 + var_60h;
            uVar3 = (uint64_t)(uint32_t)(iVar4 + (int32_t)var_54h);
        } while (iVar4 + (int32_t)var_54h < (int32_t)uVar6);
    }
    *(undefined4 *)arg4 = 1;
code_r0x000180140c1d:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_180140c4c
// Address: 0x180140c4c
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

uint64_t fcn.180140b80(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    float fVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    float var_60h;
    undefined8 var_5ch;
    int64_t var_54h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = *(uint32_t *)(arg1 + 0x18);
    uVar3 = 0;
    var_68h = 0;
    var_5ch = 0;
    fVar9 = 0.0;
    var_54h._0_4_ = 0;
    *(undefined4 *)arg4 = 0;
    if (0 < (int32_t)uVar6) {
        do {
            iVar4 = (int32_t)uVar3;
            fcn.180140080((int64_t)&var_68h, arg1, uVar3);
            iVar2 = (int32_t)var_54h;
            if ((int32_t)var_54h < 1) goto code_r0x000180140c1d;
            if ((iVar4 == 0) && (in_XMM2_Da < (float)var_5ch + fVar9)) {
                return 0;
            }
            if (in_XMM2_Da < var_5ch._4_4_ + fVar9) {
                if (iVar4 < (int32_t)uVar6) {
                    if (in_XMM1_Da < (float)var_68h) {
                        return uVar3;
                    }
                    if ((in_XMM1_Da < var_68h._4_4_) && (uVar6 = 0, fVar9 = (float)var_68h, 0 < (int32_t)var_54h)) {
                        do {
                            fVar8 = (float)fcn.18013fff0(arg1, uVar3, (uint64_t)uVar6);
                            uVar5 = uVar6 + iVar4;
                            if (in_XMM1_Da < fVar8 + fVar9) {
                                *(uint32_t *)arg4 = (uint32_t)(uVar6 != 0);
                                if (in_XMM1_Da < fVar8 * 0.5 + fVar9) {
                                    return (uint64_t)uVar5;
                                }
                                uVar3 = fcn.180140300(arg1, (uint64_t)uVar5);
                                return uVar3;
                            }
                            iVar7 = *(int32_t *)(arg1 + 0x18);
                            if ((int32_t)uVar5 < iVar7) {
                                iVar7 = fcn.1800f5c80(&var_8h, (int64_t)(int32_t)uVar5 + *(int64_t *)(arg1 + 0x20), 
                                                      (int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                                iVar7 = iVar7 + uVar5;
                            } else {
                                iVar7 = iVar7 + 1;
                            }
                            uVar6 = iVar7 - iVar4;
                            fVar9 = fVar8 + fVar9;
                        } while ((int32_t)uVar6 < iVar2);
                    }
                    iVar1 = *(int64_t *)(arg1 + 0x20);
                    uVar6 = iVar2 + iVar4;
                    *(undefined4 *)arg4 = 1;
                    if (*(char *)(iVar1 + -1 + (int64_t)(int32_t)uVar6) == '\n') {
                        uVar6 = uVar6 - 1;
                    }
                    return (uint64_t)uVar6;
                }
                break;
            }
            fVar9 = fVar9 + var_60h;
            uVar3 = (uint64_t)(uint32_t)(iVar4 + (int32_t)var_54h);
        } while (iVar4 + (int32_t)var_54h < (int32_t)uVar6);
    }
    *(undefined4 *)arg4 = 1;
code_r0x000180140c1d:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_180140cdf
// Address: 0x180140cdf
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

uint64_t fcn.180140b80(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    float fVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    float var_60h;
    undefined8 var_5ch;
    int64_t var_54h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = *(uint32_t *)(arg1 + 0x18);
    uVar3 = 0;
    var_68h = 0;
    var_5ch = 0;
    fVar9 = 0.0;
    var_54h._0_4_ = 0;
    *(undefined4 *)arg4 = 0;
    if (0 < (int32_t)uVar6) {
        do {
            iVar4 = (int32_t)uVar3;
            fcn.180140080((int64_t)&var_68h, arg1, uVar3);
            iVar2 = (int32_t)var_54h;
            if ((int32_t)var_54h < 1) goto code_r0x000180140c1d;
            if ((iVar4 == 0) && (in_XMM2_Da < (float)var_5ch + fVar9)) {
                return 0;
            }
            if (in_XMM2_Da < var_5ch._4_4_ + fVar9) {
                if (iVar4 < (int32_t)uVar6) {
                    if (in_XMM1_Da < (float)var_68h) {
                        return uVar3;
                    }
                    if ((in_XMM1_Da < var_68h._4_4_) && (uVar6 = 0, fVar9 = (float)var_68h, 0 < (int32_t)var_54h)) {
                        do {
                            fVar8 = (float)fcn.18013fff0(arg1, uVar3, (uint64_t)uVar6);
                            uVar5 = uVar6 + iVar4;
                            if (in_XMM1_Da < fVar8 + fVar9) {
                                *(uint32_t *)arg4 = (uint32_t)(uVar6 != 0);
                                if (in_XMM1_Da < fVar8 * 0.5 + fVar9) {
                                    return (uint64_t)uVar5;
                                }
                                uVar3 = fcn.180140300(arg1, (uint64_t)uVar5);
                                return uVar3;
                            }
                            iVar7 = *(int32_t *)(arg1 + 0x18);
                            if ((int32_t)uVar5 < iVar7) {
                                iVar7 = fcn.1800f5c80(&var_8h, (int64_t)(int32_t)uVar5 + *(int64_t *)(arg1 + 0x20), 
                                                      (int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                                iVar7 = iVar7 + uVar5;
                            } else {
                                iVar7 = iVar7 + 1;
                            }
                            uVar6 = iVar7 - iVar4;
                            fVar9 = fVar8 + fVar9;
                        } while ((int32_t)uVar6 < iVar2);
                    }
                    iVar1 = *(int64_t *)(arg1 + 0x20);
                    uVar6 = iVar2 + iVar4;
                    *(undefined4 *)arg4 = 1;
                    if (*(char *)(iVar1 + -1 + (int64_t)(int32_t)uVar6) == '\n') {
                        uVar6 = uVar6 - 1;
                    }
                    return (uint64_t)uVar6;
                }
                break;
            }
            fVar9 = fVar9 + var_60h;
            uVar3 = (uint64_t)(uint32_t)(iVar4 + (int32_t)var_54h);
        } while (iVar4 + (int32_t)var_54h < (int32_t)uVar6);
    }
    *(undefined4 *)arg4 = 1;
code_r0x000180140c1d:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_180140d04
// Address: 0x180140d04
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

uint64_t fcn.180140b80(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    float fVar8;
    float in_XMM1_Da;
    float in_XMM2_Da;
    float fVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_68h;
    float var_60h;
    undefined8 var_5ch;
    int64_t var_54h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = *(uint32_t *)(arg1 + 0x18);
    uVar3 = 0;
    var_68h = 0;
    var_5ch = 0;
    fVar9 = 0.0;
    var_54h._0_4_ = 0;
    *(undefined4 *)arg4 = 0;
    if (0 < (int32_t)uVar6) {
        do {
            iVar4 = (int32_t)uVar3;
            fcn.180140080((int64_t)&var_68h, arg1, uVar3);
            iVar2 = (int32_t)var_54h;
            if ((int32_t)var_54h < 1) goto code_r0x000180140c1d;
            if ((iVar4 == 0) && (in_XMM2_Da < (float)var_5ch + fVar9)) {
                return 0;
            }
            if (in_XMM2_Da < var_5ch._4_4_ + fVar9) {
                if (iVar4 < (int32_t)uVar6) {
                    if (in_XMM1_Da < (float)var_68h) {
                        return uVar3;
                    }
                    if ((in_XMM1_Da < var_68h._4_4_) && (uVar6 = 0, fVar9 = (float)var_68h, 0 < (int32_t)var_54h)) {
                        do {
                            fVar8 = (float)fcn.18013fff0(arg1, uVar3, (uint64_t)uVar6);
                            uVar5 = uVar6 + iVar4;
                            if (in_XMM1_Da < fVar8 + fVar9) {
                                *(uint32_t *)arg4 = (uint32_t)(uVar6 != 0);
                                if (in_XMM1_Da < fVar8 * 0.5 + fVar9) {
                                    return (uint64_t)uVar5;
                                }
                                uVar3 = fcn.180140300(arg1, (uint64_t)uVar5);
                                return uVar3;
                            }
                            iVar7 = *(int32_t *)(arg1 + 0x18);
                            if ((int32_t)uVar5 < iVar7) {
                                iVar7 = fcn.1800f5c80(&var_8h, (int64_t)(int32_t)uVar5 + *(int64_t *)(arg1 + 0x20), 
                                                      (int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                                iVar7 = iVar7 + uVar5;
                            } else {
                                iVar7 = iVar7 + 1;
                            }
                            uVar6 = iVar7 - iVar4;
                            fVar9 = fVar8 + fVar9;
                        } while ((int32_t)uVar6 < iVar2);
                    }
                    iVar1 = *(int64_t *)(arg1 + 0x20);
                    uVar6 = iVar2 + iVar4;
                    *(undefined4 *)arg4 = 1;
                    if (*(char *)(iVar1 + -1 + (int64_t)(int32_t)uVar6) == '\n') {
                        uVar6 = uVar6 - 1;
                    }
                    return (uint64_t)uVar6;
                }
                break;
            }
            fVar9 = fVar9 + var_60h;
            uVar3 = (uint64_t)(uint32_t)(iVar4 + (int32_t)var_54h);
        } while (iVar4 + (int32_t)var_54h < (int32_t)uVar6);
    }
    *(undefined4 *)arg4 = 1;
code_r0x000180140c1d:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_180140d30
// Address: 0x180140d30
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.180140d30(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    int64_t placeholder_1;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_2ch;
    int64_t var_18h;
    
    placeholder_1 = arg2;
    if (*(char *)(arg2 + 0x17) != '\0') {
        in_R8 = 0;
        placeholder_1 = arg1;
        fcn.180140080((int64_t)&var_38h, arg1, 0);
    }
    uVar1 = fcn.180140b80(arg1, placeholder_1, in_R8, (int64_t)&var_8h);
    *(undefined4 *)arg2 = uVar1;
    *(undefined4 *)(arg2 + 4) = uVar1;
    *(undefined4 *)(arg2 + 8) = uVar1;
    *(undefined *)(arg2 + 0x16) = 0;
    *(bool *)(arg1 + 0x76) = (int32_t)var_8h != 0;
    return;
}

// ============================================================
// Function: FUN_180140da0
// Address: 0x180140da0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.180140da0(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    int64_t placeholder_1;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_38h;
    int64_t var_2ch;
    int64_t var_18h;
    
    placeholder_1 = arg2;
    if (*(char *)(arg2 + 0x17) != '\0') {
        in_R8 = 0;
        placeholder_1 = arg1;
        fcn.180140080((int64_t)&var_38h, arg1, 0);
    }
    if (*(int32_t *)(arg2 + 4) == *(int32_t *)(arg2 + 8)) {
        *(undefined4 *)(arg2 + 4) = *(undefined4 *)arg2;
    }
    uVar1 = fcn.180140b80(arg1, placeholder_1, in_R8, (int64_t)&var_8h);
    *(undefined4 *)(arg2 + 8) = uVar1;
    *(undefined4 *)arg2 = uVar1;
    *(bool *)(arg1 + 0x76) = (int32_t)var_8h != 0;
    return;
}

// ============================================================
// Function: FUN_180140e20
// Address: 0x180140e20
// Size: 320 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180140e20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    float var_58h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    
    uVar2 = *(uint32_t *)(arg2 + 0x18);
    uVar8 = (uint32_t)arg3;
    if ((uVar8 == uVar2) && ((int32_t)arg4 != 0)) {
        fcn.180140080((int64_t)&var_68h, arg2, 0);
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        *(uint32_t *)(arg1 + 0x10) = uVar2;
        *(float *)(arg1 + 8) = var_58h - var_60h._4_4_;
        *(undefined4 *)arg1 = var_68h._4_4_;
        return;
    }
    iVar6 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    fcn.180140080((int64_t)&var_68h, arg2, 0);
    uVar1 = 0;
    uVar9 = 0;
    iVar5 = (int32_t)var_54h;
    while( true ) {
        uVar7 = uVar1;
        if (((int32_t)uVar8 < iVar5) ||
           ((((*(char *)(arg2 + 0x76) == '\x01' && (0 < **(int32_t **)(arg2 + 8))) &&
             (**(int32_t **)(arg2 + 8) == (int32_t)var_54h + uVar7)) &&
            (*(char *)(*(int64_t *)(arg2 + 0x20) + -1 + (int64_t)(int32_t)((int32_t)var_54h + uVar7)) != '\n'))))
        goto code_r0x000180140f2e;
        uVar1 = (int32_t)var_54h + uVar7;
        if (((uVar1 == uVar2) && (0 < (int32_t)uVar2)) &&
           (*(char *)(*(int64_t *)(arg2 + 0x20) + -1 + (int64_t)(int32_t)uVar2) != '\n')) goto code_r0x000180140f2e;
        *(float *)(arg1 + 4) = (float)var_60h + *(float *)(arg1 + 4);
        uVar9 = uVar7;
        if (uVar1 == uVar2) break;
        fcn.180140080((int64_t)&var_68h, arg2, (uint64_t)uVar1);
        iVar5 = (int32_t)var_54h + uVar1;
    }
    var_54h._0_4_ = 0;
    uVar7 = uVar1;
code_r0x000180140f2e:
    *(uint32_t *)(arg1 + 0xc) = uVar7;
    *(int32_t *)(arg1 + 0x10) = (int32_t)var_54h;
    *(uint32_t *)(arg1 + 0x14) = uVar9;
    *(float *)(arg1 + 8) = var_58h - var_60h._4_4_;
    *(undefined4 *)arg1 = (undefined4)var_68h;
    if ((int32_t)uVar7 < (int32_t)uVar8) {
        do {
            fcn.1800f5c80(&var_18h, (int64_t)iVar6 + *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar7, 
                          (int64_t)*(int32_t *)(arg2 + 0x18) + *(int64_t *)(arg2 + 0x20));
            if ((int16_t)(uint32_t)var_18h == 10) {
                fVar10 = -1.0;
            } else {
                iVar3 = *(int64_t *)arg2;
                piVar4 = *(int32_t **)(iVar3 + 0x12f0);
                if ((*piVar4 <= (int32_t)((uint32_t)var_18h & 0xffff)) ||
                   (fVar10 = *(float *)(*(int64_t *)(piVar4 + 2) + ((uint64_t)(uint32_t)var_18h & 0xffff) * 4),
                   fVar10 < 0.0)) {
                    fVar10 = (float)fcn.18012bbd0(piVar4);
                }
                fVar10 = fVar10 * *(float *)(iVar3 + 0x1300);
            }
            iVar6 = uVar7 + iVar6;
            *(float *)arg1 = fVar10 + *(float *)arg1;
            iVar5 = *(int32_t *)(arg2 + 0x18);
            if (iVar6 < iVar5) {
                iVar5 = fcn.1800f5c80(&var_10h, (int64_t)iVar6 + *(int64_t *)(arg2 + 0x20), 
                                      (int64_t)iVar5 + *(int64_t *)(arg2 + 0x20));
                iVar5 = iVar5 + iVar6;
            } else {
                iVar5 = iVar5 + 1;
            }
            iVar6 = iVar5 - uVar7;
        } while (iVar5 < (int32_t)uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_180140f60
// Address: 0x180140f60
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180140e20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    float var_58h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    
    uVar2 = *(uint32_t *)(arg2 + 0x18);
    uVar8 = (uint32_t)arg3;
    if ((uVar8 == uVar2) && ((int32_t)arg4 != 0)) {
        fcn.180140080((int64_t)&var_68h, arg2, 0);
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        *(uint32_t *)(arg1 + 0x10) = uVar2;
        *(float *)(arg1 + 8) = var_58h - var_60h._4_4_;
        *(undefined4 *)arg1 = var_68h._4_4_;
        return;
    }
    iVar6 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    fcn.180140080((int64_t)&var_68h, arg2, 0);
    uVar1 = 0;
    uVar9 = 0;
    iVar5 = (int32_t)var_54h;
    while( true ) {
        uVar7 = uVar1;
        if (((int32_t)uVar8 < iVar5) ||
           ((((*(char *)(arg2 + 0x76) == '\x01' && (0 < **(int32_t **)(arg2 + 8))) &&
             (**(int32_t **)(arg2 + 8) == (int32_t)var_54h + uVar7)) &&
            (*(char *)(*(int64_t *)(arg2 + 0x20) + -1 + (int64_t)(int32_t)((int32_t)var_54h + uVar7)) != '\n'))))
        goto code_r0x000180140f2e;
        uVar1 = (int32_t)var_54h + uVar7;
        if (((uVar1 == uVar2) && (0 < (int32_t)uVar2)) &&
           (*(char *)(*(int64_t *)(arg2 + 0x20) + -1 + (int64_t)(int32_t)uVar2) != '\n')) goto code_r0x000180140f2e;
        *(float *)(arg1 + 4) = (float)var_60h + *(float *)(arg1 + 4);
        uVar9 = uVar7;
        if (uVar1 == uVar2) break;
        fcn.180140080((int64_t)&var_68h, arg2, (uint64_t)uVar1);
        iVar5 = (int32_t)var_54h + uVar1;
    }
    var_54h._0_4_ = 0;
    uVar7 = uVar1;
code_r0x000180140f2e:
    *(uint32_t *)(arg1 + 0xc) = uVar7;
    *(int32_t *)(arg1 + 0x10) = (int32_t)var_54h;
    *(uint32_t *)(arg1 + 0x14) = uVar9;
    *(float *)(arg1 + 8) = var_58h - var_60h._4_4_;
    *(undefined4 *)arg1 = (undefined4)var_68h;
    if ((int32_t)uVar7 < (int32_t)uVar8) {
        do {
            fcn.1800f5c80(&var_18h, (int64_t)iVar6 + *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar7, 
                          (int64_t)*(int32_t *)(arg2 + 0x18) + *(int64_t *)(arg2 + 0x20));
            if ((int16_t)(uint32_t)var_18h == 10) {
                fVar10 = -1.0;
            } else {
                iVar3 = *(int64_t *)arg2;
                piVar4 = *(int32_t **)(iVar3 + 0x12f0);
                if ((*piVar4 <= (int32_t)((uint32_t)var_18h & 0xffff)) ||
                   (fVar10 = *(float *)(*(int64_t *)(piVar4 + 2) + ((uint64_t)(uint32_t)var_18h & 0xffff) * 4),
                   fVar10 < 0.0)) {
                    fVar10 = (float)fcn.18012bbd0(piVar4);
                }
                fVar10 = fVar10 * *(float *)(iVar3 + 0x1300);
            }
            iVar6 = uVar7 + iVar6;
            *(float *)arg1 = fVar10 + *(float *)arg1;
            iVar5 = *(int32_t *)(arg2 + 0x18);
            if (iVar6 < iVar5) {
                iVar5 = fcn.1800f5c80(&var_10h, (int64_t)iVar6 + *(int64_t *)(arg2 + 0x20), 
                                      (int64_t)iVar5 + *(int64_t *)(arg2 + 0x20));
                iVar5 = iVar5 + iVar6;
            } else {
                iVar5 = iVar5 + 1;
            }
            iVar6 = iVar5 - uVar7;
        } while (iVar5 < (int32_t)uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_180141032
// Address: 0x180141032
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180140e20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_58h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int32_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    float fVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    float var_58h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_38h;
    
    uVar2 = *(uint32_t *)(arg2 + 0x18);
    uVar8 = (uint32_t)arg3;
    if ((uVar8 == uVar2) && ((int32_t)arg4 != 0)) {
        fcn.180140080((int64_t)&var_68h, arg2, 0);
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        *(uint32_t *)(arg1 + 0x10) = uVar2;
        *(float *)(arg1 + 8) = var_58h - var_60h._4_4_;
        *(undefined4 *)arg1 = var_68h._4_4_;
        return;
    }
    iVar6 = 0;
    *(undefined4 *)(arg1 + 4) = 0;
    fcn.180140080((int64_t)&var_68h, arg2, 0);
    uVar1 = 0;
    uVar9 = 0;
    iVar5 = (int32_t)var_54h;
    while( true ) {
        uVar7 = uVar1;
        if (((int32_t)uVar8 < iVar5) ||
           ((((*(char *)(arg2 + 0x76) == '\x01' && (0 < **(int32_t **)(arg2 + 8))) &&
             (**(int32_t **)(arg2 + 8) == (int32_t)var_54h + uVar7)) &&
            (*(char *)(*(int64_t *)(arg2 + 0x20) + -1 + (int64_t)(int32_t)((int32_t)var_54h + uVar7)) != '\n'))))
        goto code_r0x000180140f2e;
        uVar1 = (int32_t)var_54h + uVar7;
        if (((uVar1 == uVar2) && (0 < (int32_t)uVar2)) &&
           (*(char *)(*(int64_t *)(arg2 + 0x20) + -1 + (int64_t)(int32_t)uVar2) != '\n')) goto code_r0x000180140f2e;
        *(float *)(arg1 + 4) = (float)var_60h + *(float *)(arg1 + 4);
        uVar9 = uVar7;
        if (uVar1 == uVar2) break;
        fcn.180140080((int64_t)&var_68h, arg2, (uint64_t)uVar1);
        iVar5 = (int32_t)var_54h + uVar1;
    }
    var_54h._0_4_ = 0;
    uVar7 = uVar1;
code_r0x000180140f2e:
    *(uint32_t *)(arg1 + 0xc) = uVar7;
    *(int32_t *)(arg1 + 0x10) = (int32_t)var_54h;
    *(uint32_t *)(arg1 + 0x14) = uVar9;
    *(float *)(arg1 + 8) = var_58h - var_60h._4_4_;
    *(undefined4 *)arg1 = (undefined4)var_68h;
    if ((int32_t)uVar7 < (int32_t)uVar8) {
        do {
            fcn.1800f5c80(&var_18h, (int64_t)iVar6 + *(int64_t *)(arg2 + 0x20) + (int64_t)(int32_t)uVar7, 
                          (int64_t)*(int32_t *)(arg2 + 0x18) + *(int64_t *)(arg2 + 0x20));
            if ((int16_t)(uint32_t)var_18h == 10) {
                fVar10 = -1.0;
            } else {
                iVar3 = *(int64_t *)arg2;
                piVar4 = *(int32_t **)(iVar3 + 0x12f0);
                if ((*piVar4 <= (int32_t)((uint32_t)var_18h & 0xffff)) ||
                   (fVar10 = *(float *)(*(int64_t *)(piVar4 + 2) + ((uint64_t)(uint32_t)var_18h & 0xffff) * 4),
                   fVar10 < 0.0)) {
                    fVar10 = (float)fcn.18012bbd0(piVar4);
                }
                fVar10 = fVar10 * *(float *)(iVar3 + 0x1300);
            }
            iVar6 = uVar7 + iVar6;
            *(float *)arg1 = fVar10 + *(float *)arg1;
            iVar5 = *(int32_t *)(arg2 + 0x18);
            if (iVar6 < iVar5) {
                iVar5 = fcn.1800f5c80(&var_10h, (int64_t)iVar6 + *(int64_t *)(arg2 + 0x20), 
                                      (int64_t)iVar5 + *(int64_t *)(arg2 + 0x20));
                iVar5 = iVar5 + iVar6;
            } else {
                iVar5 = iVar5 + 1;
            }
            iVar6 = iVar5 - uVar7;
        } while (iVar5 < (int32_t)uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_180141090
// Address: 0x180141090
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180141090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    int64_t var_8h;
    
    uVar9 = (uint32_t)arg4;
    iVar5 = (int64_t)(int32_t)uVar9;
    iVar7 = (int32_t)arg3;
    piVar3 = (int64_t *)func_0x000180142130(arg2 + 0x20, arg3 & 0xffffffff, arg4 & 0xffffffff, 0);
    if ((piVar3 != (int64_t *)0x0) && (0 < (int32_t)uVar9)) {
        iVar8 = 0;
        if (0xf < uVar9) {
            piVar1 = (int64_t *)(arg1 + 0x20);
            piVar10 = (int64_t *)((int64_t)iVar7 + *piVar1);
            piVar6 = (int64_t *)(iVar5 + -1 + (int64_t)piVar3);
            if ((((int64_t *)((int64_t)(int32_t)((uVar9 - 1) + iVar7) + *piVar1) < piVar3) || (piVar6 < piVar10)) &&
               ((piVar1 < piVar3 || (iVar8 = 0, piVar6 < piVar1)))) {
                func_0x000180498030(piVar3, piVar10, iVar5);
                goto code_r0x000180141133;
            }
        }
        do {
            iVar2 = iVar8 + iVar7;
            iVar4 = (int64_t)iVar8;
            iVar8 = iVar8 + 1;
            *(undefined *)(iVar4 + (int64_t)piVar3) = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        } while (iVar8 < (int32_t)uVar9);
    }
code_r0x000180141133:
    iVar4 = (int64_t)iVar7 + *(int64_t *)(arg1 + 0x30);
    func_0x000180498030(iVar4, iVar4 + iVar5, (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - iVar7) - uVar9) + 1));
    *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar9;
    *(undefined2 *)(arg1 + 0x73) = 0x101;
    *(undefined *)(arg2 + 0x16) = 0;
    return;
}

// ============================================================
// Function: FUN_1801410c6
// Address: 0x1801410c6
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180141090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    int64_t var_8h;
    
    uVar9 = (uint32_t)arg4;
    iVar5 = (int64_t)(int32_t)uVar9;
    iVar7 = (int32_t)arg3;
    piVar3 = (int64_t *)func_0x000180142130(arg2 + 0x20, arg3 & 0xffffffff, arg4 & 0xffffffff, 0);
    if ((piVar3 != (int64_t *)0x0) && (0 < (int32_t)uVar9)) {
        iVar8 = 0;
        if (0xf < uVar9) {
            piVar1 = (int64_t *)(arg1 + 0x20);
            piVar10 = (int64_t *)((int64_t)iVar7 + *piVar1);
            piVar6 = (int64_t *)(iVar5 + -1 + (int64_t)piVar3);
            if ((((int64_t *)((int64_t)(int32_t)((uVar9 - 1) + iVar7) + *piVar1) < piVar3) || (piVar6 < piVar10)) &&
               ((piVar1 < piVar3 || (iVar8 = 0, piVar6 < piVar1)))) {
                func_0x000180498030(piVar3, piVar10, iVar5);
                goto code_r0x000180141133;
            }
        }
        do {
            iVar2 = iVar8 + iVar7;
            iVar4 = (int64_t)iVar8;
            iVar8 = iVar8 + 1;
            *(undefined *)(iVar4 + (int64_t)piVar3) = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        } while (iVar8 < (int32_t)uVar9);
    }
code_r0x000180141133:
    iVar4 = (int64_t)iVar7 + *(int64_t *)(arg1 + 0x30);
    func_0x000180498030(iVar4, iVar4 + iVar5, (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - iVar7) - uVar9) + 1));
    *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar9;
    *(undefined2 *)(arg1 + 0x73) = 0x101;
    *(undefined *)(arg2 + 0x16) = 0;
    return;
}

// ============================================================
// Function: FUN_180141133
// Address: 0x180141133
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180141090(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t *piVar10;
    int64_t var_8h;
    
    uVar9 = (uint32_t)arg4;
    iVar5 = (int64_t)(int32_t)uVar9;
    iVar7 = (int32_t)arg3;
    piVar3 = (int64_t *)func_0x000180142130(arg2 + 0x20, arg3 & 0xffffffff, arg4 & 0xffffffff, 0);
    if ((piVar3 != (int64_t *)0x0) && (0 < (int32_t)uVar9)) {
        iVar8 = 0;
        if (0xf < uVar9) {
            piVar1 = (int64_t *)(arg1 + 0x20);
            piVar10 = (int64_t *)((int64_t)iVar7 + *piVar1);
            piVar6 = (int64_t *)(iVar5 + -1 + (int64_t)piVar3);
            if ((((int64_t *)((int64_t)(int32_t)((uVar9 - 1) + iVar7) + *piVar1) < piVar3) || (piVar6 < piVar10)) &&
               ((piVar1 < piVar3 || (iVar8 = 0, piVar6 < piVar1)))) {
                func_0x000180498030(piVar3, piVar10, iVar5);
                goto code_r0x000180141133;
            }
        }
        do {
            iVar2 = iVar8 + iVar7;
            iVar4 = (int64_t)iVar8;
            iVar8 = iVar8 + 1;
            *(undefined *)(iVar4 + (int64_t)piVar3) = *(undefined *)((int64_t)iVar2 + *(int64_t *)(arg1 + 0x20));
        } while (iVar8 < (int32_t)uVar9);
    }
code_r0x000180141133:
    iVar4 = (int64_t)iVar7 + *(int64_t *)(arg1 + 0x30);
    func_0x000180498030(iVar4, iVar4 + iVar5, (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - iVar7) - uVar9) + 1));
    *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar9;
    *(undefined2 *)(arg1 + 0x73) = 0x101;
    *(undefined *)(arg2 + 0x16) = 0;
    return;
}

// ============================================================
// Function: FUN_180141170
// Address: 0x180141170
// Size: 128 bytes
// ============================================================
void fcn.180141170(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint64_t arg3;
    
    uVar3 = *(uint32_t *)(arg1 + 0x18);
    uVar1 = *(uint32_t *)(arg2 + 8);
    arg3 = (uint64_t)uVar1;
    uVar2 = *(uint32_t *)(arg2 + 4);
    if (uVar2 != uVar1) {
        if ((int32_t)uVar3 < (int32_t)uVar2) {
            *(uint32_t *)(arg2 + 4) = uVar3;
            uVar2 = uVar3;
        }
        if ((int32_t)uVar3 < (int32_t)uVar1) {
            *(uint32_t *)(arg2 + 8) = uVar3;
            arg3 = (uint64_t)uVar3;
        }
        if (uVar2 == (uint32_t)arg3) {
            *(uint32_t *)arg2 = uVar2;
        }
    }
    if ((int32_t)uVar3 < *(int32_t *)arg2) {
        *(uint32_t *)arg2 = uVar3;
    }
    uVar3 = (uint32_t)arg3;
    if (uVar2 != uVar3) {
        if ((int32_t)uVar2 < (int32_t)uVar3) {
            fcn.180141090(arg1, arg2, (uint64_t)uVar2, (uint64_t)(uVar3 - uVar2));
            *(undefined4 *)(arg2 + 8) = *(undefined4 *)(arg2 + 4);
            *(undefined4 *)arg2 = *(undefined4 *)(arg2 + 4);
            *(undefined *)(arg2 + 0x16) = 0;
            return;
        }
        fcn.180141090(arg1, arg2, arg3, (uint64_t)(uVar2 - uVar3));
        *(undefined4 *)(arg2 + 4) = *(undefined4 *)(arg2 + 8);
        *(undefined4 *)arg2 = *(undefined4 *)(arg2 + 8);
        *(undefined *)(arg2 + 0x16) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801411f0
// Address: 0x1801411f0
// Size: 3720 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1801411f0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    int64_t *piVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    float fVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int32_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int32_t iVar15;
    uint32_t uVar16;
    uint32_t uVar17;
    uint64_t uVar18;
    int64_t *piVar19;
    int64_t *piVar20;
    uint32_t uVar21;
    bool bVar22;
    bool bVar23;
    float fVar24;
    float extraout_XMM0_Da;
    float extraout_XMM0_Da_00;
    float fVar25;
    float fVar26;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    int64_t var_8h;
    int64_t var_18h;
    int32_t iStackX_20;
    int64_t var_98h;
    int64_t var_90h;
    uint32_t var_84h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_68h = CONCAT44(unaff_XMM8_Db, unaff_XMM8_Da);
    var_18h._0_4_ = 1;
code_r0x000180141240:
    uVar12 = (uint32_t)arg3;
    if ((int32_t)uVar12 < 0x600001) {
        if (uVar12 == 0x600000) {
            func_0x000180141050(arg1, arg2);
            iVar8 = *(int32_t *)(arg2 + 8);
            if (*(int32_t *)(arg2 + 4) == iVar8) {
                iVar8 = *(int32_t *)arg2;
                *(int32_t *)(arg2 + 8) = iVar8;
                *(int32_t *)(arg2 + 4) = iVar8;
            } else {
                *(int32_t *)arg2 = iVar8;
            }
            if (iVar8 < 1) goto code_r0x000180141fac;
            iVar8 = func_0x000180140340(arg1, iVar8);
            goto code_r0x000180141fa9;
        }
    // switch table (16 cases) at 0x180141ffc
        switch(uVar12) {
        case 0x200000:
            iVar15 = *(int32_t *)(arg2 + 8);
            iVar8 = *(int32_t *)(arg2 + 4);
            bVar23 = SBORROW4(iVar8, iVar15);
            iVar7 = iVar8 - iVar15;
            bVar22 = iVar8 == iVar15;
            if (bVar22) {
                if (*(int32_t *)arg2 < 1) goto code_r0x000180141fae;
                iVar8 = func_0x000180140340(arg1);
                goto code_r0x000180141fac;
            }
            break;
        case 0x200001:
            iVar8 = *(int32_t *)(arg2 + 8);
            iVar15 = *(int32_t *)(arg2 + 4);
            if (iVar15 == iVar8) {
                iVar8 = fcn.180140300(arg1, (uint64_t)*(uint32_t *)arg2);
            } else {
                iVar7 = iVar15;
                if (iVar8 < iVar15) {
                    *(int32_t *)(arg2 + 8) = iVar15;
                    *(int32_t *)(arg2 + 4) = iVar8;
                    iVar7 = iVar8;
                    iVar8 = iVar15;
                }
                iVar15 = *(int32_t *)(arg1 + 0x18);
                if (iVar15 < iVar7) {
                    iVar7 = iVar15;
                }
                if (iVar15 < iVar8) {
                    *(int32_t *)(arg2 + 8) = iVar15;
                    iVar8 = iVar15;
                }
                if (iVar7 == iVar8) {
                    *(int32_t *)arg2 = iVar7;
                }
                if (iVar15 < *(int32_t *)arg2) {
                    *(int32_t *)arg2 = iVar15;
                }
                *(int32_t *)(arg2 + 4) = iVar8;
                *(undefined *)(arg2 + 0x16) = 0;
            }
            *(int32_t *)arg2 = iVar8;
            iVar15 = *(int32_t *)(arg2 + 8);
            iVar7 = *(int32_t *)(arg2 + 4);
            iVar10 = *(int32_t *)(arg1 + 0x18);
            if (iVar7 != iVar15) {
                if (iVar10 < iVar7) {
                    *(int32_t *)(arg2 + 4) = iVar10;
                    iVar7 = iVar10;
                }
                if (iVar10 < iVar15) {
                    *(int32_t *)(arg2 + 8) = iVar10;
                    iVar15 = iVar10;
                }
                if (iVar7 == iVar15) {
                    *(int32_t *)arg2 = iVar7;
                    iVar8 = iVar7;
                }
            }
            if (iVar10 < iVar8) {
                *(int32_t *)arg2 = iVar10;
                *(undefined *)(arg2 + 0x16) = 0;
                return;
            }
            *(undefined *)(arg2 + 0x16) = 0;
            return;
        case 0x200002:
        case 0x20000e:
            goto code_r0x0001801412c8;
        case 0x200003:
        case 0x20000f:
            goto code_r0x000180141293;
        case 0x200004:
            uVar12 = *(uint32_t *)(arg2 + 8);
            uVar18 = (uint64_t)uVar12;
            uVar21 = *(uint32_t *)(arg2 + 4);
            uVar16 = *(uint32_t *)(arg1 + 0x18);
            if (uVar21 != uVar12) {
                if ((int32_t)uVar16 < (int32_t)uVar21) {
                    *(uint32_t *)(arg2 + 4) = uVar16;
                    uVar21 = uVar16;
                }
                if ((int32_t)uVar16 < (int32_t)uVar12) {
                    *(uint32_t *)(arg2 + 8) = uVar16;
                    uVar18 = (uint64_t)uVar16;
                }
                if (uVar21 == (uint32_t)uVar18) {
                    *(uint32_t *)arg2 = uVar21;
                }
            }
            uVar12 = *(uint32_t *)arg2;
            if ((int32_t)uVar16 < (int32_t)uVar12) {
                *(uint32_t *)arg2 = uVar16;
                uVar12 = uVar16;
            }
            uVar16 = (uint32_t)uVar18;
            if (uVar21 == uVar16) {
                iVar8 = fcn.1801407d0(arg1, arg2, (uint64_t)uVar12);
            } else if ((int32_t)uVar16 < (int32_t)uVar21) {
                *(uint32_t *)(arg2 + 4) = uVar16;
                *(uint32_t *)arg2 = uVar16;
                *(uint32_t *)(arg2 + 8) = uVar16;
                *(undefined *)(arg2 + 0x16) = 0;
                iVar8 = fcn.1801407d0(arg1, arg2, uVar18);
            } else {
                *(uint32_t *)arg2 = uVar21;
                *(uint32_t *)(arg2 + 8) = uVar21;
                *(undefined *)(arg2 + 0x16) = 0;
                iVar8 = fcn.1801407d0(arg1, arg2, (uint64_t)uVar21);
            }
            goto code_r0x000180141fac;
        case 0x200005:
            uVar12 = *(uint32_t *)(arg2 + 8);
            uVar21 = *(uint32_t *)(arg2 + 4);
            uVar16 = *(uint32_t *)(arg1 + 0x18);
            if (uVar21 != uVar12) {
                if ((int32_t)uVar16 < (int32_t)uVar21) {
                    *(uint32_t *)(arg2 + 4) = uVar16;
                    uVar21 = uVar16;
                }
                if ((int32_t)uVar16 < (int32_t)uVar12) {
                    *(uint32_t *)(arg2 + 8) = uVar16;
                    uVar12 = uVar16;
                }
                if (uVar21 == uVar12) {
                    *(uint32_t *)arg2 = uVar21;
                }
            }
            uVar11 = *(uint32_t *)arg2;
            if ((int32_t)uVar16 < (int32_t)uVar11) {
                *(uint32_t *)arg2 = uVar16;
                uVar11 = uVar16;
            }
            if (uVar21 != uVar12) {
                if ((int32_t)uVar12 < (int32_t)uVar21) {
                    *(uint32_t *)(arg2 + 8) = uVar21;
                    *(uint32_t *)(arg2 + 4) = uVar12;
                    uVar12 = uVar21;
                }
                uVar21 = *(uint32_t *)(arg1 + 0x18);
                if ((int32_t)uVar21 < (int32_t)uVar12) {
                    *(uint32_t *)(arg2 + 8) = uVar21;
                    uVar12 = uVar21;
                }
                *(uint32_t *)arg2 = uVar12;
                *(uint32_t *)(arg2 + 4) = uVar12;
                *(undefined *)(arg2 + 0x16) = 0;
                uVar11 = uVar12;
            }
            iVar8 = fcn.180140950(arg1, arg2, (uint64_t)uVar11);
            goto code_r0x000180141fac;
        case 0x200006:
            *(undefined8 *)(arg2 + 4) = 0;
            *(undefined4 *)arg2 = 0;
            *(undefined *)(arg2 + 0x16) = 0;
            return;
        case 0x200007:
            uVar3 = *(undefined4 *)(arg1 + 0x18);
            *(undefined8 *)(arg2 + 4) = 0;
            *(undefined *)(arg2 + 0x16) = 0;
            *(undefined4 *)arg2 = uVar3;
            return;
        case 0x200008:
            goto code_r0x000180141ab6;
        case 0x200009:
            goto code_r0x000180141cac;
        case 0x20000a:
            func_0x0001801422c0(arg1, arg2);
            goto code_r0x000180141fae;
        case 0x20000b:
            func_0x000180142550(arg1, arg2);
            goto code_r0x000180141fae;
        case 0x20000c:
            iVar15 = *(int32_t *)(arg2 + 8);
            iVar8 = *(int32_t *)(arg2 + 4);
            bVar23 = SBORROW4(iVar8, iVar15);
            iVar7 = iVar8 - iVar15;
            bVar22 = iVar8 == iVar15;
            if (bVar22) {
                iVar8 = fcn.1801404b0(arg1, (uint64_t)*(uint32_t *)arg2);
                goto code_r0x00018014141f;
            }
            break;
        case 0x20000d:
            iVar15 = *(int32_t *)(arg2 + 8);
            iVar7 = *(int32_t *)(arg2 + 4);
            if (iVar7 == iVar15) {
                iVar8 = fcn.180140710(arg1, (uint64_t)*(uint32_t *)arg2);
code_r0x00018014141f:
                iVar15 = *(int32_t *)(arg2 + 8);
                iVar7 = *(int32_t *)(arg2 + 4);
                *(int32_t *)arg2 = iVar8;
                iVar10 = *(int32_t *)(arg1 + 0x18);
                if (iVar7 == iVar15) goto code_r0x00018014144f;
                if (iVar10 < iVar7) {
                    *(int32_t *)(arg2 + 4) = iVar10;
                    iVar7 = iVar10;
                }
                if (iVar10 < iVar15) goto code_r0x00018014143e;
                goto code_r0x000180141444;
            }
            iVar8 = iVar15;
            if (iVar15 < iVar7) {
                *(int32_t *)(arg2 + 8) = iVar7;
                *(int32_t *)(arg2 + 4) = iVar15;
                iVar8 = iVar7;
                iVar7 = iVar15;
            }
            iVar15 = *(int32_t *)(arg1 + 0x18);
            if (iVar15 < iVar7) {
                iVar7 = iVar15;
            }
            if (iVar15 < iVar8) {
                *(int32_t *)(arg2 + 8) = iVar15;
                iVar8 = iVar15;
            }
            if (iVar7 == iVar8) {
                *(int32_t *)arg2 = iVar7;
            }
            *(int32_t *)(arg2 + 4) = iVar8;
            goto code_r0x000180141fac;
        default:
            goto code_r0x000180141fb2;
        }
        if (!bVar22 && bVar23 == iVar7 < 0) {
            *(int32_t *)(arg2 + 4) = iVar15;
            iVar8 = iVar15;
        }
        goto code_r0x000180141fa9;
    }
    // switch table (15 cases) at 0x18014203c
    switch(uVar12) {
    case 0x600001:
        uVar12 = *(uint32_t *)(arg2 + 8);
        if (*(uint32_t *)(arg2 + 4) == uVar12) {
            uVar12 = *(uint32_t *)arg2;
            *(uint32_t *)(arg2 + 8) = uVar12;
            *(uint32_t *)(arg2 + 4) = uVar12;
        } else {
            *(uint32_t *)arg2 = uVar12;
        }
        iVar15 = fcn.180140300(arg1, (uint64_t)uVar12);
        iVar8 = *(int32_t *)(arg2 + 4);
        *(int32_t *)(arg2 + 8) = iVar15;
        if (iVar8 != iVar15) {
            iVar7 = *(int32_t *)(arg1 + 0x18);
            if (iVar7 < iVar8) {
                *(int32_t *)(arg2 + 4) = iVar7;
                iVar8 = iVar7;
            }
            if (iVar7 < iVar15) {
                *(int32_t *)(arg2 + 8) = iVar7;
                iVar15 = iVar7;
            }
            if (iVar8 == iVar15) {
                *(int32_t *)arg2 = iVar8;
                *(int32_t *)arg2 = iVar15;
                goto code_r0x000180141fae;
            }
        }
        *(int32_t *)arg2 = iVar15;
        goto code_r0x000180141fae;
    case 0x600002:
    case 0x60000e:
code_r0x0001801412c8:
        uVar21 = uVar12 & 0x400000;
        var_98h._0_4_ = uVar21;
        if ((uVar12 & 0xffbfffff) == 0x20000e) {
            var_18h._0_4_ = *(int32_t *)(arg2 + 0x10);
        } else if (*(char *)(arg2 + 0x17) != '\0') {
            arg3 = (int64_t)(uVar21 | 0x200000);
            goto code_r0x000180141240;
        }
        iVar8 = *(int32_t *)(arg2 + 8);
        iVar15 = *(int32_t *)(arg2 + 4);
        if ((arg3 & 0x400000U) == 0) {
            if (iVar15 == iVar8) goto code_r0x0001801417f5;
            if (iVar8 < iVar15) {
                *(int32_t *)(arg2 + 4) = iVar8;
                iVar15 = iVar8;
            }
            *(int32_t *)arg2 = iVar15;
            *(undefined *)(arg2 + 0x16) = 0;
        } else {
            if (iVar15 != iVar8) {
                *(int32_t *)arg2 = iVar8;
                goto code_r0x0001801417f5;
            }
            iVar15 = *(int32_t *)arg2;
            *(int32_t *)(arg2 + 4) = iVar15;
        }
        *(int32_t *)(arg2 + 8) = iVar15;
code_r0x0001801417f5:
        func_0x000180141050(arg1, arg2);
        fcn.180140e20((int64_t)&var_90h, arg1, (uint64_t)*(uint32_t *)arg2, (uint64_t)*(uint8_t *)(arg2 + 0x17), var_68h
                     );
        fVar6 = (float)var_90h;
        if ((int32_t)var_18h < 1) {
            return;
        }
        iStackX_20 = 0;
        uVar12 = var_80h._4_4_;
        uVar16 = var_84h;
        do {
            uVar11 = uVar12;
            fVar26 = fVar6;
            if (*(char *)(arg2 + 0x16) != '\0') {
                fVar26 = *(float *)(arg2 + 0x1c);
            }
            if (uVar11 == uVar16) {
                return;
            }
            *(uint32_t *)arg2 = uVar11;
            fcn.180140080((int64_t)&var_90h, arg1, (uint64_t)uVar11);
            uVar12 = var_80h._4_4_;
            uVar17 = 0;
            fVar25 = (float)var_90h;
            if (0 < (int32_t)var_80h._4_4_) {
                do {
                    fVar24 = (float)fcn.18013fff0(arg1, (uint64_t)uVar11, (uint64_t)uVar17);
                    iVar8 = *(int32_t *)(arg1 + 0x18);
                    iVar15 = *(int32_t *)arg2;
                    if (iVar15 < iVar8) {
                        iVar8 = fcn.1800f5c80((int64_t)&var_98h + 4, (int64_t)iVar15 + *(int64_t *)(arg1 + 0x20), 
                                              (int64_t)iVar8 + *(int64_t *)(arg1 + 0x20));
                        iVar8 = iVar15 + iVar8;
                        fVar24 = extraout_XMM0_Da_00;
                    } else {
                        iVar8 = iVar8 + 1;
                    }
                    uVar21 = (uint32_t)var_98h;
                    if ((fVar24 == -1.0) || (fVar25 = fVar25 + fVar24, fVar26 < fVar25)) break;
                    uVar17 = uVar17 + (iVar8 - *(int32_t *)arg2);
                    *(int32_t *)arg2 = iVar8;
                } while ((int32_t)uVar17 < (int32_t)uVar12);
            }
            uVar12 = *(uint32_t *)(arg2 + 8);
            uVar17 = *(uint32_t *)(arg2 + 4);
            uVar4 = *(uint32_t *)(arg1 + 0x18);
            if (uVar17 != uVar12) {
                if ((int32_t)uVar4 < (int32_t)uVar17) {
                    *(uint32_t *)(arg2 + 4) = uVar4;
                    uVar17 = uVar4;
                }
                if ((int32_t)uVar4 < (int32_t)uVar12) {
                    *(uint32_t *)(arg2 + 8) = uVar4;
                    uVar12 = uVar4;
                }
                if (uVar17 == uVar12) {
                    *(uint32_t *)arg2 = uVar17;
                }
            }
            uVar12 = *(uint32_t *)arg2;
            if ((int32_t)uVar4 < (int32_t)uVar12) {
                *(uint32_t *)arg2 = uVar4;
                uVar12 = uVar4;
            }
            if (uVar12 == uVar16) {
                *(undefined *)(arg1 + 0x76) = 1;
            } else if (uVar12 == uVar11) {
                *(undefined *)(arg1 + 0x76) = 0;
            }
            *(float *)(arg2 + 0x1c) = fVar26;
            *(undefined *)(arg2 + 0x16) = 1;
            if (uVar21 != 0) {
                *(undefined4 *)(arg2 + 8) = *(undefined4 *)arg2;
            }
            if ((int32_t)uVar11 < 1) {
                uVar18 = 0;
            } else {
                uVar18 = (uint64_t)(uVar11 - 1);
                if (0 < (int32_t)(uVar11 - 1)) {
                    uVar5 = *(uint64_t *)(arg1 + 0x20);
                    do {
                        uVar13 = uVar18 + uVar5;
                        do {
                            if (uVar13 <= uVar5) {
                                iVar8 = (int32_t)uVar5;
                                uVar13 = uVar5;
                                goto code_r0x000180141978;
                            }
                            puVar1 = (uint8_t *)(uVar13 - 1);
                            uVar13 = uVar13 - 1;
                        } while ((*puVar1 & 0xc0) == 0x80);
                        iVar8 = (int32_t)*(undefined8 *)(arg1 + 0x20);
code_r0x000180141978:
                        uVar12 = (int32_t)uVar13 - iVar8;
                    } while ((*(char *)((int64_t)(int32_t)uVar12 + uVar5) != '\n') &&
                            (uVar18 = (uint64_t)uVar12, 0 < (int32_t)uVar12));
                }
            }
            uVar12 = fcn.1801407d0(arg1, arg2, uVar18);
            iStackX_20 = iStackX_20 + 1;
            uVar16 = uVar11;
            if ((int32_t)var_18h <= iStackX_20) {
                return;
            }
        } while( true );
    case 0x600003:
    case 0x60000f:
code_r0x000180141293:
        if ((uVar12 & 0xffbfffff) != 0x20000f) {
            if (*(char *)(arg2 + 0x17) == '\0') goto code_r0x00018014160e;
            arg3 = (int64_t)(uVar12 & 0x400000 | 0x200001);
            goto code_r0x000180141240;
        }
        var_18h._0_4_ = *(int32_t *)(arg2 + 0x10);
code_r0x00018014160e:
        iVar8 = *(int32_t *)(arg2 + 8);
        iVar15 = *(int32_t *)(arg2 + 4);
        if ((arg3 & 0x400000U) == 0) {
            if (iVar15 == iVar8) goto code_r0x00018014165e;
            iVar7 = iVar8;
            if (iVar8 < iVar15) {
                *(int32_t *)(arg2 + 8) = iVar15;
                *(int32_t *)(arg2 + 4) = iVar8;
                iVar7 = iVar15;
                iVar15 = iVar8;
            }
            iVar8 = *(int32_t *)(arg1 + 0x18);
            if (iVar8 < iVar15) {
                iVar15 = iVar8;
            }
            if (iVar8 < iVar7) {
                *(int32_t *)(arg2 + 8) = iVar8;
                iVar7 = iVar8;
            }
            if (iVar15 == iVar7) {
                *(int32_t *)arg2 = iVar15;
            }
            *(int32_t *)arg2 = iVar7;
            *(undefined *)(arg2 + 0x16) = 0;
        } else {
            if (iVar15 != iVar8) {
                *(int32_t *)arg2 = iVar8;
                goto code_r0x00018014165e;
            }
            iVar7 = *(int32_t *)arg2;
            *(int32_t *)(arg2 + 8) = iVar7;
        }
        *(int32_t *)(arg2 + 4) = iVar7;
code_r0x00018014165e:
        func_0x000180141050(arg1, arg2);
        fcn.180140e20((int64_t)&var_90h, arg1, (uint64_t)*(uint32_t *)arg2, (uint64_t)*(uint8_t *)(arg2 + 0x17), var_68h
                     );
        fVar6 = (float)var_90h;
        iStackX_20 = 0;
        if ((int32_t)var_18h < 1) {
            return;
        }
        do {
            fVar26 = fVar6;
            if (*(char *)(arg2 + 0x16) != '\0') {
                fVar26 = *(float *)(arg2 + 0x1c);
            }
            if ((uint32_t)var_80h == 0) {
                return;
            }
            uVar21 = var_84h + (uint32_t)var_80h;
            *(uint32_t *)arg2 = uVar21;
            fcn.180140080((int64_t)&var_90h, arg1, (uint64_t)uVar21);
            uVar12 = var_80h._4_4_;
            uVar18 = 0;
            fVar25 = (float)var_90h;
            if (0 < (int32_t)var_80h._4_4_) {
                do {
                    fVar24 = (float)fcn.18013fff0(arg1, (uint64_t)uVar21, uVar18);
                    iVar8 = *(int32_t *)(arg1 + 0x18);
                    iVar15 = *(int32_t *)arg2;
                    if (iVar15 < iVar8) {
                        iVar8 = fcn.1800f5c80(&var_98h, (int64_t)iVar15 + *(int64_t *)(arg1 + 0x20), 
                                              (int64_t)iVar8 + *(int64_t *)(arg1 + 0x20));
                        iVar8 = iVar15 + iVar8;
                        fVar24 = extraout_XMM0_Da;
                    } else {
                        iVar8 = iVar8 + 1;
                    }
                    if ((fVar24 == -1.0) || (fVar25 = fVar25 + fVar24, fVar26 < fVar25)) break;
                    uVar16 = (int32_t)uVar18 + (iVar8 - *(int32_t *)arg2);
                    uVar18 = (uint64_t)uVar16;
                    *(int32_t *)arg2 = iVar8;
                } while ((int32_t)uVar16 < (int32_t)uVar12);
            }
            uVar16 = *(uint32_t *)(arg2 + 8);
            uVar11 = *(uint32_t *)(arg2 + 4);
            uVar17 = *(uint32_t *)(arg1 + 0x18);
            if (uVar11 != uVar16) {
                if ((int32_t)uVar17 < (int32_t)uVar11) {
                    *(uint32_t *)(arg2 + 4) = uVar17;
                    uVar11 = uVar17;
                }
                if ((int32_t)uVar17 < (int32_t)uVar16) {
                    *(uint32_t *)(arg2 + 8) = uVar17;
                    uVar16 = uVar17;
                }
                if (uVar11 == uVar16) {
                    *(uint32_t *)arg2 = uVar11;
                }
            }
            uVar16 = *(uint32_t *)arg2;
            if ((int32_t)uVar17 < (int32_t)uVar16) {
                *(uint32_t *)arg2 = uVar17;
                uVar16 = uVar17;
            }
            if (uVar16 == uVar21) {
                *(undefined *)(arg1 + 0x76) = 0;
            }
            *(float *)(arg2 + 0x1c) = fVar26;
            *(undefined *)(arg2 + 0x16) = 1;
            if ((arg3 & 0x400000U) != 0) {
                *(undefined4 *)(arg2 + 8) = *(undefined4 *)arg2;
            }
            iStackX_20 = iStackX_20 + 1;
            var_80h._0_4_ = uVar12;
            var_84h = uVar21;
            if ((int32_t)var_18h <= iStackX_20) {
                return;
            }
        } while( true );
    case 0x600004:
        uVar12 = *(uint32_t *)(arg2 + 8);
        uVar21 = *(uint32_t *)(arg2 + 4);
        uVar16 = *(uint32_t *)(arg1 + 0x18);
        if (uVar21 != uVar12) {
            if ((int32_t)uVar16 < (int32_t)uVar21) {
                *(uint32_t *)(arg2 + 4) = uVar16;
                uVar21 = uVar16;
            }
            if ((int32_t)uVar16 < (int32_t)uVar12) {
                *(uint32_t *)(arg2 + 8) = uVar16;
                uVar12 = uVar16;
            }
            if (uVar21 == uVar12) {
                *(uint32_t *)arg2 = uVar21;
            }
        }
        uVar11 = *(uint32_t *)arg2;
        if ((int32_t)uVar16 < (int32_t)uVar11) {
            *(uint32_t *)arg2 = uVar16;
            uVar11 = uVar16;
        }
        if (uVar21 == uVar12) {
            *(uint32_t *)(arg2 + 8) = uVar11;
            *(uint32_t *)(arg2 + 4) = uVar11;
            iVar8 = fcn.1801407d0(arg1, arg2, (uint64_t)uVar11);
        } else {
            *(uint32_t *)arg2 = uVar12;
            iVar8 = fcn.1801407d0(arg1, arg2, (uint64_t)uVar12);
        }
        break;
    case 0x600005:
        uVar12 = *(uint32_t *)(arg2 + 8);
        uVar21 = *(uint32_t *)(arg2 + 4);
        uVar16 = *(uint32_t *)(arg1 + 0x18);
        if (uVar21 != uVar12) {
            if ((int32_t)uVar16 < (int32_t)uVar21) {
                *(uint32_t *)(arg2 + 4) = uVar16;
                uVar21 = uVar16;
            }
            if ((int32_t)uVar16 < (int32_t)uVar12) {
                *(uint32_t *)(arg2 + 8) = uVar16;
                uVar12 = uVar16;
            }
            if (uVar21 == uVar12) {
                *(uint32_t *)arg2 = uVar21;
            }
        }
        uVar11 = *(uint32_t *)arg2;
        if ((int32_t)uVar16 < (int32_t)uVar11) {
            *(uint32_t *)arg2 = uVar16;
            uVar11 = uVar16;
        }
        if (uVar21 == uVar12) {
            *(uint32_t *)(arg2 + 8) = uVar11;
            *(uint32_t *)(arg2 + 4) = uVar11;
            uVar12 = uVar11;
        } else {
            *(uint32_t *)arg2 = uVar12;
        }
        iVar8 = fcn.180140950(arg1, arg2, (uint64_t)uVar12);
        break;
    case 0x600006:
        if (*(int32_t *)(arg2 + 4) == *(int32_t *)(arg2 + 8)) {
            *(undefined4 *)(arg2 + 4) = *(undefined4 *)arg2;
        }
        *(undefined4 *)(arg2 + 8) = 0;
        *(undefined4 *)arg2 = 0;
        *(undefined *)(arg2 + 0x16) = 0;
        return;
    case 0x600007:
        if (*(int32_t *)(arg2 + 4) == *(int32_t *)(arg2 + 8)) {
            *(undefined4 *)(arg2 + 8) = *(undefined4 *)arg2;
            *(undefined4 *)(arg2 + 4) = *(undefined4 *)arg2;
            iVar8 = *(int32_t *)(arg1 + 0x18);
        } else {
            *(int32_t *)arg2 = *(int32_t *)(arg2 + 8);
            iVar8 = *(int32_t *)(arg1 + 0x18);
        }
        break;
    case 0x600008:
code_r0x000180141ab6:
        iVar8 = *(int32_t *)(arg2 + 8);
        iVar15 = *(int32_t *)(arg2 + 4);
        if (iVar15 == iVar8) {
            uVar12 = *(uint32_t *)arg2;
            if ((int32_t)uVar12 < *(int32_t *)(arg1 + 0x18)) {
                iVar8 = fcn.180140300(arg1, (uint64_t)uVar12);
                fcn.180141090(arg1, arg2, (uint64_t)*(uint32_t *)arg2, (uint64_t)(iVar8 - uVar12));
            }
            goto code_r0x000180141fae;
        }
        iVar7 = *(int32_t *)(arg1 + 0x18);
        if (iVar7 < iVar15) {
            *(int32_t *)(arg2 + 4) = iVar7;
            iVar15 = iVar7;
        }
        if (iVar7 < iVar8) {
            *(int32_t *)(arg2 + 8) = iVar7;
            iVar8 = iVar7;
        }
        if (iVar15 == iVar8) {
            *(int32_t *)arg2 = iVar15;
        }
        if (iVar7 < *(int32_t *)arg2) {
            *(int32_t *)arg2 = iVar7;
        }
        if (iVar15 == iVar8) goto code_r0x000180141fae;
        if (iVar8 <= iVar15) {
            uVar12 = iVar15 - iVar8;
            piVar9 = (int64_t *)func_0x000180142130(arg2 + 0x20, iVar8, uVar12, 0);
            if ((piVar9 == (int64_t *)0x0) || ((int32_t)uVar12 < 1)) goto code_r0x000180141c4c;
            iVar15 = 0;
            if (uVar12 < 0x10) goto code_r0x000180141c30;
            piVar19 = (int64_t *)((int64_t)iVar8 + *(int64_t *)(arg1 + 0x20));
            piVar2 = (int64_t *)(arg1 + 0x20);
            piVar20 = (int64_t *)((int64_t)(int32_t)(uVar12 - 1) + (int64_t)piVar9);
            if ((((int64_t *)((int64_t)(int32_t)((uVar12 - 1) + iVar8) + *piVar2) < piVar9) || (piVar20 < piVar19)) &&
               ((piVar2 < piVar9 || (piVar20 < piVar2)))) {
                func_0x000180498030(piVar9, piVar19, (int64_t)(int32_t)uVar12);
            } else {
code_r0x000180141c30:
                do {
                    iVar7 = iVar15 + iVar8;
                    iVar14 = (int64_t)iVar15;
                    iVar15 = iVar15 + 1;
                    *(undefined *)(iVar14 + (int64_t)piVar9) =
                         *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                } while (iVar15 < (int32_t)uVar12);
            }
code_r0x000180141c4c:
            iVar14 = (int64_t)iVar8 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar14, (int32_t)uVar12 + iVar14, 
                                (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - uVar12) - iVar8) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar12;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
            iVar8 = *(int32_t *)(arg2 + 8);
            *(int32_t *)(arg2 + 4) = iVar8;
            goto code_r0x000180141fac;
        }
        uVar12 = iVar8 - iVar15;
        piVar9 = (int64_t *)func_0x000180142130(arg2 + 0x20, iVar15, uVar12, 0);
        if ((piVar9 == (int64_t *)0x0) || ((int32_t)uVar12 < 1)) goto code_r0x000180141b8c;
        iVar8 = 0;
        if (uVar12 < 0x10) goto code_r0x000180141b70;
        piVar19 = (int64_t *)((int64_t)iVar15 + *(int64_t *)(arg1 + 0x20));
        piVar2 = (int64_t *)(arg1 + 0x20);
        piVar20 = (int64_t *)((int64_t)(int32_t)(uVar12 - 1) + (int64_t)piVar9);
        if ((((int64_t *)((int64_t)(int32_t)((uVar12 - 1) + iVar15) + *piVar2) < piVar9) || (piVar20 < piVar19)) &&
           ((piVar2 < piVar9 || (piVar20 < piVar2)))) {
            func_0x000180498030(piVar9, piVar19, (int64_t)(int32_t)uVar12);
        } else {
code_r0x000180141b70:
            do {
                iVar7 = iVar8 + iVar15;
                iVar14 = (int64_t)iVar8;
                iVar8 = iVar8 + 1;
                *(undefined *)(iVar14 + (int64_t)piVar9) = *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
            } while (iVar8 < (int32_t)uVar12);
        }
code_r0x000180141b8c:
        iVar14 = (int64_t)iVar15 + *(int64_t *)(arg1 + 0x30);
        func_0x000180498030(iVar14, (int32_t)uVar12 + iVar14, 
                            (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - uVar12) - iVar15) + 1));
        *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar12;
        *(undefined2 *)(arg1 + 0x73) = 0x101;
        iVar8 = *(int32_t *)(arg2 + 4);
        break;
    case 0x600009:
code_r0x000180141cac:
        iVar8 = *(int32_t *)(arg2 + 8);
        iVar15 = *(int32_t *)(arg2 + 4);
        iVar7 = *(int32_t *)(arg1 + 0x18);
        if (iVar15 == iVar8) {
            iVar8 = *(int32_t *)arg2;
            if (iVar7 < iVar8) {
                *(int32_t *)arg2 = iVar7;
                iVar8 = iVar7;
            }
            if (0 < iVar8) {
                uVar12 = func_0x000180140340(arg1, iVar8);
                fcn.180141090(arg1, arg2, (uint64_t)uVar12, (uint64_t)(iVar8 - uVar12));
                *(uint32_t *)arg2 = uVar12;
            }
            goto code_r0x000180141fae;
        }
        if (iVar7 < iVar15) {
            *(int32_t *)(arg2 + 4) = iVar7;
            iVar15 = iVar7;
        }
        if (iVar7 < iVar8) {
            *(int32_t *)(arg2 + 8) = iVar7;
            iVar8 = iVar7;
        }
        if (iVar15 == iVar8) {
            *(int32_t *)arg2 = iVar15;
        }
        if (iVar7 < *(int32_t *)arg2) {
            *(int32_t *)arg2 = iVar7;
        }
        if (iVar15 == iVar8) goto code_r0x000180141fae;
        if (iVar8 <= iVar15) {
            uVar12 = iVar15 - iVar8;
            piVar9 = (int64_t *)func_0x000180142130(arg2 + 0x20, iVar8, uVar12, 0);
            if ((piVar9 == (int64_t *)0x0) || ((int32_t)uVar12 < 1)) goto code_r0x000180141e3c;
            iVar15 = 0;
            if (uVar12 < 0x10) goto code_r0x000180141e20;
            piVar19 = (int64_t *)((int64_t)iVar8 + *(int64_t *)(arg1 + 0x20));
            piVar2 = (int64_t *)(arg1 + 0x20);
            piVar20 = (int64_t *)((int64_t)(int32_t)(uVar12 - 1) + (int64_t)piVar9);
            if ((((int64_t *)((int64_t)(int32_t)((uVar12 - 1) + iVar8) + *piVar2) < piVar9) || (piVar20 < piVar19)) &&
               ((piVar2 < piVar9 || (piVar20 < piVar2)))) {
                func_0x000180498030(piVar9, piVar19, (int64_t)(int32_t)uVar12);
            } else {
code_r0x000180141e20:
                do {
                    iVar7 = iVar15 + iVar8;
                    iVar14 = (int64_t)iVar15;
                    iVar15 = iVar15 + 1;
                    *(undefined *)(iVar14 + (int64_t)piVar9) =
                         *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
                } while (iVar15 < (int32_t)uVar12);
            }
code_r0x000180141e3c:
            iVar14 = (int64_t)iVar8 + *(int64_t *)(arg1 + 0x30);
            func_0x000180498030(iVar14, (int32_t)uVar12 + iVar14, 
                                (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - uVar12) - iVar8) + 1));
            *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar12;
            *(undefined2 *)(arg1 + 0x73) = 0x101;
            iVar8 = *(int32_t *)(arg2 + 8);
            *(int32_t *)(arg2 + 4) = iVar8;
            goto code_r0x000180141fac;
        }
        uVar12 = iVar8 - iVar15;
        piVar9 = (int64_t *)func_0x000180142130(arg2 + 0x20, iVar15, uVar12, 0);
        if ((piVar9 == (int64_t *)0x0) || ((int32_t)uVar12 < 1)) goto code_r0x000180141d7d;
        iVar8 = 0;
        if (uVar12 < 0x10) goto code_r0x000180141d61;
        piVar19 = (int64_t *)((int64_t)iVar15 + *(int64_t *)(arg1 + 0x20));
        piVar2 = (int64_t *)(arg1 + 0x20);
        piVar20 = (int64_t *)((int64_t)(int32_t)(uVar12 - 1) + (int64_t)piVar9);
        if ((((int64_t *)((int64_t)(int32_t)((uVar12 - 1) + iVar15) + *piVar2) < piVar9) || (piVar20 < piVar19)) &&
           ((piVar2 < piVar9 || (piVar20 < piVar2)))) {
            func_0x000180498030(piVar9, piVar19, (int64_t)(int32_t)uVar12);
        } else {
code_r0x000180141d61:
            do {
                iVar7 = iVar8 + iVar15;
                iVar14 = (int64_t)iVar8;
                iVar8 = iVar8 + 1;
                *(undefined *)(iVar14 + (int64_t)piVar9) = *(undefined *)((int64_t)iVar7 + *(int64_t *)(arg1 + 0x20));
            } while (iVar8 < (int32_t)uVar12);
        }
code_r0x000180141d7d:
        iVar14 = (int64_t)iVar15 + *(int64_t *)(arg1 + 0x30);
        func_0x000180498030(iVar14, (int32_t)uVar12 + iVar14, 
                            (int64_t)(int32_t)(((*(int32_t *)(arg1 + 0x18) - uVar12) - iVar15) + 1));
        *(int32_t *)(arg1 + 0x18) = *(int32_t *)(arg1 + 0x18) - uVar12;
        *(undefined2 *)(arg1 + 0x73) = 0x101;
        iVar8 = *(int32_t *)(arg2 + 4);
        break;
    default:
        goto code_r0x000180141fb2;
    case 0x60000c:
        if (*(int32_t *)(arg2 + 4) == *(int32_t *)(arg2 + 8)) {
            *(undefined4 *)(arg2 + 8) = *(undefined4 *)arg2;
            *(undefined4 *)(arg2 + 4) = *(undefined4 *)arg2;
        }
        iVar8 = fcn.1801404b0(arg1, (uint64_t)*(uint32_t *)arg2);
        iVar15 = *(int32_t *)(arg2 + 4);
        *(int32_t *)arg2 = iVar8;
        *(int32_t *)(arg2 + 8) = iVar8;
        iVar10 = *(int32_t *)(arg1 + 0x18);
        if (iVar15 != iVar8) {
            if (iVar10 < iVar15) {
                *(int32_t *)(arg2 + 4) = iVar10;
                iVar15 = iVar10;
            }
            iVar7 = iVar8;
            if (iVar10 < iVar8) {
                *(int32_t *)(arg2 + 8) = iVar10;
                iVar7 = iVar10;
            }
            if (iVar15 == iVar7) {
                *(int32_t *)arg2 = iVar15;
                iVar8 = iVar15;
            }
        }
        goto code_r0x00018014144f;
    case 0x60000d:
        if (*(int32_t *)(arg2 + 4) == *(int32_t *)(arg2 + 8)) {
            *(undefined4 *)(arg2 + 8) = *(undefined4 *)arg2;
            *(undefined4 *)(arg2 + 4) = *(undefined4 *)arg2;
        }
        iVar15 = fcn.180140710(arg1, (uint64_t)*(uint32_t *)arg2);
        iVar7 = *(int32_t *)(arg2 + 4);
        *(int32_t *)arg2 = iVar15;
        *(int32_t *)(arg2 + 8) = iVar15;
        iVar10 = *(int32_t *)(arg1 + 0x18);
        iVar8 = iVar15;
        if (iVar7 == iVar15) goto code_r0x00018014144f;
        if (iVar10 < iVar7) {
            *(int32_t *)(arg2 + 4) = iVar10;
            iVar7 = iVar10;
        }
        if (iVar10 < iVar15) {
code_r0x00018014143e:
            iVar15 = iVar10;
            *(int32_t *)(arg2 + 8) = iVar15;
            iVar10 = iVar15;
        }
code_r0x000180141444:
        if (iVar7 == iVar15) {
            *(int32_t *)arg2 = iVar7;
            iVar8 = iVar7;
        }
code_r0x00018014144f:
        if (iVar8 <= iVar10) {
            return;
        }
        *(int32_t *)arg2 = iVar10;
        return;
    }
code_r0x000180141fa9:
    *(int32_t *)(arg2 + 8) = iVar8;
code_r0x000180141fac:
    *(int32_t *)arg2 = iVar8;
code_r0x000180141fae:
    *(undefined *)(arg2 + 0x16) = 0;
code_r0x000180141fb2:
    return;
}

// ============================================================
// Function: FUN_180142080
// Address: 0x180142080
// Size: 31 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801420c6: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801420cb)
// WARNING: Removing unreachable block (ram,0x0001801420db)
// WARNING: Removing unreachable block (ram,0x0001801420e0)
// WARNING: Removing unreachable block (ram,0x0001801420ee)
// WARNING: Removing unreachable block (ram,0x0001801420f4)
// WARNING: Removing unreachable block (ram,0x000180142101)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180142080(int64_t arg1, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined (*pauVar13) [32];
    undefined (*pauVar14) [32];
    undefined4 *puVar15;
    undefined4 *puVar16;
    int16_t iVar17;
    undefined (*pauVar18) [32];
    undefined (*pauVar19) [32];
    undefined4 *puVar20;
    undefined8 unaff_RSI;
    int64_t unaff_RDI;
    uint64_t uVar21;
    uint64_t uVar22;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar23;
    undefined4 uVar24;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined auVar25 [32];
    undefined auVar29 [32];
    undefined auVar30 [32];
    undefined auVar31 [32];
    undefined auVar32 [32];
    undefined auVar33 [32];
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    if (*(int16_t *)(arg1 + 0xa18) < 1) {
        return;
    }
    if (*(int32_t *)(arg1 + 0xc) < 0) {
        iVar17 = *(int16_t *)(arg1 + 0xa18) + -1;
        *(int16_t *)(arg1 + 0xa18) = iVar17;
        pauVar18 = (undefined (*) [32])(arg1 + 0x10);
        uVar21 = (int64_t)iVar17 << 4;
    } else {
        unaff_RDI = (int64_t)*(int32_t *)(arg1 + 4);
        *(int32_t *)(arg1 + 0xa1c) = *(int32_t *)(arg1 + 0xa1c) - *(int32_t *)(arg1 + 4);
        uVar21 = (uint64_t)*(int32_t *)(arg1 + 0xa1c);
        pauVar18 = (undefined (*) [32])(unaff_RDI + 0x630 + arg1);
        arg1 = arg1 + 0x630;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x1801420cb;
    }
    if (uVar21 < 0x10) {
        UNRECOVERED_JUMPTABLE = (code *)((uint64_t)*(uint32_t *)(uVar21 * 4 + 0x180650960) + 0x180000000);
    // WARNING: Could not recover jumptable at 0x00018049805b. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (16 cases) at 0x180650960
        (*UNRECOVERED_JUMPTABLE)(arg1, pauVar18, uVar21, UNRECOVERED_JUMPTABLE);
        return;
    }
    if (uVar21 < 0x21) {
        uVar2 = *(undefined4 *)(*pauVar18 + 4);
        uVar3 = *(undefined4 *)(*pauVar18 + 8);
        uVar4 = *(undefined4 *)(*pauVar18 + 0xc);
        puVar15 = (undefined4 *)(pauVar18[-1] + uVar21 + 0x10);
        uVar5 = *puVar15;
        uVar6 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        *(undefined4 *)(undefined *)arg1 = *(undefined4 *)*pauVar18;
        *(undefined4 *)((undefined *)arg1 + 4) = uVar2;
        *(undefined4 *)((undefined *)arg1 + 8) = uVar3;
        *(undefined4 *)((undefined *)arg1 + 0xc) = uVar4;
        puVar15 = (undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x10);
        *puVar15 = uVar5;
        puVar15[1] = uVar6;
        puVar15[2] = uVar7;
        puVar15[3] = uVar8;
        return;
    }
    pauVar13 = (undefined (*) [32])(*pauVar18 + uVar21);
    if ((uint64_t)arg1 <= pauVar18) {
        pauVar13 = (undefined (*) [32])arg1;
    }
    if ((uint64_t)arg1 < pauVar13) {
        uVar2 = *(undefined4 *)*pauVar18;
        uVar3 = *(undefined4 *)(*pauVar18 + 4);
        uVar4 = *(undefined4 *)(*pauVar18 + 8);
        uVar5 = *(undefined4 *)(*pauVar18 + 0xc);
        iVar23 = (int64_t)pauVar18 - arg1;
        puVar15 = (undefined4 *)(arg1 + iVar23 + (uVar21 - 0x10));
        uVar6 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        puVar16 = (undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x10);
        uVar22 = uVar21 - 0x10;
        puVar20 = puVar16;
        uVar24 = *puVar15;
        uVar26 = uVar6;
        uVar27 = uVar7;
        uVar28 = uVar8;
        if (((uint64_t)puVar16 & 0xf) != 0) {
            puVar20 = (undefined4 *)((uint64_t)puVar16 & 0xfffffffffffffff0);
            puVar1 = (undefined4 *)((int64_t)puVar20 + iVar23);
            uVar24 = *puVar1;
            uVar26 = puVar1[1];
            uVar27 = puVar1[2];
            uVar28 = puVar1[3];
            *puVar16 = *puVar15;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x14) = uVar6;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x18) = uVar7;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x1c) = uVar8;
            uVar22 = (int64_t)puVar20 - arg1;
        }
        uVar21 = uVar22 >> 7;
        if (uVar21 != 0) {
            *puVar20 = uVar24;
            puVar20[1] = uVar26;
            puVar20[2] = uVar27;
            puVar20[3] = uVar28;
            puVar15 = puVar20;
            while( true ) {
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x10);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar20 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x20);
                uVar24 = *puVar20;
                uVar26 = puVar20[1];
                uVar27 = puVar20[2];
                uVar28 = puVar20[3];
                puVar20 = puVar15 + -0x20;
                puVar15[-4] = *puVar16;
                puVar15[-3] = uVar6;
                puVar15[-2] = uVar7;
                puVar15[-1] = uVar8;
                puVar15[-8] = uVar24;
                puVar15[-7] = uVar26;
                puVar15[-6] = uVar27;
                puVar15[-5] = uVar28;
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x30);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x40);
                uVar24 = *puVar1;
                uVar26 = puVar1[1];
                uVar27 = puVar1[2];
                uVar28 = puVar1[3];
                uVar21 = uVar21 - 1;
                puVar15[-0xc] = *puVar16;
                puVar15[-0xb] = uVar6;
                puVar15[-10] = uVar7;
                puVar15[-9] = uVar8;
                puVar15[-0x10] = uVar24;
                puVar15[-0xf] = uVar26;
                puVar15[-0xe] = uVar27;
                puVar15[-0xd] = uVar28;
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x50);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x60);
                uVar24 = *puVar1;
                uVar26 = puVar1[1];
                uVar27 = puVar1[2];
                uVar28 = puVar1[3];
                puVar15[-0x14] = *puVar16;
                puVar15[-0x13] = uVar6;
                puVar15[-0x12] = uVar7;
                puVar15[-0x11] = uVar8;
                puVar15[-0x18] = uVar24;
                puVar15[-0x17] = uVar26;
                puVar15[-0x16] = uVar27;
                puVar15[-0x15] = uVar28;
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x70);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                puVar16 = (undefined4 *)((int64_t)puVar20 + iVar23);
                uVar24 = *puVar16;
                uVar26 = puVar16[1];
                uVar27 = puVar16[2];
                uVar28 = puVar16[3];
                if (uVar21 == 0) break;
                puVar15[-0x1c] = *puVar1;
                puVar15[-0x1b] = uVar6;
                puVar15[-0x1a] = uVar7;
                puVar15[-0x19] = uVar8;
                *puVar20 = uVar24;
                puVar15[-0x1f] = uVar26;
                puVar15[-0x1e] = uVar27;
                puVar15[-0x1d] = uVar28;
                puVar15 = puVar20;
            }
            puVar15[-0x1c] = *puVar1;
            puVar15[-0x1b] = uVar6;
            puVar15[-0x1a] = uVar7;
            puVar15[-0x19] = uVar8;
            uVar22 = uVar22 & 0x7f;
        }
        for (uVar21 = uVar22 >> 4; uVar21 != 0; uVar21 = uVar21 - 1) {
            *puVar20 = uVar24;
            puVar20[1] = uVar26;
            puVar20[2] = uVar27;
            puVar20[3] = uVar28;
            puVar20 = puVar20 + -4;
            puVar15 = (undefined4 *)((int64_t)puVar20 + iVar23);
            uVar24 = *puVar15;
            uVar26 = puVar15[1];
            uVar27 = puVar15[2];
            uVar28 = puVar15[3];
        }
        if ((uVar22 & 0xf) != 0) {
            *(undefined4 *)(undefined *)arg1 = uVar2;
            *(undefined4 *)((undefined *)arg1 + 4) = uVar3;
            *(undefined4 *)((undefined *)arg1 + 8) = uVar4;
            *(undefined4 *)((undefined *)arg1 + 0xc) = uVar5;
        }
        *puVar20 = uVar24;
        puVar20[1] = uVar26;
        puVar20[2] = uVar27;
        puVar20[3] = uVar28;
        return;
    }
    if (2 < *(uint32_t *)0x1806a3990) {
        if ((0x2000 < uVar21) && (uVar21 < 0x180001)) {
            pauVar13 = (undefined (*) [32])(arg1 + 0x40);
            if (pauVar18 < (uint64_t)arg1) {
                pauVar13 = pauVar18;
            }
            if ((pauVar13 <= pauVar18) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
        }
        auVar25 = vmovdqu_avx(*pauVar18);
        auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar18[-1] + uVar21));
        if (0x100 < uVar21) {
            iVar23 = (arg1 & 0x1fU) - 0x20;
            pauVar13 = (undefined (*) [32])(arg1 - iVar23);
            pauVar18 = (undefined (*) [32])((int64_t)pauVar18 - iVar23);
            uVar21 = uVar21 + iVar23;
            if (0x100 < uVar21) {
                if (0x180000 < uVar21) {
                    do {
                        uVar22 = uVar21;
                        pauVar19 = pauVar18;
                        pauVar14 = pauVar13;
                        auVar29 = vmovdqu_avx(*pauVar19);
                        auVar31 = vmovdqu_avx(pauVar19[1]);
                        auVar30 = vmovdqu_avx(pauVar19[2]);
                        auVar32 = vmovdqu_avx(pauVar19[3]);
                        auVar29 = vmovntdq_avx(auVar29);
                        *pauVar14 = auVar29;
                        auVar29 = vmovntdq_avx(auVar31);
                        pauVar14[1] = auVar29;
                        auVar29 = vmovntdq_avx(auVar30);
                        pauVar14[2] = auVar29;
                        auVar29 = vmovntdq_avx(auVar32);
                        pauVar14[3] = auVar29;
                        auVar29 = vmovdqu_avx(pauVar19[4]);
                        auVar31 = vmovdqu_avx(pauVar19[5]);
                        auVar30 = vmovdqu_avx(pauVar19[6]);
                        auVar32 = vmovdqu_avx(pauVar19[7]);
                        auVar29 = vmovntdq_avx(auVar29);
                        pauVar14[4] = auVar29;
                        auVar29 = vmovntdq_avx(auVar31);
                        pauVar14[5] = auVar29;
                        auVar29 = vmovntdq_avx(auVar30);
                        pauVar14[6] = auVar29;
                        auVar29 = vmovntdq_avx(auVar32);
                        pauVar14[7] = auVar29;
                        pauVar13 = pauVar14 + 8;
                        pauVar18 = pauVar19 + 8;
                        uVar21 = uVar22 - 0x100;
                    } while (0xff < uVar22 - 0x100);
                    uVar21 = uVar22 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                    switch(uVar22) {
                    case 0x1e1:
                    case 0x1e2:
                    case 0x1e3:
                    case 0x1e4:
                    case 0x1e5:
                    case 0x1e6:
                    case 0x1e7:
                    case 0x1e8:
                    case 0x1e9:
                    case 0x1ea:
                    case 0x1eb:
                    case 0x1ec:
                    case 0x1ed:
                    case 0x1ee:
                    case 0x1ef:
                    case 0x1f0:
                    case 0x1f1:
                    case 0x1f2:
                    case 499:
                    case 500:
                    case 0x1f5:
                    case 0x1f6:
                    case 0x1f7:
                    case 0x1f8:
                    case 0x1f9:
                    case 0x1fa:
                    case 0x1fb:
                    case 0x1fc:
                    case 0x1fd:
                    case 0x1fe:
                    case 0x1ff:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(*pauVar19 + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(*pauVar14 + uVar21) = auVar29;
                    case 0x1c1:
                    case 0x1c2:
                    case 0x1c3:
                    case 0x1c4:
                    case 0x1c5:
                    case 0x1c6:
                    case 0x1c7:
                    case 0x1c8:
                    case 0x1c9:
                    case 0x1ca:
                    case 0x1cb:
                    case 0x1cc:
                    case 0x1cd:
                    case 0x1ce:
                    case 0x1cf:
                    case 0x1d0:
                    case 0x1d1:
                    case 0x1d2:
                    case 0x1d3:
                    case 0x1d4:
                    case 0x1d5:
                    case 0x1d6:
                    case 0x1d7:
                    case 0x1d8:
                    case 0x1d9:
                    case 0x1da:
                    case 0x1db:
                    case 0x1dc:
                    case 0x1dd:
                    case 0x1de:
                    case 0x1df:
                    case 0x1e0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[1] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[1] + uVar21) = auVar29;
                    case 0x1a1:
                    case 0x1a2:
                    case 0x1a3:
                    case 0x1a4:
                    case 0x1a5:
                    case 0x1a6:
                    case 0x1a7:
                    case 0x1a8:
                    case 0x1a9:
                    case 0x1aa:
                    case 0x1ab:
                    case 0x1ac:
                    case 0x1ad:
                    case 0x1ae:
                    case 0x1af:
                    case 0x1b0:
                    case 0x1b1:
                    case 0x1b2:
                    case 0x1b3:
                    case 0x1b4:
                    case 0x1b5:
                    case 0x1b6:
                    case 0x1b7:
                    case 0x1b8:
                    case 0x1b9:
                    case 0x1ba:
                    case 0x1bb:
                    case 0x1bc:
                    case 0x1bd:
                    case 0x1be:
                    case 0x1bf:
                    case 0x1c0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[2] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[2] + uVar21) = auVar29;
                    case 0x181:
                    case 0x182:
                    case 0x183:
                    case 0x184:
                    case 0x185:
                    case 0x186:
                    case 0x187:
                    case 0x188:
                    case 0x189:
                    case 0x18a:
                    case 0x18b:
                    case 0x18c:
                    case 0x18d:
                    case 0x18e:
                    case 399:
                    case 400:
                    case 0x191:
                    case 0x192:
                    case 0x193:
                    case 0x194:
                    case 0x195:
                    case 0x196:
                    case 0x197:
                    case 0x198:
                    case 0x199:
                    case 0x19a:
                    case 0x19b:
                    case 0x19c:
                    case 0x19d:
                    case 0x19e:
                    case 0x19f:
                    case 0x1a0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[3] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[3] + uVar21) = auVar29;
                    case 0x161:
                    case 0x162:
                    case 0x163:
                    case 0x164:
                    case 0x165:
                    case 0x166:
                    case 0x167:
                    case 0x168:
                    case 0x169:
                    case 0x16a:
                    case 0x16b:
                    case 0x16c:
                    case 0x16d:
                    case 0x16e:
                    case 0x16f:
                    case 0x170:
                    case 0x171:
                    case 0x172:
                    case 0x173:
                    case 0x174:
                    case 0x175:
                    case 0x176:
                    case 0x177:
                    case 0x178:
                    case 0x179:
                    case 0x17a:
                    case 0x17b:
                    case 0x17c:
                    case 0x17d:
                    case 0x17e:
                    case 0x17f:
                    case 0x180:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[4] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[4] + uVar21) = auVar29;
                    case 0x141:
                    case 0x142:
                    case 0x143:
                    case 0x144:
                    case 0x145:
                    case 0x146:
                    case 0x147:
                    case 0x148:
                    case 0x149:
                    case 0x14a:
                    case 0x14b:
                    case 0x14c:
                    case 0x14d:
                    case 0x14e:
                    case 0x14f:
                    case 0x150:
                    case 0x151:
                    case 0x152:
                    case 0x153:
                    case 0x154:
                    case 0x155:
                    case 0x156:
                    case 0x157:
                    case 0x158:
                    case 0x159:
                    case 0x15a:
                    case 0x15b:
                    case 0x15c:
                    case 0x15d:
                    case 0x15e:
                    case 0x15f:
                    case 0x160:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[5] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[5] + uVar21) = auVar29;
                    case 0x121:
                    case 0x122:
                    case 0x123:
                    case 0x124:
                    case 0x125:
                    case 0x126:
                    case 0x127:
                    case 0x128:
                    case 0x129:
                    case 0x12a:
                    case 299:
                    case 300:
                    case 0x12d:
                    case 0x12e:
                    case 0x12f:
                    case 0x130:
                    case 0x131:
                    case 0x132:
                    case 0x133:
                    case 0x134:
                    case 0x135:
                    case 0x136:
                    case 0x137:
                    case 0x138:
                    case 0x139:
                    case 0x13a:
                    case 0x13b:
                    case 0x13c:
                    case 0x13d:
                    case 0x13e:
                    case 0x13f:
                    case 0x140:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[6] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[6] + uVar21) = auVar29;
                    default:
                        auVar33 = vmovdqu_avx(auVar33);
                        *(undefined (*) [32])(pauVar14[-1] + uVar22) = auVar33;
                    case 0x100:
                        auVar25 = vmovdqu_avx(auVar25);
                        *(undefined (*) [32])arg1 = auVar25;
                        return;
                    }
                }
                do {
                    auVar25 = vmovdqu_avx(*pauVar18);
                    auVar33 = vmovdqu_avx(pauVar18[1]);
                    auVar29 = vmovdqu_avx(pauVar18[2]);
                    auVar31 = vmovdqu_avx(pauVar18[3]);
                    *pauVar13 = auVar25;
                    pauVar13[1] = auVar33;
                    pauVar13[2] = auVar29;
                    pauVar13[3] = auVar31;
                    auVar25 = vmovdqu_avx(pauVar18[4]);
                    auVar33 = vmovdqu_avx(pauVar18[5]);
                    auVar29 = vmovdqu_avx(pauVar18[6]);
                    auVar31 = vmovdqu_avx(pauVar18[7]);
                    pauVar13[4] = auVar25;
                    pauVar13[5] = auVar33;
                    pauVar13[6] = auVar29;
                    pauVar13[7] = auVar31;
                    pauVar13 = pauVar13 + 8;
                    pauVar18 = pauVar18 + 8;
                    uVar21 = uVar21 - 0x100;
                } while (0xff < uVar21);
            }
        }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
        (*(code *)((uint64_t)*(uint32_t *)((uVar21 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
        return;
    }
    if ((uVar21 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
        if (0x80 < uVar21) {
            iVar23 = (arg1 & 0xfU) - 0x10;
            puVar15 = (undefined4 *)(arg1 - iVar23);
            puVar20 = (undefined4 *)((int64_t)pauVar18 - iVar23);
            uVar21 = uVar21 + iVar23;
            if (0x80 < uVar21) {
                do {
                    uVar2 = puVar20[1];
                    uVar3 = puVar20[2];
                    uVar4 = puVar20[3];
                    uVar5 = puVar20[4];
                    uVar6 = puVar20[5];
                    uVar7 = puVar20[6];
                    uVar8 = puVar20[7];
                    uVar24 = puVar20[8];
                    uVar26 = puVar20[9];
                    uVar27 = puVar20[10];
                    uVar28 = puVar20[0xb];
                    uVar9 = puVar20[0xc];
                    uVar10 = puVar20[0xd];
                    uVar11 = puVar20[0xe];
                    uVar12 = puVar20[0xf];
                    *puVar15 = *puVar20;
                    puVar15[1] = uVar2;
                    puVar15[2] = uVar3;
                    puVar15[3] = uVar4;
                    puVar15[4] = uVar5;
                    puVar15[5] = uVar6;
                    puVar15[6] = uVar7;
                    puVar15[7] = uVar8;
                    puVar15[8] = uVar24;
                    puVar15[9] = uVar26;
                    puVar15[10] = uVar27;
                    puVar15[0xb] = uVar28;
                    puVar15[0xc] = uVar9;
                    puVar15[0xd] = uVar10;
                    puVar15[0xe] = uVar11;
                    puVar15[0xf] = uVar12;
                    uVar2 = puVar20[0x11];
                    uVar3 = puVar20[0x12];
                    uVar4 = puVar20[0x13];
                    uVar5 = puVar20[0x14];
                    uVar6 = puVar20[0x15];
                    uVar7 = puVar20[0x16];
                    uVar8 = puVar20[0x17];
                    uVar24 = puVar20[0x18];
                    uVar26 = puVar20[0x19];
                    uVar27 = puVar20[0x1a];
                    uVar28 = puVar20[0x1b];
                    uVar9 = puVar20[0x1c];
                    uVar10 = puVar20[0x1d];
                    uVar11 = puVar20[0x1e];
                    uVar12 = puVar20[0x1f];
                    puVar15[0x10] = puVar20[0x10];
                    puVar15[0x11] = uVar2;
                    puVar15[0x12] = uVar3;
                    puVar15[0x13] = uVar4;
                    puVar15[0x14] = uVar5;
                    puVar15[0x15] = uVar6;
                    puVar15[0x16] = uVar7;
                    puVar15[0x17] = uVar8;
                    puVar15[0x18] = uVar24;
                    puVar15[0x19] = uVar26;
                    puVar15[0x1a] = uVar27;
                    puVar15[0x1b] = uVar28;
                    puVar15[0x1c] = uVar9;
                    puVar15[0x1d] = uVar10;
                    puVar15[0x1e] = uVar11;
                    puVar15[0x1f] = uVar12;
                    puVar15 = puVar15 + 0x20;
                    puVar20 = puVar20 + 0x20;
                    uVar21 = uVar21 - 0x80;
                } while (0x7f < uVar21);
            }
        }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
        (*(code *)((uint64_t)*(uint32_t *)((uVar21 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
        return;
    }
code_r0x000180498020:
    *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    for (; uVar21 != 0; uVar21 = uVar21 - 1) {
        *(undefined *)arg1 = (*pauVar18)[0];
        pauVar18 = (undefined (*) [32])(*pauVar18 + 1);
        arg1 = (int64_t)((undefined *)arg1 + 1);
    }
    return;
}

// ============================================================
// Function: FUN_18014209f
// Address: 0x18014209f
// Size: 103 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801420c6: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801420cb)
// WARNING: Removing unreachable block (ram,0x0001801420db)
// WARNING: Removing unreachable block (ram,0x0001801420e0)
// WARNING: Removing unreachable block (ram,0x0001801420ee)
// WARNING: Removing unreachable block (ram,0x0001801420f4)
// WARNING: Removing unreachable block (ram,0x000180142101)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180142080(int64_t arg1, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined (*pauVar13) [32];
    undefined (*pauVar14) [32];
    undefined4 *puVar15;
    undefined4 *puVar16;
    int16_t iVar17;
    undefined (*pauVar18) [32];
    undefined (*pauVar19) [32];
    undefined4 *puVar20;
    undefined8 unaff_RSI;
    int64_t unaff_RDI;
    uint64_t uVar21;
    uint64_t uVar22;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar23;
    undefined4 uVar24;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined auVar25 [32];
    undefined auVar29 [32];
    undefined auVar30 [32];
    undefined auVar31 [32];
    undefined auVar32 [32];
    undefined auVar33 [32];
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    if (*(int16_t *)(arg1 + 0xa18) < 1) {
        return;
    }
    if (*(int32_t *)(arg1 + 0xc) < 0) {
        iVar17 = *(int16_t *)(arg1 + 0xa18) + -1;
        *(int16_t *)(arg1 + 0xa18) = iVar17;
        pauVar18 = (undefined (*) [32])(arg1 + 0x10);
        uVar21 = (int64_t)iVar17 << 4;
    } else {
        unaff_RDI = (int64_t)*(int32_t *)(arg1 + 4);
        *(int32_t *)(arg1 + 0xa1c) = *(int32_t *)(arg1 + 0xa1c) - *(int32_t *)(arg1 + 4);
        uVar21 = (uint64_t)*(int32_t *)(arg1 + 0xa1c);
        pauVar18 = (undefined (*) [32])(unaff_RDI + 0x630 + arg1);
        arg1 = arg1 + 0x630;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x1801420cb;
    }
    if (uVar21 < 0x10) {
        UNRECOVERED_JUMPTABLE = (code *)((uint64_t)*(uint32_t *)(uVar21 * 4 + 0x180650960) + 0x180000000);
    // WARNING: Could not recover jumptable at 0x00018049805b. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (16 cases) at 0x180650960
        (*UNRECOVERED_JUMPTABLE)(arg1, pauVar18, uVar21, UNRECOVERED_JUMPTABLE);
        return;
    }
    if (uVar21 < 0x21) {
        uVar2 = *(undefined4 *)(*pauVar18 + 4);
        uVar3 = *(undefined4 *)(*pauVar18 + 8);
        uVar4 = *(undefined4 *)(*pauVar18 + 0xc);
        puVar15 = (undefined4 *)(pauVar18[-1] + uVar21 + 0x10);
        uVar5 = *puVar15;
        uVar6 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        *(undefined4 *)(undefined *)arg1 = *(undefined4 *)*pauVar18;
        *(undefined4 *)((undefined *)arg1 + 4) = uVar2;
        *(undefined4 *)((undefined *)arg1 + 8) = uVar3;
        *(undefined4 *)((undefined *)arg1 + 0xc) = uVar4;
        puVar15 = (undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x10);
        *puVar15 = uVar5;
        puVar15[1] = uVar6;
        puVar15[2] = uVar7;
        puVar15[3] = uVar8;
        return;
    }
    pauVar13 = (undefined (*) [32])(*pauVar18 + uVar21);
    if ((uint64_t)arg1 <= pauVar18) {
        pauVar13 = (undefined (*) [32])arg1;
    }
    if ((uint64_t)arg1 < pauVar13) {
        uVar2 = *(undefined4 *)*pauVar18;
        uVar3 = *(undefined4 *)(*pauVar18 + 4);
        uVar4 = *(undefined4 *)(*pauVar18 + 8);
        uVar5 = *(undefined4 *)(*pauVar18 + 0xc);
        iVar23 = (int64_t)pauVar18 - arg1;
        puVar15 = (undefined4 *)(arg1 + iVar23 + (uVar21 - 0x10));
        uVar6 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        puVar16 = (undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x10);
        uVar22 = uVar21 - 0x10;
        puVar20 = puVar16;
        uVar24 = *puVar15;
        uVar26 = uVar6;
        uVar27 = uVar7;
        uVar28 = uVar8;
        if (((uint64_t)puVar16 & 0xf) != 0) {
            puVar20 = (undefined4 *)((uint64_t)puVar16 & 0xfffffffffffffff0);
            puVar1 = (undefined4 *)((int64_t)puVar20 + iVar23);
            uVar24 = *puVar1;
            uVar26 = puVar1[1];
            uVar27 = puVar1[2];
            uVar28 = puVar1[3];
            *puVar16 = *puVar15;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x14) = uVar6;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x18) = uVar7;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x1c) = uVar8;
            uVar22 = (int64_t)puVar20 - arg1;
        }
        uVar21 = uVar22 >> 7;
        if (uVar21 != 0) {
            *puVar20 = uVar24;
            puVar20[1] = uVar26;
            puVar20[2] = uVar27;
            puVar20[3] = uVar28;
            puVar15 = puVar20;
            while( true ) {
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x10);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar20 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x20);
                uVar24 = *puVar20;
                uVar26 = puVar20[1];
                uVar27 = puVar20[2];
                uVar28 = puVar20[3];
                puVar20 = puVar15 + -0x20;
                puVar15[-4] = *puVar16;
                puVar15[-3] = uVar6;
                puVar15[-2] = uVar7;
                puVar15[-1] = uVar8;
                puVar15[-8] = uVar24;
                puVar15[-7] = uVar26;
                puVar15[-6] = uVar27;
                puVar15[-5] = uVar28;
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x30);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x40);
                uVar24 = *puVar1;
                uVar26 = puVar1[1];
                uVar27 = puVar1[2];
                uVar28 = puVar1[3];
                uVar21 = uVar21 - 1;
                puVar15[-0xc] = *puVar16;
                puVar15[-0xb] = uVar6;
                puVar15[-10] = uVar7;
                puVar15[-9] = uVar8;
                puVar15[-0x10] = uVar24;
                puVar15[-0xf] = uVar26;
                puVar15[-0xe] = uVar27;
                puVar15[-0xd] = uVar28;
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x50);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x60);
                uVar24 = *puVar1;
                uVar26 = puVar1[1];
                uVar27 = puVar1[2];
                uVar28 = puVar1[3];
                puVar15[-0x14] = *puVar16;
                puVar15[-0x13] = uVar6;
                puVar15[-0x12] = uVar7;
                puVar15[-0x11] = uVar8;
                puVar15[-0x18] = uVar24;
                puVar15[-0x17] = uVar26;
                puVar15[-0x16] = uVar27;
                puVar15[-0x15] = uVar28;
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x70);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                puVar16 = (undefined4 *)((int64_t)puVar20 + iVar23);
                uVar24 = *puVar16;
                uVar26 = puVar16[1];
                uVar27 = puVar16[2];
                uVar28 = puVar16[3];
                if (uVar21 == 0) break;
                puVar15[-0x1c] = *puVar1;
                puVar15[-0x1b] = uVar6;
                puVar15[-0x1a] = uVar7;
                puVar15[-0x19] = uVar8;
                *puVar20 = uVar24;
                puVar15[-0x1f] = uVar26;
                puVar15[-0x1e] = uVar27;
                puVar15[-0x1d] = uVar28;
                puVar15 = puVar20;
            }
            puVar15[-0x1c] = *puVar1;
            puVar15[-0x1b] = uVar6;
            puVar15[-0x1a] = uVar7;
            puVar15[-0x19] = uVar8;
            uVar22 = uVar22 & 0x7f;
        }
        for (uVar21 = uVar22 >> 4; uVar21 != 0; uVar21 = uVar21 - 1) {
            *puVar20 = uVar24;
            puVar20[1] = uVar26;
            puVar20[2] = uVar27;
            puVar20[3] = uVar28;
            puVar20 = puVar20 + -4;
            puVar15 = (undefined4 *)((int64_t)puVar20 + iVar23);
            uVar24 = *puVar15;
            uVar26 = puVar15[1];
            uVar27 = puVar15[2];
            uVar28 = puVar15[3];
        }
        if ((uVar22 & 0xf) != 0) {
            *(undefined4 *)(undefined *)arg1 = uVar2;
            *(undefined4 *)((undefined *)arg1 + 4) = uVar3;
            *(undefined4 *)((undefined *)arg1 + 8) = uVar4;
            *(undefined4 *)((undefined *)arg1 + 0xc) = uVar5;
        }
        *puVar20 = uVar24;
        puVar20[1] = uVar26;
        puVar20[2] = uVar27;
        puVar20[3] = uVar28;
        return;
    }
    if (2 < *(uint32_t *)0x1806a3990) {
        if ((0x2000 < uVar21) && (uVar21 < 0x180001)) {
            pauVar13 = (undefined (*) [32])(arg1 + 0x40);
            if (pauVar18 < (uint64_t)arg1) {
                pauVar13 = pauVar18;
            }
            if ((pauVar13 <= pauVar18) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
        }
        auVar25 = vmovdqu_avx(*pauVar18);
        auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar18[-1] + uVar21));
        if (0x100 < uVar21) {
            iVar23 = (arg1 & 0x1fU) - 0x20;
            pauVar13 = (undefined (*) [32])(arg1 - iVar23);
            pauVar18 = (undefined (*) [32])((int64_t)pauVar18 - iVar23);
            uVar21 = uVar21 + iVar23;
            if (0x100 < uVar21) {
                if (0x180000 < uVar21) {
                    do {
                        uVar22 = uVar21;
                        pauVar19 = pauVar18;
                        pauVar14 = pauVar13;
                        auVar29 = vmovdqu_avx(*pauVar19);
                        auVar31 = vmovdqu_avx(pauVar19[1]);
                        auVar30 = vmovdqu_avx(pauVar19[2]);
                        auVar32 = vmovdqu_avx(pauVar19[3]);
                        auVar29 = vmovntdq_avx(auVar29);
                        *pauVar14 = auVar29;
                        auVar29 = vmovntdq_avx(auVar31);
                        pauVar14[1] = auVar29;
                        auVar29 = vmovntdq_avx(auVar30);
                        pauVar14[2] = auVar29;
                        auVar29 = vmovntdq_avx(auVar32);
                        pauVar14[3] = auVar29;
                        auVar29 = vmovdqu_avx(pauVar19[4]);
                        auVar31 = vmovdqu_avx(pauVar19[5]);
                        auVar30 = vmovdqu_avx(pauVar19[6]);
                        auVar32 = vmovdqu_avx(pauVar19[7]);
                        auVar29 = vmovntdq_avx(auVar29);
                        pauVar14[4] = auVar29;
                        auVar29 = vmovntdq_avx(auVar31);
                        pauVar14[5] = auVar29;
                        auVar29 = vmovntdq_avx(auVar30);
                        pauVar14[6] = auVar29;
                        auVar29 = vmovntdq_avx(auVar32);
                        pauVar14[7] = auVar29;
                        pauVar13 = pauVar14 + 8;
                        pauVar18 = pauVar19 + 8;
                        uVar21 = uVar22 - 0x100;
                    } while (0xff < uVar22 - 0x100);
                    uVar21 = uVar22 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                    switch(uVar22) {
                    case 0x1e1:
                    case 0x1e2:
                    case 0x1e3:
                    case 0x1e4:
                    case 0x1e5:
                    case 0x1e6:
                    case 0x1e7:
                    case 0x1e8:
                    case 0x1e9:
                    case 0x1ea:
                    case 0x1eb:
                    case 0x1ec:
                    case 0x1ed:
                    case 0x1ee:
                    case 0x1ef:
                    case 0x1f0:
                    case 0x1f1:
                    case 0x1f2:
                    case 499:
                    case 500:
                    case 0x1f5:
                    case 0x1f6:
                    case 0x1f7:
                    case 0x1f8:
                    case 0x1f9:
                    case 0x1fa:
                    case 0x1fb:
                    case 0x1fc:
                    case 0x1fd:
                    case 0x1fe:
                    case 0x1ff:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(*pauVar19 + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(*pauVar14 + uVar21) = auVar29;
                    case 0x1c1:
                    case 0x1c2:
                    case 0x1c3:
                    case 0x1c4:
                    case 0x1c5:
                    case 0x1c6:
                    case 0x1c7:
                    case 0x1c8:
                    case 0x1c9:
                    case 0x1ca:
                    case 0x1cb:
                    case 0x1cc:
                    case 0x1cd:
                    case 0x1ce:
                    case 0x1cf:
                    case 0x1d0:
                    case 0x1d1:
                    case 0x1d2:
                    case 0x1d3:
                    case 0x1d4:
                    case 0x1d5:
                    case 0x1d6:
                    case 0x1d7:
                    case 0x1d8:
                    case 0x1d9:
                    case 0x1da:
                    case 0x1db:
                    case 0x1dc:
                    case 0x1dd:
                    case 0x1de:
                    case 0x1df:
                    case 0x1e0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[1] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[1] + uVar21) = auVar29;
                    case 0x1a1:
                    case 0x1a2:
                    case 0x1a3:
                    case 0x1a4:
                    case 0x1a5:
                    case 0x1a6:
                    case 0x1a7:
                    case 0x1a8:
                    case 0x1a9:
                    case 0x1aa:
                    case 0x1ab:
                    case 0x1ac:
                    case 0x1ad:
                    case 0x1ae:
                    case 0x1af:
                    case 0x1b0:
                    case 0x1b1:
                    case 0x1b2:
                    case 0x1b3:
                    case 0x1b4:
                    case 0x1b5:
                    case 0x1b6:
                    case 0x1b7:
                    case 0x1b8:
                    case 0x1b9:
                    case 0x1ba:
                    case 0x1bb:
                    case 0x1bc:
                    case 0x1bd:
                    case 0x1be:
                    case 0x1bf:
                    case 0x1c0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[2] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[2] + uVar21) = auVar29;
                    case 0x181:
                    case 0x182:
                    case 0x183:
                    case 0x184:
                    case 0x185:
                    case 0x186:
                    case 0x187:
                    case 0x188:
                    case 0x189:
                    case 0x18a:
                    case 0x18b:
                    case 0x18c:
                    case 0x18d:
                    case 0x18e:
                    case 399:
                    case 400:
                    case 0x191:
                    case 0x192:
                    case 0x193:
                    case 0x194:
                    case 0x195:
                    case 0x196:
                    case 0x197:
                    case 0x198:
                    case 0x199:
                    case 0x19a:
                    case 0x19b:
                    case 0x19c:
                    case 0x19d:
                    case 0x19e:
                    case 0x19f:
                    case 0x1a0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[3] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[3] + uVar21) = auVar29;
                    case 0x161:
                    case 0x162:
                    case 0x163:
                    case 0x164:
                    case 0x165:
                    case 0x166:
                    case 0x167:
                    case 0x168:
                    case 0x169:
                    case 0x16a:
                    case 0x16b:
                    case 0x16c:
                    case 0x16d:
                    case 0x16e:
                    case 0x16f:
                    case 0x170:
                    case 0x171:
                    case 0x172:
                    case 0x173:
                    case 0x174:
                    case 0x175:
                    case 0x176:
                    case 0x177:
                    case 0x178:
                    case 0x179:
                    case 0x17a:
                    case 0x17b:
                    case 0x17c:
                    case 0x17d:
                    case 0x17e:
                    case 0x17f:
                    case 0x180:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[4] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[4] + uVar21) = auVar29;
                    case 0x141:
                    case 0x142:
                    case 0x143:
                    case 0x144:
                    case 0x145:
                    case 0x146:
                    case 0x147:
                    case 0x148:
                    case 0x149:
                    case 0x14a:
                    case 0x14b:
                    case 0x14c:
                    case 0x14d:
                    case 0x14e:
                    case 0x14f:
                    case 0x150:
                    case 0x151:
                    case 0x152:
                    case 0x153:
                    case 0x154:
                    case 0x155:
                    case 0x156:
                    case 0x157:
                    case 0x158:
                    case 0x159:
                    case 0x15a:
                    case 0x15b:
                    case 0x15c:
                    case 0x15d:
                    case 0x15e:
                    case 0x15f:
                    case 0x160:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[5] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[5] + uVar21) = auVar29;
                    case 0x121:
                    case 0x122:
                    case 0x123:
                    case 0x124:
                    case 0x125:
                    case 0x126:
                    case 0x127:
                    case 0x128:
                    case 0x129:
                    case 0x12a:
                    case 299:
                    case 300:
                    case 0x12d:
                    case 0x12e:
                    case 0x12f:
                    case 0x130:
                    case 0x131:
                    case 0x132:
                    case 0x133:
                    case 0x134:
                    case 0x135:
                    case 0x136:
                    case 0x137:
                    case 0x138:
                    case 0x139:
                    case 0x13a:
                    case 0x13b:
                    case 0x13c:
                    case 0x13d:
                    case 0x13e:
                    case 0x13f:
                    case 0x140:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[6] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[6] + uVar21) = auVar29;
                    default:
                        auVar33 = vmovdqu_avx(auVar33);
                        *(undefined (*) [32])(pauVar14[-1] + uVar22) = auVar33;
                    case 0x100:
                        auVar25 = vmovdqu_avx(auVar25);
                        *(undefined (*) [32])arg1 = auVar25;
                        return;
                    }
                }
                do {
                    auVar25 = vmovdqu_avx(*pauVar18);
                    auVar33 = vmovdqu_avx(pauVar18[1]);
                    auVar29 = vmovdqu_avx(pauVar18[2]);
                    auVar31 = vmovdqu_avx(pauVar18[3]);
                    *pauVar13 = auVar25;
                    pauVar13[1] = auVar33;
                    pauVar13[2] = auVar29;
                    pauVar13[3] = auVar31;
                    auVar25 = vmovdqu_avx(pauVar18[4]);
                    auVar33 = vmovdqu_avx(pauVar18[5]);
                    auVar29 = vmovdqu_avx(pauVar18[6]);
                    auVar31 = vmovdqu_avx(pauVar18[7]);
                    pauVar13[4] = auVar25;
                    pauVar13[5] = auVar33;
                    pauVar13[6] = auVar29;
                    pauVar13[7] = auVar31;
                    pauVar13 = pauVar13 + 8;
                    pauVar18 = pauVar18 + 8;
                    uVar21 = uVar21 - 0x100;
                } while (0xff < uVar21);
            }
        }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
        (*(code *)((uint64_t)*(uint32_t *)((uVar21 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
        return;
    }
    if ((uVar21 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
        if (0x80 < uVar21) {
            iVar23 = (arg1 & 0xfU) - 0x10;
            puVar15 = (undefined4 *)(arg1 - iVar23);
            puVar20 = (undefined4 *)((int64_t)pauVar18 - iVar23);
            uVar21 = uVar21 + iVar23;
            if (0x80 < uVar21) {
                do {
                    uVar2 = puVar20[1];
                    uVar3 = puVar20[2];
                    uVar4 = puVar20[3];
                    uVar5 = puVar20[4];
                    uVar6 = puVar20[5];
                    uVar7 = puVar20[6];
                    uVar8 = puVar20[7];
                    uVar24 = puVar20[8];
                    uVar26 = puVar20[9];
                    uVar27 = puVar20[10];
                    uVar28 = puVar20[0xb];
                    uVar9 = puVar20[0xc];
                    uVar10 = puVar20[0xd];
                    uVar11 = puVar20[0xe];
                    uVar12 = puVar20[0xf];
                    *puVar15 = *puVar20;
                    puVar15[1] = uVar2;
                    puVar15[2] = uVar3;
                    puVar15[3] = uVar4;
                    puVar15[4] = uVar5;
                    puVar15[5] = uVar6;
                    puVar15[6] = uVar7;
                    puVar15[7] = uVar8;
                    puVar15[8] = uVar24;
                    puVar15[9] = uVar26;
                    puVar15[10] = uVar27;
                    puVar15[0xb] = uVar28;
                    puVar15[0xc] = uVar9;
                    puVar15[0xd] = uVar10;
                    puVar15[0xe] = uVar11;
                    puVar15[0xf] = uVar12;
                    uVar2 = puVar20[0x11];
                    uVar3 = puVar20[0x12];
                    uVar4 = puVar20[0x13];
                    uVar5 = puVar20[0x14];
                    uVar6 = puVar20[0x15];
                    uVar7 = puVar20[0x16];
                    uVar8 = puVar20[0x17];
                    uVar24 = puVar20[0x18];
                    uVar26 = puVar20[0x19];
                    uVar27 = puVar20[0x1a];
                    uVar28 = puVar20[0x1b];
                    uVar9 = puVar20[0x1c];
                    uVar10 = puVar20[0x1d];
                    uVar11 = puVar20[0x1e];
                    uVar12 = puVar20[0x1f];
                    puVar15[0x10] = puVar20[0x10];
                    puVar15[0x11] = uVar2;
                    puVar15[0x12] = uVar3;
                    puVar15[0x13] = uVar4;
                    puVar15[0x14] = uVar5;
                    puVar15[0x15] = uVar6;
                    puVar15[0x16] = uVar7;
                    puVar15[0x17] = uVar8;
                    puVar15[0x18] = uVar24;
                    puVar15[0x19] = uVar26;
                    puVar15[0x1a] = uVar27;
                    puVar15[0x1b] = uVar28;
                    puVar15[0x1c] = uVar9;
                    puVar15[0x1d] = uVar10;
                    puVar15[0x1e] = uVar11;
                    puVar15[0x1f] = uVar12;
                    puVar15 = puVar15 + 0x20;
                    puVar20 = puVar20 + 0x20;
                    uVar21 = uVar21 - 0x80;
                } while (0x7f < uVar21);
            }
        }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
        (*(code *)((uint64_t)*(uint32_t *)((uVar21 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
        return;
    }
code_r0x000180498020:
    *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    for (; uVar21 != 0; uVar21 = uVar21 - 1) {
        *(undefined *)arg1 = (*pauVar18)[0];
        pauVar18 = (undefined (*) [32])(*pauVar18 + 1);
        arg1 = (int64_t)((undefined *)arg1 + 1);
    }
    return;
}

// ============================================================
// Function: FUN_180142106
// Address: 0x180142106
// Size: 41 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801420c6: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801420cb)
// WARNING: Removing unreachable block (ram,0x0001801420db)
// WARNING: Removing unreachable block (ram,0x0001801420e0)
// WARNING: Removing unreachable block (ram,0x0001801420ee)
// WARNING: Removing unreachable block (ram,0x0001801420f4)
// WARNING: Removing unreachable block (ram,0x000180142101)
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180142080(int64_t arg1, int64_t arg_38h)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    undefined4 uVar11;
    undefined4 uVar12;
    undefined (*pauVar13) [32];
    undefined (*pauVar14) [32];
    undefined4 *puVar15;
    undefined4 *puVar16;
    int16_t iVar17;
    undefined (*pauVar18) [32];
    undefined (*pauVar19) [32];
    undefined4 *puVar20;
    undefined8 unaff_RSI;
    int64_t unaff_RDI;
    uint64_t uVar21;
    uint64_t uVar22;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar23;
    undefined4 uVar24;
    undefined4 uVar26;
    undefined4 uVar27;
    undefined4 uVar28;
    undefined auVar25 [32];
    undefined auVar29 [32];
    undefined auVar30 [32];
    undefined auVar31 [32];
    undefined auVar32 [32];
    undefined auVar33 [32];
    int64_t var_8h;
    undefined8 auStack_30 [5];
    
    if (*(int16_t *)(arg1 + 0xa18) < 1) {
        return;
    }
    if (*(int32_t *)(arg1 + 0xc) < 0) {
        iVar17 = *(int16_t *)(arg1 + 0xa18) + -1;
        *(int16_t *)(arg1 + 0xa18) = iVar17;
        pauVar18 = (undefined (*) [32])(arg1 + 0x10);
        uVar21 = (int64_t)iVar17 << 4;
    } else {
        unaff_RDI = (int64_t)*(int32_t *)(arg1 + 4);
        *(int32_t *)(arg1 + 0xa1c) = *(int32_t *)(arg1 + 0xa1c) - *(int32_t *)(arg1 + 4);
        uVar21 = (uint64_t)*(int32_t *)(arg1 + 0xa1c);
        pauVar18 = (undefined (*) [32])(unaff_RDI + 0x630 + arg1);
        arg1 = arg1 + 0x630;
        *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
        auStack_30[0] = 0x1801420cb;
    }
    if (uVar21 < 0x10) {
        UNRECOVERED_JUMPTABLE = (code *)((uint64_t)*(uint32_t *)(uVar21 * 4 + 0x180650960) + 0x180000000);
    // WARNING: Could not recover jumptable at 0x00018049805b. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (16 cases) at 0x180650960
        (*UNRECOVERED_JUMPTABLE)(arg1, pauVar18, uVar21, UNRECOVERED_JUMPTABLE);
        return;
    }
    if (uVar21 < 0x21) {
        uVar2 = *(undefined4 *)(*pauVar18 + 4);
        uVar3 = *(undefined4 *)(*pauVar18 + 8);
        uVar4 = *(undefined4 *)(*pauVar18 + 0xc);
        puVar15 = (undefined4 *)(pauVar18[-1] + uVar21 + 0x10);
        uVar5 = *puVar15;
        uVar6 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        *(undefined4 *)(undefined *)arg1 = *(undefined4 *)*pauVar18;
        *(undefined4 *)((undefined *)arg1 + 4) = uVar2;
        *(undefined4 *)((undefined *)arg1 + 8) = uVar3;
        *(undefined4 *)((undefined *)arg1 + 0xc) = uVar4;
        puVar15 = (undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x10);
        *puVar15 = uVar5;
        puVar15[1] = uVar6;
        puVar15[2] = uVar7;
        puVar15[3] = uVar8;
        return;
    }
    pauVar13 = (undefined (*) [32])(*pauVar18 + uVar21);
    if ((uint64_t)arg1 <= pauVar18) {
        pauVar13 = (undefined (*) [32])arg1;
    }
    if ((uint64_t)arg1 < pauVar13) {
        uVar2 = *(undefined4 *)*pauVar18;
        uVar3 = *(undefined4 *)(*pauVar18 + 4);
        uVar4 = *(undefined4 *)(*pauVar18 + 8);
        uVar5 = *(undefined4 *)(*pauVar18 + 0xc);
        iVar23 = (int64_t)pauVar18 - arg1;
        puVar15 = (undefined4 *)(arg1 + iVar23 + (uVar21 - 0x10));
        uVar6 = puVar15[1];
        uVar7 = puVar15[2];
        uVar8 = puVar15[3];
        puVar16 = (undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x10);
        uVar22 = uVar21 - 0x10;
        puVar20 = puVar16;
        uVar24 = *puVar15;
        uVar26 = uVar6;
        uVar27 = uVar7;
        uVar28 = uVar8;
        if (((uint64_t)puVar16 & 0xf) != 0) {
            puVar20 = (undefined4 *)((uint64_t)puVar16 & 0xfffffffffffffff0);
            puVar1 = (undefined4 *)((int64_t)puVar20 + iVar23);
            uVar24 = *puVar1;
            uVar26 = puVar1[1];
            uVar27 = puVar1[2];
            uVar28 = puVar1[3];
            *puVar16 = *puVar15;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x14) = uVar6;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x18) = uVar7;
            *(undefined4 *)(*(undefined (*) [32])(arg1 + -0x20) + uVar21 + 0x1c) = uVar8;
            uVar22 = (int64_t)puVar20 - arg1;
        }
        uVar21 = uVar22 >> 7;
        if (uVar21 != 0) {
            *puVar20 = uVar24;
            puVar20[1] = uVar26;
            puVar20[2] = uVar27;
            puVar20[3] = uVar28;
            puVar15 = puVar20;
            while( true ) {
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x10);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar20 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x20);
                uVar24 = *puVar20;
                uVar26 = puVar20[1];
                uVar27 = puVar20[2];
                uVar28 = puVar20[3];
                puVar20 = puVar15 + -0x20;
                puVar15[-4] = *puVar16;
                puVar15[-3] = uVar6;
                puVar15[-2] = uVar7;
                puVar15[-1] = uVar8;
                puVar15[-8] = uVar24;
                puVar15[-7] = uVar26;
                puVar15[-6] = uVar27;
                puVar15[-5] = uVar28;
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x30);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x40);
                uVar24 = *puVar1;
                uVar26 = puVar1[1];
                uVar27 = puVar1[2];
                uVar28 = puVar1[3];
                uVar21 = uVar21 - 1;
                puVar15[-0xc] = *puVar16;
                puVar15[-0xb] = uVar6;
                puVar15[-10] = uVar7;
                puVar15[-9] = uVar8;
                puVar15[-0x10] = uVar24;
                puVar15[-0xf] = uVar26;
                puVar15[-0xe] = uVar27;
                puVar15[-0xd] = uVar28;
                puVar16 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x50);
                uVar6 = puVar16[1];
                uVar7 = puVar16[2];
                uVar8 = puVar16[3];
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x60);
                uVar24 = *puVar1;
                uVar26 = puVar1[1];
                uVar27 = puVar1[2];
                uVar28 = puVar1[3];
                puVar15[-0x14] = *puVar16;
                puVar15[-0x13] = uVar6;
                puVar15[-0x12] = uVar7;
                puVar15[-0x11] = uVar8;
                puVar15[-0x18] = uVar24;
                puVar15[-0x17] = uVar26;
                puVar15[-0x16] = uVar27;
                puVar15[-0x15] = uVar28;
                puVar1 = (undefined4 *)((int64_t)puVar15 + iVar23 + -0x70);
                uVar6 = puVar1[1];
                uVar7 = puVar1[2];
                uVar8 = puVar1[3];
                puVar16 = (undefined4 *)((int64_t)puVar20 + iVar23);
                uVar24 = *puVar16;
                uVar26 = puVar16[1];
                uVar27 = puVar16[2];
                uVar28 = puVar16[3];
                if (uVar21 == 0) break;
                puVar15[-0x1c] = *puVar1;
                puVar15[-0x1b] = uVar6;
                puVar15[-0x1a] = uVar7;
                puVar15[-0x19] = uVar8;
                *puVar20 = uVar24;
                puVar15[-0x1f] = uVar26;
                puVar15[-0x1e] = uVar27;
                puVar15[-0x1d] = uVar28;
                puVar15 = puVar20;
            }
            puVar15[-0x1c] = *puVar1;
            puVar15[-0x1b] = uVar6;
            puVar15[-0x1a] = uVar7;
            puVar15[-0x19] = uVar8;
            uVar22 = uVar22 & 0x7f;
        }
        for (uVar21 = uVar22 >> 4; uVar21 != 0; uVar21 = uVar21 - 1) {
            *puVar20 = uVar24;
            puVar20[1] = uVar26;
            puVar20[2] = uVar27;
            puVar20[3] = uVar28;
            puVar20 = puVar20 + -4;
            puVar15 = (undefined4 *)((int64_t)puVar20 + iVar23);
            uVar24 = *puVar15;
            uVar26 = puVar15[1];
            uVar27 = puVar15[2];
            uVar28 = puVar15[3];
        }
        if ((uVar22 & 0xf) != 0) {
            *(undefined4 *)(undefined *)arg1 = uVar2;
            *(undefined4 *)((undefined *)arg1 + 4) = uVar3;
            *(undefined4 *)((undefined *)arg1 + 8) = uVar4;
            *(undefined4 *)((undefined *)arg1 + 0xc) = uVar5;
        }
        *puVar20 = uVar24;
        puVar20[1] = uVar26;
        puVar20[2] = uVar27;
        puVar20[3] = uVar28;
        return;
    }
    if (2 < *(uint32_t *)0x1806a3990) {
        if ((0x2000 < uVar21) && (uVar21 < 0x180001)) {
            pauVar13 = (undefined (*) [32])(arg1 + 0x40);
            if (pauVar18 < (uint64_t)arg1) {
                pauVar13 = pauVar18;
            }
            if ((pauVar13 <= pauVar18) && ((*(uint8_t *)0x18078131c & 2) != 0)) goto code_r0x000180498020;
        }
        auVar25 = vmovdqu_avx(*pauVar18);
        auVar33 = vmovdqu_avx(*(undefined (*) [32])(pauVar18[-1] + uVar21));
        if (0x100 < uVar21) {
            iVar23 = (arg1 & 0x1fU) - 0x20;
            pauVar13 = (undefined (*) [32])(arg1 - iVar23);
            pauVar18 = (undefined (*) [32])((int64_t)pauVar18 - iVar23);
            uVar21 = uVar21 + iVar23;
            if (0x100 < uVar21) {
                if (0x180000 < uVar21) {
                    do {
                        uVar22 = uVar21;
                        pauVar19 = pauVar18;
                        pauVar14 = pauVar13;
                        auVar29 = vmovdqu_avx(*pauVar19);
                        auVar31 = vmovdqu_avx(pauVar19[1]);
                        auVar30 = vmovdqu_avx(pauVar19[2]);
                        auVar32 = vmovdqu_avx(pauVar19[3]);
                        auVar29 = vmovntdq_avx(auVar29);
                        *pauVar14 = auVar29;
                        auVar29 = vmovntdq_avx(auVar31);
                        pauVar14[1] = auVar29;
                        auVar29 = vmovntdq_avx(auVar30);
                        pauVar14[2] = auVar29;
                        auVar29 = vmovntdq_avx(auVar32);
                        pauVar14[3] = auVar29;
                        auVar29 = vmovdqu_avx(pauVar19[4]);
                        auVar31 = vmovdqu_avx(pauVar19[5]);
                        auVar30 = vmovdqu_avx(pauVar19[6]);
                        auVar32 = vmovdqu_avx(pauVar19[7]);
                        auVar29 = vmovntdq_avx(auVar29);
                        pauVar14[4] = auVar29;
                        auVar29 = vmovntdq_avx(auVar31);
                        pauVar14[5] = auVar29;
                        auVar29 = vmovntdq_avx(auVar30);
                        pauVar14[6] = auVar29;
                        auVar29 = vmovntdq_avx(auVar32);
                        pauVar14[7] = auVar29;
                        pauVar13 = pauVar14 + 8;
                        pauVar18 = pauVar19 + 8;
                        uVar21 = uVar22 - 0x100;
                    } while (0xff < uVar22 - 0x100);
                    uVar21 = uVar22 - 0xe1 & 0xffffffffffffffe0;
    // switch table (18 cases) at 0x1806509c4
                    switch(uVar22) {
                    case 0x1e1:
                    case 0x1e2:
                    case 0x1e3:
                    case 0x1e4:
                    case 0x1e5:
                    case 0x1e6:
                    case 0x1e7:
                    case 0x1e8:
                    case 0x1e9:
                    case 0x1ea:
                    case 0x1eb:
                    case 0x1ec:
                    case 0x1ed:
                    case 0x1ee:
                    case 0x1ef:
                    case 0x1f0:
                    case 0x1f1:
                    case 0x1f2:
                    case 499:
                    case 500:
                    case 0x1f5:
                    case 0x1f6:
                    case 0x1f7:
                    case 0x1f8:
                    case 0x1f9:
                    case 0x1fa:
                    case 0x1fb:
                    case 0x1fc:
                    case 0x1fd:
                    case 0x1fe:
                    case 0x1ff:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(*pauVar19 + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(*pauVar14 + uVar21) = auVar29;
                    case 0x1c1:
                    case 0x1c2:
                    case 0x1c3:
                    case 0x1c4:
                    case 0x1c5:
                    case 0x1c6:
                    case 0x1c7:
                    case 0x1c8:
                    case 0x1c9:
                    case 0x1ca:
                    case 0x1cb:
                    case 0x1cc:
                    case 0x1cd:
                    case 0x1ce:
                    case 0x1cf:
                    case 0x1d0:
                    case 0x1d1:
                    case 0x1d2:
                    case 0x1d3:
                    case 0x1d4:
                    case 0x1d5:
                    case 0x1d6:
                    case 0x1d7:
                    case 0x1d8:
                    case 0x1d9:
                    case 0x1da:
                    case 0x1db:
                    case 0x1dc:
                    case 0x1dd:
                    case 0x1de:
                    case 0x1df:
                    case 0x1e0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[1] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[1] + uVar21) = auVar29;
                    case 0x1a1:
                    case 0x1a2:
                    case 0x1a3:
                    case 0x1a4:
                    case 0x1a5:
                    case 0x1a6:
                    case 0x1a7:
                    case 0x1a8:
                    case 0x1a9:
                    case 0x1aa:
                    case 0x1ab:
                    case 0x1ac:
                    case 0x1ad:
                    case 0x1ae:
                    case 0x1af:
                    case 0x1b0:
                    case 0x1b1:
                    case 0x1b2:
                    case 0x1b3:
                    case 0x1b4:
                    case 0x1b5:
                    case 0x1b6:
                    case 0x1b7:
                    case 0x1b8:
                    case 0x1b9:
                    case 0x1ba:
                    case 0x1bb:
                    case 0x1bc:
                    case 0x1bd:
                    case 0x1be:
                    case 0x1bf:
                    case 0x1c0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[2] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[2] + uVar21) = auVar29;
                    case 0x181:
                    case 0x182:
                    case 0x183:
                    case 0x184:
                    case 0x185:
                    case 0x186:
                    case 0x187:
                    case 0x188:
                    case 0x189:
                    case 0x18a:
                    case 0x18b:
                    case 0x18c:
                    case 0x18d:
                    case 0x18e:
                    case 399:
                    case 400:
                    case 0x191:
                    case 0x192:
                    case 0x193:
                    case 0x194:
                    case 0x195:
                    case 0x196:
                    case 0x197:
                    case 0x198:
                    case 0x199:
                    case 0x19a:
                    case 0x19b:
                    case 0x19c:
                    case 0x19d:
                    case 0x19e:
                    case 0x19f:
                    case 0x1a0:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[3] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[3] + uVar21) = auVar29;
                    case 0x161:
                    case 0x162:
                    case 0x163:
                    case 0x164:
                    case 0x165:
                    case 0x166:
                    case 0x167:
                    case 0x168:
                    case 0x169:
                    case 0x16a:
                    case 0x16b:
                    case 0x16c:
                    case 0x16d:
                    case 0x16e:
                    case 0x16f:
                    case 0x170:
                    case 0x171:
                    case 0x172:
                    case 0x173:
                    case 0x174:
                    case 0x175:
                    case 0x176:
                    case 0x177:
                    case 0x178:
                    case 0x179:
                    case 0x17a:
                    case 0x17b:
                    case 0x17c:
                    case 0x17d:
                    case 0x17e:
                    case 0x17f:
                    case 0x180:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[4] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[4] + uVar21) = auVar29;
                    case 0x141:
                    case 0x142:
                    case 0x143:
                    case 0x144:
                    case 0x145:
                    case 0x146:
                    case 0x147:
                    case 0x148:
                    case 0x149:
                    case 0x14a:
                    case 0x14b:
                    case 0x14c:
                    case 0x14d:
                    case 0x14e:
                    case 0x14f:
                    case 0x150:
                    case 0x151:
                    case 0x152:
                    case 0x153:
                    case 0x154:
                    case 0x155:
                    case 0x156:
                    case 0x157:
                    case 0x158:
                    case 0x159:
                    case 0x15a:
                    case 0x15b:
                    case 0x15c:
                    case 0x15d:
                    case 0x15e:
                    case 0x15f:
                    case 0x160:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[5] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[5] + uVar21) = auVar29;
                    case 0x121:
                    case 0x122:
                    case 0x123:
                    case 0x124:
                    case 0x125:
                    case 0x126:
                    case 0x127:
                    case 0x128:
                    case 0x129:
                    case 0x12a:
                    case 299:
                    case 300:
                    case 0x12d:
                    case 0x12e:
                    case 0x12f:
                    case 0x130:
                    case 0x131:
                    case 0x132:
                    case 0x133:
                    case 0x134:
                    case 0x135:
                    case 0x136:
                    case 0x137:
                    case 0x138:
                    case 0x139:
                    case 0x13a:
                    case 0x13b:
                    case 0x13c:
                    case 0x13d:
                    case 0x13e:
                    case 0x13f:
                    case 0x140:
                        auVar29 = vmovdqu_avx(*(undefined (*) [32])(pauVar19[6] + uVar21));
                        auVar29 = vmovntdq_avx(auVar29);
                        *(undefined (*) [32])(pauVar14[6] + uVar21) = auVar29;
                    default:
                        auVar33 = vmovdqu_avx(auVar33);
                        *(undefined (*) [32])(pauVar14[-1] + uVar22) = auVar33;
                    case 0x100:
                        auVar25 = vmovdqu_avx(auVar25);
                        *(undefined (*) [32])arg1 = auVar25;
                        return;
                    }
                }
                do {
                    auVar25 = vmovdqu_avx(*pauVar18);
                    auVar33 = vmovdqu_avx(pauVar18[1]);
                    auVar29 = vmovdqu_avx(pauVar18[2]);
                    auVar31 = vmovdqu_avx(pauVar18[3]);
                    *pauVar13 = auVar25;
                    pauVar13[1] = auVar33;
                    pauVar13[2] = auVar29;
                    pauVar13[3] = auVar31;
                    auVar25 = vmovdqu_avx(pauVar18[4]);
                    auVar33 = vmovdqu_avx(pauVar18[5]);
                    auVar29 = vmovdqu_avx(pauVar18[6]);
                    auVar31 = vmovdqu_avx(pauVar18[7]);
                    pauVar13[4] = auVar25;
                    pauVar13[5] = auVar33;
                    pauVar13[6] = auVar29;
                    pauVar13[7] = auVar31;
                    pauVar13 = pauVar13 + 8;
                    pauVar18 = pauVar18 + 8;
                    uVar21 = uVar21 - 0x100;
                } while (0xff < uVar21);
            }
        }
    // WARNING: Could not recover jumptable at 0x0001804982b2. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (27 cases) at 0x1806509a0
        (*(code *)((uint64_t)*(uint32_t *)((uVar21 + 0x1f >> 5) * 4 + 0x1806509a0) + 0x180000000))();
        return;
    }
    if ((uVar21 < 0x801) || ((*(uint8_t *)0x18078131c & 2) == 0)) {
        if (0x80 < uVar21) {
            iVar23 = (arg1 & 0xfU) - 0x10;
            puVar15 = (undefined4 *)(arg1 - iVar23);
            puVar20 = (undefined4 *)((int64_t)pauVar18 - iVar23);
            uVar21 = uVar21 + iVar23;
            if (0x80 < uVar21) {
                do {
                    uVar2 = puVar20[1];
                    uVar3 = puVar20[2];
                    uVar4 = puVar20[3];
                    uVar5 = puVar20[4];
                    uVar6 = puVar20[5];
                    uVar7 = puVar20[6];
                    uVar8 = puVar20[7];
                    uVar24 = puVar20[8];
                    uVar26 = puVar20[9];
                    uVar27 = puVar20[10];
                    uVar28 = puVar20[0xb];
                    uVar9 = puVar20[0xc];
                    uVar10 = puVar20[0xd];
                    uVar11 = puVar20[0xe];
                    uVar12 = puVar20[0xf];
                    *puVar15 = *puVar20;
                    puVar15[1] = uVar2;
                    puVar15[2] = uVar3;
                    puVar15[3] = uVar4;
                    puVar15[4] = uVar5;
                    puVar15[5] = uVar6;
                    puVar15[6] = uVar7;
                    puVar15[7] = uVar8;
                    puVar15[8] = uVar24;
                    puVar15[9] = uVar26;
                    puVar15[10] = uVar27;
                    puVar15[0xb] = uVar28;
                    puVar15[0xc] = uVar9;
                    puVar15[0xd] = uVar10;
                    puVar15[0xe] = uVar11;
                    puVar15[0xf] = uVar12;
                    uVar2 = puVar20[0x11];
                    uVar3 = puVar20[0x12];
                    uVar4 = puVar20[0x13];
                    uVar5 = puVar20[0x14];
                    uVar6 = puVar20[0x15];
                    uVar7 = puVar20[0x16];
                    uVar8 = puVar20[0x17];
                    uVar24 = puVar20[0x18];
                    uVar26 = puVar20[0x19];
                    uVar27 = puVar20[0x1a];
                    uVar28 = puVar20[0x1b];
                    uVar9 = puVar20[0x1c];
                    uVar10 = puVar20[0x1d];
                    uVar11 = puVar20[0x1e];
                    uVar12 = puVar20[0x1f];
                    puVar15[0x10] = puVar20[0x10];
                    puVar15[0x11] = uVar2;
                    puVar15[0x12] = uVar3;
                    puVar15[0x13] = uVar4;
                    puVar15[0x14] = uVar5;
                    puVar15[0x15] = uVar6;
                    puVar15[0x16] = uVar7;
                    puVar15[0x17] = uVar8;
                    puVar15[0x18] = uVar24;
                    puVar15[0x19] = uVar26;
                    puVar15[0x1a] = uVar27;
                    puVar15[0x1b] = uVar28;
                    puVar15[0x1c] = uVar9;
                    puVar15[0x1d] = uVar10;
                    puVar15[0x1e] = uVar11;
                    puVar15[0x1f] = uVar12;
                    puVar15 = puVar15 + 0x20;
                    puVar20 = puVar20 + 0x20;
                    uVar21 = uVar21 - 0x80;
                } while (0x7f < uVar21);
            }
        }
    // WARNING: Could not recover jumptable at 0x000180498556. Too many branches
    // WARNING: Treating indirect jump as call
    // switch table (9 cases) at 0x1806509e8
        (*(code *)((uint64_t)*(uint32_t *)((uVar21 + 0xf >> 4) * 4 + 0x1806509e8) + 0x180000000))();
        return;
    }
code_r0x000180498020:
    *(int64_t *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x10) = unaff_RSI;
    for (; uVar21 != 0; uVar21 = uVar21 - 1) {
        *(undefined *)arg1 = (*pauVar18)[0];
        pauVar18 = (undefined (*) [32])(*pauVar18 + 1);
        arg1 = (int64_t)((undefined *)arg1 + 1);
    }
    return;
}

// ============================================================
// Function: FUN_180142130
// Address: 0x180142130
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180142130(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int16_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    *(undefined2 *)(arg1 + 0xa1a) = 99;
    *(undefined4 *)(arg1 + 0xa20) = 999;
    if (*(int16_t *)(arg1 + 0xa18) == 99) {
        fcn.180142080(arg1, unaff_RSI);
    }
    iVar6 = (int32_t)arg3;
    if (iVar6 < 1000) {
        iVar3 = *(int32_t *)(arg1 + 0xa1c);
        while (999 < iVar3 + iVar6) {
            iVar4 = *(int16_t *)(arg1 + 0xa18);
            if (0 < iVar4) {
                if (-1 < *(int32_t *)(arg1 + 0xc)) {
                    iVar1 = *(int32_t *)(arg1 + 4);
                    *(int32_t *)(arg1 + 0xa1c) = iVar3 - iVar1;
                    func_0x000180498030(arg1 + 0x630, arg1 + 0x630 + (int64_t)iVar1, (int64_t)(iVar3 - iVar1));
                    iVar4 = *(int16_t *)(arg1 + 0xa18);
                    iVar3 = 0;
                    if (0 < iVar4) {
                        do {
                            iVar2 = *(int32_t *)(arg1 + 0xc + (int64_t)iVar3 * 0x10);
                            if (-1 < iVar2) {
                                *(int32_t *)(arg1 + 0xc + (int64_t)iVar3 * 0x10) = iVar2 - iVar1;
                            }
                            iVar4 = *(int16_t *)(arg1 + 0xa18);
                            iVar3 = iVar3 + 1;
                        } while (iVar3 < iVar4);
                    }
                }
                *(int16_t *)(arg1 + 0xa18) = iVar4 + -1;
                func_0x000180498030(arg1, arg1 + 0x10, (int64_t)(int16_t)(iVar4 + -1) << 4);
            }
            iVar3 = *(int32_t *)(arg1 + 0xa1c);
        }
        iVar4 = *(int16_t *)(arg1 + 0xa18);
        *(int16_t *)(arg1 + 0xa18) = iVar4 + 1;
        puVar5 = (undefined4 *)((int64_t)iVar4 * 0x10 + arg1);
        if (puVar5 != (undefined4 *)0x0) {
            *puVar5 = (int32_t)arg2;
            puVar5[1] = iVar6;
            puVar5[2] = (int32_t)arg4;
            if (iVar6 != 0) {
                puVar5[3] = *(undefined4 *)(arg1 + 0xa1c);
                *(int32_t *)(arg1 + 0xa1c) = *(int32_t *)(arg1 + 0xa1c) + iVar6;
                return (int64_t)(int32_t)puVar5[3] + 0x630 + arg1;
            }
            puVar5[3] = 0xffffffff;
        }
    } else {
        *(undefined2 *)(arg1 + 0xa18) = 0;
        *(undefined4 *)(arg1 + 0xa1c) = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801421a3
// Address: 0x1801421a3
// Size: 181 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180142130(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int16_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    *(undefined2 *)(arg1 + 0xa1a) = 99;
    *(undefined4 *)(arg1 + 0xa20) = 999;
    if (*(int16_t *)(arg1 + 0xa18) == 99) {
        fcn.180142080(arg1, unaff_RSI);
    }
    iVar6 = (int32_t)arg3;
    if (iVar6 < 1000) {
        iVar3 = *(int32_t *)(arg1 + 0xa1c);
        while (999 < iVar3 + iVar6) {
            iVar4 = *(int16_t *)(arg1 + 0xa18);
            if (0 < iVar4) {
                if (-1 < *(int32_t *)(arg1 + 0xc)) {
                    iVar1 = *(int32_t *)(arg1 + 4);
                    *(int32_t *)(arg1 + 0xa1c) = iVar3 - iVar1;
                    func_0x000180498030(arg1 + 0x630, arg1 + 0x630 + (int64_t)iVar1, (int64_t)(iVar3 - iVar1));
                    iVar4 = *(int16_t *)(arg1 + 0xa18);
                    iVar3 = 0;
                    if (0 < iVar4) {
                        do {
                            iVar2 = *(int32_t *)(arg1 + 0xc + (int64_t)iVar3 * 0x10);
                            if (-1 < iVar2) {
                                *(int32_t *)(arg1 + 0xc + (int64_t)iVar3 * 0x10) = iVar2 - iVar1;
                            }
                            iVar4 = *(int16_t *)(arg1 + 0xa18);
                            iVar3 = iVar3 + 1;
                        } while (iVar3 < iVar4);
                    }
                }
                *(int16_t *)(arg1 + 0xa18) = iVar4 + -1;
                func_0x000180498030(arg1, arg1 + 0x10, (int64_t)(int16_t)(iVar4 + -1) << 4);
            }
            iVar3 = *(int32_t *)(arg1 + 0xa1c);
        }
        iVar4 = *(int16_t *)(arg1 + 0xa18);
        *(int16_t *)(arg1 + 0xa18) = iVar4 + 1;
        puVar5 = (undefined4 *)((int64_t)iVar4 * 0x10 + arg1);
        if (puVar5 != (undefined4 *)0x0) {
            *puVar5 = (int32_t)arg2;
            puVar5[1] = iVar6;
            puVar5[2] = (int32_t)arg4;
            if (iVar6 != 0) {
                puVar5[3] = *(undefined4 *)(arg1 + 0xa1c);
                *(int32_t *)(arg1 + 0xa1c) = *(int32_t *)(arg1 + 0xa1c) + iVar6;
                return (int64_t)(int32_t)puVar5[3] + 0x630 + arg1;
            }
            puVar5[3] = 0xffffffff;
        }
    } else {
        *(undefined2 *)(arg1 + 0xa18) = 0;
        *(undefined4 *)(arg1 + 0xa1c) = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_180142258
// Address: 0x180142258
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180142130(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int16_t iVar4;
    undefined4 *puVar5;
    int32_t iVar6;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    *(undefined2 *)(arg1 + 0xa1a) = 99;
    *(undefined4 *)(arg1 + 0xa20) = 999;
    if (*(int16_t *)(arg1 + 0xa18) == 99) {
        fcn.180142080(arg1, unaff_RSI);
    }
    iVar6 = (int32_t)arg3;
    if (iVar6 < 1000) {
        iVar3 = *(int32_t *)(arg1 + 0xa1c);
        while (999 < iVar3 + iVar6) {
            iVar4 = *(int16_t *)(arg1 + 0xa18);
            if (0 < iVar4) {
                if (-1 < *(int32_t *)(arg1 + 0xc)) {
                    iVar1 = *(int32_t *)(arg1 + 4);
                    *(int32_t *)(arg1 + 0xa1c) = iVar3 - iVar1;
                    func_0x000180498030(arg1 + 0x630, arg1 + 0x630 + (int64_t)iVar1, (int64_t)(iVar3 - iVar1));
                    iVar4 = *(int16_t *)(arg1 + 0xa18);
                    iVar3 = 0;
                    if (0 < iVar4) {
                        do {
                            iVar2 = *(int32_t *)(arg1 + 0xc + (int64_t)iVar3 * 0x10);
                            if (-1 < iVar2) {
                                *(int32_t *)(arg1 + 0xc + (int64_t)iVar3 * 0x10) = iVar2 - iVar1;
                            }
                            iVar4 = *(int16_t *)(arg1 + 0xa18);
                            iVar3 = iVar3 + 1;
                        } while (iVar3 < iVar4);
                    }
                }
                *(int16_t *)(arg1 + 0xa18) = iVar4 + -1;
                func_0x000180498030(arg1, arg1 + 0x10, (int64_t)(int16_t)(iVar4 + -1) << 4);
            }
            iVar3 = *(int32_t *)(arg1 + 0xa1c);
        }
        iVar4 = *(int16_t *)(arg1 + 0xa18);
        *(int16_t *)(arg1 + 0xa18) = iVar4 + 1;
        puVar5 = (undefined4 *)((int64_t)iVar4 * 0x10 + arg1);
        if (puVar5 != (undefined4 *)0x0) {
            *puVar5 = (int32_t)arg2;
            puVar5[1] = iVar6;
            puVar5[2] = (int32_t)arg4;
            if (iVar6 != 0) {
                puVar5[3] = *(undefined4 *)(arg1 + 0xa1c);
                *(int32_t *)(arg1 + 0xa1c) = *(int32_t *)(arg1 + 0xa1c) + iVar6;
                return (int64_t)(int32_t)puVar5[3] + 0x630 + arg1;
            }
            puVar5[3] = 0xffffffff;
        }
    } else {
        *(undefined2 *)(arg1 + 0xa18) = 0;
        *(undefined4 *)(arg1 + 0xa1c) = 0;
    }
    return 0;
}

