// Chunk 33 - 50 functions

// ============================================================
// Function: FUN_18006c710
// Address: 0x18006c710
// Size: 25 bytes
// ============================================================
void fcn.18006c710(int64_t arg1, int64_t arg_48h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    uint64_t uVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    
    if ((*(int32_t *)(arg1 + 0x4830) != 0) && (iVar25 = 0, 0 < *(int32_t *)(*(int64_t *)arg1 + 8))) {
        do {
            iVar22 = 0;
            iVar23 = (int64_t)iVar25 * 0x60 + arg1;
            iVar21 = *(int32_t *)(iVar23 + 0x46bc) + 7 >> 3;
            iVar26 = *(int32_t *)(iVar23 + 0x46c0) + 7 >> 3;
            if (0 < iVar26) {
                do {
                    iVar20 = 0;
                    if (0 < iVar21) {
                        do {
                            uVar24 = (int64_t)*(int32_t *)(iVar23 + 0x46ac) * 0x80 + 0x3488 + arg1;
                            uVar1 = *(int64_t *)(iVar23 + 0x46f0) +
                                    (int64_t)((iVar22 * *(int32_t *)(iVar23 + 0x46f8) + iVar20) * 0x40) * 2;
                            if ((uVar24 + 0x7e < uVar1) || (uVar1 + 0x7e < uVar24)) {
                                iVar19 = 0;
                                do {
                                    piVar2 = (int16_t *)(uVar1 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x10 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x20 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x30 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    iVar19 = iVar19 + 0x20;
                                } while (iVar19 != 0x40);
                            } else {
                                iVar19 = 0;
                                do {
                                    *(int16_t *)(uVar1 + iVar19 * 2) =
                                         *(int16_t *)(uVar1 + iVar19 * 2) * *(int16_t *)(uVar24 + iVar19 * 2);
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 != 0x40);
                            }
                            (**(code **)(arg1 + 0x4870))
                                      ((int64_t)(iVar22 * *(int32_t *)(iVar23 + 0x46c4) * 8) + (int64_t)(iVar20 * 8) +
                                       *(int64_t *)(iVar23 + 0x46d0));
                            iVar20 = iVar20 + 1;
                        } while (iVar20 < iVar21);
                    }
                    iVar22 = iVar22 + 1;
                } while (iVar22 < iVar26);
            }
            iVar25 = iVar25 + 1;
        } while (iVar25 < *(int32_t *)(*(int64_t *)arg1 + 8));
    }
    return;
}

// ============================================================
// Function: FUN_18006c729
// Address: 0x18006c729
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18006c710(int64_t arg1, int64_t arg_48h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    uint64_t uVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    
    if ((*(int32_t *)(arg1 + 0x4830) != 0) && (iVar25 = 0, 0 < *(int32_t *)(*(int64_t *)arg1 + 8))) {
        do {
            iVar22 = 0;
            iVar23 = (int64_t)iVar25 * 0x60 + arg1;
            iVar21 = *(int32_t *)(iVar23 + 0x46bc) + 7 >> 3;
            iVar26 = *(int32_t *)(iVar23 + 0x46c0) + 7 >> 3;
            if (0 < iVar26) {
                do {
                    iVar20 = 0;
                    if (0 < iVar21) {
                        do {
                            uVar24 = (int64_t)*(int32_t *)(iVar23 + 0x46ac) * 0x80 + 0x3488 + arg1;
                            uVar1 = *(int64_t *)(iVar23 + 0x46f0) +
                                    (int64_t)((iVar22 * *(int32_t *)(iVar23 + 0x46f8) + iVar20) * 0x40) * 2;
                            if ((uVar24 + 0x7e < uVar1) || (uVar1 + 0x7e < uVar24)) {
                                iVar19 = 0;
                                do {
                                    piVar2 = (int16_t *)(uVar1 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x10 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x20 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x30 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    iVar19 = iVar19 + 0x20;
                                } while (iVar19 != 0x40);
                            } else {
                                iVar19 = 0;
                                do {
                                    *(int16_t *)(uVar1 + iVar19 * 2) =
                                         *(int16_t *)(uVar1 + iVar19 * 2) * *(int16_t *)(uVar24 + iVar19 * 2);
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 != 0x40);
                            }
                            (**(code **)(arg1 + 0x4870))
                                      ((int64_t)(iVar22 * *(int32_t *)(iVar23 + 0x46c4) * 8) + (int64_t)(iVar20 * 8) +
                                       *(int64_t *)(iVar23 + 0x46d0));
                            iVar20 = iVar20 + 1;
                        } while (iVar20 < iVar21);
                    }
                    iVar22 = iVar22 + 1;
                } while (iVar22 < iVar26);
            }
            iVar25 = iVar25 + 1;
        } while (iVar25 < *(int32_t *)(*(int64_t *)arg1 + 8));
    }
    return;
}

// ============================================================
// Function: FUN_18006c73b
// Address: 0x18006c73b
// Size: 426 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18006c710(int64_t arg1, int64_t arg_48h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    uint64_t uVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    
    if ((*(int32_t *)(arg1 + 0x4830) != 0) && (iVar25 = 0, 0 < *(int32_t *)(*(int64_t *)arg1 + 8))) {
        do {
            iVar22 = 0;
            iVar23 = (int64_t)iVar25 * 0x60 + arg1;
            iVar21 = *(int32_t *)(iVar23 + 0x46bc) + 7 >> 3;
            iVar26 = *(int32_t *)(iVar23 + 0x46c0) + 7 >> 3;
            if (0 < iVar26) {
                do {
                    iVar20 = 0;
                    if (0 < iVar21) {
                        do {
                            uVar24 = (int64_t)*(int32_t *)(iVar23 + 0x46ac) * 0x80 + 0x3488 + arg1;
                            uVar1 = *(int64_t *)(iVar23 + 0x46f0) +
                                    (int64_t)((iVar22 * *(int32_t *)(iVar23 + 0x46f8) + iVar20) * 0x40) * 2;
                            if ((uVar24 + 0x7e < uVar1) || (uVar1 + 0x7e < uVar24)) {
                                iVar19 = 0;
                                do {
                                    piVar2 = (int16_t *)(uVar1 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x10 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x20 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x30 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    iVar19 = iVar19 + 0x20;
                                } while (iVar19 != 0x40);
                            } else {
                                iVar19 = 0;
                                do {
                                    *(int16_t *)(uVar1 + iVar19 * 2) =
                                         *(int16_t *)(uVar1 + iVar19 * 2) * *(int16_t *)(uVar24 + iVar19 * 2);
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 != 0x40);
                            }
                            (**(code **)(arg1 + 0x4870))
                                      ((int64_t)(iVar22 * *(int32_t *)(iVar23 + 0x46c4) * 8) + (int64_t)(iVar20 * 8) +
                                       *(int64_t *)(iVar23 + 0x46d0));
                            iVar20 = iVar20 + 1;
                        } while (iVar20 < iVar21);
                    }
                    iVar22 = iVar22 + 1;
                } while (iVar22 < iVar26);
            }
            iVar25 = iVar25 + 1;
        } while (iVar25 < *(int32_t *)(*(int64_t *)arg1 + 8));
    }
    return;
}

// ============================================================
// Function: FUN_18006c8e5
// Address: 0x18006c8e5
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18006c710(int64_t arg1, int64_t arg_48h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    uint64_t uVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    
    if ((*(int32_t *)(arg1 + 0x4830) != 0) && (iVar25 = 0, 0 < *(int32_t *)(*(int64_t *)arg1 + 8))) {
        do {
            iVar22 = 0;
            iVar23 = (int64_t)iVar25 * 0x60 + arg1;
            iVar21 = *(int32_t *)(iVar23 + 0x46bc) + 7 >> 3;
            iVar26 = *(int32_t *)(iVar23 + 0x46c0) + 7 >> 3;
            if (0 < iVar26) {
                do {
                    iVar20 = 0;
                    if (0 < iVar21) {
                        do {
                            uVar24 = (int64_t)*(int32_t *)(iVar23 + 0x46ac) * 0x80 + 0x3488 + arg1;
                            uVar1 = *(int64_t *)(iVar23 + 0x46f0) +
                                    (int64_t)((iVar22 * *(int32_t *)(iVar23 + 0x46f8) + iVar20) * 0x40) * 2;
                            if ((uVar24 + 0x7e < uVar1) || (uVar1 + 0x7e < uVar24)) {
                                iVar19 = 0;
                                do {
                                    piVar2 = (int16_t *)(uVar1 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x10 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x20 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x30 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    iVar19 = iVar19 + 0x20;
                                } while (iVar19 != 0x40);
                            } else {
                                iVar19 = 0;
                                do {
                                    *(int16_t *)(uVar1 + iVar19 * 2) =
                                         *(int16_t *)(uVar1 + iVar19 * 2) * *(int16_t *)(uVar24 + iVar19 * 2);
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 != 0x40);
                            }
                            (**(code **)(arg1 + 0x4870))
                                      ((int64_t)(iVar22 * *(int32_t *)(iVar23 + 0x46c4) * 8) + (int64_t)(iVar20 * 8) +
                                       *(int64_t *)(iVar23 + 0x46d0));
                            iVar20 = iVar20 + 1;
                        } while (iVar20 < iVar21);
                    }
                    iVar22 = iVar22 + 1;
                } while (iVar22 < iVar26);
            }
            iVar25 = iVar25 + 1;
        } while (iVar25 < *(int32_t *)(*(int64_t *)arg1 + 8));
    }
    return;
}

// ============================================================
// Function: FUN_18006c8ea
// Address: 0x18006c8ea
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18006c710(int64_t arg1, int64_t arg_48h)
{
    uint64_t uVar1;
    int16_t *piVar2;
    int16_t *piVar3;
    int16_t *piVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int64_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    int64_t iVar23;
    uint64_t uVar24;
    int32_t iVar25;
    int32_t iVar26;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    
    if ((*(int32_t *)(arg1 + 0x4830) != 0) && (iVar25 = 0, 0 < *(int32_t *)(*(int64_t *)arg1 + 8))) {
        do {
            iVar22 = 0;
            iVar23 = (int64_t)iVar25 * 0x60 + arg1;
            iVar21 = *(int32_t *)(iVar23 + 0x46bc) + 7 >> 3;
            iVar26 = *(int32_t *)(iVar23 + 0x46c0) + 7 >> 3;
            if (0 < iVar26) {
                do {
                    iVar20 = 0;
                    if (0 < iVar21) {
                        do {
                            uVar24 = (int64_t)*(int32_t *)(iVar23 + 0x46ac) * 0x80 + 0x3488 + arg1;
                            uVar1 = *(int64_t *)(iVar23 + 0x46f0) +
                                    (int64_t)((iVar22 * *(int32_t *)(iVar23 + 0x46f8) + iVar20) * 0x40) * 2;
                            if ((uVar24 + 0x7e < uVar1) || (uVar1 + 0x7e < uVar24)) {
                                iVar19 = 0;
                                do {
                                    piVar2 = (int16_t *)(uVar1 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x10 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x10 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x20 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x20 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    piVar2 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    iVar5 = piVar2[1];
                                    iVar6 = piVar2[2];
                                    iVar7 = piVar2[3];
                                    iVar8 = piVar2[4];
                                    iVar9 = piVar2[5];
                                    iVar10 = piVar2[6];
                                    iVar11 = piVar2[7];
                                    piVar3 = (int16_t *)(uVar24 + 0x30 + iVar19 * 2);
                                    iVar12 = piVar3[1];
                                    iVar13 = piVar3[2];
                                    iVar14 = piVar3[3];
                                    iVar15 = piVar3[4];
                                    iVar16 = piVar3[5];
                                    iVar17 = piVar3[6];
                                    iVar18 = piVar3[7];
                                    piVar4 = (int16_t *)(uVar1 + 0x30 + iVar19 * 2);
                                    *piVar4 = *piVar3 * *piVar2;
                                    piVar4[1] = iVar12 * iVar5;
                                    piVar4[2] = iVar13 * iVar6;
                                    piVar4[3] = iVar14 * iVar7;
                                    piVar4[4] = iVar15 * iVar8;
                                    piVar4[5] = iVar16 * iVar9;
                                    piVar4[6] = iVar17 * iVar10;
                                    piVar4[7] = iVar18 * iVar11;
                                    iVar19 = iVar19 + 0x20;
                                } while (iVar19 != 0x40);
                            } else {
                                iVar19 = 0;
                                do {
                                    *(int16_t *)(uVar1 + iVar19 * 2) =
                                         *(int16_t *)(uVar1 + iVar19 * 2) * *(int16_t *)(uVar24 + iVar19 * 2);
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 != 0x40);
                            }
                            (**(code **)(arg1 + 0x4870))
                                      ((int64_t)(iVar22 * *(int32_t *)(iVar23 + 0x46c4) * 8) + (int64_t)(iVar20 * 8) +
                                       *(int64_t *)(iVar23 + 0x46d0));
                            iVar20 = iVar20 + 1;
                        } while (iVar20 < iVar21);
                    }
                    iVar22 = iVar22 + 1;
                } while (iVar22 < iVar26);
            }
            iVar25 = iVar25 + 1;
        } while (iVar25 < *(int32_t *)(*(int64_t *)arg1 + 8));
    }
    return;
}

// ============================================================
// Function: FUN_18006c900
// Address: 0x18006c900
// Size: 2099 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_1a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel

bool fcn.18006c900(int64_t arg1, int64_t arg2)
{
    int16_t *piVar1;
    char cVar2;
    uint8_t uVar3;
    uint8_t *puVar4;
    undefined *puVar5;
    int8_t iVar6;
    bool bVar7;
    uint8_t uVar8;
    uint16_t uVar9;
    int32_t iVar10;
    int32_t iVar11;
    undefined4 uVar12;
    uint32_t uVar13;
    char *pcVar14;
    int64_t iVar15;
    char cVar16;
    char cVar17;
    char cVar18;
    char cVar19;
    undefined uVar20;
    int32_t iVar21;
    int64_t iVar22;
    int64_t iVar23;
    uint64_t uVar24;
    uint32_t uVar25;
    uint32_t uVar26;
    uint64_t uVar27;
    int64_t var_8h;
    int64_t var_98h;
    int64_t var_88h;
    
    iVar11 = (int32_t)arg2;
    if (iVar11 == 0xc4) {
        iVar11 = func_0x000180069950();
        iVar11 = iVar11 + -2;
        while( true ) {
            if (iVar11 < 1) {
                return iVar11 == 0;
            }
            iVar23 = *(int64_t *)arg1;
            puVar4 = *(uint8_t **)(iVar23 + 0xc0);
            if (puVar4 < *(uint8_t **)(iVar23 + 200)) {
                uVar8 = *puVar4;
                *(uint8_t **)(iVar23 + 0xc0) = puVar4 + 1;
            } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
                uVar8 = 0;
            } else {
                func_0x000180069750(iVar23);
                uVar8 = **(uint8_t **)(iVar23 + 0xc0);
                *(uint8_t **)(iVar23 + 0xc0) = *(uint8_t **)(iVar23 + 0xc0) + 1;
            }
            uVar24 = 0;
            uVar3 = uVar8 >> 4;
            if ((1 < uVar3) || (uVar13 = uVar8 & 0xf, uVar27 = uVar24, 3 < uVar13)) break;
            do {
                iVar23 = *(int64_t *)arg1;
                puVar4 = *(uint8_t **)(iVar23 + 0xc0);
                if (puVar4 < *(uint8_t **)(iVar23 + 200)) {
                    uVar8 = *puVar4;
                    *(uint8_t **)(iVar23 + 0xc0) = puVar4 + 1;
                } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
                    uVar8 = 0;
                } else {
                    func_0x000180069750(iVar23);
                    uVar8 = **(uint8_t **)(iVar23 + 0xc0);
                    *(uint8_t **)(iVar23 + 0xc0) = *(uint8_t **)(iVar23 + 0xc0) + 1;
                }
                *(uint32_t *)((int64_t)&var_88h + uVar24 * 4) = (uint32_t)uVar8;
                uVar26 = (int32_t)uVar27 + (uint32_t)uVar8;
                uVar24 = uVar24 + 1;
                uVar27 = (uint64_t)uVar26;
            } while (uVar24 != 0x10);
            iVar23 = (uint64_t)uVar13 * 0x690 + arg1;
            if (uVar3 == 0) {
                iVar10 = func_0x00018006a460();
                if (iVar10 == 0) {
                    return false;
                }
                iVar22 = iVar23 + 0x408;
            } else {
                iVar10 = func_0x00018006a460();
                if (iVar10 == 0) {
                    return false;
                }
                iVar22 = iVar23 + 0x1e48;
            }
            iVar10 = 0;
            if (0 < (int32_t)uVar26) {
                do {
                    iVar15 = *(int64_t *)arg1;
                    puVar5 = *(undefined **)(iVar15 + 0xc0);
                    if (puVar5 < *(undefined **)(iVar15 + 200)) {
                        uVar20 = *puVar5;
                        *(undefined **)(iVar15 + 0xc0) = puVar5 + 1;
                    } else if (*(int32_t *)(iVar15 + 0x30) == 0) {
                        uVar20 = 0;
                    } else {
                        func_0x000180069750(iVar15);
                        uVar20 = **(undefined **)(iVar15 + 0xc0);
                        *(undefined **)(iVar15 + 0xc0) = *(undefined **)(iVar15 + 0xc0) + 1;
                    }
                    iVar15 = (int64_t)iVar10;
                    iVar10 = iVar10 + 1;
                    *(undefined *)(iVar15 + iVar22) = uVar20;
                } while (iVar10 < (int32_t)uVar26);
            }
            uVar24 = 0;
            iVar23 = iVar23 + 0x1a48;
            if (uVar3 != 0) {
                do {
                    piVar1 = (int16_t *)(arg1 + 0x3688 + (uint64_t)uVar13 * 0x400 + uVar24 * 2);
                    uVar8 = *(uint8_t *)(uVar24 + iVar23);
                    *piVar1 = 0;
                    if (uVar8 != 0xff) {
                        uVar3 = *(uint8_t *)((uint64_t)uVar8 + 0x400 + iVar23);
                        uVar9 = uVar3 & 0xf;
                        if (((uVar3 & 0xf) != 0) &&
                           (uVar8 = *(uint8_t *)((uint64_t)uVar8 + 0x500 + iVar23), (uint16_t)(uVar8 + uVar9) < 10)) {
                            iVar6 = (int8_t)uVar9;
                            iVar10 = (int32_t)((int32_t)uVar24 << (uVar8 & 0x1f) & 0x1ffU) >> (9U - iVar6 & 0x1f);
                            if (iVar10 < 1 << (iVar6 - 1U & 0x1f)) {
                                iVar10 = (iVar10 - (1 << iVar6)) + 1;
                            }
                            if (iVar10 + 0x80U < 0x100) {
                                *piVar1 = ((uint16_t)(uVar3 >> 4) + (int16_t)iVar10 * 0x10) * 0x10 + (uint16_t)uVar8 +
                                          uVar9;
                            }
                        }
                    }
                    uVar25 = (int32_t)uVar24 + 1;
                    uVar24 = (uint64_t)uVar25;
                } while ((int32_t)uVar25 < 0x200);
            }
            iVar11 = (iVar11 + -0x11) - uVar26;
        }
        return false;
    }
    if (iVar11 == 0xdb) {
        iVar11 = func_0x000180069950();
        iVar11 = iVar11 + -2;
        while( true ) {
            if (iVar11 < 1) {
                return iVar11 == 0;
            }
            iVar23 = *(int64_t *)arg1;
            puVar4 = *(uint8_t **)(iVar23 + 0xc0);
            if (puVar4 < *(uint8_t **)(iVar23 + 200)) {
                uVar24 = (uint64_t)*puVar4;
                *(uint8_t **)(iVar23 + 0xc0) = puVar4 + 1;
            } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
                uVar24 = 0;
            } else {
                func_0x000180069750(iVar23);
                uVar24 = (uint64_t)**(uint8_t **)(iVar23 + 0xc0);
                *(uint8_t **)(iVar23 + 0xc0) = *(uint8_t **)(iVar23 + 0xc0) + 1;
            }
            uVar27 = uVar24 >> 4;
            if (1 < (uint32_t)uVar27) break;
            uVar13 = (uint32_t)uVar24 & 0xf;
            if (3 < uVar13) {
                return false;
            }
            iVar23 = 0;
            do {
                iVar22 = *(int64_t *)arg1;
                if (uVar27 == 0) {
                    puVar4 = *(uint8_t **)(iVar22 + 0xc0);
                    if (puVar4 < *(uint8_t **)(iVar22 + 200)) {
                        uVar8 = *puVar4;
                        *(uint8_t **)(iVar22 + 0xc0) = puVar4 + 1;
                    } else if (*(int32_t *)(iVar22 + 0x30) == 0) {
                        uVar8 = 0;
                    } else {
                        func_0x000180069750(iVar22);
                        uVar8 = **(uint8_t **)(iVar22 + 0xc0);
                        *(uint8_t **)(iVar22 + 0xc0) = *(uint8_t **)(iVar22 + 0xc0) + 1;
                    }
                    uVar9 = (uint16_t)uVar8;
                } else {
                    uVar9 = func_0x000180069950(iVar22);
                }
                puVar4 = (uint8_t *)(iVar23 + 0x1805ab4c0);
                iVar23 = iVar23 + 1;
                *(uint16_t *)((uint64_t)uVar13 * 0x80 + arg1 + 0x3488 + (uint64_t)*puVar4 * 2) = uVar9;
            } while (iVar23 != 0x40);
            iVar10 = 0x41;
            if (uVar27 != 0) {
                iVar10 = 0x81;
            }
            iVar11 = iVar11 - iVar10;
        }
        return false;
    }
    if (iVar11 == 0xdd) {
        iVar11 = func_0x000180069950(*(undefined8 *)arg1);
        if (iVar11 != 4) {
            return false;
        }
        uVar12 = func_0x000180069950(*(undefined8 *)arg1);
        *(undefined4 *)(arg1 + 0x4868) = uVar12;
        return true;
    }
    if (iVar11 == 0xff) {
        return false;
    }
    if ((0xf < iVar11 - 0xe0U) && (iVar11 != 0xfe)) {
        return false;
    }
    iVar10 = func_0x000180069950();
    if (iVar10 < 2) {
        return false;
    }
    iVar21 = iVar10 + -2;
    if (iVar11 == 0xe0) {
        if (iVar21 < 5) goto code_r0x00018006cd24;
        iVar23 = *(int64_t *)arg1;
        pcVar14 = *(char **)(iVar23 + 0xc0);
        if (pcVar14 < *(char **)(iVar23 + 200)) {
            cVar16 = *pcVar14;
            *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
            cVar16 = '\0';
        } else {
            func_0x000180069750(iVar23);
            cVar16 = **(char **)(iVar23 + 0xc0);
            *(char **)(iVar23 + 0xc0) = *(char **)(iVar23 + 0xc0) + 1;
        }
        iVar23 = *(int64_t *)arg1;
        pcVar14 = *(char **)(iVar23 + 0xc0);
        if (pcVar14 < *(char **)(iVar23 + 200)) {
            cVar17 = *pcVar14;
            *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
            cVar17 = '\0';
        } else {
            func_0x000180069750(iVar23);
            cVar17 = **(char **)(iVar23 + 0xc0);
            *(char **)(iVar23 + 0xc0) = *(char **)(iVar23 + 0xc0) + 1;
        }
        iVar23 = *(int64_t *)arg1;
        pcVar14 = *(char **)(iVar23 + 0xc0);
        if (pcVar14 < *(char **)(iVar23 + 200)) {
            cVar18 = *pcVar14;
            *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
            cVar18 = '\0';
        } else {
            func_0x000180069750(iVar23);
            cVar18 = **(char **)(iVar23 + 0xc0);
            *(char **)(iVar23 + 0xc0) = *(char **)(iVar23 + 0xc0) + 1;
        }
        iVar23 = *(int64_t *)arg1;
        pcVar14 = *(char **)(iVar23 + 0xc0);
        if (pcVar14 < *(char **)(iVar23 + 200)) {
            cVar19 = *pcVar14;
            *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
            cVar19 = '\0';
        } else {
            func_0x000180069750(iVar23);
            cVar19 = **(char **)(iVar23 + 0xc0);
            *(char **)(iVar23 + 0xc0) = *(char **)(iVar23 + 0xc0) + 1;
        }
        iVar23 = *(int64_t *)arg1;
        pcVar14 = *(char **)(iVar23 + 0xc0);
        if (pcVar14 < *(char **)(iVar23 + 200)) {
code_r0x00018006caef:
            cVar2 = *pcVar14;
            *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
            if (cVar2 != '\0') {
                func_0x000180069830(*(undefined8 *)arg1, iVar10 + -7);
                return true;
            }
        } else if (*(int32_t *)(iVar23 + 0x30) != 0) {
            func_0x000180069750(iVar23);
            pcVar14 = *(char **)(iVar23 + 0xc0);
            goto code_r0x00018006caef;
        }
        iVar21 = iVar10 + -7;
        if (cVar19 == 'F' && (cVar18 == 'I' && (cVar17 == 'F' && cVar16 == 'J'))) {
            *(undefined4 *)(arg1 + 0x4848) = 1;
            func_0x000180069830(*(undefined8 *)arg1, iVar21);
            return true;
        }
        goto code_r0x00018006cd24;
    }
    if ((iVar11 != 0xee) || (iVar21 < 0xc)) goto code_r0x00018006cd24;
    iVar23 = *(int64_t *)arg1;
    pcVar14 = *(char **)(iVar23 + 0xc0);
    if (pcVar14 < *(char **)(iVar23 + 200)) {
        cVar16 = *pcVar14;
        *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
    } else if (*(int32_t *)(iVar23 + 0x30) == 0) {
        cVar16 = '\0';
    } else {
        func_0x000180069750(iVar23);
        cVar16 = **(char **)(iVar23 + 0xc0);
        *(char **)(iVar23 + 0xc0) = *(char **)(iVar23 + 0xc0) + 1;
    }
    iVar23 = *(int64_t *)arg1;
    pcVar14 = *(char **)(iVar23 + 0xc0);
    if (pcVar14 < *(char **)(iVar23 + 200)) {
code_r0x00018006cbd4:
        cVar17 = *pcVar14;
        *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        bVar7 = cVar16 == 'A';
        if (cVar17 != 'd') goto code_r0x00018006cbe6;
    } else {
        if (*(int32_t *)(iVar23 + 0x30) != 0) {
            func_0x000180069750(iVar23);
            pcVar14 = *(char **)(iVar23 + 0xc0);
            goto code_r0x00018006cbd4;
        }
code_r0x00018006cbe6:
        bVar7 = false;
    }
    iVar23 = *(int64_t *)arg1;
    pcVar14 = *(char **)(iVar23 + 0xc0);
    if (pcVar14 < *(char **)(iVar23 + 200)) {
code_r0x00018006cc11:
        cVar16 = *pcVar14;
        *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        if (cVar16 != 'o') goto code_r0x00018006cc23;
    } else {
        if (*(int32_t *)(iVar23 + 0x30) != 0) {
            func_0x000180069750(iVar23);
            pcVar14 = *(char **)(iVar23 + 0xc0);
            goto code_r0x00018006cc11;
        }
code_r0x00018006cc23:
        bVar7 = false;
    }
    iVar23 = *(int64_t *)arg1;
    pcVar14 = *(char **)(iVar23 + 0xc0);
    if (pcVar14 < *(char **)(iVar23 + 200)) {
code_r0x00018006cc4e:
        cVar16 = *pcVar14;
        *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        if (cVar16 != 'b') goto code_r0x00018006cc60;
    } else {
        if (*(int32_t *)(iVar23 + 0x30) != 0) {
            func_0x000180069750(iVar23);
            pcVar14 = *(char **)(iVar23 + 0xc0);
            goto code_r0x00018006cc4e;
        }
code_r0x00018006cc60:
        bVar7 = false;
    }
    iVar23 = *(int64_t *)arg1;
    pcVar14 = *(char **)(iVar23 + 0xc0);
    if (pcVar14 < *(char **)(iVar23 + 200)) {
code_r0x00018006cc8b:
        cVar16 = *pcVar14;
        *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        if (cVar16 != 'e') goto code_r0x00018006cc9d;
    } else {
        if (*(int32_t *)(iVar23 + 0x30) != 0) {
            func_0x000180069750(iVar23);
            pcVar14 = *(char **)(iVar23 + 0xc0);
            goto code_r0x00018006cc8b;
        }
code_r0x00018006cc9d:
        bVar7 = false;
    }
    iVar23 = *(int64_t *)arg1;
    pcVar14 = *(char **)(iVar23 + 0xc0);
    if (pcVar14 < *(char **)(iVar23 + 200)) {
code_r0x00018006ccc8:
        cVar16 = *pcVar14;
        *(char **)(iVar23 + 0xc0) = pcVar14 + 1;
        if (cVar16 != '\0') {
            func_0x000180069830(*(undefined8 *)arg1, iVar10 + -8);
            return true;
        }
    } else if (*(int32_t *)(iVar23 + 0x30) != 0) {
        func_0x000180069750(iVar23);
        pcVar14 = *(char **)(iVar23 + 0xc0);
        goto code_r0x00018006ccc8;
    }
    iVar21 = iVar10 + -8;
    if (bVar7) {
        func_0x0001800697d0(*(undefined8 *)arg1);
        func_0x000180069950(*(undefined8 *)arg1);
        func_0x000180069950(*(undefined8 *)arg1);
        uVar8 = func_0x0001800697d0(*(undefined8 *)arg1);
        iVar21 = iVar10 + -0xe;
        *(uint32_t *)(arg1 + 0x484c) = (uint32_t)uVar8;
    }
code_r0x00018006cd24:
    func_0x000180069830(*(undefined8 *)arg1, iVar21);
    return true;
}

// ============================================================
// Function: FUN_18006d140
// Address: 0x18006d140
// Size: 620 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18006d140(int64_t arg1)
{
    int32_t iVar1;
    uint8_t *puVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = func_0x000180069950();
    iVar8 = *(int64_t *)arg1;
    puVar2 = *(uint8_t **)(iVar8 + 0xc0);
    if (puVar2 < *(uint8_t **)(iVar8 + 200)) {
        uVar3 = *puVar2;
        *(uint8_t **)(iVar8 + 0xc0) = puVar2 + 1;
    } else if (*(int32_t *)(iVar8 + 0x30) == 0) {
        uVar3 = 0;
    } else {
        func_0x000180069750(iVar8);
        uVar3 = **(uint8_t **)(iVar8 + 0xc0);
        *(uint8_t **)(iVar8 + 0xc0) = *(uint8_t **)(iVar8 + 0xc0) + 1;
    }
    *(uint32_t *)(arg1 + 0x4854) = (uint32_t)uVar3;
    if (((uVar3 - 1 < 4) &&
        ((uint32_t)uVar3 == *(uint32_t *)(*(int64_t *)arg1 + 8) ||
         (int32_t)(uint32_t)uVar3 < (int32_t)*(uint32_t *)(*(int64_t *)arg1 + 8))) && (iVar5 == (uint32_t)uVar3 * 2 + 6)
       ) {
        iVar5 = 0;
        do {
            iVar8 = *(int64_t *)arg1;
            puVar2 = *(uint8_t **)(iVar8 + 0xc0);
            if (puVar2 < *(uint8_t **)(iVar8 + 200)) {
                uVar3 = *puVar2;
                *(uint8_t **)(iVar8 + 0xc0) = puVar2 + 1;
            } else if (*(int32_t *)(iVar8 + 0x30) == 0) {
                uVar3 = 0;
            } else {
                func_0x000180069750(iVar8);
                uVar3 = **(uint8_t **)(iVar8 + 0xc0);
                *(uint8_t **)(iVar8 + 0xc0) = *(uint8_t **)(iVar8 + 0xc0) + 1;
            }
            iVar8 = *(int64_t *)arg1;
            puVar2 = *(uint8_t **)(iVar8 + 0xc0);
            if (puVar2 < *(uint8_t **)(iVar8 + 200)) {
                uVar4 = *puVar2;
                *(uint8_t **)(iVar8 + 0xc0) = puVar2 + 1;
            } else if (*(int32_t *)(iVar8 + 0x30) == 0) {
                uVar4 = 0;
            } else {
                func_0x000180069750(iVar8);
                uVar4 = **(uint8_t **)(iVar8 + 0xc0);
                *(uint8_t **)(iVar8 + 0xc0) = *(uint8_t **)(iVar8 + 0xc0) + 1;
            }
            uVar7 = 0;
            iVar1 = *(int32_t *)(*(int64_t *)arg1 + 8);
            if (0 < iVar1) {
                do {
                    if (*(uint32_t *)(uVar7 * 0x60 + 0x46a0 + arg1) == (uint32_t)uVar3) goto code_r0x00018006d2b1;
                    uVar6 = (int32_t)uVar7 + 1;
                    uVar7 = (uint64_t)uVar6;
                } while ((int32_t)uVar6 < iVar1);
            }
            if ((int32_t)uVar7 == iVar1) {
                return 0;
            }
code_r0x00018006d2b1:
            iVar8 = (int64_t)(int32_t)uVar7 * 0x60;
            *(uint32_t *)(iVar8 + 0x46b0 + arg1) = (uint32_t)(uVar4 >> 4);
            if (3 < uVar4 >> 4) {
                return 0;
            }
            *(uint32_t *)(iVar8 + 0x46b4 + arg1) = uVar4 & 0xf;
            if (3 < (uVar4 & 0xf)) {
                return 0;
            }
            iVar8 = (int64_t)iVar5;
            iVar5 = iVar5 + 1;
            *(int32_t *)(arg1 + 0x4858 + iVar8 * 4) = (int32_t)uVar7;
        } while (iVar5 < *(int32_t *)(arg1 + 0x4854));
        uVar3 = func_0x0001800697d0(*(undefined8 *)arg1);
        *(uint32_t *)(arg1 + 0x4834) = (uint32_t)uVar3;
        uVar3 = func_0x0001800697d0(*(undefined8 *)arg1);
        *(uint32_t *)(arg1 + 0x4838) = (uint32_t)uVar3;
        uVar4 = func_0x0001800697d0(*(undefined8 *)arg1);
        iVar5 = *(int32_t *)(arg1 + 0x4834);
        uVar3 = uVar4 >> 4;
        *(uint32_t *)(arg1 + 0x483c) = (uint32_t)uVar3;
        *(uint32_t *)(arg1 + 0x4840) = uVar4 & 0xf;
        if (*(int32_t *)(arg1 + 0x4830) == 0) {
            if (((iVar5 == 0) && (uVar3 == 0)) && ((uVar4 & 0xf) == 0)) {
                *(undefined4 *)(arg1 + 0x4838) = 0x3f;
                return 1;
            }
        } else if (((iVar5 < 0x40) && (*(int32_t *)(arg1 + 0x4838) < 0x40)) &&
                  ((iVar5 <= *(int32_t *)(arg1 + 0x4838) && ((uVar3 < 0xe && ((uVar4 & 0xf) < 0xe)))))) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18006d3b0
// Address: 0x18006d3b0
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18006d3b0(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint64_t uVar3;
    
    uVar3 = 0;
    uVar4 = uVar3;
    if (0 < (int32_t)arg2) {
        do {
            iVar1 = uVar4 * 0x60 + arg1;
            if (*(int64_t *)(iVar1 + 0x46d8) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x46d8) = 0;
                *(undefined8 *)(iVar1 + 0x46d0) = 0;
            }
            iVar5 = (uVar4 + 0xbd) * 0x60;
            if (*(int64_t *)(iVar5 + arg1) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar5 + arg1) = 0;
                *(undefined8 *)(iVar1 + 0x46f0) = 0;
            }
            if (*(int64_t *)(iVar1 + 0x46e8) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x46e8) = 0;
            }
            uVar2 = (int32_t)uVar3 + 1;
            uVar3 = (uint64_t)uVar2;
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar2 < (int32_t)arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18006d3d1
// Address: 0x18006d3d1
// Size: 148 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18006d3b0(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint64_t uVar3;
    
    uVar3 = 0;
    uVar4 = uVar3;
    if (0 < (int32_t)arg2) {
        do {
            iVar1 = uVar4 * 0x60 + arg1;
            if (*(int64_t *)(iVar1 + 0x46d8) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x46d8) = 0;
                *(undefined8 *)(iVar1 + 0x46d0) = 0;
            }
            iVar5 = (uVar4 + 0xbd) * 0x60;
            if (*(int64_t *)(iVar5 + arg1) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar5 + arg1) = 0;
                *(undefined8 *)(iVar1 + 0x46f0) = 0;
            }
            if (*(int64_t *)(iVar1 + 0x46e8) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x46e8) = 0;
            }
            uVar2 = (int32_t)uVar3 + 1;
            uVar3 = (uint64_t)uVar2;
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar2 < (int32_t)arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18006d465
// Address: 0x18006d465
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.18006d3b0(int64_t arg1, int64_t arg2, int64_t arg_48h)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint64_t uVar3;
    
    uVar3 = 0;
    uVar4 = uVar3;
    if (0 < (int32_t)arg2) {
        do {
            iVar1 = uVar4 * 0x60 + arg1;
            if (*(int64_t *)(iVar1 + 0x46d8) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x46d8) = 0;
                *(undefined8 *)(iVar1 + 0x46d0) = 0;
            }
            iVar5 = (uVar4 + 0xbd) * 0x60;
            if (*(int64_t *)(iVar5 + arg1) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar5 + arg1) = 0;
                *(undefined8 *)(iVar1 + 0x46f0) = 0;
            }
            if (*(int64_t *)(iVar1 + 0x46e8) != 0) {
                func_0x000180460d90();
                *(undefined8 *)(iVar1 + 0x46e8) = 0;
            }
            uVar2 = (int32_t)uVar3 + 1;
            uVar3 = (uint64_t)uVar2;
            uVar4 = uVar4 + 1;
        } while ((int32_t)uVar2 < (int32_t)arg2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18006d480
// Address: 0x18006d480
// Size: 1788 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_46a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel

bool fcn.18006d480(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    char cVar2;
    uint8_t uVar3;
    int32_t iVar4;
    uint8_t *puVar5;
    int64_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    uint32_t *puVar14;
    int32_t iVar15;
    uint64_t uVar16;
    int32_t iVar17;
    int32_t iVar18;
    int64_t unaff_R12;
    int64_t iVar19;
    uint32_t uVar20;
    int64_t var_1h;
    
    uVar13 = 0;
    *(undefined4 *)(arg1 + 0x484c) = 0xffffffff;
    *(undefined4 *)(arg1 + 0x4848) = 0;
    *(undefined *)(arg1 + 0x4828) = 0xff;
    cVar2 = func_0x00018006be40();
    if (cVar2 == -0x28) {
        if ((int32_t)arg2 == 1) {
            return true;
        }
        uVar3 = func_0x00018006be40(arg1);
        uVar7 = (uint32_t)uVar3;
        if (uVar3 != 0xc0) {
code_r0x00018006d4e0:
            if (1 < uVar7 - 0xc1) {
                iVar4 = fcn.18006c900(arg1, (uint64_t)uVar7);
                if (iVar4 == 0) {
                    return false;
                }
                uVar3 = *(uint8_t *)(arg1 + 0x4828);
                if (uVar3 == 0xff) {
                    cVar2 = func_0x0001800697d0();
                    if (cVar2 == -1) {
                        do {
                            iVar12 = *(int64_t *)arg1;
                            puVar5 = *(uint8_t **)(iVar12 + 0xc0);
                            if (*(uint8_t **)(iVar12 + 200) <= puVar5) {
                                if (*(int32_t *)(iVar12 + 0x30) == 0) goto code_r0x00018006d60c;
                                func_0x000180069750(iVar12);
                                puVar5 = *(uint8_t **)(iVar12 + 0xc0);
                            }
                            uVar3 = *puVar5;
                            *(uint8_t **)(iVar12 + 0xc0) = puVar5 + 1;
                        } while (uVar3 == 0xff);
                    } else {
                        do {
                            iVar12 = *(int64_t *)arg1;
                            if (*(int64_t *)(iVar12 + 0x10) == 0) {
code_r0x00018006d54e:
                                if (*(uint64_t *)(iVar12 + 200) <= *(uint64_t *)(iVar12 + 0xc0)) {
                                    return false;
                                }
                            } else {
                                iVar4 = (**(code **)(iVar12 + 0x20))(*(undefined8 *)(iVar12 + 0x28));
                                if (iVar4 != 0) {
                                    if (*(int32_t *)(iVar12 + 0x30) == 0) {
                                        return false;
                                    }
                                    goto code_r0x00018006d54e;
                                }
                            }
                            uVar3 = *(uint8_t *)(arg1 + 0x4828);
                            if (uVar3 != 0xff) {
                                *(undefined *)(arg1 + 0x4828) = 0xff;
                                goto code_r0x00018006d611;
                            }
                            cVar2 = func_0x0001800697d0();
                        } while (cVar2 != -1);
                        do {
                            iVar12 = *(int64_t *)arg1;
                            puVar5 = *(uint8_t **)(iVar12 + 0xc0);
                            if (*(uint8_t **)(iVar12 + 200) <= puVar5) {
                                if (*(int32_t *)(iVar12 + 0x30) == 0) goto code_r0x00018006d60c;
                                func_0x000180069750(iVar12);
                                puVar5 = *(uint8_t **)(iVar12 + 0xc0);
                            }
                            uVar3 = *puVar5;
                            *(uint8_t **)(iVar12 + 0xc0) = puVar5 + 1;
                        } while (uVar3 == 0xff);
                    }
                } else {
                    *(undefined *)(arg1 + 0x4828) = 0xff;
                }
                goto code_r0x00018006d611;
            }
        }
code_r0x00018006d61d:
        puVar1 = *(uint32_t **)arg1;
        *(uint32_t *)(arg1 + 0x4830) = (uint32_t)(uVar7 == 0xc2);
        iVar4 = func_0x000180069950(puVar1);
        if ((10 < iVar4) && (cVar2 = func_0x0001800697d0(puVar1), cVar2 == '\b')) {
            uVar7 = func_0x000180069950(puVar1);
            puVar1[1] = uVar7;
            if (uVar7 != 0) {
                uVar7 = func_0x000180069950(puVar1);
                *puVar1 = uVar7;
                if (((uVar7 != 0) && (puVar1[1] < 0x1000001)) && (uVar7 < 0x1000001)) {
                    uVar3 = func_0x0001800697d0(puVar1);
                    uVar7 = (uint32_t)uVar3;
                    if (((uVar7 == 3) || (uVar7 == 1)) || (uVar7 == 4)) {
                        puVar1[2] = uVar7;
                        uVar10 = uVar13;
                        if (uVar3 != 0) {
                            do {
                                uVar8 = (int32_t)uVar10 + 1;
                                *(undefined8 *)(uVar10 * 0x60 + 0x46d0 + arg1) = 0;
                                *(undefined8 *)(uVar10 * 0x60 + 0x46e8 + arg1) = 0;
                                uVar10 = (uint64_t)uVar8;
                            } while ((int32_t)uVar8 < (int32_t)uVar7);
                        }
                        if (iVar4 == puVar1[2] * 3 + 8) {
                            *(undefined4 *)(arg1 + 0x4850) = 0;
                            uVar7 = puVar1[2];
                            uVar10 = uVar13;
                            if (0 < (int32_t)uVar7) {
                                do {
                                    puVar14 = puVar1 + 0xc;
                                    puVar5 = *(uint8_t **)(puVar1 + 0x30);
                                    if (puVar5 < *(uint8_t **)(puVar1 + 0x32)) {
                                        uVar3 = *puVar5;
                                        *(uint8_t **)(puVar1 + 0x30) = puVar5 + 1;
                                    } else if (*puVar14 == 0) {
                                        uVar3 = 0;
                                    } else {
                                        func_0x000180069750(puVar1);
                                        uVar3 = **(uint8_t **)(puVar1 + 0x30);
                                        *(uint8_t **)(puVar1 + 0x30) = *(uint8_t **)(puVar1 + 0x30) + 1;
                                    }
                                    iVar4 = (int32_t)uVar10;
                                    iVar12 = (int64_t)iVar4 * 0x60 + arg1;
                                    *(uint32_t *)(iVar12 + 0x46a0) = (uint32_t)uVar3;
                                    if ((puVar1[2] == 3) &&
                                       ((uint32_t)uVar3 == (uint32_t)*(uint8_t *)((int64_t)iVar4 + 0x18063d284))) {
                                        *(int32_t *)(arg1 + 0x4850) = *(int32_t *)(arg1 + 0x4850) + 1;
                                    }
                                    puVar5 = *(uint8_t **)(puVar1 + 0x30);
                                    if (puVar5 < *(uint8_t **)(puVar1 + 0x32)) {
                                        uVar3 = *puVar5;
                                        *(uint8_t **)(puVar1 + 0x30) = puVar5 + 1;
                                    } else if (*puVar14 == 0) {
                                        uVar3 = 0;
                                    } else {
                                        func_0x000180069750(puVar1);
                                        uVar3 = **(uint8_t **)(puVar1 + 0x30);
                                        *(uint8_t **)(puVar1 + 0x30) = *(uint8_t **)(puVar1 + 0x30) + 1;
                                    }
                                    *(uint32_t *)(iVar12 + 0x46a4) = (uint32_t)(uVar3 >> 4);
                                    if (3 < (uVar3 >> 4) - 1) {
                                        return false;
                                    }
                                    *(uint32_t *)(iVar12 + 0x46a8) = uVar3 & 0xf;
                                    if (3 < (uVar3 & 0xf) - 1) {
                                        return false;
                                    }
                                    puVar5 = *(uint8_t **)(puVar1 + 0x30);
                                    if (puVar5 < *(uint8_t **)(puVar1 + 0x32)) {
                                        uVar3 = *puVar5;
                                        *(uint8_t **)(puVar1 + 0x30) = puVar5 + 1;
                                    } else if (*puVar14 == 0) {
                                        uVar3 = 0;
                                    } else {
                                        func_0x000180069750(puVar1);
                                        uVar3 = **(uint8_t **)(puVar1 + 0x30);
                                        *(uint8_t **)(puVar1 + 0x30) = *(uint8_t **)(puVar1 + 0x30) + 1;
                                    }
                                    *(uint32_t *)(iVar12 + 0x46ac) = (uint32_t)uVar3;
                                    if (3 < uVar3) {
                                        return false;
                                    }
                                    uVar7 = puVar1[2];
                                    uVar10 = (uint64_t)(iVar4 + 1U);
                                } while ((int32_t)(iVar4 + 1U) < (int32_t)uVar7);
                            }
                            if ((int32_t)arg2 != 0) {
                                return true;
                            }
                            uVar8 = *puVar1;
                            if (-1 < (int32_t)uVar8) {
                                uVar20 = puVar1[1];
                                if (((-1 < (int32_t)uVar20) &&
                                    ((((uVar20 == 0 ||
                                       ((int32_t)uVar8 <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar20))) &&
                                      (-1 < (int32_t)(uVar8 * uVar20))) && (-1 < (int32_t)uVar7)))) &&
                                   ((uVar7 == 0 ||
                                    ((int32_t)(uVar8 * uVar20) <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar7))))) {
                                    uVar7 = puVar1[2];
                                    uVar20 = 1;
                                    uVar8 = 1;
                                    uVar10 = uVar13;
                                    if (0 < (int32_t)uVar7) {
                                        do {
                                            uVar9 = *(uint32_t *)(uVar10 * 0x60 + 0x46a4 + arg1);
                                            if ((int32_t)uVar9 <= (int32_t)uVar20) {
                                                uVar9 = uVar20;
                                            }
                                            uVar20 = uVar9;
                                            uVar9 = *(uint32_t *)(uVar10 * 0x60 + 0x46a8 + arg1);
                                            if ((int32_t)uVar9 <= (int32_t)uVar8) {
                                                uVar9 = uVar8;
                                            }
                                            uVar8 = uVar9;
                                            uVar9 = (int32_t)uVar10 + 1;
                                            uVar10 = (uint64_t)uVar9;
                                            uVar16 = uVar13;
                                        } while ((int32_t)uVar9 < (int32_t)uVar7);
                                        do {
                                            iVar12 = (int64_t)(int32_t)uVar16 * 0x60;
                                            if ((int32_t)uVar20 % *(int32_t *)(iVar12 + 0x46a4 + arg1) != 0) {
                                                return false;
                                            }
                                            if ((int32_t)uVar8 % *(int32_t *)(iVar12 + 0x46a8 + arg1) != 0) {
                                                return false;
                                            }
                                            uVar9 = (int32_t)uVar16 + 1;
                                            uVar16 = (uint64_t)uVar9;
                                        } while ((int32_t)uVar9 < (int32_t)uVar7);
                                    }
                                    *(uint32_t *)(arg1 + 0x4688) = uVar20;
                                    uVar7 = uVar20 * 8;
                                    *(uint32_t *)(arg1 + 0x468c) = uVar8;
                                    uVar9 = uVar8 * 8;
                                    *(uint32_t *)(arg1 + 0x4698) = uVar7;
                                    *(uint32_t *)(arg1 + 0x469c) = uVar9;
                                    *(uint32_t *)(arg1 + 0x4690) = ((*puVar1 - 1) + uVar7) / uVar7;
                                    *(uint32_t *)(arg1 + 0x4694) = ((puVar1[1] - 1) + uVar9) / uVar9;
                                    if ((int32_t)puVar1[2] < 1) {
                                        return true;
                                    }
                                    while( true ) {
                                        iVar11 = (int32_t)uVar13;
                                        iVar12 = (int64_t)iVar11 * 0x60 + arg1;
                                        iVar19 = ((int64_t)iVar11 + 0xbd) * 0x60;
                                        *(uint32_t *)(iVar12 + 0x46bc) =
                                             (*(int32_t *)(iVar12 + 0x46a4) * *puVar1 + -1 + uVar20) / uVar20;
                                        *(uint32_t *)(iVar12 + 0x46c0) =
                                             (*(int32_t *)(iVar12 + 0x46a8) * puVar1[1] + -1 + uVar8) / uVar8;
                                        iVar17 = *(int32_t *)(iVar12 + 0x46a4) * *(int32_t *)(arg1 + 0x4690);
                                        iVar18 = iVar17 * 8;
                                        *(int32_t *)(iVar12 + 0x46c4) = iVar18;
                                        iVar4 = *(int32_t *)(iVar12 + 0x46a8) * *(int32_t *)(arg1 + 0x4694);
                                        *(undefined8 *)(iVar12 + 0x46f0) = 0;
                                        *(undefined8 *)(iVar19 + arg1) = 0;
                                        *(undefined8 *)(iVar12 + 0x46e8) = 0;
                                        iVar15 = iVar4 * 8;
                                        *(int32_t *)(iVar12 + 0x46c8) = iVar15;
                                        if (((iVar17 * 8 < 0) || (iVar4 = iVar4 * 8, iVar4 < 0)) ||
                                           ((iVar4 != 0 && ((int32_t)(0x7fffffff / (int64_t)iVar15) < iVar18)))) break;
                                        iVar6 = func_0x00018046d050((int64_t)(iVar15 * iVar18 + 0xf));
                                        *(int64_t *)(iVar12 + 0x46d8) = iVar6;
                                        if (iVar6 == 0) goto code_r0x00018006db52;
                                        *(uint64_t *)(iVar12 + 0x46d0) = iVar6 + 0xfU & 0xfffffffffffffff0;
                                        if (*(int32_t *)(arg1 + 0x4830) != 0) {
                                            iVar4 = *(int32_t *)(iVar12 + 0x46c4);
                                            iVar15 = *(int32_t *)(iVar12 + 0x46c8);
                                            *(int32_t *)(iVar12 + 0x46f8) = (int32_t)(iVar4 + (iVar4 >> 0x1f & 7U)) >> 3
                                            ;
                                            *(int32_t *)(iVar12 + 0x46fc) =
                                                 (int32_t)(iVar15 + (iVar15 >> 0x1f & 7U)) >> 3;
                                            if ((((iVar4 < 0) || (iVar15 < 0)) ||
                                                ((iVar15 != 0 && ((int32_t)(0x7fffffff / (int64_t)iVar15) < iVar4)))) ||
                                               ((0x3fffffff < (uint32_t)(iVar15 * iVar4) ||
                                                (iVar4 = iVar15 * iVar4 * 2, 0x7ffffff0 < iVar4)))) {
                                                *(undefined8 *)(iVar19 + arg1) = 0;
                                                goto code_r0x00018006db52;
                                            }
                                            iVar6 = func_0x00018046d050((int64_t)(iVar4 + 0xf));
                                            *(int64_t *)(iVar19 + arg1) = iVar6;
                                            if (iVar6 == 0) goto code_r0x00018006db52;
                                            *(uint64_t *)(iVar12 + 0x46f0) = iVar6 + 0xfU & 0xfffffffffffffff0;
                                        }
                                        uVar13 = (uint64_t)(iVar11 + 1U);
                                        if ((int32_t)puVar1[2] <= (int32_t)(iVar11 + 1U)) {
                                            return true;
                                        }
                                    }
                                    *(undefined8 *)(iVar12 + 0x46d8) = 0;
code_r0x00018006db52:
                                    iVar4 = fcn.18006d3b0(arg1, (uint64_t)(iVar11 + 1), unaff_R12);
                                    return iVar4 != 0;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return false;
code_r0x00018006d60c:
    uVar3 = 0;
code_r0x00018006d611:
    uVar7 = (uint32_t)uVar3;
    if (uVar7 == 0xc0) goto code_r0x00018006d61d;
    goto code_r0x00018006d4e0;
}

// ============================================================
// Function: FUN_18006db80
// Address: 0x18006db80
// Size: 497 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_46a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46a4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_46ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1a48h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_408h because it doesn't fit into ProtoModel

undefined8 fcn.18006db80(int64_t arg1)
{
    char cVar1;
    undefined uVar2;
    int64_t iVar3;
    undefined *puVar4;
    uint8_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    uint32_t uVar8;
    char *pcVar9;
    int64_t var_8h;
    int64_t in_stack_00000018;
    
    *(undefined8 *)(arg1 + 0x46d8) = 0;
    *(undefined8 *)(arg1 + 0x46e0) = 0;
    *(undefined8 *)(arg1 + 0x4738) = 0;
    *(undefined8 *)(arg1 + 0x4740) = 0;
    *(undefined8 *)(arg1 + 0x4798) = 0;
    *(undefined8 *)(arg1 + 0x47a0) = 0;
    *(undefined8 *)(arg1 + 0x47f8) = 0;
    *(undefined8 *)(arg1 + 0x4800) = 0;
    *(undefined4 *)(arg1 + 0x4868) = 0;
    iVar6 = fcn.18006d480(arg1, 0);
    if (iVar6 == 0) {
        return 0;
    }
    uVar5 = func_0x00018006be40(arg1);
    uVar8 = (uint32_t)uVar5;
    if (uVar5 != 0xd9) {
        do {
            if (uVar8 == 0xda) {
                iVar6 = fcn.18006d140(arg1);
                if (iVar6 == 0) {
                    return 0;
                }
                iVar6 = func_0x00018006bee0(arg1);
                if (iVar6 == 0) {
                    return 0;
                }
                if (*(char *)(arg1 + 0x4828) == -1) {
code_r0x00018006dc30:
                    do {
                        iVar3 = *(int64_t *)arg1;
                        if (*(int64_t *)(iVar3 + 0x10) == 0) {
code_r0x00018006dc4f:
                            if (*(uint64_t *)(iVar3 + 200) <= *(uint64_t *)(iVar3 + 0xc0)) goto code_r0x00018006dd3a;
                        } else {
                            iVar6 = (**(code **)(iVar3 + 0x20))(*(undefined8 *)(iVar3 + 0x28));
                            if (iVar6 != 0) {
                                if (*(int32_t *)(iVar3 + 0x30) != 0) goto code_r0x00018006dc4f;
                                goto code_r0x00018006dd3a;
                            }
                        }
                        iVar3 = *(int64_t *)arg1;
                        pcVar9 = *(char **)(iVar3 + 0xc0);
                        if (*(char **)(iVar3 + 200) <= pcVar9) {
                            if (*(int32_t *)(iVar3 + 0x30) == 0) goto code_r0x00018006dc30;
                            func_0x000180069750(iVar3);
                            pcVar9 = *(char **)(iVar3 + 0xc0);
                        }
                        cVar1 = *pcVar9;
                        *(char **)(iVar3 + 0xc0) = pcVar9 + 1;
                    } while (cVar1 != -1);
                    iVar3 = *(int64_t *)arg1;
                    puVar4 = *(undefined **)(iVar3 + 0xc0);
                    if (puVar4 < *(undefined **)(iVar3 + 200)) {
                        uVar2 = *puVar4;
                        *(undefined **)(iVar3 + 0xc0) = puVar4 + 1;
                        *(undefined *)(arg1 + 0x4828) = uVar2;
                    } else if (*(int32_t *)(iVar3 + 0x30) == 0) {
                        *(undefined *)(arg1 + 0x4828) = 0;
                    } else {
                        func_0x000180069750(iVar3);
                        uVar2 = **(undefined **)(iVar3 + 0xc0);
                        *(undefined **)(iVar3 + 0xc0) = *(undefined **)(iVar3 + 0xc0) + 1;
                        *(undefined *)(arg1 + 0x4828) = uVar2;
                    }
                }
            } else if (uVar8 == 0xdc) {
                iVar6 = func_0x000180069950(*(undefined8 *)arg1);
                iVar7 = func_0x000180069950(*(undefined8 *)arg1);
                if (iVar6 != 4) {
                    return 0;
                }
                if (iVar7 != *(int32_t *)(*(int64_t *)arg1 + 4)) {
                    return 0;
                }
            } else {
                iVar6 = fcn.18006c900(arg1, (uint64_t)uVar8);
                if (iVar6 == 0) {
                    return 0;
                }
            }
code_r0x00018006dd3a:
            uVar5 = func_0x00018006be40(arg1);
            uVar8 = (uint32_t)uVar5;
        } while (uVar8 != 0xd9);
    }
    if (*(int32_t *)(arg1 + 0x4830) != 0) {
        fcn.18006c710(arg1, in_stack_00000018);
    }
    return 1;
}

// ============================================================
// Function: FUN_18006dd90
// Address: 0x18006dd90
// Size: 404 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18006dd90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char cVar1;
    uint16_t uVar9;
    uint16_t uVar10;
    uint16_t uVar11;
    uint16_t uVar12;
    undefined auVar13 [16];
    int32_t iVar14;
    int32_t iVar15;
    int32_t iVar16;
    int64_t iVar17;
    uint32_t uVar18;
    undefined in_XMM1 [16];
    undefined auVar19 [16];
    uint32_t uVar20;
    uint32_t uVar24;
    uint32_t uVar25;
    undefined in_XMM2 [16];
    undefined auVar21 [16];
    uint32_t uVar26;
    undefined auVar22 [16];
    undefined auVar23 [16];
    int64_t var_8h;
    int64_t var_10h;
    char cVar2;
    char cVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    char cVar7;
    char cVar8;
    
    auVar13 = *(undefined (*) [16])0x180646a10;
    uVar18 = (uint32_t)arg4;
    if (0 < (int32_t)uVar18) {
        iVar15 = 0;
        iVar14 = 0;
        iVar16 = iVar15;
        if ((0xf < uVar18) && (iVar16 = iVar14, 1 < *(int32_t *)0x1806a3990)) {
            iVar17 = (int64_t)(int32_t)uVar18 + -1;
            if ((((uint64_t)(iVar17 + arg3) < (uint64_t)arg1) || ((uint64_t)(iVar17 + arg1) < (uint64_t)arg3)) &&
               (((uint64_t)(iVar17 + arg2) < (uint64_t)arg1 || ((uint64_t)(iVar17 + arg1) < (uint64_t)arg2)))) {
                do {
                    iVar17 = (int64_t)iVar15;
                    iVar15 = iVar15 + 0x10;
                    auVar19 = pmovzxbd(in_XMM1, *(undefined4 *)(iVar17 + arg3));
                    auVar21 = pmovzxbd(in_XMM2, *(undefined4 *)(iVar17 + arg2));
                    auVar21 = pmulld(auVar21, auVar13);
                    uVar20 = auVar21._0_4_ + auVar19._0_4_ + 2U >> 2;
                    uVar24 = auVar21._4_4_ + auVar19._4_4_ + 2U >> 2;
                    uVar25 = auVar21._8_4_ + auVar19._8_4_ + 2U >> 2;
                    uVar26 = auVar21._12_4_ + auVar19._12_4_ + 2U >> 2;
                    uVar9 = (uint16_t)uVar20 & 0xff;
                    uVar10 = (uint16_t)uVar24 & 0xff;
                    uVar11 = (uint16_t)uVar25 & 0xff;
                    uVar12 = (uint16_t)uVar26 & 0xff;
                    cVar1 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar2 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar3 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar4 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    cVar5 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar6 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar7 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar8 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    auVar21._0_4_ =
                         CONCAT13((cVar4 != '\0') * (cVar4 != -1) * cVar4, 
                                  CONCAT12((cVar3 != '\0') * (cVar3 != -1) * cVar3, 
                                           CONCAT11((cVar2 != '\0') * (cVar2 != -1) * cVar2, 
                                                    (cVar1 != '\0') * (cVar1 != -1) * cVar1)));
                    auVar21[4] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    auVar21[5] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    auVar21[6] = (cVar7 != '\0') * (cVar7 != -1) * cVar7;
                    auVar21[7] = (cVar8 != '\0') * (cVar8 != -1) * cVar8;
                    auVar21[8] = (cVar1 != '\0') * (cVar1 != -1) * cVar1;
                    auVar21[9] = (cVar2 != '\0') * (cVar2 != -1) * cVar2;
                    auVar21[10] = (cVar3 != '\0') * (cVar3 != -1) * cVar3;
                    auVar21[11] = (cVar4 != '\0') * (cVar4 != -1) * cVar4;
                    auVar21[12] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    auVar21[13] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    auVar21[14] = (cVar7 != '\0') * (cVar7 != -1) * cVar7;
                    auVar21[15] = (cVar8 != '\0') * (cVar8 != -1) * cVar8;
                    *(undefined4 *)(iVar17 + arg1) = auVar21._0_4_;
                    auVar19 = pmovzxbd(auVar19, *(undefined4 *)(iVar17 + 4 + arg3));
                    auVar21 = pmovzxbd(auVar21, *(undefined4 *)(iVar17 + 4 + arg2));
                    auVar21 = pmulld(auVar21, auVar13);
                    uVar20 = auVar21._0_4_ + auVar19._0_4_ + 2U >> 2;
                    uVar24 = auVar21._4_4_ + auVar19._4_4_ + 2U >> 2;
                    uVar25 = auVar21._8_4_ + auVar19._8_4_ + 2U >> 2;
                    uVar26 = auVar21._12_4_ + auVar19._12_4_ + 2U >> 2;
                    uVar9 = (uint16_t)uVar20 & 0xff;
                    uVar10 = (uint16_t)uVar24 & 0xff;
                    uVar11 = (uint16_t)uVar25 & 0xff;
                    uVar12 = (uint16_t)uVar26 & 0xff;
                    cVar1 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar8 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar2 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar7 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    cVar6 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar5 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar4 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar3 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    auVar22._0_4_ =
                         CONCAT13((cVar7 != '\0') * (cVar7 != -1) * cVar7, 
                                  CONCAT12((cVar2 != '\0') * (cVar2 != -1) * cVar2, 
                                           CONCAT11((cVar8 != '\0') * (cVar8 != -1) * cVar8, 
                                                    (cVar1 != '\0') * (cVar1 != -1) * cVar1)));
                    auVar22[4] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    auVar22[5] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    auVar22[6] = (cVar4 != '\0') * (cVar4 != -1) * cVar4;
                    auVar22[7] = (cVar3 != '\0') * (cVar3 != -1) * cVar3;
                    auVar22[8] = (cVar1 != '\0') * (cVar1 != -1) * cVar1;
                    auVar22[9] = (cVar8 != '\0') * (cVar8 != -1) * cVar8;
                    auVar22[10] = (cVar2 != '\0') * (cVar2 != -1) * cVar2;
                    auVar22[11] = (cVar7 != '\0') * (cVar7 != -1) * cVar7;
                    auVar22[12] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    auVar22[13] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    auVar22[14] = (cVar4 != '\0') * (cVar4 != -1) * cVar4;
                    auVar22[15] = (cVar3 != '\0') * (cVar3 != -1) * cVar3;
                    *(undefined4 *)(iVar17 + 4 + arg1) = auVar22._0_4_;
                    auVar19 = pmovzxbd(auVar19, *(undefined4 *)(iVar17 + 8 + arg3));
                    auVar21 = pmovzxbd(auVar22, *(undefined4 *)(iVar17 + 8 + arg2));
                    auVar21 = pmulld(auVar21, auVar13);
                    uVar20 = auVar21._0_4_ + auVar19._0_4_ + 2U >> 2;
                    uVar24 = auVar21._4_4_ + auVar19._4_4_ + 2U >> 2;
                    uVar25 = auVar21._8_4_ + auVar19._8_4_ + 2U >> 2;
                    uVar26 = auVar21._12_4_ + auVar19._12_4_ + 2U >> 2;
                    uVar9 = (uint16_t)uVar20 & 0xff;
                    uVar10 = (uint16_t)uVar24 & 0xff;
                    uVar11 = (uint16_t)uVar25 & 0xff;
                    uVar12 = (uint16_t)uVar26 & 0xff;
                    cVar2 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar1 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar8 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar7 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    cVar6 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar5 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar4 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar3 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    auVar23._0_4_ =
                         CONCAT13((cVar7 != '\0') * (cVar7 != -1) * cVar7, 
                                  CONCAT12((cVar8 != '\0') * (cVar8 != -1) * cVar8, 
                                           CONCAT11((cVar1 != '\0') * (cVar1 != -1) * cVar1, 
                                                    (cVar2 != '\0') * (cVar2 != -1) * cVar2)));
                    auVar23[4] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    auVar23[5] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    auVar23[6] = (cVar4 != '\0') * (cVar4 != -1) * cVar4;
                    auVar23[7] = (cVar3 != '\0') * (cVar3 != -1) * cVar3;
                    auVar23[8] = (cVar2 != '\0') * (cVar2 != -1) * cVar2;
                    auVar23[9] = (cVar1 != '\0') * (cVar1 != -1) * cVar1;
                    auVar23[10] = (cVar8 != '\0') * (cVar8 != -1) * cVar8;
                    auVar23[11] = (cVar7 != '\0') * (cVar7 != -1) * cVar7;
                    auVar23[12] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    auVar23[13] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    auVar23[14] = (cVar4 != '\0') * (cVar4 != -1) * cVar4;
                    auVar23[15] = (cVar3 != '\0') * (cVar3 != -1) * cVar3;
                    *(undefined4 *)(iVar17 + 8 + arg1) = auVar23._0_4_;
                    auVar21 = pmovzxbd(auVar23, *(undefined4 *)(iVar17 + 0xc + arg2));
                    in_XMM1 = pmovzxbd(auVar19, *(undefined4 *)(iVar17 + 0xc + arg3));
                    auVar19 = pmulld(auVar21, auVar13);
                    uVar20 = auVar19._0_4_ + in_XMM1._0_4_ + 2U >> 2;
                    uVar24 = auVar19._4_4_ + in_XMM1._4_4_ + 2U >> 2;
                    uVar25 = auVar19._8_4_ + in_XMM1._8_4_ + 2U >> 2;
                    uVar26 = auVar19._12_4_ + in_XMM1._12_4_ + 2U >> 2;
                    uVar9 = (uint16_t)uVar20 & 0xff;
                    uVar10 = (uint16_t)uVar24 & 0xff;
                    uVar11 = (uint16_t)uVar25 & 0xff;
                    uVar12 = (uint16_t)uVar26 & 0xff;
                    cVar2 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar3 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar4 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar5 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    cVar6 = ((uVar20 & 0xff) != 0) * (uVar9 < 0xff) * (char)uVar20 - (0xff < uVar9);
                    cVar7 = ((uVar24 & 0xff) != 0) * (uVar10 < 0xff) * (char)uVar24 - (0xff < uVar10);
                    cVar8 = ((uVar25 & 0xff) != 0) * (uVar11 < 0xff) * (char)uVar25 - (0xff < uVar11);
                    cVar1 = ((uVar26 & 0xff) != 0) * (uVar12 < 0xff) * (char)uVar26 - (0xff < uVar12);
                    in_XMM2._0_4_ =
                         CONCAT13((cVar5 != '\0') * (cVar5 != -1) * cVar5, 
                                  CONCAT12((cVar4 != '\0') * (cVar4 != -1) * cVar4, 
                                           CONCAT11((cVar3 != '\0') * (cVar3 != -1) * cVar3, 
                                                    (cVar2 != '\0') * (cVar2 != -1) * cVar2)));
                    in_XMM2[4] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    in_XMM2[5] = (cVar7 != '\0') * (cVar7 != -1) * cVar7;
                    in_XMM2[6] = (cVar8 != '\0') * (cVar8 != -1) * cVar8;
                    in_XMM2[7] = (cVar1 != '\0') * (cVar1 != -1) * cVar1;
                    in_XMM2[8] = (cVar2 != '\0') * (cVar2 != -1) * cVar2;
                    in_XMM2[9] = (cVar3 != '\0') * (cVar3 != -1) * cVar3;
                    in_XMM2[10] = (cVar4 != '\0') * (cVar4 != -1) * cVar4;
                    in_XMM2[11] = (cVar5 != '\0') * (cVar5 != -1) * cVar5;
                    in_XMM2[12] = (cVar6 != '\0') * (cVar6 != -1) * cVar6;
                    in_XMM2[13] = (cVar7 != '\0') * (cVar7 != -1) * cVar7;
                    in_XMM2[14] = (cVar8 != '\0') * (cVar8 != -1) * cVar8;
                    in_XMM2[15] = (cVar1 != '\0') * (cVar1 != -1) * cVar1;
                    *(undefined4 *)(iVar17 + 0xc + arg1) = in_XMM2._0_4_;
                } while (iVar15 < (int32_t)(uVar18 & 0xfffffff0));
                iVar16 = iVar15;
                if ((int32_t)uVar18 <= iVar15) {
                    return arg1;
                }
            }
        }
        do {
            iVar17 = (int64_t)iVar16;
            iVar16 = iVar16 + 1;
            *(char *)(iVar17 + arg1) =
                 (char)(*(uint8_t *)(iVar17 + arg3) + 2 +
                        (uint32_t)*(uint8_t *)(iVar17 + arg2) + (uint32_t)*(uint8_t *)(iVar17 + arg2) * 2 >> 2);
        } while (iVar16 < (int32_t)uVar18);
    }
    // WARNING: Read-only address (ram,0x000180646a10) is written
    return arg1;
}

// ============================================================
// Function: FUN_18006df30
// Address: 0x18006df30
// Size: 195 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18006df30(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4)
{
    int32_t iVar1;
    uint8_t *puVar2;
    undefined uVar3;
    uint8_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t var_8h;
    
    uVar3 = *(undefined *)arg2;
    iVar8 = (int32_t)arg4;
    iVar6 = (int64_t)iVar8;
    *(undefined *)arg1 = uVar3;
    if (iVar8 == 1) {
        *(undefined *)(arg1 + 1) = uVar3;
        return arg1;
    }
    iVar7 = 1;
    *(char *)(arg1 + 1) =
         (char)(*(uint8_t *)(arg2 + 1) + 2 + (uint32_t)*(uint8_t *)arg2 + (uint32_t)*(uint8_t *)arg2 * 2 >> 2);
    if (1 < iVar8 + -1) {
        iVar9 = 1;
        do {
            puVar2 = (uint8_t *)(arg2 + iVar9);
            iVar9 = iVar9 + 1;
            iVar1 = (uint32_t)*puVar2 * 3 + 2;
            iVar5 = iVar7 * 2;
            iVar7 = iVar7 + 1;
            *(char *)(iVar5 + arg1) = (char)((uint32_t)*(uint8_t *)(arg2 + -2 + iVar9) + iVar1 >> 2);
            *(char *)((int64_t)iVar5 + 1 + arg1) = (char)((uint32_t)*(uint8_t *)(arg2 + iVar9) + iVar1 >> 2);
        } while (iVar7 < iVar8 + -1);
    }
    uVar4 = *(uint8_t *)(iVar6 + -2 + arg2);
    *(char *)(iVar7 * 2 + arg1) =
         (char)(*(uint8_t *)(iVar6 + -1 + arg2) + 2 + (uint32_t)uVar4 + (uint32_t)uVar4 * 2 >> 2);
    *(undefined *)((int64_t)(iVar7 * 2) + 1 + arg1) = *(undefined *)(iVar6 + -1 + arg2);
    return arg1;
}

// ============================================================
// Function: FUN_18006e000
// Address: 0x18006e000
// Size: 172 bytes
// ============================================================
int64_t fcn.18006e000(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    
    iVar5 = (int32_t)arg4;
    iVar2 = (uint32_t)*(uint8_t *)arg3 + (uint32_t)*(uint8_t *)arg2 + (uint32_t)*(uint8_t *)arg2 * 2;
    if (iVar5 != 1) {
        uVar7 = 1;
        *(char *)arg1 = (char)(iVar2 + 2U >> 2);
        iVar3 = iVar2;
        if (1 < iVar5) {
            do {
                iVar2 = (uint32_t)*(uint8_t *)(arg2 + uVar7) + (uint32_t)*(uint8_t *)(arg2 + uVar7) * 2 +
                        (uint32_t)*(uint8_t *)(arg3 + uVar7);
                iVar4 = (int64_t)((int32_t)uVar7 * 2);
                uVar6 = (int32_t)uVar7 + 1;
                uVar7 = (uint64_t)uVar6;
                *(char *)(iVar4 + -1 + arg1) = (char)((uint32_t)(iVar3 * 3 + 8 + iVar2) >> 4);
                *(char *)(iVar4 + arg1) = (char)((uint32_t)(iVar3 + 8 + iVar2 * 3) >> 4);
                iVar3 = iVar2;
            } while ((int32_t)uVar6 < iVar5);
        }
        *(char *)((int64_t)(iVar5 * 2) + -1 + arg1) = (char)(iVar2 + 2U >> 2);
        return arg1;
    }
    uVar1 = (undefined)(iVar2 + 2U >> 2);
    *(undefined *)(arg1 + 1) = uVar1;
    *(undefined *)arg1 = uVar1;
    return arg1;
}

// ============================================================
// Function: FUN_18006e0b0
// Address: 0x18006e0b0
// Size: 69 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018006e150)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18006e0b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint8_t uVar4;
    undefined auVar5 [15];
    undefined auVar6 [15];
    undefined auVar7 [15];
    undefined auVar8 [15];
    undefined auVar9 [15];
    undefined auVar10 [15];
    undefined auVar11 [15];
    undefined auVar12 [15];
    undefined auVar13 [15];
    undefined auVar14 [15];
    undefined auVar15 [15];
    undefined auVar16 [15];
    undefined auVar17 [15];
    unkuint9 Var18;
    undefined auVar19 [11];
    undefined auVar20 [13];
    undefined auVar21 [15];
    unkuint9 Var22;
    undefined auVar23 [11];
    undefined auVar24 [13];
    undefined auVar25 [15];
    undefined auVar26 [15];
    undefined auVar27 [15];
    undefined auVar28 [15];
    undefined uVar29;
    int32_t iVar30;
    int64_t iVar31;
    int32_t iVar32;
    uint32_t uVar33;
    int32_t iVar34;
    int32_t iVar35;
    int16_t iVar36;
    uint16_t uVar37;
    int16_t iVar39;
    uint16_t uVar40;
    int16_t iVar41;
    uint16_t uVar42;
    int16_t iVar43;
    uint16_t uVar44;
    int16_t iVar45;
    uint16_t uVar46;
    int16_t iVar47;
    uint16_t uVar48;
    int16_t iVar49;
    uint16_t uVar50;
    undefined auVar38 [16];
    int16_t iVar51;
    uint16_t uVar52;
    undefined auVar53 [16];
    uint16_t uVar54;
    uint16_t uVar55;
    uint16_t uVar56;
    uint16_t uVar57;
    uint16_t uVar58;
    uint16_t uVar59;
    uint16_t uVar60;
    uint16_t uVar61;
    undefined auVar62 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar34 = (uint32_t)*(uint8_t *)arg2 + (uint32_t)*(uint8_t *)arg2 * 2 + (uint32_t)*(uint8_t *)arg3;
    iVar32 = (int32_t)arg4;
    if (iVar32 != 1) {
        iVar35 = 0;
        uVar33 = iVar32 - 1U & 0xfffffff8;
        if (0 < (int32_t)uVar33) {
            do {
                iVar31 = (int64_t)iVar35;
                uVar2 = *(uint64_t *)(iVar31 + arg2);
                uVar3 = *(uint64_t *)(iVar31 + arg3);
                uVar4 = *(uint8_t *)(iVar31 + arg2 + 8);
                auVar5._8_6_ = 0;
                auVar5._0_8_ = uVar2;
                auVar5[14] = (char)(uVar2 >> 0x38);
                auVar7._8_4_ = 0;
                auVar7._0_8_ = uVar2;
                auVar7[12] = (char)(uVar2 >> 0x30);
                auVar7._13_2_ = auVar5._13_2_;
                auVar9._8_4_ = 0;
                auVar9._0_8_ = uVar2;
                auVar9._12_3_ = auVar7._12_3_;
                auVar11._8_2_ = 0;
                auVar11._0_8_ = uVar2;
                auVar11[10] = (char)(uVar2 >> 0x28);
                auVar11._11_4_ = auVar9._11_4_;
                auVar13._8_2_ = 0;
                auVar13._0_8_ = uVar2;
                auVar13._10_5_ = auVar11._10_5_;
                auVar15[8] = (char)(uVar2 >> 0x20);
                auVar15._0_8_ = uVar2;
                auVar15._9_6_ = auVar13._9_6_;
                auVar17._7_8_ = 0;
                auVar17._0_7_ = auVar15._8_7_;
                Var18 = CONCAT81(SUB158(auVar17 << 0x40, 7), (char)(uVar2 >> 0x18));
                auVar25._9_6_ = 0;
                auVar25._0_9_ = Var18;
                auVar19._1_10_ = SUB1510(auVar25 << 0x30, 5);
                auVar19[0] = (char)(uVar2 >> 0x10);
                auVar26._11_4_ = 0;
                auVar26._0_11_ = auVar19;
                auVar20._1_12_ = SUB1512(auVar26 << 0x20, 3);
                auVar20[0] = (char)(uVar2 >> 8);
                auVar38._0_2_ = CONCAT11(0, (uint8_t)uVar2);
                auVar38._2_13_ = auVar20;
                auVar38[15] = 0;
                auVar6._8_6_ = 0;
                auVar6._0_8_ = uVar3;
                auVar6[14] = (char)(uVar3 >> 0x38);
                auVar8._8_4_ = 0;
                auVar8._0_8_ = uVar3;
                auVar8[12] = (char)(uVar3 >> 0x30);
                auVar8._13_2_ = auVar6._13_2_;
                auVar10._8_4_ = 0;
                auVar10._0_8_ = uVar3;
                auVar10._12_3_ = auVar8._12_3_;
                auVar12._8_2_ = 0;
                auVar12._0_8_ = uVar3;
                auVar12[10] = (char)(uVar3 >> 0x28);
                auVar12._11_4_ = auVar10._11_4_;
                auVar14._8_2_ = 0;
                auVar14._0_8_ = uVar3;
                auVar14._10_5_ = auVar12._10_5_;
                auVar16[8] = (char)(uVar3 >> 0x20);
                auVar16._0_8_ = uVar3;
                auVar16._9_6_ = auVar14._9_6_;
                auVar21._7_8_ = 0;
                auVar21._0_7_ = auVar16._8_7_;
                Var22 = CONCAT81(SUB158(auVar21 << 0x40, 7), (char)(uVar3 >> 0x18));
                auVar27._9_6_ = 0;
                auVar27._0_9_ = Var22;
                auVar23._1_10_ = SUB1510(auVar27 << 0x30, 5);
                auVar23[0] = (char)(uVar3 >> 0x10);
                auVar28._11_4_ = 0;
                auVar28._0_11_ = auVar23;
                auVar24._1_12_ = SUB1512(auVar28 << 0x20, 3);
                auVar24[0] = (char)(uVar3 >> 8);
                auVar53 = psllw(auVar38, 2);
                auVar62._0_2_ = ((uint8_t)uVar3 - auVar38._0_2_) + auVar53._0_2_;
                auVar62._2_2_ = (auVar24._0_2_ - auVar20._0_2_) + auVar53._2_2_;
                auVar62._4_2_ = (auVar23._0_2_ - auVar19._0_2_) + auVar53._4_2_;
                auVar62._6_2_ = ((int16_t)Var22 - (int16_t)Var18) + auVar53._6_2_;
                auVar62._8_2_ = (auVar16._8_2_ - auVar15._8_2_) + auVar53._8_2_;
                auVar62._10_2_ = (auVar12._10_2_ - auVar11._10_2_) + auVar53._10_2_;
                auVar62._12_2_ = (auVar8._12_2_ - auVar7._12_2_) + auVar53._12_2_;
                auVar62._14_2_ = ((auVar6._13_2_ >> 8) - (auVar5._13_2_ >> 8)) + auVar53._14_2_;
                iVar30 = iVar35 * 2;
                auVar38 = psllw(auVar62, 2);
                iVar35 = iVar35 + 8;
                iVar36 = auVar38._0_2_ + 8;
                iVar39 = auVar38._2_2_ + 8;
                iVar41 = auVar38._4_2_ + 8;
                iVar43 = auVar38._6_2_ + 8;
                iVar45 = auVar38._8_2_ + 8;
                iVar47 = auVar38._10_2_ + 8;
                iVar49 = auVar38._12_2_ + 8;
                iVar51 = auVar38._14_2_ + 8;
                uVar37 = (uint16_t)(((int16_t)iVar34 - auVar62._0_2_) + iVar36) >> 4;
                uVar40 = (uint16_t)((auVar62._2_2_ - auVar62._0_2_) + iVar36) >> 4;
                uVar42 = (uint16_t)((auVar62._0_2_ - auVar62._2_2_) + iVar39) >> 4;
                uVar44 = (uint16_t)((auVar62._4_2_ - auVar62._2_2_) + iVar39) >> 4;
                uVar46 = (uint16_t)((auVar62._2_2_ - auVar62._4_2_) + iVar41) >> 4;
                uVar48 = (uint16_t)((auVar62._6_2_ - auVar62._4_2_) + iVar41) >> 4;
                uVar50 = (uint16_t)((auVar62._4_2_ - auVar62._6_2_) + iVar43) >> 4;
                uVar52 = (uint16_t)((auVar62._8_2_ - auVar62._6_2_) + iVar43) >> 4;
                uVar54 = (uint16_t)((auVar62._6_2_ - auVar62._8_2_) + iVar45) >> 4;
                uVar55 = (uint16_t)((auVar62._10_2_ - auVar62._8_2_) + iVar45) >> 4;
                uVar56 = (uint16_t)((auVar62._8_2_ - auVar62._10_2_) + iVar47) >> 4;
                uVar57 = (uint16_t)((auVar62._12_2_ - auVar62._10_2_) + iVar47) >> 4;
                uVar58 = (uint16_t)((auVar62._10_2_ - auVar62._12_2_) + iVar49) >> 4;
                uVar59 = (uint16_t)((auVar62._14_2_ - auVar62._12_2_) + iVar49) >> 4;
                uVar60 = (uint16_t)((auVar62._12_2_ - auVar62._14_2_) + iVar51) >> 4;
                uVar61 = (uint16_t)
                         ((((uint16_t)uVar4 + (uint16_t)uVar4 * 2 + (uint16_t)*(uint8_t *)(iVar31 + arg3 + 8)) -
                          auVar62._14_2_) + iVar51) >> 4;
                pcVar1 = (char *)(iVar30 + arg1);
                *pcVar1 = (uVar37 != 0) * (uVar37 < 0xff) * (char)uVar37 - (0xff < uVar37);
                pcVar1[1] = (uVar40 != 0) * (uVar40 < 0xff) * (char)uVar40 - (0xff < uVar40);
                pcVar1[2] = (uVar42 != 0) * (uVar42 < 0xff) * (char)uVar42 - (0xff < uVar42);
                pcVar1[3] = (uVar44 != 0) * (uVar44 < 0xff) * (char)uVar44 - (0xff < uVar44);
                pcVar1[4] = (uVar46 != 0) * (uVar46 < 0xff) * (char)uVar46 - (0xff < uVar46);
                pcVar1[5] = (uVar48 != 0) * (uVar48 < 0xff) * (char)uVar48 - (0xff < uVar48);
                pcVar1[6] = (uVar50 != 0) * (uVar50 < 0xff) * (char)uVar50 - (0xff < uVar50);
                pcVar1[7] = (uVar52 != 0) * (uVar52 < 0xff) * (char)uVar52 - (0xff < uVar52);
                pcVar1[8] = (uVar54 != 0) * (uVar54 < 0xff) * (char)uVar54 - (0xff < uVar54);
                pcVar1[9] = (uVar55 != 0) * (uVar55 < 0xff) * (char)uVar55 - (0xff < uVar55);
                pcVar1[10] = (uVar56 != 0) * (uVar56 < 0xff) * (char)uVar56 - (0xff < uVar56);
                pcVar1[0xb] = (uVar57 != 0) * (uVar57 < 0xff) * (char)uVar57 - (0xff < uVar57);
                pcVar1[0xc] = (uVar58 != 0) * (uVar58 < 0xff) * (char)uVar58 - (0xff < uVar58);
                pcVar1[0xd] = (uVar59 != 0) * (uVar59 < 0xff) * (char)uVar59 - (0xff < uVar59);
                pcVar1[0xe] = (uVar60 != 0) * (uVar60 < 0xff) * (char)uVar60 - (0xff < uVar60);
                pcVar1[0xf] = (uVar61 != 0) * (uVar61 < 0xff) * (char)uVar61 - (0xff < uVar61);
                uVar4 = *(uint8_t *)(iVar31 + arg2 + 7);
                iVar34 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar31 + arg3 + 7);
            } while (iVar35 < (int32_t)uVar33);
        }
        uVar4 = *(uint8_t *)(iVar35 + arg2);
        iVar30 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar35 + arg3);
        *(char *)(iVar35 * 2 + arg1) = (char)((uint32_t)(iVar30 * 3 + 8 + iVar34) >> 4);
        while (iVar35 = iVar35 + 1, iVar35 < iVar32) {
            uVar4 = *(uint8_t *)(iVar35 + arg2);
            iVar34 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar35 + arg3);
            *(char *)((int64_t)(iVar35 * 2) + -1 + arg1) = (char)((uint32_t)(iVar30 * 3 + 8 + iVar34) >> 4);
            *(char *)(iVar35 * 2 + arg1) = (char)((uint32_t)(iVar30 + 8 + iVar34 * 3) >> 4);
            iVar30 = iVar34;
        }
        *(char *)((int64_t)(iVar32 * 2) + -1 + arg1) = (char)(iVar30 + 2U >> 2);
        return arg1;
    }
    uVar29 = (undefined)(iVar34 + 2U >> 2);
    *(undefined *)(arg1 + 1) = uVar29;
    *(undefined *)arg1 = uVar29;
    return arg1;
}

// ============================================================
// Function: FUN_18006e0f5
// Address: 0x18006e0f5
// Size: 268 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018006e150)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18006e0b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint8_t uVar4;
    undefined auVar5 [15];
    undefined auVar6 [15];
    undefined auVar7 [15];
    undefined auVar8 [15];
    undefined auVar9 [15];
    undefined auVar10 [15];
    undefined auVar11 [15];
    undefined auVar12 [15];
    undefined auVar13 [15];
    undefined auVar14 [15];
    undefined auVar15 [15];
    undefined auVar16 [15];
    undefined auVar17 [15];
    unkuint9 Var18;
    undefined auVar19 [11];
    undefined auVar20 [13];
    undefined auVar21 [15];
    unkuint9 Var22;
    undefined auVar23 [11];
    undefined auVar24 [13];
    undefined auVar25 [15];
    undefined auVar26 [15];
    undefined auVar27 [15];
    undefined auVar28 [15];
    undefined uVar29;
    int32_t iVar30;
    int64_t iVar31;
    int32_t iVar32;
    uint32_t uVar33;
    int32_t iVar34;
    int32_t iVar35;
    int16_t iVar36;
    uint16_t uVar37;
    int16_t iVar39;
    uint16_t uVar40;
    int16_t iVar41;
    uint16_t uVar42;
    int16_t iVar43;
    uint16_t uVar44;
    int16_t iVar45;
    uint16_t uVar46;
    int16_t iVar47;
    uint16_t uVar48;
    int16_t iVar49;
    uint16_t uVar50;
    undefined auVar38 [16];
    int16_t iVar51;
    uint16_t uVar52;
    undefined auVar53 [16];
    uint16_t uVar54;
    uint16_t uVar55;
    uint16_t uVar56;
    uint16_t uVar57;
    uint16_t uVar58;
    uint16_t uVar59;
    uint16_t uVar60;
    uint16_t uVar61;
    undefined auVar62 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar34 = (uint32_t)*(uint8_t *)arg2 + (uint32_t)*(uint8_t *)arg2 * 2 + (uint32_t)*(uint8_t *)arg3;
    iVar32 = (int32_t)arg4;
    if (iVar32 != 1) {
        iVar35 = 0;
        uVar33 = iVar32 - 1U & 0xfffffff8;
        if (0 < (int32_t)uVar33) {
            do {
                iVar31 = (int64_t)iVar35;
                uVar2 = *(uint64_t *)(iVar31 + arg2);
                uVar3 = *(uint64_t *)(iVar31 + arg3);
                uVar4 = *(uint8_t *)(iVar31 + arg2 + 8);
                auVar5._8_6_ = 0;
                auVar5._0_8_ = uVar2;
                auVar5[14] = (char)(uVar2 >> 0x38);
                auVar7._8_4_ = 0;
                auVar7._0_8_ = uVar2;
                auVar7[12] = (char)(uVar2 >> 0x30);
                auVar7._13_2_ = auVar5._13_2_;
                auVar9._8_4_ = 0;
                auVar9._0_8_ = uVar2;
                auVar9._12_3_ = auVar7._12_3_;
                auVar11._8_2_ = 0;
                auVar11._0_8_ = uVar2;
                auVar11[10] = (char)(uVar2 >> 0x28);
                auVar11._11_4_ = auVar9._11_4_;
                auVar13._8_2_ = 0;
                auVar13._0_8_ = uVar2;
                auVar13._10_5_ = auVar11._10_5_;
                auVar15[8] = (char)(uVar2 >> 0x20);
                auVar15._0_8_ = uVar2;
                auVar15._9_6_ = auVar13._9_6_;
                auVar17._7_8_ = 0;
                auVar17._0_7_ = auVar15._8_7_;
                Var18 = CONCAT81(SUB158(auVar17 << 0x40, 7), (char)(uVar2 >> 0x18));
                auVar25._9_6_ = 0;
                auVar25._0_9_ = Var18;
                auVar19._1_10_ = SUB1510(auVar25 << 0x30, 5);
                auVar19[0] = (char)(uVar2 >> 0x10);
                auVar26._11_4_ = 0;
                auVar26._0_11_ = auVar19;
                auVar20._1_12_ = SUB1512(auVar26 << 0x20, 3);
                auVar20[0] = (char)(uVar2 >> 8);
                auVar38._0_2_ = CONCAT11(0, (uint8_t)uVar2);
                auVar38._2_13_ = auVar20;
                auVar38[15] = 0;
                auVar6._8_6_ = 0;
                auVar6._0_8_ = uVar3;
                auVar6[14] = (char)(uVar3 >> 0x38);
                auVar8._8_4_ = 0;
                auVar8._0_8_ = uVar3;
                auVar8[12] = (char)(uVar3 >> 0x30);
                auVar8._13_2_ = auVar6._13_2_;
                auVar10._8_4_ = 0;
                auVar10._0_8_ = uVar3;
                auVar10._12_3_ = auVar8._12_3_;
                auVar12._8_2_ = 0;
                auVar12._0_8_ = uVar3;
                auVar12[10] = (char)(uVar3 >> 0x28);
                auVar12._11_4_ = auVar10._11_4_;
                auVar14._8_2_ = 0;
                auVar14._0_8_ = uVar3;
                auVar14._10_5_ = auVar12._10_5_;
                auVar16[8] = (char)(uVar3 >> 0x20);
                auVar16._0_8_ = uVar3;
                auVar16._9_6_ = auVar14._9_6_;
                auVar21._7_8_ = 0;
                auVar21._0_7_ = auVar16._8_7_;
                Var22 = CONCAT81(SUB158(auVar21 << 0x40, 7), (char)(uVar3 >> 0x18));
                auVar27._9_6_ = 0;
                auVar27._0_9_ = Var22;
                auVar23._1_10_ = SUB1510(auVar27 << 0x30, 5);
                auVar23[0] = (char)(uVar3 >> 0x10);
                auVar28._11_4_ = 0;
                auVar28._0_11_ = auVar23;
                auVar24._1_12_ = SUB1512(auVar28 << 0x20, 3);
                auVar24[0] = (char)(uVar3 >> 8);
                auVar53 = psllw(auVar38, 2);
                auVar62._0_2_ = ((uint8_t)uVar3 - auVar38._0_2_) + auVar53._0_2_;
                auVar62._2_2_ = (auVar24._0_2_ - auVar20._0_2_) + auVar53._2_2_;
                auVar62._4_2_ = (auVar23._0_2_ - auVar19._0_2_) + auVar53._4_2_;
                auVar62._6_2_ = ((int16_t)Var22 - (int16_t)Var18) + auVar53._6_2_;
                auVar62._8_2_ = (auVar16._8_2_ - auVar15._8_2_) + auVar53._8_2_;
                auVar62._10_2_ = (auVar12._10_2_ - auVar11._10_2_) + auVar53._10_2_;
                auVar62._12_2_ = (auVar8._12_2_ - auVar7._12_2_) + auVar53._12_2_;
                auVar62._14_2_ = ((auVar6._13_2_ >> 8) - (auVar5._13_2_ >> 8)) + auVar53._14_2_;
                iVar30 = iVar35 * 2;
                auVar38 = psllw(auVar62, 2);
                iVar35 = iVar35 + 8;
                iVar36 = auVar38._0_2_ + 8;
                iVar39 = auVar38._2_2_ + 8;
                iVar41 = auVar38._4_2_ + 8;
                iVar43 = auVar38._6_2_ + 8;
                iVar45 = auVar38._8_2_ + 8;
                iVar47 = auVar38._10_2_ + 8;
                iVar49 = auVar38._12_2_ + 8;
                iVar51 = auVar38._14_2_ + 8;
                uVar37 = (uint16_t)(((int16_t)iVar34 - auVar62._0_2_) + iVar36) >> 4;
                uVar40 = (uint16_t)((auVar62._2_2_ - auVar62._0_2_) + iVar36) >> 4;
                uVar42 = (uint16_t)((auVar62._0_2_ - auVar62._2_2_) + iVar39) >> 4;
                uVar44 = (uint16_t)((auVar62._4_2_ - auVar62._2_2_) + iVar39) >> 4;
                uVar46 = (uint16_t)((auVar62._2_2_ - auVar62._4_2_) + iVar41) >> 4;
                uVar48 = (uint16_t)((auVar62._6_2_ - auVar62._4_2_) + iVar41) >> 4;
                uVar50 = (uint16_t)((auVar62._4_2_ - auVar62._6_2_) + iVar43) >> 4;
                uVar52 = (uint16_t)((auVar62._8_2_ - auVar62._6_2_) + iVar43) >> 4;
                uVar54 = (uint16_t)((auVar62._6_2_ - auVar62._8_2_) + iVar45) >> 4;
                uVar55 = (uint16_t)((auVar62._10_2_ - auVar62._8_2_) + iVar45) >> 4;
                uVar56 = (uint16_t)((auVar62._8_2_ - auVar62._10_2_) + iVar47) >> 4;
                uVar57 = (uint16_t)((auVar62._12_2_ - auVar62._10_2_) + iVar47) >> 4;
                uVar58 = (uint16_t)((auVar62._10_2_ - auVar62._12_2_) + iVar49) >> 4;
                uVar59 = (uint16_t)((auVar62._14_2_ - auVar62._12_2_) + iVar49) >> 4;
                uVar60 = (uint16_t)((auVar62._12_2_ - auVar62._14_2_) + iVar51) >> 4;
                uVar61 = (uint16_t)
                         ((((uint16_t)uVar4 + (uint16_t)uVar4 * 2 + (uint16_t)*(uint8_t *)(iVar31 + arg3 + 8)) -
                          auVar62._14_2_) + iVar51) >> 4;
                pcVar1 = (char *)(iVar30 + arg1);
                *pcVar1 = (uVar37 != 0) * (uVar37 < 0xff) * (char)uVar37 - (0xff < uVar37);
                pcVar1[1] = (uVar40 != 0) * (uVar40 < 0xff) * (char)uVar40 - (0xff < uVar40);
                pcVar1[2] = (uVar42 != 0) * (uVar42 < 0xff) * (char)uVar42 - (0xff < uVar42);
                pcVar1[3] = (uVar44 != 0) * (uVar44 < 0xff) * (char)uVar44 - (0xff < uVar44);
                pcVar1[4] = (uVar46 != 0) * (uVar46 < 0xff) * (char)uVar46 - (0xff < uVar46);
                pcVar1[5] = (uVar48 != 0) * (uVar48 < 0xff) * (char)uVar48 - (0xff < uVar48);
                pcVar1[6] = (uVar50 != 0) * (uVar50 < 0xff) * (char)uVar50 - (0xff < uVar50);
                pcVar1[7] = (uVar52 != 0) * (uVar52 < 0xff) * (char)uVar52 - (0xff < uVar52);
                pcVar1[8] = (uVar54 != 0) * (uVar54 < 0xff) * (char)uVar54 - (0xff < uVar54);
                pcVar1[9] = (uVar55 != 0) * (uVar55 < 0xff) * (char)uVar55 - (0xff < uVar55);
                pcVar1[10] = (uVar56 != 0) * (uVar56 < 0xff) * (char)uVar56 - (0xff < uVar56);
                pcVar1[0xb] = (uVar57 != 0) * (uVar57 < 0xff) * (char)uVar57 - (0xff < uVar57);
                pcVar1[0xc] = (uVar58 != 0) * (uVar58 < 0xff) * (char)uVar58 - (0xff < uVar58);
                pcVar1[0xd] = (uVar59 != 0) * (uVar59 < 0xff) * (char)uVar59 - (0xff < uVar59);
                pcVar1[0xe] = (uVar60 != 0) * (uVar60 < 0xff) * (char)uVar60 - (0xff < uVar60);
                pcVar1[0xf] = (uVar61 != 0) * (uVar61 < 0xff) * (char)uVar61 - (0xff < uVar61);
                uVar4 = *(uint8_t *)(iVar31 + arg2 + 7);
                iVar34 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar31 + arg3 + 7);
            } while (iVar35 < (int32_t)uVar33);
        }
        uVar4 = *(uint8_t *)(iVar35 + arg2);
        iVar30 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar35 + arg3);
        *(char *)(iVar35 * 2 + arg1) = (char)((uint32_t)(iVar30 * 3 + 8 + iVar34) >> 4);
        while (iVar35 = iVar35 + 1, iVar35 < iVar32) {
            uVar4 = *(uint8_t *)(iVar35 + arg2);
            iVar34 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar35 + arg3);
            *(char *)((int64_t)(iVar35 * 2) + -1 + arg1) = (char)((uint32_t)(iVar30 * 3 + 8 + iVar34) >> 4);
            *(char *)(iVar35 * 2 + arg1) = (char)((uint32_t)(iVar30 + 8 + iVar34 * 3) >> 4);
            iVar30 = iVar34;
        }
        *(char *)((int64_t)(iVar32 * 2) + -1 + arg1) = (char)(iVar30 + 2U >> 2);
        return arg1;
    }
    uVar29 = (undefined)(iVar34 + 2U >> 2);
    *(undefined *)(arg1 + 1) = uVar29;
    *(undefined *)arg1 = uVar29;
    return arg1;
}

// ============================================================
// Function: FUN_18006e201
// Address: 0x18006e201
// Size: 100 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018006e150)
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18006e0b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    char *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint8_t uVar4;
    undefined auVar5 [15];
    undefined auVar6 [15];
    undefined auVar7 [15];
    undefined auVar8 [15];
    undefined auVar9 [15];
    undefined auVar10 [15];
    undefined auVar11 [15];
    undefined auVar12 [15];
    undefined auVar13 [15];
    undefined auVar14 [15];
    undefined auVar15 [15];
    undefined auVar16 [15];
    undefined auVar17 [15];
    unkuint9 Var18;
    undefined auVar19 [11];
    undefined auVar20 [13];
    undefined auVar21 [15];
    unkuint9 Var22;
    undefined auVar23 [11];
    undefined auVar24 [13];
    undefined auVar25 [15];
    undefined auVar26 [15];
    undefined auVar27 [15];
    undefined auVar28 [15];
    undefined uVar29;
    int32_t iVar30;
    int64_t iVar31;
    int32_t iVar32;
    uint32_t uVar33;
    int32_t iVar34;
    int32_t iVar35;
    int16_t iVar36;
    uint16_t uVar37;
    int16_t iVar39;
    uint16_t uVar40;
    int16_t iVar41;
    uint16_t uVar42;
    int16_t iVar43;
    uint16_t uVar44;
    int16_t iVar45;
    uint16_t uVar46;
    int16_t iVar47;
    uint16_t uVar48;
    int16_t iVar49;
    uint16_t uVar50;
    undefined auVar38 [16];
    int16_t iVar51;
    uint16_t uVar52;
    undefined auVar53 [16];
    uint16_t uVar54;
    uint16_t uVar55;
    uint16_t uVar56;
    uint16_t uVar57;
    uint16_t uVar58;
    uint16_t uVar59;
    uint16_t uVar60;
    uint16_t uVar61;
    undefined auVar62 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar34 = (uint32_t)*(uint8_t *)arg2 + (uint32_t)*(uint8_t *)arg2 * 2 + (uint32_t)*(uint8_t *)arg3;
    iVar32 = (int32_t)arg4;
    if (iVar32 != 1) {
        iVar35 = 0;
        uVar33 = iVar32 - 1U & 0xfffffff8;
        if (0 < (int32_t)uVar33) {
            do {
                iVar31 = (int64_t)iVar35;
                uVar2 = *(uint64_t *)(iVar31 + arg2);
                uVar3 = *(uint64_t *)(iVar31 + arg3);
                uVar4 = *(uint8_t *)(iVar31 + arg2 + 8);
                auVar5._8_6_ = 0;
                auVar5._0_8_ = uVar2;
                auVar5[14] = (char)(uVar2 >> 0x38);
                auVar7._8_4_ = 0;
                auVar7._0_8_ = uVar2;
                auVar7[12] = (char)(uVar2 >> 0x30);
                auVar7._13_2_ = auVar5._13_2_;
                auVar9._8_4_ = 0;
                auVar9._0_8_ = uVar2;
                auVar9._12_3_ = auVar7._12_3_;
                auVar11._8_2_ = 0;
                auVar11._0_8_ = uVar2;
                auVar11[10] = (char)(uVar2 >> 0x28);
                auVar11._11_4_ = auVar9._11_4_;
                auVar13._8_2_ = 0;
                auVar13._0_8_ = uVar2;
                auVar13._10_5_ = auVar11._10_5_;
                auVar15[8] = (char)(uVar2 >> 0x20);
                auVar15._0_8_ = uVar2;
                auVar15._9_6_ = auVar13._9_6_;
                auVar17._7_8_ = 0;
                auVar17._0_7_ = auVar15._8_7_;
                Var18 = CONCAT81(SUB158(auVar17 << 0x40, 7), (char)(uVar2 >> 0x18));
                auVar25._9_6_ = 0;
                auVar25._0_9_ = Var18;
                auVar19._1_10_ = SUB1510(auVar25 << 0x30, 5);
                auVar19[0] = (char)(uVar2 >> 0x10);
                auVar26._11_4_ = 0;
                auVar26._0_11_ = auVar19;
                auVar20._1_12_ = SUB1512(auVar26 << 0x20, 3);
                auVar20[0] = (char)(uVar2 >> 8);
                auVar38._0_2_ = CONCAT11(0, (uint8_t)uVar2);
                auVar38._2_13_ = auVar20;
                auVar38[15] = 0;
                auVar6._8_6_ = 0;
                auVar6._0_8_ = uVar3;
                auVar6[14] = (char)(uVar3 >> 0x38);
                auVar8._8_4_ = 0;
                auVar8._0_8_ = uVar3;
                auVar8[12] = (char)(uVar3 >> 0x30);
                auVar8._13_2_ = auVar6._13_2_;
                auVar10._8_4_ = 0;
                auVar10._0_8_ = uVar3;
                auVar10._12_3_ = auVar8._12_3_;
                auVar12._8_2_ = 0;
                auVar12._0_8_ = uVar3;
                auVar12[10] = (char)(uVar3 >> 0x28);
                auVar12._11_4_ = auVar10._11_4_;
                auVar14._8_2_ = 0;
                auVar14._0_8_ = uVar3;
                auVar14._10_5_ = auVar12._10_5_;
                auVar16[8] = (char)(uVar3 >> 0x20);
                auVar16._0_8_ = uVar3;
                auVar16._9_6_ = auVar14._9_6_;
                auVar21._7_8_ = 0;
                auVar21._0_7_ = auVar16._8_7_;
                Var22 = CONCAT81(SUB158(auVar21 << 0x40, 7), (char)(uVar3 >> 0x18));
                auVar27._9_6_ = 0;
                auVar27._0_9_ = Var22;
                auVar23._1_10_ = SUB1510(auVar27 << 0x30, 5);
                auVar23[0] = (char)(uVar3 >> 0x10);
                auVar28._11_4_ = 0;
                auVar28._0_11_ = auVar23;
                auVar24._1_12_ = SUB1512(auVar28 << 0x20, 3);
                auVar24[0] = (char)(uVar3 >> 8);
                auVar53 = psllw(auVar38, 2);
                auVar62._0_2_ = ((uint8_t)uVar3 - auVar38._0_2_) + auVar53._0_2_;
                auVar62._2_2_ = (auVar24._0_2_ - auVar20._0_2_) + auVar53._2_2_;
                auVar62._4_2_ = (auVar23._0_2_ - auVar19._0_2_) + auVar53._4_2_;
                auVar62._6_2_ = ((int16_t)Var22 - (int16_t)Var18) + auVar53._6_2_;
                auVar62._8_2_ = (auVar16._8_2_ - auVar15._8_2_) + auVar53._8_2_;
                auVar62._10_2_ = (auVar12._10_2_ - auVar11._10_2_) + auVar53._10_2_;
                auVar62._12_2_ = (auVar8._12_2_ - auVar7._12_2_) + auVar53._12_2_;
                auVar62._14_2_ = ((auVar6._13_2_ >> 8) - (auVar5._13_2_ >> 8)) + auVar53._14_2_;
                iVar30 = iVar35 * 2;
                auVar38 = psllw(auVar62, 2);
                iVar35 = iVar35 + 8;
                iVar36 = auVar38._0_2_ + 8;
                iVar39 = auVar38._2_2_ + 8;
                iVar41 = auVar38._4_2_ + 8;
                iVar43 = auVar38._6_2_ + 8;
                iVar45 = auVar38._8_2_ + 8;
                iVar47 = auVar38._10_2_ + 8;
                iVar49 = auVar38._12_2_ + 8;
                iVar51 = auVar38._14_2_ + 8;
                uVar37 = (uint16_t)(((int16_t)iVar34 - auVar62._0_2_) + iVar36) >> 4;
                uVar40 = (uint16_t)((auVar62._2_2_ - auVar62._0_2_) + iVar36) >> 4;
                uVar42 = (uint16_t)((auVar62._0_2_ - auVar62._2_2_) + iVar39) >> 4;
                uVar44 = (uint16_t)((auVar62._4_2_ - auVar62._2_2_) + iVar39) >> 4;
                uVar46 = (uint16_t)((auVar62._2_2_ - auVar62._4_2_) + iVar41) >> 4;
                uVar48 = (uint16_t)((auVar62._6_2_ - auVar62._4_2_) + iVar41) >> 4;
                uVar50 = (uint16_t)((auVar62._4_2_ - auVar62._6_2_) + iVar43) >> 4;
                uVar52 = (uint16_t)((auVar62._8_2_ - auVar62._6_2_) + iVar43) >> 4;
                uVar54 = (uint16_t)((auVar62._6_2_ - auVar62._8_2_) + iVar45) >> 4;
                uVar55 = (uint16_t)((auVar62._10_2_ - auVar62._8_2_) + iVar45) >> 4;
                uVar56 = (uint16_t)((auVar62._8_2_ - auVar62._10_2_) + iVar47) >> 4;
                uVar57 = (uint16_t)((auVar62._12_2_ - auVar62._10_2_) + iVar47) >> 4;
                uVar58 = (uint16_t)((auVar62._10_2_ - auVar62._12_2_) + iVar49) >> 4;
                uVar59 = (uint16_t)((auVar62._14_2_ - auVar62._12_2_) + iVar49) >> 4;
                uVar60 = (uint16_t)((auVar62._12_2_ - auVar62._14_2_) + iVar51) >> 4;
                uVar61 = (uint16_t)
                         ((((uint16_t)uVar4 + (uint16_t)uVar4 * 2 + (uint16_t)*(uint8_t *)(iVar31 + arg3 + 8)) -
                          auVar62._14_2_) + iVar51) >> 4;
                pcVar1 = (char *)(iVar30 + arg1);
                *pcVar1 = (uVar37 != 0) * (uVar37 < 0xff) * (char)uVar37 - (0xff < uVar37);
                pcVar1[1] = (uVar40 != 0) * (uVar40 < 0xff) * (char)uVar40 - (0xff < uVar40);
                pcVar1[2] = (uVar42 != 0) * (uVar42 < 0xff) * (char)uVar42 - (0xff < uVar42);
                pcVar1[3] = (uVar44 != 0) * (uVar44 < 0xff) * (char)uVar44 - (0xff < uVar44);
                pcVar1[4] = (uVar46 != 0) * (uVar46 < 0xff) * (char)uVar46 - (0xff < uVar46);
                pcVar1[5] = (uVar48 != 0) * (uVar48 < 0xff) * (char)uVar48 - (0xff < uVar48);
                pcVar1[6] = (uVar50 != 0) * (uVar50 < 0xff) * (char)uVar50 - (0xff < uVar50);
                pcVar1[7] = (uVar52 != 0) * (uVar52 < 0xff) * (char)uVar52 - (0xff < uVar52);
                pcVar1[8] = (uVar54 != 0) * (uVar54 < 0xff) * (char)uVar54 - (0xff < uVar54);
                pcVar1[9] = (uVar55 != 0) * (uVar55 < 0xff) * (char)uVar55 - (0xff < uVar55);
                pcVar1[10] = (uVar56 != 0) * (uVar56 < 0xff) * (char)uVar56 - (0xff < uVar56);
                pcVar1[0xb] = (uVar57 != 0) * (uVar57 < 0xff) * (char)uVar57 - (0xff < uVar57);
                pcVar1[0xc] = (uVar58 != 0) * (uVar58 < 0xff) * (char)uVar58 - (0xff < uVar58);
                pcVar1[0xd] = (uVar59 != 0) * (uVar59 < 0xff) * (char)uVar59 - (0xff < uVar59);
                pcVar1[0xe] = (uVar60 != 0) * (uVar60 < 0xff) * (char)uVar60 - (0xff < uVar60);
                pcVar1[0xf] = (uVar61 != 0) * (uVar61 < 0xff) * (char)uVar61 - (0xff < uVar61);
                uVar4 = *(uint8_t *)(iVar31 + arg2 + 7);
                iVar34 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar31 + arg3 + 7);
            } while (iVar35 < (int32_t)uVar33);
        }
        uVar4 = *(uint8_t *)(iVar35 + arg2);
        iVar30 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar35 + arg3);
        *(char *)(iVar35 * 2 + arg1) = (char)((uint32_t)(iVar30 * 3 + 8 + iVar34) >> 4);
        while (iVar35 = iVar35 + 1, iVar35 < iVar32) {
            uVar4 = *(uint8_t *)(iVar35 + arg2);
            iVar34 = (uint32_t)uVar4 + (uint32_t)uVar4 * 2 + (uint32_t)*(uint8_t *)(iVar35 + arg3);
            *(char *)((int64_t)(iVar35 * 2) + -1 + arg1) = (char)((uint32_t)(iVar30 * 3 + 8 + iVar34) >> 4);
            *(char *)(iVar35 * 2 + arg1) = (char)((uint32_t)(iVar30 + 8 + iVar34 * 3) >> 4);
            iVar30 = iVar34;
        }
        *(char *)((int64_t)(iVar32 * 2) + -1 + arg1) = (char)(iVar30 + 2U >> 2);
        return arg1;
    }
    uVar29 = (undefined)(iVar34 + 2U >> 2);
    *(undefined *)(arg1 + 1) = uVar29;
    *(undefined *)arg1 = uVar29;
    return arg1;
}

// ============================================================
// Function: FUN_18006e270
// Address: 0x18006e270
// Size: 85 bytes
// ============================================================
int64_t fcn.18006e270(int64_t arg1, int64_t arg2, undefined8 placeholder_2, int64_t arg4, int64_t arg_48h)
{
    int32_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int32_t in_stack_00000028;
    
    uVar4 = 0;
    if (0 < (int32_t)arg4) {
        do {
            if (0 < in_stack_00000028) {
                iVar2 = 0;
                do {
                    iVar1 = (int32_t)uVar4 * in_stack_00000028 + iVar2;
                    iVar2 = iVar2 + 1;
                    *(undefined *)(iVar1 + arg1) = *(undefined *)(uVar4 + arg2);
                } while (iVar2 < in_stack_00000028);
            }
            uVar3 = (int32_t)uVar4 + 1;
            uVar4 = (uint64_t)uVar3;
        } while ((int32_t)uVar3 < (int32_t)arg4);
    }
    return arg1;
}

// ============================================================
// Function: FUN_18006e2d0
// Address: 0x18006e2d0
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18006e2d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = 0;
    if (0 < (int32_t)arg_28h) {
        do {
            iVar5 = (uint32_t)*(uint8_t *)(arg2 + uVar3) * 0x100000 + 0x80000;
            uVar1 = (int32_t)((*(uint8_t *)(arg4 + uVar3) - 0x80) * 0x166f00 + iVar5) >> 0x14;
            uVar6 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(arg4 + uVar3)) * 0xb6d00 +
                             iVar5 + ((0x80 - (uint32_t)*(uint8_t *)(arg3 + uVar3)) * 0x58200 & 0xffff0000)) >> 0x14;
            uVar4 = (int32_t)((*(uint8_t *)(arg3 + uVar3) - 0x80) * 0x1c5a00 + iVar5) >> 0x14;
            uVar2 = uVar1;
            if (0xff < uVar1) {
                uVar2 = 0xff;
                if ((int32_t)uVar1 < 0) {
                    uVar2 = 0;
                }
            }
            uVar1 = uVar6;
            if (0xff < uVar6) {
                uVar1 = 0xff;
                if ((int32_t)uVar6 < 0) {
                    uVar1 = 0;
                }
            }
            uVar6 = uVar4;
            if (0xff < uVar4) {
                uVar6 = 0xff;
                if ((int32_t)uVar4 < 0) {
                    uVar6 = 0;
                }
            }
            *(char *)arg1 = (char)uVar2;
            uVar2 = (int32_t)uVar3 + 1;
            uVar3 = (uint64_t)uVar2;
            *(char *)(arg1 + 1) = (char)uVar1;
            *(char *)(arg1 + 2) = (char)uVar6;
            *(undefined *)(arg1 + 3) = 0xff;
            arg1 = arg1 + (int32_t)arg_30h;
        } while ((int32_t)uVar2 < (int32_t)arg_28h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e2f7
// Address: 0x18006e2f7
// Size: 246 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18006e2d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = 0;
    if (0 < (int32_t)arg_28h) {
        do {
            iVar5 = (uint32_t)*(uint8_t *)(arg2 + uVar3) * 0x100000 + 0x80000;
            uVar1 = (int32_t)((*(uint8_t *)(arg4 + uVar3) - 0x80) * 0x166f00 + iVar5) >> 0x14;
            uVar6 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(arg4 + uVar3)) * 0xb6d00 +
                             iVar5 + ((0x80 - (uint32_t)*(uint8_t *)(arg3 + uVar3)) * 0x58200 & 0xffff0000)) >> 0x14;
            uVar4 = (int32_t)((*(uint8_t *)(arg3 + uVar3) - 0x80) * 0x1c5a00 + iVar5) >> 0x14;
            uVar2 = uVar1;
            if (0xff < uVar1) {
                uVar2 = 0xff;
                if ((int32_t)uVar1 < 0) {
                    uVar2 = 0;
                }
            }
            uVar1 = uVar6;
            if (0xff < uVar6) {
                uVar1 = 0xff;
                if ((int32_t)uVar6 < 0) {
                    uVar1 = 0;
                }
            }
            uVar6 = uVar4;
            if (0xff < uVar4) {
                uVar6 = 0xff;
                if ((int32_t)uVar4 < 0) {
                    uVar6 = 0;
                }
            }
            *(char *)arg1 = (char)uVar2;
            uVar2 = (int32_t)uVar3 + 1;
            uVar3 = (uint64_t)uVar2;
            *(char *)(arg1 + 1) = (char)uVar1;
            *(char *)(arg1 + 2) = (char)uVar6;
            *(undefined *)(arg1 + 3) = 0xff;
            arg1 = arg1 + (int32_t)arg_30h;
        } while ((int32_t)uVar2 < (int32_t)arg_28h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e3ed
// Address: 0x18006e3ed
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18006e2d0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar3 = 0;
    if (0 < (int32_t)arg_28h) {
        do {
            iVar5 = (uint32_t)*(uint8_t *)(arg2 + uVar3) * 0x100000 + 0x80000;
            uVar1 = (int32_t)((*(uint8_t *)(arg4 + uVar3) - 0x80) * 0x166f00 + iVar5) >> 0x14;
            uVar6 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(arg4 + uVar3)) * 0xb6d00 +
                             iVar5 + ((0x80 - (uint32_t)*(uint8_t *)(arg3 + uVar3)) * 0x58200 & 0xffff0000)) >> 0x14;
            uVar4 = (int32_t)((*(uint8_t *)(arg3 + uVar3) - 0x80) * 0x1c5a00 + iVar5) >> 0x14;
            uVar2 = uVar1;
            if (0xff < uVar1) {
                uVar2 = 0xff;
                if ((int32_t)uVar1 < 0) {
                    uVar2 = 0;
                }
            }
            uVar1 = uVar6;
            if (0xff < uVar6) {
                uVar1 = 0xff;
                if ((int32_t)uVar6 < 0) {
                    uVar1 = 0;
                }
            }
            uVar6 = uVar4;
            if (0xff < uVar4) {
                uVar6 = 0xff;
                if ((int32_t)uVar4 < 0) {
                    uVar6 = 0;
                }
            }
            *(char *)arg1 = (char)uVar2;
            uVar2 = (int32_t)uVar3 + 1;
            uVar3 = (uint64_t)uVar2;
            *(char *)(arg1 + 1) = (char)uVar1;
            *(char *)(arg1 + 2) = (char)uVar6;
            *(undefined *)(arg1 + 3) = 0xff;
            arg1 = arg1 + (int32_t)arg_30h;
        } while ((int32_t)uVar2 < (int32_t)arg_28h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e400
// Address: 0x18006e400
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18006e400(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_98h)
{
    int32_t iVar1;
    undefined8 uVar2;
    char cVar3;
    int16_t iVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int16_t iVar19;
    int16_t iVar20;
    int16_t iVar21;
    int16_t iVar22;
    int16_t iVar23;
    int16_t iVar24;
    int16_t iVar25;
    int16_t iVar26;
    undefined auVar27 [14];
    unkbyte10 Var28;
    undefined auVar29 [14];
    undefined auVar30 [12];
    unkbyte9 Var31;
    undefined auVar32 [15];
    undefined auVar33 [15];
    undefined auVar34 [15];
    undefined auVar35 [14];
    undefined auVar36 [14];
    unkbyte6 Var37;
    undefined4 uVar38;
    undefined2 uVar39;
    undefined auVar40 [16];
    undefined auVar41 [16];
    undefined auVar42 [16];
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    int64_t iVar46;
    int32_t iVar47;
    undefined uVar48;
    int32_t iVar50;
    uint32_t uVar51;
    uint32_t uVar52;
    bool bVar53;
    uint32_t uVar54;
    uint32_t uVar56;
    undefined auVar55 [16];
    uint16_t uVar57;
    uint16_t uVar67;
    uint16_t uVar68;
    uint16_t uVar69;
    uint16_t uVar70;
    uint16_t uVar71;
    uint16_t uVar72;
    undefined auVar58 [16];
    uint16_t uVar73;
    undefined auVar66 [16];
    undefined auVar74 [16];
    undefined auVar80 [16];
    undefined auVar81 [16];
    undefined auVar82 [16];
    undefined auVar83 [16];
    undefined auVar84 [16];
    undefined auVar90 [16];
    undefined auVar91 [16];
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    uint32_t uVar49;
    undefined auVar59 [16];
    undefined auVar60 [16];
    undefined auVar61 [16];
    undefined auVar62 [16];
    undefined auVar63 [16];
    undefined auVar64 [16];
    undefined auVar65 [16];
    undefined auVar75 [16];
    undefined auVar76 [16];
    undefined auVar77 [16];
    undefined auVar78 [16];
    undefined auVar79 [16];
    undefined auVar85 [16];
    undefined auVar86 [16];
    undefined auVar87 [16];
    undefined auVar88 [16];
    undefined auVar89 [16];
    
    auVar45 = *(undefined (*) [16])0x180646cc0;
    auVar44 = *(undefined (*) [16])0x180646ca0;
    auVar43 = *(undefined (*) [16])0x180646c50;
    auVar42 = *(undefined (*) [16])0x180646b60;
    auVar41 = *(undefined (*) [16])0x180646b50;
    iVar50 = 0;
    iVar47 = iVar50;
    if (((int32_t)arg_30h == 4) && (7 < (int32_t)arg_28h)) {
        do {
            auVar87._0_12_ = ZEXT812(0);
            iVar46 = (int64_t)iVar50;
            auVar77._0_12_ = ZEXT812(0);
            iVar47 = iVar50 + 8;
            uVar51 = auVar43._0_4_;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg4) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg4) >> 0x20) ^ auVar43._4_4_;
            auVar79._12_3_ = 0;
            auVar79._0_12_ = auVar77._0_12_;
            auVar79[15] = (char)(uVar56 >> 0x18);
            auVar78._14_2_ = auVar79._14_2_;
            auVar78[12] = 0;
            auVar78._0_12_ = auVar77._0_12_;
            auVar78[13] = (char)(uVar56 >> 0x10);
            auVar77._13_3_ = auVar78._13_3_;
            auVar77[12] = 0;
            auVar76._12_4_ = auVar77._12_4_;
            auVar76._0_11_ = SUB1211(auVar77._0_12_, 0);
            auVar76[11] = (char)(uVar56 >> 8);
            auVar75._11_5_ = auVar76._11_5_;
            auVar75._0_10_ = SUB1210(auVar77._0_12_, 0);
            auVar75[10] = 0;
            auVar74._10_6_ = auVar75._10_6_;
            auVar74._0_9_ = SUB129(auVar77._0_12_, 0);
            auVar74[9] = (char)uVar56;
            auVar81._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar74._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar81[0] = (char)(uVar54 >> 0x10);
            auVar81._11_5_ = 0;
            auVar35._1_12_ = SUB1612(auVar81 << 0x28, 4);
            auVar35[0] = (char)(uVar54 >> 8);
            auVar35[13] = 0;
            auVar40._1_14_ = auVar35 << 8;
            auVar40[0] = (char)uVar54;
            auVar40[15] = 0;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg3) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg3) >> 0x20) ^ auVar43._4_4_;
            auVar81 = pmulhw(auVar40 << 8, auVar41);
            auVar89._12_3_ = 0;
            auVar89._0_12_ = auVar87._0_12_;
            auVar89[15] = (char)(uVar56 >> 0x18);
            auVar88._14_2_ = auVar89._14_2_;
            auVar88[12] = 0;
            auVar88._0_12_ = auVar87._0_12_;
            auVar88[13] = (char)(uVar56 >> 0x10);
            auVar87._13_3_ = auVar88._13_3_;
            auVar87[12] = 0;
            auVar86._12_4_ = auVar87._12_4_;
            auVar86._0_11_ = SUB1211(auVar87._0_12_, 0);
            auVar86[11] = (char)(uVar56 >> 8);
            auVar85._11_5_ = auVar86._11_5_;
            auVar85._0_10_ = SUB1210(auVar87._0_12_, 0);
            auVar85[10] = 0;
            auVar84._10_6_ = auVar85._10_6_;
            auVar84._0_9_ = SUB129(auVar87._0_12_, 0);
            auVar84[9] = (char)uVar56;
            auVar80._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar84._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar80[0] = (char)(uVar54 >> 0x10);
            auVar80._11_5_ = 0;
            auVar36._1_12_ = SUB1612(auVar80 << 0x28, 4);
            auVar36[0] = (char)(uVar54 >> 8);
            auVar36[13] = 0;
            auVar83._1_14_ = auVar36 << 8;
            auVar83[0] = (char)uVar54;
            auVar83[15] = 0;
            uVar2 = *(undefined8 *)(iVar46 + arg2);
            iVar1 = iVar50 + 0xf;
            auVar65._0_14_ = auVar43._0_14_;
            auVar65[14] = auVar43[7];
            auVar65[15] = (char)((uint64_t)uVar2 >> 0x38);
            auVar64._14_2_ = auVar65._14_2_;
            auVar64._0_13_ = auVar43._0_13_;
            auVar64[13] = (char)((uint64_t)uVar2 >> 0x30);
            auVar63._13_3_ = auVar64._13_3_;
            auVar63._0_12_ = auVar43._0_12_;
            auVar63[12] = auVar43[6];
            auVar62._12_4_ = auVar63._12_4_;
            auVar62._0_11_ = auVar43._0_11_;
            auVar62[11] = (char)((uint64_t)uVar2 >> 0x28);
            auVar61._11_5_ = auVar62._11_5_;
            auVar61._0_10_ = auVar43._0_10_;
            auVar61[10] = auVar43[5];
            auVar60._10_6_ = auVar61._10_6_;
            auVar60._0_9_ = auVar43._0_9_;
            auVar60[9] = (char)((uint64_t)uVar2 >> 0x20);
            auVar59._9_7_ = auVar60._9_7_;
            auVar59._0_8_ = auVar43._0_8_;
            auVar59[8] = auVar43[4];
            Var28 = CONCAT91(CONCAT81(auVar59._8_8_, (char)((uint64_t)uVar2 >> 0x18)), auVar43[3]);
            auVar58._6_10_ = Var28;
            auVar58[5] = (char)((uint64_t)uVar2 >> 0x10);
            auVar58[4] = auVar43[2];
            auVar58._0_4_ = uVar51;
            auVar27._2_12_ = auVar58._4_12_;
            auVar27[1] = (char)((uint64_t)uVar2 >> 8);
            auVar27[0] = auVar43[1];
            uVar57 = CONCAT11((char)uVar2, auVar43[0]) >> 4;
            uVar67 = auVar27._0_2_ >> 4;
            uVar68 = auVar58._4_2_ >> 4;
            uVar69 = (uint16_t)Var28 >> 4;
            uVar70 = auVar59._8_2_ >> 4;
            uVar71 = auVar61._10_2_ >> 4;
            uVar72 = auVar63._12_2_ >> 4;
            uVar73 = auVar64._14_2_ >> 4;
            auVar82._0_2_ = auVar81._0_2_ + uVar57;
            auVar82._2_2_ = auVar81._2_2_ + uVar67;
            auVar82._4_2_ = auVar81._4_2_ + uVar68;
            auVar82._6_2_ = auVar81._6_2_ + uVar69;
            auVar82._8_2_ = auVar81._8_2_ + uVar70;
            auVar82._10_2_ = auVar81._10_2_ + uVar71;
            auVar82._12_2_ = auVar81._12_2_ + uVar72;
            auVar82._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = pmulhw(auVar83 << 8, auVar42);
            auVar90 = pmulhw(auVar83 << 8, auVar45);
            auVar83 = psraw(auVar82, 4);
            auVar80 = pmulhw(auVar40 << 8, auVar44);
            auVar55._0_2_ = auVar81._0_2_ + uVar57;
            auVar55._2_2_ = auVar81._2_2_ + uVar67;
            auVar55._4_2_ = auVar81._4_2_ + uVar68;
            auVar55._6_2_ = auVar81._6_2_ + uVar69;
            auVar55._8_2_ = auVar81._8_2_ + uVar70;
            auVar55._10_2_ = auVar81._10_2_ + uVar71;
            auVar55._12_2_ = auVar81._12_2_ + uVar72;
            auVar55._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = psraw(auVar55, 4);
            iVar4 = auVar83._0_2_;
            iVar5 = auVar83._2_2_;
            iVar7 = auVar83._4_2_;
            iVar9 = auVar83._6_2_;
            iVar11 = auVar83._8_2_;
            iVar13 = auVar83._10_2_;
            iVar15 = auVar83._12_2_;
            iVar17 = auVar83._14_2_;
            cVar3 = (0 < iVar17) * (iVar17 < 0xff) * auVar83[14] - (0xff < iVar17);
            iVar19 = auVar81._0_2_;
            iVar20 = auVar81._2_2_;
            iVar21 = auVar81._4_2_;
            iVar22 = auVar81._6_2_;
            iVar23 = auVar81._8_2_;
            iVar24 = auVar81._10_2_;
            iVar25 = auVar81._12_2_;
            iVar26 = auVar81._14_2_;
            auVar91._0_2_ = auVar90._0_2_ + uVar57 + auVar80._0_2_;
            auVar91._2_2_ = auVar90._2_2_ + uVar67 + auVar80._2_2_;
            auVar91._4_2_ = auVar90._4_2_ + uVar68 + auVar80._4_2_;
            auVar91._6_2_ = auVar90._6_2_ + uVar69 + auVar80._6_2_;
            auVar91._8_2_ = auVar90._8_2_ + uVar70 + auVar80._8_2_;
            auVar91._10_2_ = auVar90._10_2_ + uVar71 + auVar80._10_2_;
            auVar91._12_2_ = auVar90._12_2_ + uVar72 + auVar80._12_2_;
            auVar91._14_2_ = auVar90._14_2_ + uVar73 + auVar80._14_2_;
            auVar80 = psraw(auVar91, 4);
            iVar17 = auVar80._0_2_;
            iVar6 = auVar80._2_2_;
            iVar8 = auVar80._4_2_;
            iVar10 = auVar80._6_2_;
            iVar12 = auVar80._8_2_;
            iVar14 = auVar80._10_2_;
            iVar16 = auVar80._12_2_;
            iVar18 = auVar80._14_2_;
            uVar39 = CONCAT11((0 < iVar18) * (iVar18 < 0xff) * auVar80[14] - (0xff < iVar18), cVar3);
            uVar38 = CONCAT31(CONCAT21(uVar39, (0 < iVar16) * (iVar16 < 0xff) * auVar80[12] - (0xff < iVar16)), 
                              (0 < iVar15) * (iVar15 < 0xff) * auVar83[12] - (0xff < iVar15));
            Var37 = CONCAT51(CONCAT41(uVar38, (0 < iVar14) * (iVar14 < 0xff) * auVar80[10] - (0xff < iVar14)), 
                             (0 < iVar13) * (iVar13 < 0xff) * auVar83[10] - (0xff < iVar13));
            Var31 = CONCAT72(CONCAT61(Var37, (0 < iVar12) * (iVar12 < 0xff) * auVar80[8] - (0xff < iVar12)), 
                             CONCAT11((0 < iVar11) * (iVar11 < 0xff) * auVar83[8] - (0xff < iVar11), cVar3));
            Var28 = CONCAT91(CONCAT81((int64_t)((unkuint9)Var31 >> 8), 
                                      (0 < iVar10) * (iVar10 < 0xff) * auVar80[6] - (0xff < iVar10)), 
                             (0 < iVar9) * (iVar9 < 0xff) * auVar83[6] - (0xff < iVar9));
            auVar30._2_10_ = Var28;
            auVar30[1] = (0 < iVar8) * (iVar8 < 0xff) * auVar80[4] - (0xff < iVar8);
            auVar30[0] = (0 < iVar7) * (iVar7 < 0xff) * auVar83[4] - (0xff < iVar7);
            auVar29._2_12_ = auVar30;
            auVar29[1] = (0 < iVar6) * (iVar6 < 0xff) * auVar80[2] - (0xff < iVar6);
            auVar29[0] = (0 < iVar5) * (iVar5 < 0xff) * auVar83[2] - (0xff < iVar5);
            auVar66._0_2_ =
                 CONCAT11((0 < iVar17) * (iVar17 < 0xff) * auVar80[0] - (0xff < iVar17), 
                          (0 < iVar4) * (iVar4 < 0xff) * auVar83[0] - (0xff < iVar4));
            auVar66._2_14_ = auVar29;
            auVar32._12_2_ = (int16_t)Var28;
            auVar32._0_12_ = auVar66._0_12_;
            auVar32[14] = (0 < iVar22) * (iVar22 < 0xff) * auVar81[6] - (0xff < iVar22);
            auVar33[10] = (0 < iVar21) * (iVar21 < 0xff) * auVar81[4] - (0xff < iVar21);
            auVar33._0_10_ = auVar66._0_10_;
            auVar33[11] = 0;
            auVar33._12_3_ = auVar32._12_3_;
            auVar34._8_2_ = auVar30._0_2_;
            auVar34._0_8_ = auVar66._0_8_;
            auVar34._10_5_ = auVar33._10_5_;
            auVar90[7] = 0;
            auVar90[6] = (0 < iVar20) * (iVar20 < 0xff) * auVar81[2] - (0xff < iVar20);
            auVar90._8_7_ = auVar34._8_7_;
            auVar90._4_2_ = auVar29._0_2_;
            auVar90[2] = (0 < iVar19) * (iVar19 < 0xff) * auVar81[0] - (0xff < iVar19);
            auVar90._0_2_ = auVar66._0_2_;
            auVar90[3] = 0;
            auVar90[15] = 0;
            *(undefined (*) [16])arg1 = auVar90;
            *(int16_t *)*(undefined (*) [16])(arg1 + 0x10) = (int16_t)((unkuint9)Var31 >> 8);
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 2) =
                 (uint16_t)(uint8_t)((0 < iVar23) * (iVar23 < 0xff) * auVar81[8] - (0xff < iVar23));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 4) = (int16_t)Var37;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 6) =
                 (uint16_t)(uint8_t)((0 < iVar24) * (iVar24 < 0xff) * auVar81[10] - (0xff < iVar24));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 8) = (int16_t)uVar38;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 10) =
                 (uint16_t)(uint8_t)((0 < iVar25) * (iVar25 < 0xff) * auVar81[12] - (0xff < iVar25));
            *(undefined2 *)(*(undefined (*) [16])(arg1 + 0x10) + 0xc) = uVar39;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 0xe) =
                 (uint16_t)(uint8_t)((0 < iVar26) * (iVar26 < 0xff) * auVar81[14] - (0xff < iVar26));
            arg1 = arg1 + 0x20;
            iVar50 = iVar47;
        } while (iVar1 < (int32_t)arg_28h);
    }
    for (; iVar47 < (int32_t)arg_28h; iVar47 = iVar47 + 1) {
        iVar46 = (int64_t)iVar47;
        iVar50 = (uint32_t)*(uint8_t *)(iVar46 + arg2) * 0x100000 + 0x80000;
        uVar52 = (int32_t)((*(uint8_t *)(iVar46 + arg4) - 0x80) * 0x166f00 + iVar50) >> 0x14;
        uVar56 = (0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg3)) * 0x58200 & 0xffff0000;
        uVar51 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg4)) * 0xb6d00 + iVar50 + uVar56) >> 0x14;
        uVar54 = (int32_t)((*(uint8_t *)(iVar46 + arg3) - 0x80) * 0x1c5a00 + iVar50) >> 0x14;
        if (uVar52 < 0x100) {
            uVar48 = (undefined)uVar52;
        } else {
            uVar49 = 0xff;
            if ((int32_t)uVar52 < 0) {
                uVar49 = uVar56;
            }
            uVar48 = (undefined)uVar49;
        }
        uVar52 = uVar51;
        if ((0xff < uVar51) && (uVar52 = 0xff, (int32_t)uVar51 < 0)) {
            uVar52 = uVar56;
        }
        if ((0xff < uVar54) && (bVar53 = (int32_t)uVar54 < 0, uVar54 = 0xff, bVar53)) {
            uVar54 = 0;
        }
        *(undefined *)arg1 = uVar48;
        ((undefined *)arg1)[1] = (char)uVar52;
        ((undefined *)arg1)[2] = (char)uVar54;
        ((undefined *)arg1)[3] = 0xff;
        arg1 = (int64_t)((undefined *)arg1 + (int32_t)arg_30h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e43c
// Address: 0x18006e43c
// Size: 281 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18006e400(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_98h)
{
    int32_t iVar1;
    undefined8 uVar2;
    char cVar3;
    int16_t iVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int16_t iVar19;
    int16_t iVar20;
    int16_t iVar21;
    int16_t iVar22;
    int16_t iVar23;
    int16_t iVar24;
    int16_t iVar25;
    int16_t iVar26;
    undefined auVar27 [14];
    unkbyte10 Var28;
    undefined auVar29 [14];
    undefined auVar30 [12];
    unkbyte9 Var31;
    undefined auVar32 [15];
    undefined auVar33 [15];
    undefined auVar34 [15];
    undefined auVar35 [14];
    undefined auVar36 [14];
    unkbyte6 Var37;
    undefined4 uVar38;
    undefined2 uVar39;
    undefined auVar40 [16];
    undefined auVar41 [16];
    undefined auVar42 [16];
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    int64_t iVar46;
    int32_t iVar47;
    undefined uVar48;
    int32_t iVar50;
    uint32_t uVar51;
    uint32_t uVar52;
    bool bVar53;
    uint32_t uVar54;
    uint32_t uVar56;
    undefined auVar55 [16];
    uint16_t uVar57;
    uint16_t uVar67;
    uint16_t uVar68;
    uint16_t uVar69;
    uint16_t uVar70;
    uint16_t uVar71;
    uint16_t uVar72;
    undefined auVar58 [16];
    uint16_t uVar73;
    undefined auVar66 [16];
    undefined auVar74 [16];
    undefined auVar80 [16];
    undefined auVar81 [16];
    undefined auVar82 [16];
    undefined auVar83 [16];
    undefined auVar84 [16];
    undefined auVar90 [16];
    undefined auVar91 [16];
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    uint32_t uVar49;
    undefined auVar59 [16];
    undefined auVar60 [16];
    undefined auVar61 [16];
    undefined auVar62 [16];
    undefined auVar63 [16];
    undefined auVar64 [16];
    undefined auVar65 [16];
    undefined auVar75 [16];
    undefined auVar76 [16];
    undefined auVar77 [16];
    undefined auVar78 [16];
    undefined auVar79 [16];
    undefined auVar85 [16];
    undefined auVar86 [16];
    undefined auVar87 [16];
    undefined auVar88 [16];
    undefined auVar89 [16];
    
    auVar45 = *(undefined (*) [16])0x180646cc0;
    auVar44 = *(undefined (*) [16])0x180646ca0;
    auVar43 = *(undefined (*) [16])0x180646c50;
    auVar42 = *(undefined (*) [16])0x180646b60;
    auVar41 = *(undefined (*) [16])0x180646b50;
    iVar50 = 0;
    iVar47 = iVar50;
    if (((int32_t)arg_30h == 4) && (7 < (int32_t)arg_28h)) {
        do {
            auVar87._0_12_ = ZEXT812(0);
            iVar46 = (int64_t)iVar50;
            auVar77._0_12_ = ZEXT812(0);
            iVar47 = iVar50 + 8;
            uVar51 = auVar43._0_4_;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg4) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg4) >> 0x20) ^ auVar43._4_4_;
            auVar79._12_3_ = 0;
            auVar79._0_12_ = auVar77._0_12_;
            auVar79[15] = (char)(uVar56 >> 0x18);
            auVar78._14_2_ = auVar79._14_2_;
            auVar78[12] = 0;
            auVar78._0_12_ = auVar77._0_12_;
            auVar78[13] = (char)(uVar56 >> 0x10);
            auVar77._13_3_ = auVar78._13_3_;
            auVar77[12] = 0;
            auVar76._12_4_ = auVar77._12_4_;
            auVar76._0_11_ = SUB1211(auVar77._0_12_, 0);
            auVar76[11] = (char)(uVar56 >> 8);
            auVar75._11_5_ = auVar76._11_5_;
            auVar75._0_10_ = SUB1210(auVar77._0_12_, 0);
            auVar75[10] = 0;
            auVar74._10_6_ = auVar75._10_6_;
            auVar74._0_9_ = SUB129(auVar77._0_12_, 0);
            auVar74[9] = (char)uVar56;
            auVar81._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar74._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar81[0] = (char)(uVar54 >> 0x10);
            auVar81._11_5_ = 0;
            auVar35._1_12_ = SUB1612(auVar81 << 0x28, 4);
            auVar35[0] = (char)(uVar54 >> 8);
            auVar35[13] = 0;
            auVar40._1_14_ = auVar35 << 8;
            auVar40[0] = (char)uVar54;
            auVar40[15] = 0;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg3) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg3) >> 0x20) ^ auVar43._4_4_;
            auVar81 = pmulhw(auVar40 << 8, auVar41);
            auVar89._12_3_ = 0;
            auVar89._0_12_ = auVar87._0_12_;
            auVar89[15] = (char)(uVar56 >> 0x18);
            auVar88._14_2_ = auVar89._14_2_;
            auVar88[12] = 0;
            auVar88._0_12_ = auVar87._0_12_;
            auVar88[13] = (char)(uVar56 >> 0x10);
            auVar87._13_3_ = auVar88._13_3_;
            auVar87[12] = 0;
            auVar86._12_4_ = auVar87._12_4_;
            auVar86._0_11_ = SUB1211(auVar87._0_12_, 0);
            auVar86[11] = (char)(uVar56 >> 8);
            auVar85._11_5_ = auVar86._11_5_;
            auVar85._0_10_ = SUB1210(auVar87._0_12_, 0);
            auVar85[10] = 0;
            auVar84._10_6_ = auVar85._10_6_;
            auVar84._0_9_ = SUB129(auVar87._0_12_, 0);
            auVar84[9] = (char)uVar56;
            auVar80._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar84._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar80[0] = (char)(uVar54 >> 0x10);
            auVar80._11_5_ = 0;
            auVar36._1_12_ = SUB1612(auVar80 << 0x28, 4);
            auVar36[0] = (char)(uVar54 >> 8);
            auVar36[13] = 0;
            auVar83._1_14_ = auVar36 << 8;
            auVar83[0] = (char)uVar54;
            auVar83[15] = 0;
            uVar2 = *(undefined8 *)(iVar46 + arg2);
            iVar1 = iVar50 + 0xf;
            auVar65._0_14_ = auVar43._0_14_;
            auVar65[14] = auVar43[7];
            auVar65[15] = (char)((uint64_t)uVar2 >> 0x38);
            auVar64._14_2_ = auVar65._14_2_;
            auVar64._0_13_ = auVar43._0_13_;
            auVar64[13] = (char)((uint64_t)uVar2 >> 0x30);
            auVar63._13_3_ = auVar64._13_3_;
            auVar63._0_12_ = auVar43._0_12_;
            auVar63[12] = auVar43[6];
            auVar62._12_4_ = auVar63._12_4_;
            auVar62._0_11_ = auVar43._0_11_;
            auVar62[11] = (char)((uint64_t)uVar2 >> 0x28);
            auVar61._11_5_ = auVar62._11_5_;
            auVar61._0_10_ = auVar43._0_10_;
            auVar61[10] = auVar43[5];
            auVar60._10_6_ = auVar61._10_6_;
            auVar60._0_9_ = auVar43._0_9_;
            auVar60[9] = (char)((uint64_t)uVar2 >> 0x20);
            auVar59._9_7_ = auVar60._9_7_;
            auVar59._0_8_ = auVar43._0_8_;
            auVar59[8] = auVar43[4];
            Var28 = CONCAT91(CONCAT81(auVar59._8_8_, (char)((uint64_t)uVar2 >> 0x18)), auVar43[3]);
            auVar58._6_10_ = Var28;
            auVar58[5] = (char)((uint64_t)uVar2 >> 0x10);
            auVar58[4] = auVar43[2];
            auVar58._0_4_ = uVar51;
            auVar27._2_12_ = auVar58._4_12_;
            auVar27[1] = (char)((uint64_t)uVar2 >> 8);
            auVar27[0] = auVar43[1];
            uVar57 = CONCAT11((char)uVar2, auVar43[0]) >> 4;
            uVar67 = auVar27._0_2_ >> 4;
            uVar68 = auVar58._4_2_ >> 4;
            uVar69 = (uint16_t)Var28 >> 4;
            uVar70 = auVar59._8_2_ >> 4;
            uVar71 = auVar61._10_2_ >> 4;
            uVar72 = auVar63._12_2_ >> 4;
            uVar73 = auVar64._14_2_ >> 4;
            auVar82._0_2_ = auVar81._0_2_ + uVar57;
            auVar82._2_2_ = auVar81._2_2_ + uVar67;
            auVar82._4_2_ = auVar81._4_2_ + uVar68;
            auVar82._6_2_ = auVar81._6_2_ + uVar69;
            auVar82._8_2_ = auVar81._8_2_ + uVar70;
            auVar82._10_2_ = auVar81._10_2_ + uVar71;
            auVar82._12_2_ = auVar81._12_2_ + uVar72;
            auVar82._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = pmulhw(auVar83 << 8, auVar42);
            auVar90 = pmulhw(auVar83 << 8, auVar45);
            auVar83 = psraw(auVar82, 4);
            auVar80 = pmulhw(auVar40 << 8, auVar44);
            auVar55._0_2_ = auVar81._0_2_ + uVar57;
            auVar55._2_2_ = auVar81._2_2_ + uVar67;
            auVar55._4_2_ = auVar81._4_2_ + uVar68;
            auVar55._6_2_ = auVar81._6_2_ + uVar69;
            auVar55._8_2_ = auVar81._8_2_ + uVar70;
            auVar55._10_2_ = auVar81._10_2_ + uVar71;
            auVar55._12_2_ = auVar81._12_2_ + uVar72;
            auVar55._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = psraw(auVar55, 4);
            iVar4 = auVar83._0_2_;
            iVar5 = auVar83._2_2_;
            iVar7 = auVar83._4_2_;
            iVar9 = auVar83._6_2_;
            iVar11 = auVar83._8_2_;
            iVar13 = auVar83._10_2_;
            iVar15 = auVar83._12_2_;
            iVar17 = auVar83._14_2_;
            cVar3 = (0 < iVar17) * (iVar17 < 0xff) * auVar83[14] - (0xff < iVar17);
            iVar19 = auVar81._0_2_;
            iVar20 = auVar81._2_2_;
            iVar21 = auVar81._4_2_;
            iVar22 = auVar81._6_2_;
            iVar23 = auVar81._8_2_;
            iVar24 = auVar81._10_2_;
            iVar25 = auVar81._12_2_;
            iVar26 = auVar81._14_2_;
            auVar91._0_2_ = auVar90._0_2_ + uVar57 + auVar80._0_2_;
            auVar91._2_2_ = auVar90._2_2_ + uVar67 + auVar80._2_2_;
            auVar91._4_2_ = auVar90._4_2_ + uVar68 + auVar80._4_2_;
            auVar91._6_2_ = auVar90._6_2_ + uVar69 + auVar80._6_2_;
            auVar91._8_2_ = auVar90._8_2_ + uVar70 + auVar80._8_2_;
            auVar91._10_2_ = auVar90._10_2_ + uVar71 + auVar80._10_2_;
            auVar91._12_2_ = auVar90._12_2_ + uVar72 + auVar80._12_2_;
            auVar91._14_2_ = auVar90._14_2_ + uVar73 + auVar80._14_2_;
            auVar80 = psraw(auVar91, 4);
            iVar17 = auVar80._0_2_;
            iVar6 = auVar80._2_2_;
            iVar8 = auVar80._4_2_;
            iVar10 = auVar80._6_2_;
            iVar12 = auVar80._8_2_;
            iVar14 = auVar80._10_2_;
            iVar16 = auVar80._12_2_;
            iVar18 = auVar80._14_2_;
            uVar39 = CONCAT11((0 < iVar18) * (iVar18 < 0xff) * auVar80[14] - (0xff < iVar18), cVar3);
            uVar38 = CONCAT31(CONCAT21(uVar39, (0 < iVar16) * (iVar16 < 0xff) * auVar80[12] - (0xff < iVar16)), 
                              (0 < iVar15) * (iVar15 < 0xff) * auVar83[12] - (0xff < iVar15));
            Var37 = CONCAT51(CONCAT41(uVar38, (0 < iVar14) * (iVar14 < 0xff) * auVar80[10] - (0xff < iVar14)), 
                             (0 < iVar13) * (iVar13 < 0xff) * auVar83[10] - (0xff < iVar13));
            Var31 = CONCAT72(CONCAT61(Var37, (0 < iVar12) * (iVar12 < 0xff) * auVar80[8] - (0xff < iVar12)), 
                             CONCAT11((0 < iVar11) * (iVar11 < 0xff) * auVar83[8] - (0xff < iVar11), cVar3));
            Var28 = CONCAT91(CONCAT81((int64_t)((unkuint9)Var31 >> 8), 
                                      (0 < iVar10) * (iVar10 < 0xff) * auVar80[6] - (0xff < iVar10)), 
                             (0 < iVar9) * (iVar9 < 0xff) * auVar83[6] - (0xff < iVar9));
            auVar30._2_10_ = Var28;
            auVar30[1] = (0 < iVar8) * (iVar8 < 0xff) * auVar80[4] - (0xff < iVar8);
            auVar30[0] = (0 < iVar7) * (iVar7 < 0xff) * auVar83[4] - (0xff < iVar7);
            auVar29._2_12_ = auVar30;
            auVar29[1] = (0 < iVar6) * (iVar6 < 0xff) * auVar80[2] - (0xff < iVar6);
            auVar29[0] = (0 < iVar5) * (iVar5 < 0xff) * auVar83[2] - (0xff < iVar5);
            auVar66._0_2_ =
                 CONCAT11((0 < iVar17) * (iVar17 < 0xff) * auVar80[0] - (0xff < iVar17), 
                          (0 < iVar4) * (iVar4 < 0xff) * auVar83[0] - (0xff < iVar4));
            auVar66._2_14_ = auVar29;
            auVar32._12_2_ = (int16_t)Var28;
            auVar32._0_12_ = auVar66._0_12_;
            auVar32[14] = (0 < iVar22) * (iVar22 < 0xff) * auVar81[6] - (0xff < iVar22);
            auVar33[10] = (0 < iVar21) * (iVar21 < 0xff) * auVar81[4] - (0xff < iVar21);
            auVar33._0_10_ = auVar66._0_10_;
            auVar33[11] = 0;
            auVar33._12_3_ = auVar32._12_3_;
            auVar34._8_2_ = auVar30._0_2_;
            auVar34._0_8_ = auVar66._0_8_;
            auVar34._10_5_ = auVar33._10_5_;
            auVar90[7] = 0;
            auVar90[6] = (0 < iVar20) * (iVar20 < 0xff) * auVar81[2] - (0xff < iVar20);
            auVar90._8_7_ = auVar34._8_7_;
            auVar90._4_2_ = auVar29._0_2_;
            auVar90[2] = (0 < iVar19) * (iVar19 < 0xff) * auVar81[0] - (0xff < iVar19);
            auVar90._0_2_ = auVar66._0_2_;
            auVar90[3] = 0;
            auVar90[15] = 0;
            *(undefined (*) [16])arg1 = auVar90;
            *(int16_t *)*(undefined (*) [16])(arg1 + 0x10) = (int16_t)((unkuint9)Var31 >> 8);
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 2) =
                 (uint16_t)(uint8_t)((0 < iVar23) * (iVar23 < 0xff) * auVar81[8] - (0xff < iVar23));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 4) = (int16_t)Var37;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 6) =
                 (uint16_t)(uint8_t)((0 < iVar24) * (iVar24 < 0xff) * auVar81[10] - (0xff < iVar24));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 8) = (int16_t)uVar38;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 10) =
                 (uint16_t)(uint8_t)((0 < iVar25) * (iVar25 < 0xff) * auVar81[12] - (0xff < iVar25));
            *(undefined2 *)(*(undefined (*) [16])(arg1 + 0x10) + 0xc) = uVar39;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 0xe) =
                 (uint16_t)(uint8_t)((0 < iVar26) * (iVar26 < 0xff) * auVar81[14] - (0xff < iVar26));
            arg1 = arg1 + 0x20;
            iVar50 = iVar47;
        } while (iVar1 < (int32_t)arg_28h);
    }
    for (; iVar47 < (int32_t)arg_28h; iVar47 = iVar47 + 1) {
        iVar46 = (int64_t)iVar47;
        iVar50 = (uint32_t)*(uint8_t *)(iVar46 + arg2) * 0x100000 + 0x80000;
        uVar52 = (int32_t)((*(uint8_t *)(iVar46 + arg4) - 0x80) * 0x166f00 + iVar50) >> 0x14;
        uVar56 = (0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg3)) * 0x58200 & 0xffff0000;
        uVar51 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg4)) * 0xb6d00 + iVar50 + uVar56) >> 0x14;
        uVar54 = (int32_t)((*(uint8_t *)(iVar46 + arg3) - 0x80) * 0x1c5a00 + iVar50) >> 0x14;
        if (uVar52 < 0x100) {
            uVar48 = (undefined)uVar52;
        } else {
            uVar49 = 0xff;
            if ((int32_t)uVar52 < 0) {
                uVar49 = uVar56;
            }
            uVar48 = (undefined)uVar49;
        }
        uVar52 = uVar51;
        if ((0xff < uVar51) && (uVar52 = 0xff, (int32_t)uVar51 < 0)) {
            uVar52 = uVar56;
        }
        if ((0xff < uVar54) && (bVar53 = (int32_t)uVar54 < 0, uVar54 = 0xff, bVar53)) {
            uVar54 = 0;
        }
        *(undefined *)arg1 = uVar48;
        ((undefined *)arg1)[1] = (char)uVar52;
        ((undefined *)arg1)[2] = (char)uVar54;
        ((undefined *)arg1)[3] = 0xff;
        arg1 = (int64_t)((undefined *)arg1 + (int32_t)arg_30h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e555
// Address: 0x18006e555
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18006e400(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_98h)
{
    int32_t iVar1;
    undefined8 uVar2;
    char cVar3;
    int16_t iVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int16_t iVar19;
    int16_t iVar20;
    int16_t iVar21;
    int16_t iVar22;
    int16_t iVar23;
    int16_t iVar24;
    int16_t iVar25;
    int16_t iVar26;
    undefined auVar27 [14];
    unkbyte10 Var28;
    undefined auVar29 [14];
    undefined auVar30 [12];
    unkbyte9 Var31;
    undefined auVar32 [15];
    undefined auVar33 [15];
    undefined auVar34 [15];
    undefined auVar35 [14];
    undefined auVar36 [14];
    unkbyte6 Var37;
    undefined4 uVar38;
    undefined2 uVar39;
    undefined auVar40 [16];
    undefined auVar41 [16];
    undefined auVar42 [16];
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    int64_t iVar46;
    int32_t iVar47;
    undefined uVar48;
    int32_t iVar50;
    uint32_t uVar51;
    uint32_t uVar52;
    bool bVar53;
    uint32_t uVar54;
    uint32_t uVar56;
    undefined auVar55 [16];
    uint16_t uVar57;
    uint16_t uVar67;
    uint16_t uVar68;
    uint16_t uVar69;
    uint16_t uVar70;
    uint16_t uVar71;
    uint16_t uVar72;
    undefined auVar58 [16];
    uint16_t uVar73;
    undefined auVar66 [16];
    undefined auVar74 [16];
    undefined auVar80 [16];
    undefined auVar81 [16];
    undefined auVar82 [16];
    undefined auVar83 [16];
    undefined auVar84 [16];
    undefined auVar90 [16];
    undefined auVar91 [16];
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    uint32_t uVar49;
    undefined auVar59 [16];
    undefined auVar60 [16];
    undefined auVar61 [16];
    undefined auVar62 [16];
    undefined auVar63 [16];
    undefined auVar64 [16];
    undefined auVar65 [16];
    undefined auVar75 [16];
    undefined auVar76 [16];
    undefined auVar77 [16];
    undefined auVar78 [16];
    undefined auVar79 [16];
    undefined auVar85 [16];
    undefined auVar86 [16];
    undefined auVar87 [16];
    undefined auVar88 [16];
    undefined auVar89 [16];
    
    auVar45 = *(undefined (*) [16])0x180646cc0;
    auVar44 = *(undefined (*) [16])0x180646ca0;
    auVar43 = *(undefined (*) [16])0x180646c50;
    auVar42 = *(undefined (*) [16])0x180646b60;
    auVar41 = *(undefined (*) [16])0x180646b50;
    iVar50 = 0;
    iVar47 = iVar50;
    if (((int32_t)arg_30h == 4) && (7 < (int32_t)arg_28h)) {
        do {
            auVar87._0_12_ = ZEXT812(0);
            iVar46 = (int64_t)iVar50;
            auVar77._0_12_ = ZEXT812(0);
            iVar47 = iVar50 + 8;
            uVar51 = auVar43._0_4_;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg4) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg4) >> 0x20) ^ auVar43._4_4_;
            auVar79._12_3_ = 0;
            auVar79._0_12_ = auVar77._0_12_;
            auVar79[15] = (char)(uVar56 >> 0x18);
            auVar78._14_2_ = auVar79._14_2_;
            auVar78[12] = 0;
            auVar78._0_12_ = auVar77._0_12_;
            auVar78[13] = (char)(uVar56 >> 0x10);
            auVar77._13_3_ = auVar78._13_3_;
            auVar77[12] = 0;
            auVar76._12_4_ = auVar77._12_4_;
            auVar76._0_11_ = SUB1211(auVar77._0_12_, 0);
            auVar76[11] = (char)(uVar56 >> 8);
            auVar75._11_5_ = auVar76._11_5_;
            auVar75._0_10_ = SUB1210(auVar77._0_12_, 0);
            auVar75[10] = 0;
            auVar74._10_6_ = auVar75._10_6_;
            auVar74._0_9_ = SUB129(auVar77._0_12_, 0);
            auVar74[9] = (char)uVar56;
            auVar81._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar74._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar81[0] = (char)(uVar54 >> 0x10);
            auVar81._11_5_ = 0;
            auVar35._1_12_ = SUB1612(auVar81 << 0x28, 4);
            auVar35[0] = (char)(uVar54 >> 8);
            auVar35[13] = 0;
            auVar40._1_14_ = auVar35 << 8;
            auVar40[0] = (char)uVar54;
            auVar40[15] = 0;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg3) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg3) >> 0x20) ^ auVar43._4_4_;
            auVar81 = pmulhw(auVar40 << 8, auVar41);
            auVar89._12_3_ = 0;
            auVar89._0_12_ = auVar87._0_12_;
            auVar89[15] = (char)(uVar56 >> 0x18);
            auVar88._14_2_ = auVar89._14_2_;
            auVar88[12] = 0;
            auVar88._0_12_ = auVar87._0_12_;
            auVar88[13] = (char)(uVar56 >> 0x10);
            auVar87._13_3_ = auVar88._13_3_;
            auVar87[12] = 0;
            auVar86._12_4_ = auVar87._12_4_;
            auVar86._0_11_ = SUB1211(auVar87._0_12_, 0);
            auVar86[11] = (char)(uVar56 >> 8);
            auVar85._11_5_ = auVar86._11_5_;
            auVar85._0_10_ = SUB1210(auVar87._0_12_, 0);
            auVar85[10] = 0;
            auVar84._10_6_ = auVar85._10_6_;
            auVar84._0_9_ = SUB129(auVar87._0_12_, 0);
            auVar84[9] = (char)uVar56;
            auVar80._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar84._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar80[0] = (char)(uVar54 >> 0x10);
            auVar80._11_5_ = 0;
            auVar36._1_12_ = SUB1612(auVar80 << 0x28, 4);
            auVar36[0] = (char)(uVar54 >> 8);
            auVar36[13] = 0;
            auVar83._1_14_ = auVar36 << 8;
            auVar83[0] = (char)uVar54;
            auVar83[15] = 0;
            uVar2 = *(undefined8 *)(iVar46 + arg2);
            iVar1 = iVar50 + 0xf;
            auVar65._0_14_ = auVar43._0_14_;
            auVar65[14] = auVar43[7];
            auVar65[15] = (char)((uint64_t)uVar2 >> 0x38);
            auVar64._14_2_ = auVar65._14_2_;
            auVar64._0_13_ = auVar43._0_13_;
            auVar64[13] = (char)((uint64_t)uVar2 >> 0x30);
            auVar63._13_3_ = auVar64._13_3_;
            auVar63._0_12_ = auVar43._0_12_;
            auVar63[12] = auVar43[6];
            auVar62._12_4_ = auVar63._12_4_;
            auVar62._0_11_ = auVar43._0_11_;
            auVar62[11] = (char)((uint64_t)uVar2 >> 0x28);
            auVar61._11_5_ = auVar62._11_5_;
            auVar61._0_10_ = auVar43._0_10_;
            auVar61[10] = auVar43[5];
            auVar60._10_6_ = auVar61._10_6_;
            auVar60._0_9_ = auVar43._0_9_;
            auVar60[9] = (char)((uint64_t)uVar2 >> 0x20);
            auVar59._9_7_ = auVar60._9_7_;
            auVar59._0_8_ = auVar43._0_8_;
            auVar59[8] = auVar43[4];
            Var28 = CONCAT91(CONCAT81(auVar59._8_8_, (char)((uint64_t)uVar2 >> 0x18)), auVar43[3]);
            auVar58._6_10_ = Var28;
            auVar58[5] = (char)((uint64_t)uVar2 >> 0x10);
            auVar58[4] = auVar43[2];
            auVar58._0_4_ = uVar51;
            auVar27._2_12_ = auVar58._4_12_;
            auVar27[1] = (char)((uint64_t)uVar2 >> 8);
            auVar27[0] = auVar43[1];
            uVar57 = CONCAT11((char)uVar2, auVar43[0]) >> 4;
            uVar67 = auVar27._0_2_ >> 4;
            uVar68 = auVar58._4_2_ >> 4;
            uVar69 = (uint16_t)Var28 >> 4;
            uVar70 = auVar59._8_2_ >> 4;
            uVar71 = auVar61._10_2_ >> 4;
            uVar72 = auVar63._12_2_ >> 4;
            uVar73 = auVar64._14_2_ >> 4;
            auVar82._0_2_ = auVar81._0_2_ + uVar57;
            auVar82._2_2_ = auVar81._2_2_ + uVar67;
            auVar82._4_2_ = auVar81._4_2_ + uVar68;
            auVar82._6_2_ = auVar81._6_2_ + uVar69;
            auVar82._8_2_ = auVar81._8_2_ + uVar70;
            auVar82._10_2_ = auVar81._10_2_ + uVar71;
            auVar82._12_2_ = auVar81._12_2_ + uVar72;
            auVar82._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = pmulhw(auVar83 << 8, auVar42);
            auVar90 = pmulhw(auVar83 << 8, auVar45);
            auVar83 = psraw(auVar82, 4);
            auVar80 = pmulhw(auVar40 << 8, auVar44);
            auVar55._0_2_ = auVar81._0_2_ + uVar57;
            auVar55._2_2_ = auVar81._2_2_ + uVar67;
            auVar55._4_2_ = auVar81._4_2_ + uVar68;
            auVar55._6_2_ = auVar81._6_2_ + uVar69;
            auVar55._8_2_ = auVar81._8_2_ + uVar70;
            auVar55._10_2_ = auVar81._10_2_ + uVar71;
            auVar55._12_2_ = auVar81._12_2_ + uVar72;
            auVar55._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = psraw(auVar55, 4);
            iVar4 = auVar83._0_2_;
            iVar5 = auVar83._2_2_;
            iVar7 = auVar83._4_2_;
            iVar9 = auVar83._6_2_;
            iVar11 = auVar83._8_2_;
            iVar13 = auVar83._10_2_;
            iVar15 = auVar83._12_2_;
            iVar17 = auVar83._14_2_;
            cVar3 = (0 < iVar17) * (iVar17 < 0xff) * auVar83[14] - (0xff < iVar17);
            iVar19 = auVar81._0_2_;
            iVar20 = auVar81._2_2_;
            iVar21 = auVar81._4_2_;
            iVar22 = auVar81._6_2_;
            iVar23 = auVar81._8_2_;
            iVar24 = auVar81._10_2_;
            iVar25 = auVar81._12_2_;
            iVar26 = auVar81._14_2_;
            auVar91._0_2_ = auVar90._0_2_ + uVar57 + auVar80._0_2_;
            auVar91._2_2_ = auVar90._2_2_ + uVar67 + auVar80._2_2_;
            auVar91._4_2_ = auVar90._4_2_ + uVar68 + auVar80._4_2_;
            auVar91._6_2_ = auVar90._6_2_ + uVar69 + auVar80._6_2_;
            auVar91._8_2_ = auVar90._8_2_ + uVar70 + auVar80._8_2_;
            auVar91._10_2_ = auVar90._10_2_ + uVar71 + auVar80._10_2_;
            auVar91._12_2_ = auVar90._12_2_ + uVar72 + auVar80._12_2_;
            auVar91._14_2_ = auVar90._14_2_ + uVar73 + auVar80._14_2_;
            auVar80 = psraw(auVar91, 4);
            iVar17 = auVar80._0_2_;
            iVar6 = auVar80._2_2_;
            iVar8 = auVar80._4_2_;
            iVar10 = auVar80._6_2_;
            iVar12 = auVar80._8_2_;
            iVar14 = auVar80._10_2_;
            iVar16 = auVar80._12_2_;
            iVar18 = auVar80._14_2_;
            uVar39 = CONCAT11((0 < iVar18) * (iVar18 < 0xff) * auVar80[14] - (0xff < iVar18), cVar3);
            uVar38 = CONCAT31(CONCAT21(uVar39, (0 < iVar16) * (iVar16 < 0xff) * auVar80[12] - (0xff < iVar16)), 
                              (0 < iVar15) * (iVar15 < 0xff) * auVar83[12] - (0xff < iVar15));
            Var37 = CONCAT51(CONCAT41(uVar38, (0 < iVar14) * (iVar14 < 0xff) * auVar80[10] - (0xff < iVar14)), 
                             (0 < iVar13) * (iVar13 < 0xff) * auVar83[10] - (0xff < iVar13));
            Var31 = CONCAT72(CONCAT61(Var37, (0 < iVar12) * (iVar12 < 0xff) * auVar80[8] - (0xff < iVar12)), 
                             CONCAT11((0 < iVar11) * (iVar11 < 0xff) * auVar83[8] - (0xff < iVar11), cVar3));
            Var28 = CONCAT91(CONCAT81((int64_t)((unkuint9)Var31 >> 8), 
                                      (0 < iVar10) * (iVar10 < 0xff) * auVar80[6] - (0xff < iVar10)), 
                             (0 < iVar9) * (iVar9 < 0xff) * auVar83[6] - (0xff < iVar9));
            auVar30._2_10_ = Var28;
            auVar30[1] = (0 < iVar8) * (iVar8 < 0xff) * auVar80[4] - (0xff < iVar8);
            auVar30[0] = (0 < iVar7) * (iVar7 < 0xff) * auVar83[4] - (0xff < iVar7);
            auVar29._2_12_ = auVar30;
            auVar29[1] = (0 < iVar6) * (iVar6 < 0xff) * auVar80[2] - (0xff < iVar6);
            auVar29[0] = (0 < iVar5) * (iVar5 < 0xff) * auVar83[2] - (0xff < iVar5);
            auVar66._0_2_ =
                 CONCAT11((0 < iVar17) * (iVar17 < 0xff) * auVar80[0] - (0xff < iVar17), 
                          (0 < iVar4) * (iVar4 < 0xff) * auVar83[0] - (0xff < iVar4));
            auVar66._2_14_ = auVar29;
            auVar32._12_2_ = (int16_t)Var28;
            auVar32._0_12_ = auVar66._0_12_;
            auVar32[14] = (0 < iVar22) * (iVar22 < 0xff) * auVar81[6] - (0xff < iVar22);
            auVar33[10] = (0 < iVar21) * (iVar21 < 0xff) * auVar81[4] - (0xff < iVar21);
            auVar33._0_10_ = auVar66._0_10_;
            auVar33[11] = 0;
            auVar33._12_3_ = auVar32._12_3_;
            auVar34._8_2_ = auVar30._0_2_;
            auVar34._0_8_ = auVar66._0_8_;
            auVar34._10_5_ = auVar33._10_5_;
            auVar90[7] = 0;
            auVar90[6] = (0 < iVar20) * (iVar20 < 0xff) * auVar81[2] - (0xff < iVar20);
            auVar90._8_7_ = auVar34._8_7_;
            auVar90._4_2_ = auVar29._0_2_;
            auVar90[2] = (0 < iVar19) * (iVar19 < 0xff) * auVar81[0] - (0xff < iVar19);
            auVar90._0_2_ = auVar66._0_2_;
            auVar90[3] = 0;
            auVar90[15] = 0;
            *(undefined (*) [16])arg1 = auVar90;
            *(int16_t *)*(undefined (*) [16])(arg1 + 0x10) = (int16_t)((unkuint9)Var31 >> 8);
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 2) =
                 (uint16_t)(uint8_t)((0 < iVar23) * (iVar23 < 0xff) * auVar81[8] - (0xff < iVar23));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 4) = (int16_t)Var37;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 6) =
                 (uint16_t)(uint8_t)((0 < iVar24) * (iVar24 < 0xff) * auVar81[10] - (0xff < iVar24));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 8) = (int16_t)uVar38;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 10) =
                 (uint16_t)(uint8_t)((0 < iVar25) * (iVar25 < 0xff) * auVar81[12] - (0xff < iVar25));
            *(undefined2 *)(*(undefined (*) [16])(arg1 + 0x10) + 0xc) = uVar39;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 0xe) =
                 (uint16_t)(uint8_t)((0 < iVar26) * (iVar26 < 0xff) * auVar81[14] - (0xff < iVar26));
            arg1 = arg1 + 0x20;
            iVar50 = iVar47;
        } while (iVar1 < (int32_t)arg_28h);
    }
    for (; iVar47 < (int32_t)arg_28h; iVar47 = iVar47 + 1) {
        iVar46 = (int64_t)iVar47;
        iVar50 = (uint32_t)*(uint8_t *)(iVar46 + arg2) * 0x100000 + 0x80000;
        uVar52 = (int32_t)((*(uint8_t *)(iVar46 + arg4) - 0x80) * 0x166f00 + iVar50) >> 0x14;
        uVar56 = (0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg3)) * 0x58200 & 0xffff0000;
        uVar51 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg4)) * 0xb6d00 + iVar50 + uVar56) >> 0x14;
        uVar54 = (int32_t)((*(uint8_t *)(iVar46 + arg3) - 0x80) * 0x1c5a00 + iVar50) >> 0x14;
        if (uVar52 < 0x100) {
            uVar48 = (undefined)uVar52;
        } else {
            uVar49 = 0xff;
            if ((int32_t)uVar52 < 0) {
                uVar49 = uVar56;
            }
            uVar48 = (undefined)uVar49;
        }
        uVar52 = uVar51;
        if ((0xff < uVar51) && (uVar52 = 0xff, (int32_t)uVar51 < 0)) {
            uVar52 = uVar56;
        }
        if ((0xff < uVar54) && (bVar53 = (int32_t)uVar54 < 0, uVar54 = 0xff, bVar53)) {
            uVar54 = 0;
        }
        *(undefined *)arg1 = uVar48;
        ((undefined *)arg1)[1] = (char)uVar52;
        ((undefined *)arg1)[2] = (char)uVar54;
        ((undefined *)arg1)[3] = 0xff;
        arg1 = (int64_t)((undefined *)arg1 + (int32_t)arg_30h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e55d
// Address: 0x18006e55d
// Size: 236 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18006e400(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_98h)
{
    int32_t iVar1;
    undefined8 uVar2;
    char cVar3;
    int16_t iVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int16_t iVar19;
    int16_t iVar20;
    int16_t iVar21;
    int16_t iVar22;
    int16_t iVar23;
    int16_t iVar24;
    int16_t iVar25;
    int16_t iVar26;
    undefined auVar27 [14];
    unkbyte10 Var28;
    undefined auVar29 [14];
    undefined auVar30 [12];
    unkbyte9 Var31;
    undefined auVar32 [15];
    undefined auVar33 [15];
    undefined auVar34 [15];
    undefined auVar35 [14];
    undefined auVar36 [14];
    unkbyte6 Var37;
    undefined4 uVar38;
    undefined2 uVar39;
    undefined auVar40 [16];
    undefined auVar41 [16];
    undefined auVar42 [16];
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    int64_t iVar46;
    int32_t iVar47;
    undefined uVar48;
    int32_t iVar50;
    uint32_t uVar51;
    uint32_t uVar52;
    bool bVar53;
    uint32_t uVar54;
    uint32_t uVar56;
    undefined auVar55 [16];
    uint16_t uVar57;
    uint16_t uVar67;
    uint16_t uVar68;
    uint16_t uVar69;
    uint16_t uVar70;
    uint16_t uVar71;
    uint16_t uVar72;
    undefined auVar58 [16];
    uint16_t uVar73;
    undefined auVar66 [16];
    undefined auVar74 [16];
    undefined auVar80 [16];
    undefined auVar81 [16];
    undefined auVar82 [16];
    undefined auVar83 [16];
    undefined auVar84 [16];
    undefined auVar90 [16];
    undefined auVar91 [16];
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    uint32_t uVar49;
    undefined auVar59 [16];
    undefined auVar60 [16];
    undefined auVar61 [16];
    undefined auVar62 [16];
    undefined auVar63 [16];
    undefined auVar64 [16];
    undefined auVar65 [16];
    undefined auVar75 [16];
    undefined auVar76 [16];
    undefined auVar77 [16];
    undefined auVar78 [16];
    undefined auVar79 [16];
    undefined auVar85 [16];
    undefined auVar86 [16];
    undefined auVar87 [16];
    undefined auVar88 [16];
    undefined auVar89 [16];
    
    auVar45 = *(undefined (*) [16])0x180646cc0;
    auVar44 = *(undefined (*) [16])0x180646ca0;
    auVar43 = *(undefined (*) [16])0x180646c50;
    auVar42 = *(undefined (*) [16])0x180646b60;
    auVar41 = *(undefined (*) [16])0x180646b50;
    iVar50 = 0;
    iVar47 = iVar50;
    if (((int32_t)arg_30h == 4) && (7 < (int32_t)arg_28h)) {
        do {
            auVar87._0_12_ = ZEXT812(0);
            iVar46 = (int64_t)iVar50;
            auVar77._0_12_ = ZEXT812(0);
            iVar47 = iVar50 + 8;
            uVar51 = auVar43._0_4_;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg4) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg4) >> 0x20) ^ auVar43._4_4_;
            auVar79._12_3_ = 0;
            auVar79._0_12_ = auVar77._0_12_;
            auVar79[15] = (char)(uVar56 >> 0x18);
            auVar78._14_2_ = auVar79._14_2_;
            auVar78[12] = 0;
            auVar78._0_12_ = auVar77._0_12_;
            auVar78[13] = (char)(uVar56 >> 0x10);
            auVar77._13_3_ = auVar78._13_3_;
            auVar77[12] = 0;
            auVar76._12_4_ = auVar77._12_4_;
            auVar76._0_11_ = SUB1211(auVar77._0_12_, 0);
            auVar76[11] = (char)(uVar56 >> 8);
            auVar75._11_5_ = auVar76._11_5_;
            auVar75._0_10_ = SUB1210(auVar77._0_12_, 0);
            auVar75[10] = 0;
            auVar74._10_6_ = auVar75._10_6_;
            auVar74._0_9_ = SUB129(auVar77._0_12_, 0);
            auVar74[9] = (char)uVar56;
            auVar81._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar74._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar81[0] = (char)(uVar54 >> 0x10);
            auVar81._11_5_ = 0;
            auVar35._1_12_ = SUB1612(auVar81 << 0x28, 4);
            auVar35[0] = (char)(uVar54 >> 8);
            auVar35[13] = 0;
            auVar40._1_14_ = auVar35 << 8;
            auVar40[0] = (char)uVar54;
            auVar40[15] = 0;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg3) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg3) >> 0x20) ^ auVar43._4_4_;
            auVar81 = pmulhw(auVar40 << 8, auVar41);
            auVar89._12_3_ = 0;
            auVar89._0_12_ = auVar87._0_12_;
            auVar89[15] = (char)(uVar56 >> 0x18);
            auVar88._14_2_ = auVar89._14_2_;
            auVar88[12] = 0;
            auVar88._0_12_ = auVar87._0_12_;
            auVar88[13] = (char)(uVar56 >> 0x10);
            auVar87._13_3_ = auVar88._13_3_;
            auVar87[12] = 0;
            auVar86._12_4_ = auVar87._12_4_;
            auVar86._0_11_ = SUB1211(auVar87._0_12_, 0);
            auVar86[11] = (char)(uVar56 >> 8);
            auVar85._11_5_ = auVar86._11_5_;
            auVar85._0_10_ = SUB1210(auVar87._0_12_, 0);
            auVar85[10] = 0;
            auVar84._10_6_ = auVar85._10_6_;
            auVar84._0_9_ = SUB129(auVar87._0_12_, 0);
            auVar84[9] = (char)uVar56;
            auVar80._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar84._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar80[0] = (char)(uVar54 >> 0x10);
            auVar80._11_5_ = 0;
            auVar36._1_12_ = SUB1612(auVar80 << 0x28, 4);
            auVar36[0] = (char)(uVar54 >> 8);
            auVar36[13] = 0;
            auVar83._1_14_ = auVar36 << 8;
            auVar83[0] = (char)uVar54;
            auVar83[15] = 0;
            uVar2 = *(undefined8 *)(iVar46 + arg2);
            iVar1 = iVar50 + 0xf;
            auVar65._0_14_ = auVar43._0_14_;
            auVar65[14] = auVar43[7];
            auVar65[15] = (char)((uint64_t)uVar2 >> 0x38);
            auVar64._14_2_ = auVar65._14_2_;
            auVar64._0_13_ = auVar43._0_13_;
            auVar64[13] = (char)((uint64_t)uVar2 >> 0x30);
            auVar63._13_3_ = auVar64._13_3_;
            auVar63._0_12_ = auVar43._0_12_;
            auVar63[12] = auVar43[6];
            auVar62._12_4_ = auVar63._12_4_;
            auVar62._0_11_ = auVar43._0_11_;
            auVar62[11] = (char)((uint64_t)uVar2 >> 0x28);
            auVar61._11_5_ = auVar62._11_5_;
            auVar61._0_10_ = auVar43._0_10_;
            auVar61[10] = auVar43[5];
            auVar60._10_6_ = auVar61._10_6_;
            auVar60._0_9_ = auVar43._0_9_;
            auVar60[9] = (char)((uint64_t)uVar2 >> 0x20);
            auVar59._9_7_ = auVar60._9_7_;
            auVar59._0_8_ = auVar43._0_8_;
            auVar59[8] = auVar43[4];
            Var28 = CONCAT91(CONCAT81(auVar59._8_8_, (char)((uint64_t)uVar2 >> 0x18)), auVar43[3]);
            auVar58._6_10_ = Var28;
            auVar58[5] = (char)((uint64_t)uVar2 >> 0x10);
            auVar58[4] = auVar43[2];
            auVar58._0_4_ = uVar51;
            auVar27._2_12_ = auVar58._4_12_;
            auVar27[1] = (char)((uint64_t)uVar2 >> 8);
            auVar27[0] = auVar43[1];
            uVar57 = CONCAT11((char)uVar2, auVar43[0]) >> 4;
            uVar67 = auVar27._0_2_ >> 4;
            uVar68 = auVar58._4_2_ >> 4;
            uVar69 = (uint16_t)Var28 >> 4;
            uVar70 = auVar59._8_2_ >> 4;
            uVar71 = auVar61._10_2_ >> 4;
            uVar72 = auVar63._12_2_ >> 4;
            uVar73 = auVar64._14_2_ >> 4;
            auVar82._0_2_ = auVar81._0_2_ + uVar57;
            auVar82._2_2_ = auVar81._2_2_ + uVar67;
            auVar82._4_2_ = auVar81._4_2_ + uVar68;
            auVar82._6_2_ = auVar81._6_2_ + uVar69;
            auVar82._8_2_ = auVar81._8_2_ + uVar70;
            auVar82._10_2_ = auVar81._10_2_ + uVar71;
            auVar82._12_2_ = auVar81._12_2_ + uVar72;
            auVar82._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = pmulhw(auVar83 << 8, auVar42);
            auVar90 = pmulhw(auVar83 << 8, auVar45);
            auVar83 = psraw(auVar82, 4);
            auVar80 = pmulhw(auVar40 << 8, auVar44);
            auVar55._0_2_ = auVar81._0_2_ + uVar57;
            auVar55._2_2_ = auVar81._2_2_ + uVar67;
            auVar55._4_2_ = auVar81._4_2_ + uVar68;
            auVar55._6_2_ = auVar81._6_2_ + uVar69;
            auVar55._8_2_ = auVar81._8_2_ + uVar70;
            auVar55._10_2_ = auVar81._10_2_ + uVar71;
            auVar55._12_2_ = auVar81._12_2_ + uVar72;
            auVar55._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = psraw(auVar55, 4);
            iVar4 = auVar83._0_2_;
            iVar5 = auVar83._2_2_;
            iVar7 = auVar83._4_2_;
            iVar9 = auVar83._6_2_;
            iVar11 = auVar83._8_2_;
            iVar13 = auVar83._10_2_;
            iVar15 = auVar83._12_2_;
            iVar17 = auVar83._14_2_;
            cVar3 = (0 < iVar17) * (iVar17 < 0xff) * auVar83[14] - (0xff < iVar17);
            iVar19 = auVar81._0_2_;
            iVar20 = auVar81._2_2_;
            iVar21 = auVar81._4_2_;
            iVar22 = auVar81._6_2_;
            iVar23 = auVar81._8_2_;
            iVar24 = auVar81._10_2_;
            iVar25 = auVar81._12_2_;
            iVar26 = auVar81._14_2_;
            auVar91._0_2_ = auVar90._0_2_ + uVar57 + auVar80._0_2_;
            auVar91._2_2_ = auVar90._2_2_ + uVar67 + auVar80._2_2_;
            auVar91._4_2_ = auVar90._4_2_ + uVar68 + auVar80._4_2_;
            auVar91._6_2_ = auVar90._6_2_ + uVar69 + auVar80._6_2_;
            auVar91._8_2_ = auVar90._8_2_ + uVar70 + auVar80._8_2_;
            auVar91._10_2_ = auVar90._10_2_ + uVar71 + auVar80._10_2_;
            auVar91._12_2_ = auVar90._12_2_ + uVar72 + auVar80._12_2_;
            auVar91._14_2_ = auVar90._14_2_ + uVar73 + auVar80._14_2_;
            auVar80 = psraw(auVar91, 4);
            iVar17 = auVar80._0_2_;
            iVar6 = auVar80._2_2_;
            iVar8 = auVar80._4_2_;
            iVar10 = auVar80._6_2_;
            iVar12 = auVar80._8_2_;
            iVar14 = auVar80._10_2_;
            iVar16 = auVar80._12_2_;
            iVar18 = auVar80._14_2_;
            uVar39 = CONCAT11((0 < iVar18) * (iVar18 < 0xff) * auVar80[14] - (0xff < iVar18), cVar3);
            uVar38 = CONCAT31(CONCAT21(uVar39, (0 < iVar16) * (iVar16 < 0xff) * auVar80[12] - (0xff < iVar16)), 
                              (0 < iVar15) * (iVar15 < 0xff) * auVar83[12] - (0xff < iVar15));
            Var37 = CONCAT51(CONCAT41(uVar38, (0 < iVar14) * (iVar14 < 0xff) * auVar80[10] - (0xff < iVar14)), 
                             (0 < iVar13) * (iVar13 < 0xff) * auVar83[10] - (0xff < iVar13));
            Var31 = CONCAT72(CONCAT61(Var37, (0 < iVar12) * (iVar12 < 0xff) * auVar80[8] - (0xff < iVar12)), 
                             CONCAT11((0 < iVar11) * (iVar11 < 0xff) * auVar83[8] - (0xff < iVar11), cVar3));
            Var28 = CONCAT91(CONCAT81((int64_t)((unkuint9)Var31 >> 8), 
                                      (0 < iVar10) * (iVar10 < 0xff) * auVar80[6] - (0xff < iVar10)), 
                             (0 < iVar9) * (iVar9 < 0xff) * auVar83[6] - (0xff < iVar9));
            auVar30._2_10_ = Var28;
            auVar30[1] = (0 < iVar8) * (iVar8 < 0xff) * auVar80[4] - (0xff < iVar8);
            auVar30[0] = (0 < iVar7) * (iVar7 < 0xff) * auVar83[4] - (0xff < iVar7);
            auVar29._2_12_ = auVar30;
            auVar29[1] = (0 < iVar6) * (iVar6 < 0xff) * auVar80[2] - (0xff < iVar6);
            auVar29[0] = (0 < iVar5) * (iVar5 < 0xff) * auVar83[2] - (0xff < iVar5);
            auVar66._0_2_ =
                 CONCAT11((0 < iVar17) * (iVar17 < 0xff) * auVar80[0] - (0xff < iVar17), 
                          (0 < iVar4) * (iVar4 < 0xff) * auVar83[0] - (0xff < iVar4));
            auVar66._2_14_ = auVar29;
            auVar32._12_2_ = (int16_t)Var28;
            auVar32._0_12_ = auVar66._0_12_;
            auVar32[14] = (0 < iVar22) * (iVar22 < 0xff) * auVar81[6] - (0xff < iVar22);
            auVar33[10] = (0 < iVar21) * (iVar21 < 0xff) * auVar81[4] - (0xff < iVar21);
            auVar33._0_10_ = auVar66._0_10_;
            auVar33[11] = 0;
            auVar33._12_3_ = auVar32._12_3_;
            auVar34._8_2_ = auVar30._0_2_;
            auVar34._0_8_ = auVar66._0_8_;
            auVar34._10_5_ = auVar33._10_5_;
            auVar90[7] = 0;
            auVar90[6] = (0 < iVar20) * (iVar20 < 0xff) * auVar81[2] - (0xff < iVar20);
            auVar90._8_7_ = auVar34._8_7_;
            auVar90._4_2_ = auVar29._0_2_;
            auVar90[2] = (0 < iVar19) * (iVar19 < 0xff) * auVar81[0] - (0xff < iVar19);
            auVar90._0_2_ = auVar66._0_2_;
            auVar90[3] = 0;
            auVar90[15] = 0;
            *(undefined (*) [16])arg1 = auVar90;
            *(int16_t *)*(undefined (*) [16])(arg1 + 0x10) = (int16_t)((unkuint9)Var31 >> 8);
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 2) =
                 (uint16_t)(uint8_t)((0 < iVar23) * (iVar23 < 0xff) * auVar81[8] - (0xff < iVar23));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 4) = (int16_t)Var37;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 6) =
                 (uint16_t)(uint8_t)((0 < iVar24) * (iVar24 < 0xff) * auVar81[10] - (0xff < iVar24));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 8) = (int16_t)uVar38;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 10) =
                 (uint16_t)(uint8_t)((0 < iVar25) * (iVar25 < 0xff) * auVar81[12] - (0xff < iVar25));
            *(undefined2 *)(*(undefined (*) [16])(arg1 + 0x10) + 0xc) = uVar39;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 0xe) =
                 (uint16_t)(uint8_t)((0 < iVar26) * (iVar26 < 0xff) * auVar81[14] - (0xff < iVar26));
            arg1 = arg1 + 0x20;
            iVar50 = iVar47;
        } while (iVar1 < (int32_t)arg_28h);
    }
    for (; iVar47 < (int32_t)arg_28h; iVar47 = iVar47 + 1) {
        iVar46 = (int64_t)iVar47;
        iVar50 = (uint32_t)*(uint8_t *)(iVar46 + arg2) * 0x100000 + 0x80000;
        uVar52 = (int32_t)((*(uint8_t *)(iVar46 + arg4) - 0x80) * 0x166f00 + iVar50) >> 0x14;
        uVar56 = (0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg3)) * 0x58200 & 0xffff0000;
        uVar51 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg4)) * 0xb6d00 + iVar50 + uVar56) >> 0x14;
        uVar54 = (int32_t)((*(uint8_t *)(iVar46 + arg3) - 0x80) * 0x1c5a00 + iVar50) >> 0x14;
        if (uVar52 < 0x100) {
            uVar48 = (undefined)uVar52;
        } else {
            uVar49 = 0xff;
            if ((int32_t)uVar52 < 0) {
                uVar49 = uVar56;
            }
            uVar48 = (undefined)uVar49;
        }
        uVar52 = uVar51;
        if ((0xff < uVar51) && (uVar52 = 0xff, (int32_t)uVar51 < 0)) {
            uVar52 = uVar56;
        }
        if ((0xff < uVar54) && (bVar53 = (int32_t)uVar54 < 0, uVar54 = 0xff, bVar53)) {
            uVar54 = 0;
        }
        *(undefined *)arg1 = uVar48;
        ((undefined *)arg1)[1] = (char)uVar52;
        ((undefined *)arg1)[2] = (char)uVar54;
        ((undefined *)arg1)[3] = 0xff;
        arg1 = (int64_t)((undefined *)arg1 + (int32_t)arg_30h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e649
// Address: 0x18006e649
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18006e400(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_98h)
{
    int32_t iVar1;
    undefined8 uVar2;
    char cVar3;
    int16_t iVar4;
    int16_t iVar5;
    int16_t iVar6;
    int16_t iVar7;
    int16_t iVar8;
    int16_t iVar9;
    int16_t iVar10;
    int16_t iVar11;
    int16_t iVar12;
    int16_t iVar13;
    int16_t iVar14;
    int16_t iVar15;
    int16_t iVar16;
    int16_t iVar17;
    int16_t iVar18;
    int16_t iVar19;
    int16_t iVar20;
    int16_t iVar21;
    int16_t iVar22;
    int16_t iVar23;
    int16_t iVar24;
    int16_t iVar25;
    int16_t iVar26;
    undefined auVar27 [14];
    unkbyte10 Var28;
    undefined auVar29 [14];
    undefined auVar30 [12];
    unkbyte9 Var31;
    undefined auVar32 [15];
    undefined auVar33 [15];
    undefined auVar34 [15];
    undefined auVar35 [14];
    undefined auVar36 [14];
    unkbyte6 Var37;
    undefined4 uVar38;
    undefined2 uVar39;
    undefined auVar40 [16];
    undefined auVar41 [16];
    undefined auVar42 [16];
    undefined auVar43 [16];
    undefined auVar44 [16];
    undefined auVar45 [16];
    int64_t iVar46;
    int32_t iVar47;
    undefined uVar48;
    int32_t iVar50;
    uint32_t uVar51;
    uint32_t uVar52;
    bool bVar53;
    uint32_t uVar54;
    uint32_t uVar56;
    undefined auVar55 [16];
    uint16_t uVar57;
    uint16_t uVar67;
    uint16_t uVar68;
    uint16_t uVar69;
    uint16_t uVar70;
    uint16_t uVar71;
    uint16_t uVar72;
    undefined auVar58 [16];
    uint16_t uVar73;
    undefined auVar66 [16];
    undefined auVar74 [16];
    undefined auVar80 [16];
    undefined auVar81 [16];
    undefined auVar82 [16];
    undefined auVar83 [16];
    undefined auVar84 [16];
    undefined auVar90 [16];
    undefined auVar91 [16];
    int64_t var_8h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    uint32_t uVar49;
    undefined auVar59 [16];
    undefined auVar60 [16];
    undefined auVar61 [16];
    undefined auVar62 [16];
    undefined auVar63 [16];
    undefined auVar64 [16];
    undefined auVar65 [16];
    undefined auVar75 [16];
    undefined auVar76 [16];
    undefined auVar77 [16];
    undefined auVar78 [16];
    undefined auVar79 [16];
    undefined auVar85 [16];
    undefined auVar86 [16];
    undefined auVar87 [16];
    undefined auVar88 [16];
    undefined auVar89 [16];
    
    auVar45 = *(undefined (*) [16])0x180646cc0;
    auVar44 = *(undefined (*) [16])0x180646ca0;
    auVar43 = *(undefined (*) [16])0x180646c50;
    auVar42 = *(undefined (*) [16])0x180646b60;
    auVar41 = *(undefined (*) [16])0x180646b50;
    iVar50 = 0;
    iVar47 = iVar50;
    if (((int32_t)arg_30h == 4) && (7 < (int32_t)arg_28h)) {
        do {
            auVar87._0_12_ = ZEXT812(0);
            iVar46 = (int64_t)iVar50;
            auVar77._0_12_ = ZEXT812(0);
            iVar47 = iVar50 + 8;
            uVar51 = auVar43._0_4_;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg4) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg4) >> 0x20) ^ auVar43._4_4_;
            auVar79._12_3_ = 0;
            auVar79._0_12_ = auVar77._0_12_;
            auVar79[15] = (char)(uVar56 >> 0x18);
            auVar78._14_2_ = auVar79._14_2_;
            auVar78[12] = 0;
            auVar78._0_12_ = auVar77._0_12_;
            auVar78[13] = (char)(uVar56 >> 0x10);
            auVar77._13_3_ = auVar78._13_3_;
            auVar77[12] = 0;
            auVar76._12_4_ = auVar77._12_4_;
            auVar76._0_11_ = SUB1211(auVar77._0_12_, 0);
            auVar76[11] = (char)(uVar56 >> 8);
            auVar75._11_5_ = auVar76._11_5_;
            auVar75._0_10_ = SUB1210(auVar77._0_12_, 0);
            auVar75[10] = 0;
            auVar74._10_6_ = auVar75._10_6_;
            auVar74._0_9_ = SUB129(auVar77._0_12_, 0);
            auVar74[9] = (char)uVar56;
            auVar81._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar74._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar81[0] = (char)(uVar54 >> 0x10);
            auVar81._11_5_ = 0;
            auVar35._1_12_ = SUB1612(auVar81 << 0x28, 4);
            auVar35[0] = (char)(uVar54 >> 8);
            auVar35[13] = 0;
            auVar40._1_14_ = auVar35 << 8;
            auVar40[0] = (char)uVar54;
            auVar40[15] = 0;
            uVar54 = (uint32_t)*(undefined8 *)(iVar46 + arg3) ^ uVar51;
            uVar56 = (uint32_t)((uint64_t)*(undefined8 *)(iVar46 + arg3) >> 0x20) ^ auVar43._4_4_;
            auVar81 = pmulhw(auVar40 << 8, auVar41);
            auVar89._12_3_ = 0;
            auVar89._0_12_ = auVar87._0_12_;
            auVar89[15] = (char)(uVar56 >> 0x18);
            auVar88._14_2_ = auVar89._14_2_;
            auVar88[12] = 0;
            auVar88._0_12_ = auVar87._0_12_;
            auVar88[13] = (char)(uVar56 >> 0x10);
            auVar87._13_3_ = auVar88._13_3_;
            auVar87[12] = 0;
            auVar86._12_4_ = auVar87._12_4_;
            auVar86._0_11_ = SUB1211(auVar87._0_12_, 0);
            auVar86[11] = (char)(uVar56 >> 8);
            auVar85._11_5_ = auVar86._11_5_;
            auVar85._0_10_ = SUB1210(auVar87._0_12_, 0);
            auVar85[10] = 0;
            auVar84._10_6_ = auVar85._10_6_;
            auVar84._0_9_ = SUB129(auVar87._0_12_, 0);
            auVar84[9] = (char)uVar56;
            auVar80._1_10_ = (unkuint10)CONCAT81((uint64_t)auVar84._9_7_ << 8, (char)(uVar54 >> 0x18)) << 8;
            auVar80[0] = (char)(uVar54 >> 0x10);
            auVar80._11_5_ = 0;
            auVar36._1_12_ = SUB1612(auVar80 << 0x28, 4);
            auVar36[0] = (char)(uVar54 >> 8);
            auVar36[13] = 0;
            auVar83._1_14_ = auVar36 << 8;
            auVar83[0] = (char)uVar54;
            auVar83[15] = 0;
            uVar2 = *(undefined8 *)(iVar46 + arg2);
            iVar1 = iVar50 + 0xf;
            auVar65._0_14_ = auVar43._0_14_;
            auVar65[14] = auVar43[7];
            auVar65[15] = (char)((uint64_t)uVar2 >> 0x38);
            auVar64._14_2_ = auVar65._14_2_;
            auVar64._0_13_ = auVar43._0_13_;
            auVar64[13] = (char)((uint64_t)uVar2 >> 0x30);
            auVar63._13_3_ = auVar64._13_3_;
            auVar63._0_12_ = auVar43._0_12_;
            auVar63[12] = auVar43[6];
            auVar62._12_4_ = auVar63._12_4_;
            auVar62._0_11_ = auVar43._0_11_;
            auVar62[11] = (char)((uint64_t)uVar2 >> 0x28);
            auVar61._11_5_ = auVar62._11_5_;
            auVar61._0_10_ = auVar43._0_10_;
            auVar61[10] = auVar43[5];
            auVar60._10_6_ = auVar61._10_6_;
            auVar60._0_9_ = auVar43._0_9_;
            auVar60[9] = (char)((uint64_t)uVar2 >> 0x20);
            auVar59._9_7_ = auVar60._9_7_;
            auVar59._0_8_ = auVar43._0_8_;
            auVar59[8] = auVar43[4];
            Var28 = CONCAT91(CONCAT81(auVar59._8_8_, (char)((uint64_t)uVar2 >> 0x18)), auVar43[3]);
            auVar58._6_10_ = Var28;
            auVar58[5] = (char)((uint64_t)uVar2 >> 0x10);
            auVar58[4] = auVar43[2];
            auVar58._0_4_ = uVar51;
            auVar27._2_12_ = auVar58._4_12_;
            auVar27[1] = (char)((uint64_t)uVar2 >> 8);
            auVar27[0] = auVar43[1];
            uVar57 = CONCAT11((char)uVar2, auVar43[0]) >> 4;
            uVar67 = auVar27._0_2_ >> 4;
            uVar68 = auVar58._4_2_ >> 4;
            uVar69 = (uint16_t)Var28 >> 4;
            uVar70 = auVar59._8_2_ >> 4;
            uVar71 = auVar61._10_2_ >> 4;
            uVar72 = auVar63._12_2_ >> 4;
            uVar73 = auVar64._14_2_ >> 4;
            auVar82._0_2_ = auVar81._0_2_ + uVar57;
            auVar82._2_2_ = auVar81._2_2_ + uVar67;
            auVar82._4_2_ = auVar81._4_2_ + uVar68;
            auVar82._6_2_ = auVar81._6_2_ + uVar69;
            auVar82._8_2_ = auVar81._8_2_ + uVar70;
            auVar82._10_2_ = auVar81._10_2_ + uVar71;
            auVar82._12_2_ = auVar81._12_2_ + uVar72;
            auVar82._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = pmulhw(auVar83 << 8, auVar42);
            auVar90 = pmulhw(auVar83 << 8, auVar45);
            auVar83 = psraw(auVar82, 4);
            auVar80 = pmulhw(auVar40 << 8, auVar44);
            auVar55._0_2_ = auVar81._0_2_ + uVar57;
            auVar55._2_2_ = auVar81._2_2_ + uVar67;
            auVar55._4_2_ = auVar81._4_2_ + uVar68;
            auVar55._6_2_ = auVar81._6_2_ + uVar69;
            auVar55._8_2_ = auVar81._8_2_ + uVar70;
            auVar55._10_2_ = auVar81._10_2_ + uVar71;
            auVar55._12_2_ = auVar81._12_2_ + uVar72;
            auVar55._14_2_ = auVar81._14_2_ + uVar73;
            auVar81 = psraw(auVar55, 4);
            iVar4 = auVar83._0_2_;
            iVar5 = auVar83._2_2_;
            iVar7 = auVar83._4_2_;
            iVar9 = auVar83._6_2_;
            iVar11 = auVar83._8_2_;
            iVar13 = auVar83._10_2_;
            iVar15 = auVar83._12_2_;
            iVar17 = auVar83._14_2_;
            cVar3 = (0 < iVar17) * (iVar17 < 0xff) * auVar83[14] - (0xff < iVar17);
            iVar19 = auVar81._0_2_;
            iVar20 = auVar81._2_2_;
            iVar21 = auVar81._4_2_;
            iVar22 = auVar81._6_2_;
            iVar23 = auVar81._8_2_;
            iVar24 = auVar81._10_2_;
            iVar25 = auVar81._12_2_;
            iVar26 = auVar81._14_2_;
            auVar91._0_2_ = auVar90._0_2_ + uVar57 + auVar80._0_2_;
            auVar91._2_2_ = auVar90._2_2_ + uVar67 + auVar80._2_2_;
            auVar91._4_2_ = auVar90._4_2_ + uVar68 + auVar80._4_2_;
            auVar91._6_2_ = auVar90._6_2_ + uVar69 + auVar80._6_2_;
            auVar91._8_2_ = auVar90._8_2_ + uVar70 + auVar80._8_2_;
            auVar91._10_2_ = auVar90._10_2_ + uVar71 + auVar80._10_2_;
            auVar91._12_2_ = auVar90._12_2_ + uVar72 + auVar80._12_2_;
            auVar91._14_2_ = auVar90._14_2_ + uVar73 + auVar80._14_2_;
            auVar80 = psraw(auVar91, 4);
            iVar17 = auVar80._0_2_;
            iVar6 = auVar80._2_2_;
            iVar8 = auVar80._4_2_;
            iVar10 = auVar80._6_2_;
            iVar12 = auVar80._8_2_;
            iVar14 = auVar80._10_2_;
            iVar16 = auVar80._12_2_;
            iVar18 = auVar80._14_2_;
            uVar39 = CONCAT11((0 < iVar18) * (iVar18 < 0xff) * auVar80[14] - (0xff < iVar18), cVar3);
            uVar38 = CONCAT31(CONCAT21(uVar39, (0 < iVar16) * (iVar16 < 0xff) * auVar80[12] - (0xff < iVar16)), 
                              (0 < iVar15) * (iVar15 < 0xff) * auVar83[12] - (0xff < iVar15));
            Var37 = CONCAT51(CONCAT41(uVar38, (0 < iVar14) * (iVar14 < 0xff) * auVar80[10] - (0xff < iVar14)), 
                             (0 < iVar13) * (iVar13 < 0xff) * auVar83[10] - (0xff < iVar13));
            Var31 = CONCAT72(CONCAT61(Var37, (0 < iVar12) * (iVar12 < 0xff) * auVar80[8] - (0xff < iVar12)), 
                             CONCAT11((0 < iVar11) * (iVar11 < 0xff) * auVar83[8] - (0xff < iVar11), cVar3));
            Var28 = CONCAT91(CONCAT81((int64_t)((unkuint9)Var31 >> 8), 
                                      (0 < iVar10) * (iVar10 < 0xff) * auVar80[6] - (0xff < iVar10)), 
                             (0 < iVar9) * (iVar9 < 0xff) * auVar83[6] - (0xff < iVar9));
            auVar30._2_10_ = Var28;
            auVar30[1] = (0 < iVar8) * (iVar8 < 0xff) * auVar80[4] - (0xff < iVar8);
            auVar30[0] = (0 < iVar7) * (iVar7 < 0xff) * auVar83[4] - (0xff < iVar7);
            auVar29._2_12_ = auVar30;
            auVar29[1] = (0 < iVar6) * (iVar6 < 0xff) * auVar80[2] - (0xff < iVar6);
            auVar29[0] = (0 < iVar5) * (iVar5 < 0xff) * auVar83[2] - (0xff < iVar5);
            auVar66._0_2_ =
                 CONCAT11((0 < iVar17) * (iVar17 < 0xff) * auVar80[0] - (0xff < iVar17), 
                          (0 < iVar4) * (iVar4 < 0xff) * auVar83[0] - (0xff < iVar4));
            auVar66._2_14_ = auVar29;
            auVar32._12_2_ = (int16_t)Var28;
            auVar32._0_12_ = auVar66._0_12_;
            auVar32[14] = (0 < iVar22) * (iVar22 < 0xff) * auVar81[6] - (0xff < iVar22);
            auVar33[10] = (0 < iVar21) * (iVar21 < 0xff) * auVar81[4] - (0xff < iVar21);
            auVar33._0_10_ = auVar66._0_10_;
            auVar33[11] = 0;
            auVar33._12_3_ = auVar32._12_3_;
            auVar34._8_2_ = auVar30._0_2_;
            auVar34._0_8_ = auVar66._0_8_;
            auVar34._10_5_ = auVar33._10_5_;
            auVar90[7] = 0;
            auVar90[6] = (0 < iVar20) * (iVar20 < 0xff) * auVar81[2] - (0xff < iVar20);
            auVar90._8_7_ = auVar34._8_7_;
            auVar90._4_2_ = auVar29._0_2_;
            auVar90[2] = (0 < iVar19) * (iVar19 < 0xff) * auVar81[0] - (0xff < iVar19);
            auVar90._0_2_ = auVar66._0_2_;
            auVar90[3] = 0;
            auVar90[15] = 0;
            *(undefined (*) [16])arg1 = auVar90;
            *(int16_t *)*(undefined (*) [16])(arg1 + 0x10) = (int16_t)((unkuint9)Var31 >> 8);
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 2) =
                 (uint16_t)(uint8_t)((0 < iVar23) * (iVar23 < 0xff) * auVar81[8] - (0xff < iVar23));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 4) = (int16_t)Var37;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 6) =
                 (uint16_t)(uint8_t)((0 < iVar24) * (iVar24 < 0xff) * auVar81[10] - (0xff < iVar24));
            *(int16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 8) = (int16_t)uVar38;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 10) =
                 (uint16_t)(uint8_t)((0 < iVar25) * (iVar25 < 0xff) * auVar81[12] - (0xff < iVar25));
            *(undefined2 *)(*(undefined (*) [16])(arg1 + 0x10) + 0xc) = uVar39;
            *(uint16_t *)(*(undefined (*) [16])(arg1 + 0x10) + 0xe) =
                 (uint16_t)(uint8_t)((0 < iVar26) * (iVar26 < 0xff) * auVar81[14] - (0xff < iVar26));
            arg1 = arg1 + 0x20;
            iVar50 = iVar47;
        } while (iVar1 < (int32_t)arg_28h);
    }
    for (; iVar47 < (int32_t)arg_28h; iVar47 = iVar47 + 1) {
        iVar46 = (int64_t)iVar47;
        iVar50 = (uint32_t)*(uint8_t *)(iVar46 + arg2) * 0x100000 + 0x80000;
        uVar52 = (int32_t)((*(uint8_t *)(iVar46 + arg4) - 0x80) * 0x166f00 + iVar50) >> 0x14;
        uVar56 = (0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg3)) * 0x58200 & 0xffff0000;
        uVar51 = (int32_t)((0x80 - (uint32_t)*(uint8_t *)(iVar46 + arg4)) * 0xb6d00 + iVar50 + uVar56) >> 0x14;
        uVar54 = (int32_t)((*(uint8_t *)(iVar46 + arg3) - 0x80) * 0x1c5a00 + iVar50) >> 0x14;
        if (uVar52 < 0x100) {
            uVar48 = (undefined)uVar52;
        } else {
            uVar49 = 0xff;
            if ((int32_t)uVar52 < 0) {
                uVar49 = uVar56;
            }
            uVar48 = (undefined)uVar49;
        }
        uVar52 = uVar51;
        if ((0xff < uVar51) && (uVar52 = 0xff, (int32_t)uVar51 < 0)) {
            uVar52 = uVar56;
        }
        if ((0xff < uVar54) && (bVar53 = (int32_t)uVar54 < 0, uVar54 = 0xff, bVar53)) {
            uVar54 = 0;
        }
        *(undefined *)arg1 = uVar48;
        ((undefined *)arg1)[1] = (char)uVar52;
        ((undefined *)arg1)[2] = (char)uVar54;
        ((undefined *)arg1)[3] = 0xff;
        arg1 = (int64_t)((undefined *)arg1 + (int32_t)arg_30h);
    }
    return;
}

// ============================================================
// Function: FUN_18006e660
// Address: 0x18006e660
// Size: 114 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018006e69a)

code * fcn.18006e660(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    code *pcVar2;
    
    *(undefined8 *)(arg1 + 0x4870) = 0x18006afd0;
    *(code **)(arg1 + 0x4878) = fcn.18006e2d0;
    *(code **)(arg1 + 0x4880) = fcn.18006e000;
    puVar1 = (uint32_t *)cpuid_Version_info(1);
    pcVar2 = (code *)(uint64_t)*puVar1;
    if ((puVar1[2] >> 0x1a & 1) != 0) {
        *(undefined8 *)(arg1 + 0x4870) = 0x18006b610;
        *(code **)(arg1 + 0x4878) = fcn.18006e400;
        pcVar2 = fcn.18006e0b0;
        *(code **)(arg1 + 0x4880) = fcn.18006e0b0;
    }
    return pcVar2;
}

// ============================================================
// Function: FUN_18006e6e0
// Address: 0x18006e6e0
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h

void fcn.18006e6e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    code *pcVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    undefined *puVar18;
    uint8_t *puVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    uint32_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    code *pcStack_108;
    int64_t var_100h;
    int64_t var_f8h;
    undefined var_f0h [4];
    int64_t var_ech;
    int64_t var_e4h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    *(undefined4 *)(*(int64_t *)arg1 + 8) = 0;
    var_140h = arg2;
    var_138h = arg3;
    iVar9 = fcn.18006db80(arg1);
    uVar14 = *(uint64_t *)arg1;
    uVar23 = *(uint32_t *)(uVar14 + 8);
    var_168h._0_4_ = uVar23;
    if (iVar9 == 0) {
code_r0x00018006e72e:
        fcn.18006d3b0(arg1, (uint64_t)uVar23, var_158h);
        goto code_r0x00018006ecdd;
    }
    if ((uVar23 == 3) &&
       ((*(int32_t *)(arg1 + 0x4850) == 3 || ((*(int32_t *)(arg1 + 0x484c) == 0 && (*(int32_t *)(arg1 + 0x4848) == 0))))
       )) {
        var_168h._4_4_ = 1;
    } else {
        if ((int32_t)uVar23 < 1) goto code_r0x00018006e72e;
        var_168h._4_4_ = 0;
    }
    _var_130h = ZEXT816(0);
    iVar9 = 0;
    _var_120h = ZEXT816(0);
    do {
        iVar17 = (int64_t)iVar9;
        iVar12 = func_0x00018046d050(**(int32_t **)arg1 + 3, uVar14);
        iVar22 = iVar17 * 0x60 + arg1;
        *(int64_t *)(iVar22 + 0x46e8) = iVar12;
        if (iVar12 == 0) goto code_r0x00018006ecbd;
        uVar8 = (int64_t)*(int32_t *)(arg1 + 0x4688) / (int64_t)*(int32_t *)(iVar22 + 0x46a4);
        *(undefined4 *)((int64_t)&var_e4h + iVar17 * 0x30 + 4) = 0;
        iVar10 = (int32_t)uVar8;
        *(int32_t *)(var_f0h + iVar17 * 0x30) = iVar10;
        iVar11 = *(int32_t *)(arg1 + 0x468c) / *(int32_t *)(iVar22 + 0x46a8);
        *(int32_t *)(&var_ech + iVar17 * 6) = iVar11;
        *(int32_t *)(&var_e4h + iVar17 * 6) = iVar11 >> 1;
        iVar6 = **(int32_t **)arg1;
        iVar12 = *(int64_t *)(iVar22 + 0x46d0);
        *(int64_t *)(var_f0h + (iVar17 * 0xc + -2) * 4) = iVar12;
        uVar8 = uVar8 & 0xffffffff;
        uVar7 = (uint64_t)(uint32_t)(iVar6 + -1 + iVar10);
        uVar14 = uVar7 % uVar8;
        (&var_100h)[iVar17 * 6] = iVar12;
        *(int32_t *)((int64_t)&var_ech + iVar17 * 0x30 + 4) = (int32_t)(uVar7 / uVar8);
        if (iVar10 == 1) {
            if (iVar11 == 1) {
                pcVar13 = (code *)0x18006dd80;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = fcn.18006dd90;
            }
        } else if (iVar10 == 2) {
            if (iVar11 == 1) {
                pcVar13 = fcn.18006df30;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = *(code **)(arg1 + 0x4880);
            }
        } else {
code_r0x00018006e87a:
            pcVar13 = fcn.18006e270;
        }
        iVar9 = iVar9 + 1;
        (&pcStack_108)[iVar17 * 6] = pcVar13;
    } while (iVar9 < (int32_t)uVar23);
    iVar9 = **(int32_t **)arg1;
    if ((iVar9 < 0) ||
       ((iVar9 != 0 &&
        ((uVar14 = 0x7fffffff % (int64_t)iVar9 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar9) < 4 ||
         (iVar9 * 4 < 0)))))) {
code_r0x00018006ecbd:
        puVar16 = *(uint32_t **)arg1;
    } else {
        iVar6 = (*(int32_t **)arg1)[1];
        if ((iVar6 < 0) ||
           ((iVar6 != 0 &&
            (uVar14 = 0x7fffffff % (int64_t)iVar6 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar6) < iVar9 * 4))))
        goto code_r0x00018006ecbd;
        var_158h = func_0x00018046d050((int64_t)(iVar9 * iVar6 * 4 + 1), uVar14);
        puVar16 = *(uint32_t **)arg1;
        if (var_158h != 0) {
            if (puVar16[1] != 0) {
                var_160h = 0;
                iVar12 = var_128h;
                iVar17 = var_120h;
                iVar22 = var_118h;
                do {
                    uVar20 = (uint32_t)var_168h;
                    iVar9 = 0;
                    var_148h = (uint64_t)(var_160h * *puVar16 * 4) + var_158h;
                    if (0 < (int32_t)uVar23) {
                        iVar12 = 0;
                        do {
                            var_150h = iVar12 * 0x60 + arg1;
                            iVar10 = *(int32_t *)(&var_ech + iVar12 * 6);
                            iVar6 = *(int32_t *)(&var_e4h + iVar12 * 6);
                            piVar15 = &var_100h;
                            if (iVar10 >> 1 <= iVar6) {
                                piVar15 = &var_f8h;
                            }
                            var_178h._0_4_ = *(uint32_t *)(var_f0h + iVar12 * 0x30);
                            iVar17 = (*(&pcStack_108)[iVar12 * 6])
                                               (*(undefined8 *)(var_150h + 0x46e8), piVar15[iVar12 * 6]);
                            (&var_130h)[iVar12] = iVar17;
                            iVar6 = iVar6 + 1;
                            *(int32_t *)(&var_e4h + iVar12 * 6) = iVar6;
                            if (iVar10 <= iVar6) {
                                piVar2 = (int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *piVar2 = *piVar2 + 1;
                                iVar17 = *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4);
                                iVar6 = *(int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *(undefined4 *)(&var_e4h + iVar12 * 6) = 0;
                                (&var_100h)[iVar12 * 6] = iVar17;
                                if (iVar6 < *(int32_t *)(var_150h + 0x46c0)) {
                                    *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4) =
                                         *(int32_t *)(var_150h + 0x46c4) + iVar17;
                                }
                            }
                            iVar9 = iVar9 + 1;
                            iVar12 = iVar12 + 1;
                        } while (iVar9 < (int32_t)uVar20);
                        puVar16 = *(uint32_t **)arg1;
                        iVar12 = var_128h;
                        iVar17 = var_120h;
                        iVar22 = var_118h;
                        uVar23 = (uint32_t)var_168h;
                    }
                    puVar19 = (uint8_t *)var_148h;
                    if (puVar16[2] == 3) {
                        if (var_168h._4_4_ == 0) {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                            puVar16 = *(uint32_t **)arg1;
                        } else {
                            uVar14 = 0;
                            puVar18 = (undefined *)var_148h;
                            if (*puVar16 != 0) {
                                do {
                                    *puVar18 = *(undefined *)(var_130h + uVar14);
                                    puVar18[1] = *(undefined *)(uVar14 + iVar12);
                                    puVar1 = (undefined *)(uVar14 + iVar17);
                                    uVar20 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar20;
                                    puVar18[2] = *puVar1;
                                    puVar18[3] = 0xff;
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar20 < *puVar16);
                            }
                        }
                    } else if (puVar16[2] == 4) {
                        if (*(int32_t *)(arg1 + 0x484c) == 0) {
                            if (*puVar16 != 0) {
                                uVar14 = 0;
                                puVar18 = (undefined *)var_148h;
                                do {
                                    uVar3 = *(uint8_t *)(iVar22 + uVar14);
                                    uVar20 = (uint32_t)*(uint8_t *)(var_130h + uVar14) * (uint32_t)uVar3 + 0x80;
                                    *puVar18 = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar20 = (uint32_t)*(uint8_t *)(iVar12 + uVar14) * (uint32_t)uVar3 + 0x80;
                                    puVar18[1] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar4 = *(uint8_t *)(iVar17 + uVar14);
                                    uVar21 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar21;
                                    puVar18[3] = 0xff;
                                    uVar20 = (uint32_t)uVar4 * (uint32_t)uVar3 + 0x80;
                                    puVar18[2] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar21 < *puVar16);
                            }
                        } else {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            if (*(int32_t *)(arg1 + 0x484c) == 2) {
                                (**(code **)(arg1 + 0x4878))();
                                puVar16 = *(uint32_t **)arg1;
                                if (*puVar16 != 0) {
                                    uVar20 = 0;
                                    do {
                                        uVar14 = (uint64_t)uVar20;
                                        uVar20 = uVar20 + 1;
                                        uVar3 = *(uint8_t *)(uVar14 + iVar22);
                                        uVar21 = (uint32_t)(uint8_t)~*puVar19 * (uint32_t)uVar3 + 0x80;
                                        *puVar19 = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[1] * (uint32_t)uVar3 + 0x80;
                                        puVar19[1] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[2] * (uint32_t)uVar3 + 0x80;
                                        puVar19[2] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        puVar16 = *(uint32_t **)arg1;
                                        puVar19 = puVar19 + 4;
                                    } while (uVar20 < *puVar16);
                                }
                            } else {
                                (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                                puVar16 = *(uint32_t **)arg1;
                            }
                        }
                    } else {
                        uVar14 = 0;
                        puVar18 = (undefined *)var_148h;
                        if (*puVar16 != 0) {
                            do {
                                uVar5 = *(undefined *)(uVar14 + var_130h);
                                uVar20 = (int32_t)uVar14 + 1;
                                uVar14 = (uint64_t)uVar20;
                                puVar18[2] = uVar5;
                                puVar18[1] = uVar5;
                                *puVar18 = uVar5;
                                puVar18[3] = 0xff;
                                puVar18 = puVar18 + 4;
                                puVar16 = *(uint32_t **)arg1;
                            } while (uVar20 < *puVar16);
                        }
                    }
                    var_160h = var_160h + 1;
                } while (var_160h < puVar16[1]);
            }
            fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
            *(undefined4 *)var_140h = **(undefined4 **)arg1;
            *(undefined4 *)var_138h = *(undefined4 *)(*(int64_t *)arg1 + 4);
            goto code_r0x00018006ecdd;
        }
    }
    fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
code_r0x00018006ecdd:
    func_0x000180459870(var_48h ^ (uint64_t)auStackY_198);
    return;
}

// ============================================================
// Function: FUN_18006e77a
// Address: 0x18006e77a
// Size: 428 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h

void fcn.18006e6e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    code *pcVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    undefined *puVar18;
    uint8_t *puVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    uint32_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    code *pcStack_108;
    int64_t var_100h;
    int64_t var_f8h;
    undefined var_f0h [4];
    int64_t var_ech;
    int64_t var_e4h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    *(undefined4 *)(*(int64_t *)arg1 + 8) = 0;
    var_140h = arg2;
    var_138h = arg3;
    iVar9 = fcn.18006db80(arg1);
    uVar14 = *(uint64_t *)arg1;
    uVar23 = *(uint32_t *)(uVar14 + 8);
    var_168h._0_4_ = uVar23;
    if (iVar9 == 0) {
code_r0x00018006e72e:
        fcn.18006d3b0(arg1, (uint64_t)uVar23, var_158h);
        goto code_r0x00018006ecdd;
    }
    if ((uVar23 == 3) &&
       ((*(int32_t *)(arg1 + 0x4850) == 3 || ((*(int32_t *)(arg1 + 0x484c) == 0 && (*(int32_t *)(arg1 + 0x4848) == 0))))
       )) {
        var_168h._4_4_ = 1;
    } else {
        if ((int32_t)uVar23 < 1) goto code_r0x00018006e72e;
        var_168h._4_4_ = 0;
    }
    _var_130h = ZEXT816(0);
    iVar9 = 0;
    _var_120h = ZEXT816(0);
    do {
        iVar17 = (int64_t)iVar9;
        iVar12 = func_0x00018046d050(**(int32_t **)arg1 + 3, uVar14);
        iVar22 = iVar17 * 0x60 + arg1;
        *(int64_t *)(iVar22 + 0x46e8) = iVar12;
        if (iVar12 == 0) goto code_r0x00018006ecbd;
        uVar8 = (int64_t)*(int32_t *)(arg1 + 0x4688) / (int64_t)*(int32_t *)(iVar22 + 0x46a4);
        *(undefined4 *)((int64_t)&var_e4h + iVar17 * 0x30 + 4) = 0;
        iVar10 = (int32_t)uVar8;
        *(int32_t *)(var_f0h + iVar17 * 0x30) = iVar10;
        iVar11 = *(int32_t *)(arg1 + 0x468c) / *(int32_t *)(iVar22 + 0x46a8);
        *(int32_t *)(&var_ech + iVar17 * 6) = iVar11;
        *(int32_t *)(&var_e4h + iVar17 * 6) = iVar11 >> 1;
        iVar6 = **(int32_t **)arg1;
        iVar12 = *(int64_t *)(iVar22 + 0x46d0);
        *(int64_t *)(var_f0h + (iVar17 * 0xc + -2) * 4) = iVar12;
        uVar8 = uVar8 & 0xffffffff;
        uVar7 = (uint64_t)(uint32_t)(iVar6 + -1 + iVar10);
        uVar14 = uVar7 % uVar8;
        (&var_100h)[iVar17 * 6] = iVar12;
        *(int32_t *)((int64_t)&var_ech + iVar17 * 0x30 + 4) = (int32_t)(uVar7 / uVar8);
        if (iVar10 == 1) {
            if (iVar11 == 1) {
                pcVar13 = (code *)0x18006dd80;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = fcn.18006dd90;
            }
        } else if (iVar10 == 2) {
            if (iVar11 == 1) {
                pcVar13 = fcn.18006df30;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = *(code **)(arg1 + 0x4880);
            }
        } else {
code_r0x00018006e87a:
            pcVar13 = fcn.18006e270;
        }
        iVar9 = iVar9 + 1;
        (&pcStack_108)[iVar17 * 6] = pcVar13;
    } while (iVar9 < (int32_t)uVar23);
    iVar9 = **(int32_t **)arg1;
    if ((iVar9 < 0) ||
       ((iVar9 != 0 &&
        ((uVar14 = 0x7fffffff % (int64_t)iVar9 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar9) < 4 ||
         (iVar9 * 4 < 0)))))) {
code_r0x00018006ecbd:
        puVar16 = *(uint32_t **)arg1;
    } else {
        iVar6 = (*(int32_t **)arg1)[1];
        if ((iVar6 < 0) ||
           ((iVar6 != 0 &&
            (uVar14 = 0x7fffffff % (int64_t)iVar6 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar6) < iVar9 * 4))))
        goto code_r0x00018006ecbd;
        var_158h = func_0x00018046d050((int64_t)(iVar9 * iVar6 * 4 + 1), uVar14);
        puVar16 = *(uint32_t **)arg1;
        if (var_158h != 0) {
            if (puVar16[1] != 0) {
                var_160h = 0;
                iVar12 = var_128h;
                iVar17 = var_120h;
                iVar22 = var_118h;
                do {
                    uVar20 = (uint32_t)var_168h;
                    iVar9 = 0;
                    var_148h = (uint64_t)(var_160h * *puVar16 * 4) + var_158h;
                    if (0 < (int32_t)uVar23) {
                        iVar12 = 0;
                        do {
                            var_150h = iVar12 * 0x60 + arg1;
                            iVar10 = *(int32_t *)(&var_ech + iVar12 * 6);
                            iVar6 = *(int32_t *)(&var_e4h + iVar12 * 6);
                            piVar15 = &var_100h;
                            if (iVar10 >> 1 <= iVar6) {
                                piVar15 = &var_f8h;
                            }
                            var_178h._0_4_ = *(uint32_t *)(var_f0h + iVar12 * 0x30);
                            iVar17 = (*(&pcStack_108)[iVar12 * 6])
                                               (*(undefined8 *)(var_150h + 0x46e8), piVar15[iVar12 * 6]);
                            (&var_130h)[iVar12] = iVar17;
                            iVar6 = iVar6 + 1;
                            *(int32_t *)(&var_e4h + iVar12 * 6) = iVar6;
                            if (iVar10 <= iVar6) {
                                piVar2 = (int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *piVar2 = *piVar2 + 1;
                                iVar17 = *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4);
                                iVar6 = *(int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *(undefined4 *)(&var_e4h + iVar12 * 6) = 0;
                                (&var_100h)[iVar12 * 6] = iVar17;
                                if (iVar6 < *(int32_t *)(var_150h + 0x46c0)) {
                                    *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4) =
                                         *(int32_t *)(var_150h + 0x46c4) + iVar17;
                                }
                            }
                            iVar9 = iVar9 + 1;
                            iVar12 = iVar12 + 1;
                        } while (iVar9 < (int32_t)uVar20);
                        puVar16 = *(uint32_t **)arg1;
                        iVar12 = var_128h;
                        iVar17 = var_120h;
                        iVar22 = var_118h;
                        uVar23 = (uint32_t)var_168h;
                    }
                    puVar19 = (uint8_t *)var_148h;
                    if (puVar16[2] == 3) {
                        if (var_168h._4_4_ == 0) {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                            puVar16 = *(uint32_t **)arg1;
                        } else {
                            uVar14 = 0;
                            puVar18 = (undefined *)var_148h;
                            if (*puVar16 != 0) {
                                do {
                                    *puVar18 = *(undefined *)(var_130h + uVar14);
                                    puVar18[1] = *(undefined *)(uVar14 + iVar12);
                                    puVar1 = (undefined *)(uVar14 + iVar17);
                                    uVar20 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar20;
                                    puVar18[2] = *puVar1;
                                    puVar18[3] = 0xff;
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar20 < *puVar16);
                            }
                        }
                    } else if (puVar16[2] == 4) {
                        if (*(int32_t *)(arg1 + 0x484c) == 0) {
                            if (*puVar16 != 0) {
                                uVar14 = 0;
                                puVar18 = (undefined *)var_148h;
                                do {
                                    uVar3 = *(uint8_t *)(iVar22 + uVar14);
                                    uVar20 = (uint32_t)*(uint8_t *)(var_130h + uVar14) * (uint32_t)uVar3 + 0x80;
                                    *puVar18 = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar20 = (uint32_t)*(uint8_t *)(iVar12 + uVar14) * (uint32_t)uVar3 + 0x80;
                                    puVar18[1] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar4 = *(uint8_t *)(iVar17 + uVar14);
                                    uVar21 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar21;
                                    puVar18[3] = 0xff;
                                    uVar20 = (uint32_t)uVar4 * (uint32_t)uVar3 + 0x80;
                                    puVar18[2] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar21 < *puVar16);
                            }
                        } else {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            if (*(int32_t *)(arg1 + 0x484c) == 2) {
                                (**(code **)(arg1 + 0x4878))();
                                puVar16 = *(uint32_t **)arg1;
                                if (*puVar16 != 0) {
                                    uVar20 = 0;
                                    do {
                                        uVar14 = (uint64_t)uVar20;
                                        uVar20 = uVar20 + 1;
                                        uVar3 = *(uint8_t *)(uVar14 + iVar22);
                                        uVar21 = (uint32_t)(uint8_t)~*puVar19 * (uint32_t)uVar3 + 0x80;
                                        *puVar19 = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[1] * (uint32_t)uVar3 + 0x80;
                                        puVar19[1] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[2] * (uint32_t)uVar3 + 0x80;
                                        puVar19[2] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        puVar16 = *(uint32_t **)arg1;
                                        puVar19 = puVar19 + 4;
                                    } while (uVar20 < *puVar16);
                                }
                            } else {
                                (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                                puVar16 = *(uint32_t **)arg1;
                            }
                        }
                    } else {
                        uVar14 = 0;
                        puVar18 = (undefined *)var_148h;
                        if (*puVar16 != 0) {
                            do {
                                uVar5 = *(undefined *)(uVar14 + var_130h);
                                uVar20 = (int32_t)uVar14 + 1;
                                uVar14 = (uint64_t)uVar20;
                                puVar18[2] = uVar5;
                                puVar18[1] = uVar5;
                                *puVar18 = uVar5;
                                puVar18[3] = 0xff;
                                puVar18 = puVar18 + 4;
                                puVar16 = *(uint32_t **)arg1;
                            } while (uVar20 < *puVar16);
                        }
                    }
                    var_160h = var_160h + 1;
                } while (var_160h < puVar16[1]);
            }
            fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
            *(undefined4 *)var_140h = **(undefined4 **)arg1;
            *(undefined4 *)var_138h = *(undefined4 *)(*(int64_t *)arg1 + 4);
            goto code_r0x00018006ecdd;
        }
    }
    fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
code_r0x00018006ecdd:
    func_0x000180459870(var_48h ^ (uint64_t)auStackY_198);
    return;
}

// ============================================================
// Function: FUN_18006e926
// Address: 0x18006e926
// Size: 871 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h

void fcn.18006e6e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    code *pcVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    undefined *puVar18;
    uint8_t *puVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    uint32_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    code *pcStack_108;
    int64_t var_100h;
    int64_t var_f8h;
    undefined var_f0h [4];
    int64_t var_ech;
    int64_t var_e4h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    *(undefined4 *)(*(int64_t *)arg1 + 8) = 0;
    var_140h = arg2;
    var_138h = arg3;
    iVar9 = fcn.18006db80(arg1);
    uVar14 = *(uint64_t *)arg1;
    uVar23 = *(uint32_t *)(uVar14 + 8);
    var_168h._0_4_ = uVar23;
    if (iVar9 == 0) {
code_r0x00018006e72e:
        fcn.18006d3b0(arg1, (uint64_t)uVar23, var_158h);
        goto code_r0x00018006ecdd;
    }
    if ((uVar23 == 3) &&
       ((*(int32_t *)(arg1 + 0x4850) == 3 || ((*(int32_t *)(arg1 + 0x484c) == 0 && (*(int32_t *)(arg1 + 0x4848) == 0))))
       )) {
        var_168h._4_4_ = 1;
    } else {
        if ((int32_t)uVar23 < 1) goto code_r0x00018006e72e;
        var_168h._4_4_ = 0;
    }
    _var_130h = ZEXT816(0);
    iVar9 = 0;
    _var_120h = ZEXT816(0);
    do {
        iVar17 = (int64_t)iVar9;
        iVar12 = func_0x00018046d050(**(int32_t **)arg1 + 3, uVar14);
        iVar22 = iVar17 * 0x60 + arg1;
        *(int64_t *)(iVar22 + 0x46e8) = iVar12;
        if (iVar12 == 0) goto code_r0x00018006ecbd;
        uVar8 = (int64_t)*(int32_t *)(arg1 + 0x4688) / (int64_t)*(int32_t *)(iVar22 + 0x46a4);
        *(undefined4 *)((int64_t)&var_e4h + iVar17 * 0x30 + 4) = 0;
        iVar10 = (int32_t)uVar8;
        *(int32_t *)(var_f0h + iVar17 * 0x30) = iVar10;
        iVar11 = *(int32_t *)(arg1 + 0x468c) / *(int32_t *)(iVar22 + 0x46a8);
        *(int32_t *)(&var_ech + iVar17 * 6) = iVar11;
        *(int32_t *)(&var_e4h + iVar17 * 6) = iVar11 >> 1;
        iVar6 = **(int32_t **)arg1;
        iVar12 = *(int64_t *)(iVar22 + 0x46d0);
        *(int64_t *)(var_f0h + (iVar17 * 0xc + -2) * 4) = iVar12;
        uVar8 = uVar8 & 0xffffffff;
        uVar7 = (uint64_t)(uint32_t)(iVar6 + -1 + iVar10);
        uVar14 = uVar7 % uVar8;
        (&var_100h)[iVar17 * 6] = iVar12;
        *(int32_t *)((int64_t)&var_ech + iVar17 * 0x30 + 4) = (int32_t)(uVar7 / uVar8);
        if (iVar10 == 1) {
            if (iVar11 == 1) {
                pcVar13 = (code *)0x18006dd80;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = fcn.18006dd90;
            }
        } else if (iVar10 == 2) {
            if (iVar11 == 1) {
                pcVar13 = fcn.18006df30;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = *(code **)(arg1 + 0x4880);
            }
        } else {
code_r0x00018006e87a:
            pcVar13 = fcn.18006e270;
        }
        iVar9 = iVar9 + 1;
        (&pcStack_108)[iVar17 * 6] = pcVar13;
    } while (iVar9 < (int32_t)uVar23);
    iVar9 = **(int32_t **)arg1;
    if ((iVar9 < 0) ||
       ((iVar9 != 0 &&
        ((uVar14 = 0x7fffffff % (int64_t)iVar9 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar9) < 4 ||
         (iVar9 * 4 < 0)))))) {
code_r0x00018006ecbd:
        puVar16 = *(uint32_t **)arg1;
    } else {
        iVar6 = (*(int32_t **)arg1)[1];
        if ((iVar6 < 0) ||
           ((iVar6 != 0 &&
            (uVar14 = 0x7fffffff % (int64_t)iVar6 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar6) < iVar9 * 4))))
        goto code_r0x00018006ecbd;
        var_158h = func_0x00018046d050((int64_t)(iVar9 * iVar6 * 4 + 1), uVar14);
        puVar16 = *(uint32_t **)arg1;
        if (var_158h != 0) {
            if (puVar16[1] != 0) {
                var_160h = 0;
                iVar12 = var_128h;
                iVar17 = var_120h;
                iVar22 = var_118h;
                do {
                    uVar20 = (uint32_t)var_168h;
                    iVar9 = 0;
                    var_148h = (uint64_t)(var_160h * *puVar16 * 4) + var_158h;
                    if (0 < (int32_t)uVar23) {
                        iVar12 = 0;
                        do {
                            var_150h = iVar12 * 0x60 + arg1;
                            iVar10 = *(int32_t *)(&var_ech + iVar12 * 6);
                            iVar6 = *(int32_t *)(&var_e4h + iVar12 * 6);
                            piVar15 = &var_100h;
                            if (iVar10 >> 1 <= iVar6) {
                                piVar15 = &var_f8h;
                            }
                            var_178h._0_4_ = *(uint32_t *)(var_f0h + iVar12 * 0x30);
                            iVar17 = (*(&pcStack_108)[iVar12 * 6])
                                               (*(undefined8 *)(var_150h + 0x46e8), piVar15[iVar12 * 6]);
                            (&var_130h)[iVar12] = iVar17;
                            iVar6 = iVar6 + 1;
                            *(int32_t *)(&var_e4h + iVar12 * 6) = iVar6;
                            if (iVar10 <= iVar6) {
                                piVar2 = (int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *piVar2 = *piVar2 + 1;
                                iVar17 = *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4);
                                iVar6 = *(int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *(undefined4 *)(&var_e4h + iVar12 * 6) = 0;
                                (&var_100h)[iVar12 * 6] = iVar17;
                                if (iVar6 < *(int32_t *)(var_150h + 0x46c0)) {
                                    *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4) =
                                         *(int32_t *)(var_150h + 0x46c4) + iVar17;
                                }
                            }
                            iVar9 = iVar9 + 1;
                            iVar12 = iVar12 + 1;
                        } while (iVar9 < (int32_t)uVar20);
                        puVar16 = *(uint32_t **)arg1;
                        iVar12 = var_128h;
                        iVar17 = var_120h;
                        iVar22 = var_118h;
                        uVar23 = (uint32_t)var_168h;
                    }
                    puVar19 = (uint8_t *)var_148h;
                    if (puVar16[2] == 3) {
                        if (var_168h._4_4_ == 0) {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                            puVar16 = *(uint32_t **)arg1;
                        } else {
                            uVar14 = 0;
                            puVar18 = (undefined *)var_148h;
                            if (*puVar16 != 0) {
                                do {
                                    *puVar18 = *(undefined *)(var_130h + uVar14);
                                    puVar18[1] = *(undefined *)(uVar14 + iVar12);
                                    puVar1 = (undefined *)(uVar14 + iVar17);
                                    uVar20 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar20;
                                    puVar18[2] = *puVar1;
                                    puVar18[3] = 0xff;
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar20 < *puVar16);
                            }
                        }
                    } else if (puVar16[2] == 4) {
                        if (*(int32_t *)(arg1 + 0x484c) == 0) {
                            if (*puVar16 != 0) {
                                uVar14 = 0;
                                puVar18 = (undefined *)var_148h;
                                do {
                                    uVar3 = *(uint8_t *)(iVar22 + uVar14);
                                    uVar20 = (uint32_t)*(uint8_t *)(var_130h + uVar14) * (uint32_t)uVar3 + 0x80;
                                    *puVar18 = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar20 = (uint32_t)*(uint8_t *)(iVar12 + uVar14) * (uint32_t)uVar3 + 0x80;
                                    puVar18[1] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar4 = *(uint8_t *)(iVar17 + uVar14);
                                    uVar21 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar21;
                                    puVar18[3] = 0xff;
                                    uVar20 = (uint32_t)uVar4 * (uint32_t)uVar3 + 0x80;
                                    puVar18[2] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar21 < *puVar16);
                            }
                        } else {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            if (*(int32_t *)(arg1 + 0x484c) == 2) {
                                (**(code **)(arg1 + 0x4878))();
                                puVar16 = *(uint32_t **)arg1;
                                if (*puVar16 != 0) {
                                    uVar20 = 0;
                                    do {
                                        uVar14 = (uint64_t)uVar20;
                                        uVar20 = uVar20 + 1;
                                        uVar3 = *(uint8_t *)(uVar14 + iVar22);
                                        uVar21 = (uint32_t)(uint8_t)~*puVar19 * (uint32_t)uVar3 + 0x80;
                                        *puVar19 = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[1] * (uint32_t)uVar3 + 0x80;
                                        puVar19[1] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[2] * (uint32_t)uVar3 + 0x80;
                                        puVar19[2] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        puVar16 = *(uint32_t **)arg1;
                                        puVar19 = puVar19 + 4;
                                    } while (uVar20 < *puVar16);
                                }
                            } else {
                                (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                                puVar16 = *(uint32_t **)arg1;
                            }
                        }
                    } else {
                        uVar14 = 0;
                        puVar18 = (undefined *)var_148h;
                        if (*puVar16 != 0) {
                            do {
                                uVar5 = *(undefined *)(uVar14 + var_130h);
                                uVar20 = (int32_t)uVar14 + 1;
                                uVar14 = (uint64_t)uVar20;
                                puVar18[2] = uVar5;
                                puVar18[1] = uVar5;
                                *puVar18 = uVar5;
                                puVar18[3] = 0xff;
                                puVar18 = puVar18 + 4;
                                puVar16 = *(uint32_t **)arg1;
                            } while (uVar20 < *puVar16);
                        }
                    }
                    var_160h = var_160h + 1;
                } while (var_160h < puVar16[1]);
            }
            fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
            *(undefined4 *)var_140h = **(undefined4 **)arg1;
            *(undefined4 *)var_138h = *(undefined4 *)(*(int64_t *)arg1 + 4);
            goto code_r0x00018006ecdd;
        }
    }
    fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
code_r0x00018006ecdd:
    func_0x000180459870(var_48h ^ (uint64_t)auStackY_198);
    return;
}

// ============================================================
// Function: FUN_18006ec8d
// Address: 0x18006ec8d
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h

void fcn.18006e6e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    code *pcVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    undefined *puVar18;
    uint8_t *puVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    uint32_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    code *pcStack_108;
    int64_t var_100h;
    int64_t var_f8h;
    undefined var_f0h [4];
    int64_t var_ech;
    int64_t var_e4h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    *(undefined4 *)(*(int64_t *)arg1 + 8) = 0;
    var_140h = arg2;
    var_138h = arg3;
    iVar9 = fcn.18006db80(arg1);
    uVar14 = *(uint64_t *)arg1;
    uVar23 = *(uint32_t *)(uVar14 + 8);
    var_168h._0_4_ = uVar23;
    if (iVar9 == 0) {
code_r0x00018006e72e:
        fcn.18006d3b0(arg1, (uint64_t)uVar23, var_158h);
        goto code_r0x00018006ecdd;
    }
    if ((uVar23 == 3) &&
       ((*(int32_t *)(arg1 + 0x4850) == 3 || ((*(int32_t *)(arg1 + 0x484c) == 0 && (*(int32_t *)(arg1 + 0x4848) == 0))))
       )) {
        var_168h._4_4_ = 1;
    } else {
        if ((int32_t)uVar23 < 1) goto code_r0x00018006e72e;
        var_168h._4_4_ = 0;
    }
    _var_130h = ZEXT816(0);
    iVar9 = 0;
    _var_120h = ZEXT816(0);
    do {
        iVar17 = (int64_t)iVar9;
        iVar12 = func_0x00018046d050(**(int32_t **)arg1 + 3, uVar14);
        iVar22 = iVar17 * 0x60 + arg1;
        *(int64_t *)(iVar22 + 0x46e8) = iVar12;
        if (iVar12 == 0) goto code_r0x00018006ecbd;
        uVar8 = (int64_t)*(int32_t *)(arg1 + 0x4688) / (int64_t)*(int32_t *)(iVar22 + 0x46a4);
        *(undefined4 *)((int64_t)&var_e4h + iVar17 * 0x30 + 4) = 0;
        iVar10 = (int32_t)uVar8;
        *(int32_t *)(var_f0h + iVar17 * 0x30) = iVar10;
        iVar11 = *(int32_t *)(arg1 + 0x468c) / *(int32_t *)(iVar22 + 0x46a8);
        *(int32_t *)(&var_ech + iVar17 * 6) = iVar11;
        *(int32_t *)(&var_e4h + iVar17 * 6) = iVar11 >> 1;
        iVar6 = **(int32_t **)arg1;
        iVar12 = *(int64_t *)(iVar22 + 0x46d0);
        *(int64_t *)(var_f0h + (iVar17 * 0xc + -2) * 4) = iVar12;
        uVar8 = uVar8 & 0xffffffff;
        uVar7 = (uint64_t)(uint32_t)(iVar6 + -1 + iVar10);
        uVar14 = uVar7 % uVar8;
        (&var_100h)[iVar17 * 6] = iVar12;
        *(int32_t *)((int64_t)&var_ech + iVar17 * 0x30 + 4) = (int32_t)(uVar7 / uVar8);
        if (iVar10 == 1) {
            if (iVar11 == 1) {
                pcVar13 = (code *)0x18006dd80;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = fcn.18006dd90;
            }
        } else if (iVar10 == 2) {
            if (iVar11 == 1) {
                pcVar13 = fcn.18006df30;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = *(code **)(arg1 + 0x4880);
            }
        } else {
code_r0x00018006e87a:
            pcVar13 = fcn.18006e270;
        }
        iVar9 = iVar9 + 1;
        (&pcStack_108)[iVar17 * 6] = pcVar13;
    } while (iVar9 < (int32_t)uVar23);
    iVar9 = **(int32_t **)arg1;
    if ((iVar9 < 0) ||
       ((iVar9 != 0 &&
        ((uVar14 = 0x7fffffff % (int64_t)iVar9 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar9) < 4 ||
         (iVar9 * 4 < 0)))))) {
code_r0x00018006ecbd:
        puVar16 = *(uint32_t **)arg1;
    } else {
        iVar6 = (*(int32_t **)arg1)[1];
        if ((iVar6 < 0) ||
           ((iVar6 != 0 &&
            (uVar14 = 0x7fffffff % (int64_t)iVar6 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar6) < iVar9 * 4))))
        goto code_r0x00018006ecbd;
        var_158h = func_0x00018046d050((int64_t)(iVar9 * iVar6 * 4 + 1), uVar14);
        puVar16 = *(uint32_t **)arg1;
        if (var_158h != 0) {
            if (puVar16[1] != 0) {
                var_160h = 0;
                iVar12 = var_128h;
                iVar17 = var_120h;
                iVar22 = var_118h;
                do {
                    uVar20 = (uint32_t)var_168h;
                    iVar9 = 0;
                    var_148h = (uint64_t)(var_160h * *puVar16 * 4) + var_158h;
                    if (0 < (int32_t)uVar23) {
                        iVar12 = 0;
                        do {
                            var_150h = iVar12 * 0x60 + arg1;
                            iVar10 = *(int32_t *)(&var_ech + iVar12 * 6);
                            iVar6 = *(int32_t *)(&var_e4h + iVar12 * 6);
                            piVar15 = &var_100h;
                            if (iVar10 >> 1 <= iVar6) {
                                piVar15 = &var_f8h;
                            }
                            var_178h._0_4_ = *(uint32_t *)(var_f0h + iVar12 * 0x30);
                            iVar17 = (*(&pcStack_108)[iVar12 * 6])
                                               (*(undefined8 *)(var_150h + 0x46e8), piVar15[iVar12 * 6]);
                            (&var_130h)[iVar12] = iVar17;
                            iVar6 = iVar6 + 1;
                            *(int32_t *)(&var_e4h + iVar12 * 6) = iVar6;
                            if (iVar10 <= iVar6) {
                                piVar2 = (int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *piVar2 = *piVar2 + 1;
                                iVar17 = *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4);
                                iVar6 = *(int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *(undefined4 *)(&var_e4h + iVar12 * 6) = 0;
                                (&var_100h)[iVar12 * 6] = iVar17;
                                if (iVar6 < *(int32_t *)(var_150h + 0x46c0)) {
                                    *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4) =
                                         *(int32_t *)(var_150h + 0x46c4) + iVar17;
                                }
                            }
                            iVar9 = iVar9 + 1;
                            iVar12 = iVar12 + 1;
                        } while (iVar9 < (int32_t)uVar20);
                        puVar16 = *(uint32_t **)arg1;
                        iVar12 = var_128h;
                        iVar17 = var_120h;
                        iVar22 = var_118h;
                        uVar23 = (uint32_t)var_168h;
                    }
                    puVar19 = (uint8_t *)var_148h;
                    if (puVar16[2] == 3) {
                        if (var_168h._4_4_ == 0) {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                            puVar16 = *(uint32_t **)arg1;
                        } else {
                            uVar14 = 0;
                            puVar18 = (undefined *)var_148h;
                            if (*puVar16 != 0) {
                                do {
                                    *puVar18 = *(undefined *)(var_130h + uVar14);
                                    puVar18[1] = *(undefined *)(uVar14 + iVar12);
                                    puVar1 = (undefined *)(uVar14 + iVar17);
                                    uVar20 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar20;
                                    puVar18[2] = *puVar1;
                                    puVar18[3] = 0xff;
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar20 < *puVar16);
                            }
                        }
                    } else if (puVar16[2] == 4) {
                        if (*(int32_t *)(arg1 + 0x484c) == 0) {
                            if (*puVar16 != 0) {
                                uVar14 = 0;
                                puVar18 = (undefined *)var_148h;
                                do {
                                    uVar3 = *(uint8_t *)(iVar22 + uVar14);
                                    uVar20 = (uint32_t)*(uint8_t *)(var_130h + uVar14) * (uint32_t)uVar3 + 0x80;
                                    *puVar18 = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar20 = (uint32_t)*(uint8_t *)(iVar12 + uVar14) * (uint32_t)uVar3 + 0x80;
                                    puVar18[1] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar4 = *(uint8_t *)(iVar17 + uVar14);
                                    uVar21 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar21;
                                    puVar18[3] = 0xff;
                                    uVar20 = (uint32_t)uVar4 * (uint32_t)uVar3 + 0x80;
                                    puVar18[2] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar21 < *puVar16);
                            }
                        } else {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            if (*(int32_t *)(arg1 + 0x484c) == 2) {
                                (**(code **)(arg1 + 0x4878))();
                                puVar16 = *(uint32_t **)arg1;
                                if (*puVar16 != 0) {
                                    uVar20 = 0;
                                    do {
                                        uVar14 = (uint64_t)uVar20;
                                        uVar20 = uVar20 + 1;
                                        uVar3 = *(uint8_t *)(uVar14 + iVar22);
                                        uVar21 = (uint32_t)(uint8_t)~*puVar19 * (uint32_t)uVar3 + 0x80;
                                        *puVar19 = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[1] * (uint32_t)uVar3 + 0x80;
                                        puVar19[1] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[2] * (uint32_t)uVar3 + 0x80;
                                        puVar19[2] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        puVar16 = *(uint32_t **)arg1;
                                        puVar19 = puVar19 + 4;
                                    } while (uVar20 < *puVar16);
                                }
                            } else {
                                (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                                puVar16 = *(uint32_t **)arg1;
                            }
                        }
                    } else {
                        uVar14 = 0;
                        puVar18 = (undefined *)var_148h;
                        if (*puVar16 != 0) {
                            do {
                                uVar5 = *(undefined *)(uVar14 + var_130h);
                                uVar20 = (int32_t)uVar14 + 1;
                                uVar14 = (uint64_t)uVar20;
                                puVar18[2] = uVar5;
                                puVar18[1] = uVar5;
                                *puVar18 = uVar5;
                                puVar18[3] = 0xff;
                                puVar18 = puVar18 + 4;
                                puVar16 = *(uint32_t **)arg1;
                            } while (uVar20 < *puVar16);
                        }
                    }
                    var_160h = var_160h + 1;
                } while (var_160h < puVar16[1]);
            }
            fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
            *(undefined4 *)var_140h = **(undefined4 **)arg1;
            *(undefined4 *)var_138h = *(undefined4 *)(*(int64_t *)arg1 + 4);
            goto code_r0x00018006ecdd;
        }
    }
    fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
code_r0x00018006ecdd:
    func_0x000180459870(var_48h ^ (uint64_t)auStackY_198);
    return;
}

// ============================================================
// Function: FUN_18006ecdd
// Address: 0x18006ecdd
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_158h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h

void fcn.18006e6e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    int32_t *piVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    undefined uVar5;
    int32_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    code *pcVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    uint32_t *puVar16;
    int64_t iVar17;
    undefined *puVar18;
    uint8_t *puVar19;
    uint32_t uVar20;
    uint32_t uVar21;
    int64_t iVar22;
    uint32_t uVar23;
    int64_t var_20h;
    undefined auStackY_198 [32];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    uint32_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    code *pcStack_108;
    int64_t var_100h;
    int64_t var_f8h;
    undefined var_f0h [4];
    int64_t var_ech;
    int64_t var_e4h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_198;
    *(undefined4 *)(*(int64_t *)arg1 + 8) = 0;
    var_140h = arg2;
    var_138h = arg3;
    iVar9 = fcn.18006db80(arg1);
    uVar14 = *(uint64_t *)arg1;
    uVar23 = *(uint32_t *)(uVar14 + 8);
    var_168h._0_4_ = uVar23;
    if (iVar9 == 0) {
code_r0x00018006e72e:
        fcn.18006d3b0(arg1, (uint64_t)uVar23, var_158h);
        goto code_r0x00018006ecdd;
    }
    if ((uVar23 == 3) &&
       ((*(int32_t *)(arg1 + 0x4850) == 3 || ((*(int32_t *)(arg1 + 0x484c) == 0 && (*(int32_t *)(arg1 + 0x4848) == 0))))
       )) {
        var_168h._4_4_ = 1;
    } else {
        if ((int32_t)uVar23 < 1) goto code_r0x00018006e72e;
        var_168h._4_4_ = 0;
    }
    _var_130h = ZEXT816(0);
    iVar9 = 0;
    _var_120h = ZEXT816(0);
    do {
        iVar17 = (int64_t)iVar9;
        iVar12 = func_0x00018046d050(**(int32_t **)arg1 + 3, uVar14);
        iVar22 = iVar17 * 0x60 + arg1;
        *(int64_t *)(iVar22 + 0x46e8) = iVar12;
        if (iVar12 == 0) goto code_r0x00018006ecbd;
        uVar8 = (int64_t)*(int32_t *)(arg1 + 0x4688) / (int64_t)*(int32_t *)(iVar22 + 0x46a4);
        *(undefined4 *)((int64_t)&var_e4h + iVar17 * 0x30 + 4) = 0;
        iVar10 = (int32_t)uVar8;
        *(int32_t *)(var_f0h + iVar17 * 0x30) = iVar10;
        iVar11 = *(int32_t *)(arg1 + 0x468c) / *(int32_t *)(iVar22 + 0x46a8);
        *(int32_t *)(&var_ech + iVar17 * 6) = iVar11;
        *(int32_t *)(&var_e4h + iVar17 * 6) = iVar11 >> 1;
        iVar6 = **(int32_t **)arg1;
        iVar12 = *(int64_t *)(iVar22 + 0x46d0);
        *(int64_t *)(var_f0h + (iVar17 * 0xc + -2) * 4) = iVar12;
        uVar8 = uVar8 & 0xffffffff;
        uVar7 = (uint64_t)(uint32_t)(iVar6 + -1 + iVar10);
        uVar14 = uVar7 % uVar8;
        (&var_100h)[iVar17 * 6] = iVar12;
        *(int32_t *)((int64_t)&var_ech + iVar17 * 0x30 + 4) = (int32_t)(uVar7 / uVar8);
        if (iVar10 == 1) {
            if (iVar11 == 1) {
                pcVar13 = (code *)0x18006dd80;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = fcn.18006dd90;
            }
        } else if (iVar10 == 2) {
            if (iVar11 == 1) {
                pcVar13 = fcn.18006df30;
            } else {
                if (iVar11 != 2) goto code_r0x00018006e87a;
                pcVar13 = *(code **)(arg1 + 0x4880);
            }
        } else {
code_r0x00018006e87a:
            pcVar13 = fcn.18006e270;
        }
        iVar9 = iVar9 + 1;
        (&pcStack_108)[iVar17 * 6] = pcVar13;
    } while (iVar9 < (int32_t)uVar23);
    iVar9 = **(int32_t **)arg1;
    if ((iVar9 < 0) ||
       ((iVar9 != 0 &&
        ((uVar14 = 0x7fffffff % (int64_t)iVar9 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar9) < 4 ||
         (iVar9 * 4 < 0)))))) {
code_r0x00018006ecbd:
        puVar16 = *(uint32_t **)arg1;
    } else {
        iVar6 = (*(int32_t **)arg1)[1];
        if ((iVar6 < 0) ||
           ((iVar6 != 0 &&
            (uVar14 = 0x7fffffff % (int64_t)iVar6 & 0xffffffff, (int32_t)(0x7fffffff / (int64_t)iVar6) < iVar9 * 4))))
        goto code_r0x00018006ecbd;
        var_158h = func_0x00018046d050((int64_t)(iVar9 * iVar6 * 4 + 1), uVar14);
        puVar16 = *(uint32_t **)arg1;
        if (var_158h != 0) {
            if (puVar16[1] != 0) {
                var_160h = 0;
                iVar12 = var_128h;
                iVar17 = var_120h;
                iVar22 = var_118h;
                do {
                    uVar20 = (uint32_t)var_168h;
                    iVar9 = 0;
                    var_148h = (uint64_t)(var_160h * *puVar16 * 4) + var_158h;
                    if (0 < (int32_t)uVar23) {
                        iVar12 = 0;
                        do {
                            var_150h = iVar12 * 0x60 + arg1;
                            iVar10 = *(int32_t *)(&var_ech + iVar12 * 6);
                            iVar6 = *(int32_t *)(&var_e4h + iVar12 * 6);
                            piVar15 = &var_100h;
                            if (iVar10 >> 1 <= iVar6) {
                                piVar15 = &var_f8h;
                            }
                            var_178h._0_4_ = *(uint32_t *)(var_f0h + iVar12 * 0x30);
                            iVar17 = (*(&pcStack_108)[iVar12 * 6])
                                               (*(undefined8 *)(var_150h + 0x46e8), piVar15[iVar12 * 6]);
                            (&var_130h)[iVar12] = iVar17;
                            iVar6 = iVar6 + 1;
                            *(int32_t *)(&var_e4h + iVar12 * 6) = iVar6;
                            if (iVar10 <= iVar6) {
                                piVar2 = (int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *piVar2 = *piVar2 + 1;
                                iVar17 = *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4);
                                iVar6 = *(int32_t *)((int64_t)&var_e4h + iVar12 * 0x30 + 4);
                                *(undefined4 *)(&var_e4h + iVar12 * 6) = 0;
                                (&var_100h)[iVar12 * 6] = iVar17;
                                if (iVar6 < *(int32_t *)(var_150h + 0x46c0)) {
                                    *(int64_t *)(var_f0h + (iVar12 * 0xc + -2) * 4) =
                                         *(int32_t *)(var_150h + 0x46c4) + iVar17;
                                }
                            }
                            iVar9 = iVar9 + 1;
                            iVar12 = iVar12 + 1;
                        } while (iVar9 < (int32_t)uVar20);
                        puVar16 = *(uint32_t **)arg1;
                        iVar12 = var_128h;
                        iVar17 = var_120h;
                        iVar22 = var_118h;
                        uVar23 = (uint32_t)var_168h;
                    }
                    puVar19 = (uint8_t *)var_148h;
                    if (puVar16[2] == 3) {
                        if (var_168h._4_4_ == 0) {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                            puVar16 = *(uint32_t **)arg1;
                        } else {
                            uVar14 = 0;
                            puVar18 = (undefined *)var_148h;
                            if (*puVar16 != 0) {
                                do {
                                    *puVar18 = *(undefined *)(var_130h + uVar14);
                                    puVar18[1] = *(undefined *)(uVar14 + iVar12);
                                    puVar1 = (undefined *)(uVar14 + iVar17);
                                    uVar20 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar20;
                                    puVar18[2] = *puVar1;
                                    puVar18[3] = 0xff;
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar20 < *puVar16);
                            }
                        }
                    } else if (puVar16[2] == 4) {
                        if (*(int32_t *)(arg1 + 0x484c) == 0) {
                            if (*puVar16 != 0) {
                                uVar14 = 0;
                                puVar18 = (undefined *)var_148h;
                                do {
                                    uVar3 = *(uint8_t *)(iVar22 + uVar14);
                                    uVar20 = (uint32_t)*(uint8_t *)(var_130h + uVar14) * (uint32_t)uVar3 + 0x80;
                                    *puVar18 = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar20 = (uint32_t)*(uint8_t *)(iVar12 + uVar14) * (uint32_t)uVar3 + 0x80;
                                    puVar18[1] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    uVar4 = *(uint8_t *)(iVar17 + uVar14);
                                    uVar21 = (int32_t)uVar14 + 1;
                                    uVar14 = (uint64_t)uVar21;
                                    puVar18[3] = 0xff;
                                    uVar20 = (uint32_t)uVar4 * (uint32_t)uVar3 + 0x80;
                                    puVar18[2] = (char)((uVar20 >> 8) + uVar20 >> 8);
                                    puVar16 = *(uint32_t **)arg1;
                                    puVar18 = puVar18 + 4;
                                } while (uVar21 < *puVar16);
                            }
                        } else {
                            var_178h._0_4_ = *puVar16;
                            var_170h._0_4_ = 4;
                            if (*(int32_t *)(arg1 + 0x484c) == 2) {
                                (**(code **)(arg1 + 0x4878))();
                                puVar16 = *(uint32_t **)arg1;
                                if (*puVar16 != 0) {
                                    uVar20 = 0;
                                    do {
                                        uVar14 = (uint64_t)uVar20;
                                        uVar20 = uVar20 + 1;
                                        uVar3 = *(uint8_t *)(uVar14 + iVar22);
                                        uVar21 = (uint32_t)(uint8_t)~*puVar19 * (uint32_t)uVar3 + 0x80;
                                        *puVar19 = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[1] * (uint32_t)uVar3 + 0x80;
                                        puVar19[1] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        uVar21 = (uint32_t)(uint8_t)~puVar19[2] * (uint32_t)uVar3 + 0x80;
                                        puVar19[2] = (uint8_t)((uVar21 >> 8) + uVar21 >> 8);
                                        puVar16 = *(uint32_t **)arg1;
                                        puVar19 = puVar19 + 4;
                                    } while (uVar20 < *puVar16);
                                }
                            } else {
                                (**(code **)(arg1 + 0x4878))(var_148h, var_130h, iVar12);
                                puVar16 = *(uint32_t **)arg1;
                            }
                        }
                    } else {
                        uVar14 = 0;
                        puVar18 = (undefined *)var_148h;
                        if (*puVar16 != 0) {
                            do {
                                uVar5 = *(undefined *)(uVar14 + var_130h);
                                uVar20 = (int32_t)uVar14 + 1;
                                uVar14 = (uint64_t)uVar20;
                                puVar18[2] = uVar5;
                                puVar18[1] = uVar5;
                                *puVar18 = uVar5;
                                puVar18[3] = 0xff;
                                puVar18 = puVar18 + 4;
                                puVar16 = *(uint32_t **)arg1;
                            } while (uVar20 < *puVar16);
                        }
                    }
                    var_160h = var_160h + 1;
                } while (var_160h < puVar16[1]);
            }
            fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
            *(undefined4 *)var_140h = **(undefined4 **)arg1;
            *(undefined4 *)var_138h = *(undefined4 *)(*(int64_t *)arg1 + 4);
            goto code_r0x00018006ecdd;
        }
    }
    fcn.18006d3b0(arg1, (uint64_t)puVar16[2], var_158h);
code_r0x00018006ecdd:
    func_0x000180459870(var_48h ^ (uint64_t)auStackY_198);
    return;
}

// ============================================================
// Function: FUN_18006ed00
// Address: 0x18006ed00
// Size: 582 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.18006ed00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    uint32_t *puVar2;
    int32_t *piVar3;
    int32_t iVar4;
    undefined auVar5 [16];
    int32_t iVar6;
    int64_t iVar7;
    uint8_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_18h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    var_78h._0_4_ = 0;
    _var_b8h = ZEXT816(0);
    _var_a8h = ZEXT816(0);
    _var_98h = ZEXT816(0);
    _var_88h = ZEXT816(0);
    func_0x0001804986e0(0, 0, 0x400);
    uVar11 = 0;
    iVar13 = (int32_t)arg3;
    if (0 < iVar13) {
        do {
            puVar1 = (uint8_t *)(uVar11 + arg2);
            uVar10 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar10;
            piVar3 = (int32_t *)((int64_t)&var_b8h + (uint64_t)*puVar1 * 4);
            *piVar3 = *piVar3 + 1;
        } while ((int32_t)uVar10 < iVar13);
    }
    auVar5._12_4_ = 0;
    auVar5._0_12_ = stack0xffffffffffffff4c;
    _var_b8h = auVar5 << 0x20;
    uVar10 = 1;
    do {
        if (1 << ((uint8_t)uVar10 & 0x1f) < *(int32_t *)((int64_t)&var_b8h + (uint64_t)uVar10 * 4))
        goto code_r0x00018006ef23;
        uVar10 = uVar10 + 1;
    } while ((int32_t)uVar10 < 0x10);
    iVar14 = 0;
    uVar10 = 1;
    iVar6 = 0;
    do {
        uVar11 = (uint64_t)uVar10;
        iVar4 = *(int32_t *)((int64_t)&var_b8h + uVar11 * 4);
        *(int32_t *)((int64_t)&var_68h + uVar11 * 4) = iVar6;
        *(int16_t *)(arg1 + 0x400 + uVar11 * 2) = (int16_t)iVar6;
        *(int16_t *)(arg1 + 0x464 + uVar11 * 2) = (int16_t)iVar14;
        iVar6 = iVar4 + iVar6;
        uVar8 = (uint8_t)uVar10;
        if ((iVar4 != 0) && (1 << (uVar8 & 0x1f) <= iVar6 + -1)) goto code_r0x00018006ef23;
        iVar14 = iVar14 + iVar4;
        uVar10 = uVar10 + 1;
        *(int32_t *)(arg1 + 0x420 + uVar11 * 4) = iVar6 << (0x10 - uVar8 & 0x1f);
        iVar6 = iVar6 * 2;
    } while ((int32_t)uVar10 < 0x10);
    uVar11 = 0;
    *(undefined4 *)(arg1 + 0x460) = 0x10000;
    if (0 < iVar13) {
        do {
            uVar8 = *(uint8_t *)(uVar11 + arg2);
            uVar12 = (uint64_t)uVar8;
            if (uVar8 != 0) {
                puVar2 = (uint32_t *)((int64_t)&var_68h + uVar12 * 4);
                uVar10 = *puVar2;
                iVar7 = (int64_t)(int32_t)(uVar10 + ((uint32_t)*(uint16_t *)(arg1 + 0x464 + uVar12 * 2) -
                                                    (uint32_t)*(uint16_t *)(arg1 + 0x400 + uVar12 * 2)));
                *(uint8_t *)(iVar7 + 0x484 + arg1) = uVar8;
                *(uint16_t *)(arg1 + 0x5a4 + iVar7 * 2) = (uint16_t)uVar11;
                if (uVar8 < 10) {
                    uVar9 = (int32_t)uVar10 >> 1 & 0x5555U | (uVar10 & 0x5555) * 2;
                    uVar9 = uVar9 >> 2 & 0x3333 | (uVar9 & 0x3333) << 2;
                    uVar9 = uVar9 >> 4 & 0xf0f | (uVar9 & 0xf0f) << 4;
                    iVar6 = (int32_t)((uVar9 & 0xff) << 8 | uVar9 >> 8) >> (0x10 - uVar8 & 0x1f);
                    if (iVar6 < 0x200) {
                        do {
                            iVar7 = (int64_t)iVar6;
                            iVar6 = iVar6 + (1 << (uVar8 & 0x1f));
                            *(uint16_t *)(arg1 + iVar7 * 2) = (uint16_t)uVar8 << 9 | (uint16_t)uVar11;
                        } while (iVar6 < 0x200);
                    }
                }
                *puVar2 = uVar10 + 1;
            }
            uVar10 = (int32_t)uVar11 + 1;
            uVar11 = (uint64_t)uVar10;
        } while ((int32_t)uVar10 < iVar13);
    }
code_r0x00018006ef23:
    func_0x000180459870(var_28h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_18006efb0
// Address: 0x18006efb0
// Size: 294 bytes
// ============================================================
uint32_t fcn.18006efb0(int64_t arg1, int64_t arg2)
{
    uint16_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    
    if (*(int32_t *)(arg1 + 0x10) < 0x10) {
        if (*(uint64_t *)(arg1 + 8) <= *(uint64_t *)arg1) {
            return 0xffffffff;
        }
        func_0x00018006ef50();
    }
    uVar2 = *(uint32_t *)(arg1 + 0x14);
    uVar1 = *(uint16_t *)(arg2 + (uint64_t)(uVar2 & 0x1ff) * 2);
    if (uVar1 == 0) {
        uVar3 = (int32_t)uVar2 >> 1 & 0x5555U | (uVar2 & 0x5555) * 2;
        uVar3 = uVar3 >> 2 & 0x3333 | (uVar3 & 0x3333) << 2;
        uVar3 = uVar3 >> 4 & 0xf0f | (uVar3 & 0xf0f) << 4;
        uVar5 = (uVar3 & 0xff) << 8 | uVar3 >> 8;
        uVar3 = 10;
        if (*(int32_t *)(arg2 + 0x448) <= (int32_t)uVar5) {
            do {
                uVar3 = uVar3 + 1;
            } while (*(int32_t *)(arg2 + 0x420 + (int64_t)(int32_t)uVar3 * 4) <= (int32_t)uVar5);
            if (0xf < (int32_t)uVar3) {
                return 0xffffffff;
            }
        }
        iVar4 = (uint32_t)*(uint16_t *)(arg2 + 0x464 + (int64_t)(int32_t)uVar3 * 2) +
                (((int32_t)uVar5 >> (0x10 - (uint8_t)uVar3 & 0x1f)) -
                (uint32_t)*(uint16_t *)(arg2 + 0x400 + (int64_t)(int32_t)uVar3 * 2));
        if ((iVar4 < 0x120) && (*(uint8_t *)((int64_t)iVar4 + 0x484 + arg2) == uVar3)) {
            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - uVar3;
            *(uint32_t *)(arg1 + 0x14) = uVar2 >> ((uint8_t)uVar3 & 0x1f);
            return (uint32_t)*(uint16_t *)(arg2 + 0x5a4 + (int64_t)iVar4 * 2);
        }
        return 0xffffffff;
    }
    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - (uint32_t)(uVar1 >> 9);
    *(uint32_t *)(arg1 + 0x14) = uVar2 >> ((uint8_t)(uVar1 >> 9) & 0x1f);
    return uVar1 & 0x1ff;
}

// ============================================================
// Function: FUN_18006f0e0
// Address: 0x18006f0e0
// Size: 154 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18006f0e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(int64_t *)(arg1 + 0x18) = arg2;
    if (*(int32_t *)(arg1 + 0x30) != 0) {
        uVar3 = (int32_t)arg2 - *(int32_t *)(arg1 + 0x20);
        uVar1 = *(int32_t *)(arg1 + 0x28) - *(int32_t *)(arg1 + 0x20);
        if ((uint32_t)arg3 <= ~uVar3) {
            for (; uVar1 < uVar3 + (uint32_t)arg3; uVar1 = uVar1 * 2) {
                if (0x7fffffff < uVar1) {
                    return 0;
                }
            }
            iVar2 = func_0x00018046d060(*(undefined8 *)(arg1 + 0x20), uVar1);
            if (iVar2 != 0) {
                *(int64_t *)(arg1 + 0x20) = iVar2;
                *(uint64_t *)(arg1 + 0x18) = (uint64_t)uVar3 + iVar2;
                *(uint64_t *)(arg1 + 0x28) = iVar2 + (uint64_t)uVar1;
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18006f180
// Address: 0x18006f180
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_209h
// WARNING: [rz-ghidra] Detected overlap for variable var_a28h
// WARNING: [rz-ghidra] Detected overlap for variable var_a27h
// WARNING: [rz-ghidra] Detected overlap for variable var_a25h
// WARNING: [rz-ghidra] Detected overlap for variable var_a26h

void fcn.18006f180(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint8_t uVar1;
    undefined uVar2;
    uint8_t *puVar3;
    uint8_t *puVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    undefined *puVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    undefined *arg2_00;
    uint64_t uVar16;
    uint32_t uVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a48 [32];
    uint8_t var_a28h [4];
    int64_t var_a24h;
    int64_t var_a18h;
    int64_t var_228h;
    int64_t var_219h;
    uint8_t var_209h;
    int64_t var_208h;
    int64_t var_38h;
    int64_t var_28h;
    uint64_t uVar18;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a48;
    *(int64_t *)(arg1 + 0x20) = arg2;
    *(int64_t *)(arg1 + 0x18) = arg2;
    *(int64_t *)(arg1 + 0x28) = (int32_t)arg3 + arg2;
    *(undefined4 *)(arg1 + 0x30) = 1;
    if ((int32_t)arg_28h != 0) {
        puVar3 = *(uint8_t **)(arg1 + 8);
        puVar4 = *(uint8_t **)arg1;
        if (puVar3 <= puVar4) goto code_r0x00018006f44a;
        uVar12 = *puVar4;
        puVar7 = puVar4 + 1;
        *(uint8_t **)arg1 = puVar7;
        if (puVar3 <= puVar7) goto code_r0x00018006f44a;
        uVar1 = *puVar7;
        *(uint8_t **)arg1 = puVar4 + 2;
        if ((((puVar3 <= puVar4 + 2) ||
             (uVar9 = (uint32_t)uVar12 * 0x100 + (uint32_t)uVar1, uVar9 != (uVar9 / 0x1f) * 0x1f)) ||
            ((uVar1 & 0x20) != 0)) || ((uVar12 & 0xf) != 8)) goto code_r0x00018006f44a;
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    do {
        if (*(int32_t *)(arg1 + 0x10) < 1) {
            func_0x00018006ef50(arg1);
        }
        uVar9 = *(uint32_t *)(arg1 + 0x14);
        *(uint32_t *)(arg1 + 0x14) = uVar9 >> 1;
        iVar5 = *(int32_t *)(arg1 + 0x10) + -1;
        *(int32_t *)(arg1 + 0x10) = iVar5;
        var_a24h._0_4_ = uVar9;
        if (iVar5 < 2) {
            func_0x00018006ef50(arg1);
        }
        uVar10 = *(uint32_t *)(arg1 + 0x14);
        uVar17 = uVar10 >> 2;
        uVar13 = *(int32_t *)(arg1 + 0x10) - 2;
        *(uint32_t *)(arg1 + 0x14) = uVar17;
        *(uint32_t *)(arg1 + 0x10) = uVar13;
        uVar10 = uVar10 & 3;
        if (uVar10 == 0) {
            uVar10 = uVar13 & 7;
            if (uVar10 != 0) {
                if ((int32_t)uVar13 < (int32_t)uVar10) {
                    func_0x00018006ef50(arg1);
                }
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) >> ((uint8_t)uVar10 & 0x1f);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - uVar10;
                uVar13 = *(uint32_t *)(arg1 + 0x10);
                uVar17 = *(uint32_t *)(arg1 + 0x14);
            }
            uVar18 = (uint64_t)uVar17;
            iVar5 = 0;
            uVar15 = uVar18;
            if (0 < (int32_t)uVar13) {
                do {
                    uVar16 = uVar15;
                    uVar13 = uVar13 - 8;
                    iVar8 = (int64_t)iVar5;
                    uVar15 = uVar16 >> 8;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = (uint8_t)uVar18;
                    uVar18 = uVar15 & 0xff;
                } while (0 < (int32_t)uVar13);
                *(uint32_t *)(arg1 + 0x10) = uVar13;
                *(int32_t *)(arg1 + 0x14) = (int32_t)(uVar16 >> 8);
            }
            if ((int32_t)uVar13 < 0) break;
            if (iVar5 < 4) {
                puVar3 = *(uint8_t **)(arg1 + 8);
                do {
                    puVar4 = *(uint8_t **)arg1;
                    if (puVar4 < puVar3) {
                        uVar12 = *puVar4;
                        *(uint8_t **)arg1 = puVar4 + 1;
                    } else {
                        uVar12 = 0;
                    }
                    iVar8 = (int64_t)iVar5;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = uVar12;
                } while (iVar5 < 4);
            }
            uVar10 = (uint32_t)var_a28h[1] * 0x100 + (uint32_t)var_a28h[0];
            if ((((uint32_t)var_a28h[3] * 0x100 + (uint32_t)var_a28h[2] != (uVar10 ^ 0xffff)) ||
                (uVar15 = (uint64_t)uVar10, *(uint64_t *)(arg1 + 8) < *(int64_t *)arg1 + uVar15)) ||
               ((*(uint64_t *)(arg1 + 0x28) < *(int64_t *)(arg1 + 0x18) + (uint64_t)uVar10 &&
                (iVar5 = fcn.18006f0e0(arg1, *(int64_t *)(arg1 + 0x18), (uint64_t)uVar10), iVar5 == 0)))) break;
            func_0x000180498030(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)arg1, uVar15);
            *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar15;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + uVar15;
        } else {
            if (uVar10 == 3) break;
            if (uVar10 == 1) {
                iVar5 = fcn.18006ed00(arg1 + 0x34, 0x1805ab3a0, 0x120);
                if (iVar5 == 0) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, 0x1805b5360, 0x20);
            } else {
                if ((int32_t)uVar13 < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar9 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar9 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar10 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar10 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 4) {
                    func_0x00018006ef50(arg1);
                }
                uVar13 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -4;
                iVar5 = *(int32_t *)(arg1 + 0x10);
                *(uint32_t *)(arg1 + 0x14) = uVar13 >> 4;
                _var_228h = SUB1615(ZEXT816(0), 0);
                uVar13 = (uVar13 & 0xf) + 4;
                uVar15 = (uint64_t)uVar13;
                var_219h._0_4_ = 0;
                if (uVar13 != 0) {
                    uVar18 = 0;
                    do {
                        if (iVar5 < 3) {
                            func_0x00018006ef50(arg1);
                        }
                        uVar13 = *(uint32_t *)(arg1 + 0x14);
                        iVar5 = *(int32_t *)(arg1 + 0x10) + -3;
                        *(uint32_t *)(arg1 + 0x14) = uVar13 >> 3;
                        uVar12 = *(uint8_t *)(uVar18 + 0x18063d270);
                        uVar17 = (int32_t)uVar18 + 1;
                        uVar18 = (uint64_t)uVar17;
                        *(int32_t *)(arg1 + 0x10) = iVar5;
                        *(uint8_t *)((int64_t)&var_228h + (uint64_t)uVar12) = (uint8_t)uVar13 & 7;
                    } while ((int32_t)uVar17 < (int32_t)uVar15);
                }
                iVar5 = fcn.18006ed00((int64_t)&var_a18h, (int64_t)&var_228h, 0x13);
                if (iVar5 == 0) break;
                uVar13 = (uVar9 & 0x1f) + 0x101;
                iVar6 = 0;
                uVar9 = (uVar10 & 0x1f) + 1;
                iVar5 = uVar9 + uVar13;
                do {
                    uVar10 = fcn.18006efb0(arg1, (int64_t)&var_a18h);
                    if (0x12 < uVar10) goto code_r0x00018006f44a;
                    if ((int32_t)uVar10 < 0x10) {
                        iVar8 = (int64_t)iVar6;
                        iVar6 = iVar6 + 1;
                        *(char *)((int64_t)&var_208h + iVar8) = (char)uVar10;
                    } else {
                        if (uVar10 == 0x10) {
                            if (*(int32_t *)(arg1 + 0x10) < 2) {
                                func_0x00018006ef50(arg1);
                            }
                            uVar10 = *(uint32_t *)(arg1 + 0x14);
                            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -2;
                            *(uint32_t *)(arg1 + 0x14) = uVar10 >> 2;
                            if (iVar6 == 0) goto code_r0x00018006f44a;
                            iVar14 = (uVar10 & 3) + 3;
                            uVar15 = (uint64_t)(&var_209h)[iVar6];
                        } else {
                            uVar15 = 0;
                            if (uVar10 == 0x11) {
                                if (*(int32_t *)(arg1 + 0x10) < 3) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -3;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 3;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 7) + 3;
                            } else {
                                if (uVar10 != 0x12) goto code_r0x00018006f44a;
                                if (*(int32_t *)(arg1 + 0x10) < 7) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -7;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 7;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 0x7f) + 0xb;
                            }
                            *(uint32_t *)(arg1 + 0x14) = uVar10;
                        }
                        if (iVar5 - iVar6 < iVar14) goto code_r0x00018006f44a;
                        func_0x0001804986e0((int64_t)&var_208h + (int64_t)iVar6, uVar15 & 0xff, iVar14);
                        iVar6 = iVar6 + iVar14;
                    }
                } while (iVar6 < iVar5);
                if ((iVar6 != iVar5) ||
                   (iVar5 = fcn.18006ed00(arg1 + 0x34, (int64_t)&var_208h, (uint64_t)uVar13), iVar5 == 0)) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, (int64_t)&var_208h + (uint64_t)uVar13, (uint64_t)uVar9);
            }
            if (iVar5 == 0) break;
            arg2_00 = *(undefined **)(arg1 + 0x18);
            while( true ) {
                while( true ) {
                    iVar5 = fcn.18006efb0(arg1, arg1 + 0x34);
                    if (0xff < iVar5) break;
                    if (iVar5 < 0) goto code_r0x00018006f44a;
                    if (*(undefined **)(arg1 + 0x28) <= arg2_00) {
                        iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, 1);
                        if (iVar6 == 0) goto code_r0x00018006f44a;
                        arg2_00 = *(undefined **)(arg1 + 0x18);
                    }
                    *arg2_00 = (char)iVar5;
                    arg2_00 = arg2_00 + 1;
                }
                if (iVar5 == 0x100) break;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b4ecc);
                uVar9 = *(uint32_t *)((int64_t)iVar5 * 4 + 0x1805b4d7c);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    uVar9 = uVar9 + ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10);
                }
                iVar5 = fcn.18006efb0(arg1, arg1 + 0x818);
                if (iVar5 < 0) goto code_r0x00018006f44a;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1806115b0);
                iVar5 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b5250);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    iVar5 = ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10) + iVar5;
                }
                if ((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x20) < (int64_t)iVar5) goto code_r0x00018006f44a;
                if (*(undefined **)(arg1 + 0x28) < arg2_00 + (int32_t)uVar9) {
                    iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, (uint64_t)uVar9);
                    if (iVar6 == 0) goto code_r0x00018006f44a;
                    arg2_00 = *(undefined **)(arg1 + 0x18);
                }
                puVar11 = arg2_00 + -(int64_t)iVar5;
                if (iVar5 == 1) {
                    if (uVar9 != 0) {
                        func_0x0001804986e0(arg2_00, *puVar11, (int64_t)(int32_t)uVar9);
                        do {
                            arg2_00 = arg2_00 + 1;
                            uVar9 = uVar9 - 1;
                        } while (uVar9 != 0);
                    }
                } else {
                    for (; uVar9 != 0; uVar9 = uVar9 - 1) {
                        uVar2 = *puVar11;
                        puVar11 = puVar11 + 1;
                        *arg2_00 = uVar2;
                        arg2_00 = arg2_00 + 1;
                    }
                }
            }
            *(undefined **)(arg1 + 0x18) = arg2_00;
            uVar9 = (uint32_t)var_a24h;
        }
    } while ((uVar9 & 1) == 0);
code_r0x00018006f44a:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a48);
    return;
}

// ============================================================
// Function: FUN_18006f227
// Address: 0x18006f227
// Size: 547 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_209h
// WARNING: [rz-ghidra] Detected overlap for variable var_a28h
// WARNING: [rz-ghidra] Detected overlap for variable var_a27h
// WARNING: [rz-ghidra] Detected overlap for variable var_a25h
// WARNING: [rz-ghidra] Detected overlap for variable var_a26h

void fcn.18006f180(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint8_t uVar1;
    undefined uVar2;
    uint8_t *puVar3;
    uint8_t *puVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    undefined *puVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    undefined *arg2_00;
    uint64_t uVar16;
    uint32_t uVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a48 [32];
    uint8_t var_a28h [4];
    int64_t var_a24h;
    int64_t var_a18h;
    int64_t var_228h;
    int64_t var_219h;
    uint8_t var_209h;
    int64_t var_208h;
    int64_t var_38h;
    int64_t var_28h;
    uint64_t uVar18;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a48;
    *(int64_t *)(arg1 + 0x20) = arg2;
    *(int64_t *)(arg1 + 0x18) = arg2;
    *(int64_t *)(arg1 + 0x28) = (int32_t)arg3 + arg2;
    *(undefined4 *)(arg1 + 0x30) = 1;
    if ((int32_t)arg_28h != 0) {
        puVar3 = *(uint8_t **)(arg1 + 8);
        puVar4 = *(uint8_t **)arg1;
        if (puVar3 <= puVar4) goto code_r0x00018006f44a;
        uVar12 = *puVar4;
        puVar7 = puVar4 + 1;
        *(uint8_t **)arg1 = puVar7;
        if (puVar3 <= puVar7) goto code_r0x00018006f44a;
        uVar1 = *puVar7;
        *(uint8_t **)arg1 = puVar4 + 2;
        if ((((puVar3 <= puVar4 + 2) ||
             (uVar9 = (uint32_t)uVar12 * 0x100 + (uint32_t)uVar1, uVar9 != (uVar9 / 0x1f) * 0x1f)) ||
            ((uVar1 & 0x20) != 0)) || ((uVar12 & 0xf) != 8)) goto code_r0x00018006f44a;
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    do {
        if (*(int32_t *)(arg1 + 0x10) < 1) {
            func_0x00018006ef50(arg1);
        }
        uVar9 = *(uint32_t *)(arg1 + 0x14);
        *(uint32_t *)(arg1 + 0x14) = uVar9 >> 1;
        iVar5 = *(int32_t *)(arg1 + 0x10) + -1;
        *(int32_t *)(arg1 + 0x10) = iVar5;
        var_a24h._0_4_ = uVar9;
        if (iVar5 < 2) {
            func_0x00018006ef50(arg1);
        }
        uVar10 = *(uint32_t *)(arg1 + 0x14);
        uVar17 = uVar10 >> 2;
        uVar13 = *(int32_t *)(arg1 + 0x10) - 2;
        *(uint32_t *)(arg1 + 0x14) = uVar17;
        *(uint32_t *)(arg1 + 0x10) = uVar13;
        uVar10 = uVar10 & 3;
        if (uVar10 == 0) {
            uVar10 = uVar13 & 7;
            if (uVar10 != 0) {
                if ((int32_t)uVar13 < (int32_t)uVar10) {
                    func_0x00018006ef50(arg1);
                }
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) >> ((uint8_t)uVar10 & 0x1f);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - uVar10;
                uVar13 = *(uint32_t *)(arg1 + 0x10);
                uVar17 = *(uint32_t *)(arg1 + 0x14);
            }
            uVar18 = (uint64_t)uVar17;
            iVar5 = 0;
            uVar15 = uVar18;
            if (0 < (int32_t)uVar13) {
                do {
                    uVar16 = uVar15;
                    uVar13 = uVar13 - 8;
                    iVar8 = (int64_t)iVar5;
                    uVar15 = uVar16 >> 8;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = (uint8_t)uVar18;
                    uVar18 = uVar15 & 0xff;
                } while (0 < (int32_t)uVar13);
                *(uint32_t *)(arg1 + 0x10) = uVar13;
                *(int32_t *)(arg1 + 0x14) = (int32_t)(uVar16 >> 8);
            }
            if ((int32_t)uVar13 < 0) break;
            if (iVar5 < 4) {
                puVar3 = *(uint8_t **)(arg1 + 8);
                do {
                    puVar4 = *(uint8_t **)arg1;
                    if (puVar4 < puVar3) {
                        uVar12 = *puVar4;
                        *(uint8_t **)arg1 = puVar4 + 1;
                    } else {
                        uVar12 = 0;
                    }
                    iVar8 = (int64_t)iVar5;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = uVar12;
                } while (iVar5 < 4);
            }
            uVar10 = (uint32_t)var_a28h[1] * 0x100 + (uint32_t)var_a28h[0];
            if ((((uint32_t)var_a28h[3] * 0x100 + (uint32_t)var_a28h[2] != (uVar10 ^ 0xffff)) ||
                (uVar15 = (uint64_t)uVar10, *(uint64_t *)(arg1 + 8) < *(int64_t *)arg1 + uVar15)) ||
               ((*(uint64_t *)(arg1 + 0x28) < *(int64_t *)(arg1 + 0x18) + (uint64_t)uVar10 &&
                (iVar5 = fcn.18006f0e0(arg1, *(int64_t *)(arg1 + 0x18), (uint64_t)uVar10), iVar5 == 0)))) break;
            func_0x000180498030(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)arg1, uVar15);
            *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar15;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + uVar15;
        } else {
            if (uVar10 == 3) break;
            if (uVar10 == 1) {
                iVar5 = fcn.18006ed00(arg1 + 0x34, 0x1805ab3a0, 0x120);
                if (iVar5 == 0) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, 0x1805b5360, 0x20);
            } else {
                if ((int32_t)uVar13 < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar9 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar9 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar10 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar10 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 4) {
                    func_0x00018006ef50(arg1);
                }
                uVar13 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -4;
                iVar5 = *(int32_t *)(arg1 + 0x10);
                *(uint32_t *)(arg1 + 0x14) = uVar13 >> 4;
                _var_228h = SUB1615(ZEXT816(0), 0);
                uVar13 = (uVar13 & 0xf) + 4;
                uVar15 = (uint64_t)uVar13;
                var_219h._0_4_ = 0;
                if (uVar13 != 0) {
                    uVar18 = 0;
                    do {
                        if (iVar5 < 3) {
                            func_0x00018006ef50(arg1);
                        }
                        uVar13 = *(uint32_t *)(arg1 + 0x14);
                        iVar5 = *(int32_t *)(arg1 + 0x10) + -3;
                        *(uint32_t *)(arg1 + 0x14) = uVar13 >> 3;
                        uVar12 = *(uint8_t *)(uVar18 + 0x18063d270);
                        uVar17 = (int32_t)uVar18 + 1;
                        uVar18 = (uint64_t)uVar17;
                        *(int32_t *)(arg1 + 0x10) = iVar5;
                        *(uint8_t *)((int64_t)&var_228h + (uint64_t)uVar12) = (uint8_t)uVar13 & 7;
                    } while ((int32_t)uVar17 < (int32_t)uVar15);
                }
                iVar5 = fcn.18006ed00((int64_t)&var_a18h, (int64_t)&var_228h, 0x13);
                if (iVar5 == 0) break;
                uVar13 = (uVar9 & 0x1f) + 0x101;
                iVar6 = 0;
                uVar9 = (uVar10 & 0x1f) + 1;
                iVar5 = uVar9 + uVar13;
                do {
                    uVar10 = fcn.18006efb0(arg1, (int64_t)&var_a18h);
                    if (0x12 < uVar10) goto code_r0x00018006f44a;
                    if ((int32_t)uVar10 < 0x10) {
                        iVar8 = (int64_t)iVar6;
                        iVar6 = iVar6 + 1;
                        *(char *)((int64_t)&var_208h + iVar8) = (char)uVar10;
                    } else {
                        if (uVar10 == 0x10) {
                            if (*(int32_t *)(arg1 + 0x10) < 2) {
                                func_0x00018006ef50(arg1);
                            }
                            uVar10 = *(uint32_t *)(arg1 + 0x14);
                            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -2;
                            *(uint32_t *)(arg1 + 0x14) = uVar10 >> 2;
                            if (iVar6 == 0) goto code_r0x00018006f44a;
                            iVar14 = (uVar10 & 3) + 3;
                            uVar15 = (uint64_t)(&var_209h)[iVar6];
                        } else {
                            uVar15 = 0;
                            if (uVar10 == 0x11) {
                                if (*(int32_t *)(arg1 + 0x10) < 3) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -3;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 3;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 7) + 3;
                            } else {
                                if (uVar10 != 0x12) goto code_r0x00018006f44a;
                                if (*(int32_t *)(arg1 + 0x10) < 7) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -7;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 7;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 0x7f) + 0xb;
                            }
                            *(uint32_t *)(arg1 + 0x14) = uVar10;
                        }
                        if (iVar5 - iVar6 < iVar14) goto code_r0x00018006f44a;
                        func_0x0001804986e0((int64_t)&var_208h + (int64_t)iVar6, uVar15 & 0xff, iVar14);
                        iVar6 = iVar6 + iVar14;
                    }
                } while (iVar6 < iVar5);
                if ((iVar6 != iVar5) ||
                   (iVar5 = fcn.18006ed00(arg1 + 0x34, (int64_t)&var_208h, (uint64_t)uVar13), iVar5 == 0)) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, (int64_t)&var_208h + (uint64_t)uVar13, (uint64_t)uVar9);
            }
            if (iVar5 == 0) break;
            arg2_00 = *(undefined **)(arg1 + 0x18);
            while( true ) {
                while( true ) {
                    iVar5 = fcn.18006efb0(arg1, arg1 + 0x34);
                    if (0xff < iVar5) break;
                    if (iVar5 < 0) goto code_r0x00018006f44a;
                    if (*(undefined **)(arg1 + 0x28) <= arg2_00) {
                        iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, 1);
                        if (iVar6 == 0) goto code_r0x00018006f44a;
                        arg2_00 = *(undefined **)(arg1 + 0x18);
                    }
                    *arg2_00 = (char)iVar5;
                    arg2_00 = arg2_00 + 1;
                }
                if (iVar5 == 0x100) break;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b4ecc);
                uVar9 = *(uint32_t *)((int64_t)iVar5 * 4 + 0x1805b4d7c);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    uVar9 = uVar9 + ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10);
                }
                iVar5 = fcn.18006efb0(arg1, arg1 + 0x818);
                if (iVar5 < 0) goto code_r0x00018006f44a;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1806115b0);
                iVar5 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b5250);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    iVar5 = ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10) + iVar5;
                }
                if ((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x20) < (int64_t)iVar5) goto code_r0x00018006f44a;
                if (*(undefined **)(arg1 + 0x28) < arg2_00 + (int32_t)uVar9) {
                    iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, (uint64_t)uVar9);
                    if (iVar6 == 0) goto code_r0x00018006f44a;
                    arg2_00 = *(undefined **)(arg1 + 0x18);
                }
                puVar11 = arg2_00 + -(int64_t)iVar5;
                if (iVar5 == 1) {
                    if (uVar9 != 0) {
                        func_0x0001804986e0(arg2_00, *puVar11, (int64_t)(int32_t)uVar9);
                        do {
                            arg2_00 = arg2_00 + 1;
                            uVar9 = uVar9 - 1;
                        } while (uVar9 != 0);
                    }
                } else {
                    for (; uVar9 != 0; uVar9 = uVar9 - 1) {
                        uVar2 = *puVar11;
                        puVar11 = puVar11 + 1;
                        *arg2_00 = uVar2;
                        arg2_00 = arg2_00 + 1;
                    }
                }
            }
            *(undefined **)(arg1 + 0x18) = arg2_00;
            uVar9 = (uint32_t)var_a24h;
        }
    } while ((uVar9 & 1) == 0);
code_r0x00018006f44a:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a48);
    return;
}

// ============================================================
// Function: FUN_18006f44a
// Address: 0x18006f44a
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_209h
// WARNING: [rz-ghidra] Detected overlap for variable var_a28h
// WARNING: [rz-ghidra] Detected overlap for variable var_a27h
// WARNING: [rz-ghidra] Detected overlap for variable var_a25h
// WARNING: [rz-ghidra] Detected overlap for variable var_a26h

void fcn.18006f180(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint8_t uVar1;
    undefined uVar2;
    uint8_t *puVar3;
    uint8_t *puVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    undefined *puVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    undefined *arg2_00;
    uint64_t uVar16;
    uint32_t uVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a48 [32];
    uint8_t var_a28h [4];
    int64_t var_a24h;
    int64_t var_a18h;
    int64_t var_228h;
    int64_t var_219h;
    uint8_t var_209h;
    int64_t var_208h;
    int64_t var_38h;
    int64_t var_28h;
    uint64_t uVar18;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a48;
    *(int64_t *)(arg1 + 0x20) = arg2;
    *(int64_t *)(arg1 + 0x18) = arg2;
    *(int64_t *)(arg1 + 0x28) = (int32_t)arg3 + arg2;
    *(undefined4 *)(arg1 + 0x30) = 1;
    if ((int32_t)arg_28h != 0) {
        puVar3 = *(uint8_t **)(arg1 + 8);
        puVar4 = *(uint8_t **)arg1;
        if (puVar3 <= puVar4) goto code_r0x00018006f44a;
        uVar12 = *puVar4;
        puVar7 = puVar4 + 1;
        *(uint8_t **)arg1 = puVar7;
        if (puVar3 <= puVar7) goto code_r0x00018006f44a;
        uVar1 = *puVar7;
        *(uint8_t **)arg1 = puVar4 + 2;
        if ((((puVar3 <= puVar4 + 2) ||
             (uVar9 = (uint32_t)uVar12 * 0x100 + (uint32_t)uVar1, uVar9 != (uVar9 / 0x1f) * 0x1f)) ||
            ((uVar1 & 0x20) != 0)) || ((uVar12 & 0xf) != 8)) goto code_r0x00018006f44a;
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    do {
        if (*(int32_t *)(arg1 + 0x10) < 1) {
            func_0x00018006ef50(arg1);
        }
        uVar9 = *(uint32_t *)(arg1 + 0x14);
        *(uint32_t *)(arg1 + 0x14) = uVar9 >> 1;
        iVar5 = *(int32_t *)(arg1 + 0x10) + -1;
        *(int32_t *)(arg1 + 0x10) = iVar5;
        var_a24h._0_4_ = uVar9;
        if (iVar5 < 2) {
            func_0x00018006ef50(arg1);
        }
        uVar10 = *(uint32_t *)(arg1 + 0x14);
        uVar17 = uVar10 >> 2;
        uVar13 = *(int32_t *)(arg1 + 0x10) - 2;
        *(uint32_t *)(arg1 + 0x14) = uVar17;
        *(uint32_t *)(arg1 + 0x10) = uVar13;
        uVar10 = uVar10 & 3;
        if (uVar10 == 0) {
            uVar10 = uVar13 & 7;
            if (uVar10 != 0) {
                if ((int32_t)uVar13 < (int32_t)uVar10) {
                    func_0x00018006ef50(arg1);
                }
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) >> ((uint8_t)uVar10 & 0x1f);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - uVar10;
                uVar13 = *(uint32_t *)(arg1 + 0x10);
                uVar17 = *(uint32_t *)(arg1 + 0x14);
            }
            uVar18 = (uint64_t)uVar17;
            iVar5 = 0;
            uVar15 = uVar18;
            if (0 < (int32_t)uVar13) {
                do {
                    uVar16 = uVar15;
                    uVar13 = uVar13 - 8;
                    iVar8 = (int64_t)iVar5;
                    uVar15 = uVar16 >> 8;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = (uint8_t)uVar18;
                    uVar18 = uVar15 & 0xff;
                } while (0 < (int32_t)uVar13);
                *(uint32_t *)(arg1 + 0x10) = uVar13;
                *(int32_t *)(arg1 + 0x14) = (int32_t)(uVar16 >> 8);
            }
            if ((int32_t)uVar13 < 0) break;
            if (iVar5 < 4) {
                puVar3 = *(uint8_t **)(arg1 + 8);
                do {
                    puVar4 = *(uint8_t **)arg1;
                    if (puVar4 < puVar3) {
                        uVar12 = *puVar4;
                        *(uint8_t **)arg1 = puVar4 + 1;
                    } else {
                        uVar12 = 0;
                    }
                    iVar8 = (int64_t)iVar5;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = uVar12;
                } while (iVar5 < 4);
            }
            uVar10 = (uint32_t)var_a28h[1] * 0x100 + (uint32_t)var_a28h[0];
            if ((((uint32_t)var_a28h[3] * 0x100 + (uint32_t)var_a28h[2] != (uVar10 ^ 0xffff)) ||
                (uVar15 = (uint64_t)uVar10, *(uint64_t *)(arg1 + 8) < *(int64_t *)arg1 + uVar15)) ||
               ((*(uint64_t *)(arg1 + 0x28) < *(int64_t *)(arg1 + 0x18) + (uint64_t)uVar10 &&
                (iVar5 = fcn.18006f0e0(arg1, *(int64_t *)(arg1 + 0x18), (uint64_t)uVar10), iVar5 == 0)))) break;
            func_0x000180498030(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)arg1, uVar15);
            *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar15;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + uVar15;
        } else {
            if (uVar10 == 3) break;
            if (uVar10 == 1) {
                iVar5 = fcn.18006ed00(arg1 + 0x34, 0x1805ab3a0, 0x120);
                if (iVar5 == 0) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, 0x1805b5360, 0x20);
            } else {
                if ((int32_t)uVar13 < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar9 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar9 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar10 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar10 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 4) {
                    func_0x00018006ef50(arg1);
                }
                uVar13 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -4;
                iVar5 = *(int32_t *)(arg1 + 0x10);
                *(uint32_t *)(arg1 + 0x14) = uVar13 >> 4;
                _var_228h = SUB1615(ZEXT816(0), 0);
                uVar13 = (uVar13 & 0xf) + 4;
                uVar15 = (uint64_t)uVar13;
                var_219h._0_4_ = 0;
                if (uVar13 != 0) {
                    uVar18 = 0;
                    do {
                        if (iVar5 < 3) {
                            func_0x00018006ef50(arg1);
                        }
                        uVar13 = *(uint32_t *)(arg1 + 0x14);
                        iVar5 = *(int32_t *)(arg1 + 0x10) + -3;
                        *(uint32_t *)(arg1 + 0x14) = uVar13 >> 3;
                        uVar12 = *(uint8_t *)(uVar18 + 0x18063d270);
                        uVar17 = (int32_t)uVar18 + 1;
                        uVar18 = (uint64_t)uVar17;
                        *(int32_t *)(arg1 + 0x10) = iVar5;
                        *(uint8_t *)((int64_t)&var_228h + (uint64_t)uVar12) = (uint8_t)uVar13 & 7;
                    } while ((int32_t)uVar17 < (int32_t)uVar15);
                }
                iVar5 = fcn.18006ed00((int64_t)&var_a18h, (int64_t)&var_228h, 0x13);
                if (iVar5 == 0) break;
                uVar13 = (uVar9 & 0x1f) + 0x101;
                iVar6 = 0;
                uVar9 = (uVar10 & 0x1f) + 1;
                iVar5 = uVar9 + uVar13;
                do {
                    uVar10 = fcn.18006efb0(arg1, (int64_t)&var_a18h);
                    if (0x12 < uVar10) goto code_r0x00018006f44a;
                    if ((int32_t)uVar10 < 0x10) {
                        iVar8 = (int64_t)iVar6;
                        iVar6 = iVar6 + 1;
                        *(char *)((int64_t)&var_208h + iVar8) = (char)uVar10;
                    } else {
                        if (uVar10 == 0x10) {
                            if (*(int32_t *)(arg1 + 0x10) < 2) {
                                func_0x00018006ef50(arg1);
                            }
                            uVar10 = *(uint32_t *)(arg1 + 0x14);
                            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -2;
                            *(uint32_t *)(arg1 + 0x14) = uVar10 >> 2;
                            if (iVar6 == 0) goto code_r0x00018006f44a;
                            iVar14 = (uVar10 & 3) + 3;
                            uVar15 = (uint64_t)(&var_209h)[iVar6];
                        } else {
                            uVar15 = 0;
                            if (uVar10 == 0x11) {
                                if (*(int32_t *)(arg1 + 0x10) < 3) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -3;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 3;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 7) + 3;
                            } else {
                                if (uVar10 != 0x12) goto code_r0x00018006f44a;
                                if (*(int32_t *)(arg1 + 0x10) < 7) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -7;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 7;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 0x7f) + 0xb;
                            }
                            *(uint32_t *)(arg1 + 0x14) = uVar10;
                        }
                        if (iVar5 - iVar6 < iVar14) goto code_r0x00018006f44a;
                        func_0x0001804986e0((int64_t)&var_208h + (int64_t)iVar6, uVar15 & 0xff, iVar14);
                        iVar6 = iVar6 + iVar14;
                    }
                } while (iVar6 < iVar5);
                if ((iVar6 != iVar5) ||
                   (iVar5 = fcn.18006ed00(arg1 + 0x34, (int64_t)&var_208h, (uint64_t)uVar13), iVar5 == 0)) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, (int64_t)&var_208h + (uint64_t)uVar13, (uint64_t)uVar9);
            }
            if (iVar5 == 0) break;
            arg2_00 = *(undefined **)(arg1 + 0x18);
            while( true ) {
                while( true ) {
                    iVar5 = fcn.18006efb0(arg1, arg1 + 0x34);
                    if (0xff < iVar5) break;
                    if (iVar5 < 0) goto code_r0x00018006f44a;
                    if (*(undefined **)(arg1 + 0x28) <= arg2_00) {
                        iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, 1);
                        if (iVar6 == 0) goto code_r0x00018006f44a;
                        arg2_00 = *(undefined **)(arg1 + 0x18);
                    }
                    *arg2_00 = (char)iVar5;
                    arg2_00 = arg2_00 + 1;
                }
                if (iVar5 == 0x100) break;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b4ecc);
                uVar9 = *(uint32_t *)((int64_t)iVar5 * 4 + 0x1805b4d7c);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    uVar9 = uVar9 + ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10);
                }
                iVar5 = fcn.18006efb0(arg1, arg1 + 0x818);
                if (iVar5 < 0) goto code_r0x00018006f44a;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1806115b0);
                iVar5 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b5250);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    iVar5 = ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10) + iVar5;
                }
                if ((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x20) < (int64_t)iVar5) goto code_r0x00018006f44a;
                if (*(undefined **)(arg1 + 0x28) < arg2_00 + (int32_t)uVar9) {
                    iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, (uint64_t)uVar9);
                    if (iVar6 == 0) goto code_r0x00018006f44a;
                    arg2_00 = *(undefined **)(arg1 + 0x18);
                }
                puVar11 = arg2_00 + -(int64_t)iVar5;
                if (iVar5 == 1) {
                    if (uVar9 != 0) {
                        func_0x0001804986e0(arg2_00, *puVar11, (int64_t)(int32_t)uVar9);
                        do {
                            arg2_00 = arg2_00 + 1;
                            uVar9 = uVar9 - 1;
                        } while (uVar9 != 0);
                    }
                } else {
                    for (; uVar9 != 0; uVar9 = uVar9 - 1) {
                        uVar2 = *puVar11;
                        puVar11 = puVar11 + 1;
                        *arg2_00 = uVar2;
                        arg2_00 = arg2_00 + 1;
                    }
                }
            }
            *(undefined **)(arg1 + 0x18) = arg2_00;
            uVar9 = (uint32_t)var_a24h;
        }
    } while ((uVar9 & 1) == 0);
code_r0x00018006f44a:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a48);
    return;
}

// ============================================================
// Function: FUN_18006f465
// Address: 0x18006f465
// Size: 996 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_209h
// WARNING: [rz-ghidra] Detected overlap for variable var_a28h
// WARNING: [rz-ghidra] Detected overlap for variable var_a27h
// WARNING: [rz-ghidra] Detected overlap for variable var_a25h
// WARNING: [rz-ghidra] Detected overlap for variable var_a26h

void fcn.18006f180(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    uint8_t uVar1;
    undefined uVar2;
    uint8_t *puVar3;
    uint8_t *puVar4;
    int32_t iVar5;
    int32_t iVar6;
    uint8_t *puVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    undefined *puVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    int32_t iVar14;
    uint64_t uVar15;
    undefined *arg2_00;
    uint64_t uVar16;
    uint32_t uVar17;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a48 [32];
    uint8_t var_a28h [4];
    int64_t var_a24h;
    int64_t var_a18h;
    int64_t var_228h;
    int64_t var_219h;
    uint8_t var_209h;
    int64_t var_208h;
    int64_t var_38h;
    int64_t var_28h;
    uint64_t uVar18;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a48;
    *(int64_t *)(arg1 + 0x20) = arg2;
    *(int64_t *)(arg1 + 0x18) = arg2;
    *(int64_t *)(arg1 + 0x28) = (int32_t)arg3 + arg2;
    *(undefined4 *)(arg1 + 0x30) = 1;
    if ((int32_t)arg_28h != 0) {
        puVar3 = *(uint8_t **)(arg1 + 8);
        puVar4 = *(uint8_t **)arg1;
        if (puVar3 <= puVar4) goto code_r0x00018006f44a;
        uVar12 = *puVar4;
        puVar7 = puVar4 + 1;
        *(uint8_t **)arg1 = puVar7;
        if (puVar3 <= puVar7) goto code_r0x00018006f44a;
        uVar1 = *puVar7;
        *(uint8_t **)arg1 = puVar4 + 2;
        if ((((puVar3 <= puVar4 + 2) ||
             (uVar9 = (uint32_t)uVar12 * 0x100 + (uint32_t)uVar1, uVar9 != (uVar9 / 0x1f) * 0x1f)) ||
            ((uVar1 & 0x20) != 0)) || ((uVar12 & 0xf) != 8)) goto code_r0x00018006f44a;
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    do {
        if (*(int32_t *)(arg1 + 0x10) < 1) {
            func_0x00018006ef50(arg1);
        }
        uVar9 = *(uint32_t *)(arg1 + 0x14);
        *(uint32_t *)(arg1 + 0x14) = uVar9 >> 1;
        iVar5 = *(int32_t *)(arg1 + 0x10) + -1;
        *(int32_t *)(arg1 + 0x10) = iVar5;
        var_a24h._0_4_ = uVar9;
        if (iVar5 < 2) {
            func_0x00018006ef50(arg1);
        }
        uVar10 = *(uint32_t *)(arg1 + 0x14);
        uVar17 = uVar10 >> 2;
        uVar13 = *(int32_t *)(arg1 + 0x10) - 2;
        *(uint32_t *)(arg1 + 0x14) = uVar17;
        *(uint32_t *)(arg1 + 0x10) = uVar13;
        uVar10 = uVar10 & 3;
        if (uVar10 == 0) {
            uVar10 = uVar13 & 7;
            if (uVar10 != 0) {
                if ((int32_t)uVar13 < (int32_t)uVar10) {
                    func_0x00018006ef50(arg1);
                }
                *(uint32_t *)(arg1 + 0x14) = *(uint32_t *)(arg1 + 0x14) >> ((uint8_t)uVar10 & 0x1f);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - uVar10;
                uVar13 = *(uint32_t *)(arg1 + 0x10);
                uVar17 = *(uint32_t *)(arg1 + 0x14);
            }
            uVar18 = (uint64_t)uVar17;
            iVar5 = 0;
            uVar15 = uVar18;
            if (0 < (int32_t)uVar13) {
                do {
                    uVar16 = uVar15;
                    uVar13 = uVar13 - 8;
                    iVar8 = (int64_t)iVar5;
                    uVar15 = uVar16 >> 8;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = (uint8_t)uVar18;
                    uVar18 = uVar15 & 0xff;
                } while (0 < (int32_t)uVar13);
                *(uint32_t *)(arg1 + 0x10) = uVar13;
                *(int32_t *)(arg1 + 0x14) = (int32_t)(uVar16 >> 8);
            }
            if ((int32_t)uVar13 < 0) break;
            if (iVar5 < 4) {
                puVar3 = *(uint8_t **)(arg1 + 8);
                do {
                    puVar4 = *(uint8_t **)arg1;
                    if (puVar4 < puVar3) {
                        uVar12 = *puVar4;
                        *(uint8_t **)arg1 = puVar4 + 1;
                    } else {
                        uVar12 = 0;
                    }
                    iVar8 = (int64_t)iVar5;
                    iVar5 = iVar5 + 1;
                    var_a28h[iVar8] = uVar12;
                } while (iVar5 < 4);
            }
            uVar10 = (uint32_t)var_a28h[1] * 0x100 + (uint32_t)var_a28h[0];
            if ((((uint32_t)var_a28h[3] * 0x100 + (uint32_t)var_a28h[2] != (uVar10 ^ 0xffff)) ||
                (uVar15 = (uint64_t)uVar10, *(uint64_t *)(arg1 + 8) < *(int64_t *)arg1 + uVar15)) ||
               ((*(uint64_t *)(arg1 + 0x28) < *(int64_t *)(arg1 + 0x18) + (uint64_t)uVar10 &&
                (iVar5 = fcn.18006f0e0(arg1, *(int64_t *)(arg1 + 0x18), (uint64_t)uVar10), iVar5 == 0)))) break;
            func_0x000180498030(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)arg1, uVar15);
            *(uint64_t *)arg1 = *(int64_t *)arg1 + uVar15;
            *(int64_t *)(arg1 + 0x18) = *(int64_t *)(arg1 + 0x18) + uVar15;
        } else {
            if (uVar10 == 3) break;
            if (uVar10 == 1) {
                iVar5 = fcn.18006ed00(arg1 + 0x34, 0x1805ab3a0, 0x120);
                if (iVar5 == 0) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, 0x1805b5360, 0x20);
            } else {
                if ((int32_t)uVar13 < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar9 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar9 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 5) {
                    func_0x00018006ef50(arg1);
                }
                uVar10 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -5;
                *(uint32_t *)(arg1 + 0x14) = uVar10 >> 5;
                if (*(int32_t *)(arg1 + 0x10) < 4) {
                    func_0x00018006ef50(arg1);
                }
                uVar13 = *(uint32_t *)(arg1 + 0x14);
                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -4;
                iVar5 = *(int32_t *)(arg1 + 0x10);
                *(uint32_t *)(arg1 + 0x14) = uVar13 >> 4;
                _var_228h = SUB1615(ZEXT816(0), 0);
                uVar13 = (uVar13 & 0xf) + 4;
                uVar15 = (uint64_t)uVar13;
                var_219h._0_4_ = 0;
                if (uVar13 != 0) {
                    uVar18 = 0;
                    do {
                        if (iVar5 < 3) {
                            func_0x00018006ef50(arg1);
                        }
                        uVar13 = *(uint32_t *)(arg1 + 0x14);
                        iVar5 = *(int32_t *)(arg1 + 0x10) + -3;
                        *(uint32_t *)(arg1 + 0x14) = uVar13 >> 3;
                        uVar12 = *(uint8_t *)(uVar18 + 0x18063d270);
                        uVar17 = (int32_t)uVar18 + 1;
                        uVar18 = (uint64_t)uVar17;
                        *(int32_t *)(arg1 + 0x10) = iVar5;
                        *(uint8_t *)((int64_t)&var_228h + (uint64_t)uVar12) = (uint8_t)uVar13 & 7;
                    } while ((int32_t)uVar17 < (int32_t)uVar15);
                }
                iVar5 = fcn.18006ed00((int64_t)&var_a18h, (int64_t)&var_228h, 0x13);
                if (iVar5 == 0) break;
                uVar13 = (uVar9 & 0x1f) + 0x101;
                iVar6 = 0;
                uVar9 = (uVar10 & 0x1f) + 1;
                iVar5 = uVar9 + uVar13;
                do {
                    uVar10 = fcn.18006efb0(arg1, (int64_t)&var_a18h);
                    if (0x12 < uVar10) goto code_r0x00018006f44a;
                    if ((int32_t)uVar10 < 0x10) {
                        iVar8 = (int64_t)iVar6;
                        iVar6 = iVar6 + 1;
                        *(char *)((int64_t)&var_208h + iVar8) = (char)uVar10;
                    } else {
                        if (uVar10 == 0x10) {
                            if (*(int32_t *)(arg1 + 0x10) < 2) {
                                func_0x00018006ef50(arg1);
                            }
                            uVar10 = *(uint32_t *)(arg1 + 0x14);
                            *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -2;
                            *(uint32_t *)(arg1 + 0x14) = uVar10 >> 2;
                            if (iVar6 == 0) goto code_r0x00018006f44a;
                            iVar14 = (uVar10 & 3) + 3;
                            uVar15 = (uint64_t)(&var_209h)[iVar6];
                        } else {
                            uVar15 = 0;
                            if (uVar10 == 0x11) {
                                if (*(int32_t *)(arg1 + 0x10) < 3) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -3;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 3;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 7) + 3;
                            } else {
                                if (uVar10 != 0x12) goto code_r0x00018006f44a;
                                if (*(int32_t *)(arg1 + 0x10) < 7) {
                                    func_0x00018006ef50(arg1);
                                }
                                *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) + -7;
                                uVar10 = *(uint32_t *)(arg1 + 0x14) >> 7;
                                iVar14 = (*(uint32_t *)(arg1 + 0x14) & 0x7f) + 0xb;
                            }
                            *(uint32_t *)(arg1 + 0x14) = uVar10;
                        }
                        if (iVar5 - iVar6 < iVar14) goto code_r0x00018006f44a;
                        func_0x0001804986e0((int64_t)&var_208h + (int64_t)iVar6, uVar15 & 0xff, iVar14);
                        iVar6 = iVar6 + iVar14;
                    }
                } while (iVar6 < iVar5);
                if ((iVar6 != iVar5) ||
                   (iVar5 = fcn.18006ed00(arg1 + 0x34, (int64_t)&var_208h, (uint64_t)uVar13), iVar5 == 0)) break;
                iVar5 = fcn.18006ed00(arg1 + 0x818, (int64_t)&var_208h + (uint64_t)uVar13, (uint64_t)uVar9);
            }
            if (iVar5 == 0) break;
            arg2_00 = *(undefined **)(arg1 + 0x18);
            while( true ) {
                while( true ) {
                    iVar5 = fcn.18006efb0(arg1, arg1 + 0x34);
                    if (0xff < iVar5) break;
                    if (iVar5 < 0) goto code_r0x00018006f44a;
                    if (*(undefined **)(arg1 + 0x28) <= arg2_00) {
                        iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, 1);
                        if (iVar6 == 0) goto code_r0x00018006f44a;
                        arg2_00 = *(undefined **)(arg1 + 0x18);
                    }
                    *arg2_00 = (char)iVar5;
                    arg2_00 = arg2_00 + 1;
                }
                if (iVar5 == 0x100) break;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b4ecc);
                uVar9 = *(uint32_t *)((int64_t)iVar5 * 4 + 0x1805b4d7c);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    uVar9 = uVar9 + ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10);
                }
                iVar5 = fcn.18006efb0(arg1, arg1 + 0x818);
                if (iVar5 < 0) goto code_r0x00018006f44a;
                iVar6 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1806115b0);
                iVar5 = *(int32_t *)((int64_t)iVar5 * 4 + 0x1805b5250);
                if (iVar6 != 0) {
                    if (*(int32_t *)(arg1 + 0x10) < iVar6) {
                        func_0x00018006ef50(arg1);
                    }
                    uVar10 = *(uint32_t *)(arg1 + 0x14);
                    *(int32_t *)(arg1 + 0x10) = *(int32_t *)(arg1 + 0x10) - iVar6;
                    *(uint32_t *)(arg1 + 0x14) = uVar10 >> ((uint8_t)iVar6 & 0x1f);
                    iVar5 = ((1 << ((uint8_t)iVar6 & 0x1f)) - 1U & uVar10) + iVar5;
                }
                if ((int64_t)arg2_00 - *(int64_t *)(arg1 + 0x20) < (int64_t)iVar5) goto code_r0x00018006f44a;
                if (*(undefined **)(arg1 + 0x28) < arg2_00 + (int32_t)uVar9) {
                    iVar6 = fcn.18006f0e0(arg1, (int64_t)arg2_00, (uint64_t)uVar9);
                    if (iVar6 == 0) goto code_r0x00018006f44a;
                    arg2_00 = *(undefined **)(arg1 + 0x18);
                }
                puVar11 = arg2_00 + -(int64_t)iVar5;
                if (iVar5 == 1) {
                    if (uVar9 != 0) {
                        func_0x0001804986e0(arg2_00, *puVar11, (int64_t)(int32_t)uVar9);
                        do {
                            arg2_00 = arg2_00 + 1;
                            uVar9 = uVar9 - 1;
                        } while (uVar9 != 0);
                    }
                } else {
                    for (; uVar9 != 0; uVar9 = uVar9 - 1) {
                        uVar2 = *puVar11;
                        puVar11 = puVar11 + 1;
                        *arg2_00 = uVar2;
                        arg2_00 = arg2_00 + 1;
                    }
                }
            }
            *(undefined **)(arg1 + 0x18) = arg2_00;
            uVar9 = (uint32_t)var_a24h;
        }
    } while ((uVar9 & 1) == 0);
code_r0x00018006f44a:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_a48);
    return;
}

// ============================================================
// Function: FUN_18006f850
// Address: 0x18006f850
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18006f850(int64_t arg1)
{
    char *pcVar1;
    char cVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = 0;
    while( true ) {
        pcVar1 = *(char **)(arg1 + 0xc0);
        if (pcVar1 < *(char **)(arg1 + 200)) {
            cVar2 = *pcVar1;
            *(char **)(arg1 + 0xc0) = pcVar1 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            cVar2 = '\0';
        } else {
            func_0x000180069750(arg1);
            cVar2 = **(char **)(arg1 + 0xc0);
            *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
        }
        if (cVar2 != *(char *)(uVar4 + 0x18063d290)) break;
        uVar3 = (int32_t)uVar4 + 1;
        uVar4 = (uint64_t)uVar3;
        if (7 < (int32_t)uVar3) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18006f8f0
// Address: 0x18006f8f0
// Size: 4032 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

undefined8
fcn.18006f8f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h,
             int64_t arg_40h, int64_t arg_c0h)
{
    uint8_t *puVar1;
    uint8_t *puVar2;
    char *pcVar3;
    uint8_t *puVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    undefined auVar7 [16];
    int32_t iVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    uint8_t uVar11;
    uint8_t uVar12;
    uint8_t uVar13;
    uint8_t uVar14;
    uint8_t uVar15;
    uint8_t uVar16;
    uint8_t uVar17;
    uint8_t uVar18;
    uint8_t uVar19;
    uint8_t uVar20;
    uint8_t uVar21;
    uint8_t uVar22;
    uint8_t uVar23;
    uint8_t uVar24;
    uint8_t uVar25;
    uint8_t uVar26;
    uint8_t uVar27;
    uint8_t uVar28;
    uint8_t uVar29;
    uint8_t uVar30;
    uint8_t uVar31;
    uint8_t uVar32;
    uint8_t uVar33;
    uint8_t uVar34;
    uint8_t uVar35;
    uint8_t uVar36;
    uint8_t uVar37;
    uint8_t uVar38;
    uint8_t uVar39;
    uint8_t uVar40;
    uint8_t uVar41;
    uint8_t uVar42;
    uint8_t uVar43;
    uint8_t uVar44;
    uint8_t uVar45;
    uint8_t uVar46;
    uint8_t uVar47;
    uint8_t uVar48;
    uint8_t uVar49;
    uint8_t uVar50;
    uint8_t uVar51;
    uint8_t uVar52;
    uint8_t uVar53;
    uint8_t uVar54;
    uint8_t uVar55;
    uint8_t uVar56;
    uint8_t uVar57;
    uint8_t uVar58;
    uint8_t uVar59;
    uint8_t uVar60;
    uint8_t uVar61;
    uint8_t uVar62;
    uint8_t uVar63;
    uint8_t uVar64;
    uint8_t uVar65;
    uint8_t uVar66;
    uint8_t uVar67;
    uint8_t uVar68;
    uint8_t uVar69;
    uint8_t uVar70;
    uint32_t uVar71;
    int64_t iVar72;
    uint8_t *puVar73;
    uint8_t uVar74;
    uint32_t uVar75;
    int32_t iVar76;
    uint32_t uVar77;
    int32_t iVar78;
    int64_t iVar79;
    char *pcVar80;
    int64_t iVar81;
    int32_t iVar82;
    uint32_t uVar83;
    char cVar84;
    int32_t iVar85;
    int32_t iVar86;
    uint64_t uVar87;
    undefined2 *puVar88;
    uint8_t uVar89;
    int32_t iVar90;
    int64_t iVar91;
    uint32_t uVar92;
    int64_t iVar93;
    uint8_t *puVar94;
    int32_t iVar95;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_89h;
    int64_t var_68h;
    int64_t var_5ch;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar90 = (int32_t)arg4;
    iVar82 = ((int32_t)arg_38h == 0x10) + 1;
    if ((((-1 < (int32_t)(uint32_t)arg_28h) && (-1 < (int32_t)(uint32_t)arg_30h)) &&
        (((uint32_t)arg_30h == 0 || ((int32_t)(uint32_t)arg_28h <= (int32_t)(0x7fffffff / (arg_30h & 0xffffffffU))))))
       && (-1 < (int32_t)((uint32_t)arg_28h * (uint32_t)arg_30h))) {
        iVar95 = iVar82 * iVar90;
        if ((-1 < iVar95) &&
           ((iVar95 == 0 ||
            ((int32_t)((uint32_t)arg_28h * (uint32_t)arg_30h) <= (int32_t)(0x7fffffff / (int64_t)iVar95))))) {
            uVar77 = iVar95 * (uint32_t)arg_28h;
            iVar8 = *(int32_t *)(*(int64_t *)arg1 + 8);
            iVar72 = func_0x00018046d050((int64_t)(int32_t)(uVar77 * (uint32_t)arg_30h));
            *(int64_t *)(arg1 + 0x18) = iVar72;
            if (iVar72 == 0) {
                return 0;
            }
            if (iVar8 < 0) {
                return 0;
            }
            if (((uint32_t)arg_28h != 0) && ((int32_t)(0x7fffffff / (arg_28h & 0xffffffffU)) < iVar8)) {
                return 0;
            }
            iVar78 = iVar8 * (uint32_t)arg_28h;
            if (iVar78 < 0) {
                return 0;
            }
            if ((int32_t)arg_38h < 0) {
                return 0;
            }
            if (((int32_t)arg_38h != 0) && ((int32_t)(0x7fffffff / (arg_38h & 0xffffffffU)) < iVar78)) {
                return 0;
            }
            if (0x7ffffff8 < iVar78 * (int32_t)arg_38h) {
                return 0;
            }
            uVar75 = iVar78 * (int32_t)arg_38h + 7U >> 3;
            if ((uint32_t)arg3 < (uVar75 + 1) * (uint32_t)arg_30h) {
                return 0;
            }
            if ((uint32_t)arg_30h != 0) {
                var_5ch._0_4_ = (uint32_t)arg_28h;
                var_5ch._4_4_ = 0;
                uVar83 = iVar82 * iVar8;
code_r0x00018006fa80:
                uVar74 = *(uint8_t *)arg2;
                if (4 < uVar74) {
                    return 0;
                }
                iVar81 = (uint64_t)(var_5ch._4_4_ * uVar77) + iVar72;
                iVar79 = iVar81;
                if ((int32_t)arg_38h < 8) {
                    if ((uint32_t)arg_28h < uVar75) {
                        return 0;
                    }
                    uVar83 = 1;
                    iVar79 = (uint64_t)(iVar90 * (uint32_t)arg_28h - uVar75) + iVar81;
                    var_5ch._0_4_ = uVar75;
                }
                iVar93 = iVar79 - (uint64_t)uVar77;
                if (var_5ch._4_4_ == 0) {
                    uVar74 = *(uint8_t *)((uint64_t)uVar74 + 0x1805b5244);
                }
                iVar82 = 0;
                if (0 < (int32_t)uVar83) {
                    iVar91 = 0;
                    do {
    // switch table (7 cases) at 0x18007085c
                        switch(uVar74) {
                        case 0:
                            goto code_r0x00018006fb20;
                        case 1:
                            goto code_r0x00018006fb40;
                        case 2:
                            goto code_r0x00018006fb60;
                        case 3:
                            goto code_r0x00018006fb80;
                        case 4:
                            goto code_r0x00018006fba0;
                        case 5:
                            goto code_r0x00018006fbf0;
                        case 6:
                            goto code_r0x00018006fc10;
                        }
                        iVar82 = iVar82 + 1;
                        iVar91 = iVar91 + 1;
                    } while (iVar82 < (int32_t)uVar83);
                }
                goto code_r0x00018006fbc9;
            }
code_r0x000180070374:
            if ((int32_t)arg_38h < 8) {
                if ((uint32_t)arg_30h != 0) {
                    iVar72 = *(int64_t *)(arg1 + 0x18);
                    uVar83 = 0;
                    do {
                        puVar73 = (uint8_t *)
                                  (((uint64_t)(uVar83 * uVar77) - (uint64_t)uVar75) + iVar72 +
                                  (uint64_t)(iVar90 * (uint32_t)arg_28h));
                        pcVar3 = (char *)((uint64_t)(uVar83 * uVar77) + iVar72);
                        if ((int32_t)arg_40h == 0) {
                            cVar84 = *(char *)((int64_t)(int32_t)arg_38h + 0x1805b5350);
                        } else {
                            cVar84 = '\x01';
                        }
                        iVar82 = iVar78;
                        pcVar80 = pcVar3;
                        if ((int32_t)arg_38h == 4) {
                            for (; 1 < iVar82; iVar82 = iVar82 + -2) {
                                *pcVar80 = (*puVar73 >> 4) * cVar84;
                                uVar74 = *puVar73;
                                puVar73 = puVar73 + 1;
                                pcVar80[1] = (uVar74 & 0xf) * cVar84;
                                pcVar80 = pcVar80 + 2;
                            }
                            if (0 < iVar82) {
                                *pcVar80 = (*puVar73 >> 4) * cVar84;
                            }
                        } else if ((int32_t)arg_38h == 2) {
                            for (; 3 < iVar82; iVar82 = iVar82 + -4) {
                                *pcVar80 = (*puVar73 >> 6) * cVar84;
                                pcVar80[1] = (*puVar73 >> 4 & 3) * cVar84;
                                pcVar80[2] = (*puVar73 >> 2 & 3) * cVar84;
                                uVar74 = *puVar73;
                                puVar73 = puVar73 + 1;
                                pcVar80[3] = (uVar74 & 3) * cVar84;
                                pcVar80 = pcVar80 + 4;
                            }
                            if (0 < iVar82) {
                                *pcVar80 = (*puVar73 >> 6) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (1 < iVar82) {
                                *pcVar80 = (*puVar73 >> 4 & 3) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (2 < iVar82) {
                                uVar74 = *puVar73 >> 2 & 3;
code_r0x00018007072e:
                                *pcVar80 = uVar74 * cVar84;
                            }
                        } else if ((int32_t)arg_38h == 1) {
                            for (; 7 < iVar82; iVar82 = iVar82 + -8) {
                                *pcVar80 = -((char)*puVar73 >> 7) * cVar84;
                                pcVar80[1] = (*puVar73 >> 6 & 1) * cVar84;
                                pcVar80[2] = (*puVar73 >> 5 & 1) * cVar84;
                                pcVar80[3] = (*puVar73 >> 4 & 1) * cVar84;
                                pcVar80[4] = (*puVar73 >> 3 & 1) * cVar84;
                                pcVar80[5] = (*puVar73 >> 2 & 1) * cVar84;
                                pcVar80[6] = (*puVar73 >> 1 & 1) * cVar84;
                                uVar74 = *puVar73;
                                puVar73 = puVar73 + 1;
                                pcVar80[7] = (uVar74 & 1) * cVar84;
                                pcVar80 = pcVar80 + 8;
                            }
                            if (0 < iVar82) {
                                *pcVar80 = -((char)*puVar73 >> 7) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (1 < iVar82) {
                                *pcVar80 = (*puVar73 >> 6 & 1) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (2 < iVar82) {
                                *pcVar80 = (*puVar73 >> 5 & 1) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (3 < iVar82) {
                                *pcVar80 = (*puVar73 >> 4 & 1) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (4 < iVar82) {
                                *pcVar80 = (*puVar73 >> 3 & 1) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (5 < iVar82) {
                                *pcVar80 = (*puVar73 >> 2 & 1) * cVar84;
                                pcVar80 = pcVar80 + 1;
                            }
                            if (6 < iVar82) {
                                uVar74 = *puVar73 >> 1 & 1;
                                goto code_r0x00018007072e;
                            }
                        }
                        if (iVar8 != iVar90) {
                            uVar71 = (uint32_t)arg_28h - 1;
                            uVar87 = (uint64_t)uVar71;
                            if (iVar8 == 1) {
                                while (-1 < (int32_t)uVar71) {
                                    iVar79 = (int64_t)((int32_t)uVar87 * 2);
                                    pcVar3[iVar79 + 1] = -1;
                                    pcVar80 = pcVar3 + uVar87;
                                    uVar71 = (int32_t)uVar87 - 1;
                                    uVar87 = (uint64_t)uVar71;
                                    pcVar3[iVar79] = *pcVar80;
                                }
                            } else if (-1 < (int32_t)uVar71) {
                                iVar82 = (uint32_t)arg_28h * 4;
                                iVar95 = ((uint32_t)arg_28h - 1) * 3;
                                do {
                                    iVar82 = iVar82 + -4;
                                    pcVar80 = pcVar3 + iVar82;
                                    uVar71 = (int32_t)uVar87 - 1;
                                    uVar87 = (uint64_t)uVar71;
                                    pcVar80[3] = -1;
                                    pcVar80[2] = pcVar3[(int64_t)iVar95 + 2];
                                    pcVar80[1] = pcVar3[(int64_t)iVar95 + 1];
                                    *pcVar80 = pcVar3[iVar95];
                                    iVar95 = iVar95 + -3;
                                } while (-1 < (int32_t)uVar71);
                            }
                        }
                        uVar83 = uVar83 + 1;
                        if ((uint32_t)arg_30h <= uVar83) {
                            return 1;
                        }
                    } while( true );
                }
            } else if ((int32_t)arg_38h == 0x10) {
                puVar88 = *(undefined2 **)(arg1 + 0x18);
                uVar77 = 0;
                arg_30h._0_4_ = iVar90 * (uint32_t)arg_28h * (uint32_t)arg_30h;
                if ((uint32_t)arg_30h != 0) {
                    do {
                        uVar77 = uVar77 + 1;
                        *puVar88 = CONCAT11(*(undefined *)puVar88, *(undefined *)((int64_t)puVar88 + 1));
                        puVar88 = puVar88 + 1;
                    } while (uVar77 < (uint32_t)arg_30h);
                }
            }
            return 1;
        }
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    return 0;
code_r0x00018006fc10:
    do {
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + iVar91) = *(uint8_t *)(arg2 + iVar91 + 1);
        iVar91 = iVar91 + 1;
    } while (iVar82 < (int32_t)uVar83);
    goto code_r0x00018006fbc9;
code_r0x00018006fbf0:
    do {
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + iVar91) = *(uint8_t *)(arg2 + iVar91 + 1);
        iVar91 = iVar91 + 1;
    } while (iVar82 < (int32_t)uVar83);
    goto code_r0x00018006fbc9;
code_r0x00018006fba0:
    do {
        pcVar3 = (char *)(iVar93 + iVar91);
        iVar91 = iVar91 + 1;
        cVar84 = '\0';
        if (*pcVar3 != '\0') {
            cVar84 = *pcVar3;
        }
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + -1 + iVar91) = cVar84 + *(uint8_t *)(arg2 + iVar91);
    } while (iVar82 < (int32_t)uVar83);
    goto code_r0x00018006fbc9;
code_r0x00018006fb80:
    do {
        puVar73 = (uint8_t *)(iVar93 + iVar91);
        iVar91 = iVar91 + 1;
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + -1 + iVar91) = (*puVar73 >> 1) + *(uint8_t *)(arg2 + iVar91);
    } while (iVar82 < (int32_t)uVar83);
    goto code_r0x00018006fbc9;
code_r0x00018006fb60:
    do {
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + iVar91) = *(uint8_t *)(arg2 + iVar91 + 1) + *(char *)(iVar93 + iVar91);
        iVar91 = iVar91 + 1;
    } while (iVar82 < (int32_t)uVar83);
    goto code_r0x00018006fbc9;
code_r0x00018006fb40:
    do {
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + iVar91) = *(uint8_t *)(arg2 + iVar91 + 1);
        iVar91 = iVar91 + 1;
    } while (iVar82 < (int32_t)uVar83);
    goto code_r0x00018006fbc9;
code_r0x00018006fb20:
    do {
        iVar82 = iVar82 + 1;
        *(uint8_t *)(iVar79 + iVar91) = *(uint8_t *)(arg2 + iVar91 + 1);
        iVar91 = iVar91 + 1;
    } while (iVar82 < (int32_t)uVar83);
code_r0x00018006fbc9:
    if ((int32_t)arg_38h == 8) {
        if (iVar8 != iVar90) {
            *(undefined *)(iVar8 + iVar79) = 0xff;
        }
        arg2 = arg2 + (int64_t)iVar8 + 1;
        puVar73 = (uint8_t *)(iVar79 + iVar90);
        puVar94 = (uint8_t *)(iVar93 + iVar90);
code_r0x00018006fc5f:
        if (iVar8 != iVar90) {
    // switch table (7 cases) at 0x180070878
            switch(uVar74) {
            case 0:
                iVar82 = (uint32_t)arg_28h - 1;
                if (iVar82 != 0) {
                    do {
                        uVar87 = 0;
                        if (0 < (int32_t)uVar83) {
                            do {
                                puVar73[uVar87] = *(uint8_t *)(arg2 + uVar87);
                                uVar71 = (int32_t)uVar87 + 1;
                                uVar87 = (uint64_t)uVar71;
                            } while ((int32_t)uVar71 < (int32_t)uVar83);
                        }
                        puVar73[(int32_t)uVar83] = 0xff;
                        iVar82 = iVar82 + -1;
                        puVar73 = puVar73 + iVar95;
                        arg2 = arg2 + (int32_t)uVar83;
                    } while (iVar82 != 0);
                }
                break;
            case 1:
                iVar82 = (uint32_t)arg_28h - 1;
                if (iVar82 != 0) {
                    do {
                        uVar87 = 0;
                        if (0 < (int32_t)uVar83) {
                            do {
                                puVar73[uVar87] = puVar73[(int32_t)uVar87 - iVar95] + *(uint8_t *)(arg2 + uVar87);
                                uVar71 = (int32_t)uVar87 + 1;
                                uVar87 = (uint64_t)uVar71;
                            } while ((int32_t)uVar71 < (int32_t)uVar83);
                        }
                        puVar73[(int32_t)uVar83] = 0xff;
                        iVar82 = iVar82 + -1;
                        puVar73 = puVar73 + iVar95;
                        arg2 = arg2 + (int32_t)uVar83;
                    } while (iVar82 != 0);
                }
                break;
            case 2:
                iVar82 = (uint32_t)arg_28h - 1;
                if (iVar82 != 0) {
                    do {
                        if (0 < (int32_t)uVar83) {
                            iVar86 = 0;
                            if (7 < uVar83) {
                                iVar85 = uVar83 - 1;
                                if ((((uint8_t *)(arg2 + iVar85) < puVar73) || (puVar73 + iVar85 < (uint64_t)arg2)) &&
                                   ((puVar94 + iVar85 < puVar73 || (puVar73 + iVar85 < puVar94)))) {
                                    if (uVar83 < 0x40) {
code_r0x00018006fe1f:
                                        uVar71 = uVar83 & 0x80000007;
                                        if ((int32_t)uVar71 < 0) {
                                            uVar71 = (uVar71 - 1 | 0xfffffff8) + 1;
                                        }
                                        iVar85 = iVar86;
                                        do {
                                            iVar86 = iVar85 + 8;
                                            uVar5 = *(undefined8 *)(puVar94 + iVar85);
                                            uVar6 = *(undefined8 *)(arg2 + iVar85);
                                            *(uint64_t *)(puVar73 + iVar85) =
                                                 CONCAT17((char)((uint64_t)uVar5 >> 0x38) +
                                                          (char)((uint64_t)uVar6 >> 0x38), 
                                                          CONCAT16((char)((uint64_t)uVar5 >> 0x30) +
                                                                   (char)((uint64_t)uVar6 >> 0x30), 
                                                                   CONCAT15((char)((uint64_t)uVar5 >> 0x28) +
                                                                            (char)((uint64_t)uVar6 >> 0x28), 
                                                                            CONCAT14((char)((uint64_t)uVar5 >> 0x20) +
                                                                                     (char)((uint64_t)uVar6 >> 0x20), 
                                                                                     CONCAT13((char)((uint64_t)uVar5 >>
                                                                                                    0x18) +
                                                                                              (char)((uint64_t)uVar6 >>
                                                                                                    0x18), 
                                                                                              CONCAT12((char)((uint64_t)
                                                                                                              uVar5 >> 
                                                            0x10) + (char)((uint64_t)uVar6 >> 0x10), 
                                                            CONCAT11((char)((uint64_t)uVar5 >> 8) +
                                                                     (char)((uint64_t)uVar6 >> 8), 
                                                                     (char)uVar5 + (char)uVar6)))))));
                                            iVar85 = iVar86;
                                        } while (iVar86 < (int32_t)(uVar83 - uVar71));
                                    } else {
                                        uVar71 = uVar83 & 0x8000003f;
                                        if ((int32_t)uVar71 < 0) {
                                            uVar71 = (uVar71 - 1 | 0xffffffc0) + 1;
                                        }
                                        iVar85 = iVar86;
                                        do {
                                            iVar86 = iVar85 + 0x40;
                                            puVar1 = (uint8_t *)(arg2 + iVar85);
                                            uVar74 = puVar1[1];
                                            uVar89 = puVar1[2];
                                            uVar9 = puVar1[3];
                                            uVar10 = puVar1[4];
                                            uVar11 = puVar1[5];
                                            uVar12 = puVar1[6];
                                            uVar13 = puVar1[7];
                                            uVar14 = puVar1[8];
                                            uVar15 = puVar1[9];
                                            uVar16 = puVar1[10];
                                            uVar17 = puVar1[0xb];
                                            uVar18 = puVar1[0xc];
                                            uVar19 = puVar1[0xd];
                                            uVar20 = puVar1[0xe];
                                            uVar21 = puVar1[0xf];
                                            puVar2 = puVar94 + iVar85;
                                            uVar22 = puVar2[1];
                                            uVar23 = puVar2[2];
                                            uVar24 = puVar2[3];
                                            uVar25 = puVar2[4];
                                            uVar26 = puVar2[5];
                                            uVar27 = puVar2[6];
                                            uVar28 = puVar2[7];
                                            uVar29 = puVar2[8];
                                            uVar30 = puVar2[9];
                                            uVar31 = puVar2[10];
                                            uVar32 = puVar2[0xb];
                                            uVar33 = puVar2[0xc];
                                            uVar34 = puVar2[0xd];
                                            uVar35 = puVar2[0xe];
                                            uVar36 = puVar2[0xf];
                                            puVar4 = (uint8_t *)(arg2 + (int64_t)iVar85 + 0x10);
                                            uVar37 = *puVar4;
                                            uVar38 = puVar4[1];
                                            uVar39 = puVar4[2];
                                            uVar40 = puVar4[3];
                                            uVar41 = puVar4[4];
                                            uVar42 = puVar4[5];
                                            uVar43 = puVar4[6];
                                            uVar44 = puVar4[7];
                                            uVar45 = puVar4[8];
                                            uVar46 = puVar4[9];
                                            uVar47 = puVar4[10];
                                            uVar48 = puVar4[0xb];
                                            uVar49 = puVar4[0xc];
                                            uVar50 = puVar4[0xd];
                                            uVar51 = puVar4[0xe];
                                            uVar52 = puVar4[0xf];
                                            puVar4 = puVar94 + (int64_t)iVar85 + 0x10;
                                            uVar53 = *puVar4;
                                            uVar54 = puVar4[1];
                                            uVar55 = puVar4[2];
                                            uVar56 = puVar4[3];
                                            uVar57 = puVar4[4];
                                            uVar58 = puVar4[5];
                                            uVar59 = puVar4[6];
                                            uVar60 = puVar4[7];
                                            uVar61 = puVar4[8];
                                            uVar62 = puVar4[9];
                                            uVar63 = puVar4[10];
                                            uVar64 = puVar4[0xb];
                                            uVar65 = puVar4[0xc];
                                            uVar66 = puVar4[0xd];
                                            uVar67 = puVar4[0xe];
                                            uVar68 = puVar4[0xf];
                                            puVar4 = puVar73 + iVar85;
                                            *puVar4 = *puVar2 + *puVar1;
                                            puVar4[1] = uVar22 + uVar74;
                                            puVar4[2] = uVar23 + uVar89;
                                            puVar4[3] = uVar24 + uVar9;
                                            puVar4[4] = uVar25 + uVar10;
                                            puVar4[5] = uVar26 + uVar11;
                                            puVar4[6] = uVar27 + uVar12;
                                            puVar4[7] = uVar28 + uVar13;
                                            puVar4[8] = uVar29 + uVar14;
                                            puVar4[9] = uVar30 + uVar15;
                                            puVar4[10] = uVar31 + uVar16;
                                            puVar4[0xb] = uVar32 + uVar17;
                                            puVar4[0xc] = uVar33 + uVar18;
                                            puVar4[0xd] = uVar34 + uVar19;
                                            puVar4[0xe] = uVar35 + uVar20;
                                            puVar4[0xf] = uVar36 + uVar21;
                                            puVar1 = puVar94 + (int64_t)iVar85 + 0x20;
                                            uVar74 = *puVar1;
                                            uVar89 = puVar1[1];
                                            uVar9 = puVar1[2];
                                            uVar10 = puVar1[3];
                                            uVar11 = puVar1[4];
                                            uVar12 = puVar1[5];
                                            uVar13 = puVar1[6];
                                            uVar14 = puVar1[7];
                                            uVar15 = puVar1[8];
                                            uVar16 = puVar1[9];
                                            uVar17 = puVar1[10];
                                            uVar18 = puVar1[0xb];
                                            uVar19 = puVar1[0xc];
                                            uVar20 = puVar1[0xd];
                                            uVar21 = puVar1[0xe];
                                            uVar22 = puVar1[0xf];
                                            puVar1 = (uint8_t *)(arg2 + (int64_t)iVar85 + 0x20);
                                            uVar23 = *puVar1;
                                            uVar24 = puVar1[1];
                                            uVar25 = puVar1[2];
                                            uVar26 = puVar1[3];
                                            uVar27 = puVar1[4];
                                            uVar28 = puVar1[5];
                                            uVar29 = puVar1[6];
                                            uVar30 = puVar1[7];
                                            uVar31 = puVar1[8];
                                            uVar32 = puVar1[9];
                                            uVar33 = puVar1[10];
                                            uVar34 = puVar1[0xb];
                                            uVar35 = puVar1[0xc];
                                            uVar36 = puVar1[0xd];
                                            uVar69 = puVar1[0xe];
                                            uVar70 = puVar1[0xf];
                                            puVar1 = puVar73 + (int64_t)iVar85 + 0x10;
                                            *puVar1 = uVar37 + uVar53;
                                            puVar1[1] = uVar38 + uVar54;
                                            puVar1[2] = uVar39 + uVar55;
                                            puVar1[3] = uVar40 + uVar56;
                                            puVar1[4] = uVar41 + uVar57;
                                            puVar1[5] = uVar42 + uVar58;
                                            puVar1[6] = uVar43 + uVar59;
                                            puVar1[7] = uVar44 + uVar60;
                                            puVar1[8] = uVar45 + uVar61;
                                            puVar1[9] = uVar46 + uVar62;
                                            puVar1[10] = uVar47 + uVar63;
                                            puVar1[0xb] = uVar48 + uVar64;
                                            puVar1[0xc] = uVar49 + uVar65;
                                            puVar1[0xd] = uVar50 + uVar66;
                                            puVar1[0xe] = uVar51 + uVar67;
                                            puVar1[0xf] = uVar52 + uVar68;
                                            auVar7 = *(undefined (*) [16])(puVar94 + (int64_t)iVar85 + 0x30);
                                            puVar1 = (uint8_t *)(arg2 + (int64_t)iVar85 + 0x30);
                                            uVar37 = *puVar1;
                                            uVar38 = puVar1[1];
                                            uVar39 = puVar1[2];
                                            uVar40 = puVar1[3];
                                            uVar41 = puVar1[4];
                                            uVar42 = puVar1[5];
                                            uVar43 = puVar1[6];
                                            uVar44 = puVar1[7];
                                            uVar45 = puVar1[8];
                                            uVar46 = puVar1[9];
                                            uVar47 = puVar1[10];
                                            uVar48 = puVar1[0xb];
                                            uVar49 = puVar1[0xc];
                                            uVar50 = puVar1[0xd];
                                            uVar51 = puVar1[0xe];
                                            uVar52 = puVar1[0xf];
                                            puVar1 = puVar73 + (int64_t)iVar85 + 0x20;
                                            *puVar1 = uVar23 + uVar74;
                                            puVar1[1] = uVar24 + uVar89;
                                            puVar1[2] = uVar25 + uVar9;
                                            puVar1[3] = uVar26 + uVar10;
                                            puVar1[4] = uVar27 + uVar11;
                                            puVar1[5] = uVar28 + uVar12;
                                            puVar1[6] = uVar29 + uVar13;
                                            puVar1[7] = uVar30 + uVar14;
                                            puVar1[8] = uVar31 + uVar15;
                                            puVar1[9] = uVar32 + uVar16;
                                            puVar1[10] = uVar33 + uVar17;
                                            puVar1[0xb] = uVar34 + uVar18;
                                            puVar1[0xc] = uVar35 + uVar19;
                                            puVar1[0xd] = uVar36 + uVar20;
                                            puVar1[0xe] = uVar69 + uVar21;
                                            puVar1[0xf] = uVar70 + uVar22;
                                            puVar1 = puVar73 + (int64_t)iVar85 + 0x30;
                                            *puVar1 = uVar37 + auVar7[0];
                                            puVar1[1] = uVar38 + auVar7[1];
                                            puVar1[2] = uVar39 + auVar7[2];
                                            puVar1[3] = uVar40 + auVar7[3];
                                            puVar1[4] = uVar41 + auVar7[4];
                                            puVar1[5] = uVar42 + auVar7[5];
                                            puVar1[6] = uVar43 + auVar7[6];
                                            puVar1[7] = uVar44 + auVar7[7];
                                            puVar1[8] = uVar45 + auVar7[8];
                                            puVar1[9] = uVar46 + auVar7[9];
                                            puVar1[10] = uVar47 + auVar7[10];
                                            puVar1[0xb] = uVar48 + auVar7[11];
                                            puVar1[0xc] = uVar49 + auVar7[12];
                                            puVar1[0xd] = uVar50 + auVar7[13];
                                            puVar1[0xe] = uVar51 + auVar7[14];
                                            puVar1[0xf] = uVar52 + auVar7[15];
                                            iVar85 = iVar86;
                                        } while (iVar86 < (int32_t)(uVar83 - uVar71));
                                        if (7 < ((uint8_t)uVar83 & 0x3f)) goto code_r0x00018006fe1f;
                                    }
                                    if ((int32_t)uVar83 <= iVar86) goto code_r0x00018006fe86;
                                }
                            }
                            do {
                                iVar85 = iVar86 + 1;
                                puVar73[iVar86] = puVar94[iVar86] + *(uint8_t *)(arg2 + iVar86);
                                iVar86 = iVar85;
                            } while (iVar85 < (int32_t)uVar83);
                        }
code_r0x00018006fe86:
                        puVar73[(int32_t)uVar83] = 0xff;
                        iVar82 = iVar82 + -1;
                        puVar73 = puVar73 + iVar95;
                        arg2 = arg2 + (int32_t)uVar83;
                        puVar94 = puVar94 + iVar95;
                    } while (iVar82 != 0);
                }
                break;
            case 3:
                iVar82 = (uint32_t)arg_28h - 1;
                if (iVar82 != 0) {
                    do {
                        uVar87 = 0;
                        if (0 < (int32_t)uVar83) {
                            do {
                                puVar73[uVar87] =
                                     (char)((uint32_t)puVar73[(int32_t)uVar87 - iVar95] + (uint32_t)puVar94[uVar87] >> 1
                                           ) + *(uint8_t *)(arg2 + uVar87);
                                uVar71 = (int32_t)uVar87 + 1;
                                uVar87 = (uint64_t)uVar71;
                            } while ((int32_t)uVar71 < (int32_t)uVar83);
                        }
                        puVar73[(int32_t)uVar83] = 0xff;
                        iVar82 = iVar82 + -1;
                        puVar73 = puVar73 + iVar95;
                        arg2 = arg2 + (int32_t)uVar83;
                        puVar94 = puVar94 + iVar95;
                    } while (iVar82 != 0);
                }
                break;
            case 4:
                uVar71 = (uint32_t)arg_28h;
                while (uVar71 = uVar71 - 1, uVar71 != 0) {
                    uVar87 = 0;
                    if (0 < (int32_t)uVar83) {
                        do {
                            iVar82 = (int32_t)uVar87 - iVar95;
                            uVar74 = puVar94[iVar82];
                            uVar89 = puVar73[iVar82];
                            iVar86 = (uint32_t)puVar94[uVar87] - (uint32_t)uVar74;
                            iVar82 = -iVar86;
                            if (0 < iVar86) {
                                iVar82 = iVar86;
                            }
                            iVar76 = (uint32_t)uVar89 - (uint32_t)uVar74;
                            iVar85 = -iVar76;
                            if (0 < iVar76) {
                                iVar85 = iVar76;
                            }
                            iVar86 = ((uint32_t)uVar89 - (uint32_t)uVar74) + iVar86;
                            iVar76 = -iVar86;
                            if (0 < iVar86) {
                                iVar76 = iVar86;
                            }
                            if (((iVar85 < iVar82) || (iVar76 < iVar82)) && (uVar89 = uVar74, iVar85 <= iVar76)) {
                                uVar89 = puVar94[uVar87];
                            }
                            puVar73[uVar87] = uVar89 + *(uint8_t *)(arg2 + uVar87);
                            uVar92 = (int32_t)uVar87 + 1;
                            uVar87 = (uint64_t)uVar92;
                        } while ((int32_t)uVar92 < (int32_t)uVar83);
                    }
                    puVar73[(int32_t)uVar83] = 0xff;
                    puVar73 = puVar73 + iVar95;
                    arg2 = arg2 + (int32_t)uVar83;
                    puVar94 = puVar94 + iVar95;
                }
                break;
            case 5:
                iVar82 = (uint32_t)arg_28h - 1;
                if (iVar82 != 0) {
                    do {
                        uVar87 = 0;
                        if (0 < (int32_t)uVar83) {
                            do {
                                puVar73[uVar87] = (puVar73[(int32_t)uVar87 - iVar95] >> 1) + *(uint8_t *)(arg2 + uVar87)
                                ;
                                uVar71 = (int32_t)uVar87 + 1;
                                uVar87 = (uint64_t)uVar71;
                            } while ((int32_t)uVar71 < (int32_t)uVar83);
                        }
                        puVar73[(int32_t)uVar83] = 0xff;
                        iVar82 = iVar82 + -1;
                        puVar73 = puVar73 + iVar95;
                        arg2 = arg2 + (int32_t)uVar83;
                    } while (iVar82 != 0);
                }
                break;
            case 6:
                iVar82 = (uint32_t)arg_28h - 1;
                if (iVar82 != 0) {
                    do {
                        uVar87 = 0;
                        if (0 < (int32_t)uVar83) {
                            do {
                                puVar73[uVar87] = puVar73[(int32_t)uVar87 - iVar95] + *(uint8_t *)(arg2 + uVar87);
                                uVar71 = (int32_t)uVar87 + 1;
                                uVar87 = (uint64_t)uVar71;
                            } while ((int32_t)uVar71 < (int32_t)uVar83);
                        }
                        puVar73[(int32_t)uVar83] = 0xff;
                        iVar82 = iVar82 + -1;
                        puVar73 = puVar73 + iVar95;
                        arg2 = arg2 + (int32_t)uVar83;
                    } while (iVar82 != 0);
                }
            }
            if (((int32_t)arg_38h == 0x10) && (uVar71 = 0, (uint32_t)arg_28h != 0)) {
                do {
                    *(undefined *)((int64_t)(int32_t)uVar83 + 1 + iVar81) = 0xff;
                    uVar71 = uVar71 + 1;
                    iVar81 = iVar81 + iVar95;
                } while (uVar71 < (uint32_t)arg_28h);
            }
            goto code_r0x000180070338;
        }
    } else {
        if ((int32_t)arg_38h == 0x10) {
            if (iVar8 != iVar90) {
                *(undefined2 *)((int32_t)uVar83 + iVar79) = 0xffff;
            }
            arg2 = arg2 + (int64_t)(int32_t)uVar83 + 1;
            puVar73 = (uint8_t *)(iVar79 + iVar95);
            puVar94 = (uint8_t *)(iVar93 + iVar95);
            goto code_r0x00018006fc5f;
        }
        arg2 = arg2 + 2;
        puVar73 = (uint8_t *)(iVar79 + 1);
        puVar94 = (uint8_t *)(iVar93 + 1);
        if (7 < (int32_t)arg_38h) goto code_r0x00018006fc5f;
    }
    uVar71 = ((uint32_t)var_5ch - 1) * uVar83;
    // switch table (7 cases) at 0x180070894
    switch(uVar74) {
    case 0:
        func_0x000180498030(puVar73, arg2, (int64_t)(int32_t)uVar71);
        break;
    case 1:
        uVar87 = 0;
        if (0 < (int32_t)uVar71) {
            do {
                puVar73[uVar87] = puVar73[(int32_t)((int32_t)uVar87 - uVar83)] + *(uint8_t *)(arg2 + uVar87);
                uVar92 = (int32_t)uVar87 + 1;
                uVar87 = (uint64_t)uVar92;
            } while ((int32_t)uVar92 < (int32_t)uVar71);
        }
        break;
    case 2:
        if (0 < (int32_t)uVar71) {
            iVar86 = 0;
            iVar82 = iVar86;
            if (7 < uVar71) {
                iVar85 = uVar71 - 1;
                if ((((uint8_t *)(arg2 + iVar85) < puVar73) || (iVar82 = 0, puVar73 + iVar85 < (uint64_t)arg2)) &&
                   ((puVar94 + iVar85 < puVar73 || (iVar82 = 0, puVar73 + iVar85 < puVar94)))) {
                    if (uVar71 < 0x40) {
code_r0x000180070200:
                        uVar92 = uVar71 & 0x80000007;
                        if ((int32_t)uVar92 < 0) {
                            uVar92 = (uVar92 - 1 | 0xfffffff8) + 1;
                        }
                        iVar82 = iVar86;
                        do {
                            iVar86 = iVar82 + 8;
                            uVar5 = *(undefined8 *)(puVar94 + iVar82);
                            uVar6 = *(undefined8 *)(arg2 + iVar82);
                            *(uint64_t *)(puVar73 + iVar82) =
                                 CONCAT17((char)((uint64_t)uVar5 >> 0x38) + (char)((uint64_t)uVar6 >> 0x38), 
                                          CONCAT16((char)((uint64_t)uVar5 >> 0x30) + (char)((uint64_t)uVar6 >> 0x30), 
                                                   CONCAT15((char)((uint64_t)uVar5 >> 0x28) +
                                                            (char)((uint64_t)uVar6 >> 0x28), 
                                                            CONCAT14((char)((uint64_t)uVar5 >> 0x20) +
                                                                     (char)((uint64_t)uVar6 >> 0x20), 
                                                                     CONCAT13((char)((uint64_t)uVar5 >> 0x18) +
                                                                              (char)((uint64_t)uVar6 >> 0x18), 
                                                                              CONCAT12((char)((uint64_t)uVar5 >> 0x10) +
                                                                                       (char)((uint64_t)uVar6 >> 0x10), 
                                                                                       CONCAT11((char)((uint64_t)uVar5
                                                                                                      >> 8) +
                                                                                                (char)((uint64_t)uVar6
                                                                                                      >> 8), 
                                                                                                (char)uVar5 +
                                                                                                (char)uVar6)))))));
                            iVar82 = iVar86;
                        } while (iVar86 < (int32_t)(uVar71 - uVar92));
                    } else {
                        uVar92 = uVar71 & 0x8000003f;
                        if ((int32_t)uVar92 < 0) {
                            uVar92 = (uVar92 - 1 | 0xffffffc0) + 1;
                        }
                        iVar82 = iVar86;
                        do {
                            iVar86 = iVar82 + 0x40;
                            puVar1 = (uint8_t *)(arg2 + iVar82);
                            uVar74 = puVar1[1];
                            uVar89 = puVar1[2];
                            uVar9 = puVar1[3];
                            uVar10 = puVar1[4];
                            uVar11 = puVar1[5];
                            uVar12 = puVar1[6];
                            uVar13 = puVar1[7];
                            uVar14 = puVar1[8];
                            uVar15 = puVar1[9];
                            uVar16 = puVar1[10];
                            uVar17 = puVar1[0xb];
                            uVar18 = puVar1[0xc];
                            uVar19 = puVar1[0xd];
                            uVar20 = puVar1[0xe];
                            uVar21 = puVar1[0xf];
                            puVar2 = puVar94 + iVar82;
                            uVar22 = puVar2[1];
                            uVar23 = puVar2[2];
                            uVar24 = puVar2[3];
                            uVar25 = puVar2[4];
                            uVar26 = puVar2[5];
                            uVar27 = puVar2[6];
                            uVar28 = puVar2[7];
                            uVar29 = puVar2[8];
                            uVar30 = puVar2[9];
                            uVar31 = puVar2[10];
                            uVar32 = puVar2[0xb];
                            uVar33 = puVar2[0xc];
                            uVar34 = puVar2[0xd];
                            uVar35 = puVar2[0xe];
                            uVar36 = puVar2[0xf];
                            puVar4 = (uint8_t *)(arg2 + (int64_t)iVar82 + 0x10);
                            uVar37 = *puVar4;
                            uVar38 = puVar4[1];
                            uVar39 = puVar4[2];
                            uVar40 = puVar4[3];
                            uVar41 = puVar4[4];
                            uVar42 = puVar4[5];
                            uVar43 = puVar4[6];
                            uVar44 = puVar4[7];
                            uVar45 = puVar4[8];
                            uVar46 = puVar4[9];
                            uVar47 = puVar4[10];
                            uVar48 = puVar4[0xb];
                            uVar49 = puVar4[0xc];
                            uVar50 = puVar4[0xd];
                            uVar51 = puVar4[0xe];
                            uVar52 = puVar4[0xf];
                            puVar4 = puVar94 + (int64_t)iVar82 + 0x10;
                            uVar53 = *puVar4;
                            uVar54 = puVar4[1];
                            uVar55 = puVar4[2];
                            uVar56 = puVar4[3];
                            uVar57 = puVar4[4];
                            uVar58 = puVar4[5];
                            uVar59 = puVar4[6];
                            uVar60 = puVar4[7];
                            uVar61 = puVar4[8];
                            uVar62 = puVar4[9];
                            uVar63 = puVar4[10];
                            uVar64 = puVar4[0xb];
                            uVar65 = puVar4[0xc];
                            uVar66 = puVar4[0xd];
                            uVar67 = puVar4[0xe];
                            uVar68 = puVar4[0xf];
                            puVar4 = puVar73 + iVar82;
                            *puVar4 = *puVar2 + *puVar1;
                            puVar4[1] = uVar22 + uVar74;
                            puVar4[2] = uVar23 + uVar89;
                            puVar4[3] = uVar24 + uVar9;
                            puVar4[4] = uVar25 + uVar10;
                            puVar4[5] = uVar26 + uVar11;
                            puVar4[6] = uVar27 + uVar12;
                            puVar4[7] = uVar28 + uVar13;
                            puVar4[8] = uVar29 + uVar14;
                            puVar4[9] = uVar30 + uVar15;
                            puVar4[10] = uVar31 + uVar16;
                            puVar4[0xb] = uVar32 + uVar17;
                            puVar4[0xc] = uVar33 + uVar18;
                            puVar4[0xd] = uVar34 + uVar19;
                            puVar4[0xe] = uVar35 + uVar20;
                            puVar4[0xf] = uVar36 + uVar21;
                            puVar1 = puVar94 + (int64_t)iVar82 + 0x20;
                            uVar74 = *puVar1;
                            uVar89 = puVar1[1];
                            uVar9 = puVar1[2];
                            uVar10 = puVar1[3];
                            uVar11 = puVar1[4];
                            uVar12 = puVar1[5];
                            uVar13 = puVar1[6];
                            uVar14 = puVar1[7];
                            uVar15 = puVar1[8];
                            uVar16 = puVar1[9];
                            uVar17 = puVar1[10];
                            uVar18 = puVar1[0xb];
                            uVar19 = puVar1[0xc];
                            uVar20 = puVar1[0xd];
                            uVar21 = puVar1[0xe];
                            uVar22 = puVar1[0xf];
                            puVar1 = (uint8_t *)(arg2 + (int64_t)iVar82 + 0x20);
                            uVar23 = *puVar1;
                            uVar24 = puVar1[1];
                            uVar25 = puVar1[2];
                            uVar26 = puVar1[3];
                            uVar27 = puVar1[4];
                            uVar28 = puVar1[5];
                            uVar29 = puVar1[6];
                            uVar30 = puVar1[7];
                            uVar31 = puVar1[8];
                            uVar32 = puVar1[9];
                            uVar33 = puVar1[10];
                            uVar34 = puVar1[0xb];
                            uVar35 = puVar1[0xc];
                            uVar36 = puVar1[0xd];
                            uVar69 = puVar1[0xe];
                            uVar70 = puVar1[0xf];
                            puVar1 = puVar73 + (int64_t)iVar82 + 0x10;
                            *puVar1 = uVar37 + uVar53;
                            puVar1[1] = uVar38 + uVar54;
                            puVar1[2] = uVar39 + uVar55;
                            puVar1[3] = uVar40 + uVar56;
                            puVar1[4] = uVar41 + uVar57;
                            puVar1[5] = uVar42 + uVar58;
                            puVar1[6] = uVar43 + uVar59;
                            puVar1[7] = uVar44 + uVar60;
                            puVar1[8] = uVar45 + uVar61;
                            puVar1[9] = uVar46 + uVar62;
                            puVar1[10] = uVar47 + uVar63;
                            puVar1[0xb] = uVar48 + uVar64;
                            puVar1[0xc] = uVar49 + uVar65;
                            puVar1[0xd] = uVar50 + uVar66;
                            puVar1[0xe] = uVar51 + uVar67;
                            puVar1[0xf] = uVar52 + uVar68;
                            auVar7 = *(undefined (*) [16])(puVar94 + (int64_t)iVar82 + 0x30);
                            puVar1 = (uint8_t *)(arg2 + (int64_t)iVar82 + 0x30);
                            uVar37 = *puVar1;
                            uVar38 = puVar1[1];
                            uVar39 = puVar1[2];
                            uVar40 = puVar1[3];
                            uVar41 = puVar1[4];
                            uVar42 = puVar1[5];
                            uVar43 = puVar1[6];
                            uVar44 = puVar1[7];
                            uVar45 = puVar1[8];
                            uVar46 = puVar1[9];
                            uVar47 = puVar1[10];
                            uVar48 = puVar1[0xb];
                            uVar49 = puVar1[0xc];
                            uVar50 = puVar1[0xd];
                            uVar51 = puVar1[0xe];
                            uVar52 = puVar1[0xf];
                            puVar1 = puVar73 + (int64_t)iVar82 + 0x20;
                            *puVar1 = uVar23 + uVar74;
                            puVar1[1] = uVar24 + uVar89;
                            puVar1[2] = uVar25 + uVar9;
                            puVar1[3] = uVar26 + uVar10;
                            puVar1[4] = uVar27 + uVar11;
                            puVar1[5] = uVar28 + uVar12;
                            puVar1[6] = uVar29 + uVar13;
                            puVar1[7] = uVar30 + uVar14;
                            puVar1[8] = uVar31 + uVar15;
                            puVar1[9] = uVar32 + uVar16;
                            puVar1[10] = uVar33 + uVar17;
                            puVar1[0xb] = uVar34 + uVar18;
                            puVar1[0xc] = uVar35 + uVar19;
                            puVar1[0xd] = uVar36 + uVar20;
                            puVar1[0xe] = uVar69 + uVar21;
                            puVar1[0xf] = uVar70 + uVar22;
                            puVar1 = puVar73 + (int64_t)iVar82 + 0x30;
                            *puVar1 = uVar37 + auVar7[0];
                            puVar1[1] = uVar38 + auVar7[1];
                            puVar1[2] = uVar39 + auVar7[2];
                            puVar1[3] = uVar40 + auVar7[3];
                            puVar1[4] = uVar41 + auVar7[4];
                            puVar1[5] = uVar42 + auVar7[5];
                            puVar1[6] = uVar43 + auVar7[6];
                            puVar1[7] = uVar44 + auVar7[7];
                            puVar1[8] = uVar45 + auVar7[8];
                            puVar1[9] = uVar46 + auVar7[9];
                            puVar1[10] = uVar47 + auVar7[10];
                            puVar1[0xb] = uVar48 + auVar7[11];
                            puVar1[0xc] = uVar49 + auVar7[12];
                            puVar1[0xd] = uVar50 + auVar7[13];
                            puVar1[0xe] = uVar51 + auVar7[14];
                            puVar1[0xf] = uVar52 + auVar7[15];
                            iVar82 = iVar86;
                        } while (iVar86 < (int32_t)(uVar71 - uVar92));
                        if (7 < ((uint8_t)uVar71 & 0x3f)) goto code_r0x000180070200;
                    }
                    iVar82 = iVar86;
                    if ((int32_t)uVar71 <= iVar86) break;
                }
            }
            do {
                iVar86 = iVar82 + 1;
                puVar73[iVar82] = *(uint8_t *)(arg2 + iVar82) + puVar94[iVar82];
                iVar82 = iVar86;
            } while (iVar86 < (int32_t)uVar71);
        }
        break;
    case 3:
        uVar87 = 0;
        if (0 < (int32_t)uVar71) {
            do {
                puVar73[uVar87] =
                     (char)((uint32_t)puVar73[(int32_t)((int32_t)uVar87 - uVar83)] + (uint32_t)puVar94[uVar87] >> 1) +
                     *(uint8_t *)(arg2 + uVar87);
                uVar92 = (int32_t)uVar87 + 1;
                uVar87 = (uint64_t)uVar92;
            } while ((int32_t)uVar92 < (int32_t)uVar71);
        }
        break;
    case 4:
        uVar87 = 0;
        if (0 < (int32_t)uVar71) {
            do {
                iVar82 = (int32_t)uVar87 - uVar83;
                uVar74 = puVar94[iVar82];
                uVar89 = puVar73[iVar82];
                iVar86 = (uint32_t)puVar94[uVar87] - (uint32_t)uVar74;
                iVar82 = -iVar86;
                if (0 < iVar86) {
                    iVar82 = iVar86;
                }
                iVar76 = (uint32_t)uVar89 - (uint32_t)uVar74;
                iVar85 = -iVar76;
                if (0 < iVar76) {
                    iVar85 = iVar76;
                }
                iVar86 = ((uint32_t)uVar89 - (uint32_t)uVar74) + iVar86;
                iVar76 = -iVar86;
                if (0 < iVar86) {
                    iVar76 = iVar86;
                }
                if (((iVar85 < iVar82) || (iVar76 < iVar82)) && (uVar89 = uVar74, iVar85 <= iVar76)) {
                    uVar89 = puVar94[uVar87];
                }
                puVar73[uVar87] = uVar89 + *(uint8_t *)(arg2 + uVar87);
                uVar92 = (int32_t)uVar87 + 1;
                uVar87 = (uint64_t)uVar92;
            } while ((int32_t)uVar92 < (int32_t)uVar71);
        }
        break;
    case 5:
        uVar87 = 0;
        if (0 < (int32_t)uVar71) {
            do {
                puVar73[uVar87] = (puVar73[(int32_t)((int32_t)uVar87 - uVar83)] >> 1) + *(uint8_t *)(arg2 + uVar87);
                uVar92 = (int32_t)uVar87 + 1;
                uVar87 = (uint64_t)uVar92;
            } while ((int32_t)uVar92 < (int32_t)uVar71);
        }
        break;
    case 6:
        uVar87 = 0;
        if (0 < (int32_t)uVar71) {
            do {
                puVar73[uVar87] = puVar73[(int32_t)((int32_t)uVar87 - uVar83)] + *(uint8_t *)(arg2 + uVar87);
                uVar92 = (int32_t)uVar87 + 1;
                uVar87 = (uint64_t)uVar92;
            } while ((int32_t)uVar92 < (int32_t)uVar71);
        }
    }
    arg2 = arg2 + (int32_t)uVar71;
code_r0x000180070338:
    var_5ch._4_4_ = var_5ch._4_4_ + 1;
    if ((uint32_t)arg_30h <= var_5ch._4_4_) goto code_r0x000180070374;
    goto code_r0x00018006fa80;
}

// ============================================================
// Function: FUN_1800708b0
// Address: 0x1800708b0
// Size: 3883 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_1530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1520h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1510h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1500h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ah
// WARNING: [rz-ghidra] Removing arg arg_1548h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_1h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_14f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1514h
// WARNING: [rz-ghidra] Detected overlap for variable var_1510h
// WARNING: [rz-ghidra] Detected overlap for variable var_14d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_14d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_1544h
// WARNING: [rz-ghidra] Detected overlap for variable var_497h
// WARNING: [rz-ghidra] Detected overlap for variable var_496h
// WARNING: [rz-ghidra] Detected overlap for variable var_495h
// WARNING: [rz-ghidra] Detected overlap for variable var_9h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a6h
// WARNING: [rz-ghidra] Detected overlap for variable var_1548h
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_153ch
// WARNING: [rz-ghidra] Detected overlap for variable var_209h
// WARNING: [rz-ghidra] Detected overlap for variable var_a28h
// WARNING: [rz-ghidra] Detected overlap for variable var_a27h
// WARNING: [rz-ghidra] Detected overlap for variable var_a25h
// WARNING: [rz-ghidra] Detected overlap for variable var_a26h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

void fcn.1800708b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    char cVar1;
    char cVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    undefined8 uVar7;
    code *pcVar8;
    int32_t *piVar9;
    bool bVar10;
    char cVar11;
    uint8_t uVar12;
    undefined2 uVar13;
    int32_t iVar14;
    int32_t iVar15;
    int32_t iVar16;
    int32_t iVar17;
    int64_t iVar18;
    int64_t iVar19;
    uint32_t *puVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    uint32_t *puVar23;
    undefined uVar24;
    int16_t iVar25;
    uint32_t uVar26;
    uint32_t **in_RCX;
    uint64_t uVar27;
    undefined *puVar28;
    uint32_t *puVar29;
    uint32_t uVar30;
    uint8_t *puVar31;
    char cVar32;
    uint32_t uVar33;
    uint32_t *arg1;
    uint32_t uVar34;
    uint64_t in_R9;
    uint8_t uVar35;
    uint8_t uVar36;
    int64_t unaff_GS_OFFSET;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    undefined4 unaff_XMM7_Da;
    undefined4 unaff_XMM7_Db;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    undefined4 unaff_XMM8_Da;
    undefined4 unaff_XMM8_Db;
    undefined4 unaff_XMM8_Dc;
    undefined4 unaff_XMM8_Dd;
    undefined4 unaff_XMM9_Da;
    undefined4 unaff_XMM9_Db;
    undefined4 unaff_XMM9_Dc;
    undefined4 unaff_XMM9_Dd;
    int64_t var_8h;
    uint32_t var_10h [6];
    int64_t var_1540h;
    int64_t var_1538h;
    int64_t var_1530h;
    int64_t var_1528h;
    undefined4 uStack_1520;
    undefined4 uStack_151c;
    int64_t var_1518h;
    undefined4 var_1510h;
    int64_t var_1508h;
    undefined4 uStack_1500;
    undefined4 uStack_14fc;
    int64_t var_14f8h;
    int64_t var_14e8h;
    undefined4 uStack_14e0;
    undefined4 uStack_14dc;
    int64_t var_14d8h;
    undefined4 var_14d0h;
    int64_t var_14c8h;
    undefined4 uStack_14c0;
    undefined4 uStack_14bc;
    int64_t var_14b8h;
    int64_t var_14b0h;
    int64_t var_14a8h;
    int64_t var_14a0h;
    int64_t var_1490h;
    int64_t var_1488h;
    int64_t var_4a8h;
    int64_t var_498h;
    int64_t var_98h;
    undefined8 uStack_48;
    int64_t var_20h;
    
    uStack_48 = 0x1800708cf;
    iVar18 = func_0x00018045a350();
    iVar18 = -iVar18;
    *(undefined4 *)(&stack0x00001530 + iVar18) = unaff_XMM6_Da;
    *(undefined4 *)(&stack0x00001534 + iVar18) = unaff_XMM6_Db;
    *(undefined4 *)(&stack0x00001538 + iVar18) = unaff_XMM6_Dc;
    *(undefined4 *)(&stack0x0000153c + iVar18) = unaff_XMM6_Dd;
    *(undefined4 *)(&stack0x00001520 + iVar18) = unaff_XMM7_Da;
    *(undefined4 *)(&stack0x00001524 + iVar18) = unaff_XMM7_Db;
    *(undefined4 *)(&stack0x00001528 + iVar18) = unaff_XMM7_Dc;
    *(undefined4 *)(&stack0x0000152c + iVar18) = unaff_XMM7_Dd;
    *(undefined4 *)(&stack0x00001510 + iVar18) = unaff_XMM8_Da;
    *(undefined4 *)(&stack0x00001514 + iVar18) = unaff_XMM8_Db;
    *(undefined4 *)(&stack0x00001518 + iVar18) = unaff_XMM8_Dc;
    *(undefined4 *)(&stack0x0000151c + iVar18) = unaff_XMM8_Dd;
    *(undefined4 *)(&stack0x00001500 + iVar18) = unaff_XMM9_Da;
    *(undefined4 *)(&stack0x00001504 + iVar18) = unaff_XMM9_Db;
    *(undefined4 *)(&stack0x00001508 + iVar18) = unaff_XMM9_Dc;
    *(undefined4 *)(&stack0x0000150c + iVar18) = unaff_XMM9_Dd;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar18);
    arg1 = *in_RCX;
    uVar30 = 0;
    in_RCX[2] = (uint32_t *)0x0;
    in_RCX[1] = (uint32_t *)0x0;
    in_RCX[3] = (uint32_t *)0x0;
    *(uint32_t ***)((int64_t)&arg_28h + iVar18) = in_RCX;
    *(undefined2 *)((int64_t)var_10h + iVar18 + -8) = 0;
    *(undefined *)((int64_t)var_10h + iVar18 + -6) = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070935;
    iVar14 = fcn.18006f850((int64_t)arg1);
    if (iVar14 != 0) {
        var_1530h = (int64_t)arg1;
        *(undefined *)((int64_t)var_10h + iVar18 + -0x10) = 0;
        *(undefined *)((int64_t)var_10h + iVar18 + -0xf) = 0;
        *(undefined4 *)((int64_t)var_10h + iVar18 + -4) = 0;
        bVar10 = true;
        *(undefined4 *)((int64_t)var_10h + iVar18 + -0xc) = 0;
        *(undefined4 *)((int64_t)var_10h + iVar18) = 0;
        *(undefined4 *)((int64_t)var_10h + iVar18 + 4) = 0;
        *(undefined4 *)((int64_t)var_10h + iVar18 + 8) = 0;
        uVar34 = uVar30;
        do {
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007096d;
            iVar14 = func_0x000180069950(arg1);
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070977;
            iVar15 = func_0x000180069950(arg1);
            uVar33 = iVar14 * 0x10000 + iVar15;
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070984;
            iVar14 = func_0x000180069950(arg1);
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007098e;
            iVar15 = func_0x000180069950(arg1);
            uVar26 = iVar15 + iVar14 * 0x10000;
            *(uint64_t *)((int64_t)&arg_30h + iVar18) = CONCAT44(uVar26, uVar33);
            if (uVar26 < 0x49484453) {
                if (uVar26 == 0x49484452) {
                    if ((!bVar10) || (uVar33 != 0xd)) break;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070b34;
                    iVar14 = func_0x000180069950(arg1);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070b3e;
                    iVar15 = func_0x000180069950(arg1);
                    *arg1 = iVar15 + iVar14 * 0x10000;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070b4d;
                    iVar14 = func_0x000180069950(arg1);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070b57;
                    iVar15 = func_0x000180069950(arg1);
                    uVar34 = iVar15 + iVar14 * 0x10000;
                    arg1[1] = uVar34;
                    if ((0x1000000 < uVar34) || (0x1000000 < *arg1)) break;
                    puVar31 = *(uint8_t **)(arg1 + 0x30);
                    puVar20 = arg1 + 0xc;
                    if (*(uint8_t **)(arg1 + 0x32) <= puVar31) {
                        if (*puVar20 == 0) {
                            *(undefined4 *)(in_RCX + 4) = 0;
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070b9d;
                        func_0x000180069750(arg1);
                        puVar31 = *(uint8_t **)(arg1 + 0x30);
                    }
                    uVar35 = *puVar31;
                    *(uint8_t **)(arg1 + 0x30) = puVar31 + 1;
                    *(uint32_t *)(in_RCX + 4) = (uint32_t)uVar35;
                    if ((((uVar35 != 1) && (uVar35 != 2)) && (uVar35 != 4)) && ((uVar35 != 8 && (uVar35 != 0x10))))
                    break;
                    puVar31 = *(uint8_t **)(arg1 + 0x30);
                    if (puVar31 < *(uint8_t **)(arg1 + 0x32)) {
code_r0x000180070bfa:
                        uVar35 = *puVar31;
                        puVar31 = puVar31 + 1;
                        *(uint8_t **)(arg1 + 0x30) = puVar31;
                        if (6 < uVar35) break;
                        if (uVar35 != 3) {
                            if ((uVar35 & 1) == 0) goto code_r0x000180070c3e;
                            break;
                        }
                        if (*(int32_t *)(in_RCX + 4) == 0x10) break;
                        *(undefined *)((int64_t)var_10h + iVar18 + -0x10) = 3;
                        cVar32 = '\x03';
                    } else {
                        if (*puVar20 != 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070bf3;
                            func_0x000180069750(arg1);
                            puVar31 = *(uint8_t **)(arg1 + 0x30);
                            goto code_r0x000180070bfa;
                        }
                        uVar35 = 0;
code_r0x000180070c3e:
                        cVar32 = *(char *)((int64_t)var_10h + iVar18 + -0x10);
                    }
                    if (puVar31 < *(uint8_t **)(arg1 + 0x32)) {
code_r0x000180070c60:
                        uVar36 = *puVar31;
                        puVar31 = puVar31 + 1;
                        *(uint8_t **)(arg1 + 0x30) = puVar31;
                        if (uVar36 != 0) break;
                    } else if (*puVar20 != 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070c59;
                        func_0x000180069750(arg1);
                        puVar31 = *(uint8_t **)(arg1 + 0x30);
                        goto code_r0x000180070c60;
                    }
                    if (puVar31 < *(uint8_t **)(arg1 + 0x32)) {
code_r0x000180070c92:
                        uVar36 = *puVar31;
                        puVar31 = puVar31 + 1;
                        *(uint8_t **)(arg1 + 0x30) = puVar31;
                        if (uVar36 != 0) break;
                    } else if (*puVar20 != 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070c8b;
                        func_0x000180069750(arg1);
                        puVar31 = *(uint8_t **)(arg1 + 0x30);
                        goto code_r0x000180070c92;
                    }
                    if (puVar31 < *(uint8_t **)(arg1 + 0x32)) {
code_r0x000180070cc4:
                        uVar36 = *puVar31;
                        in_R9 = (uint64_t)uVar36;
                        *(uint8_t **)(arg1 + 0x30) = puVar31 + 1;
                        if (1 < uVar36) break;
                    } else {
                        if (*puVar20 != 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070cbd;
                            func_0x000180069750(arg1);
                            puVar31 = *(uint8_t **)(arg1 + 0x30);
                            goto code_r0x000180070cc4;
                        }
                        in_R9 = in_R9 & 0xffffffffffffff00;
                    }
                    uVar34 = *arg1;
                    if ((uVar34 == 0) || (uVar26 = arg1[1], uVar26 == 0)) break;
                    *(uint32_t *)((int64_t)var_10h + iVar18 + 4) = (uint32_t)uVar35;
                    uVar21 = 0x40000000 / (uint64_t)uVar34;
                    if (cVar32 == '\0') {
                        uVar33 = (uVar35 & 2 | 1) + (uVar35 >> 2 & 1);
                        uVar34 = (uint32_t)(uVar21 / uVar33);
                        arg1[2] = uVar33;
                    } else {
                        arg1[2] = 1;
                        uVar34 = (uint32_t)(uVar21 >> 2);
                    }
                    if (uVar34 < uVar26) break;
                    bVar10 = false;
                    *(uint32_t *)((int64_t)var_10h + iVar18) = (uint32_t)in_R9 & 0xff;
code_r0x000180070d4c:
                    uVar34 = *(uint32_t *)((int64_t)var_10h + iVar18 + -0xc);
                } else {
                    if (uVar26 == 0x43674249) {
                        *(undefined4 *)((int64_t)var_10h + iVar18 + 8) = 1;
                        if (uVar33 != 0) {
                            if ((int32_t)uVar33 < 0) {
                                *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg1 + 0x32);
                            } else if ((*(int64_t *)(arg1 + 4) == 0) ||
                                      ((int32_t)uVar33 <= (int32_t)(arg1[0x32] - arg1[0x30]))) {
                                *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + (int64_t)(int32_t)uVar33;
                            } else {
                                uVar7 = *(undefined8 *)(arg1 + 10);
                                *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg1 + 0x32);
                                pcVar8 = *(code **)(arg1 + 6);
                                *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070b06;
                                (*pcVar8)(uVar7);
                            }
                        }
                        goto code_r0x000180070d51;
                    }
                    if (uVar26 != 0x49444154) {
                        if (uVar26 != 0x49454e44) goto code_r0x000180070d7a;
                        if ((bVar10) || (puVar20 = in_RCX[1], puVar20 == (uint32_t *)0x0)) break;
                        uVar30 = ((*(int32_t *)(in_RCX + 4) * *arg1 + 7 >> 3) * arg1[2] + 1) * arg1[1];
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070a0d;
                        iVar19 = func_0x00018046d050((int64_t)(int32_t)uVar30);
                        if (iVar19 == 0) {
                            in_RCX[2] = (uint32_t *)0x0;
                            break;
                        }
                        iVar14 = *(int32_t *)((int64_t)var_10h + iVar18 + 8);
                        var_14a0h = (int64_t)*(int32_t *)((int64_t)var_10h + iVar18 + -4) + (int64_t)puVar20;
                        uVar21 = 0;
                        var_14a8h = (int64_t)puVar20;
                        *(uint32_t *)((int64_t)&var_20h + iVar18) = (uint32_t)(iVar14 == 0);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007109a;
                        iVar15 = fcn.18006f180((int64_t)&var_14a8h, iVar19, (uint64_t)uVar30, in_R9, 
                                               *(int64_t *)((int64_t)&var_20h + iVar18));
                        if (iVar15 == 0) {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007178e;
                            func_0x000180460d90(var_1488h);
                            in_RCX[2] = (uint32_t *)0x0;
                            break;
                        }
                        in_RCX[2] = (uint32_t *)var_1488h;
                        if (var_1488h == 0) break;
                        puVar20 = in_RCX[1];
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x1800710be;
                        func_0x000180460d90(puVar20);
                        in_RCX[1] = (uint32_t *)0x0;
                        uVar34 = arg1[2];
                        uVar30 = uVar34 + 1;
                        uVar22 = (uint64_t)uVar30;
                        *(uint32_t *)((int64_t)var_10h + iVar18 + -4) = uVar30;
                        if (((uVar30 != 4) || (*(char *)((int64_t)var_10h + iVar18 + -0x10) != '\0')) &&
                           (*(char *)((int64_t)var_10h + iVar18 + -0xf) == '\0')) {
                            uVar22 = (uint64_t)uVar34;
                            *(uint32_t *)((int64_t)var_10h + iVar18 + -4) = uVar34;
                        }
                        uVar30 = (int32_t)var_1490h - (int32_t)var_1488h;
                        arg1[3] = (uint32_t)uVar22;
                        iVar15 = *(int32_t *)(in_RCX + 4);
                        var_1538h = (int64_t)in_RCX[2];
                        puVar20 = *in_RCX;
                        *(uint32_t *)((int64_t)var_10h + iVar18 + -0xc) = uVar30;
                        *(int32_t *)((int64_t)&arg_38h + iVar18) = iVar15;
                        if (*(int32_t *)((int64_t)var_10h + iVar18) == 0) {
                            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar18) =
                                 *(undefined4 *)((int64_t)var_10h + iVar18 + 4);
                            *(int32_t *)(&stack0xfffffffffffffff0 + iVar18) = iVar15;
                            *(uint32_t *)(&stack0xffffffffffffffe8 + iVar18) = puVar20[1];
                            *(uint32_t *)((int64_t)&var_20h + iVar18) = *puVar20;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007114a;
                            iVar15 = fcn.18006f8f0((int64_t)in_RCX, var_1538h, (uint64_t)uVar30, uVar22, 
                                                   *(int64_t *)((int64_t)&var_20h + iVar18), 
                                                   *(int64_t *)(&stack0xffffffffffffffe8 + iVar18), 
                                                   *(int64_t *)(&stack0xfffffffffffffff0 + iVar18), 
                                                   *(int64_t *)(&stack0xfffffffffffffff8 + iVar18), 
                                                   *(int64_t *)(&stack0x00000078 + iVar18));
                            if (iVar15 != 0) goto code_r0x000180071410;
                            break;
                        }
                        uVar30 = *puVar20;
                        if ((int32_t)uVar30 < 0) break;
                        uVar34 = puVar20[1];
                        if ((int32_t)uVar34 < 0) break;
                        if (uVar34 != 0) {
                            if ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar34) < (int32_t)uVar30) break;
                            uVar22 = (uint64_t)*(uint32_t *)((int64_t)var_10h + iVar18 + -4);
                        }
                        iVar14 = uVar30 * uVar34;
                        if (-1 < iVar14) {
                            iVar15 = (int32_t)uVar22 * ((iVar15 == 0x10) + 1);
                            if ((-1 < iVar15) && ((iVar15 == 0 || (iVar14 <= (int32_t)(0x7fffffff / (int64_t)iVar15)))))
                            {
                                *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x1800711c1;
                                iVar19 = func_0x00018046d050((int64_t)(iVar14 * iVar15));
                                *(int64_t *)((int64_t)&arg_30h + iVar18) = iVar19;
                                if (iVar19 != 0) {
                                    *(undefined4 *)((int64_t)var_10h + iVar18 + 0x10) = 0;
                                    goto code_r0x000180071200;
                                }
                            }
                        }
                        break;
                    }
                    if ((bVar10) ||
                       ((((bool)*(char *)((int64_t)var_10h + iVar18 + -0x10) != bVar10 && (uVar34 == 0)) ||
                        (iVar14 = *(int32_t *)((int64_t)var_10h + iVar18 + -4), uVar26 = uVar33 + iVar14,
                        (int32_t)uVar26 < iVar14)))) break;
                    if (uVar30 < uVar26) {
                        if (uVar30 != 0) goto code_r0x000180070a67;
                        uVar30 = 0x1000;
                        if (0x1000 < uVar33) {
                            uVar30 = uVar33;
                        }
                        for (; uVar30 < uVar26; uVar30 = uVar30 * 2) {
code_r0x000180070a67:
                        }
                        puVar20 = in_RCX[1];
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070a7c;
                        puVar20 = (uint32_t *)func_0x00018046d060(puVar20, uVar30);
                        if (puVar20 == (uint32_t *)0x0) break;
                        in_RCX[1] = puVar20;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070aa0;
                    iVar14 = func_0x000180069890(arg1);
                    if (iVar14 == 0) break;
                    *(uint32_t *)((int64_t)var_10h + iVar18 + -4) = uVar26;
                }
            } else if (uVar26 == 0x504c5445) {
                if ((bVar10) || (0x300 < uVar33)) break;
                uVar34 = uVar33 / 3;
                *(uint32_t *)((int64_t)var_10h + iVar18 + -0xc) = uVar34;
                if (uVar34 * 3 != uVar33) break;
                uVar26 = 0;
                if (uVar34 != 0) {
                    do {
                        puVar28 = *(undefined **)(arg1 + 0x30);
                        if (puVar28 < *(undefined **)(arg1 + 0x32)) {
                            uVar24 = *puVar28;
                            puVar28 = puVar28 + 1;
                            *(undefined **)(arg1 + 0x30) = puVar28;
                        } else if (arg1[0xc] == 0) {
                            uVar24 = 0;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070f8d;
                            func_0x000180069750(arg1);
                            uVar24 = **(undefined **)(arg1 + 0x30);
                            puVar28 = *(undefined **)(arg1 + 0x30) + 1;
                            *(undefined **)(arg1 + 0x30) = puVar28;
                        }
                        uVar33 = uVar26 * 4;
                        *(undefined *)((int64_t)&var_498h + (uint64_t)uVar33) = uVar24;
                        if (puVar28 < *(undefined **)(arg1 + 0x32)) {
                            uVar24 = *puVar28;
                            puVar28 = puVar28 + 1;
                            *(undefined **)(arg1 + 0x30) = puVar28;
                        } else if (arg1[0xc] == 0) {
                            uVar24 = 0;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070fdb;
                            func_0x000180069750();
                            uVar24 = **(undefined **)(arg1 + 0x30);
                            puVar28 = *(undefined **)(arg1 + 0x30) + 1;
                            *(undefined **)(arg1 + 0x30) = puVar28;
                        }
                        *(undefined *)((int64_t)&var_498h + (uint64_t)(uVar33 + 1)) = uVar24;
                        if (puVar28 < *(undefined **)(arg1 + 0x32)) {
                            uVar24 = *puVar28;
                            *(undefined **)(arg1 + 0x30) = puVar28 + 1;
                        } else if (arg1[0xc] == 0) {
                            uVar24 = 0;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180071029;
                            func_0x000180069750();
                            uVar24 = **(undefined **)(arg1 + 0x30);
                            *(undefined **)(arg1 + 0x30) = *(undefined **)(arg1 + 0x30) + 1;
                        }
                        uVar26 = uVar26 + 1;
                        *(undefined *)((int64_t)&var_498h + (uint64_t)(uVar33 + 2)) = uVar24;
                        *(undefined *)((int64_t)&var_498h + (uint64_t)(uVar33 + 3)) = 0xff;
                    } while (uVar26 < uVar34);
                }
            } else {
                if (uVar26 == 0x74524e53) {
                    if ((!bVar10) && (in_RCX[1] == (uint32_t *)0x0)) {
                        if ((bool)*(char *)((int64_t)var_10h + iVar18 + -0x10) == bVar10) {
                            uVar26 = arg1[2];
                            if (((uVar26 & 1) != 0) && (uVar33 == uVar26 * 2)) {
                                iVar14 = *(int32_t *)(in_RCX + 4);
                                *(undefined *)((int64_t)var_10h + iVar18 + -0xf) = 1;
                                if (iVar14 == 0x10) {
                                    iVar14 = 0;
                                    if (0 < (int32_t)uVar26) {
                                        do {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070ec8;
                                            uVar13 = func_0x000180069950(arg1);
                                            iVar19 = (int64_t)iVar14;
                                            iVar14 = iVar14 + 1;
                                            *(undefined2 *)((int64_t)&var_4a8h + iVar19 * 2) = uVar13;
                                        } while (iVar14 < (int32_t)arg1[2]);
                                    }
                                } else {
                                    iVar14 = 0;
                                    if (0 < (int32_t)uVar26) {
                                        do {
                                            cVar32 = *(char *)((int64_t)*(int32_t *)(in_RCX + 4) + 0x1805b5350);
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070f02;
                                            cVar11 = func_0x000180069950(arg1);
                                            iVar19 = (int64_t)iVar14;
                                            iVar14 = iVar14 + 1;
                                            *(char *)((int64_t)var_10h + iVar19 + iVar18 + -8) = cVar11 * cVar32;
                                        } while (iVar14 < (int32_t)arg1[2]);
                                        goto code_r0x000180070d4c;
                                    }
                                }
                                goto code_r0x000180070d51;
                            }
                        } else if ((uVar34 != 0) && (uVar33 <= uVar34)) {
                            uVar34 = 0;
                            *(undefined *)((int64_t)var_10h + iVar18 + -0x10) = 4;
                            if (uVar33 != 0) {
                                do {
                                    puVar28 = *(undefined **)(arg1 + 0x30);
                                    if (puVar28 < *(undefined **)(arg1 + 0x32)) {
                                        uVar24 = *puVar28;
                                        *(undefined **)(arg1 + 0x30) = puVar28 + 1;
                                    } else if (arg1[0xc] == 0) {
                                        uVar24 = 0;
                                    } else {
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070e5d;
                                        func_0x000180069750(arg1);
                                        uVar24 = **(undefined **)(arg1 + 0x30);
                                        *(undefined **)(arg1 + 0x30) = *(undefined **)(arg1 + 0x30) + 1;
                                    }
                                    iVar14 = uVar34 * 4;
                                    uVar34 = uVar34 + 1;
                                    *(undefined *)((int64_t)&var_498h + (uint64_t)(iVar14 + 3)) = uVar24;
                                } while (uVar34 < uVar33);
                            }
                            goto code_r0x000180070d4c;
                        }
                    }
                    break;
                }
code_r0x000180070d7a:
                if ((bVar10) || ((*(uint32_t *)((int64_t)&arg_30h + iVar18 + 4) & 0x20000000) == 0)) break;
                if (uVar33 != 0) {
                    if ((int32_t)uVar33 < 0) {
                        *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg1 + 0x32);
                    } else if ((*(int64_t *)(arg1 + 4) == 0) || ((int32_t)uVar33 <= (int32_t)(arg1[0x32] - arg1[0x30])))
                    {
                        *(int64_t *)(arg1 + 0x30) = *(int64_t *)(arg1 + 0x30) + (int64_t)(int32_t)uVar33;
                    } else {
                        uVar7 = *(undefined8 *)(arg1 + 10);
                        *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg1 + 0x32);
                        pcVar8 = *(code **)(arg1 + 6);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070dd7;
                        (*pcVar8)(uVar7);
                    }
                }
            }
code_r0x000180070d51:
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070d59;
            func_0x000180069950(arg1);
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180070d61;
            func_0x000180069950(arg1);
        } while( true );
    }
    goto code_r0x0001800717a0;
code_r0x000180071200:
    do {
        puVar20 = *in_RCX;
        var_14f8h._0_4_ = 0;
        iVar14 = (int32_t)uVar21;
        var_1508h._0_4_ = 0;
        var_1508h._4_4_ = 4;
        uStack_1500 = 0;
        uStack_14fc = 2;
        stack0xffffffffffffeb0c = 1;
        var_1528h._0_4_ = 8;
        var_1528h._4_4_ = 8;
        uStack_1520 = 4;
        uStack_151c = 4;
        iVar19 = uVar21 * 4;
        var_1518h._0_4_ = 2;
        uVar30 = *(uint32_t *)((int64_t)&var_1508h + iVar19);
        var_1518h._4_4_ = 2;
        var_1510h = 1;
        uVar34 = *(uint32_t *)((int64_t)&var_1528h + iVar19);
        uVar26 = (~uVar30 + uVar34 + *puVar20) / uVar34;
        var_14c8h._0_4_ = 0;
        var_14c8h._4_4_ = 0;
        uStack_14c0 = 4;
        uStack_14bc = 0;
        var_14b8h = 2;
        var_14b0h._0_4_ = 1;
        var_14d8h._0_4_ = 4;
        var_14d8h._4_4_ = 2;
        var_14d0h = 2;
        var_14e8h._0_4_ = 8;
        var_14e8h._4_4_ = 8;
        uStack_14e0 = 8;
        uStack_14dc = 4;
        if (uVar26 == 0) {
code_r0x0001800713e7:
            in_RCX = *(uint32_t ***)((int64_t)&arg_28h + iVar18);
        } else {
            uVar33 = *(uint32_t *)((int64_t)&var_14e8h + iVar19);
            uVar3 = *(uint32_t *)((int64_t)&var_14c8h + iVar19);
            uVar4 = puVar20[1];
            *(uint32_t *)((int64_t)&arg_38h + iVar18 + 4) = uVar33;
            uVar21 = (uint64_t)(uVar4 + ~uVar3 + uVar33) / (uint64_t)uVar33;
            iVar16 = (int32_t)uVar21;
            *(int32_t *)((int64_t)var_10h + iVar18) = iVar16;
            if (iVar16 == 0) goto code_r0x0001800713e7;
            uVar33 = puVar20[2];
            iVar5 = *(int32_t *)((int64_t)&arg_38h + iVar18);
            uVar4 = *(uint32_t *)((int64_t)var_10h + iVar18 + -4);
            uVar6 = *(uint32_t *)((int64_t)var_10h + iVar18 + -0xc);
            *(undefined4 *)(&stack0xfffffffffffffff8 + iVar18) = *(undefined4 *)((int64_t)var_10h + iVar18 + 4);
            *(int32_t *)(&stack0xfffffffffffffff0 + iVar18) = iVar5;
            *(int32_t *)(&stack0xffffffffffffffe8 + iVar18) = iVar16;
            *(uint32_t *)((int64_t)&var_20h + iVar18) = uVar26;
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x1800712fb;
            iVar17 = fcn.18006f8f0(*(int64_t *)((int64_t)&arg_28h + iVar18), var_1538h, (uint64_t)uVar6, (uint64_t)uVar4
                                   , *(int64_t *)((int64_t)&var_20h + iVar18), 
                                   *(int64_t *)(&stack0xffffffffffffffe8 + iVar18), 
                                   *(int64_t *)(&stack0xfffffffffffffff0 + iVar18), 
                                   *(int64_t *)(&stack0xfffffffffffffff8 + iVar18), 
                                   *(int64_t *)(&stack0x00000078 + iVar18));
            if (iVar17 == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007148d;
                func_0x000180460d90(*(undefined8 *)((int64_t)&arg_30h + iVar18));
                goto code_r0x0001800717a0;
            }
            iVar17 = 0;
            *(undefined4 *)((int64_t)var_10h + iVar18 + 0xc) = 0;
            uVar33 = (((int32_t)(uVar33 * uVar26 * iVar5 + 7) >> 3) + 1) * iVar16;
            if (0 < iVar16) {
                do {
                    iVar14 = 0;
                    if (0 < (int32_t)uVar26) {
                        iVar16 = *(int32_t *)((int64_t)&arg_38h + iVar18 + 4);
                        do {
                            piVar9 = (*(int32_t ***)((int64_t)&arg_28h + iVar18))[3];
                            iVar5 = ***(int32_t ***)((int64_t)&arg_28h + iVar18);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007139f;
                            func_0x000180498030((uint64_t)((iVar16 * iVar17 + uVar3) * iVar15 * iVar5) +
                                                *(int64_t *)((int64_t)&arg_30h + iVar18) +
                                                (int64_t)(int32_t)((uVar34 * iVar14 + uVar30) * iVar15), 
                                                (int64_t)(int32_t)((iVar14 + uVar26 * iVar17) * iVar15) +
                                                (int64_t)piVar9, (int64_t)iVar15);
                            iVar14 = iVar14 + 1;
                        } while (iVar14 < (int32_t)uVar26);
                        iVar17 = *(int32_t *)((int64_t)var_10h + iVar18 + 0xc);
                        uVar21 = (uint64_t)*(uint32_t *)((int64_t)var_10h + iVar18);
                    }
                    iVar17 = iVar17 + 1;
                    *(int32_t *)((int64_t)var_10h + iVar18 + 0xc) = iVar17;
                } while (iVar17 < (int32_t)uVar21);
                iVar14 = *(int32_t *)((int64_t)var_10h + iVar18 + 0x10);
                arg1 = (uint32_t *)var_1530h;
            }
            in_RCX = *(uint32_t ***)((int64_t)&arg_28h + iVar18);
            puVar20 = in_RCX[3];
            *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x1800713db;
            func_0x000180460d90(puVar20);
            var_1538h = var_1538h + (uint64_t)uVar33;
            piVar9 = (int32_t *)((int64_t)var_10h + iVar18 + -0xc);
            *piVar9 = *piVar9 - uVar33;
        }
        uVar30 = iVar14 + 1;
        uVar21 = (uint64_t)uVar30;
        *(uint32_t *)((int64_t)var_10h + iVar18 + 0x10) = uVar30;
    } while ((int32_t)uVar30 < 7);
    iVar14 = *(int32_t *)((int64_t)var_10h + iVar18 + 8);
    in_RCX[3] = *(uint32_t **)((int64_t)&arg_30h + iVar18);
code_r0x000180071410:
    uVar21 = 0;
    cVar32 = *(char *)((int64_t)var_10h + iVar18 + -0xf);
    if (cVar32 != '\0') {
        puVar20 = in_RCX[3];
        uVar30 = (*in_RCX)[1] * **in_RCX;
        if (*(int32_t *)(in_RCX + 4) == 0x10) {
            if (arg1[3] == 2) {
                uVar22 = uVar21;
                if (uVar30 != 0) {
                    do {
                        iVar25 = -1;
                        if (*(int16_t *)puVar20 == (int16_t)var_4a8h) {
                            iVar25 = 0;
                        }
                        uVar34 = (int32_t)uVar22 + 1;
                        *(int16_t *)((int64_t)puVar20 + 2) = iVar25;
                        puVar20 = puVar20 + 1;
                        uVar22 = (uint64_t)uVar34;
                    } while (uVar34 < uVar30);
                }
            } else {
                uVar22 = uVar21;
                if (uVar30 != 0) {
                    do {
                        if (((*(int16_t *)puVar20 == (int16_t)var_4a8h) &&
                            (*(int16_t *)((int64_t)puVar20 + 2) == var_4a8h._2_2_)) &&
                           (*(int16_t *)(puVar20 + 1) == var_4a8h._4_2_)) {
                            *(int16_t *)((int64_t)puVar20 + 6) = 0;
                        }
                        puVar20 = puVar20 + 2;
                        uVar34 = (int32_t)uVar22 + 1;
                        uVar22 = (uint64_t)uVar34;
                    } while (uVar34 < uVar30);
                }
            }
        } else if (arg1[3] == 2) {
            if (uVar30 != 0) {
                cVar11 = *(char *)((int64_t)var_10h + iVar18 + -8);
                uVar22 = uVar21;
                do {
                    uVar27 = 0xff;
                    if (*(char *)puVar20 == cVar11) {
                        uVar27 = uVar21;
                    }
                    uVar34 = (int32_t)uVar22 + 1;
                    uVar22 = (uint64_t)uVar34;
                    *(char *)((int64_t)puVar20 + 1) = (char)uVar27;
                    puVar20 = (uint32_t *)((int64_t)puVar20 + 2);
                } while (uVar34 < uVar30);
            }
        } else if (uVar30 != 0) {
            cVar11 = *(char *)((int64_t)var_10h + iVar18 + -8);
            cVar1 = *(char *)((int64_t)var_10h + iVar18 + -6);
            cVar2 = *(char *)((int64_t)var_10h + iVar18 + -7);
            uVar22 = uVar21;
            do {
                if (((*(char *)puVar20 == cVar11) && (*(char *)((int64_t)puVar20 + 1) == cVar2)) &&
                   (*(char *)((int64_t)puVar20 + 2) == cVar1)) {
                    *(char *)((int64_t)puVar20 + 3) = '\0';
                }
                puVar20 = puVar20 + 1;
                uVar34 = (int32_t)uVar22 + 1;
                uVar22 = (uint64_t)uVar34;
            } while (uVar34 < uVar30);
        }
    }
    if (iVar14 != 0) {
        iVar19 = *(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8);
        iVar14 = *(int32_t *)0x180781f14;
        if (*(int32_t *)(iVar19 + 0x1c) != 0) {
            iVar14 = *(int32_t *)(iVar19 + 0x20);
        }
        if ((iVar14 != 0) && (2 < (int32_t)arg1[3])) {
            puVar23 = *in_RCX;
            puVar20 = in_RCX[3];
            uVar30 = puVar23[1] * *puVar23;
            if (puVar23[3] == 3) {
                uVar22 = uVar21;
                if (uVar30 != 0) {
                    do {
                        uVar35 = *(uint8_t *)puVar20;
                        uVar34 = (int32_t)uVar22 + 1;
                        uVar22 = (uint64_t)uVar34;
                        *(uint8_t *)puVar20 = *(uint8_t *)((int64_t)puVar20 + 2);
                        *(uint8_t *)((int64_t)puVar20 + 2) = uVar35;
                        puVar20 = (uint32_t *)((int64_t)puVar20 + 3);
                    } while (uVar34 < uVar30);
                }
            } else {
                iVar14 = *(int32_t *)0x180781edc;
                if (*(int32_t *)(iVar19 + 0x24) != 0) {
                    iVar14 = *(int32_t *)(iVar19 + 0x18);
                }
                if (iVar14 == 0) {
                    uVar22 = uVar21;
                    if (uVar30 != 0) {
                        do {
                            uVar35 = *(uint8_t *)puVar20;
                            uVar34 = (int32_t)uVar22 + 1;
                            uVar22 = (uint64_t)uVar34;
                            *(uint8_t *)puVar20 = *(uint8_t *)((int64_t)puVar20 + 2);
                            *(uint8_t *)((int64_t)puVar20 + 2) = uVar35;
                            puVar20 = puVar20 + 1;
                        } while (uVar34 < uVar30);
                    }
                } else if (uVar30 != 0) {
                    puVar31 = (uint8_t *)((int64_t)puVar20 + 2);
                    uVar22 = uVar21;
                    do {
                        uVar35 = *(uint8_t *)((int64_t)puVar20 + 3);
                        uVar36 = *(uint8_t *)puVar20;
                        uVar12 = *puVar31;
                        if (uVar35 != 0) {
                            uVar34 = (uint32_t)uVar35;
                            uVar26 = (uint32_t)(uVar35 >> 1);
                            *(uint8_t *)((int64_t)puVar20 + 1) =
                                 (uint8_t)(((uint32_t)*(uint8_t *)((int64_t)puVar20 + 1) * 0xff + uVar26) / uVar34);
                            uVar36 = (uint8_t)(((uint32_t)uVar36 * 0xff + uVar26) / uVar34);
                            uVar12 = (uint8_t)(((uint32_t)uVar12 * 0xff + uVar26) / uVar34);
                        }
                        *(uint8_t *)puVar20 = uVar12;
                        uVar34 = (int32_t)uVar22 + 1;
                        uVar22 = (uint64_t)uVar34;
                        *puVar31 = uVar36;
                        puVar20 = puVar20 + 1;
                        puVar31 = puVar31 + 4;
                    } while (uVar34 < uVar30);
                    cVar32 = *(char *)((int64_t)var_10h + iVar18 + -0xf);
                }
            }
        }
    }
    uVar35 = *(uint8_t *)((int64_t)var_10h + iVar18 + -0x10);
    if (uVar35 == 0) {
        if (cVar32 != '\0') {
            arg1[2] = arg1[2] + 1;
        }
    } else {
        arg1[2] = (uint32_t)uVar35;
        arg1[3] = 4;
        uVar30 = (*in_RCX)[1] * **in_RCX;
        if (((int32_t)uVar30 < 0) || (0x1fffffff < (int32_t)uVar30)) goto code_r0x0001800717a0;
        puVar20 = in_RCX[3];
        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x1800716f4;
        puVar23 = (uint32_t *)func_0x00018046d050((int64_t)(int32_t)(uVar30 * 4));
        if (puVar23 == (uint32_t *)0x0) goto code_r0x0001800717a0;
        puVar29 = puVar23;
        if (uVar30 != 0) {
            do {
                uVar34 = (int32_t)uVar21 + 1;
                uVar21 = (uint64_t)*(uint8_t *)(uVar21 + (int64_t)puVar20);
                *(undefined *)puVar29 = *(undefined *)((int64_t)&var_498h + uVar21 * 4);
                *(undefined *)((int64_t)puVar29 + 1) = *(undefined *)((int64_t)&var_498h + uVar21 * 4 + 1);
                uVar24 = *(undefined *)((int64_t)&var_498h + uVar21 * 4 + 2);
                *(undefined *)((int64_t)puVar29 + 3) = *(undefined *)((int64_t)&var_498h + uVar21 * 4 + 3);
                *(undefined *)((int64_t)puVar29 + 2) = uVar24;
                puVar29 = puVar29 + 1;
                uVar21 = (uint64_t)uVar34;
            } while (uVar34 < uVar30);
        }
        puVar20 = in_RCX[3];
        *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180071759;
        func_0x000180460d90(puVar20);
        in_RCX[3] = puVar23;
    }
    puVar20 = in_RCX[2];
    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x180071771;
    func_0x000180460d90(puVar20);
    in_RCX[2] = (uint32_t *)0x0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x18007177e;
    func_0x000180069a00(arg1);
code_r0x0001800717a0:
    *(undefined8 *)((int64_t)&uStack_48 + iVar18) = 0x1800717af;
    func_0x000180459870(var_98h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar18));
    return;
}

// ============================================================
// Function: FUN_1800718c0
// Address: 0x1800718c0
// Size: 755 bytes
// ============================================================
undefined8 fcn.1800718c0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int32_t iVar2;
    int32_t iVar3;
    undefined4 uVar4;
    char *pcVar5;
    uint32_t uVar6;
    int64_t var_6ch;
    
    pcVar5 = *(char **)(arg1 + 0xc0);
    if (*(char **)(arg1 + 200) <= pcVar5) {
        if (*(int32_t *)(arg1 + 0x30) == 0) {
            return 0;
        }
        func_0x000180069750();
        pcVar5 = *(char **)(arg1 + 0xc0);
    }
    cVar1 = *pcVar5;
    *(char **)(arg1 + 0xc0) = pcVar5 + 1;
    if (cVar1 != 'B') {
        return 0;
    }
    cVar1 = func_0x0001800697d0(arg1);
    if (cVar1 != 'M') {
        return 0;
    }
    func_0x000180069a30(arg1);
    func_0x000180069a30(arg1);
    func_0x000180069a30(arg1);
    func_0x000180069a30(arg1);
    iVar2 = func_0x000180069a30(arg1);
    iVar3 = func_0x000180069a30(arg1);
    *(int32_t *)(arg2 + 4) = iVar3 * 0x10000 + iVar2;
    iVar2 = func_0x000180069a30(arg1);
    iVar3 = func_0x000180069a30(arg1);
    uVar6 = iVar2 + iVar3 * 0x10000;
    *(undefined4 *)(arg2 + 0x20) = 0xe;
    *(uint32_t *)(arg2 + 8) = uVar6;
    *(undefined8 *)(arg2 + 0x14) = 0;
    *(undefined8 *)(arg2 + 0xc) = 0;
    if (*(int32_t *)(arg2 + 4) < 0) {
        return 0;
    }
    if (((uVar6 < 0x39) && ((0x100010000001000U >> ((uint64_t)uVar6 & 0x3f) & 1) != 0)) || (uVar6 == 0x6c)) {
        if (uVar6 == 0xc) {
            uVar4 = func_0x000180069a30(arg1);
            *(undefined4 *)arg1 = uVar4;
            uVar4 = func_0x000180069a30(arg1);
            goto code_r0x0001800719c6;
        }
    } else if (uVar6 != 0x7c) {
        return 0;
    }
    uVar4 = func_0x000180069ae0(arg1);
    *(undefined4 *)arg1 = uVar4;
    uVar4 = func_0x000180069ae0(arg1);
code_r0x0001800719c6:
    *(undefined4 *)(arg1 + 4) = uVar4;
    iVar2 = func_0x000180069a30(arg1);
    if (iVar2 == 1) {
        uVar4 = func_0x000180069a30(arg1);
        *(undefined4 *)arg2 = uVar4;
        if (uVar6 == 0xc) {
            return 1;
        }
        iVar2 = func_0x000180069ae0(arg1);
        if (((iVar2 < 1) || (iVar2 == 3)) && ((iVar2 != 3 || ((*(int32_t *)arg2 - 0x10U & 0xffffffef) == 0)))) {
            func_0x000180069ae0(arg1);
            func_0x000180069ae0(arg1);
            func_0x000180069ae0(arg1);
            func_0x000180069ae0(arg1);
            func_0x000180069ae0(arg1);
            if (uVar6 != 0x28) {
                if (uVar6 != 0x38) {
                    if ((uVar6 - 0x6c & 0xffffffef) != 0) {
                        return 0;
                    }
                    uVar4 = func_0x000180069ae0(arg1);
                    *(undefined4 *)(arg2 + 0xc) = uVar4;
                    uVar4 = func_0x000180069ae0(arg1);
                    *(undefined4 *)(arg2 + 0x10) = uVar4;
                    uVar4 = func_0x000180069ae0(arg1);
                    *(undefined4 *)(arg2 + 0x14) = uVar4;
                    uVar4 = func_0x000180069ae0(arg1);
                    *(undefined4 *)(arg2 + 0x18) = uVar4;
                    if (iVar2 != 3) {
                        func_0x000180071850(arg2, iVar2);
                    }
                    func_0x000180069ae0(arg1);
                    iVar2 = 0xc;
                    do {
                        func_0x000180069a30(arg1);
                        func_0x000180069a30(arg1);
                        iVar2 = iVar2 + -1;
                    } while (iVar2 != 0);
                    if (uVar6 != 0x7c) {
                        return 1;
                    }
                    func_0x000180069ae0(arg1);
                    func_0x000180069ae0(arg1);
                    func_0x000180069ae0(arg1);
                    func_0x000180069ae0(arg1);
                    return 1;
                }
                func_0x000180069ae0(arg1);
                func_0x000180069ae0(arg1);
                func_0x000180069ae0(arg1);
                func_0x000180069ae0(arg1);
            }
            if ((*(int32_t *)arg2 - 0x10U & 0xffffffef) != 0) {
                return 1;
            }
            if (iVar2 == 0) {
                func_0x000180071850(arg2, 0);
                return 1;
            }
            if (iVar2 == 3) {
                uVar4 = func_0x000180069ae0(arg1);
                *(undefined4 *)(arg2 + 0xc) = uVar4;
                uVar4 = func_0x000180069ae0(arg1);
                *(undefined4 *)(arg2 + 0x10) = uVar4;
                iVar2 = func_0x000180069ae0(arg1);
                *(int32_t *)(arg2 + 0x20) = *(int32_t *)(arg2 + 0x20) + 0xc;
                *(int32_t *)(arg2 + 0x14) = iVar2;
                if (*(int32_t *)(arg2 + 0xc) != *(int32_t *)(arg2 + 0x10)) {
                    return 1;
                }
                if (*(int32_t *)(arg2 + 0x10) != iVar2) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180071bc0
// Address: 0x180071bc0
// Size: 3868 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_49ch
// WARNING: [rz-ghidra] Detected overlap for variable var_480h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_488h
// WARNING: [rz-ghidra] Detected overlap for variable var_4f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_48ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4fch
// WARNING: [rz-ghidra] Detected overlap for variable var_514h
// WARNING: [rz-ghidra] Detected overlap for variable var_4f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ech
// WARNING: [rz-ghidra] Detected overlap for variable var_4e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4dch
// WARNING: [rz-ghidra] Detected overlap for variable var_4e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_50ch
// WARNING: [rz-ghidra] Detected overlap for variable var_510h
// WARNING: [rz-ghidra] Detected overlap for variable var_4a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_4c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_447h
// WARNING: [rz-ghidra] Detected overlap for variable var_446h

void fcn.180071bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    int64_t iVar2;
    uint8_t uVar3;
    undefined uVar4;
    int32_t iVar5;
    undefined *puVar6;
    int64_t iVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    uint64_t uVar10;
    int32_t iVar11;
    int32_t iVar12;
    int32_t iVar13;
    int32_t *piVar14;
    uint64_t uVar15;
    int64_t iVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint32_t uVar19;
    uint32_t uVar20;
    int32_t iVar21;
    int64_t var_20h;
    undefined auStack_538 [32];
    int64_t var_518h;
    int32_t var_510h;
    uint32_t var_50ch;
    int64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    uint32_t var_4f0h;
    uint32_t var_4ech;
    uint32_t var_4e8h;
    uint32_t var_4e4h;
    int64_t var_4e0h;
    int64_t var_4d8h;
    int64_t var_4d0h;
    int32_t var_4c8h;
    int32_t var_4c4h;
    int32_t var_4c0h;
    int64_t var_4bch;
    int64_t var_4b0h;
    int64_t var_4a8h;
    int64_t var_4a0h;
    int64_t var_498h;
    uint32_t var_490h;
    uint32_t var_48ch;
    uint32_t var_488h;
    int64_t var_484h;
    int64_t var_478h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_538;
    var_484h._0_4_ = 0xff;
    var_458h = arg2;
    var_450h = arg3;
    iVar2 = fcn.1800718c0(arg1, (int64_t)&var_4a0h);
    if (iVar2 == 0) goto code_r0x000180072ab2;
    var_4a8h._0_4_ = *(uint32_t *)(arg1 + 4);
    uVar20 = -(uint32_t)var_4a8h;
    if (0 < (int32_t)(uint32_t)var_4a8h) {
        uVar20 = (uint32_t)var_4a8h;
    }
    *(uint32_t *)(arg1 + 4) = uVar20;
    if ((0x1000000 < uVar20) || (uVar19 = *(uint32_t *)arg1, 0x1000000 < uVar19)) goto code_r0x000180072ab2;
    iVar13 = 0;
    var_4f8h._0_4_ = var_484h._4_4_;
    var_4e0h._0_4_ = var_4a0h._4_4_;
    var_518h._0_4_ = (uint32_t)var_498h;
    var_4d8h._0_4_ = (int32_t)var_4a0h;
    if ((uint32_t)var_498h == 0xc) {
        iVar13 = 0;
        if (0x17 < (int32_t)var_4a0h) goto code_r0x000180071ca3;
        iVar13 = (int32_t)((var_4a0h._4_4_ - var_484h._4_4_) + -0x18) / 3;
code_r0x000180071c9f:
        if (iVar13 == 0) goto code_r0x000180071ca3;
    } else {
        if ((int32_t)var_4a0h < 0x10) {
            iVar13 = (int32_t)((var_4a0h._4_4_ - var_484h._4_4_) - (uint32_t)var_498h) >> 2;
            goto code_r0x000180071c9f;
        }
code_r0x000180071ca3:
        if ((int64_t)var_4a0h._4_4_ !=
            ((int64_t)*(int32_t *)(arg1 + 0xb8) - *(int64_t *)(arg1 + 0xd0)) + *(int64_t *)(arg1 + 0xc0))
        goto code_r0x000180072ab2;
    }
    var_4f8h._4_4_ = var_498h._4_4_;
    var_500h._0_4_ = var_490h;
    var_500h._4_4_ = var_48ch;
    var_518h._4_4_ = (uint32_t)var_484h;
    var_4bch._0_4_ = var_488h;
    if (((int32_t)var_4a0h == 0x18) && (var_488h == 0xff000000)) {
        iVar11 = 3;
    } else {
        iVar11 = (var_488h != 0) + 3;
    }
    *(int32_t *)(arg1 + 8) = iVar11;
    if (((int32_t)uVar19 < 0) ||
       ((uVar19 != 0 && (((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar19) < 4 || ((int32_t)(uVar19 * 4) < 0))))))
    goto code_r0x000180072ab2;
    if (((int32_t)uVar20 < 0) ||
       ((((uVar20 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar20) < (int32_t)(uVar19 * 4))) ||
         ((uVar19 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar19) < 4)))) ||
        (((uVar20 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar20) < (int32_t)(uVar19 * 4))) ||
         (iVar2 = func_0x00018046d050(), uVar20 = (uint32_t)var_518h, var_508h = iVar2, iVar2 == 0))))))
    goto code_r0x000180072ab2;
    if ((int32_t)var_4a0h < 0x10) {
        if ((iVar13 == 0) || (0x100 < iVar13)) {
code_r0x000180072aab:
            func_0x000180460d90(iVar2);
            goto code_r0x000180072ab2;
        }
        uVar19 = 0;
        iVar11 = (int32_t)var_4a0h;
        if (0 < iVar13) {
            do {
                var_4b0h = iVar2;
                puVar6 = *(undefined **)(arg1 + 0xc0);
                if (puVar6 < *(undefined **)(arg1 + 200)) {
                    uVar4 = *puVar6;
                    puVar6 = puVar6 + 1;
                    *(undefined **)(arg1 + 0xc0) = puVar6;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar4 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar4 = **(undefined **)(arg1 + 0xc0);
                    puVar6 = *(undefined **)(arg1 + 0xc0) + 1;
                    *(undefined **)(arg1 + 0xc0) = puVar6;
                }
                piVar14 = (int32_t *)(arg1 + 0x30);
                iVar2 = (uint64_t)uVar19 * 4;
                *(undefined *)((int64_t)&var_448h + iVar2 + 2) = uVar4;
                if (puVar6 < *(undefined **)(arg1 + 200)) {
                    uVar4 = *puVar6;
                    puVar6 = puVar6 + 1;
                    *(undefined **)(arg1 + 0xc0) = puVar6;
                } else if (*piVar14 == 0) {
                    uVar4 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar4 = **(undefined **)(arg1 + 0xc0);
                    puVar6 = *(undefined **)(arg1 + 0xc0) + 1;
                    *(undefined **)(arg1 + 0xc0) = puVar6;
                }
                *(undefined *)((int64_t)&var_448h + iVar2 + 1) = uVar4;
                if (puVar6 < *(undefined **)(arg1 + 200)) {
                    uVar4 = *puVar6;
                    puVar6 = puVar6 + 1;
                    *(undefined **)(arg1 + 0xc0) = puVar6;
                } else if (*piVar14 == 0) {
                    uVar4 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar4 = **(undefined **)(arg1 + 0xc0);
                    puVar6 = *(undefined **)(arg1 + 0xc0) + 1;
                    *(undefined **)(arg1 + 0xc0) = puVar6;
                }
                *(undefined *)((int64_t)&var_448h + iVar2) = uVar4;
                if (uVar20 != 0xc) {
                    if (puVar6 < *(undefined **)(arg1 + 200)) {
                        *(undefined **)(arg1 + 0xc0) = puVar6 + 1;
                    } else if (*piVar14 != 0) {
                        func_0x000180069750(arg1);
                        *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 1;
                    }
                }
                uVar19 = uVar19 + 1;
                *(undefined *)((int64_t)&var_448h + iVar2 + 3) = 0xff;
                iVar2 = var_4b0h;
                var_498h._0_4_ = (uint32_t)var_518h;
                iVar11 = (int32_t)var_4d8h;
                var_4a0h._4_4_ = (int32_t)var_4e0h;
            } while ((int32_t)uVar19 < iVar13);
        }
        func_0x000180069830(arg1, ((var_4a0h._4_4_ - (((uint32_t)var_498h != 0xc) + 3) * iVar13) - (uint32_t)var_4f8h) -
                                  (uint32_t)var_498h);
        if (iVar11 == 1) {
            uVar20 = *(int32_t *)arg1 + 7U >> 3;
        } else if (iVar11 == 4) {
            uVar20 = *(int32_t *)arg1 + 1U >> 1;
        } else {
            if (iVar11 != 8) goto code_r0x000180072aab;
            uVar20 = *(uint32_t *)arg1;
        }
        uVar9 = *(uint32_t *)(arg1 + 4);
        uVar20 = -uVar20 & 3;
        iVar13 = 0;
        if (iVar11 == 1) {
            var_518h._0_4_ = 0;
            if (0 < (int32_t)uVar9) {
                do {
                    puVar1 = *(uint8_t **)(arg1 + 0xc0);
                    iVar11 = 7;
                    if (puVar1 < *(uint8_t **)(arg1 + 200)) {
                        uVar3 = *puVar1;
                        *(uint8_t **)(arg1 + 0xc0) = puVar1 + 1;
                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                        uVar3 = 0;
                    } else {
                        func_0x000180069750(arg1);
                        uVar3 = **(uint8_t **)(arg1 + 0xc0);
                        *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                    }
                    iVar21 = 0;
                    uVar19 = (uint32_t)uVar3;
                    if (0 < *(int32_t *)arg1) {
                        do {
                            iVar5 = iVar13 + 2;
                            iVar21 = iVar21 + 1;
                            iVar16 = (uint64_t)((int32_t)uVar19 >> ((uint8_t)iVar11 & 0x1f) & 1) * 4;
                            *(undefined *)(iVar13 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16);
                            iVar7 = (int64_t)iVar13;
                            iVar13 = iVar13 + 4;
                            *(undefined *)(iVar7 + 1 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16 + 1);
                            *(undefined *)(iVar5 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16 + 2);
                            *(undefined *)((int64_t)iVar5 + 1 + iVar2) = 0xff;
                            iVar5 = *(int32_t *)arg1;
                            if (iVar21 == iVar5) break;
                            iVar11 = iVar11 + -1;
                            if (iVar11 < 0) {
                                puVar1 = *(uint8_t **)(arg1 + 0xc0);
                                iVar11 = 7;
                                if (puVar1 < *(uint8_t **)(arg1 + 200)) {
                                    uVar3 = *puVar1;
                                    *(uint8_t **)(arg1 + 0xc0) = puVar1 + 1;
                                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                    uVar3 = 0;
                                } else {
                                    func_0x000180069750(arg1);
                                    uVar3 = **(uint8_t **)(arg1 + 0xc0);
                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                    iVar5 = *(int32_t *)arg1;
                                }
                                uVar19 = (uint32_t)uVar3;
                            }
                        } while (iVar21 < iVar5);
                    }
                    if (uVar20 != 0) {
                        if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                           (iVar11 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), (int32_t)uVar20 <= iVar11)) {
                            *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + (uint64_t)uVar20;
                        } else {
                            *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                            (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), uVar20 - iVar11);
                        }
                    }
                    uVar9 = *(uint32_t *)(arg1 + 4);
                    var_518h._0_4_ = (uint32_t)var_518h + 1;
                } while ((int32_t)(uint32_t)var_518h < (int32_t)uVar9);
            }
        } else {
            iVar21 = 0;
            if (0 < (int32_t)uVar9) {
                do {
                    iVar12 = 0;
                    iVar5 = iVar13;
                    if (0 < *(int32_t *)arg1) {
                        do {
                            puVar1 = *(uint8_t **)(arg1 + 0xc0);
                            if (puVar1 < *(uint8_t **)(arg1 + 200)) {
                                uVar3 = *puVar1;
                                *(uint8_t **)(arg1 + 0xc0) = puVar1 + 1;
                            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                uVar3 = 0;
                            } else {
                                func_0x000180069750(arg1);
                                uVar3 = **(uint8_t **)(arg1 + 0xc0);
                                *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                            }
                            if (iVar11 == 4) {
                                uVar10 = (uint64_t)(uVar3 & 0xf);
                                uVar3 = uVar3 >> 4;
                            } else {
                                uVar10 = 0;
                            }
                            iVar16 = (uint64_t)uVar3 * 4;
                            *(undefined *)(iVar5 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16);
                            iVar13 = iVar5 + 4;
                            *(undefined *)((int64_t)iVar5 + 1 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16 + 1)
                            ;
                            *(undefined *)((iVar5 + 2) + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16 + 2);
                            *(undefined *)((int64_t)(iVar5 + 2) + 1 + iVar2) = 0xff;
                            if (iVar12 + 1 == *(int32_t *)arg1) break;
                            if (iVar11 == 8) {
                                puVar1 = *(uint8_t **)(arg1 + 0xc0);
                                if (puVar1 < *(uint8_t **)(arg1 + 200)) {
                                    uVar3 = *puVar1;
                                    *(uint8_t **)(arg1 + 0xc0) = puVar1 + 1;
                                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                    uVar3 = 0;
                                } else {
                                    func_0x000180069750(arg1);
                                    uVar3 = **(uint8_t **)(arg1 + 0xc0);
                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                }
                                uVar10 = (uint64_t)uVar3;
                            }
                            iVar16 = uVar10 * 4;
                            iVar12 = iVar12 + 2;
                            *(undefined *)(iVar13 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16);
                            iVar7 = (int64_t)iVar13;
                            iVar13 = iVar5 + 8;
                            *(undefined *)(iVar7 + 1 + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16 + 1);
                            *(undefined *)((iVar5 + 6) + iVar2) = *(undefined *)((int64_t)&var_448h + iVar16 + 2);
                            *(undefined *)((int64_t)(iVar5 + 6) + 1 + iVar2) = 0xff;
                            iVar5 = iVar13;
                        } while (iVar12 < *(int32_t *)arg1);
                    }
                    if (uVar20 != 0) {
                        if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                           (iVar5 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), (int32_t)uVar20 <= iVar5)) {
                            *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + (uint64_t)uVar20;
                        } else {
                            *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                            (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), uVar20 - iVar5);
                        }
                    }
                    uVar9 = *(uint32_t *)(arg1 + 4);
                    iVar21 = iVar21 + 1;
                } while (iVar21 < (int32_t)uVar9);
            }
        }
    } else {
        var_4f0h = 0;
        iVar13 = 0;
        var_4e0h._0_4_ = 0;
        var_4ech = 0;
        var_4e8h = 0;
        var_4e0h._4_4_ = 0;
        var_518h._0_4_ = 0;
        var_4f8h._0_4_ = 0;
        var_4e4h = 0;
        func_0x000180069830(arg1);
        uVar19 = var_4f8h._4_4_;
        uVar20 = (uint32_t)var_500h;
        iVar2 = var_508h;
        if ((int32_t)var_4a0h == 0x18) {
            iVar11 = 1;
            uVar8 = 0;
            var_510h = 1;
            iVar13 = 0;
            uVar20 = 0;
            uVar19 = *(int32_t *)arg1 * 3;
            uVar17 = 0;
            uVar18 = 0;
        } else {
            if ((int32_t)var_4a0h == 0x10) {
                var_50ch = *(int32_t *)arg1 * 2;
code_r0x00018007236d:
                var_510h = 0;
                if (((var_4f8h._4_4_ == 0) || ((uint32_t)var_500h == 0)) || (var_500h._4_4_ == 0))
                goto code_r0x000180072aab;
            } else {
                uVar18 = 0;
                uVar8 = 0;
                var_50ch = 0;
                if ((((int32_t)var_4a0h != 0x20) || (var_500h._4_4_ != 0xff)) ||
                   (((uint32_t)var_500h != 0xff00 || (var_4f8h._4_4_ != 0xff0000)))) goto code_r0x00018007236d;
                if (var_488h == 0xff000000) {
                    iVar11 = 2;
                    var_510h = 2;
                    uVar20 = uVar8;
                    uVar19 = uVar8;
                    uVar17 = uVar8;
                    goto code_r0x00018007253e;
                }
            }
            uVar10 = (uint64_t)var_500h._4_4_;
            var_510h = 0;
            iVar11 = 0;
            iVar21 = func_0x0001800717e0(var_4f8h._4_4_);
            uVar19 = (uVar19 >> 1 & 0x55555555) + (uVar19 & 0x55555555);
            uVar19 = (uVar19 >> 2 & 0x33333333) + (uVar19 & 0x33333333);
            uVar19 = (uVar19 >> 4) + uVar19 & 0xf0f0f0f;
            uVar19 = uVar19 + (uVar19 >> 8);
            uVar19 = (uVar19 >> 0x10) + uVar19 & 0xff;
            var_4e0h._4_4_ = uVar19;
            iVar13 = func_0x0001800717e0(uVar20);
            iVar5 = func_0x0001800717e0(uVar10 & 0xffffffff);
            iVar12 = func_0x0001800717e0(var_488h);
            if ((((8 < uVar19) ||
                 (uVar20 = (uVar20 >> 1 & 0x55555555) + (uVar20 & 0x55555555),
                 uVar20 = (uVar20 >> 2 & 0x33333333) + (uVar20 & 0x33333333),
                 uVar20 = (uVar20 >> 4) + uVar20 & 0xf0f0f0f, uVar20 = uVar20 + (uVar20 >> 8),
                 var_518h._0_4_ = (uVar20 >> 0x10) + uVar20 & 0xff, 8 < (uint32_t)var_518h)) ||
                (uVar20 = (var_500h._4_4_ >> 1 & 0x55555555) + (var_500h._4_4_ & 0x55555555),
                uVar20 = (uVar20 >> 2 & 0x33333333) + (uVar20 & 0x33333333), uVar20 = (uVar20 >> 4) + uVar20 & 0xf0f0f0f
                , uVar20 = uVar20 + (uVar20 >> 8), var_4f8h._0_4_ = (uVar20 >> 0x10) + uVar20 & 0xff,
                8 < (uint32_t)var_4f8h)) ||
               (uVar20 = (var_488h >> 1 & 0x55555555) + (var_488h & 0x55555555),
               uVar20 = (uVar20 >> 2 & 0x33333333) + (uVar20 & 0x33333333), uVar20 = (uVar20 >> 4) + uVar20 & 0xf0f0f0f,
               uVar20 = uVar20 + (uVar20 >> 8), var_4e4h = (uVar20 >> 0x10) + uVar20 & 0xff, 8 < var_4e4h))
            goto code_r0x000180072aab;
            iVar13 = iVar13 + -7;
            var_4f0h = iVar21 - 7;
            uVar8 = iVar12 - 7;
            var_4ech = iVar5 - 7;
            uVar20 = var_4f0h;
            uVar19 = var_50ch;
            uVar17 = var_4ech;
            var_4e8h = uVar8;
            var_4e0h._0_4_ = iVar13;
            uVar18 = var_4e4h;
        }
code_r0x00018007253e:
        uVar9 = *(uint32_t *)(arg1 + 4);
        if (0 < (int32_t)uVar9) {
            var_4a8h._4_4_ = -uVar20;
            var_4bch._4_4_ = -uVar8;
            var_4d0h._0_4_ = 8 - var_4e0h._4_4_;
            var_50ch = -uVar19 & 3;
            uVar10 = (uint64_t)var_50ch;
            var_4d0h._4_4_ = -iVar13;
            var_4d8h._4_4_ = 0;
            var_4c8h = 8 - (uint32_t)var_518h;
            iVar13 = 0;
            var_4c4h = -uVar17;
            var_4c0h = 8 - (uint32_t)var_4f8h;
            var_4b0h = CONCAT44(var_4b0h._4_4_, 8 - uVar18);
            do {
                uVar15 = (uint64_t)(uint32_t)var_4f8h;
                if (iVar11 == 0) {
                    iVar21 = 0;
                    if (0 < *(int32_t *)arg1) {
                        piVar14 = (int32_t *)((uint64_t)var_4e0h._4_4_ * 4 + 0x18063d238);
                        var_470h = (uint64_t)var_4e0h._4_4_ * 4 + 0x18063d298;
                        var_468h = (uint64_t)(uint32_t)var_518h * 4 + 0x18063d238;
                        var_460h = (uint64_t)(uint32_t)var_518h * 4 + 0x18063d298;
                        var_478h = (int64_t)piVar14;
                        do {
                            uVar20 = func_0x000180069a30(arg1);
                            if ((int32_t)var_4d8h != 0x10) {
                                iVar11 = func_0x000180069a30(arg1);
                                uVar20 = iVar11 * 0x10000 + uVar20;
                                piVar14 = (int32_t *)var_478h;
                            }
                            if ((int32_t)var_4f0h < 0) {
                                uVar19 = (uVar20 & var_4f8h._4_4_) << ((uint8_t)var_4a8h._4_4_ & 0x1f);
                            } else {
                                uVar19 = (uVar20 & var_4f8h._4_4_) >> ((uint8_t)var_4f0h & 0x1f);
                            }
                            *(char *)(iVar13 + iVar2) =
                                 (char)((int32_t)((uVar19 >> ((uint8_t)(int32_t)var_4d0h & 0x1f)) * *piVar14) >>
                                       ((uint8_t)*(undefined4 *)var_470h & 0x1f));
                            if ((int32_t)var_4e0h < 0) {
                                uVar19 = (uVar20 & (uint32_t)var_500h) << ((uint8_t)var_4d0h._4_4_ & 0x1f);
                            } else {
                                uVar19 = (uVar20 & (uint32_t)var_500h) >> ((uint8_t)(int32_t)var_4e0h & 0x1f);
                            }
                            iVar11 = iVar13 + 2;
                            *(char *)((int64_t)iVar13 + 1 + iVar2) =
                                 (char)((int32_t)((uVar19 >> ((uint8_t)var_4c8h & 0x1f)) * *(int32_t *)var_468h) >>
                                       ((uint8_t)*(undefined4 *)var_460h & 0x1f));
                            if ((int32_t)var_4ech < 0) {
                                uVar19 = (uVar20 & var_500h._4_4_) << ((uint8_t)var_4c4h & 0x1f);
                            } else {
                                uVar19 = (uVar20 & var_500h._4_4_) >> ((uint8_t)var_4ech & 0x1f);
                            }
                            *(char *)(iVar11 + iVar2) =
                                 (char)((int32_t)((uVar19 >> ((uint8_t)var_4c0h & 0x1f)) *
                                                 *(int32_t *)(uVar15 * 4 + 0x18063d238)) >>
                                       ((uint8_t)*(undefined4 *)(uVar15 * 4 + 0x18063d298) & 0x1f));
                            if ((uint32_t)var_4bch == 0) {
                                uVar20 = 0xff;
                            } else {
                                if ((int32_t)var_4e8h < 0) {
                                    uVar20 = (uVar20 & (uint32_t)var_4bch) << ((uint8_t)var_4bch._4_4_ & 0x1f);
                                } else {
                                    uVar20 = (uVar20 & (uint32_t)var_4bch) >> ((uint8_t)var_4e8h & 0x1f);
                                }
                                uVar20 = (int32_t)((uVar20 >> ((uint8_t)var_4b0h & 0x1f)) *
                                                  *(int32_t *)((uint64_t)var_4e4h * 4 + 0x18063d238)) >>
                                         ((uint8_t)*(undefined4 *)((uint64_t)var_4e4h * 4 + 0x18063d298) & 0x1f);
                            }
                            var_518h._4_4_ = var_518h._4_4_ | uVar20;
                            iVar13 = iVar13 + 4;
                            iVar21 = iVar21 + 1;
                            *(char *)((int64_t)iVar11 + 1 + iVar2) = (char)uVar20;
                        } while (iVar21 < *(int32_t *)arg1);
                        goto code_r0x000180072974;
                    }
                } else {
                    iVar21 = 0;
                    if (0 < *(int32_t *)arg1) {
                        do {
                            puVar6 = *(undefined **)(arg1 + 0xc0);
                            if (puVar6 < *(undefined **)(arg1 + 200)) {
                                uVar4 = *puVar6;
                                *(undefined **)(arg1 + 0xc0) = puVar6 + 1;
                            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                uVar4 = 0;
                            } else {
                                func_0x000180069750(arg1);
                                uVar4 = **(undefined **)(arg1 + 0xc0);
                                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
                            }
                            iVar16 = var_508h;
                            piVar14 = (int32_t *)(arg1 + 0x30);
                            iVar7 = (int64_t)iVar13;
                            *(undefined *)(var_508h + 2 + iVar7) = uVar4;
                            puVar6 = *(undefined **)(arg1 + 0xc0);
                            if (puVar6 < *(undefined **)(arg1 + 200)) {
                                uVar4 = *puVar6;
                                *(undefined **)(arg1 + 0xc0) = puVar6 + 1;
                            } else if (*piVar14 == 0) {
                                uVar4 = 0;
                            } else {
                                func_0x000180069750(arg1);
                                uVar4 = **(undefined **)(arg1 + 0xc0);
                                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
                            }
                            *(undefined *)(iVar7 + 1 + iVar16) = uVar4;
                            puVar6 = *(undefined **)(arg1 + 0xc0);
                            if (puVar6 < *(undefined **)(arg1 + 200)) {
                                uVar4 = *puVar6;
                                *(undefined **)(arg1 + 0xc0) = puVar6 + 1;
                            } else if (*piVar14 == 0) {
                                uVar4 = 0;
                            } else {
                                func_0x000180069750(arg1);
                                uVar4 = **(undefined **)(arg1 + 0xc0);
                                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
                            }
                            *(undefined *)(iVar7 + iVar2) = uVar4;
                            iVar11 = iVar13 + 3;
                            if (var_510h == 2) {
                                puVar1 = *(uint8_t **)(arg1 + 0xc0);
                                if (puVar1 < *(uint8_t **)(arg1 + 200)) {
                                    uVar20 = (uint32_t)*puVar1;
                                    *(uint8_t **)(arg1 + 0xc0) = puVar1 + 1;
                                } else if (*piVar14 == 0) {
                                    uVar20 = 0;
                                } else {
                                    func_0x000180069750(arg1);
                                    uVar20 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                }
                            } else {
                                uVar20 = 0xff;
                            }
                            iVar13 = iVar13 + 4;
                            var_518h._4_4_ = var_518h._4_4_ | uVar20;
                            iVar21 = iVar21 + 1;
                            *(char *)(iVar11 + iVar2) = (char)uVar20;
                        } while (iVar21 < *(int32_t *)arg1);
code_r0x000180072974:
                        uVar10 = (uint64_t)var_50ch;
                        iVar11 = var_510h;
                    }
                }
                iVar21 = var_4d8h._4_4_;
                iVar5 = (int32_t)uVar10;
                if (iVar5 != 0) {
                    if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                       (iVar12 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), iVar5 <= iVar12)) {
                        *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + uVar10;
                    } else {
                        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                        (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), iVar5 - iVar12);
                        uVar10 = (uint64_t)var_50ch;
                    }
                }
                uVar9 = *(uint32_t *)(arg1 + 4);
                var_4d8h._4_4_ = iVar21 + 1;
            } while (var_4d8h._4_4_ < (int32_t)uVar9);
        }
    }
    if ((var_518h._4_4_ == 0) && (uVar20 = uVar9 * *(int32_t *)arg1 * 4 - 1, -1 < (int32_t)uVar20)) {
        do {
            *(undefined *)((uint64_t)uVar20 + var_508h) = 0xff;
            uVar20 = uVar20 - 4;
        } while (-1 < (int32_t)uVar20);
        uVar9 = *(uint32_t *)(arg1 + 4);
    }
    if ((0 < (int32_t)(uint32_t)var_4a8h) && (0 < (int32_t)(uVar9 & 0xfffffffe))) {
        uVar20 = 0;
        do {
            iVar13 = *(int32_t *)arg1;
            iVar11 = 0;
            iVar16 = (uint64_t)(uVar20 * iVar13 * 4) + iVar2;
            if (0 < iVar13 * 4) {
                do {
                    iVar7 = (int64_t)iVar11;
                    iVar11 = iVar11 + 1;
                    uVar4 = *(undefined *)(iVar16 + iVar7);
                    puVar6 = (undefined *)((uint64_t)((~uVar20 + uVar9) * iVar13 * 4) + iVar2 + iVar7);
                    *(undefined *)(iVar16 + iVar7) = *puVar6;
                    *puVar6 = uVar4;
                } while (iVar11 < *(int32_t *)arg1 << 2);
            }
            uVar9 = *(uint32_t *)(arg1 + 4);
            uVar20 = uVar20 + 1;
        } while ((int32_t)uVar20 < (int32_t)uVar9 >> 1);
    }
    *(undefined4 *)var_458h = *(undefined4 *)arg1;
    *(undefined4 *)var_450h = *(undefined4 *)(arg1 + 4);
code_r0x000180072ab2:
    func_0x000180459870(var_48h ^ (uint64_t)auStack_538);
    return;
}

// ============================================================
// Function: FUN_180072ae0
// Address: 0x180072ae0
// Size: 130 bytes
// ============================================================
void fcn.180072ae0(undefined8 placeholder_0, int64_t arg2)
{
    uint16_t uVar1;
    
    uVar1 = fcn.180069a30();
    *(char *)arg2 = (char)(((uVar1 >> 10 & 0x1f) * 0xff) / 0x1f);
    *(char *)(arg2 + 1) = (char)(((uVar1 >> 5 & 0x1f) * 0xff) / 0x1f);
    *(char *)(arg2 + 2) = (char)(((uVar1 & 0x1f) * 0xff) / 0x1f);
    return;
}

// ============================================================
// Function: FUN_180072b70
// Address: 0x180072b70
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180072b70(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char cVar2;
    uint32_t uVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = 0;
    while( true ) {
        pcVar1 = *(char **)(arg1 + 0xc0);
        if (pcVar1 < *(char **)(arg1 + 200)) {
            cVar2 = *pcVar1;
            *(char **)(arg1 + 0xc0) = pcVar1 + 1;
        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
            cVar2 = '\0';
        } else {
            func_0x000180069750(arg1);
            cVar2 = **(char **)(arg1 + 0xc0);
            *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
        }
        if (cVar2 != *(char *)(uVar4 + arg2)) break;
        uVar3 = (int32_t)uVar4 + 1;
        uVar4 = (uint64_t)uVar3;
        if (3 < (int32_t)uVar3) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180072c10
// Address: 0x180072c10
// Size: 193 bytes
// ============================================================
int64_t fcn.180072c10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined *puVar1;
    int32_t iVar2;
    undefined uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    
    uVar4 = 0x80;
    iVar5 = 0;
    do {
        if (((uint32_t)arg2 & uVar4) != 0) {
            if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180072c4d:
                if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0)) {
                    return 0;
                }
            } else {
                iVar2 = (**(code **)(arg1 + 0x20))();
                if (iVar2 != 0) {
                    if (*(int32_t *)(arg1 + 0x30) == 0) {
                        return 0;
                    }
                    goto code_r0x000180072c4d;
                }
            }
            puVar1 = *(undefined **)(arg1 + 0xc0);
            if (puVar1 < *(undefined **)(arg1 + 200)) {
                uVar3 = *puVar1;
                *(undefined **)(arg1 + 0xc0) = puVar1 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                uVar3 = 0;
            } else {
                func_0x000180069750(arg1);
                uVar3 = **(undefined **)(arg1 + 0xc0);
                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
            }
            *(undefined *)(iVar5 + arg3) = uVar3;
        }
        iVar5 = iVar5 + 1;
        if (3 < iVar5) {
            return arg3;
        }
        uVar4 = (int32_t)uVar4 >> 1;
    } while( true );
}

// ============================================================
// Function: FUN_180072ce0
// Address: 0x180072ce0
// Size: 166 bytes
// ============================================================
bool fcn.180072ce0(int64_t arg1)
{
    char cVar1;
    char *pcVar2;
    bool bVar3;
    
    pcVar2 = *(char **)(arg1 + 0xc0);
    if (pcVar2 < *(char **)(arg1 + 200)) {
code_r0x000180072d0b:
        cVar1 = *pcVar2;
        *(char **)(arg1 + 0xc0) = pcVar2 + 1;
        if (cVar1 == 'G') {
            cVar1 = func_0x0001800697d0(arg1);
            if (cVar1 == 'I') {
                cVar1 = func_0x0001800697d0(arg1);
                if (cVar1 == 'F') {
                    cVar1 = func_0x0001800697d0(arg1);
                    if (cVar1 == '8') {
                        cVar1 = func_0x0001800697d0(arg1);
                        if ((cVar1 - 0x37U & 0xfd) == 0) {
                            cVar1 = func_0x0001800697d0(arg1);
                            bVar3 = cVar1 == 'a';
                            goto code_r0x000180072d62;
                        }
                    }
                }
            }
        }
    } else if (*(int32_t *)(arg1 + 0x30) != 0) {
        func_0x000180069750();
        pcVar2 = *(char **)(arg1 + 0xc0);
        goto code_r0x000180072d0b;
    }
    bVar3 = false;
code_r0x000180072d62:
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    return bVar3;
}

// ============================================================
// Function: FUN_180072d90
// Address: 0x180072d90
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180072d90(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined *puVar1;
    undefined *puVar2;
    undefined uVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (0 < (int32_t)arg3) {
        uVar5 = 0;
        do {
            puVar1 = *(undefined **)(arg1 + 0xc0);
            if (puVar1 < *(undefined **)(arg1 + 200)) {
                uVar3 = *puVar1;
                *(undefined **)(arg1 + 0xc0) = puVar1 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                uVar3 = 0;
            } else {
                func_0x000180069750(arg1);
                uVar3 = **(undefined **)(arg1 + 0xc0);
                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
            }
            *(undefined *)(arg2 + 2 + uVar5 * 4) = uVar3;
            puVar1 = (undefined *)(arg2 + uVar5 * 4);
            puVar2 = *(undefined **)(arg1 + 0xc0);
            if (puVar2 < *(undefined **)(arg1 + 200)) {
                uVar3 = *puVar2;
                *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                uVar3 = 0;
            } else {
                func_0x000180069750(arg1);
                uVar3 = **(undefined **)(arg1 + 0xc0);
                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
            }
            puVar1[1] = uVar3;
            puVar2 = *(undefined **)(arg1 + 0xc0);
            if (puVar2 < *(undefined **)(arg1 + 200)) {
                uVar3 = *puVar2;
                *(undefined **)(arg1 + 0xc0) = puVar2 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                uVar3 = 0;
            } else {
                func_0x000180069750(arg1);
                uVar3 = **(undefined **)(arg1 + 0xc0);
                *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
            }
            *puVar1 = uVar3;
            uVar3 = 0xff;
            if ((int32_t)arg4 == (int32_t)uVar5) {
                uVar3 = 0;
            }
            uVar4 = (int32_t)uVar5 + 1;
            uVar5 = (uint64_t)uVar4;
            puVar1[3] = uVar3;
        } while ((int32_t)uVar4 < (int32_t)arg3);
    }
    return;
}

