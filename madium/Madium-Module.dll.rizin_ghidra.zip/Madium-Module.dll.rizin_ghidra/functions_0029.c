// Chunk 29 - 50 functions

// ============================================================
// Function: FUN_18005e57d
// Address: 0x18005e57d
// Size: 960 bytes
// ============================================================
undefined8 fcn.18005e57d(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    undefined8 in_RCX;
    int64_t iVar14;
    undefined uVar15;
    int64_t unaff_RBX;
    int64_t unaff_RDI;
    undefined8 uVar16;
    undefined8 unaff_R15;
    bool bVar17;
    undefined4 uVar18;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    int64_t var_20h;
    
    uVar13 = *(undefined8 *)(unaff_RDI + 0x20);
    iVar1 = *(int64_t *)(unaff_RDI + 0x10);
    func_0x000180086cc0(in_RCX, 0xffffffff, 0x1806247f0);
    if ((*(uint8_t *)(unaff_RBX + 1) & 4) != 0) {
        *(uint8_t *)(unaff_RBX + 1) = *(uint8_t *)(unaff_RBX + 1) & 0xfb;
        *(undefined8 *)(unaff_RBX + 0x48) = *(undefined8 *)(*(int64_t *)(unaff_RBX + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(unaff_RBX + 0x20) + 0x18) = unaff_RBX;
    }
    puVar2 = *(undefined4 **)(unaff_RBX + 0x40);
    for (puVar12 = puVar2; puVar2 + -8 < puVar12; puVar12 = puVar12 + -4) {
        *puVar12 = puVar12[-4];
        puVar12[1] = puVar12[-3];
        puVar12[2] = puVar12[-2];
        puVar12[3] = puVar12[-1];
    }
    puVar12 = *(undefined4 **)(unaff_RBX + 0x40);
    uVar18 = *puVar12;
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    puVar2[-8] = uVar18;
    puVar2[-7] = uVar5;
    puVar2[-6] = uVar6;
    puVar2[-5] = uVar7;
    uVar18 = func_0x0001800878a0(uVar18, 1, 0);
    uVar18 = func_0x000180086fd0(uVar18, 0, 0);
    iVar8 = 1;
    do {
        if (iVar1 == 0) {
            return 1;
        }
        puVar11 = (undefined8 *)func_0x000180087f70(uVar18, 0x28, 0x7a);
        iVar10 = (int32_t)unaff_R15;
        if ((*(int64_t *)(iVar1 + 0x30) == *(int64_t *)(iVar1 + 0x38) + 0x18) ||
           (uVar18 = extraout_XMM0_Da, *(int64_t *)(iVar1 + 0x38) == *(int64_t *)(iVar1 + 0x40) + 0x18)) {
            iVar9 = func_0x00018005d3d0(iVar1);
            uVar18 = extraout_XMM0_Da_00;
            if (iVar9 != 0) {
                if (iVar9 == 1) {
                    if ((((*(int64_t **)(iVar1 + 0x38) != (int64_t *)0x0) && (*(int64_t *)(iVar1 + 0x40) != 0)) &&
                        (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + 8) != iVar10)) &&
                       ((iVar14 = **(int64_t **)(iVar1 + 0x38), iVar14 == *(int64_t *)0x180782520 ||
                        (iVar14 == *(int64_t *)0x180782528)))) goto code_r0x00018005e896;
                } else if (((iVar9 == 2) &&
                           ((*(int64_t **)(iVar1 + 0x30) != (int64_t *)0x0 && (*(int64_t *)(iVar1 + 0x38) != 0)))) &&
                          (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) != iVar10)) {
                    bVar17 = **(int64_t **)(iVar1 + 0x30) == *(int64_t *)0x180782620;
                    goto code_r0x00018005e890;
                }
                goto code_r0x00018005e6c8;
            }
            if (((*(int64_t **)(iVar1 + 0x30) == (int64_t *)0x0) || (*(int64_t *)(iVar1 + 0x38) == 0)) ||
               (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) == iVar10)) goto code_r0x00018005e6c8;
            iVar14 = **(int64_t **)(iVar1 + 0x30);
            if (iVar14 != *(int64_t *)0x180782520) {
                bVar17 = iVar14 == *(int64_t *)0x180782528;
code_r0x00018005e890:
                if (!bVar17) goto code_r0x00018005e6c8;
            }
code_r0x00018005e896:
            iVar9 = func_0x00018005d3d0(iVar1);
            uVar18 = extraout_XMM0_Da_02;
            if (iVar9 == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x30) + 0x95);
            } else if (iVar9 == 1) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x38) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x38) + 0x95);
            } else {
                if (iVar9 != 2) goto code_r0x00018005e6c8;
                uVar15 = 1;
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x38);
            }
            if (iVar14 == 0) goto code_r0x00018005e6c8;
            iVar10 = *(int32_t *)(iVar14 + 0x34);
            uVar16 = *(undefined8 *)(iVar14 + 0x28);
            iVar9 = *(int32_t *)(iVar14 + 0x30);
        } else {
code_r0x00018005e6c8:
            uVar15 = 0;
            uVar16 = unaff_R15;
            iVar9 = iVar10;
        }
        *puVar11 = uVar13;
        puVar11[1] = iVar1;
        puVar11[2] = uVar16;
        *(char *)(puVar11 + 3) = (char)unaff_R15;
        *(undefined *)((int64_t)puVar11 + 0x19) = uVar15;
        *(int32_t *)((int64_t)puVar11 + 0x1c) = iVar9;
        *(int32_t *)(puVar11 + 4) = iVar10;
        iVar10 = func_0x0001800885b0(uVar18, 0x180624778);
        uVar18 = extraout_XMM0_Da_01;
        if (iVar10 != 0) {
            uVar18 = func_0x0001800869f0(extraout_XMM0_Da_01, 0x18005df30, 0, 0);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x1805aae90);
            uVar18 = func_0x0001800869f0(uVar18, 0x18005e370, 0, 0);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x1806203d0);
            uVar18 = func_0x0001800869f0(uVar18, 0x18005e450, 0, 0);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x180622440);
            uVar18 = func_0x0001800867f0(uVar18, 0x180624778, 0xf);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x180622470);
            uVar18 = func_0x0001800867f0(uVar18, 0x180622458, 0x17);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x1806224a0);
        }
        uVar18 = func_0x000180087650(uVar18, 0xfffffffe);
        iVar14 = *(int64_t *)(unaff_RBX + 0x40);
        if (*(char *)(*(int64_t *)(iVar14 + -0x20) + 4) != (char)unaff_R15) {
            func_0x000180092f10();
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar12 = (undefined4 *)func_0x0001800a1010(uVar18, *(int64_t *)(iVar14 + -0x20), iVar8);
        uVar18 = *(undefined4 *)(iVar14 + -0x10);
        uVar5 = *(undefined4 *)(iVar14 + -0xc);
        uVar6 = *(undefined4 *)(iVar14 + -8);
        uVar7 = *(undefined4 *)(iVar14 + -4);
        *puVar12 = uVar18;
        puVar12[1] = uVar5;
        puVar12[2] = uVar6;
        puVar12[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(unaff_RBX + 0x40) + -4)) {
            iVar14 = *(int64_t *)(iVar14 + -0x20);
            if (((*(uint8_t *)(iVar14 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(unaff_RBX + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(unaff_RBX + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    uVar18 = func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar14;
                }
            }
        }
        *(int64_t *)(unaff_RBX + 0x40) = *(int64_t *)(unaff_RBX + 0x40) + -0x10;
        iVar1 = *(int64_t *)(iVar1 + 0x10);
        iVar8 = iVar8 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18005e93d
// Address: 0x18005e93d
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_50h
// WARNING: Variable defined which should be unmapped: arg_58h
// WARNING: Variable defined which should be unmapped: arg_38h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18005e57d(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int32_t iVar9;
    int32_t iVar10;
    undefined8 *puVar11;
    undefined4 *puVar12;
    undefined8 uVar13;
    undefined8 in_RCX;
    int64_t iVar14;
    undefined uVar15;
    int64_t unaff_RBX;
    int64_t unaff_RDI;
    undefined8 uVar16;
    undefined8 unaff_R15;
    bool bVar17;
    undefined4 uVar18;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    undefined4 extraout_XMM0_Da_02;
    int64_t var_20h;
    
    uVar13 = *(undefined8 *)(unaff_RDI + 0x20);
    iVar1 = *(int64_t *)(unaff_RDI + 0x10);
    func_0x000180086cc0(in_RCX, 0xffffffff, 0x1806247f0);
    if ((*(uint8_t *)(unaff_RBX + 1) & 4) != 0) {
        *(uint8_t *)(unaff_RBX + 1) = *(uint8_t *)(unaff_RBX + 1) & 0xfb;
        *(undefined8 *)(unaff_RBX + 0x48) = *(undefined8 *)(*(int64_t *)(unaff_RBX + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(unaff_RBX + 0x20) + 0x18) = unaff_RBX;
    }
    puVar2 = *(undefined4 **)(unaff_RBX + 0x40);
    for (puVar12 = puVar2; puVar2 + -8 < puVar12; puVar12 = puVar12 + -4) {
        *puVar12 = puVar12[-4];
        puVar12[1] = puVar12[-3];
        puVar12[2] = puVar12[-2];
        puVar12[3] = puVar12[-1];
    }
    puVar12 = *(undefined4 **)(unaff_RBX + 0x40);
    uVar18 = *puVar12;
    uVar5 = puVar12[1];
    uVar6 = puVar12[2];
    uVar7 = puVar12[3];
    puVar2[-8] = uVar18;
    puVar2[-7] = uVar5;
    puVar2[-6] = uVar6;
    puVar2[-5] = uVar7;
    uVar18 = func_0x0001800878a0(uVar18, 1, 0);
    uVar18 = func_0x000180086fd0(uVar18, 0, 0);
    iVar8 = 1;
    do {
        if (iVar1 == 0) {
            return 1;
        }
        puVar11 = (undefined8 *)func_0x000180087f70(uVar18, 0x28, 0x7a);
        iVar10 = (int32_t)unaff_R15;
        if ((*(int64_t *)(iVar1 + 0x30) == *(int64_t *)(iVar1 + 0x38) + 0x18) ||
           (uVar18 = extraout_XMM0_Da, *(int64_t *)(iVar1 + 0x38) == *(int64_t *)(iVar1 + 0x40) + 0x18)) {
            iVar9 = func_0x00018005d3d0(iVar1);
            uVar18 = extraout_XMM0_Da_00;
            if (iVar9 != 0) {
                if (iVar9 == 1) {
                    if ((((*(int64_t **)(iVar1 + 0x38) != (int64_t *)0x0) && (*(int64_t *)(iVar1 + 0x40) != 0)) &&
                        (*(int32_t *)(*(int64_t *)(iVar1 + 0x40) + 8) != iVar10)) &&
                       ((iVar14 = **(int64_t **)(iVar1 + 0x38), iVar14 == *(int64_t *)0x180782520 ||
                        (iVar14 == *(int64_t *)0x180782528)))) goto code_r0x00018005e896;
                } else if (((iVar9 == 2) &&
                           ((*(int64_t **)(iVar1 + 0x30) != (int64_t *)0x0 && (*(int64_t *)(iVar1 + 0x38) != 0)))) &&
                          (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) != iVar10)) {
                    bVar17 = **(int64_t **)(iVar1 + 0x30) == *(int64_t *)0x180782620;
                    goto code_r0x00018005e890;
                }
                goto code_r0x00018005e6c8;
            }
            if (((*(int64_t **)(iVar1 + 0x30) == (int64_t *)0x0) || (*(int64_t *)(iVar1 + 0x38) == 0)) ||
               (*(int32_t *)(*(int64_t *)(iVar1 + 0x38) + 8) == iVar10)) goto code_r0x00018005e6c8;
            iVar14 = **(int64_t **)(iVar1 + 0x30);
            if (iVar14 != *(int64_t *)0x180782520) {
                bVar17 = iVar14 == *(int64_t *)0x180782528;
code_r0x00018005e890:
                if (!bVar17) goto code_r0x00018005e6c8;
            }
code_r0x00018005e896:
            iVar9 = func_0x00018005d3d0(iVar1);
            uVar18 = extraout_XMM0_Da_02;
            if (iVar9 == 0) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x30) + 0x95);
            } else if (iVar9 == 1) {
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x38) + 0x60);
                uVar15 = *(undefined *)(*(int64_t *)(iVar1 + 0x38) + 0x95);
            } else {
                if (iVar9 != 2) goto code_r0x00018005e6c8;
                uVar15 = 1;
                iVar14 = *(int64_t *)(*(int64_t *)(iVar1 + 0x30) + 0x38);
            }
            if (iVar14 == 0) goto code_r0x00018005e6c8;
            iVar10 = *(int32_t *)(iVar14 + 0x34);
            uVar16 = *(undefined8 *)(iVar14 + 0x28);
            iVar9 = *(int32_t *)(iVar14 + 0x30);
        } else {
code_r0x00018005e6c8:
            uVar15 = 0;
            uVar16 = unaff_R15;
            iVar9 = iVar10;
        }
        *puVar11 = uVar13;
        puVar11[1] = iVar1;
        puVar11[2] = uVar16;
        *(char *)(puVar11 + 3) = (char)unaff_R15;
        *(undefined *)((int64_t)puVar11 + 0x19) = uVar15;
        *(int32_t *)((int64_t)puVar11 + 0x1c) = iVar9;
        *(int32_t *)(puVar11 + 4) = iVar10;
        iVar10 = func_0x0001800885b0(uVar18, 0x180624778);
        uVar18 = extraout_XMM0_Da_01;
        if (iVar10 != 0) {
            uVar18 = func_0x0001800869f0(extraout_XMM0_Da_01, 0x18005df30, 0, 0);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x1805aae90);
            uVar18 = func_0x0001800869f0(uVar18, 0x18005e370, 0, 0);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x1806203d0);
            uVar18 = func_0x0001800869f0(uVar18, 0x18005e450, 0, 0);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x180622440);
            uVar18 = func_0x0001800867f0(uVar18, 0x180624778, 0xf);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x180622470);
            uVar18 = func_0x0001800867f0(uVar18, 0x180622458, 0x17);
            uVar18 = func_0x000180087370(uVar18, 0xfffffffe, 0x1806224a0);
        }
        uVar18 = func_0x000180087650(uVar18, 0xfffffffe);
        iVar14 = *(int64_t *)(unaff_RBX + 0x40);
        if (*(char *)(*(int64_t *)(iVar14 + -0x20) + 4) != (char)unaff_R15) {
            func_0x000180092f10();
            pcVar4 = (code *)swi(3);
            uVar13 = (*pcVar4)();
            return uVar13;
        }
        puVar12 = (undefined4 *)func_0x0001800a1010(uVar18, *(int64_t *)(iVar14 + -0x20), iVar8);
        uVar18 = *(undefined4 *)(iVar14 + -0x10);
        uVar5 = *(undefined4 *)(iVar14 + -0xc);
        uVar6 = *(undefined4 *)(iVar14 + -8);
        uVar7 = *(undefined4 *)(iVar14 + -4);
        *puVar12 = uVar18;
        puVar12[1] = uVar5;
        puVar12[2] = uVar6;
        puVar12[3] = uVar7;
        if (5 < *(int32_t *)(*(int64_t *)(unaff_RBX + 0x40) + -4)) {
            iVar14 = *(int64_t *)(iVar14 + -0x20);
            if (((*(uint8_t *)(iVar14 + 1) & 4) != 0) &&
               ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(unaff_RBX + 0x40) + -0x10) + 1) & 3) != 0)) {
                iVar3 = *(int64_t *)(unaff_RBX + 0x20);
                if (*(char *)(iVar3 + 0x59) == '\x02') {
                    uVar18 = func_0x000180094420();
                } else {
                    *(uint8_t *)(iVar14 + 1) = *(uint8_t *)(iVar14 + 1) & 0xfb;
                    *(undefined8 *)(iVar14 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                    *(int64_t *)(iVar3 + 0x18) = iVar14;
                }
            }
        }
        *(int64_t *)(unaff_RBX + 0x40) = *(int64_t *)(unaff_RBX + 0x40) + -0x10;
        iVar1 = *(int64_t *)(iVar1 + 0x10);
        iVar8 = iVar8 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18005e943
// Address: 0x18005e943
// Size: 33 bytes
// ============================================================
void fcn.18005e943(void)
{
    code *pcVar1;
    
    fcn.180088470();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18005e964
// Address: 0x18005e964
// Size: 9 bytes
// ============================================================
void fcn.18005e964(void)
{
    code *pcVar1;
    
    fcn.180087960();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18005e970
// Address: 0x18005e970
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005e970(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t iStack_18;
    undefined4 uStack_10;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 9) {
        uVar12 = (uint32_t)*(uint8_t *)(*piVar10 + 3);
    } else {
        uVar12 = 0xffffffff;
    }
    if (uVar12 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    func_0x0001800869f0(arg1, 0x18005e470, 0, 0, 0);
    func_0x000180085bf0(arg1, 1);
    iVar9 = func_0x0001800878a0(arg1, 1, 1);
    if (((iVar9 == 0) && ((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430)) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
        func_0x000180086510(arg1);
        iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        if (iVar9 != 0) {
            uVar12 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar9 = uVar12 + 1;
            do {
                func_0x000180086cc0(arg1, 0xffffffff, 0x1806247fc);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar3 = *(undefined4 **)(arg1 + 0x40);
                for (puVar4 = puVar3; puVar3 + -8 < puVar4; puVar4 = puVar4 + -4) {
                    *puVar4 = puVar4[-4];
                    puVar4[1] = puVar4[-3];
                    puVar4[2] = puVar4[-2];
                    puVar4[3] = puVar4[-1];
                }
                puVar4 = *(undefined4 **)(arg1 + 0x40);
                iVar13 = 2;
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                puVar3[-8] = *puVar4;
                puVar3[-7] = uVar6;
                puVar3[-6] = uVar7;
                puVar3[-5] = uVar8;
                if (2 < iVar9) {
                    do {
                        func_0x000180085bf0(arg1, iVar13);
                        iVar13 = iVar13 + 1;
                    } while (iVar13 < iVar9);
                }
                if (((iVar9 < 0) && (*(char *)0x180777010 != '\0')) &&
                   ((**(uint64_t **)(arg1 + 0x18) <
                     (uint64_t)((int64_t)(int32_t)~uVar12 * 0x10 + *(int64_t *)(arg1 + 0x40)) &&
                    (iVar13 = func_0x000180085510(arg1), iVar13 == 0)))) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
                iStack_18 = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar9 * -0x10;
                uStack_10 = 0;
                func_0x000180094080(arg1, 0x180087890, &iStack_18, iStack_18 - *(int64_t *)(arg1 + 0x38), 0);
                iVar13 = func_0x000180087970(arg1, 0xfffffffe);
            } while (iVar13 != 0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005e9db
// Address: 0x18005e9db
// Size: 422 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005e970(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t iStack_18;
    undefined4 uStack_10;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 9) {
        uVar12 = (uint32_t)*(uint8_t *)(*piVar10 + 3);
    } else {
        uVar12 = 0xffffffff;
    }
    if (uVar12 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    func_0x0001800869f0(arg1, 0x18005e470, 0, 0, 0);
    func_0x000180085bf0(arg1, 1);
    iVar9 = func_0x0001800878a0(arg1, 1, 1);
    if (((iVar9 == 0) && ((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430)) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
        func_0x000180086510(arg1);
        iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        if (iVar9 != 0) {
            uVar12 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar9 = uVar12 + 1;
            do {
                func_0x000180086cc0(arg1, 0xffffffff, 0x1806247fc);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar3 = *(undefined4 **)(arg1 + 0x40);
                for (puVar4 = puVar3; puVar3 + -8 < puVar4; puVar4 = puVar4 + -4) {
                    *puVar4 = puVar4[-4];
                    puVar4[1] = puVar4[-3];
                    puVar4[2] = puVar4[-2];
                    puVar4[3] = puVar4[-1];
                }
                puVar4 = *(undefined4 **)(arg1 + 0x40);
                iVar13 = 2;
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                puVar3[-8] = *puVar4;
                puVar3[-7] = uVar6;
                puVar3[-6] = uVar7;
                puVar3[-5] = uVar8;
                if (2 < iVar9) {
                    do {
                        func_0x000180085bf0(arg1, iVar13);
                        iVar13 = iVar13 + 1;
                    } while (iVar13 < iVar9);
                }
                if (((iVar9 < 0) && (*(char *)0x180777010 != '\0')) &&
                   ((**(uint64_t **)(arg1 + 0x18) <
                     (uint64_t)((int64_t)(int32_t)~uVar12 * 0x10 + *(int64_t *)(arg1 + 0x40)) &&
                    (iVar13 = func_0x000180085510(arg1), iVar13 == 0)))) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
                iStack_18 = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar9 * -0x10;
                uStack_10 = 0;
                func_0x000180094080(arg1, 0x180087890, &iStack_18, iStack_18 - *(int64_t *)(arg1 + 0x38), 0);
                iVar13 = func_0x000180087970(arg1, 0xfffffffe);
            } while (iVar13 != 0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005eb81
// Address: 0x18005eb81
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005e970(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t iStack_18;
    undefined4 uStack_10;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 9) {
        uVar12 = (uint32_t)*(uint8_t *)(*piVar10 + 3);
    } else {
        uVar12 = 0xffffffff;
    }
    if (uVar12 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    func_0x0001800869f0(arg1, 0x18005e470, 0, 0, 0);
    func_0x000180085bf0(arg1, 1);
    iVar9 = func_0x0001800878a0(arg1, 1, 1);
    if (((iVar9 == 0) && ((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430)) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
        func_0x000180086510(arg1);
        iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        if (iVar9 != 0) {
            uVar12 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar9 = uVar12 + 1;
            do {
                func_0x000180086cc0(arg1, 0xffffffff, 0x1806247fc);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar3 = *(undefined4 **)(arg1 + 0x40);
                for (puVar4 = puVar3; puVar3 + -8 < puVar4; puVar4 = puVar4 + -4) {
                    *puVar4 = puVar4[-4];
                    puVar4[1] = puVar4[-3];
                    puVar4[2] = puVar4[-2];
                    puVar4[3] = puVar4[-1];
                }
                puVar4 = *(undefined4 **)(arg1 + 0x40);
                iVar13 = 2;
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                puVar3[-8] = *puVar4;
                puVar3[-7] = uVar6;
                puVar3[-6] = uVar7;
                puVar3[-5] = uVar8;
                if (2 < iVar9) {
                    do {
                        func_0x000180085bf0(arg1, iVar13);
                        iVar13 = iVar13 + 1;
                    } while (iVar13 < iVar9);
                }
                if (((iVar9 < 0) && (*(char *)0x180777010 != '\0')) &&
                   ((**(uint64_t **)(arg1 + 0x18) <
                     (uint64_t)((int64_t)(int32_t)~uVar12 * 0x10 + *(int64_t *)(arg1 + 0x40)) &&
                    (iVar13 = func_0x000180085510(arg1), iVar13 == 0)))) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
                iStack_18 = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar9 * -0x10;
                uStack_10 = 0;
                func_0x000180094080(arg1, 0x180087890, &iStack_18, iStack_18 - *(int64_t *)(arg1 + 0x38), 0);
                iVar13 = func_0x000180087970(arg1, 0xfffffffe);
            } while (iVar13 != 0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005eba7
// Address: 0x18005eba7
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005e970(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    undefined4 *puVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int32_t iVar9;
    int64_t *piVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_47h;
    int64_t var_28h;
    int64_t iStack_18;
    undefined4 uStack_10;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    piVar10 = piVar1;
    if (piVar2 <= piVar1) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar10 + 0xc) == 9) {
        uVar12 = (uint32_t)*(uint8_t *)(*piVar10 + 3);
    } else {
        uVar12 = 0xffffffff;
    }
    if (uVar12 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar5 = (code *)swi(3);
        uVar11 = (*pcVar5)();
        return uVar11;
    }
    func_0x0001800869f0(arg1, 0x18005e470, 0, 0, 0);
    func_0x000180085bf0(arg1, 1);
    iVar9 = func_0x0001800878a0(arg1, 1, 1);
    if (((iVar9 == 0) && ((int64_t *)(*(int64_t *)(arg1 + 0x40) - 0x10U) != *(int64_t **)0x180782430)) &&
       (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) == 7)) {
        func_0x000180086510(arg1);
        iVar9 = func_0x000180087970(arg1, 0xfffffffe);
        if (iVar9 != 0) {
            uVar12 = (uint32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
            iVar9 = uVar12 + 1;
            do {
                func_0x000180086cc0(arg1, 0xffffffff, 0x1806247fc);
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                puVar3 = *(undefined4 **)(arg1 + 0x40);
                for (puVar4 = puVar3; puVar3 + -8 < puVar4; puVar4 = puVar4 + -4) {
                    *puVar4 = puVar4[-4];
                    puVar4[1] = puVar4[-3];
                    puVar4[2] = puVar4[-2];
                    puVar4[3] = puVar4[-1];
                }
                puVar4 = *(undefined4 **)(arg1 + 0x40);
                iVar13 = 2;
                uVar6 = puVar4[1];
                uVar7 = puVar4[2];
                uVar8 = puVar4[3];
                puVar3[-8] = *puVar4;
                puVar3[-7] = uVar6;
                puVar3[-6] = uVar7;
                puVar3[-5] = uVar8;
                if (2 < iVar9) {
                    do {
                        func_0x000180085bf0(arg1, iVar13);
                        iVar13 = iVar13 + 1;
                    } while (iVar13 < iVar9);
                }
                if (((iVar9 < 0) && (*(char *)0x180777010 != '\0')) &&
                   ((**(uint64_t **)(arg1 + 0x18) <
                     (uint64_t)((int64_t)(int32_t)~uVar12 * 0x10 + *(int64_t *)(arg1 + 0x40)) &&
                    (iVar13 = func_0x000180085510(arg1), iVar13 == 0)))) {
                    func_0x000180099450(arg1, 0x18063d8d0);
                    fcn.180087960(arg1);
                    pcVar5 = (code *)swi(3);
                    uVar11 = (*pcVar5)();
                    return uVar11;
                }
                iStack_18 = *(int64_t *)(arg1 + 0x40) + (int64_t)iVar9 * -0x10;
                uStack_10 = 0;
                func_0x000180094080(arg1, 0x180087890, &iStack_18, iStack_18 - *(int64_t *)(arg1 + 0x38), 0);
                iVar13 = func_0x000180087970(arg1, 0xfffffffe);
            } while (iVar13 != 0);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18005ebc0
// Address: 0x18005ebc0
// Size: 781 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h

undefined8 fcn.18005ebc0(int64_t arg1)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t **ppiVar10;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    undefined4 uVar14;
    int64_t *piVar15;
    uint32_t uVar16;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar13 = *(int64_t **)(arg1 + 0x28);
    piVar15 = *(int64_t **)(arg1 + 0x40);
    piVar9 = piVar13;
    if (piVar15 <= piVar13) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if ((piVar9 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar9 + 0xc) != 9)) {
code_r0x00018005ee8c:
        fcn.180088470(arg1, 1, 9);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    piVar9 = piVar13;
    if (piVar15 <= piVar13) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar9 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar9 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 != *(uint32_t *)0x1807823d4) {
        func_0x000180088380(arg1, 1, 0x180624758);
        pcVar5 = (code *)swi(3);
        uVar12 = (*pcVar5)();
        return uVar12;
    }
    if (piVar15 <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) == 9) {
        ppiVar10 = (int64_t **)(*piVar13 + 0x10);
    } else if (*(int32_t *)((int64_t)piVar13 + 0xc) == 2) {
        ppiVar10 = (int64_t **)*piVar13;
    } else {
        ppiVar10 = (int64_t **)0x0;
    }
    piVar13 = *ppiVar10;
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
    func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf20);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar2 = *(undefined4 **)(arg1 + 0x40);
    puVar3 = puVar2;
    while (puVar2 + -8 < puVar3) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
        puVar3 = puVar3 + -4;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar14 = puVar3[1];
    uVar6 = puVar3[2];
    uVar7 = puVar3[3];
    puVar2[-8] = *puVar3;
    puVar2[-7] = uVar14;
    puVar2[-6] = uVar6;
    puVar2[-5] = uVar7;
    func_0x0001800867f0(arg1, 0x180624020, 0xd);
    var_38h = *(int64_t *)(arg1 + 0x40) + -0x30;
    var_30h = CONCAT44(var_30h._4_4_, 1);
    iVar8 = func_0x000180094080(arg1, 0x180087890, &var_38h, var_38h - *(int64_t *)(arg1 + 0x38), 0);
    if (iVar8 == 0) {
        func_0x000180086cc0(arg1, 0xffffffff, 0x1806247b8);
        iVar4 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar4 + -4) == 9) {
            piVar15 = (int64_t *)(*(int64_t *)(iVar4 + -0x10) + 0x10);
        } else if (*(int32_t *)(iVar4 + -4) == 2) {
            piVar15 = *(int64_t **)(iVar4 + -0x10);
        } else {
            piVar15 = (int64_t *)0x0;
        }
        if (piVar15[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar15[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_38h = *piVar15;
        piVar15 = (int64_t *)piVar15[1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
        iVar4 = *(int64_t *)(*(int64_t *)(*(int64_t *)(var_38h + 0x3070) + 0x38) + 8);
        iVar11 = *(int64_t *)(iVar4 + 8);
        uVar14 = 0;
        if (iVar11 != iVar4) {
            do {
                if (*(int64_t *)(iVar11 + 0x10) == *piVar13) {
                    uVar14 = 1;
                    break;
                }
                iVar11 = *(int64_t *)(iVar11 + 8);
                uVar14 = 0;
            } while (iVar11 != iVar4);
        }
        var_30h = (int64_t)piVar15;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), iVar8 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            goto code_r0x00018005ee8c;
        }
        puVar2 = *(undefined4 **)(arg1 + 0x40);
        *puVar2 = uVar14;
        puVar2[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        if (piVar15 != (int64_t *)0x0) {
            LOCK();
            piVar13 = piVar15 + 1;
            iVar8 = *(int32_t *)piVar13;
            *(int32_t *)piVar13 = *(int32_t *)piVar13 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)*piVar15)(piVar15);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar15 + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*piVar15 + 8))(piVar15);
                    return 1;
                }
            }
        }
    } else {
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar8 = func_0x000180085510(arg1, 1), iVar8 == 0)) {
            func_0x000180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar5 = (code *)swi(3);
            uVar12 = (*pcVar5)();
            return uVar12;
        }
        puVar2 = *(undefined4 **)(arg1 + 0x40);
        *puVar2 = 0;
        puVar2[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    }
    return 1;
}

// ============================================================
// Function: FUN_18005eed0
// Address: 0x18005eed0
// Size: 1334 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h

undefined8 fcn.18005eed0(int64_t arg1, int64_t arg_28h, int64_t arg_40h)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    double dVar4;
    int32_t iVar5;
    int64_t *piVar6;
    int64_t **ppiVar7;
    int64_t *piVar8;
    uint64_t uVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    uint64_t uVar13;
    int64_t iVar14;
    uint64_t uVar15;
    uint32_t uVar16;
    int64_t in_R10;
    int32_t iVar17;
    bool bVar18;
    int64_t var_8h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    piVar12 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar12;
    if (piVar11 <= piVar12) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar3 = (code *)swi(3);
        uVar10 = (*pcVar3)();
        return uVar10;
    }
    piVar6 = piVar12;
    if (piVar11 <= piVar12) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar6 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar11 <= piVar12) {
            piVar12 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar12 + 0xc) == 9) {
            ppiVar7 = (int64_t **)(*piVar12 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar12 + 0xc) == 2) {
            ppiVar7 = (int64_t **)*piVar12;
        } else {
            ppiVar7 = (int64_t **)0x0;
        }
        piVar12 = *ppiVar7;
        var_8h = (int64_t)piVar12;
        func_0x0001800869f0(arg1, fcn.18005ebc0, 0, 0, 0);
        func_0x000180085bf0(arg1, 1);
        func_0x0001800878a0(arg1, 1, 1);
        piVar6 = *(int64_t **)0x180782430;
        piVar11 = (int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10);
        if (((piVar11 == *(int64_t **)0x180782430) || (*(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4) != 1)) ||
           (*(int32_t *)piVar11 == 0)) {
            func_0x0001800858c0(arg1, 0xfffffffe);
            func_0x000180088380(arg1, 1, 0x1806247d0);
            pcVar3 = (code *)swi(3);
            uVar10 = (*pcVar3)();
            return uVar10;
        }
        *(int64_t **)(arg1 + 0x40) = piVar11;
        piVar8 = *(int64_t **)(arg1 + 0x28);
        if (piVar11 <= *(int64_t **)(arg1 + 0x28)) {
            piVar8 = piVar6;
        }
        piVar8 = piVar8 + 2;
        if (piVar8 < piVar11) {
            do {
                *(int32_t *)(piVar8 + -2) = *(int32_t *)piVar8;
                *(int32_t *)((int64_t)piVar8 + -0xc) = *(int32_t *)((int64_t)piVar8 + 4);
                *(int32_t *)(piVar8 + -1) = *(int32_t *)(piVar8 + 1);
                *(int32_t *)((int64_t)piVar8 + -4) = *(int32_t *)((int64_t)piVar8 + 0xc);
                piVar8 = piVar8 + 2;
                piVar11 = *(int64_t **)(arg1 + 0x40);
            } while (piVar8 < piVar11);
        }
        *(int64_t **)(arg1 + 0x40) = piVar11 + -2;
        _var_68h = ZEXT816(0);
        (**(code **)0x180782540)(&var_68h, arg1);
        in_R10 = *piVar12;
        iVar14 = (*(int64_t *)(var_68h + 8) - *(int64_t *)var_68h >> 4) * -0x3333333333333333;
        if (iVar14 - (*(int64_t *)(in_R10 + 0x50) - *(int64_t *)(in_R10 + 0x48)) / 0x70 == 0) {
            iVar17 = 0;
            piVar11 = (int64_t *)var_68h;
            if (iVar14 != 0) {
                do {
                    uVar13 = (uint64_t)iVar17;
                    iVar14 = *(int64_t *)(*piVar12 + 0x48);
                    if ((uint64_t)((*(int64_t *)(*piVar12 + 0x50) - iVar14) / 0x70) <= uVar13) {
                        func_0x000180060370();
                        pcVar3 = (code *)swi(3);
                        uVar10 = (*pcVar3)();
                        return uVar10;
                    }
                    uVar9 = (piVar11[1] - *piVar11 >> 4) * -0x3333333333333333;
                    if (uVar9 < uVar13 || uVar9 - uVar13 == 0) {
code_r0x00018005f3fa:
                        func_0x000180060370();
                        pcVar3 = (code *)swi(3);
                        uVar10 = (*pcVar3)();
                        return uVar10;
                    }
                    iVar2 = *(int64_t *)(*piVar11 + uVar13 * 0x50);
                    iVar14 = *(int64_t *)(uVar13 * 0x70 + 8 + iVar14);
                    if (iVar2 != iVar14) {
                        piVar12 = *(int64_t **)(iVar2 + 8);
                        uVar9 = piVar12[2];
                        if (0xf < (uint64_t)piVar12[3]) {
                            piVar12 = (int64_t *)*piVar12;
                        }
                        uVar15 = uVar9;
                        if (6 < uVar9) {
                            uVar15 = 6;
                        }
                        iVar5 = func_0x000180497f30(piVar12, 0x1806248b0, uVar15);
                        if ((iVar5 != 0) || (uVar9 != 6)) {
                            fcn.180088560(arg1, 0x180624810);
                            pcVar3 = (code *)swi(3);
                            uVar10 = (*pcVar3)();
                            return uVar10;
                        }
                        iVar5 = *(int32_t *)(iVar14 + 0x30);
                        if (iVar5 == 2) {
                            *(int64_t *)(*piVar11 + uVar13 * 0x50) = iVar14;
                            dVar4 = (double)func_0x000180085ea0(arg1, iVar17 + 1, 0);
                            uVar9 = (*(int64_t *)(var_68h + 8) - *(int64_t *)var_68h >> 4) * -0x3333333333333333;
                            if (uVar9 < uVar13 || uVar9 - uVar13 == 0) goto code_r0x00018005f3fa;
                            *(int32_t *)(*(int64_t *)var_68h + 0x10 + uVar13 * 0x50) = (int32_t)dVar4;
                        } else if (iVar5 == 3) {
                            *(int64_t *)(*piVar11 + uVar13 * 0x50) = iVar14;
                            func_0x000180085ea0(arg1, iVar17 + 1, 0);
                            uVar10 = func_0x00018046d070();
                            uVar9 = (*(int64_t *)(var_68h + 8) - *(int64_t *)var_68h >> 4) * -0x3333333333333333;
                            if (uVar9 < uVar13 || uVar9 - uVar13 == 0) goto code_r0x00018005f3fa;
                            *(undefined8 *)(*(int64_t *)var_68h + 0x10 + uVar13 * 0x50) = uVar10;
                        } else {
                            piVar12 = (int64_t *)var_8h;
                            if (iVar5 != 4) goto code_r0x00018005f24d;
                            *(int64_t *)(*piVar11 + uVar13 * 0x50) = iVar14;
                            dVar4 = (double)func_0x000180085ea0(arg1, iVar17 + 1, 0);
                            uVar9 = (*(int64_t *)(var_68h + 8) - *(int64_t *)var_68h >> 4) * -0x3333333333333333;
                            if (uVar9 < uVar13 || uVar9 - uVar13 == 0) goto code_r0x00018005f3fa;
                            *(float *)(*(int64_t *)var_68h + 0x10 + uVar13 * 0x50) = (float)dVar4;
                        }
                        piVar11 = (int64_t *)var_68h;
                        piVar12 = (int64_t *)var_8h;
                    }
code_r0x00018005f24d:
                    iVar17 = iVar17 + 1;
                } while ((uint64_t)(int64_t)iVar17 < (uint64_t)((piVar11[1] - *piVar11 >> 4) * -0x3333333333333333));
            }
            iVar14 = piVar12[4];
            if (iVar14 == 0) {
code_r0x00018005f2a7:
                var_58h = 0;
                piVar6 = (int64_t *)var_58h;
                _var_58h = ZEXT816(0);
            } else {
                iVar17 = *(int32_t *)(iVar14 + 8);
                do {
                    piVar11 = (int64_t *)var_68h;
                    if (iVar17 == 0) goto code_r0x00018005f2a7;
                    LOCK();
                    iVar5 = *(int32_t *)(iVar14 + 8);
                    bVar18 = iVar17 == iVar5;
                    if (bVar18) {
                        *(int32_t *)(iVar14 + 8) = iVar17 + 1;
                        iVar5 = iVar17;
                    }
                    UNLOCK();
                    iVar17 = iVar5;
                } while (!bVar18);
                piVar6 = *(int64_t **)*(undefined (*) [16])(piVar12 + 3);
                _var_58h = *(undefined (*) [16])(piVar12 + 3);
            }
            if (piVar6 != (int64_t *)0x0) {
                var_8h = 0;
                (**(code **)(*piVar6 + 0x18))(0, *piVar12, piVar11, &var_8h);
            }
            iVar14 = var_50h;
            if (var_50h != 0) {
                LOCK();
                piVar1 = (int32_t *)(var_50h + 8);
                iVar17 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar17 == 1) {
                    (***(code ***)var_50h)(var_50h);
                    LOCK();
                    piVar1 = (int32_t *)(iVar14 + 0xc);
                    iVar17 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar17 == 1) {
                        (**(code **)(*(int64_t *)iVar14 + 8))(iVar14);
                    }
                }
            }
            iVar14 = var_60h;
            if (var_60h != 0) {
                LOCK();
                piVar1 = (int32_t *)(var_60h + 8);
                iVar17 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar17 == 1) {
                    (***(code ***)var_60h)(var_60h);
                    LOCK();
                    piVar1 = (int32_t *)(iVar14 + 0xc);
                    iVar17 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar17 == 1) {
                        (**(code **)(*(int64_t *)iVar14 + 8))(iVar14);
                    }
                }
            }
            return 0;
        }
    } else {
        func_0x000180088380(arg1, 1, 0x180624758);
    }
    uVar10 = func_0x00018001ed90(&var_68h);
    func_0x000180060320(uVar10);
    uVar10 = func_0x000180060340(in_R10 + 0x48);
    fcn.180088560(arg1, 0x180624888, uVar10);
    pcVar3 = (code *)swi(3);
    uVar10 = (*pcVar3)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f410
// Address: 0x18005f410
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18005f410(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    undefined8 *puVar13;
    int32_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar12 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar12 = (int64_t **)*piVar11;
        } else {
            ppiVar12 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar12;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar15 = *(int64_t *)(iVar2 + 0x48);
        if ((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70 != 0) {
            iVar14 = 0;
            do {
                puVar13 = *(undefined8 **)(*(int64_t *)((int64_t)iVar14 * 0x70 + 8 + iVar15) + 0x28);
                if (0xf < (uint64_t)puVar13[3]) {
                    puVar13 = (undefined8 *)*puVar13;
                }
                if (puVar13 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar13);
                    func_0x0001800867f0(arg1, puVar13, uVar10);
                }
                iVar15 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar15 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar14 = iVar14 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar15 + -0x20), iVar14);
                uVar5 = *(undefined4 *)(iVar15 + -0xc);
                uVar6 = *(undefined4 *)(iVar15 + -8);
                uVar7 = *(undefined4 *)(iVar15 + -4);
                *puVar9 = *(undefined4 *)(iVar15 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar15 = *(int64_t *)(iVar15 + -0x20);
                    if (((*(uint8_t *)(iVar15 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar3 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar3 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar15 + 1) = *(uint8_t *)(iVar15 + 1) & 0xfb;
                            *(undefined8 *)(iVar15 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                            *(int64_t *)(iVar3 + 0x18) = iVar15;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar15 = *(int64_t *)(iVar2 + 0x48);
            } while ((uint64_t)(int64_t)iVar14 < (uint64_t)((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f475
// Address: 0x18005f475
// Size: 371 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18005f410(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    undefined8 *puVar13;
    int32_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar12 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar12 = (int64_t **)*piVar11;
        } else {
            ppiVar12 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar12;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar15 = *(int64_t *)(iVar2 + 0x48);
        if ((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70 != 0) {
            iVar14 = 0;
            do {
                puVar13 = *(undefined8 **)(*(int64_t *)((int64_t)iVar14 * 0x70 + 8 + iVar15) + 0x28);
                if (0xf < (uint64_t)puVar13[3]) {
                    puVar13 = (undefined8 *)*puVar13;
                }
                if (puVar13 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar13);
                    func_0x0001800867f0(arg1, puVar13, uVar10);
                }
                iVar15 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar15 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar14 = iVar14 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar15 + -0x20), iVar14);
                uVar5 = *(undefined4 *)(iVar15 + -0xc);
                uVar6 = *(undefined4 *)(iVar15 + -8);
                uVar7 = *(undefined4 *)(iVar15 + -4);
                *puVar9 = *(undefined4 *)(iVar15 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar15 = *(int64_t *)(iVar15 + -0x20);
                    if (((*(uint8_t *)(iVar15 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar3 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar3 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar15 + 1) = *(uint8_t *)(iVar15 + 1) & 0xfb;
                            *(undefined8 *)(iVar15 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                            *(int64_t *)(iVar3 + 0x18) = iVar15;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar15 = *(int64_t *)(iVar2 + 0x48);
            } while ((uint64_t)(int64_t)iVar14 < (uint64_t)((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f5e8
// Address: 0x18005f5e8
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18005f410(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    undefined8 *puVar13;
    int32_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar12 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar12 = (int64_t **)*piVar11;
        } else {
            ppiVar12 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar12;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar15 = *(int64_t *)(iVar2 + 0x48);
        if ((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70 != 0) {
            iVar14 = 0;
            do {
                puVar13 = *(undefined8 **)(*(int64_t *)((int64_t)iVar14 * 0x70 + 8 + iVar15) + 0x28);
                if (0xf < (uint64_t)puVar13[3]) {
                    puVar13 = (undefined8 *)*puVar13;
                }
                if (puVar13 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar13);
                    func_0x0001800867f0(arg1, puVar13, uVar10);
                }
                iVar15 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar15 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar14 = iVar14 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar15 + -0x20), iVar14);
                uVar5 = *(undefined4 *)(iVar15 + -0xc);
                uVar6 = *(undefined4 *)(iVar15 + -8);
                uVar7 = *(undefined4 *)(iVar15 + -4);
                *puVar9 = *(undefined4 *)(iVar15 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar15 = *(int64_t *)(iVar15 + -0x20);
                    if (((*(uint8_t *)(iVar15 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar3 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar3 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar15 + 1) = *(uint8_t *)(iVar15 + 1) & 0xfb;
                            *(undefined8 *)(iVar15 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                            *(int64_t *)(iVar3 + 0x18) = iVar15;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar15 = *(int64_t *)(iVar2 + 0x48);
            } while ((uint64_t)(int64_t)iVar14 < (uint64_t)((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f5ee
// Address: 0x18005f5ee
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18005f410(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    undefined8 *puVar13;
    int32_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar12 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar12 = (int64_t **)*piVar11;
        } else {
            ppiVar12 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar12;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar15 = *(int64_t *)(iVar2 + 0x48);
        if ((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70 != 0) {
            iVar14 = 0;
            do {
                puVar13 = *(undefined8 **)(*(int64_t *)((int64_t)iVar14 * 0x70 + 8 + iVar15) + 0x28);
                if (0xf < (uint64_t)puVar13[3]) {
                    puVar13 = (undefined8 *)*puVar13;
                }
                if (puVar13 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar13);
                    func_0x0001800867f0(arg1, puVar13, uVar10);
                }
                iVar15 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar15 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar14 = iVar14 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010(arg1, *(int64_t *)(iVar15 + -0x20), iVar14);
                uVar5 = *(undefined4 *)(iVar15 + -0xc);
                uVar6 = *(undefined4 *)(iVar15 + -8);
                uVar7 = *(undefined4 *)(iVar15 + -4);
                *puVar9 = *(undefined4 *)(iVar15 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar15 = *(int64_t *)(iVar15 + -0x20);
                    if (((*(uint8_t *)(iVar15 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar3 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar3 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar15 + 1) = *(uint8_t *)(iVar15 + 1) & 0xfb;
                            *(undefined8 *)(iVar15 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
                            *(int64_t *)(iVar3 + 0x18) = iVar15;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
                iVar15 = *(int64_t *)(iVar2 + 0x48);
            } while ((uint64_t)(int64_t)iVar14 < (uint64_t)((*(int64_t *)(iVar2 + 0x50) - iVar15) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f620
// Address: 0x18005f620
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005f620(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t **ppiVar14;
    undefined8 *puVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar14 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar14 = (int64_t **)*piVar11;
        } else {
            ppiVar14 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar14;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar13 = 0;
        iVar12 = *(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48);
        iVar3 = iVar12 >> 0x3f;
        if (iVar12 / 0x70 + iVar3 != iVar3) {
            do {
                func_0x000180086fd0(arg1, 0, 0);
                puVar15 = *(undefined8 **)((int64_t)iVar13 * 0x70 + *(int64_t *)(iVar2 + 0x48));
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x180622ff4);
                puVar15 = *(undefined8 **)(*(int64_t *)((int64_t)iVar13 * 0x70 + 8 + *(int64_t *)(iVar2 + 0x48)) + 0x28)
                ;
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x18062487c);
                iVar3 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar13 = iVar13 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010();
                uVar5 = *(undefined4 *)(iVar3 + -0xc);
                uVar6 = *(undefined4 *)(iVar3 + -8);
                uVar7 = *(undefined4 *)(iVar3 + -4);
                *puVar9 = *(undefined4 *)(iVar3 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar3 = *(int64_t *)(iVar3 + -0x20);
                    if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar12 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar12 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar12 + 0x18);
                            *(int64_t *)(iVar12 + 0x18) = iVar3;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((uint64_t)(int64_t)iVar13 <
                     (uint64_t)((*(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48)) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f682
// Address: 0x18005f682
// Size: 488 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005f620(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t **ppiVar14;
    undefined8 *puVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar14 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar14 = (int64_t **)*piVar11;
        } else {
            ppiVar14 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar14;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar13 = 0;
        iVar12 = *(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48);
        iVar3 = iVar12 >> 0x3f;
        if (iVar12 / 0x70 + iVar3 != iVar3) {
            do {
                func_0x000180086fd0(arg1, 0, 0);
                puVar15 = *(undefined8 **)((int64_t)iVar13 * 0x70 + *(int64_t *)(iVar2 + 0x48));
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x180622ff4);
                puVar15 = *(undefined8 **)(*(int64_t *)((int64_t)iVar13 * 0x70 + 8 + *(int64_t *)(iVar2 + 0x48)) + 0x28)
                ;
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x18062487c);
                iVar3 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar13 = iVar13 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010();
                uVar5 = *(undefined4 *)(iVar3 + -0xc);
                uVar6 = *(undefined4 *)(iVar3 + -8);
                uVar7 = *(undefined4 *)(iVar3 + -4);
                *puVar9 = *(undefined4 *)(iVar3 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar3 = *(int64_t *)(iVar3 + -0x20);
                    if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar12 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar12 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar12 + 0x18);
                            *(int64_t *)(iVar12 + 0x18) = iVar3;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((uint64_t)(int64_t)iVar13 <
                     (uint64_t)((*(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48)) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f86a
// Address: 0x18005f86a
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005f620(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t **ppiVar14;
    undefined8 *puVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar14 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar14 = (int64_t **)*piVar11;
        } else {
            ppiVar14 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar14;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar13 = 0;
        iVar12 = *(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48);
        iVar3 = iVar12 >> 0x3f;
        if (iVar12 / 0x70 + iVar3 != iVar3) {
            do {
                func_0x000180086fd0(arg1, 0, 0);
                puVar15 = *(undefined8 **)((int64_t)iVar13 * 0x70 + *(int64_t *)(iVar2 + 0x48));
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x180622ff4);
                puVar15 = *(undefined8 **)(*(int64_t *)((int64_t)iVar13 * 0x70 + 8 + *(int64_t *)(iVar2 + 0x48)) + 0x28)
                ;
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x18062487c);
                iVar3 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar13 = iVar13 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010();
                uVar5 = *(undefined4 *)(iVar3 + -0xc);
                uVar6 = *(undefined4 *)(iVar3 + -8);
                uVar7 = *(undefined4 *)(iVar3 + -4);
                *puVar9 = *(undefined4 *)(iVar3 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar3 = *(int64_t *)(iVar3 + -0x20);
                    if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar12 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar12 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar12 + 0x18);
                            *(int64_t *)(iVar12 + 0x18) = iVar3;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((uint64_t)(int64_t)iVar13 <
                     (uint64_t)((*(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48)) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f870
// Address: 0x18005f870
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18005f620(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *piVar11;
    int64_t iVar12;
    int32_t iVar13;
    int64_t **ppiVar14;
    undefined8 *puVar15;
    uint32_t uVar16;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    piVar11 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar8 + 0xc) != 9)) {
        fcn.180088470(arg1, 1, 9);
        pcVar4 = (code *)swi(3);
        uVar10 = (*pcVar4)();
        return uVar10;
    }
    piVar8 = piVar11;
    if (piVar1 <= piVar11) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) == 9) {
        uVar16 = (uint32_t)*(uint8_t *)(*piVar8 + 3);
    } else {
        uVar16 = 0xffffffff;
    }
    if (uVar16 == *(uint32_t *)0x1807823d4) {
        if (piVar1 <= piVar11) {
            piVar11 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar11 + 0xc) == 9) {
            ppiVar14 = (int64_t **)(*piVar11 + 0x10);
        } else if (*(int32_t *)((int64_t)piVar11 + 0xc) == 2) {
            ppiVar14 = (int64_t **)*piVar11;
        } else {
            ppiVar14 = (int64_t **)0x0;
        }
        piVar11 = *ppiVar14;
        func_0x000180086fd0(arg1, 0, 0);
        iVar2 = *piVar11;
        iVar13 = 0;
        iVar12 = *(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48);
        iVar3 = iVar12 >> 0x3f;
        if (iVar12 / 0x70 + iVar3 != iVar3) {
            do {
                func_0x000180086fd0(arg1, 0, 0);
                puVar15 = *(undefined8 **)((int64_t)iVar13 * 0x70 + *(int64_t *)(iVar2 + 0x48));
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x180622ff4);
                puVar15 = *(undefined8 **)(*(int64_t *)((int64_t)iVar13 * 0x70 + 8 + *(int64_t *)(iVar2 + 0x48)) + 0x28)
                ;
                if (0xf < (uint64_t)puVar15[3]) {
                    puVar15 = (undefined8 *)*puVar15;
                }
                if (puVar15 == (undefined8 *)0x0) {
                    func_0x000180086510(arg1);
                } else {
                    uVar10 = func_0x000180498cd0(puVar15);
                    func_0x0001800867f0(arg1, puVar15, uVar10);
                }
                func_0x000180087370(arg1, 0xfffffffe, 0x18062487c);
                iVar3 = *(int64_t *)(arg1 + 0x40);
                if (*(char *)(*(int64_t *)(iVar3 + -0x20) + 4) != '\0') {
                    func_0x000180092f10(arg1);
                    pcVar4 = (code *)swi(3);
                    uVar10 = (*pcVar4)();
                    return uVar10;
                }
                iVar13 = iVar13 + 1;
                puVar9 = (undefined4 *)func_0x0001800a1010();
                uVar5 = *(undefined4 *)(iVar3 + -0xc);
                uVar6 = *(undefined4 *)(iVar3 + -8);
                uVar7 = *(undefined4 *)(iVar3 + -4);
                *puVar9 = *(undefined4 *)(iVar3 + -0x10);
                puVar9[1] = uVar5;
                puVar9[2] = uVar6;
                puVar9[3] = uVar7;
                if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                    iVar3 = *(int64_t *)(iVar3 + -0x20);
                    if (((*(uint8_t *)(iVar3 + 1) & 4) != 0) &&
                       ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                        iVar12 = *(int64_t *)(arg1 + 0x20);
                        if (*(char *)(iVar12 + 0x59) == '\x02') {
                            func_0x000180094420();
                        } else {
                            *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar3 + 1) & 0xfb;
                            *(undefined8 *)(iVar3 + 0x18) = *(undefined8 *)(iVar12 + 0x18);
                            *(int64_t *)(iVar12 + 0x18) = iVar3;
                        }
                    }
                }
                *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
            } while ((uint64_t)(int64_t)iVar13 <
                     (uint64_t)((*(int64_t *)(iVar2 + 0x50) - *(int64_t *)(iVar2 + 0x48)) / 0x70));
        }
        return 1;
    }
    func_0x000180088380(arg1, 1, 0x180624758);
    pcVar4 = (code *)swi(3);
    uVar10 = (*pcVar4)();
    return uVar10;
}

// ============================================================
// Function: FUN_18005f8a0
// Address: 0x18005f8a0
// Size: 736 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e0h

int64_t * fcn.18005f8a0(int64_t arg1, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    undefined8 uVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t iStack_98;
    int64_t iStack_90;
    int64_t iStack_88;
    int64_t iStack_80;
    int64_t var_58h;
    int64_t var_50h;
    
    iStack_80 = 0x18005f8c5;
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
    iStack_80 = 0x18005f8dd;
    func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf20);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar12 = *(undefined4 **)(arg1 + 0x40);
    puVar3 = puVar12;
    while (puVar12 + -8 < puVar3) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
        puVar3 = puVar3 + -4;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    puVar12[-8] = *puVar3;
    puVar12[-7] = uVar7;
    puVar12[-6] = uVar8;
    puVar12[-5] = uVar9;
    iStack_80 = 0x18005f941;
    func_0x0001800867f0(arg1, 0x180624020, 0xd);
    iStack_80 = 0x18005f954;
    iVar10 = func_0x0001800878a0(arg1, 2, 1);
    if ((iVar10 == 0) && ((iVar10 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4), iVar10 == 9 || (iVar10 == 2)))) {
        iStack_80 = 0x18005f983;
        func_0x000180086cc0(arg1, 0xffffffff, 0x1806247b8);
        iVar13 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar13 + -4) == 9) {
            piVar14 = (int64_t *)(*(int64_t *)(iVar13 + -0x10) + 0x10);
        } else if (*(int32_t *)(iVar13 + -4) == 2) {
            piVar14 = *(int64_t **)(iVar13 + -0x10);
        } else {
            piVar14 = (int64_t *)0x0;
        }
        if (piVar14[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar14[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_58h = *piVar14;
        piVar14 = (int64_t *)piVar14[1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
        iVar13 = *(int64_t *)(*(int64_t *)(*(int64_t *)(var_58h + 0x3070) + 0x38) + 8);
        iStack_80 = 0x18005f9eb;
        var_50h = (int64_t)piVar14;
        func_0x000180086fd0(arg1, 0, 0);
        for (iVar4 = *(int64_t *)(iVar13 + 8); iVar4 != iVar13; iVar4 = *(int64_t *)(iVar4 + 8)) {
            iVar5 = *(int64_t *)(iVar4 + 0x10);
            iStack_80 = 0x18005fa11;
            func_0x000180086fd0(arg1, 0, 0);
            puVar17 = *(undefined8 **)(iVar5 + 8);
            if (0xf < (uint64_t)puVar17[3]) {
                puVar17 = (undefined8 *)*puVar17;
            }
            if (puVar17 == (undefined8 *)0x0) {
                iStack_80 = 0x18005fa2c;
                func_0x000180086510(arg1);
            } else {
                iStack_80 = 0x18005fa36;
                uVar11 = func_0x000180498cd0(puVar17);
                iStack_80 = 0x18005fa44;
                func_0x0001800867f0(arg1, puVar17, uVar11);
            }
            iStack_80 = 0x18005fa58;
            func_0x000180087370(arg1, 0xfffffffe, 0x1806248d4);
            puVar17 = *(undefined8 **)(*(int64_t *)(iVar5 + 0x30) + 8);
            if (0xf < (uint64_t)puVar17[3]) {
                puVar17 = (undefined8 *)*puVar17;
            }
            if (puVar17 == (undefined8 *)0x0) {
                iStack_80 = 0x18005fa77;
                func_0x000180086510(arg1);
            } else {
                iStack_80 = 0x18005fa81;
                uVar11 = func_0x000180498cd0(puVar17);
                iStack_80 = 0x18005fa8f;
                func_0x0001800867f0(arg1, puVar17, uVar11);
            }
            iStack_80 = 0x18005faa3;
            func_0x000180087370(arg1, 0xfffffffe, 0x180623bdc);
            iVar6 = *(int64_t *)(arg1 + 0x40);
            iVar15 = *(int64_t *)(iVar6 + -0x20);
            if (*(char *)(iVar15 + 4) != '\0') {
                iStack_80 = 0x18005fb7f;
                func_0x000180092f10(arg1);
                iStack_98 = iVar6;
                iStack_90 = iVar4;
                iStack_88 = iVar5;
                iStack_80 = arg1;
                func_0x000180018f70();
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_d0h = 0x1806248e0;
                func_0x0001800869f0(iVar15, 0x18005e470, 0x1806248b8, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x1806248b8);
                piVar14 = &var_d0h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x1806248b8);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_c8h);
                iVar13 = *(int64_t *)(iVar15 + 0x40);
                iVar4 = *(int64_t *)(iVar15 + 0x28);
                func_0x0001800869f0(iVar15, fcn.18005e970, 0x1806248c8, 0, 0);
                func_0x000180087370(iVar15, iVar13 - iVar4 >> 4 & 0xffffffff, 0x1806248c8);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_c8h = 0x180624918;
                func_0x0001800869f0(iVar15, fcn.18005ebc0, 0x180624930, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624930);
                piVar14 = &var_c8h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624930);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_c0h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_c0h = 0x1806248f0;
                func_0x0001800869f0(iVar15, fcn.18005eed0, 0x180624908, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624908);
                piVar14 = &var_c0h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624908);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_b8h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_b8h = 0x180624980;
                func_0x0001800869f0(iVar15, fcn.18005f410, 0x180624998, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624998);
                piVar14 = &var_b8h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624998);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_b0h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_b0h = 0x180624948;
                func_0x0001800869f0(iVar15, fcn.18005f620, 0x180624968, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624968);
                piVar14 = &var_b0h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624968);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_a8h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_a8h = 0x1806249b0;
                func_0x0001800869f0(iVar15, fcn.18005f8a0, 0x1806249c8, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x1806249c8);
                piVar14 = &var_a8h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x1806249c8);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_a0h);
                return &var_a0h;
            }
            iStack_80 = 0x18005fac3;
            puVar12 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar6 + -0xc);
            uVar8 = *(undefined4 *)(iVar6 + -8);
            uVar9 = *(undefined4 *)(iVar6 + -4);
            *puVar12 = *(undefined4 *)(iVar6 + -0x10);
            puVar12[1] = uVar7;
            puVar12[2] = uVar8;
            puVar12[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar5 = *(int64_t *)(iVar6 + -0x20);
                if (((*(uint8_t *)(iVar5 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar6 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar6 + 0x59) == '\x02') {
                        iStack_80 = 0x18005fafa;
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar5 + 1) = *(uint8_t *)(iVar5 + 1) & 0xfb;
                        *(undefined8 *)(iVar5 + 0x18) = *(undefined8 *)(iVar6 + 0x18);
                        *(int64_t *)(iVar6 + 0x18) = iVar5;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        }
        if (piVar14 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar14 + 1;
            iVar10 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar10 == 1) {
                iStack_80 = 0x18005fb3b;
                (**(code **)*piVar14)(piVar14);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar14 + 0xc);
                iVar10 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar10 == 1) {
                    iStack_80 = 0x18005fb50;
                    (**(code **)(*piVar14 + 8))(piVar14);
                }
            }
        }
    } else {
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
        iStack_80 = 0x18005fb64;
        func_0x000180086fd0(arg1, 0, 0);
    }
    return (int64_t *)0x1;
}

// ============================================================
// Function: FUN_18005fb80
// Address: 0x18005fb80
// Size: 993 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e0h

int64_t * fcn.18005f8a0(int64_t arg1, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    undefined8 uVar11;
    undefined4 *puVar12;
    int64_t iVar13;
    int64_t *piVar14;
    int64_t iVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    int64_t var_8h;
    int64_t var_e0h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t iStack_98;
    int64_t iStack_90;
    int64_t iStack_88;
    int64_t iStack_80;
    int64_t var_58h;
    int64_t var_50h;
    
    iStack_80 = 0x18005f8c5;
    func_0x000180086cc0(arg1, 0xffffd8ee, 0x1805aaed0);
    iStack_80 = 0x18005f8dd;
    func_0x000180086cc0(arg1, 0xffffffff, 0x1805aaf20);
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    puVar12 = *(undefined4 **)(arg1 + 0x40);
    puVar3 = puVar12;
    while (puVar12 + -8 < puVar3) {
        *puVar3 = puVar3[-4];
        puVar3[1] = puVar3[-3];
        puVar3[2] = puVar3[-2];
        puVar3[3] = puVar3[-1];
        puVar3 = puVar3 + -4;
    }
    puVar3 = *(undefined4 **)(arg1 + 0x40);
    uVar7 = puVar3[1];
    uVar8 = puVar3[2];
    uVar9 = puVar3[3];
    puVar12[-8] = *puVar3;
    puVar12[-7] = uVar7;
    puVar12[-6] = uVar8;
    puVar12[-5] = uVar9;
    iStack_80 = 0x18005f941;
    func_0x0001800867f0(arg1, 0x180624020, 0xd);
    iStack_80 = 0x18005f954;
    iVar10 = func_0x0001800878a0(arg1, 2, 1);
    if ((iVar10 == 0) && ((iVar10 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4), iVar10 == 9 || (iVar10 == 2)))) {
        iStack_80 = 0x18005f983;
        func_0x000180086cc0(arg1, 0xffffffff, 0x1806247b8);
        iVar13 = *(int64_t *)(arg1 + 0x40);
        if (*(int32_t *)(iVar13 + -4) == 9) {
            piVar14 = (int64_t *)(*(int64_t *)(iVar13 + -0x10) + 0x10);
        } else if (*(int32_t *)(iVar13 + -4) == 2) {
            piVar14 = *(int64_t **)(iVar13 + -0x10);
        } else {
            piVar14 = (int64_t *)0x0;
        }
        if (piVar14[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar14[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_58h = *piVar14;
        piVar14 = (int64_t *)piVar14[1];
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
        iVar13 = *(int64_t *)(*(int64_t *)(*(int64_t *)(var_58h + 0x3070) + 0x38) + 8);
        iStack_80 = 0x18005f9eb;
        var_50h = (int64_t)piVar14;
        func_0x000180086fd0(arg1, 0, 0);
        for (iVar4 = *(int64_t *)(iVar13 + 8); iVar4 != iVar13; iVar4 = *(int64_t *)(iVar4 + 8)) {
            iVar5 = *(int64_t *)(iVar4 + 0x10);
            iStack_80 = 0x18005fa11;
            func_0x000180086fd0(arg1, 0, 0);
            puVar17 = *(undefined8 **)(iVar5 + 8);
            if (0xf < (uint64_t)puVar17[3]) {
                puVar17 = (undefined8 *)*puVar17;
            }
            if (puVar17 == (undefined8 *)0x0) {
                iStack_80 = 0x18005fa2c;
                func_0x000180086510(arg1);
            } else {
                iStack_80 = 0x18005fa36;
                uVar11 = func_0x000180498cd0(puVar17);
                iStack_80 = 0x18005fa44;
                func_0x0001800867f0(arg1, puVar17, uVar11);
            }
            iStack_80 = 0x18005fa58;
            func_0x000180087370(arg1, 0xfffffffe, 0x1806248d4);
            puVar17 = *(undefined8 **)(*(int64_t *)(iVar5 + 0x30) + 8);
            if (0xf < (uint64_t)puVar17[3]) {
                puVar17 = (undefined8 *)*puVar17;
            }
            if (puVar17 == (undefined8 *)0x0) {
                iStack_80 = 0x18005fa77;
                func_0x000180086510(arg1);
            } else {
                iStack_80 = 0x18005fa81;
                uVar11 = func_0x000180498cd0(puVar17);
                iStack_80 = 0x18005fa8f;
                func_0x0001800867f0(arg1, puVar17, uVar11);
            }
            iStack_80 = 0x18005faa3;
            func_0x000180087370(arg1, 0xfffffffe, 0x180623bdc);
            iVar6 = *(int64_t *)(arg1 + 0x40);
            iVar15 = *(int64_t *)(iVar6 + -0x20);
            if (*(char *)(iVar15 + 4) != '\0') {
                iStack_80 = 0x18005fb7f;
                func_0x000180092f10(arg1);
                iStack_98 = iVar6;
                iStack_90 = iVar4;
                iStack_88 = iVar5;
                iStack_80 = arg1;
                func_0x000180018f70();
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_d0h = 0x1806248e0;
                func_0x0001800869f0(iVar15, 0x18005e470, 0x1806248b8, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x1806248b8);
                piVar14 = &var_d0h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x1806248b8);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_c8h);
                iVar13 = *(int64_t *)(iVar15 + 0x40);
                iVar4 = *(int64_t *)(iVar15 + 0x28);
                func_0x0001800869f0(iVar15, fcn.18005e970, 0x1806248c8, 0, 0);
                func_0x000180087370(iVar15, iVar13 - iVar4 >> 4 & 0xffffffff, 0x1806248c8);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_c8h = 0x180624918;
                func_0x0001800869f0(iVar15, fcn.18005ebc0, 0x180624930, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624930);
                piVar14 = &var_c8h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624930);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_c0h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_c0h = 0x1806248f0;
                func_0x0001800869f0(iVar15, fcn.18005eed0, 0x180624908, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624908);
                piVar14 = &var_c0h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624908);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_b8h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_b8h = 0x180624980;
                func_0x0001800869f0(iVar15, fcn.18005f410, 0x180624998, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624998);
                piVar14 = &var_b8h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624998);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_b0h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_b0h = 0x180624948;
                func_0x0001800869f0(iVar15, fcn.18005f620, 0x180624968, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x180624968);
                piVar14 = &var_b0h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x180624968);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_a8h);
                uVar16 = *(int64_t *)(iVar15 + 0x40) - *(int64_t *)(iVar15 + 0x28) >> 4;
                var_a8h = 0x1806249b0;
                func_0x0001800869f0(iVar15, fcn.18005f8a0, 0x1806249c8, 0, 0);
                func_0x000180087370(iVar15, uVar16 & 0xffffffff, 0x1806249c8);
                piVar14 = &var_a8h;
                do {
                    func_0x000180086cc0(iVar15, uVar16 & 0xffffffff, 0x1806249c8);
                    iVar13 = *(int64_t *)(iVar15 + 0x40) + -0x10;
                    if ((iVar13 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(iVar15 + 0x40) + -4) != 0)) {
                        func_0x000180087370(iVar15, uVar16 & 0xffffffff, *piVar14);
                    } else {
                        *(int64_t *)(iVar15 + 0x40) = iVar13;
                    }
                    piVar14 = piVar14 + 1;
                } while (piVar14 != &var_a0h);
                return &var_a0h;
            }
            iStack_80 = 0x18005fac3;
            puVar12 = (undefined4 *)func_0x0001800a1010();
            uVar7 = *(undefined4 *)(iVar6 + -0xc);
            uVar8 = *(undefined4 *)(iVar6 + -8);
            uVar9 = *(undefined4 *)(iVar6 + -4);
            *puVar12 = *(undefined4 *)(iVar6 + -0x10);
            puVar12[1] = uVar7;
            puVar12[2] = uVar8;
            puVar12[3] = uVar9;
            if (5 < *(int32_t *)(*(int64_t *)(arg1 + 0x40) + -4)) {
                iVar5 = *(int64_t *)(iVar6 + -0x20);
                if (((*(uint8_t *)(iVar5 + 1) & 4) != 0) &&
                   ((*(uint8_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + -0x10) + 1) & 3) != 0)) {
                    iVar6 = *(int64_t *)(arg1 + 0x20);
                    if (*(char *)(iVar6 + 0x59) == '\x02') {
                        iStack_80 = 0x18005fafa;
                        func_0x000180094420();
                    } else {
                        *(uint8_t *)(iVar5 + 1) = *(uint8_t *)(iVar5 + 1) & 0xfb;
                        *(undefined8 *)(iVar5 + 0x18) = *(undefined8 *)(iVar6 + 0x18);
                        *(int64_t *)(iVar6 + 0x18) = iVar5;
                    }
                }
            }
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x10;
        }
        if (piVar14 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar14 + 1;
            iVar10 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar10 == 1) {
                iStack_80 = 0x18005fb3b;
                (**(code **)*piVar14)(piVar14);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar14 + 0xc);
                iVar10 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar10 == 1) {
                    iStack_80 = 0x18005fb50;
                    (**(code **)(*piVar14 + 8))(piVar14);
                }
            }
        }
    } else {
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + -0x20;
        iStack_80 = 0x18005fb64;
        func_0x000180086fd0(arg1, 0, 0);
    }
    return (int64_t *)0x1;
}

// ============================================================
// Function: FUN_18005ff80
// Address: 0x18005ff80
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18005ff80(void)
{
    char cVar1;
    int64_t *piVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)0x1807826e0;
    cVar1 = *(char *)((int64_t)*(int64_t **)(*(int64_t *)0x1807826e0 + 8) + 0x19);
    piVar3 = *(int64_t **)(*(int64_t *)0x1807826e0 + 8);
    while (cVar1 == '\0') {
        func_0x00018000ee20(0x1807826e0, 0x1807826e0, piVar3[2]);
        piVar2 = (int64_t *)*piVar3;
        func_0x000180459c3c(piVar3, 0x30);
        piVar3 = piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    *(int64_t *)(iVar4 + 8) = iVar4;
    *(int64_t *)iVar4 = iVar4;
    *(int64_t *)(iVar4 + 0x10) = iVar4;
    *(undefined8 *)0x1807826e8 = 0;
    return;
}

// ============================================================
// Function: FUN_18005fff0
// Address: 0x18005fff0
// Size: 811 bytes
// ============================================================
int64_t ** fcn.18005fff0(undefined8 placeholder_0, int64_t arg2)
{
    char cVar1;
    int64_t **ppiVar2;
    int64_t *piVar3;
    code *pcVar4;
    int64_t **ppiVar5;
    int64_t **ppiVar6;
    int64_t **ppiVar7;
    int64_t **ppiVar8;
    int64_t *piVar9;
    bool bVar10;
    int64_t var_38h;
    int64_t var_30h;
    
    ppiVar5 = *(int64_t ***)0x1807826e0;
    ppiVar8 = (int64_t **)(*(int64_t ***)0x1807826e0)[1];
    ppiVar7 = *(int64_t ***)0x1807826e0;
    if (*(char *)((int64_t)ppiVar8 + 0x19) == '\0') {
        ppiVar6 = ppiVar8;
        do {
            ppiVar8 = ppiVar6;
            bVar10 = *(int64_t **)arg2 <= ppiVar8[4];
            if (bVar10) {
                ppiVar6 = (int64_t **)*ppiVar8;
                ppiVar7 = ppiVar8;
            } else {
                ppiVar6 = (int64_t **)ppiVar8[2];
            }
        } while (*(char *)((int64_t)ppiVar6 + 0x19) == '\0');
    } else {
        bVar10 = false;
    }
    if ((*(char *)((int64_t)ppiVar7 + 0x19) != '\0') || (*(int64_t **)arg2 < ppiVar7[4])) {
        if (*(int64_t *)0x1807826e8 == 0x555555555555555) {
            func_0x000180013c00();
            pcVar4 = (code *)swi(3);
            ppiVar8 = (int64_t **)(*pcVar4)();
            return ppiVar8;
        }
        ppiVar7 = (int64_t **)func_0x000180459890(0x30);
        ppiVar7[4] = *(int64_t **)arg2;
        ppiVar7[5] = (int64_t *)0x0;
        *ppiVar7 = (int64_t *)ppiVar5;
        ppiVar7[2] = (int64_t *)ppiVar5;
        *(undefined2 *)(ppiVar7 + 3) = 0;
        ppiVar5 = *(int64_t ***)0x1807826e0;
        *(int64_t *)0x1807826e8 = *(int64_t *)0x1807826e8 + 1;
        ppiVar7[1] = (int64_t *)ppiVar8;
        if (ppiVar8 == ppiVar5) {
            *ppiVar5 = (int64_t *)ppiVar7;
            ppiVar5[1] = (int64_t *)ppiVar7;
            ppiVar5[2] = (int64_t *)ppiVar7;
            ppiVar8 = ppiVar7;
        } else {
            if (bVar10) {
                *ppiVar8 = (int64_t *)ppiVar7;
                if (ppiVar8 == (int64_t **)*ppiVar5) {
                    *ppiVar5 = (int64_t *)ppiVar7;
                }
            } else {
                ppiVar8[2] = (int64_t *)ppiVar7;
                if (ppiVar8 == (int64_t **)ppiVar5[2]) {
                    ppiVar5[2] = (int64_t *)ppiVar7;
                }
            }
            cVar1 = *(char *)(ppiVar7[1] + 3);
            ppiVar8 = ppiVar7;
            while (cVar1 == '\0') {
                ppiVar6 = (int64_t **)ppiVar8[1];
                ppiVar2 = (int64_t **)*ppiVar6[1];
                if (ppiVar6 == ppiVar2) {
                    piVar9 = (int64_t *)ppiVar6[1][2];
                    if (*(char *)(piVar9 + 3) == '\0') {
                        *(undefined *)(ppiVar6 + 3) = 1;
                        *(undefined *)(piVar9 + 3) = 1;
                        *(undefined *)(ppiVar8[1][1] + 0x18) = 0;
                        ppiVar8 = (int64_t **)ppiVar8[1][1];
                    } else {
                        ppiVar2 = (int64_t **)ppiVar6[2];
                        if (ppiVar8 == ppiVar2) {
                            ppiVar6[2] = *ppiVar2;
                            if (*(char *)((int64_t)*ppiVar2 + 0x19) == '\0') {
                                (*ppiVar2)[1] = (int64_t)ppiVar6;
                            }
                            ppiVar2[1] = ppiVar6[1];
                            if (ppiVar6 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar2;
                            } else {
                                ppiVar8 = (int64_t **)ppiVar6[1];
                                if (ppiVar6 == (int64_t **)*ppiVar8) {
                                    *ppiVar8 = (int64_t *)ppiVar2;
                                } else {
                                    ppiVar8[2] = (int64_t *)ppiVar2;
                                }
                            }
                            *ppiVar2 = (int64_t *)ppiVar6;
                            ppiVar6[1] = (int64_t *)ppiVar2;
                            ppiVar8 = ppiVar6;
                        }
                        *(undefined *)(ppiVar8[1] + 3) = 1;
                        *(undefined *)(ppiVar8[1][1] + 0x18) = 0;
                        piVar9 = (int64_t *)ppiVar8[1][1];
                        ppiVar6 = (int64_t **)*piVar9;
                        *piVar9 = (int64_t)ppiVar6[2];
                        if (*(char *)((int64_t)ppiVar6[2] + 0x19) == '\0') {
                            *(int64_t **)((int64_t)ppiVar6[2] + 8) = piVar9;
                        }
                        ppiVar6[1] = (int64_t *)piVar9[1];
                        if (piVar9 == (*(int64_t ***)0x1807826e0)[1]) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar6;
                            ppiVar6[2] = piVar9;
                        } else {
                            piVar3 = (int64_t *)piVar9[1];
                            if (piVar9 == (int64_t *)piVar3[2]) {
                                piVar3[2] = (int64_t)ppiVar6;
                                ppiVar6[2] = piVar9;
                            } else {
                                *piVar3 = (int64_t)ppiVar6;
                                ppiVar6[2] = piVar9;
                            }
                        }
code_r0x0001800602ed:
                        piVar9[1] = (int64_t)ppiVar6;
                    }
                } else {
                    if (*(char *)(ppiVar2 + 3) != '\0') {
                        ppiVar2 = (int64_t **)*ppiVar6;
                        if (ppiVar8 == ppiVar2) {
                            *ppiVar6 = ppiVar2[2];
                            if (*(char *)((int64_t)ppiVar2[2] + 0x19) == '\0') {
                                ppiVar2[2][1] = (int64_t)ppiVar6;
                            }
                            ppiVar2[1] = ppiVar6[1];
                            if (ppiVar6 == (int64_t **)(*(int64_t ***)0x1807826e0)[1]) {
                                (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar2;
                            } else {
                                ppiVar8 = (int64_t **)ppiVar6[1];
                                if (ppiVar6 == (int64_t **)ppiVar8[2]) {
                                    ppiVar8[2] = (int64_t *)ppiVar2;
                                } else {
                                    *ppiVar8 = (int64_t *)ppiVar2;
                                }
                            }
                            ppiVar2[2] = (int64_t *)ppiVar6;
                            ppiVar6[1] = (int64_t *)ppiVar2;
                            ppiVar8 = ppiVar6;
                        }
                        *(undefined *)(ppiVar8[1] + 3) = 1;
                        *(undefined *)(ppiVar8[1][1] + 0x18) = 0;
                        piVar9 = (int64_t *)ppiVar8[1][1];
                        ppiVar6 = (int64_t **)piVar9[2];
                        piVar9[2] = (int64_t)*ppiVar6;
                        if (*(char *)((int64_t)*ppiVar6 + 0x19) == '\0') {
                            (*ppiVar6)[1] = (int64_t)piVar9;
                        }
                        ppiVar6[1] = (int64_t *)piVar9[1];
                        if (piVar9 == (*(int64_t ***)0x1807826e0)[1]) {
                            (*(int64_t ***)0x1807826e0)[1] = (int64_t *)ppiVar6;
                        } else {
                            ppiVar2 = (int64_t **)piVar9[1];
                            if (piVar9 == *ppiVar2) {
                                *ppiVar2 = (int64_t *)ppiVar6;
                            } else {
                                ppiVar2[2] = (int64_t *)ppiVar6;
                            }
                        }
                        *ppiVar6 = piVar9;
                        goto code_r0x0001800602ed;
                    }
                    *(undefined *)(ppiVar6 + 3) = 1;
                    *(undefined *)(ppiVar2 + 3) = 1;
                    *(undefined *)(ppiVar8[1][1] + 0x18) = 0;
                    ppiVar8 = (int64_t **)ppiVar8[1][1];
                }
                cVar1 = *(char *)(ppiVar8[1] + 3);
            }
            ppiVar8 = (int64_t **)ppiVar5[1];
        }
        *(undefined *)(ppiVar8 + 3) = 1;
    }
    return ppiVar7 + 5;
}

// ============================================================
// Function: FUN_180060370
// Address: 0x180060370
// Size: 17 bytes
// ============================================================
void fcn.180060370(void)
{
    code *pcVar1;
    
    fcn.1804546f8(0x1806249e0);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180060450
// Address: 0x180060450
// Size: 181 bytes
// ============================================================
undefined8 fcn.180060450(int64_t arg1)
{
    uint64_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined8 uVar5;
    
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    uVar1 = *(uint64_t *)(arg1 + 0x40);
    uVar3 = uVar4;
    if (uVar1 <= uVar4) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar3 + 0xc) == -1)) {
        fcn.180088560(arg1, 0x18063da20, 1);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    uVar4 = uVar4 + 0x10;
    uVar3 = uVar4;
    if (uVar1 <= uVar4) {
        uVar3 = *(uint64_t *)0x180782430;
    }
    if ((uVar3 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar3 + 0xc) != 0)) {
        if (uVar1 <= uVar4) {
            uVar4 = *(uint64_t *)0x180782430;
        }
        if ((uVar4 == *(uint64_t *)0x180782430) || (*(int32_t *)(uVar4 + 0xc) != 7)) {
            fcn.1800883d0(arg1, 2, 0x1806226e8);
            pcVar2 = (code *)swi(3);
            uVar5 = (*pcVar2)();
            return uVar5;
        }
    }
    func_0x000180085bf0(arg1, 2);
    func_0x000180087650(arg1, 1);
    func_0x000180085bf0(arg1, 1);
    return 1;
}

// ============================================================
// Function: FUN_180060510
// Address: 0x180060510
// Size: 86 bytes
// ============================================================
undefined8 fcn.180060510(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar2 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((piVar2 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar2 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        fcn.180086b20(arg1, *(undefined *)(*piVar4 + 4));
        return 1;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180060570
// Address: 0x180060570
// Size: 88 bytes
// ============================================================
undefined8 fcn.180060570(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar2 = piVar4;
    if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if ((piVar2 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar2 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        fcn.180086b20(arg1, ~(uint32_t)*(uint8_t *)(*piVar4 + 4));
        return 1;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800605d0
// Address: 0x1800605d0
// Size: 297 bytes
// ============================================================
undefined8 fcn.1800605d0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar6 = piVar4 + 2;
    piVar7 = piVar6;
    if (piVar1 <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 1)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) < 1)) {
            iVar3 = 0;
        } else {
            iVar3 = func_0x000180088860(arg1, 1);
        }
        piVar4 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar4 = *(int64_t **)0x180782430;
        }
        *(bool *)(*piVar4 + 4) = iVar3 == 0;
        return 0;
    }
    piVar7 = piVar6;
    if (piVar1 <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar7 + 0xc) == 1)) {
        if (piVar1 <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) != 0) &&
           ((*(int32_t *)((int64_t)piVar6 + 0xc) != 1 || (*(int32_t *)piVar6 != 0)))) {
            if (piVar1 <= piVar4) {
                piVar4 = *(int64_t **)0x180782430;
            }
            *(undefined *)(*piVar4 + 4) = 1;
            return 0;
        }
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        *(undefined *)(*piVar4 + 4) = 0;
        return 0;
    }
    fcn.180088470(arg1, 2, 1);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180060700
// Address: 0x180060700
// Size: 78 bytes
// ============================================================
undefined8 fcn.180060700(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int64_t **)0x180782430;
        }
        *(undefined *)(*piVar2 + 4) = 1;
        return 0;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180060750
// Address: 0x180060750
// Size: 78 bytes
// ============================================================
undefined8 fcn.180060750(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 7)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int64_t **)0x180782430;
        }
        *(undefined *)(*piVar2 + 4) = 0;
        return 0;
    }
    fcn.180088470(arg1, 1, 7);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_1800607a0
// Address: 0x1800607a0
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1800607a0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    iVar2 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        iVar2 = *(int64_t *)(arg1 + 8) + 0x18;
    }
    if (iVar2 != 0) {
        uVar1 = fcn.180498cd0(iVar2);
        fcn.1800867f0(arg1, iVar2, uVar1);
        return 1;
    }
    fcn.180086510();
    return 1;
}

// ============================================================
// Function: FUN_180060800
// Address: 0x180060800
// Size: 118 bytes
// ============================================================
undefined8 fcn.180060800(int64_t arg1)
{
    code *pcVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    undefined8 uVar4;
    
    puVar2 = *(undefined8 **)0x180782430;
    puVar3 = *(undefined8 **)(arg1 + 0x28);
    if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
        puVar3 = *(undefined8 **)0x180782430;
    }
    if ((puVar3 != *(undefined8 **)0x180782430) && (*(int32_t *)((int64_t)puVar3 + 0xc) == 6)) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        puVar3 = *(undefined8 **)(arg1 + 0x28);
        if (*(undefined8 **)(arg1 + 0x40) <= *(undefined8 **)(arg1 + 0x28)) {
            puVar3 = puVar2;
        }
        if (puVar3 == puVar2) {
            puVar3 = (undefined8 *)0x0;
        }
        *(undefined8 *)(arg1 + 8) = *puVar3;
        return 0;
    }
    fcn.180088470(arg1, 1, 6);
    pcVar1 = (code *)swi(3);
    uVar4 = (*pcVar1)();
    return uVar4;
}

// ============================================================
// Function: FUN_180060880
// Address: 0x180060880
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180060880(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar8;
    if (piVar11 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar9 = (*pcVar2)();
        return uVar9;
    }
    if (piVar11 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(char *)(*piVar8 + 4) == '\0') {
        iVar6 = func_0x000180087120(arg1, 1);
        if (iVar6 != 0) {
            fcn.1800867f0(arg1, 0x1806224a0, 0xb);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar11 + -2;
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + -4) != 0)) {
                if (piVar8 < piVar11) {
                    do {
                        uVar3 = *(undefined4 *)(piVar8 + 1);
                        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0xc);
                        *(undefined4 *)(piVar8 + -2) = *(undefined4 *)piVar8;
                        *(undefined4 *)((int64_t)piVar8 - 0xc) = *(undefined4 *)((int64_t)piVar8 + 4);
                        *(undefined4 *)(piVar8 + -1) = uVar3;
                        *(undefined4 *)((int64_t)piVar8 - 4) = uVar4;
                        piVar11 = *(int64_t **)(arg1 + 0x40);
                        piVar8 = piVar8 + 2;
                    } while (piVar8 < piVar11);
                }
                *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
                if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar11 + -2)) &&
                   (iVar6 = fcn.180085510(in_stack_00000010), iVar6 == 0)) goto code_r0x000180060a64;
                puVar7 = *(undefined4 **)(arg1 + 0x40);
                *puVar7 = 1;
                goto code_r0x000180060a2d;
            }
            *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
            puVar7 = *(undefined4 **)(arg1 + 0x40);
            *puVar7 = 0;
code_r0x000180060a2d:
            puVar7[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            return 1;
        }
    } else if (((*(char *)0x180777010 == '\0') || (piVar11 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
              (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = 1;
        puVar7[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
code_r0x000180060a64:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar9 = (*pcVar2)();
    return uVar9;
}

// ============================================================
// Function: FUN_180060928
// Address: 0x180060928
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180060880(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar8;
    if (piVar11 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar9 = (*pcVar2)();
        return uVar9;
    }
    if (piVar11 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(char *)(*piVar8 + 4) == '\0') {
        iVar6 = func_0x000180087120(arg1, 1);
        if (iVar6 != 0) {
            fcn.1800867f0(arg1, 0x1806224a0, 0xb);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar11 + -2;
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + -4) != 0)) {
                if (piVar8 < piVar11) {
                    do {
                        uVar3 = *(undefined4 *)(piVar8 + 1);
                        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0xc);
                        *(undefined4 *)(piVar8 + -2) = *(undefined4 *)piVar8;
                        *(undefined4 *)((int64_t)piVar8 - 0xc) = *(undefined4 *)((int64_t)piVar8 + 4);
                        *(undefined4 *)(piVar8 + -1) = uVar3;
                        *(undefined4 *)((int64_t)piVar8 - 4) = uVar4;
                        piVar11 = *(int64_t **)(arg1 + 0x40);
                        piVar8 = piVar8 + 2;
                    } while (piVar8 < piVar11);
                }
                *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
                if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar11 + -2)) &&
                   (iVar6 = fcn.180085510(in_stack_00000010), iVar6 == 0)) goto code_r0x000180060a64;
                puVar7 = *(undefined4 **)(arg1 + 0x40);
                *puVar7 = 1;
                goto code_r0x000180060a2d;
            }
            *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
            puVar7 = *(undefined4 **)(arg1 + 0x40);
            *puVar7 = 0;
code_r0x000180060a2d:
            puVar7[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            return 1;
        }
    } else if (((*(char *)0x180777010 == '\0') || (piVar11 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
              (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = 1;
        puVar7[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
code_r0x000180060a64:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar9 = (*pcVar2)();
    return uVar9;
}

// ============================================================
// Function: FUN_180060989
// Address: 0x180060989
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180060880(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    undefined4 *puVar7;
    int64_t *piVar8;
    undefined8 uVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    piVar8 = *(int64_t **)(arg1 + 0x28);
    piVar11 = *(int64_t **)(arg1 + 0x40);
    piVar10 = piVar8;
    if (piVar11 <= piVar8) {
        piVar10 = *(int64_t **)0x180782430;
    }
    if ((piVar10 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar10 + 0xc) != 7)) {
        fcn.180088470(arg1, 1, 7);
        pcVar2 = (code *)swi(3);
        uVar9 = (*pcVar2)();
        return uVar9;
    }
    if (piVar11 <= piVar8) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(char *)(*piVar8 + 4) == '\0') {
        iVar6 = func_0x000180087120(arg1, 1);
        if (iVar6 != 0) {
            fcn.1800867f0(arg1, 0x1806224a0, 0xb);
            if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
            }
            iVar1 = *(int64_t *)(arg1 + 0x40);
            puVar7 = (undefined4 *)func_0x0001800a0ea0(*(undefined8 *)(iVar1 + -0x20), (undefined4 *)(iVar1 + -0x10));
            uVar3 = puVar7[1];
            uVar4 = puVar7[2];
            uVar5 = puVar7[3];
            *(undefined4 *)(iVar1 + -0x10) = *puVar7;
            *(undefined4 *)(iVar1 + -0xc) = uVar3;
            *(undefined4 *)(iVar1 + -8) = uVar4;
            *(undefined4 *)(iVar1 + -4) = uVar5;
            piVar11 = *(int64_t **)(arg1 + 0x40);
            piVar8 = piVar11 + -2;
            if ((piVar8 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar11 + -4) != 0)) {
                if (piVar8 < piVar11) {
                    do {
                        uVar3 = *(undefined4 *)(piVar8 + 1);
                        uVar4 = *(undefined4 *)((int64_t)piVar8 + 0xc);
                        *(undefined4 *)(piVar8 + -2) = *(undefined4 *)piVar8;
                        *(undefined4 *)((int64_t)piVar8 - 0xc) = *(undefined4 *)((int64_t)piVar8 + 4);
                        *(undefined4 *)(piVar8 + -1) = uVar3;
                        *(undefined4 *)((int64_t)piVar8 - 4) = uVar4;
                        piVar11 = *(int64_t **)(arg1 + 0x40);
                        piVar8 = piVar8 + 2;
                    } while (piVar8 < piVar11);
                }
                *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
                if (((*(char *)0x180777010 != '\0') && (**(int64_t ***)(arg1 + 0x18) < piVar11 + -2)) &&
                   (iVar6 = fcn.180085510(in_stack_00000010), iVar6 == 0)) goto code_r0x000180060a64;
                puVar7 = *(undefined4 **)(arg1 + 0x40);
                *puVar7 = 1;
                goto code_r0x000180060a2d;
            }
            *(int64_t **)(arg1 + 0x40) = piVar11 + -4;
        }
        if (((*(char *)0x180777010 == '\0') || (*(int64_t *)(arg1 + 0x40) + 0x10U <= **(uint64_t **)(arg1 + 0x18))) ||
           (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
            puVar7 = *(undefined4 **)(arg1 + 0x40);
            *puVar7 = 0;
code_r0x000180060a2d:
            puVar7[3] = 1;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
            return 1;
        }
    } else if (((*(char *)0x180777010 == '\0') || (piVar11 + 2 <= **(int64_t ***)(arg1 + 0x18))) ||
              (iVar6 = fcn.180085510(in_stack_00000010), iVar6 != 0)) {
        puVar7 = *(undefined4 **)(arg1 + 0x40);
        *puVar7 = 1;
        puVar7[3] = 1;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 1;
    }
code_r0x000180060a64:
    fcn.180099450(arg1, 0x18063d8d0);
    fcn.180087960(arg1);
    pcVar2 = (code *)swi(3);
    uVar9 = (*pcVar2)();
    return uVar9;
}

// ============================================================
// Function: FUN_180060a80
// Address: 0x180060a80
// Size: 298 bytes
// ============================================================
undefined8 fcn.180060a80(int64_t arg1)
{
    int32_t iVar1;
    int64_t *piVar2;
    code *pcVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    undefined uVar7;
    int64_t *piVar8;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar4 = piVar6;
    if (piVar2 <= piVar6) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (((piVar4 == *(int64_t **)0x180782430) ||
        (iVar1 = *(int32_t *)((int64_t)piVar4 + 0xc), (iVar1 - 7U & 0xfffffffc) != 0)) || (iVar1 == 9)) {
        func_0x000180088380(arg1, 1, 0x180624a20);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
    piVar4 = piVar6 + 2;
    piVar8 = piVar4;
    if (piVar2 <= piVar4) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if ((piVar8 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar8 + 0xc) == 1)) {
        if (piVar2 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 0) ||
           ((*(int32_t *)((int64_t)piVar4 + 0xc) == 1 && (*(int32_t *)piVar4 == 0)))) {
            uVar7 = 0;
        } else {
            uVar7 = 1;
        }
        if (iVar1 == 7) {
            if (piVar2 <= piVar6) {
                piVar6 = *(int64_t **)0x180782430;
            }
            if (piVar6 == *(int64_t **)0x180782430) {
                piVar6 = (int64_t *)0x0;
            }
            *(undefined *)(*piVar6 + 6) = uVar7;
        } else {
            if (iVar1 == 8) {
                if (piVar2 <= piVar6) {
                    piVar6 = *(int64_t **)0x180782430;
                }
                if (piVar6 == *(int64_t **)0x180782430) {
                    piVar6 = (int64_t *)0x0;
                }
                *(undefined *)(*(int64_t *)(*piVar6 + 0x10) + 6) = uVar7;
                return 0;
            }
            if (iVar1 == 10) {
                if (piVar2 <= piVar6) {
                    piVar6 = *(int64_t **)0x180782430;
                }
                if (*(int32_t *)((int64_t)piVar6 + 0xc) != 10) {
                    *(undefined *)(*(int64_t *)0x58 + 6) = uVar7;
                    return 0;
                }
                *(undefined *)(*(int64_t *)(*piVar6 + 0x58) + 6) = uVar7;
                return 0;
            }
        }
        return 0;
    }
    fcn.180088470(arg1, 2, 1);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_180060bb0
// Address: 0x180060bb0
// Size: 219 bytes
// ============================================================
undefined8 fcn.180060bb0(int64_t arg1)
{
    char cVar1;
    int32_t iVar2;
    int64_t *piVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int64_t *piVar8;
    bool bVar9;
    
    piVar7 = *(int64_t **)(arg1 + 0x28);
    piVar3 = *(int64_t **)(arg1 + 0x40);
    piVar8 = piVar7;
    if (piVar3 <= piVar7) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (((piVar8 == *(int64_t **)0x180782430) ||
        (iVar2 = *(int32_t *)((int64_t)piVar8 + 0xc), (iVar2 - 7U & 0xfffffffc) != 0)) || (iVar2 == 9)) {
        func_0x000180088380(arg1, 1, 0x180624a20);
        pcVar4 = (code *)swi(3);
        uVar6 = (*pcVar4)();
        return uVar6;
    }
    bVar9 = false;
    if (iVar2 == 7) {
        if (piVar3 <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
        if (piVar7 == *(int64_t **)0x180782430) {
            piVar7 = (int64_t *)0x0;
        }
        iVar5 = *piVar7;
code_r0x000180060c59:
        cVar1 = *(char *)(iVar5 + 6);
    } else {
        if (iVar2 != 8) {
            if (iVar2 != 10) goto code_r0x000180060c61;
            if (piVar3 <= piVar7) {
                piVar7 = *(int64_t **)0x180782430;
            }
            iVar5 = *(int64_t *)0x58;
            if (*(int32_t *)((int64_t)piVar7 + 0xc) == 10) {
                iVar5 = *(int64_t *)(*piVar7 + 0x58);
            }
            goto code_r0x000180060c59;
        }
        if (piVar3 <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
        if (piVar7 == *(int64_t **)0x180782430) {
            piVar7 = (int64_t *)0x0;
        }
        cVar1 = *(char *)(*(int64_t *)(*piVar7 + 0x10) + 6);
    }
    bVar9 = cVar1 != '\0';
code_r0x000180060c61:
    fcn.180086b20(arg1, bVar9);
    return 1;
}

// ============================================================
// Function: FUN_180060c90
// Address: 0x180060c90
// Size: 1266 bytes
// ============================================================
void fcn.180060c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    func_0x000180018f70();
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, 0x180035b00, 0x180624a48, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624a48);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060450, 0x180624a00, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624a00);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060510, 0x180624a10, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624a10);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_78h = 0x180624a78;
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060570, 0x180624a88, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624a88);
    piVar4 = &var_78h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624a88);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_70h);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.1800605d0, 0x180624a58, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624a58);
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_70h = 0x180624a68;
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060700, 0x180624ab8, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624ab8);
    piVar4 = &var_70h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624ab8);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_68h);
    var_48h = 0x180624ac8;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_40h = 0x180624a98;
    var_88h = 0;
    var_38h = 0x180624aa8;
    func_0x0001800869f0(arg2, fcn.180060750, 0x180624b08, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624b08);
    piVar4 = &var_48h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624b08);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_30h);
    var_68h = 0x180624b18;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_60h = 0x180624ad8;
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.1800607a0, 0x180624af0, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624af0);
    piVar4 = &var_68h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624af0);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_58h);
    var_58h = 0x180624b58;
    uVar3 = *(int64_t *)(arg2 + 0x40) - *(int64_t *)(arg2 + 0x28) >> 4;
    var_50h = 0x180624b70;
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060800, 0x180624b30, 0);
    func_0x000180087370(arg2, uVar3 & 0xffffffff, 0x180624b30);
    piVar4 = &var_58h;
    do {
        func_0x000180086cc0(arg2, uVar3 & 0xffffffff, 0x180624b30);
        iVar2 = *(int64_t *)(arg2 + 0x40) + -0x10;
        if ((iVar2 == *(int64_t *)0x180782430) || (*(int32_t *)(*(int64_t *)(arg2 + 0x40) + -4) != 0)) {
            func_0x000180087370(arg2, uVar3 & 0xffffffff, *piVar4);
        } else {
            *(int64_t *)(arg2 + 0x40) = iVar2;
        }
        piVar4 = piVar4 + 1;
    } while (piVar4 != &var_48h);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060880, 0x180624b48, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624b48);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060a80, 0x180624b88, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624b88);
    iVar2 = *(int64_t *)(arg2 + 0x40);
    iVar1 = *(int64_t *)(arg2 + 0x28);
    var_88h = 0;
    func_0x0001800869f0(arg2, fcn.180060bb0, 0x180624b98, 0);
    func_0x000180087370(arg2, iVar2 - iVar1 >> 4 & 0xffffffff, 0x180624b98);
    func_0x000180459870(var_30h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_1800611a0
// Address: 0x1800611a0
// Size: 32 bytes
// ============================================================
int64_t fcn.1800611a0(int64_t arg1)
{
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    fcn.180458f6c();
    return arg1;
}

// ============================================================
// Function: FUN_1800611c0
// Address: 0x1800611c0
// Size: 15 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.1800611c0(int64_t arg1)
{
    code *pcVar1;
    int64_t var_8h;
    
    fcn.180458fdc();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800611e0
// Address: 0x1800611e0
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800611e0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t var_18h;
    
    piVar1 = (int64_t *)(arg1 + 0x40);
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x10) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x20) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x30) = ZEXT816(0);
    if (piVar1 != (int64_t *)arg2) {
        piVar2 = *(int64_t **)(arg1 + 0x78);
        if (piVar2 != (int64_t *)0x0) {
            (**(code **)(*piVar2 + 0x20))(piVar2, piVar2 != piVar1);
            *(undefined8 *)(arg1 + 0x78) = 0;
        }
        piVar2 = *(int64_t **)(arg2 + 0x38);
        if (piVar2 != (int64_t *)0x0) {
            if (piVar2 == (int64_t *)arg2) {
                uVar3 = (**(code **)(*piVar2 + 8))(piVar2, piVar1);
                *(undefined8 *)(arg1 + 0x78) = uVar3;
                piVar1 = *(int64_t **)(arg2 + 0x38);
                if (piVar1 == (int64_t *)0x0) goto code_r0x000180061266;
                (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
            } else {
                *(int64_t **)(arg1 + 0x78) = piVar2;
            }
            *(undefined8 *)(arg2 + 0x38) = 0;
        }
    }
code_r0x000180061266:
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180061290
// Address: 0x180061290
// Size: 260 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180061290(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    
    *(undefined4 *)arg1 = 0;
    LOCK();
    *(undefined4 *)arg1 = 0;
    UNLOCK();
    *(undefined4 *)(arg1 + 4) = 0;
    *(undefined (*) [16])(arg1 + 0x30) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x40) = ZEXT816(0);
    *(undefined (*) [16])(arg1 + 0x50) = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    *(undefined4 *)(arg1 + 0x60) = 0xffffffff;
    *(undefined4 *)(arg1 + 0x18) = 2;
    *(undefined4 *)(arg1 + 100) = 0;
    puVar1 = (undefined8 *)(arg1 + 0x68);
    *puVar1 = 0;
    *(undefined8 *)(arg1 + 0x70) = 0;
    *(undefined8 *)(arg1 + 0x78) = 0;
    *(undefined8 *)(arg1 + 0x80) = 0;
    *(undefined8 *)(arg1 + 0x88) = 0;
    puVar2 = (undefined8 *)func_0x000180459890(0x10);
    puVar2[1] = 0;
    *puVar1 = puVar2;
    *puVar2 = puVar1;
    *(undefined8 *)(arg1 + 0x90) = 0;
    *(undefined8 *)(arg1 + 0x98) = 0;
    iVar3 = func_0x000180459890(0x38);
    *(int64_t *)iVar3 = iVar3;
    *(int64_t *)(iVar3 + 8) = iVar3;
    *(int64_t *)(iVar3 + 0x10) = iVar3;
    *(undefined2 *)(iVar3 + 0x18) = 0x101;
    *(int64_t *)(arg1 + 0x90) = iVar3;
    *(undefined8 *)(arg1 + 0xa0) = 0;
    LOCK();
    *(undefined4 *)arg1 = 1;
    UNLOCK();
    bVar4 = arg2 == 0;
    if (bVar4) {
        arg2 = func_0x000180182270(2);
    }
    *(int64_t *)(arg1 + 8) = arg2;
    *(bool *)(arg1 + 0x10) = bVar4;
    LOCK();
    *(undefined4 *)(arg1 + 4) = 0;
    UNLOCK();
    LOCK();
    *(undefined8 *)(arg1 + 0xa0) = 0;
    UNLOCK();
    LOCK();
    *(undefined4 *)arg1 = 2;
    UNLOCK();
    return arg1;
}

// ============================================================
// Function: FUN_1800613a0
// Address: 0x1800613a0
// Size: 80 bytes
// ============================================================
void fcn.1800613a0(int64_t arg1)
{
    undefined8 *puVar1;
    
    puVar1 = (undefined8 *)(arg1 + 8);
    if (*(int64_t *)(arg1 + 8) != 0) {
        if (*(int32_t *)arg1 < 5) {
            if (*(char *)(arg1 + 0x10) != '\0') {
                fcn.1801821b0(puVar1);
                *puVar1 = 0;
                return;
            }
        } else {
            LOCK();
            *(undefined4 *)arg1 = 7;
            UNLOCK();
            fcn.180182a20(*puVar1);
        }
        *puVar1 = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800613f0
// Address: 0x1800613f0
// Size: 258 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800613f0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 *puVar2;
    int64_t var_18h;
    undefined auStack_e8 [32];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_80h;
    int64_t iStack_78;
    int64_t var_68h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    var_c8h = (int64_t)&var_b8h;
    var_c0h = (int64_t)&var_68h;
    var_30h = 0;
    puVar2 = *(undefined8 **)(arg2 + 0x38);
    iStack_78 = arg2;
    if (puVar2 != (undefined8 *)0x0) {
        var_30h = (**(code **)*puVar2)(puVar2, &var_68h);
    }
    var_80h = 0;
    puVar2 = (undefined8 *)func_0x000180459890(0x48);
    *puVar2 = 0x180624ca0;
    puVar2[8] = 0;
    func_0x000180014de0(puVar2 + 1, &var_68h);
    var_80h = (int64_t)puVar2;
    func_0x000180061500(arg1, &var_b8h);
    if (var_30h != 0) {
        (**(code **)(*(int64_t *)var_30h + 0x20))
                  (var_30h, CONCAT71((unkint7)((uint64_t)&var_68h >> 8), (int64_t *)var_30h != &var_68h));
    }
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
    fcn.180459870(var_28h ^ (uint64_t)auStack_e8);
    return;
}

// ============================================================
// Function: FUN_180061500
// Address: 0x180061500
// Size: 564 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.180061500(int64_t arg1, int64_t arg2, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined (*arg1_00) [16];
    int32_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    undefined8 *puVar4;
    undefined (**ppauVar5) [16];
    code *pcVar6;
    int32_t iVar7;
    undefined (*pauVar8) [16];
    undefined8 uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    undefined auStack_c8 [32];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_50h = arg2;
    if (*(int64_t *)(arg1 + 8) == 0) {
        piVar3 = *(int64_t **)(arg2 + 0x38);
        if (piVar3 != (int64_t *)0x0) {
            (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)arg2);
            *(undefined8 *)(arg2 + 0x38) = 0;
        }
    } else {
        pauVar8 = (undefined (*) [16])func_0x000180459890(0x90);
        *pauVar8 = ZEXT816(0);
        *(undefined4 *)(*pauVar8 + 8) = 1;
        *(undefined4 *)(*pauVar8 + 0xc) = 1;
        *(undefined8 *)*pauVar8 = 0x1804a6e50;
        arg1_00 = pauVar8 + 1;
        var_a0h = (int64_t)&var_90h;
        var_58h = 0;
        puVar4 = *(undefined8 **)(arg2 + 0x38);
        var_a8h = (int64_t)pauVar8;
        if (puVar4 != (undefined8 *)0x0) {
            var_58h = (**(code **)*puVar4)(puVar4, &var_90h);
        }
        fcn.1800611e0((int64_t)arg1_00, (int64_t)&var_90h);
        *(int64_t *)pauVar8[3] = arg1;
        *(undefined8 *)(pauVar8[2] + 8) = 0x180061740;
        var_a0h = (int64_t)arg1_00;
        var_98h = (int64_t)pauVar8;
        iVar7 = func_0x000180456008(arg1 + 0x18);
        if (iVar7 != 0) {
            func_0x0001804542e8(5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (*(int32_t *)(arg1 + 100) == 0x7fffffff) {
            *(undefined4 *)(arg1 + 100) = 0x7ffffffe;
            func_0x0001804542e8(6);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (*(uint64_t *)(arg1 + 0x78) <= *(int64_t *)(arg1 + 0x88) + 1U) {
            func_0x000180065b40(arg1 + 0x68, 1);
        }
        uVar10 = *(int64_t *)(arg1 + 0x78) - 1;
        *(uint64_t *)(arg1 + 0x80) = *(uint64_t *)(arg1 + 0x80) & uVar10;
        uVar11 = *(int64_t *)(arg1 + 0x80) + *(int64_t *)(arg1 + 0x88);
        iVar2 = (uVar11 & uVar10) * 8;
        if (*(int64_t *)(iVar2 + *(int64_t *)(arg1 + 0x70)) == 0) {
            uVar9 = func_0x000180459890(0x10);
            *(undefined8 *)(iVar2 + *(int64_t *)(arg1 + 0x70)) = uVar9;
        }
        ppauVar5 = *(undefined (***) [16])(*(int64_t *)(arg1 + 0x70) + (*(int64_t *)(arg1 + 0x78) - 1U & uVar11) * 8);
        *ppauVar5 = (undefined (*) [16])0x0;
        ppauVar5[1] = (undefined (*) [16])0x0;
        LOCK();
        *(int32_t *)(*pauVar8 + 8) = *(int32_t *)(*pauVar8 + 8) + 1;
        UNLOCK();
        *ppauVar5 = arg1_00;
        ppauVar5[1] = pauVar8;
        *(int64_t *)(arg1 + 0x88) = *(int64_t *)(arg1 + 0x88) + 1;
        func_0x000180456010(arg1 + 0x18);
        fcn.1801823b0(*(undefined8 *)(arg1 + 8), arg1_00);
        LOCK();
        piVar1 = (int32_t *)(*pauVar8 + 8);
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (***(code ***)*pauVar8)(pauVar8);
            LOCK();
            piVar1 = (int32_t *)(*pauVar8 + 0xc);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)(*(int64_t *)*pauVar8 + 8))(pauVar8);
            }
        }
        piVar3 = *(int64_t **)(arg2 + 0x38);
        if (piVar3 != (int64_t *)0x0) {
            (**(code **)(*piVar3 + 0x20))(piVar3, piVar3 != (int64_t *)arg2);
            *(undefined8 *)(arg2 + 0x38) = 0;
        }
    }
    fcn.180459870(var_48h ^ (uint64_t)auStack_c8);
    return;
}

// ============================================================
// Function: FUN_180061740
// Address: 0x180061740
// Size: 334 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180061740(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t iVar5;
    int64_t *piVar6;
    code *pcVar7;
    int32_t iVar8;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar3 = *(int64_t *)(arg1 + 0x20);
    iVar8 = func_0x000180456008(iVar3 + 0x18);
    if (iVar8 != 0) {
        func_0x0001804542e8(5);
        pcVar7 = (code *)swi(3);
        (*pcVar7)();
        return;
    }
    if (*(int32_t *)(iVar3 + 100) != 0x7fffffff) {
        piVar4 = *(int64_t **)
                  (*(int64_t *)(iVar3 + 0x70) + (*(int64_t *)(iVar3 + 0x78) - 1U & *(uint64_t *)(iVar3 + 0x80)) * 8);
        if (piVar4[1] != 0) {
            LOCK();
            piVar1 = (int32_t *)(piVar4[1] + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        iVar5 = *piVar4;
        piVar4 = (int64_t *)piVar4[1];
        piVar6 = *(int64_t **)
                  (*(int64_t *)
                    (*(int64_t *)(iVar3 + 0x70) + (*(int64_t *)(iVar3 + 0x78) - 1U & *(uint64_t *)(iVar3 + 0x80)) * 8) +
                  8);
        if (piVar6 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar6 + 1;
            iVar8 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)*piVar6)(piVar6);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar6 + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*piVar6 + 8))(piVar6);
                }
            }
        }
        piVar6 = (int64_t *)(iVar3 + 0x88);
        *piVar6 = *piVar6 + -1;
        if (*piVar6 == 0) {
            *(undefined8 *)(iVar3 + 0x80) = 0;
        } else {
            *(int64_t *)(iVar3 + 0x80) = *(int64_t *)(iVar3 + 0x80) + 1;
        }
        func_0x000180456010(iVar3 + 0x18);
        if ((iVar5 != 0) && (piVar6 = *(int64_t **)(iVar5 + 0x78), piVar6 != (int64_t *)0x0)) {
            var_8h = iVar5;
            (**(code **)(*piVar6 + 0x10))(piVar6, &var_8h, in_R8, in_R9, iVar5, piVar4);
        }
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar6 = piVar4 + 1;
            iVar8 = *(int32_t *)piVar6;
            *(int32_t *)piVar6 = *(int32_t *)piVar6 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar8 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar8 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
        return;
    }
    *(undefined4 *)(iVar3 + 100) = 0x7ffffffe;
    func_0x0001804542e8(6);
    pcVar7 = (code *)swi(3);
    (*pcVar7)();
    return;
}

// ============================================================
// Function: FUN_1800618a0
// Address: 0x1800618a0
// Size: 451 bytes
// ============================================================
int64_t fcn.1800618a0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    bool bVar5;
    bool bVar6;
    undefined (*pauVar7) [16];
    int64_t *piVar8;
    undefined (*arg1_00) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    *(undefined4 *)arg1 = 0;
    LOCK();
    *(undefined4 *)arg1 = 0;
    UNLOCK();
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    bVar6 = true;
    bVar5 = false;
    LOCK();
    *(undefined4 *)arg1 = 1;
    UNLOCK();
    if (*(int64_t *)arg2 == 0) {
        pauVar7 = (undefined (*) [16])func_0x000180459890(0xb8);
        *pauVar7 = ZEXT816(0);
        *(undefined4 *)(*pauVar7 + 8) = 1;
        *(undefined4 *)(*pauVar7 + 0xc) = 1;
        *(undefined8 *)*pauVar7 = 0x1804a6e78;
        arg1_00 = pauVar7 + 1;
        fcn.180061290((int64_t)arg1_00, 0);
        var_40h = (int64_t)pauVar7;
        piVar8 = &var_48h;
        bVar6 = false;
        bVar5 = true;
    } else {
        if (*(int64_t *)(arg2 + 8) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        arg1_00 = *(undefined (**) [16])arg2;
        var_50h = *(int64_t *)(arg2 + 8);
        piVar8 = &var_58h;
        var_58h = (int64_t)arg1_00;
    }
    iVar4 = piVar8[1];
    *piVar8 = 0;
    piVar8[1] = 0;
    *(undefined (**) [16])(arg1 + 8) = arg1_00;
    piVar8 = *(int64_t **)(arg1 + 0x10);
    *(int64_t *)(arg1 + 0x10) = iVar4;
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar8 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    iVar4 = var_40h;
    if (bVar5) {
        if (var_40h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_40h + 8);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (***(code ***)var_40h)(var_40h);
                LOCK();
                piVar1 = (int32_t *)(iVar4 + 0xc);
                iVar3 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*(int64_t *)iVar4 + 8))(iVar4);
                }
            }
        }
    }
    iVar4 = var_50h;
    if ((bVar6) && (var_50h != 0)) {
        LOCK();
        piVar1 = (int32_t *)(var_50h + 8);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (***(code ***)var_50h)(var_50h);
            LOCK();
            piVar1 = (int32_t *)(iVar4 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*(int64_t *)iVar4 + 8))(iVar4);
            }
        }
    }
    LOCK();
    *(undefined4 *)arg1 = 2;
    UNLOCK();
    piVar8 = *(int64_t **)(arg2 + 8);
    if (piVar8 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar8 + 1;
        iVar3 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar8)(piVar8);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar8 + 8))(piVar8);
            }
        }
    }
    return arg1;
}

// ============================================================
// Function: FUN_180061a70
// Address: 0x180061a70
// Size: 210 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 fcn.180061a70(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    if ((2 < *(int32_t *)arg1) && (*(int32_t *)arg1 < 7)) {
        LOCK();
        *(undefined4 *)arg1 = 7;
        UNLOCK();
        if (*(int64_t *)(*(int64_t *)(arg1 + 8) + 8) == 0) {
            (*(code *)0x699ddc)();
        } else {
            func_0x000180182b10();
        }
        fcn.1800613a0(*(int64_t *)(arg1 + 8));
    }
    func_0x000180061db0(arg1);
    piVar5 = *(int64_t **)(arg1 + 0x20);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    piVar5 = *(int64_t **)(arg1 + 0x10);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    LOCK();
    uVar4 = *(undefined4 *)arg1;
    *(undefined4 *)arg1 = 9;
    UNLOCK();
    return uVar4;
}

// ============================================================
// Function: FUN_180061b50
// Address: 0x180061b50
// Size: 604 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180061b50(int64_t arg1, undefined8 placeholder_1, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h, int64_t arg_80h, int64_t arg_88h)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 *puVar3;
    int64_t *piVar4;
    code *pcVar5;
    undefined (*pauVar6) [16];
    int64_t iVar7;
    undefined8 uVar8;
    int64_t var_10h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    var_58h = arg3;
    var_50h = arg4;
    if (((*(int32_t *)arg1 < 3) || (7 < *(int32_t *)arg1)) && (**(int32_t **)(arg1 + 8) != 5)) {
        LOCK();
        *(undefined4 *)arg1 = 3;
        UNLOCK();
        pauVar6 = (undefined (*) [16])func_0x000180459890(0x20);
        *pauVar6 = ZEXT816(0);
        *(undefined4 *)(*pauVar6 + 8) = 1;
        *(undefined4 *)(*pauVar6 + 0xc) = 1;
        *(undefined8 *)*pauVar6 = 0x1804a6ea0;
        var_68h = (int64_t)pauVar6;
        iVar7 = func_0x000180459890(0x90);
        *(undefined8 *)(iVar7 + 0x38) = 0;
        puVar3 = *(undefined8 **)(arg4 + 0x38);
        var_60h = iVar7;
        if (puVar3 != (undefined8 *)0x0) {
            var_78h = iVar7;
            uVar8 = (**(code **)*puVar3)(puVar3, iVar7);
            *(undefined8 *)(iVar7 + 0x38) = uVar8;
        }
        var_78h = iVar7 + 0x40;
        *(undefined8 *)(iVar7 + 0x78) = 0;
        puVar3 = *(undefined8 **)(arg3 + 0x38);
        if (puVar3 != (undefined8 *)0x0) {
            uVar8 = (**(code **)*puVar3)(puVar3, var_78h);
            *(undefined8 *)(iVar7 + 0x78) = uVar8;
        }
        *(int64_t *)(iVar7 + 0x80) = arg1;
        *(undefined8 *)(iVar7 + 0x88) = 0x180061e60;
        var_88h._0_4_ = 0;
        var_80h = (int64_t)(pauVar6[1] + 8);
        var_78h = iVar7;
        iVar7 = func_0x00018045f6e8(0, 0, 0x180065d40, iVar7);
        *(int64_t *)pauVar6[1] = iVar7;
        if (iVar7 == 0) {
            *(undefined4 *)(pauVar6[1] + 8) = 0;
            func_0x0001804542e8(6);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        var_78h = (int64_t)(pauVar6 + 1);
        var_70h = (int64_t)pauVar6;
        func_0x000180063990(arg1 + 0x18, &var_78h);
        iVar7 = var_70h;
        if (var_70h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_70h + 8);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (***(code ***)var_70h)(var_70h);
                LOCK();
                piVar1 = (int32_t *)(iVar7 + 0xc);
                iVar2 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar2 == 1) {
                    (**(code **)(*(int64_t *)iVar7 + 8))(iVar7);
                }
            }
        }
        if ((char)placeholder_1 != '\0') {
            iVar2 = **(int32_t **)(arg1 + 8);
            while (iVar2 < 5) {
                (*(code *)0x699d32)(1);
                iVar2 = **(int32_t **)(arg1 + 8);
            }
        }
        piVar4 = *(int64_t **)(arg3 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg3);
            *(undefined8 *)(arg3 + 0x38) = 0;
        }
        piVar4 = *(int64_t **)(arg4 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg4);
            *(undefined8 *)(arg4 + 0x38) = 0;
        }
    } else {
        piVar4 = *(int64_t **)(arg3 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg3);
            *(undefined8 *)(arg3 + 0x38) = 0;
        }
        piVar4 = *(int64_t **)(arg4 + 0x38);
        if (piVar4 != (int64_t *)0x0) {
            (**(code **)(*piVar4 + 0x20))(piVar4, piVar4 != (int64_t *)arg4);
            *(undefined8 *)(arg4 + 0x38) = 0;
        }
    }
    fcn.180459870(var_48h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180061db0
// Address: 0x180061db0
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180061db0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined (*pauVar3) [16];
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    pauVar3 = *(undefined (**) [16])(arg1 + 0x18);
    if ((pauVar3 != (undefined (*) [16])0x0) && (*(int32_t *)(*pauVar3 + 8) != 0)) {
        iVar7 = *(int32_t *)(*pauVar3 + 8);
        iVar6 = sub.KERNEL32.dll_GetCurrentThreadId();
        if (iVar7 == iVar6) {
            fcn.1804542e8(5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        var_18h._0_4_ = *(undefined4 *)*pauVar3;
        var_18h._4_4_ = *(undefined4 *)(*pauVar3 + 4);
        uStack_10 = *(undefined4 *)(*pauVar3 + 8);
        uStack_c = *(undefined4 *)(*pauVar3 + 0xc);
        iVar7 = fcn.180454a30(&var_18h, 0);
        if (iVar7 != 0) {
            fcn.1804542e8(2);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        *pauVar3 = ZEXT816(0);
        piVar4 = *(int64_t **)(arg1 + 0x20);
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar7 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180061dcc
// Address: 0x180061dcc
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180061db0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    undefined (*pauVar3) [16];
    int64_t *piVar4;
    code *pcVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    pauVar3 = *(undefined (**) [16])(arg1 + 0x18);
    if ((pauVar3 != (undefined (*) [16])0x0) && (*(int32_t *)(*pauVar3 + 8) != 0)) {
        iVar7 = *(int32_t *)(*pauVar3 + 8);
        iVar6 = sub.KERNEL32.dll_GetCurrentThreadId();
        if (iVar7 == iVar6) {
            fcn.1804542e8(5);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        var_18h._0_4_ = *(undefined4 *)*pauVar3;
        var_18h._4_4_ = *(undefined4 *)(*pauVar3 + 4);
        uStack_10 = *(undefined4 *)(*pauVar3 + 8);
        uStack_c = *(undefined4 *)(*pauVar3 + 0xc);
        iVar7 = fcn.180454a30(&var_18h, 0);
        if (iVar7 != 0) {
            fcn.1804542e8(2);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        *pauVar3 = ZEXT816(0);
        piVar4 = *(int64_t **)(arg1 + 0x20);
        *(undefined8 *)(arg1 + 0x18) = 0;
        *(undefined8 *)(arg1 + 0x20) = 0;
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = piVar4 + 1;
            iVar7 = *(int32_t *)piVar1;
            *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)*piVar4)(piVar4);
                LOCK();
                piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
                iVar7 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*piVar4 + 8))(piVar4);
                }
            }
        }
    }
    return;
}

