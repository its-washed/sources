// Chunk 191 - 50 functions

// ============================================================
// Function: FUN_1802570e0
// Address: 0x1802570e0
// Size: 63 bytes
// ============================================================
undefined8 * fcn.1802570e0(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802570f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025710d;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        *puVar4 = in_RCX;
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025712d;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257132;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257148;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                return puVar4;
            }
        }
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257164;
        (*pcVar1)(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257169;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257181;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257193;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802571a8;
        fcn.180224990(puVar4, 0x1804e6448, 0x20);
        puVar4 = (undefined8 *)0x0;
    }
    return puVar4;
}

// ============================================================
// Function: FUN_18025711f
// Address: 0x18025711f
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1802570e0(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802570f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025710d;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        *puVar4 = in_RCX;
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025712d;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257132;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257148;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                return puVar4;
            }
        }
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257164;
        (*pcVar1)(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257169;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257181;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257193;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802571a8;
        fcn.180224990(puVar4, 0x1804e6448, 0x20);
        puVar4 = (undefined8 *)0x0;
    }
    return puVar4;
}

// ============================================================
// Function: FUN_180257140
// Address: 0x180257140
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1802570e0(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    undefined8 *in_RCX;
    undefined8 unaff_RBX;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802570f0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025710d;
    puVar4 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    if (puVar4 != (undefined8 *)0x0) {
        *puVar4 = in_RCX;
        uVar5 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        pcVar1 = (code *)in_RCX[5];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18025712d;
        uVar5 = fcn.18027e810(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257132;
        iVar6 = (*pcVar1)(uVar5);
        puVar4[1] = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257148;
            iVar2 = fcn.180248230(in_RCX);
            if (iVar2 != 0) {
                return puVar4;
            }
        }
        pcVar1 = (code *)in_RCX[7];
        uVar5 = puVar4[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257164;
        (*pcVar1)(uVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257169;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257181;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257193;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802571a8;
        fcn.180224990(puVar4, 0x1804e6448, 0x20);
        puVar4 = (undefined8 *)0x0;
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1802571c0
// Address: 0x1802571c0
// Size: 49 bytes
// ============================================================
undefined8 fcn.1802571c0(int64_t *param_1)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(*param_1 + 0x80) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x0001802571e4. Too many branches
    // WARNING: Treating indirect jump as call
        uVar1 = (**(code **)(*param_1 + 0x80))(param_1[1]);
        return uVar1;
    }
    return 1;
}

// ============================================================
// Function: FUN_180257200
// Address: 0x180257200
// Size: 529 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180257200(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_a8h, int64_t arg_b8h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined8 uVar10;
    int64_t *in_RCX;
    int64_t in_RDX;
    uint64_t *in_R8;
    uint64_t in_R9;
    undefined4 extraout_XMM0_Da;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025721a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined4 *)((int64_t)&arg_b8h + iVar7) = 0;
    if ((in_RCX == (int64_t *)0x0) || (*in_RCX == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802573cc;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802573e4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
    } else if (*(int64_t *)(*in_RCX + 0x50) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257255;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x18025726d;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar7));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257283;
        uVar8 = func_0x000180257880(extraout_XMM0_Da, 0x18063dcac);
        if (in_RDX == 0) {
            if (in_R8 != (uint64_t *)0x0) {
                *in_R8 = uVar8;
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257292;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802572aa;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
        } else {
            if (uVar8 <= in_R9) {
                if (*(int32_t *)((int64_t)&arg_b8h + iVar7) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257317;
                    puVar9 = (undefined4 *)
                             func_0x000180229bc0((int64_t)&arg_78h + iVar7, 0x1804bb8e0, (int64_t)&arg_b8h + iVar7);
                    uVar3 = puVar9[1];
                    uVar4 = puVar9[2];
                    uVar5 = puVar9[3];
                    *(undefined4 *)((int64_t)&arg_28h + iVar7) = *puVar9;
                    *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000030 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x00000034 + iVar7) = uVar5;
                    uVar3 = puVar9[5];
                    uVar4 = puVar9[6];
                    uVar5 = puVar9[7];
                    *(undefined4 *)((int64_t)&arg_38h + iVar7) = puVar9[4];
                    *(undefined4 *)((int64_t)&arg_38h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000040 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x00000044 + iVar7) = uVar5;
                    *(undefined8 *)((int64_t)&arg_48h + iVar7) = *(undefined8 *)(puVar9 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257340;
                    puVar9 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_78h + iVar7);
                    uVar3 = puVar9[1];
                    uVar4 = puVar9[2];
                    uVar5 = puVar9[3];
                    *(undefined4 *)((int64_t)&arg_50h + iVar7) = *puVar9;
                    *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000058 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000005c + iVar7) = uVar5;
                    uVar3 = puVar9[5];
                    uVar4 = puVar9[6];
                    uVar5 = puVar9[7];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7) = puVar9[4];
                    *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar3;
                    *(undefined4 *)(&stack0x00000068 + iVar7) = uVar4;
                    *(undefined4 *)(&stack0x0000006c + iVar7) = uVar5;
                    iVar1 = *in_RCX;
                    *(undefined8 *)((int64_t)&arg_70h + iVar7) = *(undefined8 *)(puVar9 + 8);
                    pcVar2 = *(code **)(iVar1 + 0x80);
                    if (pcVar2 != (code *)0x0) {
                        iVar1 = in_RCX[1];
                        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257377;
                        iVar6 = (*pcVar2)(iVar1, (int64_t)&arg_28h + iVar7);
                        if (iVar6 < 1) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257380;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257398;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar7), 
                                          *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                          *(int64_t *)(&stack0x00000030 + iVar7), 
                                          *(int64_t *)((int64_t)&arg_48h + iVar7));
                            goto code_r0x0001802573e9;
                        }
                    }
                }
                iVar1 = in_RCX[1];
                pcVar2 = *(code **)(*in_RCX + 0x50);
                *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802573b8;
                uVar10 = (*pcVar2)(iVar1, in_RDX, (int64_t)&var_18h + iVar7, in_R9);
                if (in_R8 == (uint64_t *)0x0) {
                    return uVar10;
                }
                *in_R8 = *(uint64_t *)((int64_t)&var_18h + iVar7);
                return uVar10;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802572cb;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7));
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802572e3;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar7), *(int64_t *)(&stack0x00000030 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar7));
        }
    }
code_r0x0001802573e9:
    *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802573f6;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar7));
    return 0;
}

// ============================================================
// Function: FUN_180257420
// Address: 0x180257420
// Size: 90 bytes
// ============================================================
undefined8 fcn.180257420(int64_t *param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025742a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*(code **)(*param_1 + 0x40) == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18025743e;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180257456;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                      *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                      *(int64_t *)(&stack0x00000050 + iVar1));
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180257468;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180257477. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(*param_1 + 0x40))(param_1[1]);
    return uVar2;
}

// ============================================================
// Function: FUN_180257480
// Address: 0x180257480
// Size: 56 bytes
// ============================================================
undefined8 fcn.180257480(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025748a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1802574a3;
        iVar1 = fcn.180280ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802574c0
// Address: 0x1802574c0
// Size: 31 bytes
// ============================================================
void fcn.1802574c0(int64_t *param_1, undefined8 param_2, undefined8 param_3)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x0001802574dc. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(*param_1 + 0x48))(param_1[1], param_2, param_3, *(code **)(*param_1 + 0x48));
    return;
}

// ============================================================
// Function: FUN_1802574e0
// Address: 0x1802574e0
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802574e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_b8h,
                     int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h,
                     int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                     int64_t arg_188h)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 unaff_RBX;
    undefined8 uVar15;
    undefined8 unaff_RDI;
    int64_t in_R9;
    int64_t iVar16;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802574f5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257500;
    puVar8 = (undefined8 *)func_0x000180256ae0();
    puVar1 = *(undefined8 **)((int64_t)&arg_110h + iVar7);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
    iVar16 = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8) = 0;
    if (puVar1 != (undefined8 *)0x0) {
        *puVar1 = 0;
    }
    if (puVar8 == (undefined8 *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_c0h + iVar7) = unaff_RDI;
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257577;
        uVar10 = func_0x000180256b90(puVar8);
        uVar15 = 0x1804af254;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025758c;
        iVar11 = func_0x00018022ae60(uVar10, 0x1804af254);
        if (iVar11 == 0) {
            uVar15 = 0x1804b4464;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575a3;
            iVar11 = func_0x00018022ae60(uVar10, 0x1804b4464);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575ad;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575c5;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575d7;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                iVar16 = iVar9;
                goto code_r0x000180257849;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575f2;
        puVar12 = (undefined4 *)func_0x000180229e30((int64_t)&arg_68h + iVar7, uVar15, in_R9, 0);
        uVar3 = puVar12[1];
        uVar4 = puVar12[2];
        uVar5 = puVar12[3];
        *(undefined4 *)((int64_t)&var_18h + iVar7) = *puVar12;
        *(undefined4 *)((int64_t)&var_18h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&var_20h + iVar7 + 4) = uVar5;
        uVar3 = puVar12[5];
        uVar4 = puVar12[6];
        uVar5 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_28h + iVar7) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_30h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_30h + iVar7 + 4) = uVar5;
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = *(undefined8 *)(puVar12 + 8);
    }
    iVar11 = *(int64_t *)((int64_t)&arg_e0h + iVar7);
    if ((iVar11 == 0) && (*(int64_t *)((int64_t)&arg_e8h + iVar7) == 0)) {
        iVar11 = *(int64_t *)((int64_t)&arg_f0h + iVar7);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257643;
    piVar13 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    if (piVar13 == (int64_t *)0x0) goto code_r0x000180257849;
    *piVar13 = (int64_t)puVar8;
    uVar10 = *puVar8;
    pcVar2 = (code *)puVar8[5];
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025765e;
    uVar10 = fcn.18027e810(uVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257663;
    iVar14 = (*pcVar2)(uVar10);
    piVar13[1] = iVar14;
    if (iVar14 == 0) {
code_r0x0001802577fb:
        pcVar2 = (code *)puVar8[7];
        iVar16 = piVar13[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257805;
        (*pcVar2)(iVar16);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025780a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257822;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257834;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        uVar10 = 0x20;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257678;
        iVar6 = fcn.180248230(puVar8);
        if (iVar6 == 0) goto code_r0x0001802577fb;
        pcVar2 = *(code **)(*piVar13 + 0x80);
        if (pcVar2 == (code *)0x0) {
code_r0x0001802576a3:
            uVar10 = *(undefined8 *)((int64_t)&arg_d8h + iVar7);
            pcVar2 = *(code **)(*piVar13 + 0x80);
            iVar9 = iVar16;
            if (pcVar2 != (code *)0x0) {
                iVar16 = piVar13[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576c4;
                iVar6 = (*pcVar2)(iVar16, uVar10);
                if (iVar6 == 0) goto code_r0x0001802577d6;
            }
            pcVar2 = *(code **)(*piVar13 + 0x40);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576dd;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576f5;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257707;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
            } else {
                iVar16 = piVar13[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257721;
                iVar6 = (*pcVar2)(iVar16, iVar11, *(undefined8 *)((int64_t)&arg_e8h + iVar7), uVar10);
                if (iVar6 != 0) {
                    iVar16 = piVar13[1];
                    pcVar2 = *(code **)(*piVar13 + 0x48);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257747;
                    iVar6 = (*pcVar2)(iVar16, *(undefined8 *)((int64_t)&arg_f0h + iVar7), 
                                      *(undefined8 *)((int64_t)&arg_f8h + iVar7));
                    if (iVar6 != 0) {
                        iVar16 = *(int64_t *)((int64_t)&arg_100h + iVar7);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025776f;
                        iVar6 = fcn.180257200(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar7), 
                                              *(int64_t *)(&stack0x00000088 + iVar7), 
                                              *(int64_t *)(&stack0x00000098 + iVar7));
                        if (iVar6 != 0) {
                            uVar10 = *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8);
                            if (iVar16 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257792;
                                iVar16 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                       *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                if (iVar16 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577ab;
                                    iVar6 = fcn.180257200(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_58h + iVar7), 
                                                          *(int64_t *)(&stack0x00000088 + iVar7), 
                                                          *(int64_t *)(&stack0x00000098 + iVar7));
                                    if (iVar6 == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577c4;
                                        fcn.180224990(iVar16, 0x1804e6448, 0x12e);
                                        goto code_r0x0001802577d6;
                                    }
                                }
                            }
                            iVar9 = iVar16;
                            if ((iVar16 != 0) && (puVar1 != (undefined8 *)0x0)) {
                                *puVar1 = uVar10;
                            }
                        }
                    }
                }
            }
        } else {
            iVar14 = piVar13[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025769b;
            iVar6 = (*pcVar2)(iVar14, (int64_t)&var_18h + iVar7);
            if (iVar6 != 0) goto code_r0x0001802576a3;
        }
code_r0x0001802577d6:
        iVar16 = piVar13[1];
        pcVar2 = *(code **)(*piVar13 + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577e3;
        (*pcVar2)(iVar16);
        iVar16 = *piVar13;
        piVar13[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577f3;
        func_0x000180256b30(iVar16);
        uVar10 = 0x2f;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257849;
    fcn.180224990(piVar13, 0x1804e6448, uVar10);
    iVar16 = iVar9;
code_r0x000180257849:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257851;
    func_0x000180256b30(puVar8);
    return iVar16;
}

// ============================================================
// Function: FUN_180257556
// Address: 0x180257556
// Size: 782 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802574e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_b8h,
                     int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h,
                     int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                     int64_t arg_188h)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 unaff_RBX;
    undefined8 uVar15;
    undefined8 unaff_RDI;
    int64_t in_R9;
    int64_t iVar16;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802574f5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257500;
    puVar8 = (undefined8 *)func_0x000180256ae0();
    puVar1 = *(undefined8 **)((int64_t)&arg_110h + iVar7);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
    iVar16 = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8) = 0;
    if (puVar1 != (undefined8 *)0x0) {
        *puVar1 = 0;
    }
    if (puVar8 == (undefined8 *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_c0h + iVar7) = unaff_RDI;
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257577;
        uVar10 = func_0x000180256b90(puVar8);
        uVar15 = 0x1804af254;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025758c;
        iVar11 = func_0x00018022ae60(uVar10, 0x1804af254);
        if (iVar11 == 0) {
            uVar15 = 0x1804b4464;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575a3;
            iVar11 = func_0x00018022ae60(uVar10, 0x1804b4464);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575ad;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575c5;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575d7;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                iVar16 = iVar9;
                goto code_r0x000180257849;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575f2;
        puVar12 = (undefined4 *)func_0x000180229e30((int64_t)&arg_68h + iVar7, uVar15, in_R9, 0);
        uVar3 = puVar12[1];
        uVar4 = puVar12[2];
        uVar5 = puVar12[3];
        *(undefined4 *)((int64_t)&var_18h + iVar7) = *puVar12;
        *(undefined4 *)((int64_t)&var_18h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&var_20h + iVar7 + 4) = uVar5;
        uVar3 = puVar12[5];
        uVar4 = puVar12[6];
        uVar5 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_28h + iVar7) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_30h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_30h + iVar7 + 4) = uVar5;
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = *(undefined8 *)(puVar12 + 8);
    }
    iVar11 = *(int64_t *)((int64_t)&arg_e0h + iVar7);
    if ((iVar11 == 0) && (*(int64_t *)((int64_t)&arg_e8h + iVar7) == 0)) {
        iVar11 = *(int64_t *)((int64_t)&arg_f0h + iVar7);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257643;
    piVar13 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    if (piVar13 == (int64_t *)0x0) goto code_r0x000180257849;
    *piVar13 = (int64_t)puVar8;
    uVar10 = *puVar8;
    pcVar2 = (code *)puVar8[5];
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025765e;
    uVar10 = fcn.18027e810(uVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257663;
    iVar14 = (*pcVar2)(uVar10);
    piVar13[1] = iVar14;
    if (iVar14 == 0) {
code_r0x0001802577fb:
        pcVar2 = (code *)puVar8[7];
        iVar16 = piVar13[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257805;
        (*pcVar2)(iVar16);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025780a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257822;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257834;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        uVar10 = 0x20;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257678;
        iVar6 = fcn.180248230(puVar8);
        if (iVar6 == 0) goto code_r0x0001802577fb;
        pcVar2 = *(code **)(*piVar13 + 0x80);
        if (pcVar2 == (code *)0x0) {
code_r0x0001802576a3:
            uVar10 = *(undefined8 *)((int64_t)&arg_d8h + iVar7);
            pcVar2 = *(code **)(*piVar13 + 0x80);
            iVar9 = iVar16;
            if (pcVar2 != (code *)0x0) {
                iVar16 = piVar13[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576c4;
                iVar6 = (*pcVar2)(iVar16, uVar10);
                if (iVar6 == 0) goto code_r0x0001802577d6;
            }
            pcVar2 = *(code **)(*piVar13 + 0x40);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576dd;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576f5;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257707;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
            } else {
                iVar16 = piVar13[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257721;
                iVar6 = (*pcVar2)(iVar16, iVar11, *(undefined8 *)((int64_t)&arg_e8h + iVar7), uVar10);
                if (iVar6 != 0) {
                    iVar16 = piVar13[1];
                    pcVar2 = *(code **)(*piVar13 + 0x48);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257747;
                    iVar6 = (*pcVar2)(iVar16, *(undefined8 *)((int64_t)&arg_f0h + iVar7), 
                                      *(undefined8 *)((int64_t)&arg_f8h + iVar7));
                    if (iVar6 != 0) {
                        iVar16 = *(int64_t *)((int64_t)&arg_100h + iVar7);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025776f;
                        iVar6 = fcn.180257200(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar7), 
                                              *(int64_t *)(&stack0x00000088 + iVar7), 
                                              *(int64_t *)(&stack0x00000098 + iVar7));
                        if (iVar6 != 0) {
                            uVar10 = *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8);
                            if (iVar16 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257792;
                                iVar16 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                       *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                if (iVar16 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577ab;
                                    iVar6 = fcn.180257200(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_58h + iVar7), 
                                                          *(int64_t *)(&stack0x00000088 + iVar7), 
                                                          *(int64_t *)(&stack0x00000098 + iVar7));
                                    if (iVar6 == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577c4;
                                        fcn.180224990(iVar16, 0x1804e6448, 0x12e);
                                        goto code_r0x0001802577d6;
                                    }
                                }
                            }
                            iVar9 = iVar16;
                            if ((iVar16 != 0) && (puVar1 != (undefined8 *)0x0)) {
                                *puVar1 = uVar10;
                            }
                        }
                    }
                }
            }
        } else {
            iVar14 = piVar13[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025769b;
            iVar6 = (*pcVar2)(iVar14, (int64_t)&var_18h + iVar7);
            if (iVar6 != 0) goto code_r0x0001802576a3;
        }
code_r0x0001802577d6:
        iVar16 = piVar13[1];
        pcVar2 = *(code **)(*piVar13 + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577e3;
        (*pcVar2)(iVar16);
        iVar16 = *piVar13;
        piVar13[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577f3;
        func_0x000180256b30(iVar16);
        uVar10 = 0x2f;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257849;
    fcn.180224990(piVar13, 0x1804e6448, uVar10);
    iVar16 = iVar9;
code_r0x000180257849:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257851;
    func_0x000180256b30(puVar8);
    return iVar16;
}

// ============================================================
// Function: FUN_180257864
// Address: 0x180257864
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1802574e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_b8h,
                     int64_t arg_c0h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h,
                     int64_t arg_f0h, int64_t arg_f8h, int64_t arg_100h, int64_t arg_108h, int64_t arg_110h,
                     int64_t arg_188h)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    undefined8 uVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    int64_t *piVar13;
    int64_t iVar14;
    undefined8 unaff_RBX;
    undefined8 uVar15;
    undefined8 unaff_RDI;
    int64_t in_R9;
    int64_t iVar16;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1802574f5;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257500;
    puVar8 = (undefined8 *)func_0x000180256ae0();
    puVar1 = *(undefined8 **)((int64_t)&arg_110h + iVar7);
    iVar9 = 0;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = 0;
    iVar16 = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = 0;
    *(undefined4 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
    *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8) = 0;
    if (puVar1 != (undefined8 *)0x0) {
        *puVar1 = 0;
    }
    if (puVar8 == (undefined8 *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_b8h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_c0h + iVar7) = unaff_RDI;
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257577;
        uVar10 = func_0x000180256b90(puVar8);
        uVar15 = 0x1804af254;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025758c;
        iVar11 = func_0x00018022ae60(uVar10, 0x1804af254);
        if (iVar11 == 0) {
            uVar15 = 0x1804b4464;
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575a3;
            iVar11 = func_0x00018022ae60(uVar10, 0x1804b4464);
            if (iVar11 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575ad;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575c5;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575d7;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
                iVar16 = iVar9;
                goto code_r0x000180257849;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802575f2;
        puVar12 = (undefined4 *)func_0x000180229e30((int64_t)&arg_68h + iVar7, uVar15, in_R9, 0);
        uVar3 = puVar12[1];
        uVar4 = puVar12[2];
        uVar5 = puVar12[3];
        *(undefined4 *)((int64_t)&var_18h + iVar7) = *puVar12;
        *(undefined4 *)((int64_t)&var_18h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&var_20h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&var_20h + iVar7 + 4) = uVar5;
        uVar3 = puVar12[5];
        uVar4 = puVar12[6];
        uVar5 = puVar12[7];
        *(undefined4 *)((int64_t)&arg_28h + iVar7) = puVar12[4];
        *(undefined4 *)((int64_t)&arg_28h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_30h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_30h + iVar7 + 4) = uVar5;
        *(undefined8 *)((int64_t)&arg_38h + iVar7) = *(undefined8 *)(puVar12 + 8);
    }
    iVar11 = *(int64_t *)((int64_t)&arg_e0h + iVar7);
    if ((iVar11 == 0) && (*(int64_t *)((int64_t)&arg_e8h + iVar7) == 0)) {
        iVar11 = *(int64_t *)((int64_t)&arg_f0h + iVar7);
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257643;
    piVar13 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8));
    if (piVar13 == (int64_t *)0x0) goto code_r0x000180257849;
    *piVar13 = (int64_t)puVar8;
    uVar10 = *puVar8;
    pcVar2 = (code *)puVar8[5];
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025765e;
    uVar10 = fcn.18027e810(uVar10);
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257663;
    iVar14 = (*pcVar2)(uVar10);
    piVar13[1] = iVar14;
    if (iVar14 == 0) {
code_r0x0001802577fb:
        pcVar2 = (code *)puVar8[7];
        iVar16 = piVar13[1];
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257805;
        (*pcVar2)(iVar16);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025780a;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257822;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar7), 
                      *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7));
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257834;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
        uVar10 = 0x20;
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257678;
        iVar6 = fcn.180248230(puVar8);
        if (iVar6 == 0) goto code_r0x0001802577fb;
        pcVar2 = *(code **)(*piVar13 + 0x80);
        if (pcVar2 == (code *)0x0) {
code_r0x0001802576a3:
            uVar10 = *(undefined8 *)((int64_t)&arg_d8h + iVar7);
            pcVar2 = *(code **)(*piVar13 + 0x80);
            iVar9 = iVar16;
            if (pcVar2 != (code *)0x0) {
                iVar16 = piVar13[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576c4;
                iVar6 = (*pcVar2)(iVar16, uVar10);
                if (iVar6 == 0) goto code_r0x0001802577d6;
            }
            pcVar2 = *(code **)(*piVar13 + 0x40);
            if (pcVar2 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576dd;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802576f5;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar7), *(int64_t *)((int64_t)&var_18h + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar7), *(int64_t *)((int64_t)&arg_38h + iVar7));
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257707;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar7));
            } else {
                iVar16 = piVar13[1];
                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257721;
                iVar6 = (*pcVar2)(iVar16, iVar11, *(undefined8 *)((int64_t)&arg_e8h + iVar7), uVar10);
                if (iVar6 != 0) {
                    iVar16 = piVar13[1];
                    pcVar2 = *(code **)(*piVar13 + 0x48);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257747;
                    iVar6 = (*pcVar2)(iVar16, *(undefined8 *)((int64_t)&arg_f0h + iVar7), 
                                      *(undefined8 *)((int64_t)&arg_f8h + iVar7));
                    if (iVar6 != 0) {
                        iVar16 = *(int64_t *)((int64_t)&arg_100h + iVar7);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025776f;
                        iVar6 = fcn.180257200(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                              *(int64_t *)((int64_t)&var_18h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar7), 
                                              *(int64_t *)(&stack0x00000088 + iVar7), 
                                              *(int64_t *)(&stack0x00000098 + iVar7));
                        if (iVar6 != 0) {
                            uVar10 = *(undefined8 *)((int64_t)&iStackX_10 + iVar7 + -8);
                            if (iVar16 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257792;
                                iVar16 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                       *(int64_t *)((int64_t)&iStackX_10 + iVar7));
                                if (iVar16 != 0) {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577ab;
                                    iVar6 = fcn.180257200(*(int64_t *)((int64_t)&iStackX_10 + iVar7 + -8), 
                                                          *(int64_t *)((int64_t)&var_18h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_28h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_30h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_40h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_50h + iVar7), 
                                                          *(int64_t *)((int64_t)&arg_58h + iVar7), 
                                                          *(int64_t *)(&stack0x00000088 + iVar7), 
                                                          *(int64_t *)(&stack0x00000098 + iVar7));
                                    if (iVar6 == 0) {
                                        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577c4;
                                        fcn.180224990(iVar16, 0x1804e6448, 0x12e);
                                        goto code_r0x0001802577d6;
                                    }
                                }
                            }
                            iVar9 = iVar16;
                            if ((iVar16 != 0) && (puVar1 != (undefined8 *)0x0)) {
                                *puVar1 = uVar10;
                            }
                        }
                    }
                }
            }
        } else {
            iVar14 = piVar13[1];
            *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x18025769b;
            iVar6 = (*pcVar2)(iVar14, (int64_t)&var_18h + iVar7);
            if (iVar6 != 0) goto code_r0x0001802576a3;
        }
code_r0x0001802577d6:
        iVar16 = piVar13[1];
        pcVar2 = *(code **)(*piVar13 + 0x38);
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577e3;
        (*pcVar2)(iVar16);
        iVar16 = *piVar13;
        piVar13[1] = 0;
        *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x1802577f3;
        func_0x000180256b30(iVar16);
        uVar10 = 0x2f;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257849;
    fcn.180224990(piVar13, 0x1804e6448, uVar10);
    iVar16 = iVar9;
code_r0x000180257849:
    *(undefined8 *)((int64_t)&uStack_20 + iVar7) = 0x180257851;
    func_0x000180256b30(puVar8);
    return iVar16;
}

// ============================================================
// Function: FUN_180257880
// Address: 0x180257880
// Size: 220 bytes
// ============================================================
undefined8
fcn.180257880(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a8h, int64_t arg_158h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    int64_t *in_RCX;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18025788c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&arg_a8h + iVar7) = 0;
    if (in_RCX[1] != 0) {
        *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_58h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_60h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_70h + iVar7) = 0;
        *(undefined4 *)((int64_t)&arg_78h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_80h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_88h + iVar7) = 0;
        *(undefined8 *)((int64_t)&arg_90h + iVar7) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x1802578f4;
        puVar8 = (undefined4 *)func_0x000180229cc0((int64_t)&var_18h + iVar7);
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar7) = *puVar8;
        *(undefined4 *)((int64_t)&arg_48h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_50h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_50h + iVar7 + 4) = uVar5;
        uVar3 = puVar8[5];
        uVar4 = puVar8[6];
        uVar5 = puVar8[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar7) = puVar8[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar7 + 4) = uVar3;
        *(undefined4 *)((int64_t)&arg_60h + iVar7) = uVar4;
        *(undefined4 *)((int64_t)&arg_60h + iVar7 + 4) = uVar5;
        iVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&arg_68h + iVar7) = *(undefined8 *)(puVar8 + 8);
        pcVar2 = *(code **)(iVar1 + 0x78);
        if (pcVar2 == (code *)0x0) {
            pcVar2 = *(code **)(iVar1 + 0x70);
            if (pcVar2 == (code *)0x0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257947;
            iVar6 = (*pcVar2)((int64_t)&arg_48h + iVar7);
        } else {
            iVar1 = in_RCX[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar7) = 0x180257928;
            iVar6 = (*pcVar2)(iVar1, (int64_t)&arg_48h + iVar7);
        }
        if (iVar6 != 0) {
            return *(undefined8 *)((int64_t)&arg_a8h + iVar7);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180257960
// Address: 0x180257960
// Size: 70 bytes
// ============================================================
void fcn.180257960(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18025796a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180257bb0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180257ae0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180258090;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802579a1;
    fcn.180280b30(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000070 + iVar1), *(int64_t *)(&stack0x000000a0 + iVar1), 
                  *(int64_t *)(&stack0x000000d0 + iVar1), *(int64_t *)(&stack0x000000d8 + iVar1), 
                  *(int64_t *)(&stack0x000000e0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802579b0
// Address: 0x1802579b0
// Size: 70 bytes
// ============================================================
void fcn.1802579b0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802579ba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180257bb0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180257ae0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180258090;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802579f1;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180257a00
// Address: 0x180257a00
// Size: 95 bytes
// ============================================================
void fcn.180257a00(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180257a10;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x28);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180257a3b;
            fcn.180224990(uVar3, 0x1804e64c0, 0x138);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180257a44;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180257a59;
            fcn.180224990(arg1, 0x1804e64c0, 0x13b);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180257a60
// Address: 0x180257a60
// Size: 57 bytes
// ============================================================
undefined8 fcn.180257a60(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x180257a6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_1 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180257a84;
        iVar1 = fcn.180280ea0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                              *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
        if (iVar1 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180257aa0
// Address: 0x180257aa0
// Size: 53 bytes
// ============================================================
bool fcn.180257aa0(int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t in_RCX;
    int32_t iVar9;
    code *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar10;
    undefined8 unaff_RDI;
    undefined8 in_R8;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(in_RCX + 0x20);
    if (iVar4 == 0) {
        return true;
    }
    iVar9 = *(int32_t *)(in_RCX + 4);
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x180280fb5;
    iVar4 = fcn.18045a350(iVar4, iVar9, in_RDX, in_R8);
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180280fc5;
    fcn.18027f1e0();
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x180280fcd;
    iVar5 = fcn.180299670(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_70h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_78h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_80h + iVar4 + iVar3), 
                          *(int64_t *)((int64_t)&arg_88h + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x000000d0 + iVar4 + iVar3));
    uVar8 = *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3);
    *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3);
    *(undefined8 *)((int64_t)&arg_60h + iVar4 + iVar3) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_68h + iVar4 + iVar3) = *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3);
    *(undefined8 *)(&stack0x00000040 + iVar4 + iVar3) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_38h + iVar4 + iVar3) = 0x18029932b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if ((iVar5 != 0) && (0 < iVar9)) {
        uVar1 = *(undefined8 *)(iVar5 + 0x10);
        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x180299353;
        iVar2 = func_0x000180222850(uVar1);
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(iVar5 + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x180299367;
            iVar7 = func_0x000180222340(uVar1, iVar9 + -1);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x180299377;
                iVar7 = func_0x000180221950(iVar7);
            }
            uVar1 = *(undefined8 *)(iVar5 + 0x10);
            *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x180299383;
            fcn.180222910(uVar1);
            if (iVar7 != 0) {
                *(undefined8 *)((int64_t)&arg_70h + iVar6 + iVar4 + iVar3) = uVar8;
                iVar10 = 0;
                *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x180299399;
                iVar2 = fcn.180222010(iVar7);
                iVar9 = 0;
                if (0 < iVar2) {
                    do {
                        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x1802993aa;
                        uVar8 = func_0x000180222340(iVar7, iVar9);
                        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x1802993b3;
                        (*in_RDX)(uVar8, in_R8);
                        iVar10 = iVar9 + 1;
                        *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x1802993bd;
                        iVar2 = fcn.180222010(iVar7);
                        iVar9 = iVar10;
                    } while (iVar10 < iVar2);
                }
                *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar4 + iVar3) = 0x1802993c9;
                func_0x000180221d50(iVar7);
                return 0 < iVar10;
            }
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180257af0
// Address: 0x180257af0
// Size: 46 bytes
// ============================================================
void fcn.180257af0(int64_t param_1, undefined8 param_2, undefined4 param_3)
{
    fcn.18045a350();
    if (*(code **)(param_1 + 0xf8) == (code *)0x0) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180257b1b. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0xf8))(param_2, param_3);
    return;
}

// ============================================================
// Function: FUN_180257b20
// Address: 0x180257b20
// Size: 64 bytes
// ============================================================
void fcn.180257b20(int64_t arg_48h)
{
    int64_t iVar1;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    undefined8 in_R9;
    
    iVar1 = fcn.18045a350();
    if (*(code **)(in_RCX + 0xe0) == (code *)0x0) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180257b5d. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(in_RCX + 0xe0))(in_RDX, in_R8 & 0xffffffff, in_R9, *(undefined8 *)((int64_t)&arg_48h - iVar1));
    return;
}

// ============================================================
// Function: FUN_180257b60
// Address: 0x180257b60
// Size: 70 bytes
// ============================================================
void fcn.180257b60(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180257b6a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x180257bb0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180257ae0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180258090;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180257ba1;
    fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1), *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180257bb0
// Address: 0x180257bb0
// Size: 95 bytes
// ============================================================
void fcn.180257bb0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180257bc0;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x28);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180257beb;
            fcn.180224990(uVar3, 0x1804e64c0, 0x138);
            uVar3 = *(undefined8 *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180257bf4;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180257c09;
            fcn.180224990(arg1, 0x1804e64c0, 0x13b);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180257c10
// Address: 0x180257c10
// Size: 27 bytes
// ============================================================
void fcn.180257c10(int64_t param_1, undefined8 param_2)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x000180257c28. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0x38))(param_2);
    return;
}

// ============================================================
// Function: FUN_180257c30
// Address: 0x180257c30
// Size: 274 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180257c30(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar5;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180257c50;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar5 = 0x1805aadb1;
    if (*(int64_t *)(in_RCX + 0x18) != 0) {
        iVar5 = *(int64_t *)(in_RCX + 0x18);
    }
    if (*(int64_t *)(in_RCX + 0x90) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257c80;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257c98;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(int64_t *)((int64_t)&var_18h + iVar3) = iVar5;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257cb7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        iVar4 = 0;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257cc0;
        func_0x000180229b10();
        pcVar1 = *(code **)(in_RCX + 0x90);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257cd2;
        iVar4 = (*pcVar1)(in_RDX, in_R8, in_R9);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257cdf;
            iVar2 = func_0x000180229970();
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257ce8;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257d00;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(int64_t *)((int64_t)&var_18h + iVar3) = iVar5;
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257d1f;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180257d24;
        func_0x000180229900();
    }
    return iVar4;
}

// ============================================================
// Function: FUN_180257d50
// Address: 0x180257d50
// Size: 40 bytes
// ============================================================
void fcn.180257d50(int64_t param_1, undefined8 param_2)
{
    fcn.18045a350();
    if (*(code **)(param_1 + 0x98) != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180257d70. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(param_1 + 0x98))(param_2);
        return;
    }
    return;
}

// ============================================================
// Function: FUN_180257d80
// Address: 0x180257d80
// Size: 43 bytes
// ============================================================
void fcn.180257d80(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    fcn.18045a350();
    if (*(code **)(param_1 + 0x70) == (code *)0x0) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180257da8. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0x70))(param_2, param_3);
    return;
}

// ============================================================
// Function: FUN_180257db0
// Address: 0x180257db0
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180257db0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180257dc5;
    iVar1 = fcn.18045a350();
    uVar2 = *(undefined8 *)(in_RCX + 0x20);
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180257dd9;
    uVar2 = fcn.18027e810(uVar2);
    if (*(code **)(in_RCX + 0x60) == (code *)0x0) {
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180257e0b. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(in_RCX + 0x60))(uVar2, in_RDX & 0xffffffff, in_R8);
    return uVar2;
}

// ============================================================
// Function: FUN_180257e10
// Address: 0x180257e10
// Size: 46 bytes
// ============================================================
void fcn.180257e10(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    fcn.18045a350();
    if (*(code **)(param_1 + 0x80) == (code *)0x0) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180257e3b. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0x80))(param_2, param_3);
    return;
}

// ============================================================
// Function: FUN_180257e40
// Address: 0x180257e40
// Size: 48 bytes
// ============================================================
undefined8 fcn.180257e40(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(param_1 + 0x68) == (code *)0x0) {
        return 1;
    }
    // WARNING: Could not recover jumptable at 0x000180257e6d. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(param_1 + 0x68))(param_2, param_3);
    return uVar1;
}

// ============================================================
// Function: FUN_180257e70
// Address: 0x180257e70
// Size: 48 bytes
// ============================================================
undefined8 fcn.180257e70(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(param_1 + 0x40) == (code *)0x0) {
        return 1;
    }
    // WARNING: Could not recover jumptable at 0x000180257e9d. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(param_1 + 0x40))(param_2, param_3);
    return uVar1;
}

// ============================================================
// Function: FUN_180257ea0
// Address: 0x180257ea0
// Size: 36 bytes
// ============================================================
void fcn.180257ea0(int64_t param_1, undefined8 param_2, undefined4 param_3)
{
    fcn.18045a350();
    // WARNING: Could not recover jumptable at 0x000180257ec1. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0xb0))(param_2, param_3);
    return;
}

// ============================================================
// Function: FUN_180257ef0
// Address: 0x180257ef0
// Size: 52 bytes
// ============================================================
void fcn.180257ef0(int64_t param_1, undefined8 param_2, uint64_t param_3, undefined8 param_4)
{
    fcn.18045a350();
    if (*(code **)(param_1 + 200) == (code *)0x0) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180257f21. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 200))(param_2, param_3 & 0xffffffff, param_4);
    return;
}

// ============================================================
// Function: FUN_180257f30
// Address: 0x180257f30
// Size: 53 bytes
// ============================================================
undefined8 fcn.180257f30(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if ((param_1 != 0) && (*(code **)(param_1 + 0xa0) != (code *)0x0)) {
    // WARNING: Could not recover jumptable at 0x000180257f5b. Too many branches
    // WARNING: Treating indirect jump as call
        uVar1 = (**(code **)(param_1 + 0xa0))(param_2, param_3);
        return uVar1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180257f70
// Address: 0x180257f70
// Size: 52 bytes
// ============================================================
void fcn.180257f70(int64_t param_1, undefined8 param_2, undefined8 param_3, undefined4 param_4)
{
    fcn.18045a350();
    if (*(code **)(param_1 + 0xc0) == (code *)0x0) {
        return;
    }
    // WARNING: Could not recover jumptable at 0x000180257fa1. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)(param_1 + 0xc0))(param_2, param_3, param_4);
    return;
}

// ============================================================
// Function: FUN_180257fb0
// Address: 0x180257fb0
// Size: 55 bytes
// ============================================================
undefined8 fcn.180257fb0(int64_t param_1)
{
    int64_t iVar1;
    undefined8 uVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x180257fbc;
    iVar1 = fcn.18045a350();
    uVar2 = *(undefined8 *)(param_1 + 0x20);
    *(undefined8 *)((int64_t)&uStack_10 - iVar1) = 0x180257fcb;
    uVar2 = fcn.18027e810(uVar2);
    if (*(code **)(param_1 + 0x30) == (code *)0x0) {
        return 0;
    }
    // WARNING: Could not recover jumptable at 0x000180257fe4. Too many branches
    // WARNING: Treating indirect jump as call
    uVar2 = (**(code **)(param_1 + 0x30))(uVar2);
    return uVar2;
}

// ============================================================
// Function: FUN_180257ff0
// Address: 0x180257ff0
// Size: 48 bytes
// ============================================================
undefined8 fcn.180257ff0(int64_t param_1, undefined8 param_2, undefined8 param_3)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(param_1 + 0x50) == (code *)0x0) {
        return 1;
    }
    // WARNING: Could not recover jumptable at 0x00018025801d. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(param_1 + 0x50))(param_2, param_3);
    return uVar1;
}

// ============================================================
// Function: FUN_180258020
// Address: 0x180258020
// Size: 57 bytes
// ============================================================
undefined8 fcn.180258020(int64_t param_1, undefined8 param_2, uint64_t param_3, undefined4 param_4)
{
    undefined8 uVar1;
    
    fcn.18045a350();
    if (*(code **)(param_1 + 0xb8) == (code *)0x0) {
        return 1;
    }
    // WARNING: Could not recover jumptable at 0x000180258056. Too many branches
    // WARNING: Treating indirect jump as call
    uVar1 = (**(code **)(param_1 + 0xb8))(param_2, param_3 & 0xffffffff, param_4);
    return uVar1;
}

// ============================================================
// Function: FUN_180258060
// Address: 0x180258060
// Size: 36 bytes
// ============================================================
void fcn.180258060(undefined8 param_1, int32_t *param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025806c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (*param_2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025807c;
        iVar1 = fcn.1802314f0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8)
                              , *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000070 + iVar2));
        *param_2 = iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_180258090
// Address: 0x180258090
// Size: 1700 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

int64_t fcn.180258090(undefined8 placeholder_0, int64_t placeholder_1, int64_t arg3, int64_t arg_48h, int64_t arg_50h,
                     int64_t arg_58h, int64_t arg_60h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int32_t iVar11;
    undefined4 uVar12;
    uint32_t uVar13;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_40;
    int64_t var_10h;
    
    uStack_40 = 0x1802580af;
    var_18h = arg3;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    piVar1 = *(int32_t **)(placeholder_1 + 0x10);
    *(undefined4 *)((int64_t)&var_10h + iVar5) = 0;
    *(undefined4 *)((int64_t)&arg_50h + iVar5) = 0;
    *(undefined4 *)(&stack0xffffffffffffffe8 + iVar5) = 0;
    *(undefined4 *)(&stack0xffffffffffffffec + iVar5) = 0;
    *(undefined4 *)((int64_t)&arg_60h + iVar5) = 0;
    uVar9 = 0;
    uVar13 = 0;
    uVar10 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802580fd;
    iVar6 = fcn.180224d60(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5));
    if (iVar6 != 0) {
        *(undefined4 *)(iVar6 + 0x28) = 1;
        *(undefined4 **)(&stack0xfffffffffffffff8 + iVar5) = (undefined4 *)(iVar6 + 4);
        *(undefined4 *)(iVar6 + 4) = (undefined4)placeholder_0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180258123;
        iVar7 = func_0x000180282210(placeholder_1);
        *(int64_t *)(iVar6 + 0x10) = iVar7;
        if (iVar7 == 0) {
            LOCK();
            piVar1 = (int32_t *)(iVar6 + 0x28);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 < 2) {
                uVar2 = *(undefined8 *)(iVar6 + 0x10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180258155;
                fcn.180224990(uVar2, 0x1804e64c0, 0x138);
                uVar2 = *(undefined8 *)(iVar6 + 0x20);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18025815e;
                fcn.18027edb0(uVar2);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180258173;
                fcn.180224990(iVar6, 0x1804e64c0, 0x13b);
            }
        } else {
            *(undefined8 *)(iVar6 + 0x18) = *(undefined8 *)(placeholder_1 + 0x18);
            iVar3 = *piVar1;
            if (iVar3 != 0) {
                puVar8 = (undefined8 *)(piVar1 + 2);
                iVar11 = 0;
                do {
    // switch table (46 cases) at 0x18025867c
                    switch(iVar3) {
                    case 1:
                        if (*(int64_t *)(iVar6 + 0x30) == 0) {
                            *(undefined8 *)(iVar6 + 0x30) = *puVar8;
                        }
                        break;
                    case 2:
                        if (*(int64_t *)(iVar6 + 0x60) == 0) {
                            *(undefined8 *)(iVar6 + 0x60) = *puVar8;
                        }
                        break;
                    case 3:
                        if (*(int64_t *)(iVar6 + 0x68) == 0) {
                            *(undefined8 *)(iVar6 + 0x68) = *puVar8;
                        }
                        break;
                    case 4:
                        if (*(int64_t *)(iVar6 + 0x80) == 0) {
                            uVar2 = *puVar8;
                            *(int32_t *)((int64_t)&arg_50h + iVar5) = *(int32_t *)((int64_t)&arg_50h + iVar5) + 1;
                            *(undefined8 *)(iVar6 + 0x80) = uVar2;
                        }
                        break;
                    case 5:
                        if (*(int64_t *)(iVar6 + 0x88) == 0) {
                            uVar2 = *puVar8;
                            *(int32_t *)((int64_t)&arg_50h + iVar5) = *(int32_t *)((int64_t)&arg_50h + iVar5) + 1;
                            *(undefined8 *)(iVar6 + 0x88) = uVar2;
                        }
                        break;
                    case 6:
                        if (*(int64_t *)(iVar6 + 0x90) == 0) {
                            *(undefined8 *)(iVar6 + 0x90) = *puVar8;
                        }
                        break;
                    case 7:
                        if (*(int64_t *)(iVar6 + 0x98) == 0) {
                            *(undefined8 *)(iVar6 + 0x98) = *puVar8;
                        }
                        break;
                    case 8:
                        if (*(int64_t *)(iVar6 + 0xa0) == 0) {
                            *(undefined8 *)(iVar6 + 0xa0) = *puVar8;
                        }
                        break;
                    case 10:
                        if (*(int64_t *)(iVar6 + 0x38) == 0) {
                            *(undefined8 *)(iVar6 + 0x38) = *puVar8;
                        }
                        break;
                    case 0xb:
                        if (*(int64_t *)(iVar6 + 0x40) == 0) {
                            uVar9 = uVar9 + 1;
                            *(undefined8 *)(iVar6 + 0x40) = *puVar8;
                        }
                        break;
                    case 0xc:
                        if (*(int64_t *)(iVar6 + 0x48) == 0) {
                            uVar9 = uVar9 + 1;
                            *(undefined8 *)(iVar6 + 0x48) = *puVar8;
                        }
                        break;
                    case 0xd:
                        if (*(int64_t *)(iVar6 + 0x50) == 0) {
                            iVar11 = iVar11 + 1;
                            *(undefined8 *)(iVar6 + 0x50) = *puVar8;
                        }
                        break;
                    case 0xe:
                        if (*(int64_t *)(iVar6 + 0x58) == 0) {
                            iVar11 = iVar11 + 1;
                            *(undefined8 *)(iVar6 + 0x58) = *puVar8;
                        }
                        break;
                    case 0xf:
                        if (*(int64_t *)(iVar6 + 0x70) == 0) {
                            uVar2 = *puVar8;
                            *(int32_t *)((int64_t)&arg_60h + iVar5) = *(int32_t *)((int64_t)&arg_60h + iVar5) + 1;
                            *(undefined8 *)(iVar6 + 0x70) = uVar2;
                        }
                        break;
                    case 0x10:
                        if (*(int64_t *)(iVar6 + 0x78) == 0) {
                            uVar2 = *puVar8;
                            *(int32_t *)((int64_t)&arg_60h + iVar5) = *(int32_t *)((int64_t)&arg_60h + iVar5) + 1;
                            *(undefined8 *)(iVar6 + 0x78) = uVar2;
                        }
                        break;
                    case 0x14:
                        if (*(int64_t *)(iVar6 + 0xa8) == 0) {
                            *(undefined8 *)(iVar6 + 0xa8) = *puVar8;
                        }
                        break;
                    case 0x15:
                        if (*(int64_t *)(iVar6 + 0xb0) == 0) {
                            *(undefined8 *)(iVar6 + 0xb0) = *puVar8;
                        }
                        break;
                    case 0x16:
                        if (*(int64_t *)(iVar6 + 0xb8) == 0) {
                            *(undefined8 *)(iVar6 + 0xb8) = *puVar8;
                        }
                        break;
                    case 0x17:
                        if (*(int64_t *)(iVar6 + 0xc0) == 0) {
                            *(undefined8 *)(iVar6 + 0xc0) = *puVar8;
                        }
                        break;
                    case 0x28:
                        if (*(int64_t *)(iVar6 + 200) == 0) {
                            uVar13 = uVar13 + 1;
                            *(undefined8 *)(iVar6 + 200) = *puVar8;
                        }
                        break;
                    case 0x29:
                        if (*(int64_t *)(iVar6 + 0xd0) == 0) {
                            uVar4 = uVar13 + 1;
                            if (*(int32_t *)(&stack0xffffffffffffffe8 + iVar5) != 0) {
                                uVar4 = uVar13;
                            }
                            *(int32_t *)(&stack0xffffffffffffffe8 + iVar5) =
                                 *(int32_t *)(&stack0xffffffffffffffe8 + iVar5) + 1;
                            *(undefined8 *)(iVar6 + 0xd0) = *puVar8;
                            uVar13 = uVar4;
                        }
                        break;
                    case 0x2a:
                        if (*(int64_t *)(iVar6 + 0xe0) == 0) {
                            uVar10 = uVar10 + 1;
                            *(undefined8 *)(iVar6 + 0xe0) = *puVar8;
                        }
                        break;
                    case 0x2b:
                        if (*(int64_t *)(iVar6 + 0xe8) == 0) {
                            iVar3 = *(int32_t *)(&stack0xffffffffffffffec + iVar5);
                            uVar4 = uVar10 + 1;
                            if (iVar3 != 0) {
                                uVar4 = uVar10;
                            }
                            *(undefined8 *)(iVar6 + 0xe8) = *puVar8;
                            uVar10 = uVar4;
code_r0x0001802584d4:
                            *(int32_t *)(&stack0xffffffffffffffec + iVar5) = iVar3 + 1;
                        }
                        break;
                    case 0x2c:
                        if (*(int64_t *)(iVar6 + 0xf8) == 0) {
                            *(undefined8 *)(iVar6 + 0xf8) = *puVar8;
                        }
                        break;
                    case 0x2d:
                        if (*(int64_t *)(iVar6 + 0xd8) == 0) {
                            uVar4 = uVar13 + 1;
                            if (*(int32_t *)(&stack0xffffffffffffffe8 + iVar5) != 0) {
                                uVar4 = uVar13;
                            }
                            *(int32_t *)(&stack0xffffffffffffffe8 + iVar5) =
                                 *(int32_t *)(&stack0xffffffffffffffe8 + iVar5) + 1;
                            *(undefined8 *)(iVar6 + 0xd8) = *puVar8;
                            uVar13 = uVar4;
                        }
                        break;
                    case 0x2e:
                        if (*(int64_t *)(iVar6 + 0xf0) == 0) {
                            iVar3 = *(int32_t *)(&stack0xffffffffffffffec + iVar5);
                            uVar4 = uVar10 + 1;
                            if (iVar3 != 0) {
                                uVar4 = uVar10;
                            }
                            *(undefined8 *)(iVar6 + 0xf0) = *puVar8;
                            uVar10 = uVar4;
                            goto code_r0x0001802584d4;
                        }
                    }
                    iVar3 = *(int32_t *)(puVar8 + 1);
                    puVar8 = puVar8 + 2;
                } while (iVar3 != 0);
                *(int32_t *)((int64_t)&var_10h + iVar5) = iVar11;
            }
            uVar12 = 0;
            if ((((*(int64_t *)(iVar6 + 0x38) != 0) &&
                 ((((*(int64_t *)(iVar6 + 0x30) != 0 || (*(int64_t *)(iVar6 + 0x90) != 0)) ||
                   (*(int64_t *)(iVar6 + 0xa0) != 0)) &&
                  ((*(int64_t *)(iVar6 + 0xb0) != 0 && ((uVar9 & 0xfffffffd) == 0)))))) &&
                ((*(uint32_t *)((int64_t)&var_10h + iVar5) & 0xfffffffd) == 0)) &&
               (((((*(uint32_t *)((int64_t)&arg_50h + iVar5) & 0xfffffffd) == 0 &&
                  ((*(uint32_t *)((int64_t)&arg_60h + iVar5) & 0xfffffffd) == 0)) &&
                 (((uVar13 & 0xfffffffd) == 0 && ((uVar10 & 0xfffffffd) == 0)))) &&
                ((*(int64_t *)(iVar6 + 0x90) == 0 ||
                 ((*(int64_t *)(iVar6 + 0x60) != 0 && (*(int64_t *)(iVar6 + 0x98) != 0)))))))) {
                iVar7 = *(int64_t *)((int64_t)&arg_58h + iVar5);
                *(int64_t *)(iVar6 + 0x20) = iVar7;
                if (iVar7 != 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802585b0;
                    func_0x00018027fb30(iVar7);
                }
                iVar7 = *(int64_t *)(iVar6 + 0x20);
                *(undefined4 *)((int64_t)&arg_50h + iVar5) = 0;
                if (iVar7 != 0) {
                    uVar12 = **(undefined4 **)(&stack0xfffffffffffffff8 + iVar5);
                    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x1802585dc;
                    func_0x000180280fa0(iVar7, uVar12, fcn.180258060, (int64_t)&arg_50h + iVar5);
                    uVar12 = *(undefined4 *)((int64_t)&arg_50h + iVar5);
                }
                *(undefined4 *)(iVar6 + 8) = uVar12;
                return iVar6;
            }
            LOCK();
            piVar1 = (int32_t *)(iVar6 + 0x28);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar3 < 2) {
                uVar2 = *(undefined8 *)(iVar6 + 0x10);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180258612;
                fcn.180224990(uVar2, 0x1804e64c0, 0x138);
                uVar2 = *(undefined8 *)(iVar6 + 0x20);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18025861b;
                fcn.18027edb0(uVar2);
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180258630;
                fcn.180224990(iVar6, 0x1804e64c0, 0x13b);
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x180258635;
            fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18025864d;
            fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar5), *(int64_t *)(&stack0x00000000 + iVar5), 
                          *(int64_t *)((int64_t)&var_18h + iVar5));
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18025865f;
            fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar5));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180258740
// Address: 0x180258740
// Size: 266 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.180258740(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_70h)
{
    int32_t iVar1;
    undefined8 uVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180258753;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18025876c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180258784;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180258796;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_50h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802587bd;
    fcn.180229b10();
    iVar1 = *(int32_t *)((int64_t)&arg_68h + iVar4);
    uVar2 = *(undefined8 *)((int64_t)&arg_70h + iVar4);
    *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)iVar1;
    *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar2;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802587f1;
    uVar3 = fcn.180259ee0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                          *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)((int64_t)&arg_60h + iVar4));
    if (uVar3 == 0xfffffffe) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802587fd;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180258804;
        fcn.180229900();
        if (((int32_t)uVar3 < 1) || (*in_RCX == 0)) {
            return (uint64_t)uVar3;
        }
    }
    *(undefined8 *)((int64_t)&var_10h + iVar4) = uVar2;
    *(int32_t *)((int64_t)&var_8h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180258829;
    uVar5 = fcn.1802595d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar4));
    return uVar5;
}

// ============================================================
// Function: FUN_180258850
// Address: 0x180258850
// Size: 100 bytes
// ============================================================
uint32_t * fcn.180258850(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025885c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258873;
        iVar3 = fcn.18026b010(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025887c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258894;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588a6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            return (uint32_t *)0x0;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588ca;
    puVar5 = (uint32_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (puVar5 == (uint32_t *)0x0) {
        return (uint32_t *)0x0;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x22);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588f5;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x22) = *(undefined8 *)(in_RCX + 0x22);
    *puVar5 = *in_RCX;
    *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)(puVar5 + 6) = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(puVar5 + 4) = 0;
    if (*(int64_t *)(in_RCX + 4) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025893e;
        iVar6 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(int64_t *)(puVar5 + 4) = iVar6;
        if (iVar6 == 0) goto code_r0x0001802589c1;
    }
    puVar5[0x1d] = in_RCX[0x1d];
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025895b;
        iVar3 = fcn.180257ae0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
        *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(in_RCX + 8);
    }
    uVar1 = *in_RCX;
    if ((uVar1 >> 0xb & 1) == 0) {
        if ((uVar1 & 0xc1f0) == 0) {
            if ((uVar1 & 0x600) == 0) {
                if ((uVar1 & 0x3000) == 0) {
                    if ((uVar1 & 6) != 0) goto code_r0x0001802589c1;
                } else {
                    if (*(int64_t *)(in_RCX + 10) != 0) {
                        *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258ab4;
                        iVar3 = fcn.180248230();
                        if (iVar3 == 0) goto code_r0x0001802589c1;
                    }
                    if (*(int64_t *)(in_RCX + 0xc) != 0) {
                        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                        if (pcVar2 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258add;
                            uVar7 = (*pcVar2)();
                            *(undefined8 *)(puVar5 + 0xc) = uVar7;
                        }
                        if (*(int64_t *)(puVar5 + 0xc) != 0) {
                            return puVar5;
                        }
                        uVar7 = *(undefined8 *)(puVar5 + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258af4;
                        fcn.18026df60(uVar7);
                        goto code_r0x0001802589bd;
                    }
                }
            } else {
                if (*(int64_t *)(in_RCX + 10) != 0) {
                    *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a52;
                    iVar3 = fcn.180248230();
                    if (iVar3 == 0) goto code_r0x0001802589c1;
                }
                if (*(int64_t *)(in_RCX + 0xc) != 0) {
                    if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                    if (pcVar2 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a7f;
                        uVar7 = (*pcVar2)();
                        *(undefined8 *)(puVar5 + 0xc) = uVar7;
                    }
                    if (*(int64_t *)(puVar5 + 0xc) != 0) {
                        return puVar5;
                    }
                    uVar7 = *(undefined8 *)(puVar5 + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a96;
                    fcn.180264d30(uVar7);
                    goto code_r0x0001802589bd;
                }
            }
        } else {
            if (*(int64_t *)(in_RCX + 10) != 0) {
                *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589f8;
                iVar3 = fcn.180248230();
                if (iVar3 == 0) goto code_r0x0001802589c1;
            }
            if (*(int64_t *)(in_RCX + 0xc) != 0) {
                if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xd8);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a20;
                    uVar7 = (*pcVar2)();
                    *(undefined8 *)(puVar5 + 0xc) = uVar7;
                }
                if (*(int64_t *)(puVar5 + 0xc) != 0) {
                    return puVar5;
                }
                uVar7 = *(undefined8 *)(puVar5 + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a37;
                fcn.1802481d0(uVar7);
                goto code_r0x0001802589bd;
            }
        }
    } else {
        if (*(int64_t *)(in_RCX + 10) != 0) {
            *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258981;
            iVar3 = fcn.180248230();
            if (iVar3 == 0) goto code_r0x0001802589c1;
        }
        if (*(int64_t *)(in_RCX + 0xc) != 0) {
            if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x50);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589a6;
                uVar7 = (*pcVar2)();
                *(undefined8 *)(puVar5 + 0xc) = uVar7;
            }
            if (*(int64_t *)(puVar5 + 0xc) != 0) {
                return puVar5;
            }
            uVar7 = *(undefined8 *)(puVar5 + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589bd;
            fcn.180249610(uVar7);
code_r0x0001802589bd:
            *(undefined8 *)(puVar5 + 10) = 0;
            goto code_r0x0001802589c1;
        }
    }
    *(undefined8 *)(puVar5 + 0x1e) = *(undefined8 *)(in_RCX + 0x1e);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(in_RCX + 0x20);
    if (*(int64_t *)(in_RCX + 0x24) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b28;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x24) = *(undefined8 *)(in_RCX + 0x24);
    if (*(int64_t *)(in_RCX + 0x1e) == 0) {
        if (*puVar5 == 0) {
            iVar6 = *(int64_t *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)(in_RCX + 8);
            if (iVar6 == 0) {
                return puVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b76;
            iVar6 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar4));
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b89;
                iVar3 = fcn.180257ae0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
                if (iVar3 != 0) {
                    iVar6 = *(int64_t *)(puVar5 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b9a;
                    fcn.180257a00(iVar6);
                    *(undefined8 *)(puVar5 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                    return puVar5;
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258bc2;
        iVar3 = (*pcVar2)(puVar5, in_RCX);
        if (0 < iVar3) {
            return puVar5;
        }
    }
code_r0x0001802589c1:
    *(undefined8 *)(puVar5 + 0x1e) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589cd;
    fcn.180258be0(puVar5);
    return (uint32_t *)0x0;
}

// ============================================================
// Function: FUN_1802588b4
// Address: 0x1802588b4
// Size: 41 bytes
// ============================================================
uint32_t * fcn.180258850(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025885c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258873;
        iVar3 = fcn.18026b010(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025887c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258894;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588a6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            return (uint32_t *)0x0;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588ca;
    puVar5 = (uint32_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (puVar5 == (uint32_t *)0x0) {
        return (uint32_t *)0x0;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x22);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588f5;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x22) = *(undefined8 *)(in_RCX + 0x22);
    *puVar5 = *in_RCX;
    *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)(puVar5 + 6) = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(puVar5 + 4) = 0;
    if (*(int64_t *)(in_RCX + 4) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025893e;
        iVar6 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(int64_t *)(puVar5 + 4) = iVar6;
        if (iVar6 == 0) goto code_r0x0001802589c1;
    }
    puVar5[0x1d] = in_RCX[0x1d];
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025895b;
        iVar3 = fcn.180257ae0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
        *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(in_RCX + 8);
    }
    uVar1 = *in_RCX;
    if ((uVar1 >> 0xb & 1) == 0) {
        if ((uVar1 & 0xc1f0) == 0) {
            if ((uVar1 & 0x600) == 0) {
                if ((uVar1 & 0x3000) == 0) {
                    if ((uVar1 & 6) != 0) goto code_r0x0001802589c1;
                } else {
                    if (*(int64_t *)(in_RCX + 10) != 0) {
                        *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258ab4;
                        iVar3 = fcn.180248230();
                        if (iVar3 == 0) goto code_r0x0001802589c1;
                    }
                    if (*(int64_t *)(in_RCX + 0xc) != 0) {
                        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                        if (pcVar2 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258add;
                            uVar7 = (*pcVar2)();
                            *(undefined8 *)(puVar5 + 0xc) = uVar7;
                        }
                        if (*(int64_t *)(puVar5 + 0xc) != 0) {
                            return puVar5;
                        }
                        uVar7 = *(undefined8 *)(puVar5 + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258af4;
                        fcn.18026df60(uVar7);
                        goto code_r0x0001802589bd;
                    }
                }
            } else {
                if (*(int64_t *)(in_RCX + 10) != 0) {
                    *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a52;
                    iVar3 = fcn.180248230();
                    if (iVar3 == 0) goto code_r0x0001802589c1;
                }
                if (*(int64_t *)(in_RCX + 0xc) != 0) {
                    if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                    if (pcVar2 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a7f;
                        uVar7 = (*pcVar2)();
                        *(undefined8 *)(puVar5 + 0xc) = uVar7;
                    }
                    if (*(int64_t *)(puVar5 + 0xc) != 0) {
                        return puVar5;
                    }
                    uVar7 = *(undefined8 *)(puVar5 + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a96;
                    fcn.180264d30(uVar7);
                    goto code_r0x0001802589bd;
                }
            }
        } else {
            if (*(int64_t *)(in_RCX + 10) != 0) {
                *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589f8;
                iVar3 = fcn.180248230();
                if (iVar3 == 0) goto code_r0x0001802589c1;
            }
            if (*(int64_t *)(in_RCX + 0xc) != 0) {
                if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xd8);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a20;
                    uVar7 = (*pcVar2)();
                    *(undefined8 *)(puVar5 + 0xc) = uVar7;
                }
                if (*(int64_t *)(puVar5 + 0xc) != 0) {
                    return puVar5;
                }
                uVar7 = *(undefined8 *)(puVar5 + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a37;
                fcn.1802481d0(uVar7);
                goto code_r0x0001802589bd;
            }
        }
    } else {
        if (*(int64_t *)(in_RCX + 10) != 0) {
            *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258981;
            iVar3 = fcn.180248230();
            if (iVar3 == 0) goto code_r0x0001802589c1;
        }
        if (*(int64_t *)(in_RCX + 0xc) != 0) {
            if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x50);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589a6;
                uVar7 = (*pcVar2)();
                *(undefined8 *)(puVar5 + 0xc) = uVar7;
            }
            if (*(int64_t *)(puVar5 + 0xc) != 0) {
                return puVar5;
            }
            uVar7 = *(undefined8 *)(puVar5 + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589bd;
            fcn.180249610(uVar7);
code_r0x0001802589bd:
            *(undefined8 *)(puVar5 + 10) = 0;
            goto code_r0x0001802589c1;
        }
    }
    *(undefined8 *)(puVar5 + 0x1e) = *(undefined8 *)(in_RCX + 0x1e);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(in_RCX + 0x20);
    if (*(int64_t *)(in_RCX + 0x24) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b28;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x24) = *(undefined8 *)(in_RCX + 0x24);
    if (*(int64_t *)(in_RCX + 0x1e) == 0) {
        if (*puVar5 == 0) {
            iVar6 = *(int64_t *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)(in_RCX + 8);
            if (iVar6 == 0) {
                return puVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b76;
            iVar6 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar4));
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b89;
                iVar3 = fcn.180257ae0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
                if (iVar3 != 0) {
                    iVar6 = *(int64_t *)(puVar5 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b9a;
                    fcn.180257a00(iVar6);
                    *(undefined8 *)(puVar5 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                    return puVar5;
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258bc2;
        iVar3 = (*pcVar2)(puVar5, in_RCX);
        if (0 < iVar3) {
            return puVar5;
        }
    }
code_r0x0001802589c1:
    *(undefined8 *)(puVar5 + 0x1e) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589cd;
    fcn.180258be0(puVar5);
    return (uint32_t *)0x0;
}

// ============================================================
// Function: FUN_1802588dd
// Address: 0x1802588dd
// Size: 258 bytes
// ============================================================
uint32_t * fcn.180258850(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025885c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258873;
        iVar3 = fcn.18026b010(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025887c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258894;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588a6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            return (uint32_t *)0x0;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588ca;
    puVar5 = (uint32_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (puVar5 == (uint32_t *)0x0) {
        return (uint32_t *)0x0;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x22);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588f5;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x22) = *(undefined8 *)(in_RCX + 0x22);
    *puVar5 = *in_RCX;
    *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)(puVar5 + 6) = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(puVar5 + 4) = 0;
    if (*(int64_t *)(in_RCX + 4) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025893e;
        iVar6 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(int64_t *)(puVar5 + 4) = iVar6;
        if (iVar6 == 0) goto code_r0x0001802589c1;
    }
    puVar5[0x1d] = in_RCX[0x1d];
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025895b;
        iVar3 = fcn.180257ae0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
        *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(in_RCX + 8);
    }
    uVar1 = *in_RCX;
    if ((uVar1 >> 0xb & 1) == 0) {
        if ((uVar1 & 0xc1f0) == 0) {
            if ((uVar1 & 0x600) == 0) {
                if ((uVar1 & 0x3000) == 0) {
                    if ((uVar1 & 6) != 0) goto code_r0x0001802589c1;
                } else {
                    if (*(int64_t *)(in_RCX + 10) != 0) {
                        *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258ab4;
                        iVar3 = fcn.180248230();
                        if (iVar3 == 0) goto code_r0x0001802589c1;
                    }
                    if (*(int64_t *)(in_RCX + 0xc) != 0) {
                        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                        if (pcVar2 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258add;
                            uVar7 = (*pcVar2)();
                            *(undefined8 *)(puVar5 + 0xc) = uVar7;
                        }
                        if (*(int64_t *)(puVar5 + 0xc) != 0) {
                            return puVar5;
                        }
                        uVar7 = *(undefined8 *)(puVar5 + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258af4;
                        fcn.18026df60(uVar7);
                        goto code_r0x0001802589bd;
                    }
                }
            } else {
                if (*(int64_t *)(in_RCX + 10) != 0) {
                    *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a52;
                    iVar3 = fcn.180248230();
                    if (iVar3 == 0) goto code_r0x0001802589c1;
                }
                if (*(int64_t *)(in_RCX + 0xc) != 0) {
                    if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                    if (pcVar2 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a7f;
                        uVar7 = (*pcVar2)();
                        *(undefined8 *)(puVar5 + 0xc) = uVar7;
                    }
                    if (*(int64_t *)(puVar5 + 0xc) != 0) {
                        return puVar5;
                    }
                    uVar7 = *(undefined8 *)(puVar5 + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a96;
                    fcn.180264d30(uVar7);
                    goto code_r0x0001802589bd;
                }
            }
        } else {
            if (*(int64_t *)(in_RCX + 10) != 0) {
                *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589f8;
                iVar3 = fcn.180248230();
                if (iVar3 == 0) goto code_r0x0001802589c1;
            }
            if (*(int64_t *)(in_RCX + 0xc) != 0) {
                if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xd8);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a20;
                    uVar7 = (*pcVar2)();
                    *(undefined8 *)(puVar5 + 0xc) = uVar7;
                }
                if (*(int64_t *)(puVar5 + 0xc) != 0) {
                    return puVar5;
                }
                uVar7 = *(undefined8 *)(puVar5 + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a37;
                fcn.1802481d0(uVar7);
                goto code_r0x0001802589bd;
            }
        }
    } else {
        if (*(int64_t *)(in_RCX + 10) != 0) {
            *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258981;
            iVar3 = fcn.180248230();
            if (iVar3 == 0) goto code_r0x0001802589c1;
        }
        if (*(int64_t *)(in_RCX + 0xc) != 0) {
            if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x50);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589a6;
                uVar7 = (*pcVar2)();
                *(undefined8 *)(puVar5 + 0xc) = uVar7;
            }
            if (*(int64_t *)(puVar5 + 0xc) != 0) {
                return puVar5;
            }
            uVar7 = *(undefined8 *)(puVar5 + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589bd;
            fcn.180249610(uVar7);
code_r0x0001802589bd:
            *(undefined8 *)(puVar5 + 10) = 0;
            goto code_r0x0001802589c1;
        }
    }
    *(undefined8 *)(puVar5 + 0x1e) = *(undefined8 *)(in_RCX + 0x1e);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(in_RCX + 0x20);
    if (*(int64_t *)(in_RCX + 0x24) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b28;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x24) = *(undefined8 *)(in_RCX + 0x24);
    if (*(int64_t *)(in_RCX + 0x1e) == 0) {
        if (*puVar5 == 0) {
            iVar6 = *(int64_t *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)(in_RCX + 8);
            if (iVar6 == 0) {
                return puVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b76;
            iVar6 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar4));
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b89;
                iVar3 = fcn.180257ae0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
                if (iVar3 != 0) {
                    iVar6 = *(int64_t *)(puVar5 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b9a;
                    fcn.180257a00(iVar6);
                    *(undefined8 *)(puVar5 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                    return puVar5;
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258bc2;
        iVar3 = (*pcVar2)(puVar5, in_RCX);
        if (0 < iVar3) {
            return puVar5;
        }
    }
code_r0x0001802589c1:
    *(undefined8 *)(puVar5 + 0x1e) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589cd;
    fcn.180258be0(puVar5);
    return (uint32_t *)0x0;
}

// ============================================================
// Function: FUN_1802589df
// Address: 0x1802589df
// Size: 471 bytes
// ============================================================
uint32_t * fcn.180258850(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025885c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258873;
        iVar3 = fcn.18026b010(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025887c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258894;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588a6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            return (uint32_t *)0x0;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588ca;
    puVar5 = (uint32_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (puVar5 == (uint32_t *)0x0) {
        return (uint32_t *)0x0;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x22);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588f5;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x22) = *(undefined8 *)(in_RCX + 0x22);
    *puVar5 = *in_RCX;
    *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)(puVar5 + 6) = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(puVar5 + 4) = 0;
    if (*(int64_t *)(in_RCX + 4) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025893e;
        iVar6 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(int64_t *)(puVar5 + 4) = iVar6;
        if (iVar6 == 0) goto code_r0x0001802589c1;
    }
    puVar5[0x1d] = in_RCX[0x1d];
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025895b;
        iVar3 = fcn.180257ae0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
        *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(in_RCX + 8);
    }
    uVar1 = *in_RCX;
    if ((uVar1 >> 0xb & 1) == 0) {
        if ((uVar1 & 0xc1f0) == 0) {
            if ((uVar1 & 0x600) == 0) {
                if ((uVar1 & 0x3000) == 0) {
                    if ((uVar1 & 6) != 0) goto code_r0x0001802589c1;
                } else {
                    if (*(int64_t *)(in_RCX + 10) != 0) {
                        *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258ab4;
                        iVar3 = fcn.180248230();
                        if (iVar3 == 0) goto code_r0x0001802589c1;
                    }
                    if (*(int64_t *)(in_RCX + 0xc) != 0) {
                        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                        if (pcVar2 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258add;
                            uVar7 = (*pcVar2)();
                            *(undefined8 *)(puVar5 + 0xc) = uVar7;
                        }
                        if (*(int64_t *)(puVar5 + 0xc) != 0) {
                            return puVar5;
                        }
                        uVar7 = *(undefined8 *)(puVar5 + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258af4;
                        fcn.18026df60(uVar7);
                        goto code_r0x0001802589bd;
                    }
                }
            } else {
                if (*(int64_t *)(in_RCX + 10) != 0) {
                    *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a52;
                    iVar3 = fcn.180248230();
                    if (iVar3 == 0) goto code_r0x0001802589c1;
                }
                if (*(int64_t *)(in_RCX + 0xc) != 0) {
                    if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                    if (pcVar2 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a7f;
                        uVar7 = (*pcVar2)();
                        *(undefined8 *)(puVar5 + 0xc) = uVar7;
                    }
                    if (*(int64_t *)(puVar5 + 0xc) != 0) {
                        return puVar5;
                    }
                    uVar7 = *(undefined8 *)(puVar5 + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a96;
                    fcn.180264d30(uVar7);
                    goto code_r0x0001802589bd;
                }
            }
        } else {
            if (*(int64_t *)(in_RCX + 10) != 0) {
                *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589f8;
                iVar3 = fcn.180248230();
                if (iVar3 == 0) goto code_r0x0001802589c1;
            }
            if (*(int64_t *)(in_RCX + 0xc) != 0) {
                if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xd8);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a20;
                    uVar7 = (*pcVar2)();
                    *(undefined8 *)(puVar5 + 0xc) = uVar7;
                }
                if (*(int64_t *)(puVar5 + 0xc) != 0) {
                    return puVar5;
                }
                uVar7 = *(undefined8 *)(puVar5 + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a37;
                fcn.1802481d0(uVar7);
                goto code_r0x0001802589bd;
            }
        }
    } else {
        if (*(int64_t *)(in_RCX + 10) != 0) {
            *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258981;
            iVar3 = fcn.180248230();
            if (iVar3 == 0) goto code_r0x0001802589c1;
        }
        if (*(int64_t *)(in_RCX + 0xc) != 0) {
            if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x50);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589a6;
                uVar7 = (*pcVar2)();
                *(undefined8 *)(puVar5 + 0xc) = uVar7;
            }
            if (*(int64_t *)(puVar5 + 0xc) != 0) {
                return puVar5;
            }
            uVar7 = *(undefined8 *)(puVar5 + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589bd;
            fcn.180249610(uVar7);
code_r0x0001802589bd:
            *(undefined8 *)(puVar5 + 10) = 0;
            goto code_r0x0001802589c1;
        }
    }
    *(undefined8 *)(puVar5 + 0x1e) = *(undefined8 *)(in_RCX + 0x1e);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(in_RCX + 0x20);
    if (*(int64_t *)(in_RCX + 0x24) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b28;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x24) = *(undefined8 *)(in_RCX + 0x24);
    if (*(int64_t *)(in_RCX + 0x1e) == 0) {
        if (*puVar5 == 0) {
            iVar6 = *(int64_t *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)(in_RCX + 8);
            if (iVar6 == 0) {
                return puVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b76;
            iVar6 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar4));
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b89;
                iVar3 = fcn.180257ae0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
                if (iVar3 != 0) {
                    iVar6 = *(int64_t *)(puVar5 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b9a;
                    fcn.180257a00(iVar6);
                    *(undefined8 *)(puVar5 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                    return puVar5;
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258bc2;
        iVar3 = (*pcVar2)(puVar5, in_RCX);
        if (0 < iVar3) {
            return puVar5;
        }
    }
code_r0x0001802589c1:
    *(undefined8 *)(puVar5 + 0x1e) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589cd;
    fcn.180258be0(puVar5);
    return (uint32_t *)0x0;
}

// ============================================================
// Function: FUN_180258bb6
// Address: 0x180258bb6
// Size: 39 bytes
// ============================================================
uint32_t * fcn.180258850(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint32_t *puVar5;
    int64_t iVar6;
    undefined8 uVar7;
    uint32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18025885c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258873;
        iVar3 = fcn.18026b010(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025887c;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258894;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588a6;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            return (uint32_t *)0x0;
        }
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588ca;
    puVar5 = (uint32_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar4));
    if (puVar5 == (uint32_t *)0x0) {
        return (uint32_t *)0x0;
    }
    iVar6 = *(int64_t *)(in_RCX + 0x22);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802588f5;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x22) = *(undefined8 *)(in_RCX + 0x22);
    *puVar5 = *in_RCX;
    *(undefined8 *)(puVar5 + 2) = *(undefined8 *)(in_RCX + 2);
    *(undefined8 *)(puVar5 + 6) = *(undefined8 *)(in_RCX + 6);
    *(undefined8 *)(puVar5 + 4) = 0;
    if (*(int64_t *)(in_RCX + 4) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025893e;
        iVar6 = fcn.1802231e0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(int64_t *)(puVar5 + 4) = iVar6;
        if (iVar6 == 0) goto code_r0x0001802589c1;
    }
    puVar5[0x1d] = in_RCX[0x1d];
    if (*(int64_t *)(in_RCX + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18025895b;
        iVar3 = fcn.180257ae0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
        *(undefined8 *)(puVar5 + 8) = *(undefined8 *)(in_RCX + 8);
    }
    uVar1 = *in_RCX;
    if ((uVar1 >> 0xb & 1) == 0) {
        if ((uVar1 & 0xc1f0) == 0) {
            if ((uVar1 & 0x600) == 0) {
                if ((uVar1 & 0x3000) == 0) {
                    if ((uVar1 & 6) != 0) goto code_r0x0001802589c1;
                } else {
                    if (*(int64_t *)(in_RCX + 10) != 0) {
                        *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258ab4;
                        iVar3 = fcn.180248230();
                        if (iVar3 == 0) goto code_r0x0001802589c1;
                    }
                    if (*(int64_t *)(in_RCX + 0xc) != 0) {
                        if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                        if (pcVar2 != (code *)0x0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258add;
                            uVar7 = (*pcVar2)();
                            *(undefined8 *)(puVar5 + 0xc) = uVar7;
                        }
                        if (*(int64_t *)(puVar5 + 0xc) != 0) {
                            return puVar5;
                        }
                        uVar7 = *(undefined8 *)(puVar5 + 10);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258af4;
                        fcn.18026df60(uVar7);
                        goto code_r0x0001802589bd;
                    }
                }
            } else {
                if (*(int64_t *)(in_RCX + 10) != 0) {
                    *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a52;
                    iVar3 = fcn.180248230();
                    if (iVar3 == 0) goto code_r0x0001802589c1;
                }
                if (*(int64_t *)(in_RCX + 0xc) != 0) {
                    if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                    pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x58);
                    if (pcVar2 != (code *)0x0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a7f;
                        uVar7 = (*pcVar2)();
                        *(undefined8 *)(puVar5 + 0xc) = uVar7;
                    }
                    if (*(int64_t *)(puVar5 + 0xc) != 0) {
                        return puVar5;
                    }
                    uVar7 = *(undefined8 *)(puVar5 + 10);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a96;
                    fcn.180264d30(uVar7);
                    goto code_r0x0001802589bd;
                }
            }
        } else {
            if (*(int64_t *)(in_RCX + 10) != 0) {
                *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589f8;
                iVar3 = fcn.180248230();
                if (iVar3 == 0) goto code_r0x0001802589c1;
            }
            if (*(int64_t *)(in_RCX + 0xc) != 0) {
                if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
                pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xd8);
                if (pcVar2 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a20;
                    uVar7 = (*pcVar2)();
                    *(undefined8 *)(puVar5 + 0xc) = uVar7;
                }
                if (*(int64_t *)(puVar5 + 0xc) != 0) {
                    return puVar5;
                }
                uVar7 = *(undefined8 *)(puVar5 + 10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258a37;
                fcn.1802481d0(uVar7);
                goto code_r0x0001802589bd;
            }
        }
    } else {
        if (*(int64_t *)(in_RCX + 10) != 0) {
            *(int64_t *)(puVar5 + 10) = *(int64_t *)(in_RCX + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258981;
            iVar3 = fcn.180248230();
            if (iVar3 == 0) goto code_r0x0001802589c1;
        }
        if (*(int64_t *)(in_RCX + 0xc) != 0) {
            if (*(int64_t *)(in_RCX + 10) == 0) goto code_r0x0001802589c1;
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x50);
            if (pcVar2 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589a6;
                uVar7 = (*pcVar2)();
                *(undefined8 *)(puVar5 + 0xc) = uVar7;
            }
            if (*(int64_t *)(puVar5 + 0xc) != 0) {
                return puVar5;
            }
            uVar7 = *(undefined8 *)(puVar5 + 10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589bd;
            fcn.180249610(uVar7);
code_r0x0001802589bd:
            *(undefined8 *)(puVar5 + 10) = 0;
            goto code_r0x0001802589c1;
        }
    }
    *(undefined8 *)(puVar5 + 0x1e) = *(undefined8 *)(in_RCX + 0x1e);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(in_RCX + 0x20);
    if (*(int64_t *)(in_RCX + 0x24) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b28;
        iVar3 = fcn.1802308d0();
        if (iVar3 == 0) goto code_r0x0001802589c1;
    }
    *(undefined8 *)(puVar5 + 0x24) = *(undefined8 *)(in_RCX + 0x24);
    if (*(int64_t *)(in_RCX + 0x1e) == 0) {
        if (*puVar5 == 0) {
            iVar6 = *(int64_t *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)(in_RCX + 8);
            if (iVar6 == 0) {
                return puVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b76;
            iVar6 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000040 + iVar4), 
                                  *(int64_t *)(&stack0x000000a0 + iVar4));
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b89;
                iVar3 = fcn.180257ae0(*(undefined8 *)((int64_t)&arg_28h + iVar4));
                if (iVar3 != 0) {
                    iVar6 = *(int64_t *)(puVar5 + 8);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258b9a;
                    fcn.180257a00(iVar6);
                    *(undefined8 *)(puVar5 + 8) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                    return puVar5;
                }
            }
        }
    } else {
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180258bc2;
        iVar3 = (*pcVar2)(puVar5, in_RCX);
        if (0 < iVar3) {
            return puVar5;
        }
    }
code_r0x0001802589c1:
    *(undefined8 *)(puVar5 + 0x1e) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1802589cd;
    fcn.180258be0(puVar5);
    return (uint32_t *)0x0;
}

// ============================================================
// Function: FUN_180258be0
// Address: 0x180258be0
// Size: 214 bytes
// ============================================================
void fcn.180258be0(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t arg1_00;
    int64_t iVar3;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180258bf4;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        if ((*(int64_t *)(arg1 + 0x78) != 0) &&
           (pcVar1 = *(code **)(*(int64_t *)(arg1 + 0x78) + 0x18), pcVar1 != (code *)0x0)) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c0e;
            (*pcVar1)();
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c16;
        fcn.180259930(arg1);
        uVar2 = *(undefined8 *)(arg1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c2c;
        fcn.180224990(uVar2, 0x1804e6520, 0x5fd);
        uVar2 = *(undefined8 *)(arg1 + 0x38);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c42;
        fcn.180224990(uVar2, 0x1804e6520, 0x5fe);
        arg1_00 = *(int64_t *)(arg1 + 0x20);
        *(undefined8 *)(arg1 + 0x40) = 0;
        *(undefined8 *)(arg1 + 0x38) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c55;
        fcn.180257a00(arg1_00);
        uVar2 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c6b;
        fcn.180224990(uVar2, 0x1804e6520, 0x194);
        uVar2 = *(undefined8 *)(arg1 + 0x88);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c77;
        fcn.18022ecc0(uVar2);
        uVar2 = *(undefined8 *)(arg1 + 0x90);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c83;
        fcn.18022ecc0(uVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c8f;
        fcn.18026aee0(*(int64_t *)((int64_t)&iStackX_20 + iVar3));
        uVar2 = *(undefined8 *)(arg1 + 0xa8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258c9b;
        fcn.180255290(uVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180258cb0;
        fcn.180224990(arg1, 0x1804e6520, 0x19b);
    }
    return;
}

// ============================================================
// Function: FUN_180258cd0
// Address: 0x180258cd0
// Size: 248 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

code * fcn.180258cd0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h,
                    int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_80h
                    , int64_t arg_188h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    code *UNRECOVERED_JUMPTABLE_00;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint32_t *in_RCX;
    undefined8 uVar9;
    int64_t *in_RDX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int32_t var_74h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180258ce0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180258cee;
    iVar3 = func_0x000180259e70();
    if (iVar3 != 1) {
        if (iVar3 == 2) {
            uVar4 = *in_RCX;
            if (((((((uVar4 >> 0xb & 1) != 0) && (*(int64_t *)(in_RCX + 10) != 0)) &&
                  (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x68),
                  UNRECOVERED_JUMPTABLE_00 != (code *)0x0)) ||
                 ((((uVar4 & 0xc1f0) != 0 && (*(int64_t *)(in_RCX + 10) != 0)) &&
                  (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0xe0),
                  UNRECOVERED_JUMPTABLE_00 != (code *)0x0)))) ||
                ((((uVar4 & 0x600) != 0 && (*(int64_t *)(in_RCX + 10) != 0)) &&
                 (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x60),
                 UNRECOVERED_JUMPTABLE_00 != (code *)0x0)))) ||
               ((((uVar4 & 0x3000) != 0 && (*(int64_t *)(in_RCX + 10) != 0)) &&
                (UNRECOVERED_JUMPTABLE_00 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x60),
                UNRECOVERED_JUMPTABLE_00 != (code *)0x0)))) {
    // WARNING: Could not recover jumptable at 0x000180258d2b. Too many branches
    // WARNING: Treating indirect jump as call
                UNRECOVERED_JUMPTABLE_00 = (code *)(*UNRECOVERED_JUMPTABLE_00)(*(undefined8 *)(in_RCX + 0xc), in_RDX);
                return UNRECOVERED_JUMPTABLE_00;
            }
            if ((((uVar4 & 6) != 0) && (iVar6 = *(int64_t *)(in_RCX + 8), iVar6 != 0)) &&
               (*(int64_t *)(iVar6 + 0x70) != 0)) {
                uVar9 = *(undefined8 *)(in_RCX + 10);
                *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = 0x180257d8a;
                fcn.18045a350(iVar6, uVar9, in_RDX);
                UNRECOVERED_JUMPTABLE_00 = *(code **)(iVar6 + 0x70);
                if (UNRECOVERED_JUMPTABLE_00 != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180257da8. Too many branches
    // WARNING: Treating indirect jump as call
                    UNRECOVERED_JUMPTABLE_00 = (code *)(*UNRECOVERED_JUMPTABLE_00)(uVar9, in_RDX);
                    return UNRECOVERED_JUMPTABLE_00;
                }
                return UNRECOVERED_JUMPTABLE_00;
            }
        }
        return (code *)0x0;
    }
    uVar9 = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    uVar11 = *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + 8) = 0x1802a2c6a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = iVar6 + iVar5 + 0x18;
    if (*(int64_t *)(in_RCX + 8) != 0) {
        return (code *)0x0;
    }
    uVar10 = 1;
    *(undefined8 *)((int64_t)&arg_68h + iVar6 + iVar5) = uVar9;
    *(undefined8 *)((int64_t)&arg_40h + iVar6 + iVar5) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_38h + iVar6 + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar6 + iVar5) = uVar11;
    *(undefined8 *)((int64_t)&arg_28h + iVar6 + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + 0x10) = unaff_R13;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + 0x18 + -0x18) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_10 + iVar6 + iVar5 + -8) = 0x1802a2cdf;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)auStackX_10 + iVar6 + iVar5 + -0x10) =
         *(uint64_t *)0x1806a3940 ^ (int64_t)auStackX_10 + iVar7 + iVar2 + -0x18;
    uVar4 = *in_RCX;
    uVar1 = in_RCX[0x1d];
    *(int32_t *)((int64_t)&arg_40h + iVar7 + iVar2 + -0x18) = (int32_t)uVar10;
    if (uVar4 == 0) {
        uVar4 = 0xffffffff;
    }
    for (; (in_RDX != (int64_t *)0x0 && (iVar8 = *in_RDX, iVar8 != 0)); in_RDX = in_RDX + 5) {
        *(undefined8 *)((int64_t)&arg_70h + iVar7 + iVar2 + -0x18) = 0;
        *(undefined (*) [16])((int64_t)&arg_60h + iVar7 + iVar2 + -0x18) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&var_90h + iVar6 + iVar5) = ZEXT816(0);
        *(int32_t *)((int64_t)&var_88h + iVar6 + iVar5) = (int32_t)uVar10;
        *(undefined (*) [16])((int64_t)&var_80h + iVar6 + iVar5) = ZEXT816(0);
        UNRECOVERED_JUMPTABLE_00 = (code *)0x1802a2120;
        *(int32_t *)((int64_t)&arg_50h + iVar7 + iVar2 + -0x18) = (int32_t)uVar10;
        *(undefined (*) [16])((int64_t)&var_70h + iVar6 + iVar5) = ZEXT816(0);
        *(uint32_t *)((int64_t)&arg_58h + iVar7 + iVar2 + -0x18) = uVar1;
        *(undefined (*) [16])((int64_t)&var_60h + iVar6 + iVar5) = ZEXT816(0);
        *(uint32_t *)((int64_t)&arg_50h + iVar7 + iVar2 + -0x14) = uVar1;
        *(undefined (*) [16])((int64_t)&var_50h + iVar6 + iVar5) = ZEXT816(0);
        *(uint32_t *)((int64_t)&arg_58h + iVar7 + iVar2 + -0x14) = uVar4;
        *(undefined (*) [16])((int64_t)&var_40h + iVar6 + iVar5) = ZEXT816(0);
        *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar2 + -0x18) = iVar8;
        *(undefined (*) [16])((int64_t)&var_30h + iVar6 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&var_20h + iVar6 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&uStack_10 + iVar6 + iVar5) = ZEXT816(0);
        *(undefined (*) [16])((int64_t)&arg_80h + iVar7 + iVar2 + -0x18) = ZEXT816(0);
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2d97;
        iVar8 = func_0x0001802a33a0((int64_t)&arg_50h + iVar7 + iVar2 + -0x18);
        if (iVar8 != 0) {
            if (*(code **)(iVar8 + 0x38) != (code *)0x0) {
                UNRECOVERED_JUMPTABLE_00 = *(code **)(iVar8 + 0x38);
            }
            *(undefined4 *)((int64_t)&var_88h + iVar6 + iVar5 + 4) = *(undefined4 *)(iVar8 + 0x10);
        }
        *(uint32_t **)((int64_t)&var_90h + iVar6 + iVar5) = in_RCX;
        *(int64_t **)((int64_t)&var_60h + iVar6 + iVar5) = in_RDX;
        *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2dc6;
        iVar3 = (*UNRECOVERED_JUMPTABLE_00)(7, iVar8, (int64_t)&var_90h + iVar6 + iVar5);
        if (iVar3 < 1) {
code_r0x0001802a2df6:
            if (-1 < iVar3) goto code_r0x0001802a2dfa;
        } else {
            if (*(int32_t *)((int64_t)&var_88h + iVar6 + iVar5) != 0) {
                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar2 + -0x18) =
                     *(undefined8 *)((int64_t)&var_70h + iVar6 + iVar5);
                *(undefined4 *)((int64_t)&arg_30h + iVar7 + iVar2 + -0x18) =
                     *(undefined4 *)((int64_t)&var_74h + iVar6 + iVar5);
                *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2df4;
                iVar3 = fcn.180258740(*(int64_t *)((int64_t)&arg_50h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_68h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_70h + iVar7 + iVar2 + -0x18), 
                                      *(int64_t *)((int64_t)&arg_78h + iVar7 + iVar2 + -0x18));
                goto code_r0x0001802a2df6;
            }
code_r0x0001802a2dfa:
            *(int32_t *)((int64_t)&var_74h + iVar6 + iVar5) = iVar3;
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2e0b;
            (*UNRECOVERED_JUMPTABLE_00)(8, iVar8, (int64_t)&var_90h + iVar6 + iVar5);
            iVar3 = *(int32_t *)((int64_t)&var_74h + iVar6 + iVar5);
        }
        iVar8 = *(int64_t *)((int64_t)&var_18h + iVar6 + iVar5);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2e29;
            fcn.180224990(iVar8, 0x1804f0ed0, 0x2cd);
        }
        if (iVar3 < 1) break;
        uVar10 = (uint64_t)*(uint32_t *)((int64_t)&arg_40h + iVar7 + iVar2 + -0x18);
    }
    uVar10 = *(uint64_t *)((int64_t)auStackX_10 + iVar6 + iVar5 + -0x10);
    *(undefined8 *)((int64_t)auStackX_10 + iVar7 + iVar2 + -0x20) = 0x1802a2e4c;
    UNRECOVERED_JUMPTABLE_00 = (code *)func_0x000180459870(uVar10 ^ (int64_t)auStackX_10 + iVar7 + iVar2 + -0x18);
    return UNRECOVERED_JUMPTABLE_00;
}

// ============================================================
// Function: FUN_180258dd0
// Address: 0x180258dd0
// Size: 422 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_e9h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_f1h
// WARNING: [rz-ghidra] Detected overlap for variable arg_f5h
// WARNING: [rz-ghidra] Detected overlap for variable arg_f7h
// WARNING: [rz-ghidra] Detected overlap for variable arg_a9h
// WARNING: [rz-ghidra] Removing arg arg_b9h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_c9h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_54h
// WARNING: [rz-ghidra] Detected overlap for variable arg_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h

void fcn.180258dd0(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_50h, int64_t arg_60h, int64_t arg_70h,
                  int64_t arg_78h, int64_t arg_a8h, int64_t arg_f8h, int64_t arg_128h)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    uint32_t *in_RCX;
    int64_t *in_RDX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180258de0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(uint64_t *)((int64_t)&arg_f8h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6);
    *(undefined *)((int64_t)&arg_a8h + iVar6) = 0;
    *(undefined8 *)(&stack0x000000e9 + iVar6) = 0;
    *(undefined4 *)(&stack0x000000f1 + iVar6) = 0;
    *(undefined2 *)(&stack0x000000f5 + iVar6) = 0;
    (&stack0x000000f7)[iVar6] = 0;
    *(undefined (*) [16])((int64_t)&arg_a8h + iVar6 + 1) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000000b9 + iVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000000c9 + iVar6) = ZEXT816(0);
    *(undefined (*) [16])(&stack0x000000d9 + iVar6) = ZEXT816(0);
    if ((in_RCX == (uint32_t *)0x0) || ((*in_RCX & 0xc1f0) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258f26;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258f3e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258f50;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    } else if (*(int64_t *)(in_RCX + 0xc) == 0) {
        *(int64_t **)((int64_t)&var_20h + iVar6) = in_RDX;
        *(undefined4 *)((int64_t)&var_18h + iVar6) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258e80;
        fcn.180258740(*(int64_t *)((int64_t)&arg_38h + iVar6), *(int64_t *)(&stack0x00000040 + iVar6), 
                      *(int64_t *)((int64_t)&arg_48h + iVar6), *(int64_t *)((int64_t)&arg_50h + iVar6), 
                      *(int64_t *)(&stack0x00000058 + iVar6), *(int64_t *)((int64_t)&arg_60h + iVar6));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258ea7;
        puVar7 = (undefined4 *)
                 func_0x000180229e30((int64_t)&arg_78h + iVar6, 0x1804af254, (int64_t)&arg_a8h + iVar6, 0x50);
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)((int64_t)&arg_28h + iVar6) = *puVar7;
        *(undefined4 *)((int64_t)&arg_28h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000030 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x00000034 + iVar6) = uVar4;
        uVar2 = puVar7[5];
        uVar3 = puVar7[6];
        uVar4 = puVar7[7];
        *(undefined4 *)((int64_t)&arg_38h + iVar6) = puVar7[4];
        *(undefined4 *)((int64_t)&arg_38h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000040 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x00000044 + iVar6) = uVar4;
        *(undefined8 *)((int64_t)&arg_48h + iVar6) = *(undefined8 *)(puVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258ed0;
        puVar7 = (undefined4 *)func_0x000180229ba0((int64_t)&arg_78h + iVar6);
        uVar2 = puVar7[1];
        uVar3 = puVar7[2];
        uVar4 = puVar7[3];
        *(undefined4 *)((int64_t)&arg_50h + iVar6) = *puVar7;
        *(undefined4 *)((int64_t)&arg_50h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000058 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x0000005c + iVar6) = uVar4;
        uVar2 = puVar7[5];
        uVar3 = puVar7[6];
        uVar4 = puVar7[7];
        *(undefined4 *)((int64_t)&arg_60h + iVar6) = puVar7[4];
        *(undefined4 *)((int64_t)&arg_60h + iVar6 + 4) = uVar2;
        *(undefined4 *)(&stack0x00000068 + iVar6) = uVar3;
        *(undefined4 *)(&stack0x0000006c + iVar6) = uVar4;
        *(undefined8 *)((int64_t)&arg_70h + iVar6) = *(undefined8 *)(puVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258ef9;
        iVar5 = fcn.180258cd0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)(&stack0x00000030 + iVar6), 
                              *(int64_t *)(&stack0x00000040 + iVar6), *(int64_t *)((int64_t)&arg_48h + iVar6), 
                              *(int64_t *)((int64_t)&arg_50h + iVar6), *(int64_t *)(&stack0x00000058 + iVar6), 
                              *(int64_t *)((int64_t)&arg_60h + iVar6), *(int64_t *)(&stack0x00000068 + iVar6), 
                              *(int64_t *)((int64_t)&arg_70h + iVar6), *(int64_t *)(&stack0x00000178 + iVar6));
        if (iVar5 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258f0e;
            iVar8 = func_0x00018022e3d0(uVar1, (int64_t)&arg_a8h + iVar6);
            if (iVar8 != 0) {
                *in_RDX = iVar8;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180258f65;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_f8h + iVar6) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180258f80
// Address: 0x180258f80
// Size: 296 bytes
// ============================================================
undefined8 fcn.180258f80(uint32_t *param_1)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x180258f8c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    uVar1 = *param_1;
    if ((((uVar1 >> 0xb & 1) != 0) && (*(int64_t *)(param_1 + 10) != 0)) &&
       (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0x70) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180258faf;
        uVar3 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180258fb7;
        uVar3 = fcn.18027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x000180258fcb. Too many branches
    // WARNING: Treating indirect jump as call
        uVar3 = (**(code **)(*(int64_t *)(param_1 + 10) + 0x70))
                          (*(undefined8 *)(param_1 + 0xc), uVar3, *(code **)(*(int64_t *)(param_1 + 10) + 0x70));
        return uVar3;
    }
    if ((((uVar1 & 0xc1f0) != 0) && (*(int64_t *)(param_1 + 10) != 0)) &&
       (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0xe8) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180258fed;
        uVar3 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180258ff5;
        uVar3 = fcn.18027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x00018025900c. Too many branches
    // WARNING: Treating indirect jump as call
        uVar3 = (**(code **)(*(int64_t *)(param_1 + 10) + 0xe8))
                          (*(undefined8 *)(param_1 + 0xc), uVar3, *(code **)(*(int64_t *)(param_1 + 10) + 0xe8));
        return uVar3;
    }
    if ((((uVar1 & 0x600) == 0) || (*(int64_t *)(param_1 + 10) == 0)) ||
       (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0x68) == 0)) {
        if ((((uVar1 & 0x3000) == 0) || (*(int64_t *)(param_1 + 10) == 0)) ||
           (*(int64_t *)(*(int64_t *)(param_1 + 10) + 0x68) == 0)) {
            if ((((uVar1 & 6) != 0) && (*(int64_t *)(param_1 + 8) != 0)) &&
               (*(int64_t *)(*(int64_t *)(param_1 + 8) + 0x78) != 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259081;
                uVar3 = func_0x0001801dd170();
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259089;
                uVar3 = fcn.18027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x00018025909d. Too many branches
    // WARNING: Treating indirect jump as call
                uVar3 = (**(code **)(*(int64_t *)(param_1 + 8) + 0x78))
                                  (*(undefined8 *)(param_1 + 10), uVar3, *(code **)(*(int64_t *)(param_1 + 8) + 0x78));
                return uVar3;
            }
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259066;
        uVar3 = func_0x00018021eaf0();
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18025902b;
        uVar3 = func_0x00018021eaf0();
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180259033;
    uVar3 = fcn.18027e810(uVar3);
    // WARNING: Could not recover jumptable at 0x000180259047. Too many branches
    // WARNING: Treating indirect jump as call
    uVar3 = (**(code **)(*(int64_t *)(param_1 + 10) + 0x68))
                      (*(undefined8 *)(param_1 + 0xc), uVar3, *(code **)(*(int64_t *)(param_1 + 10) + 0x68));
    return uVar3;
}

// ============================================================
// Function: FUN_1802590b0
// Address: 0x1802590b0
// Size: 64 bytes
// ============================================================
bool fcn.1802590b0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802590bc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar4 = *(int64_t *)(param_1 + 0x20);
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802590d3;
        iVar1 = fcn.1802314f0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)(&stack0x00000040 + iVar3), *(int64_t *)(&stack0x00000070 + iVar3));
        return **(int32_t **)(param_1 + 0x78) == iVar1;
    }
    *(undefined8 *)((int64_t)aiStackX_18 + iVar3) = 0x180257a6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar2 + iVar3) = 0x180257a84;
        iVar1 = fcn.180280ea0(*(int64_t *)(&stack0x00000040 + iVar2 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar2 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar2 + iVar3), 
                              *(int64_t *)(&stack0x00000058 + iVar2 + iVar3));
        if (iVar1 != 0) {
            return true;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1802590f0
// Address: 0x1802590f0
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802590f0(int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180259105;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_R9 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025911d;
        iVar2 = fcn.18022e160(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
        if (iVar2 != 0) {
            *(int64_t *)((int64_t)&var_20h + iVar1) = iVar2;
            *(undefined4 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180259142;
            uVar3 = fcn.180258740(*(int64_t *)((int64_t)&arg_38h + iVar1), *(int64_t *)((int64_t)&arg_40h + iVar1), 
                                  *(int64_t *)(&stack0x00000048 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                                  *(int64_t *)(&stack0x00000058 + iVar1), *(int64_t *)(&stack0x00000060 + iVar1));
            return uVar3;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180259157;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18025916f;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                  *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180259181;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar1));
    return 0;
}

