// Chunk 132 - 50 functions

// ============================================================
// Function: FUN_1801c393b
// Address: 0x1801c393b
// Size: 125 bytes
// ============================================================
undefined8 fcn.1801c393b(int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    
    fcn.18022ecc0();
    *(undefined8 *)(unaff_RBX + 0x308) = unaff_RBP;
    fcn.1801dada0();
    fcn.180224990(*(undefined8 *)(unaff_RBX + 0x4b8), 0x1804b3080, 0xda7);
    fcn.180224990(*(undefined8 *)(unaff_RBX + 0x4c8), 0x1804b3080, 0xda8);
    uVar1 = *(uint32_t *)(unaff_RBX + 0x160);
    fcn.1804986e0(unaff_RBX + 0x164, 0, 0x38c);
    *(uint32_t *)(unaff_RBX + 0x160) = uVar1 & 0x6000;
    iVar2 = fcn.180197630();
    if (iVar2 != 0) {
        *(undefined4 *)(unaff_RBX + 0x48) = 0x300;
        fcn.180224990(*(undefined8 *)(unaff_RBX + 0xb00), 0x1804b3080, 0xdb8);
        *(undefined8 *)(unaff_RBX + 0xb00) = unaff_RBP;
        *(undefined8 *)(unaff_RBX + 0xb08) = unaff_RBP;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c39b8
// Address: 0x1801c39b8
// Size: 75 bytes
// ============================================================
undefined8 fcn.1801c393b(int64_t arg_38h, int64_t arg_40h)
{
    uint32_t uVar1;
    int32_t iVar2;
    int64_t unaff_RBX;
    undefined8 unaff_RBP;
    
    fcn.18022ecc0();
    *(undefined8 *)(unaff_RBX + 0x308) = unaff_RBP;
    fcn.1801dada0();
    fcn.180224990(*(undefined8 *)(unaff_RBX + 0x4b8), 0x1804b3080, 0xda7);
    fcn.180224990(*(undefined8 *)(unaff_RBX + 0x4c8), 0x1804b3080, 0xda8);
    uVar1 = *(uint32_t *)(unaff_RBX + 0x160);
    fcn.1804986e0(unaff_RBX + 0x164, 0, 0x38c);
    *(uint32_t *)(unaff_RBX + 0x160) = uVar1 & 0x6000;
    iVar2 = fcn.180197630();
    if (iVar2 != 0) {
        *(undefined4 *)(unaff_RBX + 0x48) = 0x300;
        fcn.180224990(*(undefined8 *)(unaff_RBX + 0xb00), 0x1804b3080, 0xdb8);
        *(undefined8 *)(unaff_RBX + 0xb00) = unaff_RBP;
        *(undefined8 *)(unaff_RBX + 0xb08) = unaff_RBP;
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c3a10
// Address: 0x1801c3a10
// Size: 2865 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

uint64_t fcn.1801c3a10(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined2 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    uint16_t uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    int32_t *piVar8;
    int64_t iVar9;
    int32_t *in_RCX;
    undefined4 in_EDX;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t in_R8;
    int64_t *in_R9;
    undefined8 uVar12;
    int64_t iVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    int64_t var_28h;
    
    uStack_30 = 0x1801c3a2c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar10 = 0;
    iVar6 = (int32_t)in_R8;
    iVar13 = (int64_t)iVar6;
    uVar11 = 0;
    if (in_RCX == (int32_t *)0x0) goto code_r0x0001801c3b04;
    if (*in_RCX != 0) {
        if ((char)*in_RCX < '\0') {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3a65;
            piVar8 = (int32_t *)func_0x0001801bda50();
            *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
            if (piVar8 != (int32_t *)0x0) goto code_r0x0001801c3a76;
        }
        goto code_r0x0001801c3b04;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    piVar8 = in_RCX;
code_r0x0001801c3a76:
    // switch table (141 cases) at 0x1801c43e8
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3ada;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            goto code_r0x0001801c3ae6;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b28;
        iVar13 = func_0x0001801bc7c0(in_R9);
        if (iVar13 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b35;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b4d;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7));
            goto code_r0x0001801c3af7;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b5f;
        iVar6 = func_0x000180194310(in_RCX, iVar13);
        if (iVar6 != 0) goto code_r0x0001801c3b9f;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b6b;
        fcn.18022ecc0(iVar13);
        goto code_r0x0001801c3b04;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&var_8h + iVar7) = in_R9;
            *(int32_t **)(&stack0x00000000 + iVar7) = piVar8 + 0x2ae;
            *(int32_t **)(&stack0xfffffffffffffff8 + iVar7) = piVar8 + 0x2b0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3c02;
            uVar11 = func_0x0001801bc970(piVar8 + 0x2a4, piVar8 + 0x2a2, piVar8 + 0x2ac, piVar8 + 0x2aa);
            return uVar11;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3bb3;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
code_r0x0001801c3ae6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3af2;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        goto code_r0x0001801c3af7;
    case 6:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b72;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b8a;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar7));
        goto code_r0x0001801c3af7;
    case 10:
        uVar11 = (uint64_t)(uint32_t)piVar8[0x75];
        break;
    case 0xb:
        uVar11 = (uint64_t)(uint32_t)piVar8[0x75];
        piVar8[0x75] = 0;
        break;
    case 0xc:
        uVar11 = (uint64_t)(uint32_t)piVar8[0x74];
        break;
    case 0xd:
        uVar11 = (uint64_t)(uint32_t)piVar8[0x58];
        break;
    case 0x10:
        *(int64_t **)(piVar8 + 0x140) = in_R9;
        uVar11 = 1;
        break;
    case 0x37:
        if (iVar6 == 0) {
            uVar12 = *(undefined8 *)(piVar8 + 0x286);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3c29;
            fcn.180224990(uVar12, 0x1804b3080, 0xe23);
            *(undefined8 *)(piVar8 + 0x286) = 0;
            if (in_R9 == (int64_t *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3c46;
            iVar13 = func_0x000180498cd0(in_R9);
            if (iVar13 - 1U < 0xff) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3c66;
                iVar13 = func_0x0001802231e0(in_R9, 0x1804b3080, 0xe2e);
                *(int64_t *)(piVar8 + 0x286) = iVar13;
                if (iVar13 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3c7b;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3c93;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                              *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar7));
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3ca2;
                fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3cba;
                fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                              *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar7));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3cc9;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3ce1;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                          *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                          *(int64_t *)(&stack0x00000028 + iVar7));
        }
code_r0x0001801c3af7:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3b04;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_18h + iVar7));
        goto code_r0x0001801c3b04;
    case 0x39:
        *(int64_t **)(piVar8 + 0x284) = in_R9;
        uVar11 = 1;
        break;
    case 0x41:
        piVar8[0x288] = iVar6;
        uVar11 = 1;
        break;
    case 0x42:
        uVar11 = 1;
        *in_R9 = *(int64_t *)(piVar8 + 0x290);
        break;
    case 0x43:
        *(int64_t **)(piVar8 + 0x290) = in_R9;
        uVar11 = 1;
        break;
    case 0x44:
        *in_R9 = *(int64_t *)(piVar8 + 0x28e);
        uVar11 = 1;
        break;
    case 0x45:
        *(int64_t **)(piVar8 + 0x28e) = in_R9;
        uVar11 = 1;
        break;
    case 0x46:
        *in_R9 = 0;
        uVar12 = *(undefined8 *)(piVar8 + 0x296);
        uVar11 = 0xffffffff;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3d86;
        iVar13 = func_0x000180222340(uVar12, 0);
        if (iVar13 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3d98;
            uVar5 = func_0x00018023f2c0(iVar13, (int64_t)&arg_48h + iVar7);
            if (0 < (int32_t)uVar5) {
                uVar12 = *(undefined8 *)(piVar8 + 0x292);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3db8;
                fcn.180224990(uVar12, 0x1804b3080, 0xe64);
                *(undefined8 *)(piVar8 + 0x292) = *(undefined8 *)((int64_t)&arg_48h + iVar7);
                *in_R9 = *(int64_t *)((int64_t)&arg_48h + iVar7);
                uVar11 = (uint64_t)uVar5;
                *(int64_t *)(piVar8 + 0x294) = (int64_t)(int32_t)uVar5;
            }
        }
        break;
    case 0x47:
        iVar13 = *(int64_t *)(piVar8 + 0x292);
        if (iVar13 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3dff;
            fcn.180224990(iVar13, 0x1804b3080, 0xe75);
            *(undefined8 *)(piVar8 + 0x292) = 0;
            *(undefined8 *)(piVar8 + 0x294) = 0;
        }
        uVar12 = *(undefined8 *)(piVar8 + 0x296);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3e20;
        func_0x000180222290(uVar12, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3e2f;
        fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000030 + iVar7));
        *(undefined8 *)(piVar8 + 0x296) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3e48;
        uVar12 = func_0x000180221f60(0, 1);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3e57;
        iVar13 = func_0x000180222290(uVar12, 0x180196ec0);
        *(int64_t *)(piVar8 + 0x296) = iVar13;
        if (iVar13 != 0) {
            *(int64_t **)((int64_t)&arg_48h + iVar7) = in_R9;
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3e7b;
            iVar13 = func_0x00018023f280(0, (int64_t)&arg_48h + iVar7, in_R8 & 0xffffffff);
            if (iVar13 == 0) {
                return 1;
            }
            uVar12 = *(undefined8 *)(piVar8 + 0x296);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3e93;
            func_0x000180222110(uVar12, iVar13);
            return 1;
        }
        goto code_r0x0001801c3b04;
    case 0x58:
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3f34;
            uVar11 = func_0x0001801a2320(piVar8, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3f2a;
            uVar11 = func_0x0001801a2430();
        }
        break;
    case 0x59:
        if (iVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3f55;
            uVar11 = func_0x0001801a17b0(piVar8, 0, in_R9);
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3f4b;
            uVar11 = func_0x0001801a1880();
        }
        break;
    case 0x5a:
        if (*(int64_t *)(piVar8 + 0x23e) != 0) {
            iVar13 = *(int64_t *)(piVar8 + 0x2a8);
            uVar11 = *(uint64_t *)(piVar8 + 0x2a6);
            if ((in_R9 != (int64_t *)0x0) && (uVar11 != 0)) {
                do {
                    uVar1 = *(undefined2 *)(iVar13 + uVar10 * 2);
                    uVar12 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c402e;
                    iVar9 = func_0x0001801ab700(uVar12, uVar1);
                    if (iVar9 == 0) {
                        uVar5 = *(uint16_t *)(iVar13 + uVar10 * 2) | 0x1000000;
                    } else {
                        uVar1 = *(undefined2 *)(iVar9 + 0x1c);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c403e;
                        uVar5 = func_0x0001801ab6c0(uVar1, 1);
                    }
                    *(uint32_t *)((int64_t)in_R9 + uVar10 * 4) = uVar5;
                    uVar10 = uVar10 + 1;
                } while (uVar10 < uVar11);
            }
            return uVar11 & 0xffffffff;
        }
        goto code_r0x0001801c3b04;
    case 0x5b:
        *(int64_t *)((int64_t)&var_10h + iVar7) = iVar13;
        *(int64_t **)((int64_t)&var_8h + iVar7) = in_R9;
        *(int32_t **)(&stack0x00000000 + iVar7) = piVar8 + 0x2ae;
        *(int32_t **)(&stack0xfffffffffffffff8 + iVar7) = piVar8 + 0x2b0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c409e;
        uVar11 = func_0x0001801abb30(piVar8 + 0x2a4, piVar8 + 0x2a2, piVar8 + 0x2ac, piVar8 + 0x2aa);
        break;
    case 0x5c:
        *(int64_t **)((int64_t)&var_10h + iVar7) = in_R9;
        *(int32_t **)((int64_t)&var_8h + iVar7) = piVar8 + 0x2ae;
        *(int32_t **)(&stack0x00000000 + iVar7) = piVar8 + 0x2b0;
        uVar12 = *(undefined8 *)(in_RCX + 2);
        *(int32_t **)(&stack0xfffffffffffffff8 + iVar7) = piVar8 + 0x2aa;
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c40ea;
        uVar11 = func_0x0001801abdc0(uVar12, piVar8 + 0x2a4, piVar8 + 0x2a2, piVar8 + 0x2ac);
        break;
    case 0x5d:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c40fa;
        uVar4 = func_0x0001801ac8f0(piVar8, in_R8 & 0xffffffff);
        if (iVar6 == -1) {
            uVar11 = (uint64_t)uVar4;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c410d;
            uVar11 = func_0x0001801ab6c0(uVar4, 1);
        }
        break;
    case 0x61:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c419a;
        uVar11 = func_0x0001801ac640(uVar12, in_R9, iVar13, 0);
        break;
    case 0x62:
        uVar12 = 0;
        goto code_r0x0001801c41a2;
    case 0x65:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c41d2;
        uVar11 = func_0x0001801ac640(uVar12, in_R9, iVar13, 1);
        break;
    case 0x66:
        uVar12 = 1;
code_r0x0001801c41a2:
        uVar2 = *(undefined8 *)(piVar8 + 0x21e);
        uVar3 = *(undefined8 *)(in_RCX + 2);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c41b5;
        uVar11 = func_0x0001801ac780(uVar3, uVar2, in_R9, uVar12);
        break;
    case 0x67:
        if ((piVar8[0x1e] == 0) && (piVar8[0xd0] != 0)) {
            if (in_R9 != (int64_t *)0x0) {
                *in_R9 = *(int64_t *)(piVar8 + 0xd2);
            }
            return (uint64_t)(uint32_t)piVar8[0xd4];
        }
        goto code_r0x0001801c3b04;
    case 0x68:
        if (piVar8[0x1e] != 0) {
            uVar12 = *(undefined8 *)(piVar8 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4229;
            uVar11 = func_0x0001801c5900(uVar12, in_R9, iVar13);
            return uVar11;
        }
        goto code_r0x0001801c3b04;
    case 0x69:
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c423b;
        uVar11 = func_0x0001801a1400(piVar8, 0, in_R8 & 0xffffffff);
        break;
    case 0x6a:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4255;
        uVar11 = func_0x0001801a24c0(uVar12, in_R9, 0, in_R8 & 0xffffffff);
        break;
    case 0x6b:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4272;
        uVar11 = func_0x0001801a24c0(uVar12, in_R9, 1, in_R8 & 0xffffffff);
        break;
    case 0x6c:
        iVar7 = *(int64_t *)(piVar8 + 0x100);
        goto code_r0x0001801c42d8;
    case 0x6d:
        if ((*(int64_t *)(piVar8 + 0x23e) != 0) && (*(int64_t *)(piVar8 + 0x138) != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4344;
            iVar6 = func_0x0001802308d0();
            if (iVar6 != 0) {
                *in_R9 = *(int64_t *)(piVar8 + 0x138);
                return 1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x6f:
        if (*(int64_t *)(piVar8 + 0x2a0) != 0) {
            *in_R9 = *(int64_t *)(piVar8 + 0x2a0);
            return (uint64_t)(uint32_t)piVar8[0x29e];
        }
        goto code_r0x0001801c3b04;
    case 0x73:
        *in_R9 = *(int64_t *)(**(int64_t **)(piVar8 + 0x21e) + 0x10);
        uVar11 = 1;
        break;
    case 0x74:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3f86;
        uVar11 = func_0x0001801a2260(uVar12, in_R9);
        break;
    case 0x75:
        if (iVar6 != 3) {
            uVar12 = *(undefined8 *)(piVar8 + 0x21e);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3fed;
            uVar11 = func_0x0001801a2550(uVar12, in_R8 & 0xffffffff);
            return uVar11;
        }
        if ((piVar8[0x1e] != 0) && (*(int64_t *)(piVar8 + 0xc0) != 0)) {
            if ((*(uint8_t *)(*(int64_t *)(piVar8 + 0xc0) + 0x20) & 0x44) != 0) {
                return 2;
            }
            if (*(int64_t *)(piVar8 + 0xf6) != 0) {
                **(int64_t **)(piVar8 + 0x21e) = *(int64_t *)(piVar8 + 0xf6);
                return 1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x76:
        *(int32_t *)(*(int64_t *)(piVar8 + 0x21e) + 0x18) = iVar6;
code_r0x0001801c3b9f:
        uVar11 = 1;
        break;
    case 0x7f:
        uVar11 = (uint64_t)(uint32_t)piVar8[0x288];
        break;
    case 0x84:
        iVar7 = *(int64_t *)(piVar8 + 0xf4);
code_r0x0001801c42d8:
        if (iVar7 != 0) {
            *(undefined4 *)in_R9 = *(undefined4 *)(iVar7 + 0x14);
            return 1;
        }
        goto code_r0x0001801c3b04;
    case 0x85:
        if ((*(int64_t *)(piVar8 + 0x23e) != 0) && (*(int64_t *)(piVar8 + 0xc2) != 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4382;
            iVar6 = func_0x0001802308d0();
            if (iVar6 != 0) {
                *in_R9 = *(int64_t *)(piVar8 + 0xc2);
                return 1;
            }
        }
        goto code_r0x0001801c3b04;
    case 0x86:
        if (((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(piVar8 + 6) + 0x36) + 0x50) & 8) == 0) &&
             (iVar6 = **(int32_t **)(piVar8 + 6), 0x303 < iVar6)) && (iVar6 != 0x10000)) &&
           (*(char *)((int64_t)piVar8 + 0x4dd) != '\0')) {
            uVar1 = *(undefined2 *)((int64_t)piVar8 + 0x4de);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4158;
            uVar11 = func_0x0001801ab6c0(uVar1, 1);
        } else {
            if (*(int64_t *)(piVar8 + 0x23e) != 0) {
                uVar10 = (uint64_t)*(uint32_t *)(*(int64_t *)(piVar8 + 0x23e) + 0x304);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c417e;
            uVar11 = func_0x0001801ab6c0(uVar10 & 0xffff, 1);
        }
        break;
    case 0x87:
        if (in_R9 != (int64_t *)0x0) {
            *in_R9 = *(int64_t *)(piVar8 + 0x2a8);
        }
        uVar11 = (uint64_t)(uint32_t)piVar8[0x2a6];
        break;
    case 0x89:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c4289;
        uVar11 = func_0x0001801a1fc0(uVar12, in_R9, 0);
        break;
    case 0x8a:
        uVar12 = *(undefined8 *)(piVar8 + 0x21e);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c42a3;
        uVar11 = func_0x0001801a1fc0(uVar12, in_R9, 1);
        break;
    case 0x8c:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar8 + 0xf4) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar8 + 0xf4);
            return 1;
        }
        goto code_r0x0001801c3b04;
    case 0x8d:
        if ((in_R9 != (int64_t *)0x0) && (*(int64_t **)(piVar8 + 0x100) != (int64_t *)0x0)) {
            *in_R9 = **(int64_t **)(piVar8 + 0x100);
            return 1;
        }
code_r0x0001801c3b04:
        uVar11 = 0;
        break;
    case 0x8e:
        *in_R9 = *(int64_t *)(piVar8 + 0x296);
        uVar12 = *(undefined8 *)(piVar8 + 0x296);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3eb0;
        uVar11 = func_0x000180222010(uVar12);
        break;
    case 0x8f:
        iVar13 = *(int64_t *)(piVar8 + 0x292);
        if (iVar13 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3ed5;
            fcn.180224990(iVar13, 0x1804b3080, 0xe9b);
            *(undefined8 *)(piVar8 + 0x292) = 0;
            *(undefined8 *)(piVar8 + 0x294) = 0;
        }
        uVar12 = *(undefined8 *)(piVar8 + 0x296);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3ef6;
        func_0x000180222290(uVar12, 0x180196ec0);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801c3f05;
        fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                      *(int64_t *)((int64_t)&var_8h + iVar7), *(int64_t *)((int64_t)&var_10h + iVar7), 
                      *(int64_t *)(&stack0x00000030 + iVar7));
        *(int64_t **)(piVar8 + 0x296) = in_R9;
        uVar11 = 1;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c4670
// Address: 0x1801c4670
// Size: 2193 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801a247b: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801a2480)
// WARNING: Removing unreachable block (ram,0x0001801a249e)
// WARNING: Removing unreachable block (ram,0x0001801a2484)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.1801c4670(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a0h,
                      int64_t arg_a8h, int64_t arg_b0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_128h, int64_t arg_190h, int64_t arg_1f0h)
{
    int32_t *piVar1;
    int32_t iVar2;
    bool bVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t iVar11;
    int64_t *piVar12;
    undefined2 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t **ppiVar17;
    int64_t *piVar18;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t *piVar19;
    uint64_t uVar20;
    int32_t iVar21;
    int64_t iVar22;
    undefined *puVar23;
    undefined8 unaff_RBP;
    int64_t unaff_RSI;
    undefined8 uVar24;
    uint32_t in_R8D;
    uint64_t uVar25;
    int64_t *in_R9;
    undefined2 *puVar26;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    code *pcStack_10;
    
    pcStack_10 = (code *)0x1801c4680;
    iVar15 = fcn.18045a350();
    iVar15 = -iVar15;
    // switch table (137 cases) at 0x1801c4de4
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c46bc;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
            goto code_r0x0001801c46c8;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c46fb;
        iVar9 = fcn.1801bc7c0(*(int64_t *)((int64_t)&var_18h + iVar15));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4732;
            iVar7 = fcn.180192b80(*(int64_t *)((int64_t)&arg_28h + iVar15));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4742;
                fcn.18022ecc0(iVar9);
                return 0;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4708;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4720;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_28h + iVar15) = in_R9;
            *(int64_t *)((int64_t)&var_20h + iVar15) = in_RCX + 0x2b0;
            *(int64_t *)((int64_t)&var_18h + iVar15) = in_RCX + 0x2b8;
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c47ea;
            uVar16 = fcn.1801bc970(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar15), *(int64_t *)((int64_t)&arg_50h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_58h + iVar15), *(int64_t *)((int64_t)&arg_68h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar15), *(int64_t *)((int64_t)&arg_78h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_80h + iVar15));
            return uVar16;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c479b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
code_r0x0001801c46c8:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c46d4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    default:
        goto code_r0x0001801c46e6;
    case 6:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4754;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c476c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0xe:
        iVar9 = *(int64_t *)(in_RCX + 0x110);
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cb3;
            iVar9 = fcn.180221f20();
            *(int64_t *)(in_RCX + 0x110) = iVar9;
            if (iVar9 != 0) goto code_r0x0001801c4ce6;
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cc4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        } else {
code_r0x0001801c4ce6:
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cf1;
            iVar7 = fcn.180222110(iVar9, in_R9);
            if (iVar7 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cdc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x36:
        *(int64_t **)(in_RCX + 0x238) = in_R9;
        return 1;
    case 0x3a:
    case 0x3b:
        if (in_R9 == (int64_t *)0x0) {
            return 0x50;
        }
        if (in_R8D == 0x50) {
            if (in_EDX == 0x3b) {
                iVar7 = *(int32_t *)((int64_t)in_R9 + 4);
                iVar21 = *(int32_t *)(in_R9 + 1);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0xc);
                piVar1 = *(int32_t **)(in_RCX + 0x250);
                *(int32_t *)(in_RCX + 0x240) = *(int32_t *)in_R9;
                *(int32_t *)(in_RCX + 0x244) = iVar7;
                *(int32_t *)(in_RCX + 0x248) = iVar21;
                *(int32_t *)(in_RCX + 0x24c) = iVar2;
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x14);
                iVar21 = *(int32_t *)(in_R9 + 3);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x1c);
                *piVar1 = *(int32_t *)(in_R9 + 2);
                piVar1[1] = iVar7;
                piVar1[2] = iVar21;
                piVar1[3] = iVar2;
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x24);
                iVar21 = *(int32_t *)(in_R9 + 5);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x2c);
                piVar1[4] = *(int32_t *)(in_R9 + 4);
                piVar1[5] = iVar7;
                piVar1[6] = iVar21;
                piVar1[7] = iVar2;
                iVar15 = *(int64_t *)(in_RCX + 0x250);
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x34);
                iVar21 = *(int32_t *)(in_R9 + 7);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x3c);
                *(int32_t *)(iVar15 + 0x20) = *(int32_t *)(in_R9 + 6);
                *(int32_t *)(iVar15 + 0x24) = iVar7;
                *(int32_t *)(iVar15 + 0x28) = iVar21;
                *(int32_t *)(iVar15 + 0x2c) = iVar2;
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x44);
                iVar21 = *(int32_t *)(in_R9 + 9);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x4c);
                *(int32_t *)(iVar15 + 0x30) = *(int32_t *)(in_R9 + 8);
                *(int32_t *)(iVar15 + 0x34) = iVar7;
                *(int32_t *)(iVar15 + 0x38) = iVar21;
                *(int32_t *)(iVar15 + 0x3c) = iVar2;
                return 1;
            }
            iVar7 = *(int32_t *)(in_RCX + 0x244);
            iVar21 = *(int32_t *)(in_RCX + 0x248);
            iVar2 = *(int32_t *)(in_RCX + 0x24c);
            *(int32_t *)in_R9 = *(int32_t *)(in_RCX + 0x240);
            *(int32_t *)((int64_t)in_R9 + 4) = iVar7;
            *(int32_t *)(in_R9 + 1) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0xc) = iVar2;
            piVar1 = *(int32_t **)(in_RCX + 0x250);
            iVar7 = piVar1[1];
            iVar21 = piVar1[2];
            iVar2 = piVar1[3];
            *(int32_t *)(in_R9 + 2) = *piVar1;
            *(int32_t *)((int64_t)in_R9 + 0x14) = iVar7;
            *(int32_t *)(in_R9 + 3) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x1c) = iVar2;
            iVar7 = piVar1[5];
            iVar21 = piVar1[6];
            iVar2 = piVar1[7];
            *(int32_t *)(in_R9 + 4) = piVar1[4];
            *(int32_t *)((int64_t)in_R9 + 0x24) = iVar7;
            *(int32_t *)(in_R9 + 5) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x2c) = iVar2;
            iVar15 = *(int64_t *)(in_RCX + 0x250);
            iVar7 = *(int32_t *)(iVar15 + 0x24);
            iVar21 = *(int32_t *)(iVar15 + 0x28);
            iVar2 = *(int32_t *)(iVar15 + 0x2c);
            *(int32_t *)(in_R9 + 6) = *(int32_t *)(iVar15 + 0x20);
            *(int32_t *)((int64_t)in_R9 + 0x34) = iVar7;
            *(int32_t *)(in_R9 + 7) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x3c) = iVar2;
            iVar7 = *(int32_t *)(iVar15 + 0x34);
            iVar21 = *(int32_t *)(iVar15 + 0x38);
            iVar2 = *(int32_t *)(iVar15 + 0x3c);
            *(int32_t *)(in_R9 + 8) = *(int32_t *)(iVar15 + 0x30);
            *(int32_t *)((int64_t)in_R9 + 0x44) = iVar7;
            *(int32_t *)(in_R9 + 9) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x4c) = iVar2;
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c482c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4844;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x40:
        *(int64_t **)(in_RCX + 0x270) = in_R9;
        return 1;
    case 0x41:
        *(uint32_t *)(in_RCX + 0x278) = in_R8D;
        return 1;
    case 0x4e:
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(int64_t **)(in_RCX + 0x340) = in_R9;
        return 1;
    case 0x4f:
        uVar8 = *(undefined8 *)(in_RCX + 0x360);
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c497e;
        fcn.180224990(uVar8, 0x1804b3080, 0x1013);
        *(undefined8 *)(in_RCX + 0x360) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c499a;
        uVar16 = fcn.180498cd0(in_R9);
        if (uVar16 < 0x100) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49aa;
            iVar9 = fcn.180498cd0(in_R9);
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49c5;
                iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar15));
                *(int64_t *)(in_RCX + 0x360) = iVar9;
                if (iVar9 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49da;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
                goto code_r0x0001801c49df;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a01;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a19;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x50:
        *(uint32_t *)(in_RCX + 0x3b0) = in_R8D;
        return 1;
    case 0x51:
        iVar9 = *(int64_t *)(in_RCX + 0x3a8);
        *(undefined8 *)(in_RCX + 0x358) = 0x1801c31f0;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a4f;
            fcn.180224990(iVar9, 0x1804b3080, 0x1024);
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a64;
        iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                              *(int64_t *)((int64_t)&arg_28h + iVar15));
        *(int64_t *)(in_RCX + 0x3a8) = iVar9;
        if (iVar9 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a79;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
code_r0x0001801c49df:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x52:
        iVar15 = *(int64_t *)(in_RCX + 0x110);
        if ((iVar15 != 0) || (in_R8D != 0)) goto code_r0x0001801c4d20;
    case 0x73:
        iVar15 = *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x10);
code_r0x0001801c4d20:
        *in_R9 = iVar15;
        return 1;
    case 0x53:
        uVar8 = *(undefined8 *)(in_RCX + 0x110);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4d3f;
        fcn.180238640(uVar8);
        *(undefined8 *)(in_RCX + 0x110) = 0;
        return 1;
    case 0x58:
        iVar9 = 0;
        if (in_R8D == 0) {
            piVar19 = *(int64_t **)((int64_t)&arg_48h + iVar15);
            iVar11 = *(int64_t *)((int64_t)&arg_38h + iVar15);
            puVar23 = (undefined *)((int64_t)&arg_40h + iVar15);
        } else {
            piVar19 = *(int64_t **)((int64_t)&arg_48h + iVar15);
            *(int64_t *)((int64_t)&arg_50h + iVar15) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
            *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a2440;
            iVar11 = fcn.18045a350();
            iVar11 = -iVar11;
            if (in_R9 == (int64_t *)0x0) {
                puVar23 = (undefined *)((int64_t)&arg_60h + iVar11 + iVar15);
                unaff_RSI = *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15);
                iVar11 = *(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15);
                in_R9 = (int64_t *)0x0;
            } else {
                *(int64_t **)((int64_t)&arg_68h + iVar11 + iVar15) = piVar19;
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a246a;
                piVar19 = (int64_t *)fcn.180238060(*(int64_t *)((int64_t)&arg_80h + iVar11 + iVar15));
                if (piVar19 == (int64_t *)0x0) {
                    return 0;
                }
                puVar23 = (undefined *)((int64_t)&arg_30h + iVar11 + iVar15 + 0x38 + -0x38);
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15 + 0x38 + -0x38) = 0x1801a2480;
                unaff_RSI = iVar9;
                iVar11 = in_RCX;
                in_R9 = piVar19;
            }
        }
        *(undefined8 *)(puVar23 + 0x20) = unaff_RBP;
        *(int64_t *)(puVar23 + -8) = unaff_RSI;
        *(int64_t *)(puVar23 + -0x10) = iVar11;
        *(undefined8 *)(puVar23 + -0x18) = unaff_R15;
        *(undefined8 *)(puVar23 + -0x20) = 0x1801a2333;
        iVar15 = fcn.18045a350();
        iVar15 = -iVar15;
        if (iVar9 == 0) {
            piVar18 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar18 = *(int64_t **)(iVar9 + 0x878);
        }
        iVar9 = *piVar18;
        if (iVar9 == 0) {
            return 0;
        }
        *(int64_t **)(puVar23 + iVar15 + 0x38) = piVar19;
        *(undefined8 *)(puVar23 + iVar15 + 0x40) = unaff_R12;
        iVar21 = 0;
        *(undefined8 *)(puVar23 + iVar15 + 0x48) = unaff_R14;
        *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a2389;
        iVar7 = fcn.180222010(in_R9);
        if (0 < iVar7) {
            do {
                *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a239a;
                fcn.180222340(in_R9, iVar21);
                *(undefined4 *)(puVar23 + iVar15 + 8) = 0;
                *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23b0;
                iVar7 = fcn.1801a8d20(*(int64_t *)(puVar23 + iVar15 + 0x28), *(int64_t *)(puVar23 + iVar15 + 0x30), 
                                      *(int64_t *)(puVar23 + iVar15 + 0x40), *(int64_t *)(puVar23 + iVar15 + 0x48), 
                                      *(int64_t *)(puVar23 + iVar15 + 0xb8));
                if (iVar7 != 1) {
                    *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)(puVar23 + iVar15 + 8), *(int64_t *)(puVar23 + iVar15 + 0x10));
                    *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)(puVar23 + iVar15 + 8), *(int64_t *)(puVar23 + iVar15 + 0x10), 
                                  *(int64_t *)(puVar23 + iVar15 + 0x18), *(int64_t *)(puVar23 + iVar15 + 0x20), 
                                  *(int64_t *)(puVar23 + iVar15 + 0x38));
                    *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(puVar23 + iVar15 + 0x28));
                    return 0;
                }
                iVar21 = iVar21 + 1;
                *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23c2;
                iVar7 = fcn.180222010(in_R9);
            } while (iVar21 < iVar7);
        }
        uVar8 = *(undefined8 *)(iVar9 + 0x10);
        *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23cf;
        fcn.180238640(uVar8);
        *(int64_t **)(iVar9 + 0x10) = in_R9;
        return 1;
    case 0x59:
        iVar9 = 0;
        if (in_R8D == 0) {
            uVar8 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
            *(undefined8 *)((int64_t)&arg_58h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
            *(int64_t *)((int64_t)&arg_38h + iVar15) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a17c0;
            iVar11 = fcn.18045a350(0, in_RCX, in_R9);
            iVar11 = -iVar11;
            if (iVar9 == 0) {
                piVar19 = *(int64_t **)(in_RCX + 0x158);
            } else {
                piVar19 = *(int64_t **)(iVar9 + 0x878);
            }
            *(undefined8 *)((int64_t)&arg_78h + iVar11 + iVar15) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_80h + iVar11 + iVar15) = uVar8;
            iVar9 = *piVar19;
            if (iVar9 != 0) {
                *(undefined4 *)((int64_t)&arg_58h + iVar11 + iVar15) = 0;
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a17fb;
                iVar7 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_80h + iVar11 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_90h + iVar11 + iVar15), 
                                      *(int64_t *)(&stack0x00000098 + iVar11 + iVar15), 
                                      *(int64_t *)(&stack0x00000108 + iVar11 + iVar15));
                if (iVar7 == 1) {
                    iVar22 = *(int64_t *)(iVar9 + 0x10);
                    if (iVar22 == 0) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1853;
                        iVar22 = fcn.180221f20();
                        *(int64_t *)(iVar9 + 0x10) = iVar22;
                        if (iVar22 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1867;
                    iVar7 = fcn.180222110(iVar22, in_R9);
                    return (uint64_t)(iVar7 != 0);
                }
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1807;
                fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a181f;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_88h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a182e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15));
            }
            return 0;
        }
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a1895;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a18a9;
        uVar16 = fcn.1802375f0(in_R9);
        if ((int32_t)uVar16 == 0) {
            return uVar16;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar11 + iVar15) = uVar8;
        if (iVar9 == 0) {
            piVar19 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar19 = *(int64_t **)(iVar9 + 0x878);
        }
        iVar9 = *piVar19;
        if (iVar9 != 0) {
            *(undefined4 *)((int64_t)&arg_58h + iVar11 + iVar15) = 0;
            *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a18f8;
            iVar7 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar11 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_90h + iVar11 + iVar15), 
                                  *(int64_t *)(&stack0x00000098 + iVar11 + iVar15), 
                                  *(int64_t *)(&stack0x00000108 + iVar11 + iVar15));
            if (iVar7 == 1) {
                iVar22 = *(int64_t *)(iVar9 + 0x10);
                if (iVar22 == 0) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1958;
                    iVar22 = fcn.180221f20();
                    *(int64_t *)(iVar9 + 0x10) = iVar22;
                    if (iVar22 == 0) goto code_r0x0001801a192b;
                }
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a196c;
                iVar7 = fcn.180222110(iVar22, in_R9);
                if (iVar7 != 0) {
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1904;
                fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a191c;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_88h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a192b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15));
            }
        }
code_r0x0001801a192b:
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1933;
        fcn.18021fe80(in_R9);
        return 0;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_30h + iVar15) = (int64_t)(int32_t)in_R8D;
        *(int64_t **)((int64_t)&arg_28h + iVar15) = in_R9;
        *(int64_t *)((int64_t)&var_20h + iVar15) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&var_18h + iVar15) = in_RCX + 0x2b8;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4afe;
        uVar16 = fcn.1801abb30(*(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                               *(int64_t *)((int64_t)&arg_38h + iVar15), *(int64_t *)((int64_t)&arg_40h + iVar15), 
                               *(int64_t *)((int64_t)&arg_48h + iVar15), *(int64_t *)((int64_t)&arg_50h + iVar15), 
                               *(int64_t *)((int64_t)&arg_58h + iVar15), *(int64_t *)((int64_t)&arg_60h + iVar15));
        return uVar16;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_30h + iVar15) = in_R9;
        *(int64_t *)((int64_t)&arg_28h + iVar15) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&var_20h + iVar15) = in_RCX + 0x2b8;
        *(int64_t *)((int64_t)&var_18h + iVar15) = in_RCX + 0x2a0;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4b4f;
        uVar16 = fcn.1801abdc0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                               *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                               *(int64_t *)((int64_t)&arg_68h + iVar15), *(int64_t *)((int64_t)&arg_88h + iVar15), 
                               *(int64_t *)((int64_t)&arg_90h + iVar15));
        return uVar16;
    case 0x61:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 0;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        goto code_r0x0001801ac640;
    case 0x62:
        iVar7 = 0;
        goto code_r0x0001801c4bb0;
    case 0x65:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 1;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
code_r0x0001801ac640:
        uVar16 = (uint64_t)(int32_t)in_R8D;
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = uVar8;
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = uVar24;
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_28h + iVar15) = unaff_R15;
        *(undefined8 *)((int64_t)&var_20h + iVar15) = 0x1801ac65e;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        if ((uVar16 & 1) == 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac697;
            puVar13 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15));
            if (puVar13 != (undefined2 *)0x0) {
                uVar25 = 0;
                puVar26 = puVar13;
                if (uVar16 != 0) {
                    do {
                        iVar21 = *(int32_t *)in_R9;
                        uVar20 = 0;
                        piVar1 = (int32_t *)((int64_t)in_R9 + 4);
                        in_R9 = in_R9 + 1;
                        iVar22 = 0x1804ae0e0;
                        do {
                            if ((*(int32_t *)(iVar22 + 0x14) == iVar21) && (*(int32_t *)(iVar22 + 0x1c) == *piVar1)) {
                                *puVar26 = *(undefined2 *)(iVar22 + 0x10);
                                puVar26 = puVar26 + 1;
                                break;
                            }
                            uVar20 = uVar20 + 1;
                            iVar22 = iVar22 + 0x48;
                        } while (uVar20 < 0x1f);
                        if (uVar20 == 0x1f) {
                            *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac744;
                            fcn.180224990(puVar13, 0x1804aeee0, 0xf47);
                            return 0;
                        }
                        uVar25 = uVar25 + 2;
                    } while (uVar25 < uVar16);
                }
                if (iVar7 == 0) {
                    uVar8 = *(undefined8 *)(iVar9 + 0x40);
                    *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac76e;
                    fcn.180224990(uVar8, 0x1804aeee0, 0xf3f);
                    *(undefined2 **)(iVar9 + 0x40) = puVar13;
                    *(uint64_t *)(iVar9 + 0x48) = uVar16 >> 1;
                    return 1;
                }
                uVar8 = *(undefined8 *)(iVar9 + 0x50);
                *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac720;
                fcn.180224990(uVar8, 0x1804aeee0, 0xf3b);
                *(undefined2 **)(iVar9 + 0x50) = puVar13;
                *(uint64_t *)(iVar9 + 0x58) = uVar16 >> 1;
                return 1;
            }
        }
        return 0;
    case 0x66:
        iVar7 = 1;
code_r0x0001801c4bb0:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        uVar8 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_28h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&var_20h + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&var_18h + iVar15) = 0x1801ac790;
        iVar11 = fcn.18045a350(in_RCX, iVar9, in_R9);
        iVar11 = -iVar11;
        *(uint64_t *)((int64_t)&arg_e0h + iVar11 + iVar15) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&var_20h + iVar11 + iVar15;
        *(undefined8 *)((int64_t)&arg_50h + iVar11 + iVar15) = 0;
        iVar22 = *(int64_t *)((int64_t)&arg_d8h + iVar11 + iVar15);
        if (in_RCX != 0) {
            iVar22 = in_RCX;
        }
        *(int64_t *)((int64_t)&arg_d8h + iVar11 + iVar15) = iVar22;
        *(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15) = (int64_t)&arg_50h + iVar11 + iVar15;
        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac7f0;
        iVar21 = fcn.18024a850(*(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15), 
                               *(int64_t *)((int64_t)&arg_50h + iVar11 + iVar15), 
                               *(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                               *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15));
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)&arg_f0h + iVar11 + iVar15) = uVar8;
            iVar22 = *(int64_t *)((int64_t)&arg_50h + iVar11 + iVar15);
            if (iVar22 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_50h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15));
            } else if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac86d;
                iVar14 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15));
                if (iVar14 != 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac886;
                    fcn.180498030(iVar14, (int64_t)&arg_58h + iVar11 + iVar15, iVar22 * 2);
                    if (iVar7 == 0) {
                        uVar8 = *(undefined8 *)(iVar9 + 0x40);
                        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac8ba;
                        fcn.180224990(uVar8, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar9 + 0x40) = iVar14;
                        *(int64_t *)(iVar9 + 0x48) = iVar22;
                    } else {
                        uVar8 = *(undefined8 *)(iVar9 + 0x50);
                        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac8a1;
                        fcn.180224990(uVar8, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar9 + 0x50) = iVar14;
                        *(int64_t *)(iVar9 + 0x58) = iVar22;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac8e1;
        uVar16 = fcn.180459870(*(uint64_t *)((int64_t)&arg_e0h + iVar11 + iVar15) ^ (int64_t)&var_20h + iVar11 + iVar15)
        ;
        return uVar16;
    case 0x68:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        uVar16 = (uint64_t)(int32_t)in_R8D;
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(int64_t *)((int64_t)&arg_50h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801c5915;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        uVar8 = *(undefined8 *)(iVar9 + 0x30);
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801c5937;
        fcn.180224990(uVar8, 0x1804b3080, 0x121c);
        *(undefined8 *)(iVar9 + 0x30) = 0;
        *(undefined8 *)(iVar9 + 0x38) = 0;
        if ((in_R9 != (int64_t *)0x0) && (uVar16 != 0)) {
            if (uVar16 < 0x100) {
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801c596c;
                iVar15 = fcn.180223170(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15));
                *(int64_t *)(iVar9 + 0x30) = iVar15;
                if (iVar15 != 0) {
                    *(uint64_t *)(iVar9 + 0x38) = uVar16;
                    return 1;
                }
            }
            return 0;
        }
        return 1;
    case 0x69:
        iVar22 = 0;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(int64_t *)((int64_t)&arg_50h + iVar15) = in_RCX;
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = uVar8;
        *(int64_t *)((int64_t)&arg_30h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_28h + iVar15) = uVar24;
        *(undefined8 *)((int64_t)&var_20h + iVar15) = unaff_R12;
        *(undefined8 *)((int64_t)&var_18h + iVar15) = unaff_R13;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + -8) = unaff_R15;
        *(undefined8 *)(&stack0x00000000 + iVar15) = 0x1801a141f;
        iVar9 = fcn.18045a350();
        iVar9 = -iVar9;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&arg_b0h + iVar9 + iVar15) = 0;
        if (iVar22 == 0) {
            ppiVar17 = *(int64_t ***)(in_RCX + 0x158);
        } else {
            ppiVar17 = *(int64_t ***)(iVar22 + 0x878);
            in_RCX = *(int64_t *)(iVar22 + 8);
        }
        piVar19 = *ppiVar17;
        *(int64_t **)((int64_t)&arg_48h + iVar9 + iVar15) = piVar19;
        uVar25 = 0;
        uVar5 = 0;
        uVar16 = 0;
        *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15) = in_RCX;
        *(int64_t ***)((int64_t)&arg_38h + iVar9 + iVar15) = ppiVar17;
        *(uint32_t *)((int64_t)&arg_a8h + iVar9 + iVar15) = in_R8D & 4;
        if (*piVar19 == 0) {
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a147d;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1495;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14a7;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
            uVar16 = uVar25;
code_r0x0001801a1782:
            uVar25 = uVar16;
            if (*(int32_t *)((int64_t)&arg_a8h + iVar9 + iVar15) == 0) goto code_r0x0001801a1794;
        } else {
            if ((in_R8D & 4) == 0) {
                if ((in_R8D & 1) != 0) {
                    *(int64_t *)((int64_t)&arg_b0h + iVar9 + iVar15) = piVar19[2];
                }
code_r0x0001801a1536:
                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a154a;
                iVar11 = fcn.18024c080(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                       *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                if (iVar11 == 0) {
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1557;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a156f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1581;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                    uVar16 = uVar25;
                } else {
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a159c;
                    iVar7 = fcn.18024bbe0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15));
                    if (iVar7 == 0) {
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15a5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                        uVar16 = uVar25;
                    } else {
                        uVar4 = *(uint32_t *)((int64_t)ppiVar17 + 0x1c);
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15e5;
                        fcn.18024c330(iVar11, uVar4 & 0x30000);
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15ed;
                        iVar7 = fcn.18024c740(*(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15));
                        if (iVar7 < 1) {
                            if ((in_R8D & 8) == 0) {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16f2;
                                uVar6 = fcn.18024bbd0(iVar11);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16f9;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1711;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1718;
                                fcn.180250ec0(uVar6);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1731;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                                goto code_r0x0001801a1782;
                            }
                            if ((in_R8D & 0x10) != 0) {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1606;
                                fcn.1802203d0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                            }
                            uVar5 = 2;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1613;
                        iVar22 = fcn.18024b970(iVar11);
                        *(int64_t *)((int64_t)&arg_b0h + iVar9 + iVar15) = iVar22;
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1626;
                        uVar8 = fcn.1802222a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15));
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a162e;
                        fcn.18021fe80(uVar8);
                        if ((in_R8D & 2) != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a163c;
                            iVar7 = fcn.180222010(iVar22);
                            if (0 < iVar7) {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1648;
                                iVar7 = fcn.180222010(iVar22);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1653;
                                uVar8 = fcn.180222340(iVar22, iVar7 + -1);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a165b;
                                uVar4 = fcn.18023bbb0(uVar8);
                                if ((uVar4 >> 0xd & 1) != 0) {
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1669;
                                    uVar8 = fcn.180222020(iVar22);
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1671;
                                    fcn.18021fe80(uVar8);
                                }
                            }
                        }
                        iVar21 = 0;
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a167b;
                        iVar7 = fcn.180222010(iVar22);
                        if (iVar7 < 1) {
                            iVar14 = piVar19[2];
                            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1774;
                            fcn.180238640(iVar14);
                            piVar19[2] = iVar22;
                            uVar16 = (uint64_t)uVar5;
                            if (uVar5 == 0) {
                                uVar16 = 1;
                            }
                        } else {
                            do {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a169d;
                                fcn.180222340(iVar22, iVar21);
                                *(undefined4 *)((int64_t)&arg_28h + iVar9 + iVar15) = 0;
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16b6;
                                uVar5 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_d8h + iVar9 + iVar15));
                                uVar16 = (uint64_t)uVar5;
                                if (uVar5 != 1) {
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1738;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1750;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a175f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1767;
                                    fcn.180238640(iVar22);
                                    uVar16 = 0;
                                    goto code_r0x0001801a1782;
                                }
                                iVar21 = iVar21 + 1;
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16c7;
                                iVar7 = fcn.180222010(iVar22);
                            } while (iVar21 < iVar7);
                            iVar22 = *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15);
                            uVar8 = *(undefined8 *)(iVar22 + 0x10);
                            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16d9;
                            fcn.180238640(uVar8);
                            *(undefined8 *)(iVar22 + 0x10) = *(undefined8 *)((int64_t)&arg_b0h + iVar9 + iVar15);
                        }
                    }
                }
                goto code_r0x0001801a1782;
            }
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14b5;
            iVar22 = fcn.18021f3d0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
            if (iVar22 != 0) {
                iVar14 = piVar19[2];
                iVar21 = 0;
                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14cc;
                iVar7 = fcn.180222010(iVar14);
                if (0 < iVar7) {
                    do {
                        iVar14 = piVar19[2];
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14db;
                        uVar8 = fcn.180222340(iVar14, iVar21);
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14e6;
                        iVar7 = fcn.18021f070(iVar22, uVar8);
                        if (iVar7 == 0) goto code_r0x0001801a178c;
                        iVar14 = piVar19[2];
                        iVar21 = iVar21 + 1;
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14f9;
                        iVar7 = fcn.180222010(iVar14);
                    } while (iVar21 < iVar7);
                }
                iVar14 = *piVar19;
                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1508;
                iVar7 = fcn.18021f070(iVar22, iVar14);
                if (iVar7 != 0) {
                    ppiVar17 = *(int64_t ***)((int64_t)&arg_38h + iVar9 + iVar15);
                    goto code_r0x0001801a1536;
                }
            }
        }
code_r0x0001801a178c:
        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1794;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15)
                      , *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                      *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15), *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15)
                     );
code_r0x0001801a1794:
        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a179c;
        fcn.18024b910(iVar11);
        return uVar25;
    case 0x6a:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 0;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        goto code_r0x0001801a24c0;
    case 0x6b:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 1;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
code_r0x0001801a24c0:
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = uVar24;
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a24d5;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        if ((in_R8D != 0) && (in_R9 != (int64_t *)0x0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a24f3;
            uVar16 = fcn.18021f5b0(in_R9);
            if ((int32_t)uVar16 == 0) {
                return uVar16;
            }
        }
        *(undefined8 *)((int64_t)&arg_68h + iVar11 + iVar15) = uVar8;
        iVar22 = 0x70;
        if (iVar7 == 0) {
            iVar22 = 0x78;
        }
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a2524;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_88h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_90h + iVar11 + iVar15));
        *(int64_t **)(iVar22 + iVar9) = in_R9;
        return 1;
    case 0x74:
        ppiVar17 = *(int64_t ***)(in_RCX + 0x158);
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a2280;
        iVar9 = fcn.18045a350();
        iVar9 = -iVar9;
        if (in_R9 != (int64_t *)0x0) {
            piVar19 = (int64_t *)0x0;
            if (ppiVar17[5] != (int64_t *)0x0) {
                ppiVar10 = (int64_t **)ppiVar17[4];
                piVar18 = piVar19;
                do {
                    if ((*ppiVar10 == in_R9) && (ppiVar10[1] != (int64_t *)0x0)) {
                        *ppiVar17 = (int64_t *)ppiVar10;
                        return 1;
                    }
                    piVar18 = (int64_t *)((int64_t)piVar18 + 1);
                    ppiVar10 = ppiVar10 + 5;
                    piVar12 = piVar19;
                } while (piVar18 < ppiVar17[5]);
                do {
                    piVar18 = (int64_t *)((int64_t)ppiVar17[4] + (int64_t)piVar12);
                    if ((piVar18[1] != 0) && (*piVar18 != 0)) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar9 + iVar15) = 0x1801a22de;
                        iVar7 = fcn.180238200(*(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar15), 
                                              *(int64_t *)(&stack0x00000098 + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_a0h + iVar9 + iVar15), 
                                              *(int64_t *)(&stack0x00000108 + iVar9 + iVar15), 
                                              *(int64_t *)(&stack0x00000150 + iVar9 + iVar15));
                        if (iVar7 == 0) {
                            *ppiVar17 = piVar18;
                            return 1;
                        }
                    }
                    piVar19 = (int64_t *)((int64_t)piVar19 + 1);
                    piVar12 = piVar12 + 5;
                } while (piVar19 < ppiVar17[5]);
            }
        }
        return 0;
    case 0x75:
        ppiVar17 = *(int64_t ***)(in_RCX + 0x158);
        if (ppiVar17 != (int64_t **)0x0) {
            if (in_R8D == 1) {
                piVar18 = ppiVar17[5];
                piVar19 = (int64_t *)0x0;
                if (piVar18 != (int64_t *)0x0) {
code_r0x0001801a25ab:
                    piVar12 = ppiVar17[4] + (int64_t)piVar19 * 5;
                    while ((*piVar12 == 0 || (piVar12[1] == 0))) {
                        piVar19 = (int64_t *)((int64_t)piVar19 + 1);
                        piVar12 = piVar12 + 5;
                        if (piVar18 <= piVar19) {
                            return 0;
                        }
                    }
                    *ppiVar17 = piVar12;
                    return 1;
                }
            } else if ((in_R8D == 2) &&
                      (piVar19 = (int64_t *)(((int64_t)*ppiVar17 - (int64_t)ppiVar17[4]) / 0x28 + 1),
                      piVar19 < ppiVar17[5])) {
                piVar18 = ppiVar17[5];
                goto code_r0x0001801a25ab;
            }
        }
        return 0;
    case 0x76:
        *(uint32_t *)(*(int64_t *)(in_RCX + 0x158) + 0x18) = in_R8D;
        return 1;
    case 0x7f:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x278);
    case 0x80:
        *in_R9 = *(int64_t *)(in_RCX + 0x268);
        return 1;
    case 0x81:
        *in_R9 = *(int64_t *)(in_RCX + 0x270);
        return 1;
    case 0x89:
        iVar15 = *(int64_t *)(in_RCX + 0x158);
        bVar3 = false;
        goto code_r0x0001801a1fc0;
    case 0x8a:
        iVar15 = *(int64_t *)(in_RCX + 0x158);
        bVar3 = true;
code_r0x0001801a1fc0:
        iVar9 = 0x70;
        if (!bVar3) {
            iVar9 = 0x78;
        }
        *in_R9 = *(int64_t *)(iVar9 + iVar15);
        return 1;
    case 0x8b:
        *(int64_t **)((int64_t)&var_20h + iVar15) = in_R9;
        *(uint32_t *)((int64_t)&var_18h + iVar15) = in_R8D;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4b83;
        uVar16 = fcn.1801ab100(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                               *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                               *(int64_t *)((int64_t)&arg_40h + iVar15), *(int64_t *)((int64_t)&arg_88h + iVar15), 
                               *(int64_t *)((int64_t)&arg_90h + iVar15));
        return uVar16;
    }
    *(code **)((int64_t)&pcStack_10 + iVar15) = case.0x1801c46af.5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar15));
code_r0x0001801c46e6:
    return 0;
}

// ============================================================
// Function: FUN_1801c4f10
// Address: 0x1801c4f10
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c4f49
// Address: 0x1801c4f49
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c4f51
// Address: 0x1801c4f51
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c4f7b
// Address: 0x1801c4f7b
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c4fbf
// Address: 0x1801c4fbf
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c4fd7
// Address: 0x1801c4fd7
// Size: 340 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c512b
// Address: 0x1801c512b
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801c4f10(int64_t arg1, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    uint64_t uVar5;
    undefined8 unaff_RDI;
    int64_t *piVar6;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    int64_t var_8h;
    
    if (arg1 == 0) {
        return;
    }
    uStack_10 = 0x1801c4f24;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (*(int32_t *)arg1 != 0) {
        if (-1 < (char)*(int32_t *)arg1) {
            return;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f3d;
        arg1 = func_0x0001801bda50();
        if ((int32_t *)arg1 == (int32_t *)0x0) {
            return;
        }
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f5b;
    func_0x0001801da740(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4f67;
    fcn.18022ecc0(uVar1);
    uVar5 = 0;
    *(undefined8 *)(arg1 + 0x4e0) = 0;
    if (*(int64_t *)(arg1 + 0x338) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RDI;
        piVar6 = (int64_t *)(arg1 + 0x310);
        do {
            if (*piVar6 != 0) {
                if (*(int64_t *)(arg1 + 0x308) == *piVar6) {
                    *(undefined8 *)(arg1 + 0x308) = 0;
                }
                iVar2 = *piVar6;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fa7;
                fcn.18022ecc0(iVar2);
                *piVar6 = 0;
            }
            uVar5 = uVar5 + 1;
            piVar6 = piVar6 + 1;
        } while (uVar5 < *(uint64_t *)(arg1 + 0x338));
    }
    *(undefined8 *)(arg1 + 0x338) = 0;
    if (*(int64_t *)(arg1 + 0x308) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fdc;
        fcn.18022ecc0();
        *(undefined8 *)(arg1 + 0x308) = 0;
    }
    uVar1 = *(undefined8 *)(arg1 + 0x370);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4fef;
    func_0x0001801974e0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x378);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c4ffb;
    func_0x0001801975c0(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x348);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5014;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6c);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5027;
    fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                  *(int64_t *)(&stack0x00000050 + iVar4));
    uVar1 = *(undefined8 *)(arg1 + 0x3a0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5040;
    fcn.180224990(uVar1, 0x1804b3080, 0xd6e);
    uVar1 = *(undefined8 *)(arg1 + 0x3b8);
    uVar3 = *(undefined8 *)(arg1 + 0x3b0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5060;
    func_0x000180224b90(uVar3, uVar1, 0x1804b3080, 0xd6f);
    uVar1 = *(undefined8 *)(arg1 + 0x3e0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5079;
    fcn.180224990(uVar1, 0x1804b3080, 0xd70);
    uVar1 = *(undefined8 *)(arg1 + 1000);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5092;
    fcn.180224990(uVar1, 0x1804b3080, 0xd71);
    uVar1 = *(undefined8 *)(arg1 + 0x408);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50ab;
    fcn.180224990(uVar1, 0x1804b3080, 0xd72);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50b3;
    fcn.1801dada0(arg1);
    uVar1 = *(undefined8 *)(arg1 + 0x4b8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50cc;
    fcn.180224990(uVar1, 0x1804b3080, 0xd74);
    uVar1 = *(undefined8 *)(arg1 + 0x4c8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50e5;
    fcn.180224990(uVar1, 0x1804b3080, 0xd75);
    uVar1 = *(undefined8 *)(arg1 + 0x158);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c50f1;
    func_0x0001801a6070(uVar1);
    uVar1 = *(undefined8 *)(arg1 + 0x3c0);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c510a;
    fcn.180224990(uVar1, 0x1804b3080, 0xd79);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5112;
    func_0x0001801bd3b0(arg1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5126;
    fcn.1804986e0((int32_t *)(arg1 + 0x160), 0, 0x390);
    return;
}

// ============================================================
// Function: FUN_1801c5160
// Address: 0x1801c5160
// Size: 119 bytes
// ============================================================
void fcn.1801c5160(int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    uint8_t *in_RCX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c516a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(uint32_t *)((int64_t)&arg_38h + iVar1) = (*in_RCX | 0x30000) << 8 | (uint32_t)in_RCX[1];
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c519a;
    iVar2 = fcn.180191930((int64_t)&var_20h + iVar1, 0x18069c690, 7);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c51b6;
        iVar2 = fcn.180191930((int64_t)&var_20h + iVar1, 0x18069c8c0, 0xa7);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c51d2;
            fcn.180191930((int64_t)&var_20h + iVar1, 0x18069fcf0, 2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801c51e0
// Address: 0x1801c51e0
// Size: 101 bytes
// ============================================================
void fcn.1801c51e0(int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined4 in_ECX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c51ea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_38h + iVar1) = in_ECX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c5208;
    iVar2 = fcn.180191930((int64_t)&var_20h + iVar1, 0x18069c690, 7);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c5224;
        iVar2 = fcn.180191930((int64_t)&var_20h + iVar1, 0x18069c8c0, 0xa7);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c5240;
            fcn.180191930((int64_t)&var_20h + iVar1, 0x18069fcf0, 2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801c5250
// Address: 0x1801c5250
// Size: 206 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1801c5250(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_58h,
                     int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 in_RCX;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c5270;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = 7;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0x18069c690;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = 0xa7;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = 0x18069c8c0;
    uVar5 = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar3) = 2;
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = 0x18069fcf0;
    do {
        uVar1 = *(uint64_t *)((int64_t)&arg_30h + uVar5 + iVar3);
        uVar4 = 0;
        iVar6 = *(int64_t *)((int64_t)&var_18h + uVar5 + iVar3);
        if (uVar1 != 0) {
            do {
                if (*(int64_t *)(iVar6 + 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c52e2;
                    iVar2 = func_0x000180498f10(in_RCX);
                    if (iVar2 == 0) {
                        return iVar6;
                    }
                }
                uVar4 = uVar4 + 1;
                iVar6 = iVar6 + 0x50;
            } while (uVar4 < uVar1);
        }
        uVar5 = uVar5 + 8;
    } while (uVar5 < 0x18);
    return 0;
}

// ============================================================
// Function: FUN_1801c5320
// Address: 0x1801c5320
// Size: 545 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

uint64_t fcn.1801c5320(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c5335;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *(int64_t *)(in_RCX + 0x878);
    *(undefined4 *)((int64_t)&arg_28h + iVar4) = 0;
    if (*(int64_t *)(iVar1 + 0x30) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5360;
        uVar5 = fcn.1802445f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        return uVar5;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5388;
    fcn.1801a9330(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_28h + iVar4));
    uVar3 = *(uint32_t *)(*(int64_t *)(in_RCX + 0x300) + 0x1c);
    if ((0x300 < *(int32_t *)(in_RCX + 0x48)) && ((uVar3 & 0x10) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c53bc;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c53d7;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c53f2;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c540d;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5428;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
    }
    if ((0x302 < *(int32_t *)(in_RCX + 0x48)) && ((uVar3 >> 9 & 1) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5452;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c546d;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
    }
    if ((*(int32_t *)(in_RCX + 0x48) == 0x300) && ((uVar3 & 2) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5497;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        uVar3 = *(uint32_t *)((int64_t)&arg_28h + iVar4);
        if ((uVar3 & 2) != 0) goto code_r0x0001801c54be;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c54b6;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
    }
    uVar3 = *(uint32_t *)((int64_t)&arg_28h + iVar4);
code_r0x0001801c54be:
    if ((uVar3 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c54d2;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        uVar3 = *(uint32_t *)((int64_t)&arg_28h + iVar4);
    }
    if ((uVar3 & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c54f1;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        if (iVar2 == 0) {
            return 0;
        }
        uVar3 = *(uint32_t *)((int64_t)&arg_28h + iVar4);
    }
    if ((0x300 < *(int32_t *)(in_RCX + 0x48)) && ((uVar3 & 8) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c551d;
        iVar2 = fcn.1802446f0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4));
        return (uint64_t)(iVar2 != 0);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801c5550
// Address: 0x1801c5550
// Size: 96 bytes
// ============================================================
bool fcn.1801c5550(int32_t *param_1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int32_t *piVar4;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c555c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (param_1 == (int32_t *)0x0) {
        return false;
    }
    piVar4 = param_1;
    if (*param_1 != 0) {
        if (-1 < (char)*param_1) {
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c557b;
        piVar4 = (int32_t *)func_0x0001801bda50();
        if (piVar4 == (int32_t *)0x0) {
            return false;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c5588;
    iVar2 = func_0x0001801bd4c0(piVar4);
    if (iVar2 == 0) {
        return false;
    }
    pcVar1 = *(code **)(*(int64_t *)(param_1 + 6) + 0x30);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801c5599;
    iVar2 = (*pcVar1)(param_1);
    return iVar2 != 0;
}

// ============================================================
// Function: FUN_1801c55c0
// Address: 0x1801c55c0
// Size: 34 bytes
// ============================================================
void fcn.1801c55c0(void)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c55ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c55dd;
    fcn.1801c5680(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801c55f0
// Address: 0x1801c55f0
// Size: 101 bytes
// ============================================================
undefined8 fcn.1801c55f0(int64_t param_1, undefined8 param_2, undefined8 *param_3)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c55fc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if ((*(uint32_t *)(param_1 + 0x18) & 0xff000000) != 0x3000000) {
        *param_3 = 0;
        return 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801c5639;
    uVar2 = fcn.1802446f0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *param_3 = 2;
    return 1;
}

// ============================================================
// Function: FUN_1801c5660
// Address: 0x1801c5660
// Size: 31 bytes
// ============================================================
void fcn.1801c5660(void)
{
    int64_t iVar1;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c566a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801c567a;
    fcn.1801c5680(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801c5680
// Address: 0x1801c5680
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.1801c5680(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    int32_t *piVar7;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c569a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        piVar7 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar7 = in_RCX;
        }
        if (piVar7 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c56d5;
            (*(code *)0x69a006)(0);
            if (piVar7[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5700;
                    iVar4 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5710;
                        iVar4 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar4 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c571c;
                            iVar4 = func_0x00018019b2a0(in_RCX);
                            if (iVar4 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5728;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar5);
            piVar7[0x76] = 1;
            iVar2 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
            pcVar3 = *(code **)(iVar2 + 0x80);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5778;
            iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
            if ((iVar4 == -1) && (piVar7[0x76] == 2)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5795;
                func_0x00018019b730(piVar7, 1);
                iVar2 = *(int64_t *)(in_RCX + 6);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
                *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
                pcVar3 = *(code **)(iVar2 + 0x80);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57bd;
                iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57c9;
                func_0x00018019b730(piVar7, 0);
                return iVar4;
            }
            piVar7[0x76] = 0;
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c56c3
// Address: 0x1801c56c3
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.1801c5680(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    int32_t *piVar7;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c569a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        piVar7 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar7 = in_RCX;
        }
        if (piVar7 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c56d5;
            (*(code *)0x69a006)(0);
            if (piVar7[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5700;
                    iVar4 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5710;
                        iVar4 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar4 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c571c;
                            iVar4 = func_0x00018019b2a0(in_RCX);
                            if (iVar4 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5728;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar5);
            piVar7[0x76] = 1;
            iVar2 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
            pcVar3 = *(code **)(iVar2 + 0x80);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5778;
            iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
            if ((iVar4 == -1) && (piVar7[0x76] == 2)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5795;
                func_0x00018019b730(piVar7, 1);
                iVar2 = *(int64_t *)(in_RCX + 6);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
                *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
                pcVar3 = *(code **)(iVar2 + 0x80);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57bd;
                iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57c9;
                func_0x00018019b730(piVar7, 0);
                return iVar4;
            }
            piVar7[0x76] = 0;
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c57d7
// Address: 0x1801c57d7
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.1801c5680(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    int32_t *piVar7;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c569a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        piVar7 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar7 = in_RCX;
        }
        if (piVar7 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c56d5;
            (*(code *)0x69a006)(0);
            if (piVar7[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5700;
                    iVar4 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5710;
                        iVar4 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar4 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c571c;
                            iVar4 = func_0x00018019b2a0(in_RCX);
                            if (iVar4 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5728;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar5);
            piVar7[0x76] = 1;
            iVar2 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
            pcVar3 = *(code **)(iVar2 + 0x80);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5778;
            iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
            if ((iVar4 == -1) && (piVar7[0x76] == 2)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5795;
                func_0x00018019b730(piVar7, 1);
                iVar2 = *(int64_t *)(in_RCX + 6);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
                *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
                pcVar3 = *(code **)(iVar2 + 0x80);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57bd;
                iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57c9;
                func_0x00018019b730(piVar7, 0);
                return iVar4;
            }
            piVar7[0x76] = 0;
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c57ef
// Address: 0x1801c57ef
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.1801c5680(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    int32_t *piVar6;
    undefined8 unaff_RBP;
    int32_t *piVar7;
    undefined8 in_R8;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c569a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX != (int32_t *)0x0) {
        piVar7 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar7 = in_RCX;
        }
        if (piVar7 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_RBX;
            *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_RBP;
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c56d5;
            (*(code *)0x69a006)(0);
            if (piVar7[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5700;
                    iVar4 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar4 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5710;
                        iVar4 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar4 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c571c;
                            iVar4 = func_0x00018019b2a0(in_RCX);
                            if (iVar4 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5728;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            uVar1 = *(undefined8 *)((int64_t)&arg_68h + iVar5);
            piVar7[0x76] = 1;
            iVar2 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
            *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
            *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
            pcVar3 = *(code **)(iVar2 + 0x80);
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5778;
            iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
            if ((iVar4 == -1) && (piVar7[0x76] == 2)) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c5795;
                func_0x00018019b730(piVar7, 1);
                iVar2 = *(int64_t *)(in_RCX + 6);
                *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar1;
                *(undefined4 *)((int64_t)&var_10h + iVar5) = in_R9D;
                *(undefined8 *)((int64_t)&var_8h + iVar5) = in_R8;
                pcVar3 = *(code **)(iVar2 + 0x80);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57bd;
                iVar4 = (*pcVar3)(in_RCX, 0x17, 0, in_RDX);
                *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x1801c57c9;
                func_0x00018019b730(piVar7, 0);
                return iVar4;
            }
            piVar7[0x76] = 0;
            return iVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5840
// Address: 0x1801c5840
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801c5840(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *in_RCX;
    int32_t in_EDX;
    int32_t *piVar3;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c585a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar3 = in_RCX;
        }
        if (piVar3 != (int32_t *)0x0) {
            if (piVar3[0x73] == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c588f;
            iVar1 = func_0x0001801a2fb0(piVar3 + 0x314);
            if (iVar1 != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c589f;
            iVar1 = func_0x0001801a31f0(piVar3 + 0x314);
            if (iVar1 != 0) {
                return 0;
            }
            if (in_EDX == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c58af;
                iVar1 = func_0x00018019b2a0(in_RCX);
                if (iVar1 != 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c58bb;
            func_0x00018019b790(piVar3);
            piVar3[0x75] = piVar3[0x75] + 1;
            piVar3[0x74] = piVar3[0x74] + 1;
            piVar3[0x73] = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5885
// Address: 0x1801c5885
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801c5840(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *in_RCX;
    int32_t in_EDX;
    int32_t *piVar3;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c585a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar3 = in_RCX;
        }
        if (piVar3 != (int32_t *)0x0) {
            if (piVar3[0x73] == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c588f;
            iVar1 = func_0x0001801a2fb0(piVar3 + 0x314);
            if (iVar1 != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c589f;
            iVar1 = func_0x0001801a31f0(piVar3 + 0x314);
            if (iVar1 != 0) {
                return 0;
            }
            if (in_EDX == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c58af;
                iVar1 = func_0x00018019b2a0(in_RCX);
                if (iVar1 != 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c58bb;
            func_0x00018019b790(piVar3);
            piVar3[0x75] = piVar3[0x75] + 1;
            piVar3[0x74] = piVar3[0x74] + 1;
            piVar3[0x73] = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c58d7
// Address: 0x1801c58d7
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801c5840(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int64_t iVar2;
    int32_t *in_RCX;
    int32_t in_EDX;
    int32_t *piVar3;
    undefined8 unaff_R14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c585a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX != (int32_t *)0x0) {
        piVar3 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar3 = in_RCX;
        }
        if (piVar3 != (int32_t *)0x0) {
            if (piVar3[0x73] == 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_R14;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c588f;
            iVar1 = func_0x0001801a2fb0(piVar3 + 0x314);
            if (iVar1 != 0) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c589f;
            iVar1 = func_0x0001801a31f0(piVar3 + 0x314);
            if (iVar1 != 0) {
                return 0;
            }
            if (in_EDX == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c58af;
                iVar1 = func_0x00018019b2a0(in_RCX);
                if (iVar1 != 0) {
                    return 0;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801c58bb;
            func_0x00018019b790(piVar3);
            piVar3[0x75] = piVar3[0x75] + 1;
            piVar3[0x74] = piVar3[0x74] + 1;
            piVar3[0x73] = 0;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5900
// Address: 0x1801c5900
// Size: 160 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x0001801a247b: Changing call to branch
// WARNING: Removing unreachable block (ram,0x0001801a2480)
// WARNING: Removing unreachable block (ram,0x0001801a249e)
// WARNING: Removing unreachable block (ram,0x0001801a2484)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_7ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.1801c4670(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h,
                      int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_a0h,
                      int64_t arg_a8h, int64_t arg_b0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_f0h,
                      int64_t arg_128h, int64_t arg_190h, int64_t arg_1f0h)
{
    int32_t *piVar1;
    int32_t iVar2;
    bool bVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t **ppiVar10;
    int64_t iVar11;
    int64_t *piVar12;
    undefined2 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint64_t uVar16;
    int64_t **ppiVar17;
    int64_t *piVar18;
    int64_t in_RCX;
    int32_t in_EDX;
    int64_t *piVar19;
    uint64_t uVar20;
    int32_t iVar21;
    int64_t iVar22;
    undefined *puVar23;
    undefined8 unaff_RBP;
    int64_t unaff_RSI;
    undefined8 uVar24;
    uint32_t in_R8D;
    uint64_t uVar25;
    int64_t *in_R9;
    undefined2 *puVar26;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_8h;
    undefined8 uStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    code *pcStack_10;
    
    pcStack_10 = (code *)0x1801c4680;
    iVar15 = fcn.18045a350();
    iVar15 = -iVar15;
    // switch table (137 cases) at 0x1801c4de4
    switch(in_EDX) {
    case 3:
        if (in_R9 == (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c46bc;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
            goto code_r0x0001801c46c8;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c46fb;
        iVar9 = fcn.1801bc7c0(*(int64_t *)((int64_t)&var_18h + iVar15));
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4732;
            iVar7 = fcn.180192b80(*(int64_t *)((int64_t)&arg_28h + iVar15));
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4742;
                fcn.18022ecc0(iVar9);
                return 0;
            }
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4708;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4720;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 4:
        if (in_R9 != (int64_t *)0x0) {
            *(int64_t **)((int64_t)&arg_28h + iVar15) = in_R9;
            *(int64_t *)((int64_t)&var_20h + iVar15) = in_RCX + 0x2b0;
            *(int64_t *)((int64_t)&var_18h + iVar15) = in_RCX + 0x2b8;
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c47ea;
            uVar16 = fcn.1801bc970(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&arg_28h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar15), *(int64_t *)((int64_t)&arg_50h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_58h + iVar15), *(int64_t *)((int64_t)&arg_68h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_70h + iVar15), *(int64_t *)((int64_t)&arg_78h + iVar15), 
                                   *(int64_t *)((int64_t)&arg_80h + iVar15));
            return uVar16;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c479b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
code_r0x0001801c46c8:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c46d4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    default:
        goto code_r0x0001801c46e6;
    case 6:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4754;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c476c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0xe:
        iVar9 = *(int64_t *)(in_RCX + 0x110);
        if (iVar9 == 0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cb3;
            iVar9 = fcn.180221f20();
            *(int64_t *)(in_RCX + 0x110) = iVar9;
            if (iVar9 != 0) goto code_r0x0001801c4ce6;
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cc4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        } else {
code_r0x0001801c4ce6:
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cf1;
            iVar7 = fcn.180222110(iVar9, in_R9);
            if (iVar7 != 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cfa;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4cdc;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x36:
        *(int64_t **)(in_RCX + 0x238) = in_R9;
        return 1;
    case 0x3a:
    case 0x3b:
        if (in_R9 == (int64_t *)0x0) {
            return 0x50;
        }
        if (in_R8D == 0x50) {
            if (in_EDX == 0x3b) {
                iVar7 = *(int32_t *)((int64_t)in_R9 + 4);
                iVar21 = *(int32_t *)(in_R9 + 1);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0xc);
                piVar1 = *(int32_t **)(in_RCX + 0x250);
                *(int32_t *)(in_RCX + 0x240) = *(int32_t *)in_R9;
                *(int32_t *)(in_RCX + 0x244) = iVar7;
                *(int32_t *)(in_RCX + 0x248) = iVar21;
                *(int32_t *)(in_RCX + 0x24c) = iVar2;
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x14);
                iVar21 = *(int32_t *)(in_R9 + 3);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x1c);
                *piVar1 = *(int32_t *)(in_R9 + 2);
                piVar1[1] = iVar7;
                piVar1[2] = iVar21;
                piVar1[3] = iVar2;
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x24);
                iVar21 = *(int32_t *)(in_R9 + 5);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x2c);
                piVar1[4] = *(int32_t *)(in_R9 + 4);
                piVar1[5] = iVar7;
                piVar1[6] = iVar21;
                piVar1[7] = iVar2;
                iVar15 = *(int64_t *)(in_RCX + 0x250);
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x34);
                iVar21 = *(int32_t *)(in_R9 + 7);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x3c);
                *(int32_t *)(iVar15 + 0x20) = *(int32_t *)(in_R9 + 6);
                *(int32_t *)(iVar15 + 0x24) = iVar7;
                *(int32_t *)(iVar15 + 0x28) = iVar21;
                *(int32_t *)(iVar15 + 0x2c) = iVar2;
                iVar7 = *(int32_t *)((int64_t)in_R9 + 0x44);
                iVar21 = *(int32_t *)(in_R9 + 9);
                iVar2 = *(int32_t *)((int64_t)in_R9 + 0x4c);
                *(int32_t *)(iVar15 + 0x30) = *(int32_t *)(in_R9 + 8);
                *(int32_t *)(iVar15 + 0x34) = iVar7;
                *(int32_t *)(iVar15 + 0x38) = iVar21;
                *(int32_t *)(iVar15 + 0x3c) = iVar2;
                return 1;
            }
            iVar7 = *(int32_t *)(in_RCX + 0x244);
            iVar21 = *(int32_t *)(in_RCX + 0x248);
            iVar2 = *(int32_t *)(in_RCX + 0x24c);
            *(int32_t *)in_R9 = *(int32_t *)(in_RCX + 0x240);
            *(int32_t *)((int64_t)in_R9 + 4) = iVar7;
            *(int32_t *)(in_R9 + 1) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0xc) = iVar2;
            piVar1 = *(int32_t **)(in_RCX + 0x250);
            iVar7 = piVar1[1];
            iVar21 = piVar1[2];
            iVar2 = piVar1[3];
            *(int32_t *)(in_R9 + 2) = *piVar1;
            *(int32_t *)((int64_t)in_R9 + 0x14) = iVar7;
            *(int32_t *)(in_R9 + 3) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x1c) = iVar2;
            iVar7 = piVar1[5];
            iVar21 = piVar1[6];
            iVar2 = piVar1[7];
            *(int32_t *)(in_R9 + 4) = piVar1[4];
            *(int32_t *)((int64_t)in_R9 + 0x24) = iVar7;
            *(int32_t *)(in_R9 + 5) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x2c) = iVar2;
            iVar15 = *(int64_t *)(in_RCX + 0x250);
            iVar7 = *(int32_t *)(iVar15 + 0x24);
            iVar21 = *(int32_t *)(iVar15 + 0x28);
            iVar2 = *(int32_t *)(iVar15 + 0x2c);
            *(int32_t *)(in_R9 + 6) = *(int32_t *)(iVar15 + 0x20);
            *(int32_t *)((int64_t)in_R9 + 0x34) = iVar7;
            *(int32_t *)(in_R9 + 7) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x3c) = iVar2;
            iVar7 = *(int32_t *)(iVar15 + 0x34);
            iVar21 = *(int32_t *)(iVar15 + 0x38);
            iVar2 = *(int32_t *)(iVar15 + 0x3c);
            *(int32_t *)(in_R9 + 8) = *(int32_t *)(iVar15 + 0x30);
            *(int32_t *)((int64_t)in_R9 + 0x44) = iVar7;
            *(int32_t *)(in_R9 + 9) = iVar21;
            *(int32_t *)((int64_t)in_R9 + 0x4c) = iVar2;
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c482c;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4844;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x40:
        *(int64_t **)(in_RCX + 0x270) = in_R9;
        return 1;
    case 0x41:
        *(uint32_t *)(in_RCX + 0x278) = in_R8D;
        return 1;
    case 0x4e:
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(int64_t **)(in_RCX + 0x340) = in_R9;
        return 1;
    case 0x4f:
        uVar8 = *(undefined8 *)(in_RCX + 0x360);
        *(uint32_t *)(in_RCX + 0x3b4) = *(uint32_t *)(in_RCX + 0x3b4) | 0x20;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c497e;
        fcn.180224990(uVar8, 0x1804b3080, 0x1013);
        *(undefined8 *)(in_RCX + 0x360) = 0;
        if (in_R9 == (int64_t *)0x0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c499a;
        uVar16 = fcn.180498cd0(in_R9);
        if (uVar16 < 0x100) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49aa;
            iVar9 = fcn.180498cd0(in_R9);
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49c5;
                iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15)
                                      , *(int64_t *)((int64_t)&arg_28h + iVar15));
                *(int64_t *)(in_RCX + 0x360) = iVar9;
                if (iVar9 != 0) {
                    return 1;
                }
                *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49da;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
                goto code_r0x0001801c49df;
            }
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a01;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a19;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x50:
        *(uint32_t *)(in_RCX + 0x3b0) = in_R8D;
        return 1;
    case 0x51:
        iVar9 = *(int64_t *)(in_RCX + 0x3a8);
        *(undefined8 *)(in_RCX + 0x358) = 0x1801c31f0;
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a4f;
            fcn.180224990(iVar9, 0x1804b3080, 0x1024);
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a64;
        iVar9 = fcn.1802231e0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                              *(int64_t *)((int64_t)&arg_28h + iVar15));
        *(int64_t *)(in_RCX + 0x3a8) = iVar9;
        if (iVar9 != 0) {
            return 1;
        }
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4a79;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15));
code_r0x0001801c49df:
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c49f2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                      *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                      *(int64_t *)((int64_t)&arg_48h + iVar15));
        break;
    case 0x52:
        iVar15 = *(int64_t *)(in_RCX + 0x110);
        if ((iVar15 != 0) || (in_R8D != 0)) goto code_r0x0001801c4d20;
    case 0x73:
        iVar15 = *(int64_t *)(**(int64_t **)(in_RCX + 0x158) + 0x10);
code_r0x0001801c4d20:
        *in_R9 = iVar15;
        return 1;
    case 0x53:
        uVar8 = *(undefined8 *)(in_RCX + 0x110);
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4d3f;
        fcn.180238640(uVar8);
        *(undefined8 *)(in_RCX + 0x110) = 0;
        return 1;
    case 0x58:
        iVar9 = 0;
        if (in_R8D == 0) {
            piVar19 = *(int64_t **)((int64_t)&arg_48h + iVar15);
            iVar11 = *(int64_t *)((int64_t)&arg_38h + iVar15);
            puVar23 = (undefined *)((int64_t)&arg_40h + iVar15);
        } else {
            piVar19 = *(int64_t **)((int64_t)&arg_48h + iVar15);
            *(int64_t *)((int64_t)&arg_50h + iVar15) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
            *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a2440;
            iVar11 = fcn.18045a350();
            iVar11 = -iVar11;
            if (in_R9 == (int64_t *)0x0) {
                puVar23 = (undefined *)((int64_t)&arg_60h + iVar11 + iVar15);
                unaff_RSI = *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15);
                iVar11 = *(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15);
                in_R9 = (int64_t *)0x0;
            } else {
                *(int64_t **)((int64_t)&arg_68h + iVar11 + iVar15) = piVar19;
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a246a;
                piVar19 = (int64_t *)fcn.180238060(*(int64_t *)((int64_t)&arg_80h + iVar11 + iVar15));
                if (piVar19 == (int64_t *)0x0) {
                    return 0;
                }
                puVar23 = (undefined *)((int64_t)&arg_30h + iVar11 + iVar15 + 0x38 + -0x38);
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15 + 0x38 + -0x38) = 0x1801a2480;
                unaff_RSI = iVar9;
                iVar11 = in_RCX;
                in_R9 = piVar19;
            }
        }
        *(undefined8 *)(puVar23 + 0x20) = unaff_RBP;
        *(int64_t *)(puVar23 + -8) = unaff_RSI;
        *(int64_t *)(puVar23 + -0x10) = iVar11;
        *(undefined8 *)(puVar23 + -0x18) = unaff_R15;
        *(undefined8 *)(puVar23 + -0x20) = 0x1801a2333;
        iVar15 = fcn.18045a350();
        iVar15 = -iVar15;
        if (iVar9 == 0) {
            piVar18 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar18 = *(int64_t **)(iVar9 + 0x878);
        }
        iVar9 = *piVar18;
        if (iVar9 == 0) {
            return 0;
        }
        *(int64_t **)(puVar23 + iVar15 + 0x38) = piVar19;
        *(undefined8 *)(puVar23 + iVar15 + 0x40) = unaff_R12;
        iVar21 = 0;
        *(undefined8 *)(puVar23 + iVar15 + 0x48) = unaff_R14;
        *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a2389;
        iVar7 = fcn.180222010(in_R9);
        if (0 < iVar7) {
            do {
                *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a239a;
                fcn.180222340(in_R9, iVar21);
                *(undefined4 *)(puVar23 + iVar15 + 8) = 0;
                *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23b0;
                iVar7 = fcn.1801a8d20(*(int64_t *)(puVar23 + iVar15 + 0x28), *(int64_t *)(puVar23 + iVar15 + 0x30), 
                                      *(int64_t *)(puVar23 + iVar15 + 0x40), *(int64_t *)(puVar23 + iVar15 + 0x48), 
                                      *(int64_t *)(puVar23 + iVar15 + 0xb8));
                if (iVar7 != 1) {
                    *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23fa;
                    fcn.180229480(*(int64_t *)(puVar23 + iVar15 + 8), *(int64_t *)(puVar23 + iVar15 + 0x10));
                    *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a2412;
                    fcn.1802295a0(*(int64_t *)(puVar23 + iVar15 + 8), *(int64_t *)(puVar23 + iVar15 + 0x10), 
                                  *(int64_t *)(puVar23 + iVar15 + 0x18), *(int64_t *)(puVar23 + iVar15 + 0x20), 
                                  *(int64_t *)(puVar23 + iVar15 + 0x38));
                    *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a2422;
                    fcn.1802296d0(*(int64_t *)(puVar23 + iVar15 + 0x28));
                    return 0;
                }
                iVar21 = iVar21 + 1;
                *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23c2;
                iVar7 = fcn.180222010(in_R9);
            } while (iVar21 < iVar7);
        }
        uVar8 = *(undefined8 *)(iVar9 + 0x10);
        *(undefined8 *)(puVar23 + iVar15 + -0x20) = 0x1801a23cf;
        fcn.180238640(uVar8);
        *(int64_t **)(iVar9 + 0x10) = in_R9;
        return 1;
    case 0x59:
        iVar9 = 0;
        if (in_R8D == 0) {
            uVar8 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
            *(undefined8 *)((int64_t)&arg_58h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
            *(int64_t *)((int64_t)&arg_38h + iVar15) = unaff_RSI;
            *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a17c0;
            iVar11 = fcn.18045a350(0, in_RCX, in_R9);
            iVar11 = -iVar11;
            if (iVar9 == 0) {
                piVar19 = *(int64_t **)(in_RCX + 0x158);
            } else {
                piVar19 = *(int64_t **)(iVar9 + 0x878);
            }
            *(undefined8 *)((int64_t)&arg_78h + iVar11 + iVar15) = unaff_RBP;
            *(undefined8 *)((int64_t)&arg_80h + iVar11 + iVar15) = uVar8;
            iVar9 = *piVar19;
            if (iVar9 != 0) {
                *(undefined4 *)((int64_t)&arg_58h + iVar11 + iVar15) = 0;
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a17fb;
                iVar7 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_80h + iVar11 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_90h + iVar11 + iVar15), 
                                      *(int64_t *)(&stack0x00000098 + iVar11 + iVar15), 
                                      *(int64_t *)(&stack0x00000108 + iVar11 + iVar15));
                if (iVar7 == 1) {
                    iVar22 = *(int64_t *)(iVar9 + 0x10);
                    if (iVar22 == 0) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1853;
                        iVar22 = fcn.180221f20();
                        *(int64_t *)(iVar9 + 0x10) = iVar22;
                        if (iVar22 == 0) {
                            return 0;
                        }
                    }
                    *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1867;
                    iVar7 = fcn.180222110(iVar22, in_R9);
                    return (uint64_t)(iVar7 != 0);
                }
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1807;
                fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a181f;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_88h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a182e;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15));
            }
            return 0;
        }
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a1895;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a18a9;
        uVar16 = fcn.1802375f0(in_R9);
        if ((int32_t)uVar16 == 0) {
            return uVar16;
        }
        *(undefined8 *)((int64_t)&arg_78h + iVar11 + iVar15) = uVar8;
        if (iVar9 == 0) {
            piVar19 = *(int64_t **)(in_RCX + 0x158);
        } else {
            piVar19 = *(int64_t **)(iVar9 + 0x878);
        }
        iVar9 = *piVar19;
        if (iVar9 != 0) {
            *(undefined4 *)((int64_t)&arg_58h + iVar11 + iVar15) = 0;
            *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a18f8;
            iVar7 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_80h + iVar11 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_90h + iVar11 + iVar15), 
                                  *(int64_t *)(&stack0x00000098 + iVar11 + iVar15), 
                                  *(int64_t *)(&stack0x00000108 + iVar11 + iVar15));
            if (iVar7 == 1) {
                iVar22 = *(int64_t *)(iVar9 + 0x10);
                if (iVar22 == 0) {
                    *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1958;
                    iVar22 = fcn.180221f20();
                    *(int64_t *)(iVar9 + 0x10) = iVar22;
                    if (iVar22 == 0) goto code_r0x0001801a192b;
                }
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a196c;
                iVar7 = fcn.180222110(iVar22, in_R9);
                if (iVar7 != 0) {
                    return 1;
                }
            } else {
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1904;
                fcn.180229480(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a191c;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_88h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a192b;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_78h + iVar11 + iVar15));
            }
        }
code_r0x0001801a192b:
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a1933;
        fcn.18021fe80(in_R9);
        return 0;
    case 0x5b:
        *(int64_t *)((int64_t)&arg_30h + iVar15) = (int64_t)(int32_t)in_R8D;
        *(int64_t **)((int64_t)&arg_28h + iVar15) = in_R9;
        *(int64_t *)((int64_t)&var_20h + iVar15) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&var_18h + iVar15) = in_RCX + 0x2b8;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4afe;
        uVar16 = fcn.1801abb30(*(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                               *(int64_t *)((int64_t)&arg_38h + iVar15), *(int64_t *)((int64_t)&arg_40h + iVar15), 
                               *(int64_t *)((int64_t)&arg_48h + iVar15), *(int64_t *)((int64_t)&arg_50h + iVar15), 
                               *(int64_t *)((int64_t)&arg_58h + iVar15), *(int64_t *)((int64_t)&arg_60h + iVar15));
        return uVar16;
    case 0x5c:
        *(int64_t **)((int64_t)&arg_30h + iVar15) = in_R9;
        *(int64_t *)((int64_t)&arg_28h + iVar15) = in_RCX + 0x2b0;
        *(int64_t *)((int64_t)&var_20h + iVar15) = in_RCX + 0x2b8;
        *(int64_t *)((int64_t)&var_18h + iVar15) = in_RCX + 0x2a0;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4b4f;
        uVar16 = fcn.1801abdc0(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                               *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                               *(int64_t *)((int64_t)&arg_68h + iVar15), *(int64_t *)((int64_t)&arg_88h + iVar15), 
                               *(int64_t *)((int64_t)&arg_90h + iVar15));
        return uVar16;
    case 0x61:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 0;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        goto code_r0x0001801ac640;
    case 0x62:
        iVar7 = 0;
        goto code_r0x0001801c4bb0;
    case 0x65:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 1;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
code_r0x0001801ac640:
        uVar16 = (uint64_t)(int32_t)in_R8D;
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = uVar8;
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = uVar24;
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_28h + iVar15) = unaff_R15;
        *(undefined8 *)((int64_t)&var_20h + iVar15) = 0x1801ac65e;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        if ((uVar16 & 1) == 0) {
            *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac697;
            puVar13 = (undefined2 *)fcn.180224ed0(*(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15));
            if (puVar13 != (undefined2 *)0x0) {
                uVar25 = 0;
                puVar26 = puVar13;
                if (uVar16 != 0) {
                    do {
                        iVar21 = *(int32_t *)in_R9;
                        uVar20 = 0;
                        piVar1 = (int32_t *)((int64_t)in_R9 + 4);
                        in_R9 = in_R9 + 1;
                        iVar22 = 0x1804ae0e0;
                        do {
                            if ((*(int32_t *)(iVar22 + 0x14) == iVar21) && (*(int32_t *)(iVar22 + 0x1c) == *piVar1)) {
                                *puVar26 = *(undefined2 *)(iVar22 + 0x10);
                                puVar26 = puVar26 + 1;
                                break;
                            }
                            uVar20 = uVar20 + 1;
                            iVar22 = iVar22 + 0x48;
                        } while (uVar20 < 0x1f);
                        if (uVar20 == 0x1f) {
                            *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac744;
                            fcn.180224990(puVar13, 0x1804aeee0, 0xf47);
                            return 0;
                        }
                        uVar25 = uVar25 + 2;
                    } while (uVar25 < uVar16);
                }
                if (iVar7 == 0) {
                    uVar8 = *(undefined8 *)(iVar9 + 0x40);
                    *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac76e;
                    fcn.180224990(uVar8, 0x1804aeee0, 0xf3f);
                    *(undefined2 **)(iVar9 + 0x40) = puVar13;
                    *(uint64_t *)(iVar9 + 0x48) = uVar16 >> 1;
                    return 1;
                }
                uVar8 = *(undefined8 *)(iVar9 + 0x50);
                *(undefined8 *)((int64_t)&var_20h + iVar11 + iVar15) = 0x1801ac720;
                fcn.180224990(uVar8, 0x1804aeee0, 0xf3b);
                *(undefined2 **)(iVar9 + 0x50) = puVar13;
                *(uint64_t *)(iVar9 + 0x58) = uVar16 >> 1;
                return 1;
            }
        }
        return 0;
    case 0x66:
        iVar7 = 1;
code_r0x0001801c4bb0:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        uVar8 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_28h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&var_20h + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&var_18h + iVar15) = 0x1801ac790;
        iVar11 = fcn.18045a350(in_RCX, iVar9, in_R9);
        iVar11 = -iVar11;
        *(uint64_t *)((int64_t)&arg_e0h + iVar11 + iVar15) =
             *(uint64_t *)0x1806a3940 ^ (int64_t)&var_20h + iVar11 + iVar15;
        *(undefined8 *)((int64_t)&arg_50h + iVar11 + iVar15) = 0;
        iVar22 = *(int64_t *)((int64_t)&arg_d8h + iVar11 + iVar15);
        if (in_RCX != 0) {
            iVar22 = in_RCX;
        }
        *(int64_t *)((int64_t)&arg_d8h + iVar11 + iVar15) = iVar22;
        *(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15) = (int64_t)&arg_50h + iVar11 + iVar15;
        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac7f0;
        iVar21 = fcn.18024a850(*(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15), 
                               *(int64_t *)((int64_t)&arg_50h + iVar11 + iVar15), 
                               *(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                               *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15));
        if (iVar21 != 0) {
            *(undefined8 *)((int64_t)&arg_f0h + iVar11 + iVar15) = uVar8;
            iVar22 = *(int64_t *)((int64_t)&arg_50h + iVar11 + iVar15);
            if (iVar22 == 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac80f;
                fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac827;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_48h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_50h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                              *(int64_t *)((int64_t)&arg_70h + iVar11 + iVar15));
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac840;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15));
            } else if (iVar9 != 0) {
                *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac86d;
                iVar14 = fcn.180224ed0(*(int64_t *)((int64_t)&arg_40h + iVar11 + iVar15));
                if (iVar14 != 0) {
                    *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac886;
                    fcn.180498030(iVar14, (int64_t)&arg_58h + iVar11 + iVar15, iVar22 * 2);
                    if (iVar7 == 0) {
                        uVar8 = *(undefined8 *)(iVar9 + 0x40);
                        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac8ba;
                        fcn.180224990(uVar8, 0x1804aeee0, 0xf17);
                        *(int64_t *)(iVar9 + 0x40) = iVar14;
                        *(int64_t *)(iVar9 + 0x48) = iVar22;
                    } else {
                        uVar8 = *(undefined8 *)(iVar9 + 0x50);
                        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac8a1;
                        fcn.180224990(uVar8, 0x1804aeee0, 0xf13);
                        *(int64_t *)(iVar9 + 0x50) = iVar14;
                        *(int64_t *)(iVar9 + 0x58) = iVar22;
                    }
                }
            }
        }
        *(undefined8 *)((int64_t)&var_18h + iVar11 + iVar15) = 0x1801ac8e1;
        uVar16 = fcn.180459870(*(uint64_t *)((int64_t)&arg_e0h + iVar11 + iVar15) ^ (int64_t)&var_20h + iVar11 + iVar15)
        ;
        return uVar16;
    case 0x68:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        uVar16 = (uint64_t)(int32_t)in_R8D;
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(int64_t *)((int64_t)&arg_50h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801c5915;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        uVar8 = *(undefined8 *)(iVar9 + 0x30);
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801c5937;
        fcn.180224990(uVar8, 0x1804b3080, 0x121c);
        *(undefined8 *)(iVar9 + 0x30) = 0;
        *(undefined8 *)(iVar9 + 0x38) = 0;
        if ((in_R9 != (int64_t *)0x0) && (uVar16 != 0)) {
            if (uVar16 < 0x100) {
                *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801c596c;
                iVar15 = fcn.180223170(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15));
                *(int64_t *)(iVar9 + 0x30) = iVar15;
                if (iVar15 != 0) {
                    *(uint64_t *)(iVar9 + 0x38) = uVar16;
                    return 1;
                }
            }
            return 0;
        }
        return 1;
    case 0x69:
        iVar22 = 0;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(int64_t *)((int64_t)&arg_50h + iVar15) = in_RCX;
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = 0;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = uVar8;
        *(int64_t *)((int64_t)&arg_30h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_28h + iVar15) = uVar24;
        *(undefined8 *)((int64_t)&var_20h + iVar15) = unaff_R12;
        *(undefined8 *)((int64_t)&var_18h + iVar15) = unaff_R13;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&uStackX_10 + iVar15 + -8) = unaff_R15;
        *(undefined8 *)(&stack0x00000000 + iVar15) = 0x1801a141f;
        iVar9 = fcn.18045a350();
        iVar9 = -iVar9;
        iVar11 = 0;
        *(undefined8 *)((int64_t)&arg_b0h + iVar9 + iVar15) = 0;
        if (iVar22 == 0) {
            ppiVar17 = *(int64_t ***)(in_RCX + 0x158);
        } else {
            ppiVar17 = *(int64_t ***)(iVar22 + 0x878);
            in_RCX = *(int64_t *)(iVar22 + 8);
        }
        piVar19 = *ppiVar17;
        *(int64_t **)((int64_t)&arg_48h + iVar9 + iVar15) = piVar19;
        uVar25 = 0;
        uVar5 = 0;
        uVar16 = 0;
        *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15) = in_RCX;
        *(int64_t ***)((int64_t)&arg_38h + iVar9 + iVar15) = ppiVar17;
        *(uint32_t *)((int64_t)&arg_a8h + iVar9 + iVar15) = in_R8D & 4;
        if (*piVar19 == 0) {
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a147d;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1495;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                          *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14a7;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
            uVar16 = uVar25;
code_r0x0001801a1782:
            uVar25 = uVar16;
            if (*(int32_t *)((int64_t)&arg_a8h + iVar9 + iVar15) == 0) goto code_r0x0001801a1794;
        } else {
            if ((in_R8D & 4) == 0) {
                if ((in_R8D & 1) != 0) {
                    *(int64_t *)((int64_t)&arg_b0h + iVar9 + iVar15) = piVar19[2];
                }
code_r0x0001801a1536:
                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a154a;
                iVar11 = fcn.18024c080(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                       *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                if (iVar11 == 0) {
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1557;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a156f;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1581;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                    uVar16 = uVar25;
                } else {
                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a159c;
                    iVar7 = fcn.18024bbe0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15));
                    if (iVar7 == 0) {
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15a5;
                        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15bd;
                        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15cf;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                        uVar16 = uVar25;
                    } else {
                        uVar4 = *(uint32_t *)((int64_t)ppiVar17 + 0x1c);
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15e5;
                        fcn.18024c330(iVar11, uVar4 & 0x30000);
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a15ed;
                        iVar7 = fcn.18024c740(*(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15));
                        if (iVar7 < 1) {
                            if ((in_R8D & 8) == 0) {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16f2;
                                uVar6 = fcn.18024bbd0(iVar11);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16f9;
                                fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1711;
                                fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1718;
                                fcn.180250ec0(uVar6);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1731;
                                fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                                goto code_r0x0001801a1782;
                            }
                            if ((in_R8D & 0x10) != 0) {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1606;
                                fcn.1802203d0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                            }
                            uVar5 = 2;
                        }
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1613;
                        iVar22 = fcn.18024b970(iVar11);
                        *(int64_t *)((int64_t)&arg_b0h + iVar9 + iVar15) = iVar22;
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1626;
                        uVar8 = fcn.1802222a0(*(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15));
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a162e;
                        fcn.18021fe80(uVar8);
                        if ((in_R8D & 2) != 0) {
                            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a163c;
                            iVar7 = fcn.180222010(iVar22);
                            if (0 < iVar7) {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1648;
                                iVar7 = fcn.180222010(iVar22);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1653;
                                uVar8 = fcn.180222340(iVar22, iVar7 + -1);
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a165b;
                                uVar4 = fcn.18023bbb0(uVar8);
                                if ((uVar4 >> 0xd & 1) != 0) {
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1669;
                                    uVar8 = fcn.180222020(iVar22);
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1671;
                                    fcn.18021fe80(uVar8);
                                }
                            }
                        }
                        iVar21 = 0;
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a167b;
                        iVar7 = fcn.180222010(iVar22);
                        if (iVar7 < 1) {
                            iVar14 = piVar19[2];
                            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1774;
                            fcn.180238640(iVar14);
                            piVar19[2] = iVar22;
                            uVar16 = (uint64_t)uVar5;
                            if (uVar5 == 0) {
                                uVar16 = 1;
                            }
                        } else {
                            do {
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a169d;
                                fcn.180222340(iVar22, iVar21);
                                *(undefined4 *)((int64_t)&arg_28h + iVar9 + iVar15) = 0;
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16b6;
                                uVar5 = fcn.1801a8d20(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar15), 
                                                      *(int64_t *)((int64_t)&arg_d8h + iVar9 + iVar15));
                                uVar16 = (uint64_t)uVar5;
                                if (uVar5 != 1) {
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1738;
                                    fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15));
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1750;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_40h + iVar9 + iVar15), 
                                                  *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a175f;
                                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15));
                                    *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1767;
                                    fcn.180238640(iVar22);
                                    uVar16 = 0;
                                    goto code_r0x0001801a1782;
                                }
                                iVar21 = iVar21 + 1;
                                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16c7;
                                iVar7 = fcn.180222010(iVar22);
                            } while (iVar21 < iVar7);
                            iVar22 = *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15);
                            uVar8 = *(undefined8 *)(iVar22 + 0x10);
                            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a16d9;
                            fcn.180238640(uVar8);
                            *(undefined8 *)(iVar22 + 0x10) = *(undefined8 *)((int64_t)&arg_b0h + iVar9 + iVar15);
                        }
                    }
                }
                goto code_r0x0001801a1782;
            }
            *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14b5;
            iVar22 = fcn.18021f3d0(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_48h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_50h + iVar9 + iVar15), 
                                   *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15));
            if (iVar22 != 0) {
                iVar14 = piVar19[2];
                iVar21 = 0;
                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14cc;
                iVar7 = fcn.180222010(iVar14);
                if (0 < iVar7) {
                    do {
                        iVar14 = piVar19[2];
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14db;
                        uVar8 = fcn.180222340(iVar14, iVar21);
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14e6;
                        iVar7 = fcn.18021f070(iVar22, uVar8);
                        if (iVar7 == 0) goto code_r0x0001801a178c;
                        iVar14 = piVar19[2];
                        iVar21 = iVar21 + 1;
                        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a14f9;
                        iVar7 = fcn.180222010(iVar14);
                    } while (iVar21 < iVar7);
                }
                iVar14 = *piVar19;
                *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1508;
                iVar7 = fcn.18021f070(iVar22, iVar14);
                if (iVar7 != 0) {
                    ppiVar17 = *(int64_t ***)((int64_t)&arg_38h + iVar9 + iVar15);
                    goto code_r0x0001801a1536;
                }
            }
        }
code_r0x0001801a178c:
        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a1794;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_28h + iVar9 + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar9 + iVar15)
                      , *(int64_t *)((int64_t)&arg_38h + iVar9 + iVar15), 
                      *(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15), *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15)
                     );
code_r0x0001801a1794:
        *(undefined8 *)(&stack0x00000000 + iVar9 + iVar15) = 0x1801a179c;
        fcn.18024b910(iVar11);
        return uVar25;
    case 0x6a:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 0;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        goto code_r0x0001801a24c0;
    case 0x6b:
        iVar9 = *(int64_t *)(in_RCX + 0x158);
        iVar7 = 1;
        uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        uVar24 = *(undefined8 *)((int64_t)&arg_38h + iVar15);
code_r0x0001801a24c0:
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = uVar24;
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a24d5;
        iVar11 = fcn.18045a350();
        iVar11 = -iVar11;
        if ((in_R8D != 0) && (in_R9 != (int64_t *)0x0)) {
            *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a24f3;
            uVar16 = fcn.18021f5b0(in_R9);
            if ((int32_t)uVar16 == 0) {
                return uVar16;
            }
        }
        *(undefined8 *)((int64_t)&arg_68h + iVar11 + iVar15) = uVar8;
        iVar22 = 0x70;
        if (iVar7 == 0) {
            iVar22 = 0x78;
        }
        *(undefined8 *)((int64_t)&arg_30h + iVar11 + iVar15) = 0x1801a2524;
        fcn.18021f290(*(int64_t *)((int64_t)&arg_58h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_60h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_68h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_88h + iVar11 + iVar15), 
                      *(int64_t *)((int64_t)&arg_90h + iVar11 + iVar15));
        *(int64_t **)(iVar22 + iVar9) = in_R9;
        return 1;
    case 0x74:
        ppiVar17 = *(int64_t ***)(in_RCX + 0x158);
        *(undefined8 *)((int64_t)&arg_48h + iVar15) = *(undefined8 *)((int64_t)&arg_48h + iVar15);
        *(undefined8 *)((int64_t)&arg_50h + iVar15) = unaff_RBP;
        *(int64_t *)((int64_t)&arg_58h + iVar15) = unaff_RSI;
        *(undefined8 *)((int64_t)&arg_60h + iVar15) = *(undefined8 *)((int64_t)&arg_38h + iVar15);
        *(undefined8 *)((int64_t)&arg_38h + iVar15) = unaff_R14;
        *(undefined8 *)((int64_t)&arg_30h + iVar15) = 0x1801a2280;
        iVar9 = fcn.18045a350();
        iVar9 = -iVar9;
        if (in_R9 != (int64_t *)0x0) {
            piVar19 = (int64_t *)0x0;
            if (ppiVar17[5] != (int64_t *)0x0) {
                ppiVar10 = (int64_t **)ppiVar17[4];
                piVar18 = piVar19;
                do {
                    if ((*ppiVar10 == in_R9) && (ppiVar10[1] != (int64_t *)0x0)) {
                        *ppiVar17 = (int64_t *)ppiVar10;
                        return 1;
                    }
                    piVar18 = (int64_t *)((int64_t)piVar18 + 1);
                    ppiVar10 = ppiVar10 + 5;
                    piVar12 = piVar19;
                } while (piVar18 < ppiVar17[5]);
                do {
                    piVar18 = (int64_t *)((int64_t)ppiVar17[4] + (int64_t)piVar12);
                    if ((piVar18[1] != 0) && (*piVar18 != 0)) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar9 + iVar15) = 0x1801a22de;
                        iVar7 = fcn.180238200(*(int64_t *)((int64_t)&arg_58h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_60h + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_68h + iVar9 + iVar15), 
                                              *(int64_t *)(&stack0x00000098 + iVar9 + iVar15), 
                                              *(int64_t *)((int64_t)&arg_a0h + iVar9 + iVar15), 
                                              *(int64_t *)(&stack0x00000108 + iVar9 + iVar15), 
                                              *(int64_t *)(&stack0x00000150 + iVar9 + iVar15));
                        if (iVar7 == 0) {
                            *ppiVar17 = piVar18;
                            return 1;
                        }
                    }
                    piVar19 = (int64_t *)((int64_t)piVar19 + 1);
                    piVar12 = piVar12 + 5;
                } while (piVar19 < ppiVar17[5]);
            }
        }
        return 0;
    case 0x75:
        ppiVar17 = *(int64_t ***)(in_RCX + 0x158);
        if (ppiVar17 != (int64_t **)0x0) {
            if (in_R8D == 1) {
                piVar18 = ppiVar17[5];
                piVar19 = (int64_t *)0x0;
                if (piVar18 != (int64_t *)0x0) {
code_r0x0001801a25ab:
                    piVar12 = ppiVar17[4] + (int64_t)piVar19 * 5;
                    while ((*piVar12 == 0 || (piVar12[1] == 0))) {
                        piVar19 = (int64_t *)((int64_t)piVar19 + 1);
                        piVar12 = piVar12 + 5;
                        if (piVar18 <= piVar19) {
                            return 0;
                        }
                    }
                    *ppiVar17 = piVar12;
                    return 1;
                }
            } else if ((in_R8D == 2) &&
                      (piVar19 = (int64_t *)(((int64_t)*ppiVar17 - (int64_t)ppiVar17[4]) / 0x28 + 1),
                      piVar19 < ppiVar17[5])) {
                piVar18 = ppiVar17[5];
                goto code_r0x0001801a25ab;
            }
        }
        return 0;
    case 0x76:
        *(uint32_t *)(*(int64_t *)(in_RCX + 0x158) + 0x18) = in_R8D;
        return 1;
    case 0x7f:
        return (uint64_t)*(uint32_t *)(in_RCX + 0x278);
    case 0x80:
        *in_R9 = *(int64_t *)(in_RCX + 0x268);
        return 1;
    case 0x81:
        *in_R9 = *(int64_t *)(in_RCX + 0x270);
        return 1;
    case 0x89:
        iVar15 = *(int64_t *)(in_RCX + 0x158);
        bVar3 = false;
        goto code_r0x0001801a1fc0;
    case 0x8a:
        iVar15 = *(int64_t *)(in_RCX + 0x158);
        bVar3 = true;
code_r0x0001801a1fc0:
        iVar9 = 0x70;
        if (!bVar3) {
            iVar9 = 0x78;
        }
        *in_R9 = *(int64_t *)(iVar9 + iVar15);
        return 1;
    case 0x8b:
        *(int64_t **)((int64_t)&var_20h + iVar15) = in_R9;
        *(uint32_t *)((int64_t)&var_18h + iVar15) = in_R8D;
        *(undefined8 *)((int64_t)&pcStack_10 + iVar15) = 0x1801c4b83;
        uVar16 = fcn.1801ab100(*(int64_t *)((int64_t)&var_18h + iVar15), *(int64_t *)((int64_t)&var_20h + iVar15), 
                               *(int64_t *)((int64_t)&arg_28h + iVar15), *(int64_t *)((int64_t)&arg_30h + iVar15), 
                               *(int64_t *)((int64_t)&arg_40h + iVar15), *(int64_t *)((int64_t)&arg_88h + iVar15), 
                               *(int64_t *)((int64_t)&arg_90h + iVar15));
        return uVar16;
    }
    *(code **)((int64_t)&pcStack_10 + iVar15) = case.0x1801c46af.5;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar15));
code_r0x0001801c46e6:
    return 0;
}

// ============================================================
// Function: FUN_1801c59a0
// Address: 0x1801c59a0
// Size: 330 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801c59a0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int32_t *in_RCX;
    int32_t *piVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c59b5;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar5 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar5 = in_RCX;
        }
        if (piVar5 != (int32_t *)0x0) {
            if (piVar5[0x20] == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c59e8;
                iVar3 = func_0x00018019b250();
                if (iVar3 == 0) {
                    uVar1 = piVar5[0x21];
                    if ((uVar1 & 1) == 0) {
                        piVar5[0x21] = uVar1 | 1;
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5a13;
                        func_0x0001801c6e50(piVar5, 1, 0);
                        if (0 < piVar5[0x71]) {
                            return 0xffffffff;
                        }
                    } else if (piVar5[0x71] < 1) {
                        if ((uVar1 & 2) == 0) {
                            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x80);
                            *(int64_t *)((int64_t)&arg_28h + iVar4) = (int64_t)&arg_48h + iVar4;
                            *(undefined4 *)((int64_t)&var_20h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5a97;
                            (*pcVar2)(in_RCX, 0, 0, 0);
                            if ((*(uint8_t *)(piVar5 + 0x21) & 2) == 0) {
                                return 0xffffffff;
                            }
                        }
                    } else {
                        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 6) + 0x90);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c5a60;
                        iVar3 = (*pcVar2)(in_RCX);
                        if (iVar3 == -1) {
                            return 0xffffffff;
                        }
                    }
                    if (piVar5[0x21] != 3) {
                        return 0;
                    }
                    return (uint64_t)(piVar5[0x71] == 0);
                }
            }
            piVar5[0x21] = 3;
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5af0
// Address: 0x1801c5af0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801c5af0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t *in_RCX;
    undefined in_DL;
    unkbyte7 in_RDX;
    int32_t *piVar6;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c5b09;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b3a;
            (*(code *)0x69a006)(0);
            if (piVar6[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b6a;
                    iVar3 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b7a;
                        iVar3 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b86;
                            iVar3 = func_0x00018019b2a0(in_RCX);
                            if (iVar3 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b92;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = in_R9;
            pcVar2 = *(code **)(iVar1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5bcb;
            uVar5 = (*pcVar2)(in_RCX, 0x17, CONCAT71(in_RDX, in_DL), in_R8);
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5b60
// Address: 0x1801c5b60
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801c5af0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t *in_RCX;
    undefined in_DL;
    unkbyte7 in_RDX;
    int32_t *piVar6;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c5b09;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b3a;
            (*(code *)0x69a006)(0);
            if (piVar6[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b6a;
                    iVar3 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b7a;
                        iVar3 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b86;
                            iVar3 = func_0x00018019b2a0(in_RCX);
                            if (iVar3 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b92;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = in_R9;
            pcVar2 = *(code **)(iVar1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5bcb;
            uVar5 = (*pcVar2)(in_RCX, 0x17, CONCAT71(in_RDX, in_DL), in_R8);
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5bad
// Address: 0x1801c5bad
// Size: 54 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801c5af0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int32_t *in_RCX;
    undefined in_DL;
    unkbyte7 in_RDX;
    int32_t *piVar6;
    undefined8 unaff_RSI;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c5b09;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX != (int32_t *)0x0) {
        piVar6 = (int32_t *)0x0;
        if (*in_RCX == 0) {
            piVar6 = in_RCX;
        }
        if (piVar6 != (int32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b3a;
            (*(code *)0x69a006)(0);
            if (piVar6[0x73] != 0) {
                piVar6 = (int32_t *)0x0;
                if (*in_RCX == 0) {
                    piVar6 = in_RCX;
                }
                if ((piVar6 != (int32_t *)0x0) && (piVar6[0x73] != 0)) {
                    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b6a;
                    iVar3 = func_0x0001801a2fb0(piVar6 + 0x314);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b7a;
                        iVar3 = func_0x0001801a31f0(piVar6 + 0x314);
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b86;
                            iVar3 = func_0x00018019b2a0(in_RCX);
                            if (iVar3 == 0) {
                                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5b92;
                                func_0x00018019b790(piVar6);
                                piVar6[0x75] = piVar6[0x75] + 1;
                                piVar6[0x74] = piVar6[0x74] + 1;
                                piVar6[0x73] = 0;
                            }
                        }
                    }
                }
            }
            iVar1 = *(int64_t *)(in_RCX + 6);
            *(undefined8 *)((int64_t)&var_8h + iVar4) = in_R9;
            pcVar2 = *(code **)(iVar1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5bcb;
            uVar5 = (*pcVar2)(in_RCX, 0x17, CONCAT71(in_RDX, in_DL), in_R8);
            return uVar5;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801c5bf0
// Address: 0x1801c5bf0
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801c5bf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 in_R8;
    undefined8 uVar9;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c5c09;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = 0;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c2c;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c44;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c5a;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    uVar5 = *puVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c75;
    uVar5 = func_0x000180259210(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c82;
    iVar2 = func_0x00018026e0a0(uVar5, 0);
    if (iVar2 < 1) {
code_r0x0001801c5d4f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d54;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        uVar6 = uVar7;
code_r0x0001801c5d59:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d6c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = 0xc0103;
    } else {
        *(undefined8 *)((int64_t)&iStackX_10 + iVar4 + -8) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ca1;
        iVar2 = func_0x00018026dfc0(uVar5, 0, (int64_t)&arg_38h + iVar4, in_R8);
        if (iVar2 < 1) goto code_r0x0001801c5d4f;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5cc0;
        uVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        if (uVar6 != 0) {
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4 + -8) = in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d08;
            iVar2 = func_0x00018026dfc0(uVar5, uVar6, (int64_t)&arg_38h + iVar4, in_R8);
            if (0 < iVar2) {
                if (*(int32_t *)((int64_t)&arg_58h + iVar4) == 0) {
                    uVar9 = *(undefined8 *)((int64_t)&arg_38h + iVar4);
                    *(uint64_t *)(in_RCX + 0x3b0) = uVar6;
                    *(undefined8 *)(in_RCX + 0x3b8) = uVar9;
                    uVar8 = 1;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d2e;
                    uVar3 = func_0x0001801c68f0(in_RCX, uVar6, *(undefined8 *)((int64_t)&arg_38h + iVar4));
                    uVar8 = (uint64_t)uVar3;
                    uVar7 = uVar6;
                }
                goto code_r0x0001801c5d82;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d11;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
            goto code_r0x0001801c5d59;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ccd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ce5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = 0x8000f;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d82;
    func_0x00018019b5e0(in_RCX, 0x50, uVar9, 0);
    uVar8 = uVar7;
    uVar7 = uVar6;
code_r0x0001801c5d82:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d9c;
    func_0x000180224b90(uVar7, *(undefined8 *)((int64_t)&arg_38h + iVar4), 0x1804b3080, 0x143a);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5da4;
    func_0x000180258be0(uVar5);
    return uVar8;
}

// ============================================================
// Function: FUN_1801c5c6b
// Address: 0x1801c5c6b
// Size: 320 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801c5bf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 in_R8;
    undefined8 uVar9;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c5c09;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = 0;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c2c;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c44;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c5a;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    uVar5 = *puVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c75;
    uVar5 = func_0x000180259210(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c82;
    iVar2 = func_0x00018026e0a0(uVar5, 0);
    if (iVar2 < 1) {
code_r0x0001801c5d4f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d54;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        uVar6 = uVar7;
code_r0x0001801c5d59:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d6c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = 0xc0103;
    } else {
        *(undefined8 *)((int64_t)&iStackX_10 + iVar4 + -8) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ca1;
        iVar2 = func_0x00018026dfc0(uVar5, 0, (int64_t)&arg_38h + iVar4, in_R8);
        if (iVar2 < 1) goto code_r0x0001801c5d4f;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5cc0;
        uVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        if (uVar6 != 0) {
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4 + -8) = in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d08;
            iVar2 = func_0x00018026dfc0(uVar5, uVar6, (int64_t)&arg_38h + iVar4, in_R8);
            if (0 < iVar2) {
                if (*(int32_t *)((int64_t)&arg_58h + iVar4) == 0) {
                    uVar9 = *(undefined8 *)((int64_t)&arg_38h + iVar4);
                    *(uint64_t *)(in_RCX + 0x3b0) = uVar6;
                    *(undefined8 *)(in_RCX + 0x3b8) = uVar9;
                    uVar8 = 1;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d2e;
                    uVar3 = func_0x0001801c68f0(in_RCX, uVar6, *(undefined8 *)((int64_t)&arg_38h + iVar4));
                    uVar8 = (uint64_t)uVar3;
                    uVar7 = uVar6;
                }
                goto code_r0x0001801c5d82;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d11;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
            goto code_r0x0001801c5d59;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ccd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ce5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = 0x8000f;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d82;
    func_0x00018019b5e0(in_RCX, 0x50, uVar9, 0);
    uVar8 = uVar7;
    uVar7 = uVar6;
code_r0x0001801c5d82:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d9c;
    func_0x000180224b90(uVar7, *(undefined8 *)((int64_t)&arg_38h + iVar4), 0x1804b3080, 0x143a);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5da4;
    func_0x000180258be0(uVar5);
    return uVar8;
}

// ============================================================
// Function: FUN_1801c5dab
// Address: 0x1801c5dab
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

uint64_t fcn.1801c5bf0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined8 in_R8;
    undefined8 uVar9;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x1801c5c09;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = 0;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c2c;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c44;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c5a;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    uVar5 = *puVar1;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c75;
    uVar5 = func_0x000180259210(uVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5c82;
    iVar2 = func_0x00018026e0a0(uVar5, 0);
    if (iVar2 < 1) {
code_r0x0001801c5d4f:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d54;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        uVar6 = uVar7;
code_r0x0001801c5d59:
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d6c;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = 0xc0103;
    } else {
        *(undefined8 *)((int64_t)&iStackX_10 + iVar4 + -8) = in_R9;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ca1;
        iVar2 = func_0x00018026dfc0(uVar5, 0, (int64_t)&arg_38h + iVar4, in_R8);
        if (iVar2 < 1) goto code_r0x0001801c5d4f;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5cc0;
        uVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        if (uVar6 != 0) {
            *(undefined8 *)((int64_t)&iStackX_10 + iVar4 + -8) = in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d08;
            iVar2 = func_0x00018026dfc0(uVar5, uVar6, (int64_t)&arg_38h + iVar4, in_R8);
            if (0 < iVar2) {
                if (*(int32_t *)((int64_t)&arg_58h + iVar4) == 0) {
                    uVar9 = *(undefined8 *)((int64_t)&arg_38h + iVar4);
                    *(uint64_t *)(in_RCX + 0x3b0) = uVar6;
                    *(undefined8 *)(in_RCX + 0x3b8) = uVar9;
                    uVar8 = 1;
                } else {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d2e;
                    uVar3 = func_0x0001801c68f0(in_RCX, uVar6, *(undefined8 *)((int64_t)&arg_38h + iVar4));
                    uVar8 = (uint64_t)uVar3;
                    uVar7 = uVar6;
                }
                goto code_r0x0001801c5d82;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d11;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
            goto code_r0x0001801c5d59;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ccd;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5ce5;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_10 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_10 + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = 0x8000f;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d82;
    func_0x00018019b5e0(in_RCX, 0x50, uVar9, 0);
    uVar8 = uVar7;
    uVar7 = uVar6;
code_r0x0001801c5d82:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5d9c;
    func_0x000180224b90(uVar7, *(undefined8 *)((int64_t)&arg_38h + iVar4), 0x1804b3080, 0x143a);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1801c5da4;
    func_0x000180258be0(uVar5);
    return uVar8;
}

// ============================================================
// Function: FUN_1801c5dc0
// Address: 0x1801c5dc0
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801c5dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBP;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 uVar10;
    int32_t in_R9D;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801c5dd7;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    if ((in_RDX == 0) || (in_R8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fc5;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fdd;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ff3;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    uVar5 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e19;
    uVar5 = func_0x000180259210(uVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e24;
    iVar2 = func_0x0001802498b0(uVar5);
    if (iVar2 < 1) {
code_r0x0001801c5f52:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f57;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f6f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        uVar10 = 0xc0103;
        uVar6 = uVar8;
code_r0x0001801c5f75:
        uVar7 = 0x50;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e37;
        iVar2 = func_0x000180249d50(uVar5, in_R8);
        if (iVar2 < 1) goto code_r0x0001801c5f52;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e4e;
        iVar2 = func_0x000180249670(uVar5, 0, (int64_t)&arg_28h + iVar4);
        if (iVar2 < 1) goto code_r0x0001801c5f52;
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e86;
            iVar2 = fcn.18022fc40(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4))
            ;
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e97;
                func_0x00018026db10(uVar5, 1);
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5eae;
        uVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        if (uVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ebb;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ed3;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
            uVar10 = 0x8000f;
            goto code_r0x0001801c5f75;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5eee;
        iVar2 = func_0x000180249670(uVar5, uVar6, (int64_t)&arg_28h + iVar4);
        if (0 < iVar2) {
            if (in_R9D == 0) {
                uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                *(uint64_t *)(in_RCX + 0x3b0) = uVar6;
                *(undefined8 *)(in_RCX + 0x3b8) = uVar10;
                uVar9 = 1;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f31;
                uVar3 = func_0x0001801c68f0(in_RCX, uVar6, *(undefined8 *)((int64_t)&arg_28h + iVar4));
                uVar9 = (uint64_t)uVar3;
                uVar8 = uVar6;
            }
            goto code_r0x0001801c5f85;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ef7;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f0f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        uVar7 = 0x2f;
        uVar10 = 0x6c;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f85;
    func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
    uVar9 = uVar8;
    uVar8 = uVar6;
code_r0x0001801c5f85:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f9f;
    func_0x000180224b90(uVar8, *(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b3080, 0x1406);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fa7;
    func_0x000180258be0(uVar5);
    return uVar9;
}

// ============================================================
// Function: FUN_1801c5e05
// Address: 0x1801c5e05
// Size: 443 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801c5dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBP;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 uVar10;
    int32_t in_R9D;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801c5dd7;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    if ((in_RDX == 0) || (in_R8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fc5;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fdd;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ff3;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    uVar5 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e19;
    uVar5 = func_0x000180259210(uVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e24;
    iVar2 = func_0x0001802498b0(uVar5);
    if (iVar2 < 1) {
code_r0x0001801c5f52:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f57;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f6f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        uVar10 = 0xc0103;
        uVar6 = uVar8;
code_r0x0001801c5f75:
        uVar7 = 0x50;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e37;
        iVar2 = func_0x000180249d50(uVar5, in_R8);
        if (iVar2 < 1) goto code_r0x0001801c5f52;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e4e;
        iVar2 = func_0x000180249670(uVar5, 0, (int64_t)&arg_28h + iVar4);
        if (iVar2 < 1) goto code_r0x0001801c5f52;
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e86;
            iVar2 = fcn.18022fc40(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4))
            ;
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e97;
                func_0x00018026db10(uVar5, 1);
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5eae;
        uVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        if (uVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ebb;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ed3;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
            uVar10 = 0x8000f;
            goto code_r0x0001801c5f75;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5eee;
        iVar2 = func_0x000180249670(uVar5, uVar6, (int64_t)&arg_28h + iVar4);
        if (0 < iVar2) {
            if (in_R9D == 0) {
                uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                *(uint64_t *)(in_RCX + 0x3b0) = uVar6;
                *(undefined8 *)(in_RCX + 0x3b8) = uVar10;
                uVar9 = 1;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f31;
                uVar3 = func_0x0001801c68f0(in_RCX, uVar6, *(undefined8 *)((int64_t)&arg_28h + iVar4));
                uVar9 = (uint64_t)uVar3;
                uVar8 = uVar6;
            }
            goto code_r0x0001801c5f85;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ef7;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f0f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        uVar7 = 0x2f;
        uVar10 = 0x6c;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f85;
    func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
    uVar9 = uVar8;
    uVar8 = uVar6;
code_r0x0001801c5f85:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f9f;
    func_0x000180224b90(uVar8, *(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b3080, 0x1406);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fa7;
    func_0x000180258be0(uVar5);
    return uVar9;
}

// ============================================================
// Function: FUN_1801c5fc0
// Address: 0x1801c5fc0
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.1801c5dc0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 *puVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    undefined8 uVar5;
    uint64_t uVar6;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar7;
    undefined8 unaff_RBP;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t in_R8;
    undefined8 uVar10;
    int32_t in_R9D;
    int64_t aiStackX_8 [2];
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801c5dd7;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = 0;
    if ((in_RDX == 0) || (in_R8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fc5;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fdd;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ff3;
        func_0x00018019b5e0(in_RCX, 0x50, 0xc0103, 0);
        return 0;
    }
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RBP;
    uVar5 = *puVar1;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e19;
    uVar5 = func_0x000180259210(uVar5);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e24;
    iVar2 = func_0x0001802498b0(uVar5);
    if (iVar2 < 1) {
code_r0x0001801c5f52:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f57;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f6f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        uVar10 = 0xc0103;
        uVar6 = uVar8;
code_r0x0001801c5f75:
        uVar7 = 0x50;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e37;
        iVar2 = func_0x000180249d50(uVar5, in_R8);
        if (iVar2 < 1) goto code_r0x0001801c5f52;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e4e;
        iVar2 = func_0x000180249670(uVar5, 0, (int64_t)&arg_28h + iVar4);
        if (iVar2 < 1) goto code_r0x0001801c5f52;
        if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
            (iVar2 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar2)) && (iVar2 != 0x10000)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e86;
            iVar2 = fcn.18022fc40(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4)
                                  , *(int64_t *)((int64_t)aiStackX_8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), *(int64_t *)(&stack0x00000050 + iVar4))
            ;
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5e97;
                func_0x00018026db10(uVar5, 1);
            }
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5eae;
        uVar6 = fcn.1802248d0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        if (uVar6 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ebb;
            fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ed3;
            fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4));
            uVar10 = 0x8000f;
            goto code_r0x0001801c5f75;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5eee;
        iVar2 = func_0x000180249670(uVar5, uVar6, (int64_t)&arg_28h + iVar4);
        if (0 < iVar2) {
            if (in_R9D == 0) {
                uVar10 = *(undefined8 *)((int64_t)&arg_28h + iVar4);
                *(uint64_t *)(in_RCX + 0x3b0) = uVar6;
                *(undefined8 *)(in_RCX + 0x3b8) = uVar10;
                uVar9 = 1;
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f31;
                uVar3 = func_0x0001801c68f0(in_RCX, uVar6, *(undefined8 *)((int64_t)&arg_28h + iVar4));
                uVar9 = (uint64_t)uVar3;
                uVar8 = uVar6;
            }
            goto code_r0x0001801c5f85;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5ef7;
        fcn.180229480(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f0f;
        fcn.1802295a0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar4));
        uVar7 = 0x2f;
        uVar10 = 0x6c;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f85;
    func_0x00018019b5e0(in_RCX, uVar7, uVar10, 0);
    uVar9 = uVar8;
    uVar8 = uVar6;
code_r0x0001801c5f85:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5f9f;
    func_0x000180224b90(uVar8, *(undefined8 *)((int64_t)&arg_28h + iVar4), 0x1804b3080, 0x1406);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c5fa7;
    func_0x000180258be0(uVar5);
    return uVar9;
}

// ============================================================
// Function: FUN_1801c6010
// Address: 0x1801c6010
// Size: 619 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

int32_t fcn.1801c6010(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                     int64_t arg_98h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t *in_R8;
    undefined8 *in_R9;
    undefined8 unaff_R14;
    int64_t aiStackX_8 [3];
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x1801c6026;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = 0;
    iVar7 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = 0;
    if (in_RDX == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6050;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6068;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c607e;
        fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar4 + 0x10));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c60a5;
    uVar5 = fcn.180259210(*(int64_t *)((int64_t)&var_8h + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c60b2;
    iVar2 = fcn.18026e190(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 0x10), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)(&stack0x00000078 + iVar4), 
                          *(int64_t *)(&stack0x00000080 + iVar4), *(int64_t *)(&stack0x00000088 + iVar4), 
                          *(int64_t *)(&stack0x00000090 + iVar4), *(int64_t *)(&stack0x00000138 + iVar4));
    if (iVar2 < 1) {
code_r0x0001801c61f9:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c61fe;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6216;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar4));
    } else {
        *(int64_t *)((int64_t)&var_8h + iVar4) = (int64_t)&arg_38h + iVar4;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c60d6;
        iVar2 = fcn.18026e0d0(uVar5, 0, (int64_t)&arg_40h + iVar4, 0);
        if (((iVar2 < 1) || (*(int64_t *)((int64_t)&arg_38h + iVar4) == 0)) ||
           (*(int64_t *)((int64_t)&arg_40h + iVar4) == 0)) goto code_r0x0001801c61f9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6109;
        iVar6 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6123;
        iVar7 = fcn.1802248d0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
        if ((iVar6 == 0) || (iVar7 == 0)) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c61d9;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c61f1;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
        } else {
            *(int64_t *)((int64_t)&var_8h + iVar4) = (int64_t)&arg_38h + iVar4;
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6155;
            iVar2 = fcn.18026e0d0(uVar5, iVar7, (int64_t)&arg_40h + iVar4, iVar6);
            if (0 < iVar2) {
                if (*(int32_t *)((int64_t)&arg_58h + iVar4) == 0) {
                    uVar1 = *(undefined8 *)((int64_t)&arg_38h + iVar4);
                    iVar3 = 1;
                    *(int64_t *)(in_RCX + 0x3b0) = iVar6;
                    *(undefined8 *)(in_RCX + 0x3b8) = uVar1;
                } else {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c619f;
                    iVar3 = fcn.1801c68f0(*(int64_t *)((int64_t)aiStackX_8 + iVar4), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                                          *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 0x10), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_58h + iVar4), 
                                          *(int64_t *)(&stack0x00000060 + iVar4), *(int64_t *)(&stack0x000000e0 + iVar4)
                                         );
                    if (iVar3 < 1) goto code_r0x0001801c622c;
                }
                uVar1 = *(undefined8 *)((int64_t)&arg_40h + iVar4);
                *in_R8 = iVar7;
                iVar7 = 0;
                *in_R9 = uVar1;
                goto code_r0x0001801c622c;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c615e;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6176;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_8 + iVar4), *(int64_t *)((int64_t)aiStackX_8 + iVar4 + 8), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
        }
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c622c;
    fcn.18019b5e0(*(int64_t *)((int64_t)aiStackX_8 + iVar4 + 0x10));
code_r0x0001801c622c:
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6246;
    fcn.180224b90(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)(&stack0x00000000 + iVar4));
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c625b;
    fcn.180224990(iVar7, 0x1804b3080, 0x1477);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x1801c6263;
    fcn.180258be0(uVar5);
    return iVar3;
}

// ============================================================
// Function: FUN_1801c6280
// Address: 0x1801c6280
// Size: 247 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.1801c6280(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t in_RCX;
    int32_t in_EDX;
    undefined *puVar6;
    undefined *in_R8;
    uint64_t in_R9;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c6295;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_R9 < 4) {
        return 0;
    }
    uVar2 = *(uint32_t *)(in_RCX + 0x9b0) >> 5;
    if (in_EDX != 0) {
        uVar2 = *(uint32_t *)(in_RCX + 0x9b0) >> 6;
    }
    puVar6 = in_R8;
    uVar5 = in_R9;
    if ((uVar2 & 1) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c62d5;
        uVar3 = func_0x000180467bd4(0);
        in_R8[3] = (char)uVar3;
        *in_R8 = (char)((uint32_t)uVar3 >> 0x18);
        in_R8[1] = (char)((uint32_t)uVar3 >> 0x10);
        in_R8[2] = (char)((uint32_t)uVar3 >> 8);
        puVar6 = in_R8 + 4;
        uVar5 = in_R9 - 4;
    }
    uVar1 = **(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801c6311;
    uVar5 = func_0x00018021b9c0(uVar1, puVar6, uVar5, 0);
    if (0 < (int32_t)uVar5) {
        if (in_R9 < 9) {
            return 0;
        }
        if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 1) {
            *(undefined8 *)(in_R8 + (in_R9 - 8)) = 0x14452474e574f44;
            return uVar5;
        }
        if (*(int32_t *)((int64_t)&arg_48h + iVar4) == 2) {
            *(undefined8 *)(in_R8 + (in_R9 - 8)) = 0x4452474e574f44;
        }
    }
    return uVar5 & 0xffffffff;
}

// ============================================================
// Function: FUN_1801c6380
// Address: 0x1801c6380
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c63a1
// Address: 0x1801c63a1
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c63b1
// Address: 0x1801c63b1
// Size: 395 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c653c
// Address: 0x1801c653c
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c6578
// Address: 0x1801c6578
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c6590
// Address: 0x1801c6590
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801c6590(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c65aa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c65c3;
    iVar7 = func_0x0001801ab700(puVar1);
    if (iVar7 != 0) {
        uVar2 = puVar1[0x8c];
        uVar3 = *(undefined8 *)(iVar7 + 0x10);
        uVar4 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c65e2;
        iVar8 = func_0x0001802591e0(uVar4, uVar3, uVar2);
        if (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c65f2;
            iVar5 = func_0x00018025aed0(iVar8);
            if (0 < iVar5) {
                uVar2 = *(undefined8 *)(iVar7 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6602;
                iVar5 = func_0x00018020fa70(iVar8, uVar2);
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c660b;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6623;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6639;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6648;
                    iVar5 = func_0x00018025ae70(iVar8, (int64_t)&arg_28h + iVar6);
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6656;
                        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_28h + iVar6));
                        *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6667;
    fcn.180258be0(iVar8);
    return *(undefined8 *)((int64_t)&arg_28h + iVar6);
}

// ============================================================
// Function: FUN_1801c6690
// Address: 0x1801c6690
// Size: 137 bytes
// ============================================================
undefined8 fcn.1801c6690(int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801c669a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0;
    if (in_RDX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c66ca;
    iVar3 = fcn.180259210(*(int64_t *)((int64_t)&var_20h + iVar2));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c66da;
        iVar1 = fcn.18025abd0(*(int64_t *)((int64_t)&var_20h + iVar2));
        if (0 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c66eb;
            iVar1 = fcn.18025ab70(*(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                                  *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2));
            if (iVar1 < 1) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c66f9;
                fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_30h + iVar2));
                *(undefined8 *)((int64_t)&arg_30h + iVar2) = 0;
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x1801c670a;
    fcn.180258be0(iVar3);
    return *(undefined8 *)((int64_t)&arg_30h + iVar2);
}

// ============================================================
// Function: FUN_1801c6720
// Address: 0x1801c6720
// Size: 458 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801c6720(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801c673b;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar1 = *(undefined8 **)(in_RCX + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c674d;
    iVar7 = func_0x0001801ab700(puVar1);
    iVar8 = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6761;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6779;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                      *(int64_t *)(&stack0x00000048 + iVar6));
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c678f;
        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
    } else {
        uVar2 = puVar1[0x8c];
        uVar3 = *(undefined8 *)(iVar7 + 0x10);
        uVar4 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c67a7;
        iVar8 = func_0x0001802591e0(uVar4, uVar3, uVar2);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c67b4;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c67cc;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                          *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                          *(int64_t *)(&stack0x00000048 + iVar6));
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c67e2;
            fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c67ef;
            iVar5 = fcn.18025abd0(*(int64_t *)((int64_t)&var_18h + iVar6));
            if (iVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c67f8;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6810;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                              *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)(&stack0x00000048 + iVar6));
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6826;
                fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
            } else {
                uVar2 = *(undefined8 *)(iVar7 + 8);
                *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6837;
                iVar5 = func_0x00018020fa70(iVar8, uVar2);
                if (iVar5 < 1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6840;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6858;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar6));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c686e;
                    fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c687d;
                    iVar5 = fcn.18025ab70(*(int64_t *)((int64_t)&var_20h + iVar6), 
                                          *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6)
                                          , *(int64_t *)(&stack0x00000060 + iVar6));
                    if (iVar5 < 1) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c6886;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c689e;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_20h + iVar6), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                                      *(int64_t *)(&stack0x00000048 + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c68b4;
                        fcn.18019b5e0(*(int64_t *)((int64_t)&arg_38h + iVar6));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c68be;
                        fcn.18022ecc0(*(undefined8 *)((int64_t)&arg_28h + iVar6));
                        *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801c68cf;
    fcn.180258be0(iVar8);
    return *(undefined8 *)((int64_t)&arg_28h + iVar6);
}

// ============================================================
// Function: FUN_1801c68f0
// Address: 0x1801c68f0
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c6943
// Address: 0x1801c6943
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

// ============================================================
// Function: FUN_1801c697f
// Address: 0x1801c697f
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8
fcn.1801c68f0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
             int64_t arg_78h, int64_t arg_88h, int64_t arg_90h, int64_t arg_110h)
{
    undefined *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    code *pcVar5;
    undefined8 uVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBX;
    int64_t in_R8;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    uint32_t uVar12;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x1801c6905;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    if ((((*(uint8_t *)(*(int64_t *)(*(int32_t **)(in_RCX + 0x18) + 0x36) + 0x50) & 8) == 0) &&
        (iVar7 = **(int32_t **)(in_RCX + 0x18), 0x303 < iVar7)) && (iVar7 != 0x10000)) {
        if (*(int32_t *)(in_RCX + 0x508) == 0) {
            *(undefined8 *)((int64_t)&arg_38h + iVar10) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6957;
            uVar11 = func_0x0001801a0380(in_RCX);
            *(int64_t *)((int64_t)&var_20h + iVar10) = in_RCX + 0x574;
            *(undefined8 *)((int64_t)&var_18h + iVar10) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c6976;
            iVar7 = func_0x0001801b3d70(in_RCX, uVar11, 0, 0);
            if (iVar7 == 0) {
                return 0;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar10) = 0x1801c698d;
        iVar7 = func_0x0001801b3c40(in_RCX, in_RDX, in_R8);
        if (iVar7 == 0) {
            return 0;
        }
        return 1;
    }
    uVar11 = *(undefined8 *)((int64_t)&arg_40h + iVar10);
    uVar6 = *(undefined8 *)((int64_t)&arg_48h + iVar10);
    *(undefined4 *)((int64_t)&arg_50h + iVar10) = 0;
    *(undefined8 *)(&stack0x00000028 + iVar10) = *(undefined8 *)(&stack0x00000028 + iVar10);
    *(undefined8 *)((int64_t)&var_20h + iVar10) = unaff_R13;
    *(undefined8 *)((int64_t)&var_18h + iVar10) = unaff_R14;
    *(undefined8 *)((int64_t)&var_10h + iVar10) = 0x1801c6394;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar2 = *(int64_t *)(in_RCX + 0x300);
    *(undefined8 *)((int64_t)&arg_90h + iVar8 + iVar10) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar10) = uVar11;
    *(undefined8 *)((int64_t)&arg_58h + iVar8 + iVar10) = uVar6;
    *(undefined8 *)((int64_t)&arg_50h + iVar8 + iVar10) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar10) = unaff_R15;
    uVar12 = *(uint32_t *)(iVar2 + 0x1c);
    if ((uVar12 & 0x1c8) == 0) {
        iVar2 = *(int64_t *)(in_RCX + 0x8f8);
        iVar3 = *(int64_t *)(*(int64_t *)(in_RCX + 0x18) + 0xd8);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar2 + 8;
        pcVar5 = *(code **)(iVar3 + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c651e;
        iVar7 = (*pcVar5)(in_RCX, iVar2 + 0x50, in_RDX, in_R8);
        uVar11 = 0;
        if (iVar7 == 0) goto code_r0x0001801c6528;
    } else {
        iVar2 = *(int64_t *)(in_RCX + 0x3c8);
        uVar12 = uVar12 & 8;
        *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar10) = iVar2;
        if (uVar12 != 0) {
            in_R8 = iVar2;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6407;
        puVar9 = (undefined *)
                 fcn.1802248d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                               *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        uVar11 = 0;
        if (puVar9 == (undefined *)0x0) goto code_r0x0001801c6528;
        puVar9[1] = (char)in_R8;
        puVar1 = puVar9 + 2;
        *puVar9 = (char)((uint64_t)in_R8 >> 8);
        if (uVar12 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c643f;
            fcn.180498030(puVar1, in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6435;
            fcn.1804986e0(puVar1, 0);
        }
        uVar11 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar10);
        puVar1[in_R8 + 1] = (char)uVar11;
        puVar1[in_R8] = (char)((uint64_t)uVar11 >> 8);
        uVar6 = *(undefined8 *)(in_RCX + 0x3c0);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c646a;
        fcn.180498030(puVar1 + in_R8 + 2, uVar6, uVar11);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10 + 0x18 + -0x18) = 0x1801c6486;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
        iVar3 = *(int64_t *)(in_RCX + 0x8f8);
        *(undefined8 *)(in_RCX + 0x3c0) = 0;
        *(undefined8 *)(in_RCX + 0x3c8) = 0;
        iVar4 = *(int64_t *)(in_RCX + 0x18);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10) = iVar3 + 8;
        pcVar5 = *(code **)(*(int64_t *)(iVar4 + 0xd8) + 8);
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64c5;
        iVar7 = (*pcVar5)(in_RCX, iVar3 + 0x50, puVar9, iVar2 + 4 + in_R8);
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64e1;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
            uVar11 = 0;
            goto code_r0x0001801c6528;
        }
        *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c64ee;
        fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10)
                     );
    }
    uVar11 = 1;
code_r0x0001801c6528:
    if (in_RDX != 0) {
        if (*(int32_t *)(&stack0x000000a0 + iVar8 + iVar10) == 0) {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c6565;
            func_0x000180244fc0(in_RDX, in_R8);
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar8 + iVar10) = 0x1801c655e;
            fcn.180224b90(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar10), 
                          *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar10));
        }
    }
    if (*(int32_t *)(in_RCX + 0x78) == 0) {
        *(undefined8 *)(in_RCX + 0x3b0) = 0;
        *(undefined8 *)(in_RCX + 0x3b8) = 0;
    }
    return uVar11;
}

