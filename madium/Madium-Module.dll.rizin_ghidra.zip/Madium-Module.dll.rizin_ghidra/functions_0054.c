// Chunk 54 - 50 functions

// ============================================================
// Function: FUN_1800a93f6
// Address: 0x1800a93f6
// Size: 3634 bytes
// ============================================================
void fcn.1800a93f6(int64_t arg4, int64_t arg_f0h)
{
    double dVar1;
    uint64_t unaff_RBX;
    int64_t unaff_RBP;
    undefined8 *unaff_RDI;
    uint64_t uVar2;
    int64_t in_R10;
    undefined4 uVar3;
    undefined4 uVar4;
    double dVar5;
    int64_t var_20h;
    undefined4 in_stack_00000028;
    undefined4 in_stack_0000002c;
    int64_t var_79h;
    
    if ((unaff_RBX == 0) || (*(int32_t *)arg4 != 3)) {
code_r0x0001800a9446:
        *(undefined8 *)(unaff_RBP + -0x79) = 0;
        *(undefined4 *)unaff_RDI = 0;
        *(undefined4 *)((int64_t)unaff_RDI + 4) = 0;
        *(undefined4 *)(unaff_RDI + 1) = in_stack_00000028;
        *(undefined4 *)((int64_t)unaff_RDI + 0xc) = in_stack_0000002c;
        unaff_RDI[2] = 0;
    } else {
        dVar5 = *(double *)(arg4 + 8);
        uVar2 = 1;
        if (1 < unaff_RBX) {
            do {
                if (*(int32_t *)(in_R10 + uVar2 * 0x18) != 3) goto code_r0x0001800a9446;
                dVar1 = *(double *)(in_R10 + 8 + uVar2 * 0x18);
                uVar3 = SUB84(dVar1, 0);
                uVar4 = (undefined4)((uint64_t)dVar1 >> 0x20);
                uVar2 = uVar2 + 1;
                if (dVar1 <= dVar5) {
                    uVar3 = SUB84(dVar5, 0);
                    uVar4 = (undefined4)((uint64_t)dVar5 >> 0x20);
                }
                dVar5 = (double)CONCAT44(uVar4, uVar3);
            } while (uVar2 < unaff_RBX);
        }
        *unaff_RDI = 3;
        unaff_RDI[2] = 0;
        unaff_RDI[1] = dVar5;
    }
    func_0x000180459870(*(uint64_t *)(unaff_RBP + 0x1f) ^ (uint64_t)&stack0x00000000);
    return;
}

// ============================================================
// Function: FUN_1800aa290
// Address: 0x1800aa290
// Size: 43 bytes
// ============================================================
int64_t fcn.1800aa290(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 8);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800aa2c0
// Address: 0x1800aa2c0
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1800aa2c0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t *piVar2;
    uint64_t uVar3;
    int64_t *piVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0x10) != 0) && (arg2 != *(int64_t *)(arg1 + 0x18))) {
        uVar5 = *(int64_t *)(arg1 + 8) - 1;
        uVar1 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar3 = 0;
        do {
            uVar1 = uVar1 & uVar5;
            piVar4 = (int64_t *)(uVar1 * 0x10 + *(int64_t *)arg1);
            if (*piVar4 == arg2) {
                piVar2 = piVar4 + 1;
                if (piVar4 == (int64_t *)0x0) {
                    piVar2 = (int64_t *)0x0;
                }
                if (piVar2 == (int64_t *)0x0) {
                    return 0;
                }
                return *(undefined4 *)piVar2;
            }
            if (*piVar4 == *(int64_t *)(arg1 + 0x18)) {
                return 0;
            }
            uVar1 = uVar1 + 1 + uVar3;
            uVar3 = uVar3 + 1;
        } while (uVar3 <= uVar5);
    }
    return 0;
}

// ============================================================
// Function: FUN_1800aa350
// Address: 0x1800aa350
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800aa350(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 uVar2;
    undefined auVar3 [12];
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [12];
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    iVar4 = *(int32_t *)0x180782738;
    iVar5 = *(int32_t *)(arg2 + 8);
    ppiVar13 = (int64_t **)0x0;
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x180782728) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar9 + 4);
        ppiVar9 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar9 = ppiVar13;
        }
        if (((ppiVar9 != (int64_t **)0x0) && (*(char *)(ppiVar9 + 1) == '\0')) && (*ppiVar9 != (int64_t *)0x0)) {
            pauVar7 = (undefined (*) [12])fcn.1800aa350((int64_t)&var_28h, (int64_t)*ppiVar9, arg3, arg4);
            auVar3 = *pauVar7;
            uVar2 = *(undefined4 *)pauVar7[1];
            var_28h._0_4_ = auVar3._0_4_;
            var_28h._4_4_ = auVar3._4_4_;
            uStack_20._0_4_ = auVar3._8_4_;
            *(undefined4 *)arg1 = (undefined4)var_28h;
            *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
            *(undefined4 *)(arg1 + 0xc) = uVar2;
            return arg1;
        }
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        return arg1;
    }
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x18078269c) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 == (int64_t **)0x0) {
        if (iVar5 == *(int32_t *)0x180782738) {
            ppiVar13 = (int64_t **)arg2;
        }
        if (ppiVar13 != (int64_t **)0x0) {
            piVar11 = ppiVar13[4];
            iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
            if (iVar5 == 0) {
                uStack_20._0_4_ = SUB84(piVar11, 0);
                uStack_20._4_4_ = (undefined4)((uint64_t)piVar11 >> 0x20);
                *(undefined4 *)arg1 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
                *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
                return arg1;
            }
            *(undefined4 *)arg1 = 0;
            *(undefined4 *)(arg1 + 4) = 0;
            *(undefined4 *)(arg1 + 8) = 0;
            *(undefined4 *)(arg1 + 0xc) = 0;
            return arg1;
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
    ppiVar1 = (int64_t **)ppiVar9[4];
    ppiVar10 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == *(int32_t *)0x180782728) {
        ppiVar10 = ppiVar1;
    }
    if (ppiVar10 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar10 + 4);
        ppiVar10 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar10 = ppiVar13;
        }
        if (((ppiVar10 != (int64_t **)0x0) && (*(char *)(ppiVar10 + 1) == '\0')) &&
           (ppiVar10 = (int64_t **)*ppiVar10, ppiVar10 != (int64_t **)0x0)) {
            ppiVar12 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == iVar4) {
                ppiVar12 = ppiVar10;
            }
            if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            ppiVar8 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == *(int32_t *)0x180782668) {
                ppiVar8 = ppiVar10;
            }
            if ((ppiVar8 != (int64_t **)0x0) && (*(int32_t *)(ppiVar8 + 4) == 0xf)) {
                ppiVar12 = ppiVar13;
                if (*(int32_t *)(ppiVar8[5] + 1) == iVar4) {
                    ppiVar12 = (int64_t **)ppiVar8[5];
                }
                if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            }
        }
    }
    ppiVar12 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == iVar4) {
        ppiVar12 = ppiVar1;
    }
    if (ppiVar12 == (int64_t **)0x0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
code_r0x0001800aa4c1:
    piVar11 = ppiVar12[4];
    iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
    if (iVar5 == 0) {
        uStack_20 = ppiVar9[5];
        var_28h = (int64_t)piVar11;
    } else {
        _var_28h = ZEXT816(0);
    }
    *(undefined4 *)arg1 = (undefined4)var_28h;
    *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
    *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
    *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800aa40f
// Address: 0x1800aa40f
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800aa350(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 uVar2;
    undefined auVar3 [12];
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [12];
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    iVar4 = *(int32_t *)0x180782738;
    iVar5 = *(int32_t *)(arg2 + 8);
    ppiVar13 = (int64_t **)0x0;
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x180782728) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar9 + 4);
        ppiVar9 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar9 = ppiVar13;
        }
        if (((ppiVar9 != (int64_t **)0x0) && (*(char *)(ppiVar9 + 1) == '\0')) && (*ppiVar9 != (int64_t *)0x0)) {
            pauVar7 = (undefined (*) [12])fcn.1800aa350((int64_t)&var_28h, (int64_t)*ppiVar9, arg3, arg4);
            auVar3 = *pauVar7;
            uVar2 = *(undefined4 *)pauVar7[1];
            var_28h._0_4_ = auVar3._0_4_;
            var_28h._4_4_ = auVar3._4_4_;
            uStack_20._0_4_ = auVar3._8_4_;
            *(undefined4 *)arg1 = (undefined4)var_28h;
            *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
            *(undefined4 *)(arg1 + 0xc) = uVar2;
            return arg1;
        }
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        return arg1;
    }
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x18078269c) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 == (int64_t **)0x0) {
        if (iVar5 == *(int32_t *)0x180782738) {
            ppiVar13 = (int64_t **)arg2;
        }
        if (ppiVar13 != (int64_t **)0x0) {
            piVar11 = ppiVar13[4];
            iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
            if (iVar5 == 0) {
                uStack_20._0_4_ = SUB84(piVar11, 0);
                uStack_20._4_4_ = (undefined4)((uint64_t)piVar11 >> 0x20);
                *(undefined4 *)arg1 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
                *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
                return arg1;
            }
            *(undefined4 *)arg1 = 0;
            *(undefined4 *)(arg1 + 4) = 0;
            *(undefined4 *)(arg1 + 8) = 0;
            *(undefined4 *)(arg1 + 0xc) = 0;
            return arg1;
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
    ppiVar1 = (int64_t **)ppiVar9[4];
    ppiVar10 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == *(int32_t *)0x180782728) {
        ppiVar10 = ppiVar1;
    }
    if (ppiVar10 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar10 + 4);
        ppiVar10 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar10 = ppiVar13;
        }
        if (((ppiVar10 != (int64_t **)0x0) && (*(char *)(ppiVar10 + 1) == '\0')) &&
           (ppiVar10 = (int64_t **)*ppiVar10, ppiVar10 != (int64_t **)0x0)) {
            ppiVar12 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == iVar4) {
                ppiVar12 = ppiVar10;
            }
            if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            ppiVar8 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == *(int32_t *)0x180782668) {
                ppiVar8 = ppiVar10;
            }
            if ((ppiVar8 != (int64_t **)0x0) && (*(int32_t *)(ppiVar8 + 4) == 0xf)) {
                ppiVar12 = ppiVar13;
                if (*(int32_t *)(ppiVar8[5] + 1) == iVar4) {
                    ppiVar12 = (int64_t **)ppiVar8[5];
                }
                if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            }
        }
    }
    ppiVar12 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == iVar4) {
        ppiVar12 = ppiVar1;
    }
    if (ppiVar12 == (int64_t **)0x0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
code_r0x0001800aa4c1:
    piVar11 = ppiVar12[4];
    iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
    if (iVar5 == 0) {
        uStack_20 = ppiVar9[5];
        var_28h = (int64_t)piVar11;
    } else {
        _var_28h = ZEXT816(0);
    }
    *(undefined4 *)arg1 = (undefined4)var_28h;
    *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
    *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
    *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800aa424
// Address: 0x1800aa424
// Size: 219 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800aa350(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 uVar2;
    undefined auVar3 [12];
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [12];
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    iVar4 = *(int32_t *)0x180782738;
    iVar5 = *(int32_t *)(arg2 + 8);
    ppiVar13 = (int64_t **)0x0;
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x180782728) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar9 + 4);
        ppiVar9 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar9 = ppiVar13;
        }
        if (((ppiVar9 != (int64_t **)0x0) && (*(char *)(ppiVar9 + 1) == '\0')) && (*ppiVar9 != (int64_t *)0x0)) {
            pauVar7 = (undefined (*) [12])fcn.1800aa350((int64_t)&var_28h, (int64_t)*ppiVar9, arg3, arg4);
            auVar3 = *pauVar7;
            uVar2 = *(undefined4 *)pauVar7[1];
            var_28h._0_4_ = auVar3._0_4_;
            var_28h._4_4_ = auVar3._4_4_;
            uStack_20._0_4_ = auVar3._8_4_;
            *(undefined4 *)arg1 = (undefined4)var_28h;
            *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
            *(undefined4 *)(arg1 + 0xc) = uVar2;
            return arg1;
        }
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        return arg1;
    }
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x18078269c) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 == (int64_t **)0x0) {
        if (iVar5 == *(int32_t *)0x180782738) {
            ppiVar13 = (int64_t **)arg2;
        }
        if (ppiVar13 != (int64_t **)0x0) {
            piVar11 = ppiVar13[4];
            iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
            if (iVar5 == 0) {
                uStack_20._0_4_ = SUB84(piVar11, 0);
                uStack_20._4_4_ = (undefined4)((uint64_t)piVar11 >> 0x20);
                *(undefined4 *)arg1 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
                *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
                return arg1;
            }
            *(undefined4 *)arg1 = 0;
            *(undefined4 *)(arg1 + 4) = 0;
            *(undefined4 *)(arg1 + 8) = 0;
            *(undefined4 *)(arg1 + 0xc) = 0;
            return arg1;
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
    ppiVar1 = (int64_t **)ppiVar9[4];
    ppiVar10 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == *(int32_t *)0x180782728) {
        ppiVar10 = ppiVar1;
    }
    if (ppiVar10 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar10 + 4);
        ppiVar10 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar10 = ppiVar13;
        }
        if (((ppiVar10 != (int64_t **)0x0) && (*(char *)(ppiVar10 + 1) == '\0')) &&
           (ppiVar10 = (int64_t **)*ppiVar10, ppiVar10 != (int64_t **)0x0)) {
            ppiVar12 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == iVar4) {
                ppiVar12 = ppiVar10;
            }
            if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            ppiVar8 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == *(int32_t *)0x180782668) {
                ppiVar8 = ppiVar10;
            }
            if ((ppiVar8 != (int64_t **)0x0) && (*(int32_t *)(ppiVar8 + 4) == 0xf)) {
                ppiVar12 = ppiVar13;
                if (*(int32_t *)(ppiVar8[5] + 1) == iVar4) {
                    ppiVar12 = (int64_t **)ppiVar8[5];
                }
                if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            }
        }
    }
    ppiVar12 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == iVar4) {
        ppiVar12 = ppiVar1;
    }
    if (ppiVar12 == (int64_t **)0x0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
code_r0x0001800aa4c1:
    piVar11 = ppiVar12[4];
    iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
    if (iVar5 == 0) {
        uStack_20 = ppiVar9[5];
        var_28h = (int64_t)piVar11;
    } else {
        _var_28h = ZEXT816(0);
    }
    *(undefined4 *)arg1 = (undefined4)var_28h;
    *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
    *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
    *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800aa4ff
// Address: 0x1800aa4ff
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800aa350(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 uVar2;
    undefined auVar3 [12];
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [12];
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    iVar4 = *(int32_t *)0x180782738;
    iVar5 = *(int32_t *)(arg2 + 8);
    ppiVar13 = (int64_t **)0x0;
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x180782728) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar9 + 4);
        ppiVar9 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar9 = ppiVar13;
        }
        if (((ppiVar9 != (int64_t **)0x0) && (*(char *)(ppiVar9 + 1) == '\0')) && (*ppiVar9 != (int64_t *)0x0)) {
            pauVar7 = (undefined (*) [12])fcn.1800aa350((int64_t)&var_28h, (int64_t)*ppiVar9, arg3, arg4);
            auVar3 = *pauVar7;
            uVar2 = *(undefined4 *)pauVar7[1];
            var_28h._0_4_ = auVar3._0_4_;
            var_28h._4_4_ = auVar3._4_4_;
            uStack_20._0_4_ = auVar3._8_4_;
            *(undefined4 *)arg1 = (undefined4)var_28h;
            *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
            *(undefined4 *)(arg1 + 0xc) = uVar2;
            return arg1;
        }
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        return arg1;
    }
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x18078269c) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 == (int64_t **)0x0) {
        if (iVar5 == *(int32_t *)0x180782738) {
            ppiVar13 = (int64_t **)arg2;
        }
        if (ppiVar13 != (int64_t **)0x0) {
            piVar11 = ppiVar13[4];
            iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
            if (iVar5 == 0) {
                uStack_20._0_4_ = SUB84(piVar11, 0);
                uStack_20._4_4_ = (undefined4)((uint64_t)piVar11 >> 0x20);
                *(undefined4 *)arg1 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
                *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
                return arg1;
            }
            *(undefined4 *)arg1 = 0;
            *(undefined4 *)(arg1 + 4) = 0;
            *(undefined4 *)(arg1 + 8) = 0;
            *(undefined4 *)(arg1 + 0xc) = 0;
            return arg1;
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
    ppiVar1 = (int64_t **)ppiVar9[4];
    ppiVar10 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == *(int32_t *)0x180782728) {
        ppiVar10 = ppiVar1;
    }
    if (ppiVar10 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar10 + 4);
        ppiVar10 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar10 = ppiVar13;
        }
        if (((ppiVar10 != (int64_t **)0x0) && (*(char *)(ppiVar10 + 1) == '\0')) &&
           (ppiVar10 = (int64_t **)*ppiVar10, ppiVar10 != (int64_t **)0x0)) {
            ppiVar12 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == iVar4) {
                ppiVar12 = ppiVar10;
            }
            if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            ppiVar8 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == *(int32_t *)0x180782668) {
                ppiVar8 = ppiVar10;
            }
            if ((ppiVar8 != (int64_t **)0x0) && (*(int32_t *)(ppiVar8 + 4) == 0xf)) {
                ppiVar12 = ppiVar13;
                if (*(int32_t *)(ppiVar8[5] + 1) == iVar4) {
                    ppiVar12 = (int64_t **)ppiVar8[5];
                }
                if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            }
        }
    }
    ppiVar12 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == iVar4) {
        ppiVar12 = ppiVar1;
    }
    if (ppiVar12 == (int64_t **)0x0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
code_r0x0001800aa4c1:
    piVar11 = ppiVar12[4];
    iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
    if (iVar5 == 0) {
        uStack_20 = ppiVar9[5];
        var_28h = (int64_t)piVar11;
    } else {
        _var_28h = ZEXT816(0);
    }
    *(undefined4 *)arg1 = (undefined4)var_28h;
    *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
    *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
    *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800aa515
// Address: 0x1800aa515
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800aa350(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 uVar2;
    undefined auVar3 [12];
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [12];
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    iVar4 = *(int32_t *)0x180782738;
    iVar5 = *(int32_t *)(arg2 + 8);
    ppiVar13 = (int64_t **)0x0;
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x180782728) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar9 + 4);
        ppiVar9 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar9 = ppiVar13;
        }
        if (((ppiVar9 != (int64_t **)0x0) && (*(char *)(ppiVar9 + 1) == '\0')) && (*ppiVar9 != (int64_t *)0x0)) {
            pauVar7 = (undefined (*) [12])fcn.1800aa350((int64_t)&var_28h, (int64_t)*ppiVar9, arg3, arg4);
            auVar3 = *pauVar7;
            uVar2 = *(undefined4 *)pauVar7[1];
            var_28h._0_4_ = auVar3._0_4_;
            var_28h._4_4_ = auVar3._4_4_;
            uStack_20._0_4_ = auVar3._8_4_;
            *(undefined4 *)arg1 = (undefined4)var_28h;
            *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
            *(undefined4 *)(arg1 + 0xc) = uVar2;
            return arg1;
        }
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        return arg1;
    }
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x18078269c) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 == (int64_t **)0x0) {
        if (iVar5 == *(int32_t *)0x180782738) {
            ppiVar13 = (int64_t **)arg2;
        }
        if (ppiVar13 != (int64_t **)0x0) {
            piVar11 = ppiVar13[4];
            iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
            if (iVar5 == 0) {
                uStack_20._0_4_ = SUB84(piVar11, 0);
                uStack_20._4_4_ = (undefined4)((uint64_t)piVar11 >> 0x20);
                *(undefined4 *)arg1 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
                *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
                return arg1;
            }
            *(undefined4 *)arg1 = 0;
            *(undefined4 *)(arg1 + 4) = 0;
            *(undefined4 *)(arg1 + 8) = 0;
            *(undefined4 *)(arg1 + 0xc) = 0;
            return arg1;
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
    ppiVar1 = (int64_t **)ppiVar9[4];
    ppiVar10 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == *(int32_t *)0x180782728) {
        ppiVar10 = ppiVar1;
    }
    if (ppiVar10 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar10 + 4);
        ppiVar10 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar10 = ppiVar13;
        }
        if (((ppiVar10 != (int64_t **)0x0) && (*(char *)(ppiVar10 + 1) == '\0')) &&
           (ppiVar10 = (int64_t **)*ppiVar10, ppiVar10 != (int64_t **)0x0)) {
            ppiVar12 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == iVar4) {
                ppiVar12 = ppiVar10;
            }
            if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            ppiVar8 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == *(int32_t *)0x180782668) {
                ppiVar8 = ppiVar10;
            }
            if ((ppiVar8 != (int64_t **)0x0) && (*(int32_t *)(ppiVar8 + 4) == 0xf)) {
                ppiVar12 = ppiVar13;
                if (*(int32_t *)(ppiVar8[5] + 1) == iVar4) {
                    ppiVar12 = (int64_t **)ppiVar8[5];
                }
                if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            }
        }
    }
    ppiVar12 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == iVar4) {
        ppiVar12 = ppiVar1;
    }
    if (ppiVar12 == (int64_t **)0x0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
code_r0x0001800aa4c1:
    piVar11 = ppiVar12[4];
    iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
    if (iVar5 == 0) {
        uStack_20 = ppiVar9[5];
        var_28h = (int64_t)piVar11;
    } else {
        _var_28h = ZEXT816(0);
    }
    *(undefined4 *)arg1 = (undefined4)var_28h;
    *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
    *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
    *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800aa51e
// Address: 0x1800aa51e
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800aa350(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t **ppiVar1;
    undefined4 uVar2;
    undefined auVar3 [12];
    int32_t iVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [12];
    int64_t **ppiVar8;
    int64_t **ppiVar9;
    int64_t **ppiVar10;
    int64_t *piVar11;
    int64_t **ppiVar12;
    int64_t **ppiVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    undefined8 uStack_20;
    
    iVar4 = *(int32_t *)0x180782738;
    iVar5 = *(int32_t *)(arg2 + 8);
    ppiVar13 = (int64_t **)0x0;
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x180782728) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar9 + 4);
        ppiVar9 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar9 = ppiVar13;
        }
        if (((ppiVar9 != (int64_t **)0x0) && (*(char *)(ppiVar9 + 1) == '\0')) && (*ppiVar9 != (int64_t *)0x0)) {
            pauVar7 = (undefined (*) [12])fcn.1800aa350((int64_t)&var_28h, (int64_t)*ppiVar9, arg3, arg4);
            auVar3 = *pauVar7;
            uVar2 = *(undefined4 *)pauVar7[1];
            var_28h._0_4_ = auVar3._0_4_;
            var_28h._4_4_ = auVar3._4_4_;
            uStack_20._0_4_ = auVar3._8_4_;
            *(undefined4 *)arg1 = (undefined4)var_28h;
            *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
            *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
            *(undefined4 *)(arg1 + 0xc) = uVar2;
            return arg1;
        }
        *(undefined4 *)arg1 = 0;
        *(undefined4 *)(arg1 + 4) = 0;
        *(undefined4 *)(arg1 + 8) = 0;
        *(undefined4 *)(arg1 + 0xc) = 0;
        return arg1;
    }
    ppiVar9 = ppiVar13;
    if (iVar5 == *(int32_t *)0x18078269c) {
        ppiVar9 = (int64_t **)arg2;
    }
    if (ppiVar9 == (int64_t **)0x0) {
        if (iVar5 == *(int32_t *)0x180782738) {
            ppiVar13 = (int64_t **)arg2;
        }
        if (ppiVar13 != (int64_t **)0x0) {
            piVar11 = ppiVar13[4];
            iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
            if (iVar5 == 0) {
                uStack_20._0_4_ = SUB84(piVar11, 0);
                uStack_20._4_4_ = (undefined4)((uint64_t)piVar11 >> 0x20);
                *(undefined4 *)arg1 = 0;
                *(undefined4 *)(arg1 + 4) = 0;
                *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
                *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
                return arg1;
            }
            *(undefined4 *)arg1 = 0;
            *(undefined4 *)(arg1 + 4) = 0;
            *(undefined4 *)(arg1 + 8) = 0;
            *(undefined4 *)(arg1 + 0xc) = 0;
            return arg1;
        }
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
    ppiVar1 = (int64_t **)ppiVar9[4];
    ppiVar10 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == *(int32_t *)0x180782728) {
        ppiVar10 = ppiVar1;
    }
    if (ppiVar10 != (int64_t **)0x0) {
        iVar6 = fcn.1800ac770(arg4, ppiVar10 + 4);
        ppiVar10 = (int64_t **)(iVar6 + 8);
        if (iVar6 == 0) {
            ppiVar10 = ppiVar13;
        }
        if (((ppiVar10 != (int64_t **)0x0) && (*(char *)(ppiVar10 + 1) == '\0')) &&
           (ppiVar10 = (int64_t **)*ppiVar10, ppiVar10 != (int64_t **)0x0)) {
            ppiVar12 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == iVar4) {
                ppiVar12 = ppiVar10;
            }
            if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            ppiVar8 = ppiVar13;
            if (*(int32_t *)(ppiVar10 + 1) == *(int32_t *)0x180782668) {
                ppiVar8 = ppiVar10;
            }
            if ((ppiVar8 != (int64_t **)0x0) && (*(int32_t *)(ppiVar8 + 4) == 0xf)) {
                ppiVar12 = ppiVar13;
                if (*(int32_t *)(ppiVar8[5] + 1) == iVar4) {
                    ppiVar12 = (int64_t **)ppiVar8[5];
                }
                if (ppiVar12 != (int64_t **)0x0) goto code_r0x0001800aa4c1;
            }
        }
    }
    ppiVar12 = ppiVar13;
    if (*(int32_t *)(ppiVar1 + 1) == iVar4) {
        ppiVar12 = ppiVar1;
    }
    if (ppiVar12 == (int64_t **)0x0) {
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        return arg1;
    }
code_r0x0001800aa4c1:
    piVar11 = ppiVar12[4];
    iVar5 = fcn.1800aa2c0(arg3, (int64_t)piVar11);
    if (iVar5 == 0) {
        uStack_20 = ppiVar9[5];
        var_28h = (int64_t)piVar11;
    } else {
        _var_28h = ZEXT816(0);
    }
    *(undefined4 *)arg1 = (undefined4)var_28h;
    *(undefined4 *)(arg1 + 4) = var_28h._4_4_;
    *(undefined4 *)(arg1 + 8) = (undefined4)uStack_20;
    *(undefined4 *)(arg1 + 0xc) = uStack_20._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_1800aa580
// Address: 0x1800aa580
// Size: 305 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800aa580(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    bool bVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625868)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 1;
                }
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062623c)) {
                iVar7 = iVar4;
                if (iVar4 == 5) {
                    return 0x28;
                }
            }
            if (iVar5 != 0) {
                iVar7 = 0;
                while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180626234)) {
                    iVar7 = iVar4;
                    if (iVar4 == 7) {
                        return 0x2c;
                    }
                }
                if (iVar5 != 0) {
                    iVar7 = 0;
                    while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa0)) {
                        iVar7 = iVar4;
                        if (iVar4 == 7) {
                            return 0x31;
                        }
                    }
                    if (iVar5 != 0) {
                        iVar7 = 0;
                        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fb0)) {
                            iVar7 = iVar4;
                            if (iVar4 == 7) {
                                return 0x32;
                            }
                        }
                    }
                }
            }
        }
    }
    if (((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) &&
       (iVar3 = fcn.180498f10(iVar5, 0x180625f68), iVar3 == 0)) {
        return 0x33;
    }
    if ((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) {
        iVar7 = 0;
        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa8)) {
            iVar7 = iVar4;
            if (iVar4 == 7) {
                return 0x3a;
            }
        }
    }
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x18062622c)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x35;
                }
            }
        }
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625f98)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x39;
                }
            }
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622848), iVar3 == 0)) {
            return 0x3c;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622870), iVar3 == 0)) {
            return 0x3d;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626210), iVar3 == 0)) {
            return 0x3e;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626200), iVar3 == 0)) {
            return 0x3f;
        }
    }
    if (iVar6 == 0) {
code_r0x0001800aaee8:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800aaef4;
code_r0x0001800ab1f4:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab200;
code_r0x0001800ab2f7:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab303;
code_r0x0001800ab6a0:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800ab915;
    } else {
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625d34)) goto code_r0x0001800aaee8;
            iVar5 = iVar7;
        } while (iVar7 != 5);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 2;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c0)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 3;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c24c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 4;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c23c)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 5;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c244)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 6;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 7;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e2c8)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 8;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c300)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 9;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c320)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c340)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0xb;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xc;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c37c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0xd;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e328)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xe;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e320)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xf;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e318)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c808)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x11;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x12;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x13;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c80c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x14;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d0)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x15;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8ac)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x16;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e310)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x17;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb00)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x18;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb38)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x19;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e348)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x1a;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb54)) {
                    iVar5 = iVar7;
                    if (iVar7 == 4) {
                        return 0x1b;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x2e;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x2f;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9bc)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x30;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x59;
                    }
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e338)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e330)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5c;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063e360);
            if (iVar3 == 0) {
                return 0x5d;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800aaef4:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x1806258c8)) goto code_r0x0001800ab1f4;
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c258)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x1c;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c274)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1d;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c26c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1e;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c260)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x1f;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c294)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x20;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc50)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x21;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c338)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x22;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc48)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x23;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7f8)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x24;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x180621a08)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x25;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc40)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x26;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9b4)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x27;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x37;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f0)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x38;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063dc80);
            if (iVar3 == 0) {
                return 0x40;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab200:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625fe4)) goto code_r0x0001800ab2f7;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c28c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x29;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2bc)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x2a;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7cc)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb24)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2d;
                }
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab303:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180622fb4)) {
                if (iVar6 != 0) goto code_r0x0001800ab38d;
                goto code_r0x0001800ab6a0;
            }
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18063c6b4)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x34;
                }
            }
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062622c)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x35;
                }
            }
        }
code_r0x0001800ab38d:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18062598c)) goto code_r0x0001800ab6a0;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c914)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x41;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c950)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x42;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc18)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc30)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x44;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c900)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x45;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar3 = fcn.180498f10(iVar6, 0x18063cbb8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbf8), iVar3 == 0)) {
                return 0x46;
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c920)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x47;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c958)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x48;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063cba8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbe8), iVar3 == 0)) {
                return 0x49;
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e8)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4a;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbd8);
                if (iVar3 == 0) {
                    return 0x4b;
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e0)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4c;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbc8);
                if (iVar3 == 0) {
                    return 0x4d;
                }
            }
        }
        cVar2 = *(char *)0x180777e58;
        if ((*(char *)0x180777e78 == '\0') || (*(char *)0x180777e58 == '\0')) goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd20), iVar3 == 0)) {
            return 0x83;
        }
        if (cVar2 == '\0') goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd10), iVar3 == 0)) {
            return 0x84;
        }
        iVar6 = *(int64_t *)arg1;
    }
    iVar5 = 0;
    do {
        iVar7 = iVar5 + 1;
        if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18063e1a8)) goto code_r0x0001800ab915;
        iVar5 = iVar7;
    } while (iVar7 != 7);
    iVar6 = *(int64_t *)(arg1 + 8);
    if (iVar6 != 0) {
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c32c)) {
            iVar5 = iVar7;
            if (iVar7 == 7) {
                return 0x36;
            }
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee78);
        if (iVar3 == 0) {
            return 0x4e;
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee88);
        if (iVar3 == 0) {
            return 0x4f;
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee94)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x50;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee40)) {
            iVar5 = iVar7;
            if (iVar7 == 4) {
                return 0x51;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x52;
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x53;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x54;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x55;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x56;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x57;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x58;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x5a;
                    }
                }
            }
        }
    }
code_r0x0001800ab915:
    if ((*(char *)0x180777e78 != '\0') && (*(int64_t *)arg1 != 0)) {
        iVar6 = 0;
        do {
            iVar5 = iVar6 + 1;
            if (*(char *)(*(int64_t *)arg1 + iVar6) != *(char *)(iVar6 + 0x18063e1a0)) goto code_r0x0001800ac007;
            iVar6 = iVar5;
        } while (iVar5 != 8);
        pcVar1 = *(char **)(arg1 + 8);
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f8)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x61;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063cb24)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x62;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e24c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x6b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f4)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 99;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e240)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 100;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e234)) {
                iVar6 = iVar5;
                if (iVar5 == 5) {
                    return 0x68;
                }
            }
            if (pcVar1 != (char *)0x0) {
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e22c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x69;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e23c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x67;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e250)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x6a;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c814)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x65;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c818)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x66;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1fc)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x60;
                    }
                }
                if (pcVar1 != (char *)0x0) {
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c32c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 7) {
                            return 0x5e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2a4)) {
                        iVar6 = iVar5;
                        if (iVar5 == 6) {
                            return 0x6c;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c274)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6d;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c260)) {
                        iVar6 = iVar5;
                        if (iVar5 == 4) {
                            return 0x6e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c294)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x70;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c26c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6f;
                        }
                    }
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc50)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x7f;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e274)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x82;
                }
            }
            if (*pcVar1 == 'l') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x71;
                }
                if (((*pcVar1 == 'l') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x72;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e264)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x73;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e260)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x74;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            if (*pcVar1 == 'g') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x75;
                }
                if (((*pcVar1 == 'g') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x76;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e280)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x77;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e27c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x78;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c7f8)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x79;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c9b4)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x7a;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c258)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc48)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7c;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc40)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7d;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f0)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x80;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f8)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x81;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c338)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7e;
                }
            }
        }
        if ((pcVar1 != (char *)0x0) && (iVar3 = fcn.180498f10(pcVar1, 0x180626210), iVar3 == 0)) {
            return 0x5f;
        }
    }
code_r0x0001800ac007:
    iVar6 = *(int64_t *)(arg2 + 0x18);
    if (iVar6 != 0) {
        iVar5 = *(int64_t *)arg1;
        if (*(int64_t *)(arg2 + 0x10) == 0) {
            bVar8 = iVar5 == 0;
        } else {
            if (iVar5 == 0) {
                return 0xffffffff;
            }
            iVar3 = fcn.180498f10(iVar5);
            bVar8 = iVar3 == 0;
        }
        if (((bVar8) && (*(int64_t *)(arg1 + 8) != 0)) &&
           (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), iVar6), iVar3 == 0)) {
            return 0x36;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800aa6b1
// Address: 0x1800aa6b1
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800aa580(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    bool bVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625868)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 1;
                }
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062623c)) {
                iVar7 = iVar4;
                if (iVar4 == 5) {
                    return 0x28;
                }
            }
            if (iVar5 != 0) {
                iVar7 = 0;
                while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180626234)) {
                    iVar7 = iVar4;
                    if (iVar4 == 7) {
                        return 0x2c;
                    }
                }
                if (iVar5 != 0) {
                    iVar7 = 0;
                    while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa0)) {
                        iVar7 = iVar4;
                        if (iVar4 == 7) {
                            return 0x31;
                        }
                    }
                    if (iVar5 != 0) {
                        iVar7 = 0;
                        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fb0)) {
                            iVar7 = iVar4;
                            if (iVar4 == 7) {
                                return 0x32;
                            }
                        }
                    }
                }
            }
        }
    }
    if (((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) &&
       (iVar3 = fcn.180498f10(iVar5, 0x180625f68), iVar3 == 0)) {
        return 0x33;
    }
    if ((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) {
        iVar7 = 0;
        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa8)) {
            iVar7 = iVar4;
            if (iVar4 == 7) {
                return 0x3a;
            }
        }
    }
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x18062622c)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x35;
                }
            }
        }
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625f98)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x39;
                }
            }
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622848), iVar3 == 0)) {
            return 0x3c;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622870), iVar3 == 0)) {
            return 0x3d;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626210), iVar3 == 0)) {
            return 0x3e;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626200), iVar3 == 0)) {
            return 0x3f;
        }
    }
    if (iVar6 == 0) {
code_r0x0001800aaee8:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800aaef4;
code_r0x0001800ab1f4:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab200;
code_r0x0001800ab2f7:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab303;
code_r0x0001800ab6a0:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800ab915;
    } else {
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625d34)) goto code_r0x0001800aaee8;
            iVar5 = iVar7;
        } while (iVar7 != 5);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 2;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c0)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 3;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c24c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 4;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c23c)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 5;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c244)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 6;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 7;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e2c8)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 8;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c300)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 9;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c320)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c340)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0xb;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xc;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c37c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0xd;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e328)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xe;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e320)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xf;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e318)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c808)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x11;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x12;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x13;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c80c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x14;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d0)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x15;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8ac)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x16;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e310)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x17;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb00)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x18;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb38)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x19;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e348)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x1a;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb54)) {
                    iVar5 = iVar7;
                    if (iVar7 == 4) {
                        return 0x1b;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x2e;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x2f;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9bc)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x30;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x59;
                    }
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e338)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e330)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5c;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063e360);
            if (iVar3 == 0) {
                return 0x5d;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800aaef4:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x1806258c8)) goto code_r0x0001800ab1f4;
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c258)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x1c;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c274)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1d;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c26c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1e;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c260)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x1f;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c294)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x20;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc50)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x21;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c338)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x22;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc48)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x23;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7f8)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x24;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x180621a08)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x25;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc40)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x26;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9b4)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x27;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x37;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f0)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x38;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063dc80);
            if (iVar3 == 0) {
                return 0x40;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab200:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625fe4)) goto code_r0x0001800ab2f7;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c28c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x29;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2bc)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x2a;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7cc)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb24)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2d;
                }
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab303:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180622fb4)) {
                if (iVar6 != 0) goto code_r0x0001800ab38d;
                goto code_r0x0001800ab6a0;
            }
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18063c6b4)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x34;
                }
            }
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062622c)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x35;
                }
            }
        }
code_r0x0001800ab38d:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18062598c)) goto code_r0x0001800ab6a0;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c914)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x41;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c950)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x42;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc18)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc30)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x44;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c900)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x45;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar3 = fcn.180498f10(iVar6, 0x18063cbb8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbf8), iVar3 == 0)) {
                return 0x46;
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c920)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x47;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c958)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x48;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063cba8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbe8), iVar3 == 0)) {
                return 0x49;
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e8)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4a;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbd8);
                if (iVar3 == 0) {
                    return 0x4b;
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e0)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4c;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbc8);
                if (iVar3 == 0) {
                    return 0x4d;
                }
            }
        }
        cVar2 = *(char *)0x180777e58;
        if ((*(char *)0x180777e78 == '\0') || (*(char *)0x180777e58 == '\0')) goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd20), iVar3 == 0)) {
            return 0x83;
        }
        if (cVar2 == '\0') goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd10), iVar3 == 0)) {
            return 0x84;
        }
        iVar6 = *(int64_t *)arg1;
    }
    iVar5 = 0;
    do {
        iVar7 = iVar5 + 1;
        if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18063e1a8)) goto code_r0x0001800ab915;
        iVar5 = iVar7;
    } while (iVar7 != 7);
    iVar6 = *(int64_t *)(arg1 + 8);
    if (iVar6 != 0) {
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c32c)) {
            iVar5 = iVar7;
            if (iVar7 == 7) {
                return 0x36;
            }
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee78);
        if (iVar3 == 0) {
            return 0x4e;
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee88);
        if (iVar3 == 0) {
            return 0x4f;
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee94)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x50;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee40)) {
            iVar5 = iVar7;
            if (iVar7 == 4) {
                return 0x51;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x52;
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x53;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x54;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x55;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x56;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x57;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x58;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x5a;
                    }
                }
            }
        }
    }
code_r0x0001800ab915:
    if ((*(char *)0x180777e78 != '\0') && (*(int64_t *)arg1 != 0)) {
        iVar6 = 0;
        do {
            iVar5 = iVar6 + 1;
            if (*(char *)(*(int64_t *)arg1 + iVar6) != *(char *)(iVar6 + 0x18063e1a0)) goto code_r0x0001800ac007;
            iVar6 = iVar5;
        } while (iVar5 != 8);
        pcVar1 = *(char **)(arg1 + 8);
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f8)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x61;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063cb24)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x62;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e24c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x6b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f4)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 99;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e240)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 100;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e234)) {
                iVar6 = iVar5;
                if (iVar5 == 5) {
                    return 0x68;
                }
            }
            if (pcVar1 != (char *)0x0) {
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e22c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x69;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e23c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x67;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e250)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x6a;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c814)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x65;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c818)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x66;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1fc)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x60;
                    }
                }
                if (pcVar1 != (char *)0x0) {
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c32c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 7) {
                            return 0x5e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2a4)) {
                        iVar6 = iVar5;
                        if (iVar5 == 6) {
                            return 0x6c;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c274)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6d;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c260)) {
                        iVar6 = iVar5;
                        if (iVar5 == 4) {
                            return 0x6e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c294)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x70;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c26c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6f;
                        }
                    }
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc50)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x7f;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e274)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x82;
                }
            }
            if (*pcVar1 == 'l') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x71;
                }
                if (((*pcVar1 == 'l') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x72;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e264)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x73;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e260)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x74;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            if (*pcVar1 == 'g') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x75;
                }
                if (((*pcVar1 == 'g') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x76;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e280)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x77;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e27c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x78;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c7f8)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x79;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c9b4)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x7a;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c258)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc48)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7c;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc40)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7d;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f0)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x80;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f8)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x81;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c338)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7e;
                }
            }
        }
        if ((pcVar1 != (char *)0x0) && (iVar3 = fcn.180498f10(pcVar1, 0x180626210), iVar3 == 0)) {
            return 0x5f;
        }
    }
code_r0x0001800ac007:
    iVar6 = *(int64_t *)(arg2 + 0x18);
    if (iVar6 != 0) {
        iVar5 = *(int64_t *)arg1;
        if (*(int64_t *)(arg2 + 0x10) == 0) {
            bVar8 = iVar5 == 0;
        } else {
            if (iVar5 == 0) {
                return 0xffffffff;
            }
            iVar3 = fcn.180498f10(iVar5);
            bVar8 = iVar3 == 0;
        }
        if (((bVar8) && (*(int64_t *)(arg1 + 8) != 0)) &&
           (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), iVar6), iVar3 == 0)) {
            return 0x36;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800aa6f6
// Address: 0x1800aa6f6
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800aa580(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    bool bVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625868)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 1;
                }
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062623c)) {
                iVar7 = iVar4;
                if (iVar4 == 5) {
                    return 0x28;
                }
            }
            if (iVar5 != 0) {
                iVar7 = 0;
                while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180626234)) {
                    iVar7 = iVar4;
                    if (iVar4 == 7) {
                        return 0x2c;
                    }
                }
                if (iVar5 != 0) {
                    iVar7 = 0;
                    while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa0)) {
                        iVar7 = iVar4;
                        if (iVar4 == 7) {
                            return 0x31;
                        }
                    }
                    if (iVar5 != 0) {
                        iVar7 = 0;
                        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fb0)) {
                            iVar7 = iVar4;
                            if (iVar4 == 7) {
                                return 0x32;
                            }
                        }
                    }
                }
            }
        }
    }
    if (((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) &&
       (iVar3 = fcn.180498f10(iVar5, 0x180625f68), iVar3 == 0)) {
        return 0x33;
    }
    if ((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) {
        iVar7 = 0;
        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa8)) {
            iVar7 = iVar4;
            if (iVar4 == 7) {
                return 0x3a;
            }
        }
    }
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x18062622c)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x35;
                }
            }
        }
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625f98)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x39;
                }
            }
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622848), iVar3 == 0)) {
            return 0x3c;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622870), iVar3 == 0)) {
            return 0x3d;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626210), iVar3 == 0)) {
            return 0x3e;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626200), iVar3 == 0)) {
            return 0x3f;
        }
    }
    if (iVar6 == 0) {
code_r0x0001800aaee8:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800aaef4;
code_r0x0001800ab1f4:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab200;
code_r0x0001800ab2f7:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab303;
code_r0x0001800ab6a0:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800ab915;
    } else {
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625d34)) goto code_r0x0001800aaee8;
            iVar5 = iVar7;
        } while (iVar7 != 5);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 2;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c0)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 3;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c24c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 4;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c23c)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 5;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c244)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 6;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 7;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e2c8)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 8;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c300)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 9;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c320)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c340)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0xb;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xc;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c37c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0xd;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e328)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xe;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e320)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xf;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e318)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c808)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x11;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x12;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x13;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c80c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x14;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d0)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x15;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8ac)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x16;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e310)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x17;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb00)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x18;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb38)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x19;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e348)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x1a;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb54)) {
                    iVar5 = iVar7;
                    if (iVar7 == 4) {
                        return 0x1b;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x2e;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x2f;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9bc)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x30;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x59;
                    }
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e338)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e330)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5c;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063e360);
            if (iVar3 == 0) {
                return 0x5d;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800aaef4:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x1806258c8)) goto code_r0x0001800ab1f4;
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c258)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x1c;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c274)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1d;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c26c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1e;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c260)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x1f;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c294)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x20;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc50)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x21;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c338)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x22;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc48)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x23;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7f8)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x24;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x180621a08)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x25;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc40)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x26;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9b4)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x27;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x37;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f0)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x38;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063dc80);
            if (iVar3 == 0) {
                return 0x40;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab200:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625fe4)) goto code_r0x0001800ab2f7;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c28c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x29;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2bc)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x2a;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7cc)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb24)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2d;
                }
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab303:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180622fb4)) {
                if (iVar6 != 0) goto code_r0x0001800ab38d;
                goto code_r0x0001800ab6a0;
            }
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18063c6b4)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x34;
                }
            }
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062622c)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x35;
                }
            }
        }
code_r0x0001800ab38d:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18062598c)) goto code_r0x0001800ab6a0;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c914)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x41;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c950)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x42;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc18)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc30)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x44;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c900)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x45;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar3 = fcn.180498f10(iVar6, 0x18063cbb8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbf8), iVar3 == 0)) {
                return 0x46;
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c920)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x47;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c958)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x48;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063cba8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbe8), iVar3 == 0)) {
                return 0x49;
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e8)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4a;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbd8);
                if (iVar3 == 0) {
                    return 0x4b;
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e0)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4c;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbc8);
                if (iVar3 == 0) {
                    return 0x4d;
                }
            }
        }
        cVar2 = *(char *)0x180777e58;
        if ((*(char *)0x180777e78 == '\0') || (*(char *)0x180777e58 == '\0')) goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd20), iVar3 == 0)) {
            return 0x83;
        }
        if (cVar2 == '\0') goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd10), iVar3 == 0)) {
            return 0x84;
        }
        iVar6 = *(int64_t *)arg1;
    }
    iVar5 = 0;
    do {
        iVar7 = iVar5 + 1;
        if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18063e1a8)) goto code_r0x0001800ab915;
        iVar5 = iVar7;
    } while (iVar7 != 7);
    iVar6 = *(int64_t *)(arg1 + 8);
    if (iVar6 != 0) {
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c32c)) {
            iVar5 = iVar7;
            if (iVar7 == 7) {
                return 0x36;
            }
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee78);
        if (iVar3 == 0) {
            return 0x4e;
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee88);
        if (iVar3 == 0) {
            return 0x4f;
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee94)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x50;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee40)) {
            iVar5 = iVar7;
            if (iVar7 == 4) {
                return 0x51;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x52;
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x53;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x54;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x55;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x56;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x57;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x58;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x5a;
                    }
                }
            }
        }
    }
code_r0x0001800ab915:
    if ((*(char *)0x180777e78 != '\0') && (*(int64_t *)arg1 != 0)) {
        iVar6 = 0;
        do {
            iVar5 = iVar6 + 1;
            if (*(char *)(*(int64_t *)arg1 + iVar6) != *(char *)(iVar6 + 0x18063e1a0)) goto code_r0x0001800ac007;
            iVar6 = iVar5;
        } while (iVar5 != 8);
        pcVar1 = *(char **)(arg1 + 8);
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f8)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x61;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063cb24)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x62;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e24c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x6b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f4)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 99;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e240)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 100;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e234)) {
                iVar6 = iVar5;
                if (iVar5 == 5) {
                    return 0x68;
                }
            }
            if (pcVar1 != (char *)0x0) {
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e22c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x69;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e23c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x67;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e250)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x6a;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c814)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x65;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c818)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x66;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1fc)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x60;
                    }
                }
                if (pcVar1 != (char *)0x0) {
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c32c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 7) {
                            return 0x5e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2a4)) {
                        iVar6 = iVar5;
                        if (iVar5 == 6) {
                            return 0x6c;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c274)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6d;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c260)) {
                        iVar6 = iVar5;
                        if (iVar5 == 4) {
                            return 0x6e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c294)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x70;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c26c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6f;
                        }
                    }
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc50)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x7f;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e274)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x82;
                }
            }
            if (*pcVar1 == 'l') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x71;
                }
                if (((*pcVar1 == 'l') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x72;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e264)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x73;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e260)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x74;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            if (*pcVar1 == 'g') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x75;
                }
                if (((*pcVar1 == 'g') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x76;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e280)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x77;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e27c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x78;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c7f8)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x79;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c9b4)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x7a;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c258)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc48)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7c;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc40)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7d;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f0)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x80;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f8)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x81;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c338)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7e;
                }
            }
        }
        if ((pcVar1 != (char *)0x0) && (iVar3 = fcn.180498f10(pcVar1, 0x180626210), iVar3 == 0)) {
            return 0x5f;
        }
    }
code_r0x0001800ac007:
    iVar6 = *(int64_t *)(arg2 + 0x18);
    if (iVar6 != 0) {
        iVar5 = *(int64_t *)arg1;
        if (*(int64_t *)(arg2 + 0x10) == 0) {
            bVar8 = iVar5 == 0;
        } else {
            if (iVar5 == 0) {
                return 0xffffffff;
            }
            iVar3 = fcn.180498f10(iVar5);
            bVar8 = iVar3 == 0;
        }
        if (((bVar8) && (*(int64_t *)(arg1 + 8) != 0)) &&
           (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), iVar6), iVar3 == 0)) {
            return 0x36;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800aa73b
// Address: 0x1800aa73b
// Size: 6457 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1800aa580(int64_t arg1, int64_t arg2)
{
    char *pcVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    bool bVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625868)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 1;
                }
            }
        }
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062623c)) {
                iVar7 = iVar4;
                if (iVar4 == 5) {
                    return 0x28;
                }
            }
            if (iVar5 != 0) {
                iVar7 = 0;
                while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180626234)) {
                    iVar7 = iVar4;
                    if (iVar4 == 7) {
                        return 0x2c;
                    }
                }
                if (iVar5 != 0) {
                    iVar7 = 0;
                    while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa0)) {
                        iVar7 = iVar4;
                        if (iVar4 == 7) {
                            return 0x31;
                        }
                    }
                    if (iVar5 != 0) {
                        iVar7 = 0;
                        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fb0)) {
                            iVar7 = iVar4;
                            if (iVar4 == 7) {
                                return 0x32;
                            }
                        }
                    }
                }
            }
        }
    }
    if (((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) &&
       (iVar3 = fcn.180498f10(iVar5, 0x180625f68), iVar3 == 0)) {
        return 0x33;
    }
    if ((iVar6 == 0) && (iVar5 = *(int64_t *)(arg1 + 8), iVar5 != 0)) {
        iVar7 = 0;
        while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x180625fa8)) {
            iVar7 = iVar4;
            if (iVar4 == 7) {
                return 0x3a;
            }
        }
    }
    if (iVar6 == 0) {
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x18062622c)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x35;
                }
            }
        }
        if (*(int64_t *)(arg1 + 8) != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(*(int64_t *)(arg1 + 8) + iVar5) == *(char *)(iVar5 + 0x180625f98)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x39;
                }
            }
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622848), iVar3 == 0)) {
            return 0x3c;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180622870), iVar3 == 0)) {
            return 0x3d;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626210), iVar3 == 0)) {
            return 0x3e;
        }
        if ((*(int64_t *)(arg1 + 8) != 0) && (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), 0x180626200), iVar3 == 0)) {
            return 0x3f;
        }
    }
    if (iVar6 == 0) {
code_r0x0001800aaee8:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800aaef4;
code_r0x0001800ab1f4:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab200;
code_r0x0001800ab2f7:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 != 0) goto code_r0x0001800ab303;
code_r0x0001800ab6a0:
        iVar6 = *(int64_t *)arg1;
        if (iVar6 == 0) goto code_r0x0001800ab915;
    } else {
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625d34)) goto code_r0x0001800aaee8;
            iVar5 = iVar7;
        } while (iVar7 != 5);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 2;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c0)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 3;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c24c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 4;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c23c)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 5;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c244)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 6;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 7;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e2c8)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 8;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c300)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 9;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c320)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c340)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0xb;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xc;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c37c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0xd;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e328)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xe;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e320)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0xf;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e318)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x10;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c808)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x11;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x12;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x13;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c80c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x14;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d0)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x15;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8ac)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x16;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e310)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x17;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb00)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x18;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb38)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x19;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e348)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x1a;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb54)) {
                    iVar5 = iVar7;
                    if (iVar7 == 4) {
                        return 0x1b;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x2e;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x2f;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9bc)) {
                    iVar5 = iVar7;
                    if (iVar7 == 6) {
                        return 0x30;
                    }
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x59;
                    }
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e338)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e330)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x5c;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063e360);
            if (iVar3 == 0) {
                return 0x5d;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800aaef4:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x1806258c8)) goto code_r0x0001800ab1f4;
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c258)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x1c;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c274)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1d;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c26c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x1e;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c260)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x1f;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c294)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x20;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc50)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x21;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c338)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x22;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc48)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x23;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7f8)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x24;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x180621a08)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x25;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063dc40)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x26;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c9b4)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x27;
                }
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x37;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2f0)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x38;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063dc80);
            if (iVar3 == 0) {
                return 0x40;
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab200:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180625fe4)) goto code_r0x0001800ab2f7;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c28c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x29;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2bc)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x2a;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c7cc)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2b;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb24)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x2d;
                }
            }
        }
        iVar6 = *(int64_t *)arg1;
code_r0x0001800ab303:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x180622fb4)) {
                if (iVar6 != 0) goto code_r0x0001800ab38d;
                goto code_r0x0001800ab6a0;
            }
            iVar5 = iVar7;
        } while (iVar7 != 6);
        iVar5 = *(int64_t *)(arg1 + 8);
        if (iVar5 != 0) {
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18063c6b4)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x34;
                }
            }
            iVar7 = 0;
            while (iVar4 = iVar7 + 1, *(char *)(iVar5 + iVar7) == *(char *)(iVar7 + 0x18062622c)) {
                iVar7 = iVar4;
                if (iVar4 == 7) {
                    return 0x35;
                }
            }
        }
code_r0x0001800ab38d:
        iVar5 = 0;
        do {
            iVar7 = iVar5 + 1;
            if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18062598c)) goto code_r0x0001800ab6a0;
            iVar5 = iVar7;
        } while (iVar7 != 7);
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c914)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x41;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c950)) {
                iVar5 = iVar7;
                if (iVar7 == 7) {
                    return 0x42;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc18)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cc30)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x43;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8d8)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x44;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c900)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x45;
                }
            }
        }
        iVar6 = *(int64_t *)(arg1 + 8);
        if (iVar6 != 0) {
            iVar3 = fcn.180498f10(iVar6, 0x18063cbb8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbf8), iVar3 == 0)) {
                return 0x46;
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c920)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x47;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c958)) {
                iVar5 = iVar7;
                if (iVar7 == 8) {
                    return 0x48;
                }
            }
            iVar3 = fcn.180498f10(iVar6, 0x18063cba8);
            if ((iVar3 == 0) || (iVar3 = fcn.180498f10(iVar6, 0x18063cbe8), iVar3 == 0)) {
                return 0x49;
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e8)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4a;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbd8);
                if (iVar3 == 0) {
                    return 0x4b;
                }
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c8e0)) {
                    iVar5 = iVar7;
                    if (iVar7 == 8) {
                        return 0x4c;
                    }
                }
                iVar3 = fcn.180498f10(iVar6, 0x18063cbc8);
                if (iVar3 == 0) {
                    return 0x4d;
                }
            }
        }
        cVar2 = *(char *)0x180777e58;
        if ((*(char *)0x180777e78 == '\0') || (*(char *)0x180777e58 == '\0')) goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd20), iVar3 == 0)) {
            return 0x83;
        }
        if (cVar2 == '\0') goto code_r0x0001800ab6a0;
        if ((iVar6 != 0) && (iVar3 = fcn.180498f10(iVar6, 0x18063dd10), iVar3 == 0)) {
            return 0x84;
        }
        iVar6 = *(int64_t *)arg1;
    }
    iVar5 = 0;
    do {
        iVar7 = iVar5 + 1;
        if (*(char *)(iVar6 + iVar5) != *(char *)(iVar5 + 0x18063e1a8)) goto code_r0x0001800ab915;
        iVar5 = iVar7;
    } while (iVar7 != 7);
    iVar6 = *(int64_t *)(arg1 + 8);
    if (iVar6 != 0) {
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c32c)) {
            iVar5 = iVar7;
            if (iVar7 == 7) {
                return 0x36;
            }
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee78);
        if (iVar3 == 0) {
            return 0x4e;
        }
        iVar3 = fcn.180498f10(iVar6, 0x18063ee88);
        if (iVar3 == 0) {
            return 0x4f;
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee94)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x50;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063ee40)) {
            iVar5 = iVar7;
            if (iVar7 == 4) {
                return 0x51;
            }
        }
        iVar5 = 0;
        while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c384)) {
            iVar5 = iVar7;
            if (iVar7 == 6) {
                return 0x52;
            }
        }
        if (iVar6 != 0) {
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c27c)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x53;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c1c8)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x54;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063cb04)) {
                iVar5 = iVar7;
                if (iVar7 == 5) {
                    return 0x55;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c2a4)) {
                iVar5 = iVar7;
                if (iVar7 == 6) {
                    return 0x56;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c814)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x57;
                }
            }
            iVar5 = 0;
            while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063c818)) {
                iVar5 = iVar7;
                if (iVar7 == 4) {
                    return 0x58;
                }
            }
            if (iVar6 != 0) {
                iVar5 = 0;
                while (iVar7 = iVar5 + 1, *(char *)(iVar6 + iVar5) == *(char *)(iVar5 + 0x18063e340)) {
                    iVar5 = iVar7;
                    if (iVar7 == 5) {
                        return 0x5a;
                    }
                }
            }
        }
    }
code_r0x0001800ab915:
    if ((*(char *)0x180777e78 != '\0') && (*(int64_t *)arg1 != 0)) {
        iVar6 = 0;
        do {
            iVar5 = iVar6 + 1;
            if (*(char *)(*(int64_t *)arg1 + iVar6) != *(char *)(iVar6 + 0x18063e1a0)) goto code_r0x0001800ac007;
            iVar6 = iVar5;
        } while (iVar5 != 8);
        pcVar1 = *(char **)(arg1 + 8);
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f8)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x61;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063cb24)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x62;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e24c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x6b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1f4)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 99;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e240)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 100;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e234)) {
                iVar6 = iVar5;
                if (iVar5 == 5) {
                    return 0x68;
                }
            }
            if (pcVar1 != (char *)0x0) {
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e22c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x69;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e23c)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x67;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e250)) {
                    iVar6 = iVar5;
                    if (iVar5 == 5) {
                        return 0x6a;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c814)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x65;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c818)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x66;
                    }
                }
                iVar6 = 0;
                while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e1fc)) {
                    iVar6 = iVar5;
                    if (iVar5 == 4) {
                        return 0x60;
                    }
                }
                if (pcVar1 != (char *)0x0) {
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c32c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 7) {
                            return 0x5e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2a4)) {
                        iVar6 = iVar5;
                        if (iVar5 == 6) {
                            return 0x6c;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c274)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6d;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c260)) {
                        iVar6 = iVar5;
                        if (iVar5 == 4) {
                            return 0x6e;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c294)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x70;
                        }
                    }
                    iVar6 = 0;
                    while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c26c)) {
                        iVar6 = iVar5;
                        if (iVar5 == 5) {
                            return 0x6f;
                        }
                    }
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc50)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x7f;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e274)) {
                iVar6 = iVar5;
                if (iVar5 == 6) {
                    return 0x82;
                }
            }
            if (*pcVar1 == 'l') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x71;
                }
                if (((*pcVar1 == 'l') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x72;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e264)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x73;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e260)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x74;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            if (*pcVar1 == 'g') {
                if ((pcVar1[1] == 't') && (pcVar1[2] == '\0')) {
                    return 0x75;
                }
                if (((*pcVar1 == 'g') && (pcVar1[1] == 'e')) && (pcVar1[2] == '\0')) {
                    return 0x76;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e280)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x77;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063e27c)) {
                iVar6 = iVar5;
                if (iVar5 == 4) {
                    return 0x78;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c7f8)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x79;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c9b4)) {
                iVar6 = iVar5;
                if (iVar5 == 7) {
                    return 0x7a;
                }
            }
        }
        if (pcVar1 != (char *)0x0) {
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c258)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7b;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc48)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7c;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063dc40)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7d;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f0)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x80;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c2f8)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x81;
                }
            }
            iVar6 = 0;
            while (iVar5 = iVar6 + 1, pcVar1[iVar6] == *(char *)(iVar6 + 0x18063c338)) {
                iVar6 = iVar5;
                if (iVar5 == 8) {
                    return 0x7e;
                }
            }
        }
        if ((pcVar1 != (char *)0x0) && (iVar3 = fcn.180498f10(pcVar1, 0x180626210), iVar3 == 0)) {
            return 0x5f;
        }
    }
code_r0x0001800ac007:
    iVar6 = *(int64_t *)(arg2 + 0x18);
    if (iVar6 != 0) {
        iVar5 = *(int64_t *)arg1;
        if (*(int64_t *)(arg2 + 0x10) == 0) {
            bVar8 = iVar5 == 0;
        } else {
            if (iVar5 == 0) {
                return 0xffffffff;
            }
            iVar3 = fcn.180498f10(iVar5);
            bVar8 = iVar3 == 0;
        }
        if (((bVar8) && (*(int64_t *)(arg1 + 8) != 0)) &&
           (iVar3 = fcn.180498f10(*(int64_t *)(arg1 + 8), iVar6), iVar3 == 0)) {
            return 0x36;
        }
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800ac080
// Address: 0x1800ac080
// Size: 98 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800ac080(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    undefined auStack_18 [16];
    
    if (*(char *)(arg2 + 0x48) == '\0') {
        var_10h = arg2;
        piVar2 = (int64_t *)
                 fcn.1800aa350((int64_t)auStack_18, *(int64_t *)(arg2 + 0x20), *(int64_t *)(arg1 + 0x110), 
                               *(int64_t *)(arg1 + 0x118));
        var_28h = *piVar2;
        var_20h = piVar2[1];
        if ((var_28h != 0) || (var_20h != 0)) {
            iVar1 = fcn.1800aa580((int64_t)&var_28h, *(int64_t *)(arg1 + 0x120));
            if ((iVar1 < 0) || (*(char *)((int64_t)iVar1 + 0x10 + arg1) == '\0')) {
                if (iVar1 == 0x39) {
                    if (*(int64_t *)(arg2 + 0x40) != 2) {
                        return 1;
                    }
                    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x38) + 8) + 8) != *(int32_t *)0x1807826b8) {
                        return 1;
                    }
                } else if (iVar1 < 0) {
                    return 1;
                }
                piVar3 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8), &var_10h);
                *piVar3 = iVar1;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800ac0e2
// Address: 0x1800ac0e2
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800ac080(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    undefined auStack_18 [16];
    
    if (*(char *)(arg2 + 0x48) == '\0') {
        var_10h = arg2;
        piVar2 = (int64_t *)
                 fcn.1800aa350((int64_t)auStack_18, *(int64_t *)(arg2 + 0x20), *(int64_t *)(arg1 + 0x110), 
                               *(int64_t *)(arg1 + 0x118));
        var_28h = *piVar2;
        var_20h = piVar2[1];
        if ((var_28h != 0) || (var_20h != 0)) {
            iVar1 = fcn.1800aa580((int64_t)&var_28h, *(int64_t *)(arg1 + 0x120));
            if ((iVar1 < 0) || (*(char *)((int64_t)iVar1 + 0x10 + arg1) == '\0')) {
                if (iVar1 == 0x39) {
                    if (*(int64_t *)(arg2 + 0x40) != 2) {
                        return 1;
                    }
                    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x38) + 8) + 8) != *(int32_t *)0x1807826b8) {
                        return 1;
                    }
                } else if (iVar1 < 0) {
                    return 1;
                }
                piVar3 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8), &var_10h);
                *piVar3 = iVar1;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800ac12b
// Address: 0x1800ac12b
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800ac080(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    undefined auStack_18 [16];
    
    if (*(char *)(arg2 + 0x48) == '\0') {
        var_10h = arg2;
        piVar2 = (int64_t *)
                 fcn.1800aa350((int64_t)auStack_18, *(int64_t *)(arg2 + 0x20), *(int64_t *)(arg1 + 0x110), 
                               *(int64_t *)(arg1 + 0x118));
        var_28h = *piVar2;
        var_20h = piVar2[1];
        if ((var_28h != 0) || (var_20h != 0)) {
            iVar1 = fcn.1800aa580((int64_t)&var_28h, *(int64_t *)(arg1 + 0x120));
            if ((iVar1 < 0) || (*(char *)((int64_t)iVar1 + 0x10 + arg1) == '\0')) {
                if (iVar1 == 0x39) {
                    if (*(int64_t *)(arg2 + 0x40) != 2) {
                        return 1;
                    }
                    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x38) + 8) + 8) != *(int32_t *)0x1807826b8) {
                        return 1;
                    }
                } else if (iVar1 < 0) {
                    return 1;
                }
                piVar3 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8), &var_10h);
                *piVar3 = iVar1;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800ac144
// Address: 0x1800ac144
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1800ac080(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    undefined auStack_18 [16];
    
    if (*(char *)(arg2 + 0x48) == '\0') {
        var_10h = arg2;
        piVar2 = (int64_t *)
                 fcn.1800aa350((int64_t)auStack_18, *(int64_t *)(arg2 + 0x20), *(int64_t *)(arg1 + 0x110), 
                               *(int64_t *)(arg1 + 0x118));
        var_28h = *piVar2;
        var_20h = piVar2[1];
        if ((var_28h != 0) || (var_20h != 0)) {
            iVar1 = fcn.1800aa580((int64_t)&var_28h, *(int64_t *)(arg1 + 0x120));
            if ((iVar1 < 0) || (*(char *)((int64_t)iVar1 + 0x10 + arg1) == '\0')) {
                if (iVar1 == 0x39) {
                    if (*(int64_t *)(arg2 + 0x40) != 2) {
                        return 1;
                    }
                    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(arg2 + 0x38) + 8) + 8) != *(int32_t *)0x1807826b8) {
                        return 1;
                    }
                } else if (iVar1 < 0) {
                    return 1;
                }
                piVar3 = (int32_t *)func_0x0001800ac540(*(undefined8 *)(arg1 + 8), &var_10h);
                *piVar3 = iVar1;
            }
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800ac160
// Address: 0x1800ac160
// Size: 43 bytes
// ============================================================
int64_t fcn.1800ac160(int64_t arg1)
{
    uint64_t in_RDX;
    
    *(undefined8 *)arg1 = 0x18063f2c0;
    if ((in_RDX & 1) != 0) {
        fcn.180459c3c(arg1, 0x130);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800ac190
// Address: 0x1800ac190
// Size: 511 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_19ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1bch
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ach
// WARNING: [rz-ghidra] Detected overlap for variable var_198h

void fcn.1800ac190(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t *piVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    undefined auStack_1e8 [32];
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1b8h;
    int64_t var_1b0h;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1e8;
    var_178h = 0x18063f0b0;
    var_50h = arg_30h;
    var_170h = arg1;
    var_68h = arg2;
    var_60h = arg3;
    var_58h = arg4;
    func_0x0001804986e0(&var_168h, 0, 0x100);
    piVar5 = *(int64_t **)(arg4 + 0x50);
    if (piVar5 != (int64_t *)0x0) {
        iVar2 = *piVar5;
        while (iVar2 != 0) {
            iVar2 = func_0x00018045b928(iVar2, 0x2e);
            if (iVar2 == 0) {
                iVar2 = *piVar5;
                var_1a0h._0_4_ = func_0x000180498cd0(iVar2);
                var_1a0h._4_4_ = 0;
                var_1a8h = iVar2;
                piVar3 = (int64_t *)func_0x0001800d8ef0(arg_30h, &var_1a8h);
                if (((piVar3 != (int64_t *)0x0) && (iVar2 = *piVar3, iVar2 != 0)) &&
                   (iVar1 = fcn.1800aa2c0(arg2, iVar2), iVar1 == 0)) {
                    var_188h = 0;
                    piVar3 = &var_188h;
                    var_180h = iVar2;
                    goto code_r0x0001800ac333;
                }
            } else {
                var_1c8h = *piVar5;
                var_1c0h._0_4_ = (int32_t)iVar2 - (int32_t)var_1c8h;
                var_1c0h._4_4_ = 0;
                piVar3 = (int64_t *)func_0x0001800d8ef0(arg_30h, &var_1c8h);
                if (piVar3 == (int64_t *)0x0) {
                    iVar4 = 0;
                } else {
                    iVar4 = *piVar3;
                }
                var_1b0h._0_4_ = func_0x000180498cd0(iVar2 + 1);
                var_1b0h._4_4_ = 0;
                var_1b8h = iVar2 + 1;
                piVar3 = (int64_t *)func_0x0001800d8ef0(arg_30h);
                if (piVar3 == (int64_t *)0x0) {
                    iVar2 = 0;
                } else {
                    iVar2 = *piVar3;
                }
                if (((iVar4 != 0) && (iVar2 != 0)) && (iVar1 = fcn.1800aa2c0(arg2, iVar2), iVar1 == 0)) {
                    piVar3 = &var_198h;
                    var_198h = iVar4;
                    var_190h = iVar2;
code_r0x0001800ac333:
                    iVar1 = fcn.1800aa580((int64_t)piVar3, arg4);
                    if (-1 < iVar1) {
                        *(undefined *)((int64_t)&var_168h + (int64_t)iVar1) = 1;
                    }
                }
            }
            piVar5 = piVar5 + 1;
            iVar2 = *piVar5;
        }
    }
    (***(code ***)arg_28h)(arg_28h, &var_178h);
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1e8);
    return;
}

// ============================================================
// Function: FUN_1800ac540
// Address: 0x1800ac540
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800ac540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ac6c3;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800ac5e0:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800ac5e0;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ac680;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ac680;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ac680:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ac6c3:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ac573
// Address: 0x1800ac573
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800ac540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ac6c3;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800ac5e0:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800ac5e0;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ac680;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ac680;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ac680:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ac6c3:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ac57d
// Address: 0x1800ac57d
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800ac540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ac6c3;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800ac5e0:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800ac5e0;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ac680;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ac680;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ac680:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ac6c3:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ac620
// Address: 0x1800ac620
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800ac540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ac6c3;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800ac5e0:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800ac5e0;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ac680;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ac680;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ac680:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ac6c3:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ac6be
// Address: 0x1800ac6be
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800ac540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800ac6c3;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = func_0x000180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800ac5e0:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined4 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            iVar3 = 0;
            uVar9 = 0;
        } else {
            iVar3 = func_0x000180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800ac5e0;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar6 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar8 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar8 == uVar1) {
                        *puVar8 = uVar4;
                        goto code_r0x0001800ac680;
                    }
                    if (*puVar8 == uVar4) goto code_r0x0001800ac680;
                    uVar5 = uVar5 + 1 + uVar6;
                    uVar6 = uVar6 + 1;
                } while (uVar6 <= uVar9 - 1);
                puVar8 = (uint64_t *)0x0;
code_r0x0001800ac680:
                iVar2 = *(int64_t *)arg1;
                *puVar8 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                *(undefined4 *)(puVar8 + 1) = *(undefined4 *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800ac6c3:
    iVar3 = func_0x0001800ac6e0(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800ac6e0
// Address: 0x1800ac6e0
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t * fcn.1800ac6e0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t *puVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)arg2;
    uVar5 = *(int64_t *)(arg1 + 8) - 1;
    uVar2 = (uVar1 >> 5 ^ uVar1) >> 4;
    uVar3 = 0;
    while( true ) {
        uVar2 = uVar2 & uVar5;
        puVar4 = (uint64_t *)(uVar2 * 0x10 + *(int64_t *)arg1);
        if (*puVar4 == *(uint64_t *)(arg1 + 0x18)) {
            *puVar4 = uVar1;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return puVar4;
        }
        if (*puVar4 == uVar1) break;
        uVar2 = uVar2 + 1 + uVar3;
        uVar3 = uVar3 + 1;
        if (uVar5 < uVar3) {
            return (uint64_t *)0x0;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800ac770
// Address: 0x1800ac770
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800ac770(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar5 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar5;
                uVar2 = *(uint64_t *)(*(int64_t *)arg1 + uVar3 * 0x18);
                if (uVar2 == uVar1) {
                    return *(int64_t *)arg1 + uVar3 * 0x18;
                }
                if (uVar2 == *(uint64_t *)(arg1 + 0x18)) {
                    return 0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800ac7f0
// Address: 0x1800ac7f0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t * fcn.1800ac7f0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint64_t *)arg2;
        if (uVar1 != *(uint64_t *)(arg1 + 0x18)) {
            uVar6 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (uVar1 >> 5 ^ uVar1) >> 4;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar6;
                puVar5 = (uint64_t *)(uVar3 * 0x10 + *(int64_t *)arg1);
                uVar2 = *puVar5;
                if (uVar2 == uVar1) {
                    return puVar5;
                }
                if (uVar2 == *(uint64_t *)(arg1 + 0x18)) {
                    return (uint64_t *)0x0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar6);
        }
    }
    return (uint64_t *)0x0;
}

// ============================================================
// Function: FUN_1800ac870
// Address: 0x1800ac870
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800ac870(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar12 = 0;
            goto code_r0x0001800ac913;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800ac913;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800ac913:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar11 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar11 == uVar1) {
                        *puVar11 = uVar6;
                        goto code_r0x0001800ac990;
                    }
                    if (*puVar11 == uVar6) goto code_r0x0001800ac990;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar12 - 1);
                puVar11 = (uint64_t *)0x0;
code_r0x0001800ac990:
                iVar10 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar11 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800ac877
// Address: 0x1800ac877
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800ac870(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar12 = 0;
            goto code_r0x0001800ac913;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800ac913;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800ac913:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar11 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar11 == uVar1) {
                        *puVar11 = uVar6;
                        goto code_r0x0001800ac990;
                    }
                    if (*puVar11 == uVar6) goto code_r0x0001800ac990;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar12 - 1);
                puVar11 = (uint64_t *)0x0;
code_r0x0001800ac990:
                iVar10 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar11 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800ac882
// Address: 0x1800ac882
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800ac870(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar12 = 0;
            goto code_r0x0001800ac913;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800ac913;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800ac913:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar11 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar11 == uVar1) {
                        *puVar11 = uVar6;
                        goto code_r0x0001800ac990;
                    }
                    if (*puVar11 == uVar6) goto code_r0x0001800ac990;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar12 - 1);
                puVar11 = (uint64_t *)0x0;
code_r0x0001800ac990:
                iVar10 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar11 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800ac930
// Address: 0x1800ac930
// Size: 168 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800ac870(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar12 = 0;
            goto code_r0x0001800ac913;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800ac913;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800ac913:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar11 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar11 == uVar1) {
                        *puVar11 = uVar6;
                        goto code_r0x0001800ac990;
                    }
                    if (*puVar11 == uVar6) goto code_r0x0001800ac990;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar12 - 1);
                puVar11 = (uint64_t *)0x0;
code_r0x0001800ac990:
                iVar10 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar11 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800ac9d8
// Address: 0x1800ac9d8
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800ac870(int64_t arg1)
{
    uint64_t uVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    uint64_t *puVar11;
    uint64_t uVar12;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_10h;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)(arg1 + 8);
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar4 == 0) {
        uVar9 = 0x10;
        iVar4 = func_0x000180459890(0x100);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = 0x10;
    } else {
        uVar9 = iVar4 * 2;
        if (uVar9 == 0) {
            iVar4 = 0;
            uVar12 = 0;
            goto code_r0x0001800ac913;
        }
        iVar4 = func_0x000180459890(iVar4 << 5);
        uVar6 = 0;
        iVar10 = iVar4;
        uVar12 = uVar9;
        if (uVar9 == 0) goto code_r0x0001800ac913;
    }
    do {
        uVar7 = uVar6 + 1;
        *(uint64_t *)(iVar10 + uVar6 * 0x10) = *(uint64_t *)(arg1 + 0x18);
        *(undefined4 *)(iVar10 + 8 + uVar6 * 0x10) = 0;
        uVar6 = uVar7;
    } while (uVar7 < uVar9);
code_r0x0001800ac913:
    uVar9 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar6 = *(uint64_t *)(*(int64_t *)arg1 + uVar9 * 0x10);
            if (uVar6 != *(uint64_t *)(arg1 + 0x18)) {
                uVar7 = (uVar6 >> 5 ^ uVar6) >> 4;
                uVar8 = 0;
                do {
                    uVar7 = uVar7 & uVar12 - 1;
                    puVar11 = (uint64_t *)(uVar7 * 0x10 + iVar4);
                    if (*puVar11 == uVar1) {
                        *puVar11 = uVar6;
                        goto code_r0x0001800ac990;
                    }
                    if (*puVar11 == uVar6) goto code_r0x0001800ac990;
                    uVar7 = uVar7 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar12 - 1);
                puVar11 = (uint64_t *)0x0;
code_r0x0001800ac990:
                iVar10 = *(int64_t *)arg1;
                *puVar11 = *(uint64_t *)(iVar10 + uVar9 * 0x10);
                *(undefined4 *)(puVar11 + 1) = *(undefined4 *)(iVar10 + 8 + uVar9 * 0x10);
            }
            uVar9 = uVar9 + 1;
        } while (uVar9 < *(uint64_t *)(arg1 + 8));
    }
    iVar10 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar4;
    *(uint64_t *)(arg1 + 8) = uVar12;
    if (iVar10 == 0) {
        return;
    }
    if ((iVar10 != 0) && (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar10), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar5 = (undefined4 *)fcn.18046b77c();
        *puVar5 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_1800ac9f0
// Address: 0x1800ac9f0
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800ac9f0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t *in_RAX;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0x10) != 0) && (arg2 != *(int64_t *)(arg1 + 0x18))) {
        uVar6 = *(int64_t *)(arg1 + 8) - 1;
        in_RAX = (int64_t *)(((uint64_t)arg2 >> 5 ^ arg2) >> 4 & uVar6);
        uVar4 = 0;
        do {
            piVar5 = (int64_t *)((int64_t)in_RAX * 0x20 + *(int64_t *)arg1);
            if (*piVar5 == arg2) {
                in_RAX = (int64_t *)0x0;
                piVar3 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar3 = in_RAX;
                }
                if (piVar3 != (int64_t *)0x0) {
                    uVar1 = *(uint32_t *)piVar3;
                    in_RAX = (int64_t *)(uint64_t)uVar1;
                    if ((1 < uVar1) && ((uVar1 != 2 || (*(char *)(piVar3 + 1) != '\0')))) {
                        return CONCAT71((unkuint7)(unkuint3)(uVar1 >> 8), 1);
                    }
                }
                break;
            }
            if (*piVar5 == *(int64_t *)(arg1 + 0x18)) break;
            iVar2 = uVar4 + 1;
            uVar4 = uVar4 + 1;
            in_RAX = (int64_t *)((int64_t)in_RAX + iVar2 & uVar6);
        } while (uVar4 <= uVar6);
    }
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800aca90
// Address: 0x1800aca90
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800aca90(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t *in_RAX;
    int64_t *piVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0x10) != 0) && (arg2 != *(int64_t *)(arg1 + 0x18))) {
        uVar6 = *(int64_t *)(arg1 + 8) - 1;
        in_RAX = (int64_t *)(((uint64_t)arg2 >> 5 ^ arg2) >> 4 & uVar6);
        uVar4 = 0;
        do {
            piVar5 = (int64_t *)((int64_t)in_RAX * 0x20 + *(int64_t *)arg1);
            if (*piVar5 == arg2) {
                in_RAX = (int64_t *)0x0;
                piVar3 = piVar5 + 1;
                if (piVar5 == (int64_t *)0x0) {
                    piVar3 = in_RAX;
                }
                if (piVar3 != (int64_t *)0x0) {
                    uVar1 = *(uint32_t *)piVar3;
                    in_RAX = (int64_t *)(uint64_t)uVar1;
                    if ((uVar1 != 0) && ((uVar1 == 1 || ((uVar1 == 2 && (*(char *)(piVar3 + 1) == '\0')))))) {
                        return CONCAT71((unkuint7)(unkuint3)(uVar1 >> 8), 1);
                    }
                }
                break;
            }
            if (*piVar5 == *(int64_t *)(arg1 + 0x18)) break;
            iVar2 = uVar4 + 1;
            uVar4 = uVar4 + 1;
            in_RAX = (int64_t *)((int64_t)in_RAX + iVar2 & uVar6);
        } while (uVar4 <= uVar6);
    }
    return (uint64_t)in_RAX & 0xffffffffffffff00;
}

// ============================================================
// Function: FUN_1800acb30
// Address: 0x1800acb30
// Size: 299 bytes
// ============================================================
undefined8 fcn.1800acb30(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t arg2_00;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    char cVar7;
    int64_t iVar8;
    uint64_t uVar9;
    
    iVar6 = *(int32_t *)0x180782750;
    iVar5 = *(int32_t *)0x180782724;
    iVar4 = *(int32_t *)0x180782718;
    iVar3 = *(int32_t *)0x180782700;
    iVar2 = *(int32_t *)0x1807826d0;
    iVar8 = 0;
    if (*(int32_t *)(arg2 + 8) == *(int32_t *)0x180782718) {
        iVar8 = arg2;
    }
    while( true ) {
        if (iVar8 != 0) {
            uVar9 = 0;
            if (*(int64_t *)(iVar8 + 0x30) != 0) {
                do {
                    cVar7 = fcn.1800acb30(arg1, *(int64_t *)(*(int64_t *)(iVar8 + 0x28) + uVar9 * 8));
                    if (cVar7 != '\0') {
                        return 1;
                    }
                    uVar9 = uVar9 + 1;
                } while (uVar9 < *(uint64_t *)(iVar8 + 0x30));
            }
            return 0;
        }
        iVar1 = *(int32_t *)(arg2 + 8);
        if (iVar1 == iVar2) {
            return 1;
        }
        if (iVar1 == iVar3) {
            return 1;
        }
        if (iVar1 == iVar6) break;
        iVar8 = 0;
        if (iVar1 == iVar5) {
            iVar8 = arg2;
        }
        if (iVar8 == 0) {
            return 0;
        }
        arg2_00 = *(int64_t *)(iVar8 + 0x28);
        cVar7 = fcn.1800ac9f0(arg1, arg2_00);
        if (cVar7 == '\0') {
            cVar7 = fcn.1800aca90(arg1, arg2_00);
            if ((cVar7 == '\0') || (arg2 = *(int64_t *)(iVar8 + 0x38), arg2 == 0)) {
                if (*(int64_t *)(iVar8 + 0x38) == 0) {
                    return 0;
                }
                cVar7 = fcn.1800acb30(arg1, *(int64_t *)(iVar8 + 0x30));
                if (cVar7 != '\0') {
                    cVar7 = fcn.1800acb30(arg1, *(int64_t *)(iVar8 + 0x38));
                    if (cVar7 != '\0') {
                        return 1;
                    }
                    return 0;
                }
                return 0;
            }
        } else {
            arg2 = *(int64_t *)(iVar8 + 0x30);
        }
        iVar8 = 0;
        if (*(int32_t *)(arg2 + 8) == iVar4) {
            iVar8 = arg2;
        }
    }
    return 1;
}

// ============================================================
// Function: FUN_1800acc60
// Address: 0x1800acc60
// Size: 41 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800acc60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498a80(arg2, 0x25);
    if (iVar4 != 0) {
        uVar5 = 0;
        if (arg3 != 0) {
            do {
                uVar2 = *(uint64_t *)(arg1 + 0x10);
                cVar1 = *(char *)(arg2 + uVar5);
                if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                    *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                    iVar4 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    *(char *)(uVar2 + iVar4) = cVar1;
                    *(undefined *)(uVar2 + 1 + iVar4) = 0;
                } else {
                    iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, cVar1);
                }
                if (cVar1 == '%') {
                    uVar2 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined2 *)(uVar2 + iVar4) = 0x25;
                    } else {
                        iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, 0x25);
                    }
                }
                uVar5 = uVar5 + 1;
            } while (uVar5 < (uint64_t)arg3);
        }
        return iVar4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar4 < (uint64_t)arg3) {
        iVar4 = func_0x00018000ee80(arg1, arg3, var_8h & 0xff, arg2, arg3);
        return iVar4;
    }
    *(int64_t *)(arg1 + 0x10) = iVar4 + arg3;
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar4 + iVar3, arg2, arg3);
    *(undefined *)(iVar4 + iVar3 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800acc89
// Address: 0x1800acc89
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800acc60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498a80(arg2, 0x25);
    if (iVar4 != 0) {
        uVar5 = 0;
        if (arg3 != 0) {
            do {
                uVar2 = *(uint64_t *)(arg1 + 0x10);
                cVar1 = *(char *)(arg2 + uVar5);
                if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                    *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                    iVar4 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    *(char *)(uVar2 + iVar4) = cVar1;
                    *(undefined *)(uVar2 + 1 + iVar4) = 0;
                } else {
                    iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, cVar1);
                }
                if (cVar1 == '%') {
                    uVar2 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined2 *)(uVar2 + iVar4) = 0x25;
                    } else {
                        iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, 0x25);
                    }
                }
                uVar5 = uVar5 + 1;
            } while (uVar5 < (uint64_t)arg3);
        }
        return iVar4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar4 < (uint64_t)arg3) {
        iVar4 = func_0x00018000ee80(arg1, arg3, var_8h & 0xff, arg2, arg3);
        return iVar4;
    }
    *(int64_t *)(arg1 + 0x10) = iVar4 + arg3;
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar4 + iVar3, arg2, arg3);
    *(undefined *)(iVar4 + iVar3 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800acc9a
// Address: 0x1800acc9a
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800acc60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498a80(arg2, 0x25);
    if (iVar4 != 0) {
        uVar5 = 0;
        if (arg3 != 0) {
            do {
                uVar2 = *(uint64_t *)(arg1 + 0x10);
                cVar1 = *(char *)(arg2 + uVar5);
                if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                    *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                    iVar4 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    *(char *)(uVar2 + iVar4) = cVar1;
                    *(undefined *)(uVar2 + 1 + iVar4) = 0;
                } else {
                    iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, cVar1);
                }
                if (cVar1 == '%') {
                    uVar2 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined2 *)(uVar2 + iVar4) = 0x25;
                    } else {
                        iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, 0x25);
                    }
                }
                uVar5 = uVar5 + 1;
            } while (uVar5 < (uint64_t)arg3);
        }
        return iVar4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar4 < (uint64_t)arg3) {
        iVar4 = func_0x00018000ee80(arg1, arg3, var_8h & 0xff, arg2, arg3);
        return iVar4;
    }
    *(int64_t *)(arg1 + 0x10) = iVar4 + arg3;
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar4 + iVar3, arg2, arg3);
    *(undefined *)(iVar4 + iVar3 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800acd64
// Address: 0x1800acd64
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800acc60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498a80(arg2, 0x25);
    if (iVar4 != 0) {
        uVar5 = 0;
        if (arg3 != 0) {
            do {
                uVar2 = *(uint64_t *)(arg1 + 0x10);
                cVar1 = *(char *)(arg2 + uVar5);
                if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                    *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                    iVar4 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    *(char *)(uVar2 + iVar4) = cVar1;
                    *(undefined *)(uVar2 + 1 + iVar4) = 0;
                } else {
                    iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, cVar1);
                }
                if (cVar1 == '%') {
                    uVar2 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined2 *)(uVar2 + iVar4) = 0x25;
                    } else {
                        iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, 0x25);
                    }
                }
                uVar5 = uVar5 + 1;
            } while (uVar5 < (uint64_t)arg3);
        }
        return iVar4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar4 < (uint64_t)arg3) {
        iVar4 = func_0x00018000ee80(arg1, arg3, var_8h & 0xff, arg2, arg3);
        return iVar4;
    }
    *(int64_t *)(arg1 + 0x10) = iVar4 + arg3;
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar4 + iVar3, arg2, arg3);
    *(undefined *)(iVar4 + iVar3 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800acd73
// Address: 0x1800acd73
// Size: 23 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800acc60(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_50h, int64_t arg_58h)
{
    char cVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    iVar4 = func_0x000180498a80(arg2, 0x25);
    if (iVar4 != 0) {
        uVar5 = 0;
        if (arg3 != 0) {
            do {
                uVar2 = *(uint64_t *)(arg1 + 0x10);
                cVar1 = *(char *)(arg2 + uVar5);
                if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                    *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                    iVar4 = arg1;
                    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                        iVar4 = *(int64_t *)arg1;
                    }
                    *(char *)(uVar2 + iVar4) = cVar1;
                    *(undefined *)(uVar2 + 1 + iVar4) = 0;
                } else {
                    iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, cVar1);
                }
                if (cVar1 == '%') {
                    uVar2 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar2 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar2 + 1;
                        iVar4 = arg1;
                        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                            iVar4 = *(int64_t *)arg1;
                        }
                        *(undefined2 *)(uVar2 + iVar4) = 0x25;
                    } else {
                        iVar4 = func_0x00018000f010(arg1, 1, (undefined)var_20h, 0x25);
                    }
                }
                uVar5 = uVar5 + 1;
            } while (uVar5 < (uint64_t)arg3);
        }
        return iVar4;
    }
    iVar4 = *(int64_t *)(arg1 + 0x10);
    if (*(uint64_t *)(arg1 + 0x18) - iVar4 < (uint64_t)arg3) {
        iVar4 = func_0x00018000ee80(arg1, arg3, var_8h & 0xff, arg2, arg3);
        return iVar4;
    }
    *(int64_t *)(arg1 + 0x10) = iVar4 + arg3;
    iVar3 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar3 = *(int64_t *)arg1;
    }
    func_0x000180498030(iVar4 + iVar3, arg2, arg3);
    *(undefined *)(iVar4 + iVar3 + arg3) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_1800acdf0
// Address: 0x1800acdf0
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800acdf0(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x180640178;
    fcn.180004e40(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    fcn.18045b56c(arg1 + 8);
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x48);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800ace50
// Address: 0x1800ace50
// Size: 52 bytes
// ============================================================
void fcn.1800ace50(int64_t arg1)
{
    *(undefined8 *)arg1 = 0x180640178;
    fcn.180004e40(arg1 + 0x28);
    *(undefined8 *)arg1 = 0x1804a5358;
    if (*(char *)(arg1 + 0x10) != '\0') {
        fcn.180460d90(*(undefined8 *)(arg1 + 8));
    }
    *(undefined *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800acea0
// Address: 0x1800acea0
// Size: 89 bytes
// ============================================================
void fcn.1800acea0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    undefined8 uVar2;
    int64_t iStackX_18;
    int64_t iStackX_20;
    int64_t in_stack_ffffffffffffff58;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_58h;
    
    iStackX_18 = arg3;
    iStackX_20 = arg4;
    fcn.1800d4cb0(&var_80h, arg2, &iStackX_18);
    uVar2 = fcn.18000b4d0(&var_a0h, &var_80h);
    fcn.1800acd90(&var_58h, arg1, uVar2);
    fcn.18045bae0(in_stack_ffffffffffffff58);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800acf00
// Address: 0x1800acf00
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800acf00(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x180640178;
    uVar1 = *(undefined4 *)(arg2 + 0x1c);
    uVar2 = *(undefined4 *)(arg2 + 0x20);
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x1c) = uVar1;
    *(undefined4 *)(arg1 + 0x20) = uVar2;
    *(undefined4 *)(arg1 + 0x24) = uVar3;
    fcn.18000b4d0(arg1 + 0x28, arg2 + 0x28);
    return arg1;
}

// ============================================================
// Function: FUN_1800acf70
// Address: 0x1800acf70
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800acf70(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    uint8_t *puVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    if ((*(int64_t *)(arg1 + 0x98) != 0) && (arg2 != *(int64_t *)(arg1 + 0xa0))) {
        uVar6 = *(int64_t *)(arg1 + 0x90) - 1;
        uVar3 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar5 = 0;
        do {
            uVar3 = uVar3 & uVar6;
            iVar1 = *(int64_t *)(arg1 + 0x88) + uVar3 * 0x18;
            iVar2 = *(int64_t *)(*(int64_t *)(arg1 + 0x88) + uVar3 * 0x18);
            if (iVar2 == arg2) {
                puVar4 = (uint8_t *)(iVar1 + 8);
                if (iVar1 == 0) {
                    puVar4 = (uint8_t *)0x0;
                }
                if (puVar4 == (uint8_t *)0x0) {
                    return 0xffffffff;
                }
                if (puVar4[1] == 0) {
                    return 0xffffffff;
                }
                return (uint64_t)*puVar4;
            }
            if (iVar2 == *(int64_t *)(arg1 + 0xa0)) {
                return 0xffffffff;
            }
            uVar3 = uVar3 + 1 + uVar5;
            uVar5 = uVar5 + 1;
        } while (uVar5 <= uVar6);
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1800ad020
// Address: 0x1800ad020
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800ad020(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = 0;
    uVar6 = *(int64_t *)(arg1 + 0x660) - *(int64_t *)(arg1 + 0x658) >> 3;
    if (uVar6 != 0) {
        do {
            if (*(int64_t *)(*(int64_t *)(arg1 + 0x658) + uVar3 * 8) == arg2) {
                return uVar3;
            }
            uVar3 = uVar3 + 1;
        } while (uVar3 < uVar6);
    }
    var_10h = arg2;
    if (199 < uVar6) {
        fcn.1800acea0(arg2 + 8, 0x18063f720, *(int64_t *)arg2, 200);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if ((*(int64_t *)(arg1 + 0xe8) != 0) && (arg2 != *(int64_t *)(arg1 + 0xf0))) {
        uVar7 = *(int64_t *)(arg1 + 0xe0) - 1;
        uVar3 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar3 = uVar3 & uVar7;
            iVar4 = *(int64_t *)(arg1 + 0xd8) + uVar3 * 0x18;
            iVar5 = *(int64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar3 * 0x18);
            if (iVar5 == arg2) {
                iVar5 = iVar4 + 8;
                if (iVar4 == 0) {
                    iVar5 = 0;
                }
                if ((iVar5 != 0) && (*(char *)(iVar5 + 8) != '\0')) {
                    iVar4 = func_0x0001800c0050(arg1 + 0x88, &var_10h);
                    *(undefined *)(iVar4 + 2) = 1;
                }
                break;
            }
            if (iVar5 == *(int64_t *)(arg1 + 0xf0)) break;
            uVar3 = uVar3 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
    }
    func_0x0001800bf890(arg1 + 0x658, &var_10h);
    uVar2 = *(int32_t *)(arg1 + 0x660) - *(int32_t *)(arg1 + 0x658);
    return CONCAT71((unkint7)(unkuint7)(unkuint3)(uVar2 >> 8) >> 3, (char)((int64_t)(uint64_t)uVar2 >> 3) + -1);
}

// ============================================================
// Function: FUN_1800ad0a1
// Address: 0x1800ad0a1
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800ad020(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = 0;
    uVar6 = *(int64_t *)(arg1 + 0x660) - *(int64_t *)(arg1 + 0x658) >> 3;
    if (uVar6 != 0) {
        do {
            if (*(int64_t *)(*(int64_t *)(arg1 + 0x658) + uVar3 * 8) == arg2) {
                return uVar3;
            }
            uVar3 = uVar3 + 1;
        } while (uVar3 < uVar6);
    }
    var_10h = arg2;
    if (199 < uVar6) {
        fcn.1800acea0(arg2 + 8, 0x18063f720, *(int64_t *)arg2, 200);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if ((*(int64_t *)(arg1 + 0xe8) != 0) && (arg2 != *(int64_t *)(arg1 + 0xf0))) {
        uVar7 = *(int64_t *)(arg1 + 0xe0) - 1;
        uVar3 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar3 = uVar3 & uVar7;
            iVar4 = *(int64_t *)(arg1 + 0xd8) + uVar3 * 0x18;
            iVar5 = *(int64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar3 * 0x18);
            if (iVar5 == arg2) {
                iVar5 = iVar4 + 8;
                if (iVar4 == 0) {
                    iVar5 = 0;
                }
                if ((iVar5 != 0) && (*(char *)(iVar5 + 8) != '\0')) {
                    iVar4 = func_0x0001800c0050(arg1 + 0x88, &var_10h);
                    *(undefined *)(iVar4 + 2) = 1;
                }
                break;
            }
            if (iVar5 == *(int64_t *)(arg1 + 0xf0)) break;
            uVar3 = uVar3 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
    }
    func_0x0001800bf890(arg1 + 0x658, &var_10h);
    uVar2 = *(int32_t *)(arg1 + 0x660) - *(int32_t *)(arg1 + 0x658);
    return CONCAT71((unkint7)(unkuint7)(unkuint3)(uVar2 >> 8) >> 3, (char)((int64_t)(uint64_t)uVar2 >> 3) + -1);
}

// ============================================================
// Function: FUN_1800ad11a
// Address: 0x1800ad11a
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1800ad020(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar3 = 0;
    uVar6 = *(int64_t *)(arg1 + 0x660) - *(int64_t *)(arg1 + 0x658) >> 3;
    if (uVar6 != 0) {
        do {
            if (*(int64_t *)(*(int64_t *)(arg1 + 0x658) + uVar3 * 8) == arg2) {
                return uVar3;
            }
            uVar3 = uVar3 + 1;
        } while (uVar3 < uVar6);
    }
    var_10h = arg2;
    if (199 < uVar6) {
        fcn.1800acea0(arg2 + 8, 0x18063f720, *(int64_t *)arg2, 200);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if ((*(int64_t *)(arg1 + 0xe8) != 0) && (arg2 != *(int64_t *)(arg1 + 0xf0))) {
        uVar7 = *(int64_t *)(arg1 + 0xe0) - 1;
        uVar3 = ((uint64_t)arg2 >> 5 ^ arg2) >> 4;
        uVar6 = 0;
        do {
            uVar3 = uVar3 & uVar7;
            iVar4 = *(int64_t *)(arg1 + 0xd8) + uVar3 * 0x18;
            iVar5 = *(int64_t *)(*(int64_t *)(arg1 + 0xd8) + uVar3 * 0x18);
            if (iVar5 == arg2) {
                iVar5 = iVar4 + 8;
                if (iVar4 == 0) {
                    iVar5 = 0;
                }
                if ((iVar5 != 0) && (*(char *)(iVar5 + 8) != '\0')) {
                    iVar4 = func_0x0001800c0050(arg1 + 0x88, &var_10h);
                    *(undefined *)(iVar4 + 2) = 1;
                }
                break;
            }
            if (iVar5 == *(int64_t *)(arg1 + 0xf0)) break;
            uVar3 = uVar3 + 1 + uVar6;
            uVar6 = uVar6 + 1;
        } while (uVar6 <= uVar7);
    }
    func_0x0001800bf890(arg1 + 0x658, &var_10h);
    uVar2 = *(int32_t *)(arg1 + 0x660) - *(int32_t *)(arg1 + 0x658);
    return CONCAT71((unkint7)(unkuint7)(unkuint3)(uVar2 >> 8) >> 3, (char)((int64_t)(uint64_t)uVar2 >> 3) + -1);
}

// ============================================================
// Function: FUN_1800ad170
// Address: 0x1800ad170
// Size: 101 bytes
// ============================================================
void fcn.1800ad170(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    int64_t var_10h;
    
    if (*(char *)(arg2 + 0x31) != '\0') {
        var_10h = arg2;
        if ((((*(int64_t *)(arg1 + 0x628) == 0) || (*(int64_t *)(*(int64_t *)(arg1 + 0x628) + 0x98) != 0)) ||
            (*(int64_t *)(arg1 + 0x630) != 0)) || (*(int64_t *)(arg1 + 0x688) != *(int64_t *)(arg1 + 0x690))) {
            fcn.1800acea0(arg3, 0x18063f768, arg3, arg4);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        fcn.1800bf890(arg1 + 0x6d0, &var_10h);
    }
    return;
}

// ============================================================
// Function: FUN_1800ad1e0
// Address: 0x1800ad1e0
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800ad1e0(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t *piVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    code *pcVar6;
    uint32_t uVar7;
    uint64_t uVar8;
    undefined *puVar9;
    undefined4 uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar2 = (int64_t *)(arg1 + 0x5c0);
    if ((*(int64_t *)(arg1 + 0x98) != 0) && (piVar2 != *(int64_t **)(arg1 + 0xa0))) {
        uVar12 = *(int64_t *)(arg1 + 0x90) - 1;
        uVar8 = ((uint64_t)piVar2 >> 5 ^ (uint64_t)piVar2) >> 4;
        uVar11 = 0;
        do {
            uVar8 = uVar8 & uVar12;
            piVar4 = *(int64_t **)(*(int64_t *)(arg1 + 0x88) + uVar8 * 0x18);
            if (piVar4 == piVar2) {
                return;
            }
            if (piVar4 == *(int64_t **)(arg1 + 0xa0)) break;
            uVar8 = uVar8 + 1 + uVar11;
            uVar11 = uVar11 + 1;
        } while (uVar11 <= uVar12);
    }
    uVar3 = *(uint32_t *)(arg1 + 0x60c);
    uVar1 = uVar3 + 1;
    if (0xff < uVar1) {
        fcn.1800acea0(arg2 + 0xc, 0x18063fbc0, 1, 0xff);
        pcVar6 = (code *)swi(3);
        (*pcVar6)();
        return;
    }
    *(uint32_t *)(arg1 + 0x60c) = uVar1;
    uVar7 = *(uint32_t *)(arg1 + 0x610);
    if (*(uint32_t *)(arg1 + 0x610) < uVar1) {
        uVar7 = uVar1;
    }
    *(uint32_t *)(arg1 + 0x610) = uVar7;
    iVar5 = *(int64_t *)arg1;
    var_8h = CONCAT44(var_8h._4_4_, (uVar3 & 0xff) << 8) | 0x35;
    func_0x0001800d31a0(iVar5 + 0x28, &var_8h);
    func_0x0001800d31a0(iVar5 + 0x40, iVar5 + 0x270);
    iVar5 = *(int64_t *)arg1;
    var_8h = var_8h & 0xffffffff00000000;
    func_0x0001800d31a0(iVar5 + 0x28, &var_8h);
    func_0x0001800d31a0(iVar5 + 0x40, iVar5 + 0x270);
    var_8h = (int64_t)piVar2;
    if ((uint64_t)(*(int64_t *)(arg1 + 0x648) - *(int64_t *)(arg1 + 0x640) >> 3) < 200) {
        fcn.1800bf890((int64_t *)(arg1 + 0x640), &var_8h);
        puVar9 = (undefined *)func_0x0001800c0050(arg1 + 0x88, &var_8h);
        *puVar9 = (char)uVar3;
        puVar9[1] = 1;
        uVar10 = (undefined4)(*(int64_t *)(*(int64_t *)arg1 + 0x30) - *(int64_t *)(*(int64_t *)arg1 + 0x28) >> 2);
        *(undefined4 *)(puVar9 + 4) = uVar10;
        *(undefined4 *)(puVar9 + 8) = uVar10;
        return;
    }
    fcn.1800acea0(arg1 + 0x5c8, 0x18063fb70, *piVar2, 200);
    pcVar6 = (code *)swi(3);
    (*pcVar6)();
    return;
}

