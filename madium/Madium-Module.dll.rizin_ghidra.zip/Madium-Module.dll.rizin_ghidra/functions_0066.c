// Chunk 66 - 50 functions

// ============================================================
// Function: FUN_1800d3850
// Address: 0x1800d3850
// Size: 239 bytes
// ============================================================
undefined4 * fcn.1800d3850(int64_t arg1, int64_t arg2)
{
    uint8_t *puVar1;
    undefined4 *puVar2;
    uint64_t uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    uint64_t uVar12;
    bool bVar13;
    
    uVar3 = *(uint64_t *)(arg2 + 8);
    uVar8 = 0x811c9dc5;
    if (uVar3 != 0) {
        uVar10 = 0;
        do {
            puVar1 = (uint8_t *)(*(int64_t *)arg2 + uVar10);
            uVar10 = uVar10 + 1;
            uVar8 = (*puVar1 ^ uVar8) * 0x1000193;
        } while (uVar10 < uVar3);
    }
    uVar11 = *(int64_t *)(arg1 + 8) - 1;
    uVar10 = (uint64_t)uVar8;
    uVar12 = 0;
    do {
        uVar10 = uVar10 & uVar11;
        iVar9 = *(int64_t *)(*(int64_t *)arg1 + uVar10 * 0x18);
        puVar2 = (undefined4 *)(*(int64_t *)arg1 + uVar10 * 0x18);
        if ((iVar9 == 0) || (*(int64_t *)(arg1 + 0x18) == 0)) {
            if (iVar9 == *(int64_t *)(arg1 + 0x18)) goto code_r0x0001800d38d7;
            if (iVar9 != 0) goto code_r0x0001800d3901;
code_r0x0001800d391f:
            bVar13 = iVar9 == *(int64_t *)arg2;
code_r0x0001800d3923:
            if (bVar13) {
                return puVar2;
            }
        } else {
            if ((*(int64_t *)(puVar2 + 2) == *(int64_t *)(arg1 + 0x20)) &&
               (iVar7 = func_0x000180497f30(iVar9), iVar7 == 0)) {
code_r0x0001800d38d7:
                uVar4 = *(undefined4 *)(arg2 + 4);
                uVar5 = *(undefined4 *)(arg2 + 8);
                uVar6 = *(undefined4 *)(arg2 + 0xc);
                *puVar2 = *(undefined4 *)arg2;
                puVar2[1] = uVar4;
                puVar2[2] = uVar5;
                puVar2[3] = uVar6;
                *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
                return puVar2;
            }
code_r0x0001800d3901:
            if (*(int64_t *)arg2 == 0) goto code_r0x0001800d391f;
            if (*(uint64_t *)(puVar2 + 2) == uVar3) {
                iVar7 = func_0x000180497f30(iVar9);
                bVar13 = iVar7 == 0;
                goto code_r0x0001800d3923;
            }
        }
        iVar9 = uVar10 + uVar12;
        uVar12 = uVar12 + 1;
        if (uVar11 < uVar12) {
            return (undefined4 *)0x0;
        }
        uVar10 = iVar9 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800d3940
// Address: 0x1800d3940
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800d3940(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint32_t *)arg2;
        if (uVar1 != *(uint32_t *)(arg1 + 0x18)) {
            uVar5 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (((((uint64_t)(uVar1 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)(uVar1 >> 8 & 0xff))
                      * 0x100000001b3 ^ (uint64_t)(uVar1 >> 0x10 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar1 >> 0x18)) *
                    0x100000001b3;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar5;
                uVar2 = *(uint32_t *)(*(int64_t *)arg1 + uVar3 * 8);
                if (uVar2 == uVar1) {
                    return *(int64_t *)arg1 + uVar3 * 8;
                }
                if (uVar2 == *(uint32_t *)(arg1 + 0x18)) {
                    return 0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800d3980
// Address: 0x1800d3980
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800d3940(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint32_t *)arg2;
        if (uVar1 != *(uint32_t *)(arg1 + 0x18)) {
            uVar5 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (((((uint64_t)(uVar1 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)(uVar1 >> 8 & 0xff))
                      * 0x100000001b3 ^ (uint64_t)(uVar1 >> 0x10 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar1 >> 0x18)) *
                    0x100000001b3;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar5;
                uVar2 = *(uint32_t *)(*(int64_t *)arg1 + uVar3 * 8);
                if (uVar2 == uVar1) {
                    return *(int64_t *)arg1 + uVar3 * 8;
                }
                if (uVar2 == *(uint32_t *)(arg1 + 0x18)) {
                    return 0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800d39d0
// Address: 0x1800d39d0
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.1800d3940(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        uVar1 = *(uint32_t *)arg2;
        if (uVar1 != *(uint32_t *)(arg1 + 0x18)) {
            uVar5 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = (((((uint64_t)(uVar1 & 0xff) ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)(uVar1 >> 8 & 0xff))
                      * 0x100000001b3 ^ (uint64_t)(uVar1 >> 0x10 & 0xff)) * 0x100000001b3 ^ (uint64_t)(uVar1 >> 0x18)) *
                    0x100000001b3;
            uVar4 = 0;
            do {
                uVar3 = uVar3 & uVar5;
                uVar2 = *(uint32_t *)(*(int64_t *)arg1 + uVar3 * 8);
                if (uVar2 == uVar1) {
                    return *(int64_t *)arg1 + uVar3 * 8;
                }
                if (uVar2 == *(uint32_t *)(arg1 + 0x18)) {
                    return 0;
                }
                uVar3 = uVar3 + 1 + uVar4;
                uVar4 = uVar4 + 1;
            } while (uVar4 <= uVar5);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1800d3a00
// Address: 0x1800d3a00
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t * fcn.1800d3a00(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(int64_t *)(arg1 + 8) - 1;
    uVar3 = (((((uint64_t)*(uint8_t *)arg2 ^ 0xcbf29ce484222325) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 1)) *
              0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 2)) * 0x100000001b3 ^ (uint64_t)*(uint8_t *)(arg2 + 3)) *
            0x100000001b3;
    uVar4 = 0;
    while( true ) {
        uVar3 = uVar3 & uVar5;
        iVar2 = *(int32_t *)(*(int64_t *)arg1 + uVar3 * 8);
        piVar1 = (int32_t *)(*(int64_t *)arg1 + uVar3 * 8);
        if (iVar2 == *(int32_t *)(arg1 + 0x18)) {
            *piVar1 = *(int32_t *)arg2;
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return piVar1;
        }
        if (iVar2 == *(int32_t *)arg2) break;
        uVar3 = uVar3 + 1 + uVar4;
        uVar4 = uVar4 + 1;
        if (uVar5 < uVar4) {
            return (int32_t *)0x0;
        }
    }
    return piVar1;
}

// ============================================================
// Function: FUN_1800d3ab0
// Address: 0x1800d3ab0
// Size: 414 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800d3ab0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    bool bVar2;
    char cVar3;
    char cVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if ((*(int64_t *)(arg1 + 0x10) == 0) ||
       (cVar4 = func_0x0001800d43b0(arg1, arg2, arg1 + 0x18), cVar3 = *(char *)0x180777fb8, cVar4 != '\0')) {
        return 0;
    }
    uVar5 = 0x811c9dc5;
    if ((uint64_t)*(uint32_t *)(arg2 + 0x100) != 0) {
        uVar8 = 0;
        do {
            uVar5 = (uVar5 ^ *(uint32_t *)(arg2 + uVar8 * 4)) * 0x1000193;
            if ((*(char *)0x180777fb8 != '\0') && (*(char *)(arg2 + 0x104) != '\0')) {
                uVar5 = (uVar5 ^ *(uint32_t *)(arg2 + 0x80 + uVar8 * 4)) * 0x1000193;
            }
            uVar8 = uVar8 + 1;
        } while (uVar8 < *(uint32_t *)(arg2 + 0x100));
    }
    iVar1 = *(int64_t *)arg1;
    uVar10 = *(int64_t *)(arg1 + 8) - 1;
    uVar8 = (uint64_t)uVar5;
    uVar11 = 0;
    do {
        uVar8 = uVar8 & uVar10;
        iVar7 = uVar8 * 0x10c;
        uVar5 = *(uint32_t *)(iVar7 + 0x100 + iVar1);
        uVar9 = (uint64_t)uVar5;
        iVar7 = iVar7 + iVar1;
        if (cVar3 == '\0') {
            if (uVar5 == *(uint32_t *)(arg2 + 0x100)) {
                iVar6 = func_0x000180497f30(iVar7, arg2, uVar9 << 2);
joined_r0x0001800d3c03:
                if (iVar6 == 0) {
                    return iVar7;
                }
            }
        } else {
            if (((uVar5 == *(uint32_t *)(arg2 + 0x100)) &&
                (iVar6 = func_0x000180497f30(iVar7, arg2, uVar9 * 4), iVar6 == 0)) &&
               (*(char *)(iVar7 + 0x104) == *(char *)(arg2 + 0x104))) {
                bVar2 = true;
            } else {
                bVar2 = false;
            }
            if (*(char *)(iVar7 + 0x104) == '\0') {
                if (bVar2) {
                    return iVar7;
                }
            } else if (bVar2) {
                iVar6 = func_0x000180497f30(iVar7 + 0x80, arg2 + 0x80, uVar9 * 4);
                goto joined_r0x0001800d3c03;
            }
        }
        cVar4 = func_0x0001800d43b0();
        if (cVar4 != '\0') {
            return 0;
        }
        iVar7 = uVar8 + uVar11;
        uVar11 = uVar11 + 1;
        if (uVar10 < uVar11) {
            return 0;
        }
        uVar8 = iVar7 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_1800d3c50
// Address: 0x1800d3c50
// Size: 695 bytes
// ============================================================
undefined8 * fcn.1800d3c50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    bool bVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 *puVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    char cVar16;
    uint64_t uVar17;
    uint64_t uVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    uVar4 = *(uint32_t *)(arg2 + 0x100);
    uVar9 = 0x811c9dc5;
    if ((uint64_t)uVar4 != 0) {
        uVar14 = 0;
        do {
            uVar9 = (uVar9 ^ *(uint32_t *)(arg2 + uVar14 * 4)) * 0x1000193;
            if ((*(char *)0x180777fb8 != '\0') && (*(char *)(arg2 + 0x104) != '\0')) {
                uVar9 = (uVar9 ^ *(uint32_t *)(arg2 + 0x80 + uVar14 * 4)) * 0x1000193;
            }
            uVar14 = uVar14 + 1;
        } while (uVar14 < uVar4);
    }
    uVar14 = *(int64_t *)(arg1 + 8) - 1;
    uVar17 = (uint64_t)uVar9;
    iVar12 = *(int64_t *)arg1;
    uVar18 = 0;
    cVar16 = *(char *)0x180777fb8;
    do {
        uVar17 = uVar17 & uVar14;
        iVar11 = uVar17 * 0x10c;
        uVar9 = *(uint32_t *)(iVar11 + 0x100 + iVar12);
        uVar15 = (uint64_t)uVar9;
        puVar3 = (undefined8 *)(iVar11 + iVar12);
        if (cVar16 == '\0') {
            if (uVar9 == *(uint32_t *)(arg1 + 0x118)) {
                iVar10 = func_0x000180497f30(puVar3, arg1 + 0x18, uVar15 << 2);
joined_r0x0001800d3e17:
                cVar16 = *(char *)0x180777fb8;
                if (iVar10 == 0) {
code_r0x0001800d3d34:
                    iVar12 = 2;
                    puVar13 = puVar3;
                    do {
                        puVar1 = puVar13 + 0x10;
                        uVar5 = *(undefined4 *)(arg2 + 4);
                        uVar6 = *(undefined4 *)(arg2 + 8);
                        uVar7 = *(undefined4 *)(arg2 + 0xc);
                        puVar2 = (undefined8 *)(arg2 + 0x80);
                        *(undefined4 *)puVar13 = *(undefined4 *)arg2;
                        *(undefined4 *)((int64_t)puVar13 + 4) = uVar5;
                        *(undefined4 *)(puVar13 + 1) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0xc) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 0x14);
                        uVar6 = *(undefined4 *)(arg2 + 0x18);
                        uVar7 = *(undefined4 *)(arg2 + 0x1c);
                        *(undefined4 *)(puVar13 + 2) = *(undefined4 *)(arg2 + 0x10);
                        *(undefined4 *)((int64_t)puVar13 + 0x14) = uVar5;
                        *(undefined4 *)(puVar13 + 3) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x1c) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 0x24);
                        uVar6 = *(undefined4 *)(arg2 + 0x28);
                        uVar7 = *(undefined4 *)(arg2 + 0x2c);
                        *(undefined4 *)(puVar13 + 4) = *(undefined4 *)(arg2 + 0x20);
                        *(undefined4 *)((int64_t)puVar13 + 0x24) = uVar5;
                        *(undefined4 *)(puVar13 + 5) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x2c) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 0x34);
                        uVar6 = *(undefined4 *)(arg2 + 0x38);
                        uVar7 = *(undefined4 *)(arg2 + 0x3c);
                        *(undefined4 *)(puVar13 + 6) = *(undefined4 *)(arg2 + 0x30);
                        *(undefined4 *)((int64_t)puVar13 + 0x34) = uVar5;
                        *(undefined4 *)(puVar13 + 7) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x3c) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 0x44);
                        uVar6 = *(undefined4 *)(arg2 + 0x48);
                        uVar7 = *(undefined4 *)(arg2 + 0x4c);
                        *(undefined4 *)(puVar13 + 8) = *(undefined4 *)(arg2 + 0x40);
                        *(undefined4 *)((int64_t)puVar13 + 0x44) = uVar5;
                        *(undefined4 *)(puVar13 + 9) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x4c) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 0x54);
                        uVar6 = *(undefined4 *)(arg2 + 0x58);
                        uVar7 = *(undefined4 *)(arg2 + 0x5c);
                        *(undefined4 *)(puVar13 + 10) = *(undefined4 *)(arg2 + 0x50);
                        *(undefined4 *)((int64_t)puVar13 + 0x54) = uVar5;
                        *(undefined4 *)(puVar13 + 0xb) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x5c) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 100);
                        uVar6 = *(undefined4 *)(arg2 + 0x68);
                        uVar7 = *(undefined4 *)(arg2 + 0x6c);
                        *(undefined4 *)(puVar13 + 0xc) = *(undefined4 *)(arg2 + 0x60);
                        *(undefined4 *)((int64_t)puVar13 + 100) = uVar5;
                        *(undefined4 *)(puVar13 + 0xd) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x6c) = uVar7;
                        uVar5 = *(undefined4 *)(arg2 + 0x74);
                        uVar6 = *(undefined4 *)(arg2 + 0x78);
                        uVar7 = *(undefined4 *)(arg2 + 0x7c);
                        *(undefined4 *)(puVar13 + 0xe) = *(undefined4 *)(arg2 + 0x70);
                        *(undefined4 *)((int64_t)puVar13 + 0x74) = uVar5;
                        *(undefined4 *)(puVar13 + 0xf) = uVar6;
                        *(undefined4 *)((int64_t)puVar13 + 0x7c) = uVar7;
                        iVar12 = iVar12 + -1;
                        puVar13 = puVar1;
                        arg2 = (int64_t)puVar2;
                    } while (iVar12 != 0);
                    *puVar1 = *puVar2;
                    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
                    return puVar3;
                }
            }
        } else {
            if (((uVar9 == *(uint32_t *)(arg1 + 0x118)) &&
                (iVar10 = func_0x000180497f30(puVar3, arg1 + 0x18, uVar15 * 4), iVar10 == 0)) &&
               (*(char *)((int64_t)puVar3 + 0x104) == *(char *)(arg1 + 0x11c))) {
                bVar8 = true;
            } else {
                bVar8 = false;
            }
            cVar16 = *(char *)0x180777fb8;
            if (*(char *)((int64_t)puVar3 + 0x104) == '\0') {
                if (bVar8) goto code_r0x0001800d3d34;
            } else if (bVar8) {
                iVar10 = func_0x000180497f30(puVar3 + 0x10, arg1 + 0x98, uVar15 * 4);
                goto joined_r0x0001800d3e17;
            }
        }
        uVar9 = *(uint32_t *)(puVar3 + 0x20);
        uVar15 = (uint64_t)uVar9;
        if (cVar16 == '\0') {
            if (uVar9 == uVar4) {
                iVar10 = func_0x000180497f30(puVar3, arg2, uVar15 << 2);
joined_r0x0001800d3ec1:
                cVar16 = *(char *)0x180777fb8;
                if (iVar10 == 0) {
                    return puVar3;
                }
            }
        } else {
            if (((uVar9 == uVar4) && (iVar10 = func_0x000180497f30(puVar3, arg2, uVar15 * 4), iVar10 == 0)) &&
               (*(char *)((int64_t)puVar3 + 0x104) == *(char *)(arg2 + 0x104))) {
                bVar8 = true;
            } else {
                bVar8 = false;
            }
            cVar16 = *(char *)0x180777fb8;
            if (*(char *)((int64_t)puVar3 + 0x104) == '\0') {
                if (bVar8) {
                    return puVar3;
                }
            } else if (bVar8) {
                iVar10 = func_0x000180497f30(puVar3 + 0x10, arg2 + 0x80, uVar15 * 4);
                goto joined_r0x0001800d3ec1;
            }
        }
        iVar11 = uVar18 + 1;
        uVar18 = uVar18 + 1;
        if (uVar14 < uVar18) {
            return (undefined8 *)0x0;
        }
        uVar17 = uVar17 + iVar11;
    } while( true );
}

// ============================================================
// Function: FUN_1800d3f10
// Address: 0x1800d3f10
// Size: 203 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800d3f10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    iVar8 = 2;
    puVar6 = (undefined8 *)arg2;
    puVar9 = (undefined8 *)(arg1 + 0x18);
    do {
        puVar1 = puVar9 + 0x10;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 4);
        uVar4 = *(undefined4 *)(puVar6 + 1);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0xc);
        puVar2 = puVar6 + 0x10;
        *(undefined4 *)puVar9 = *(undefined4 *)puVar6;
        *(undefined4 *)((int64_t)puVar9 + 4) = uVar3;
        *(undefined4 *)(puVar9 + 1) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0xc) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x14);
        uVar4 = *(undefined4 *)(puVar6 + 3);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x1c);
        *(undefined4 *)(puVar9 + 2) = *(undefined4 *)(puVar6 + 2);
        *(undefined4 *)((int64_t)puVar9 + 0x14) = uVar3;
        *(undefined4 *)(puVar9 + 3) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x1c) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x24);
        uVar4 = *(undefined4 *)(puVar6 + 5);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x2c);
        *(undefined4 *)(puVar9 + 4) = *(undefined4 *)(puVar6 + 4);
        *(undefined4 *)((int64_t)puVar9 + 0x24) = uVar3;
        *(undefined4 *)(puVar9 + 5) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x2c) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x34);
        uVar4 = *(undefined4 *)(puVar6 + 7);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x3c);
        *(undefined4 *)(puVar9 + 6) = *(undefined4 *)(puVar6 + 6);
        *(undefined4 *)((int64_t)puVar9 + 0x34) = uVar3;
        *(undefined4 *)(puVar9 + 7) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x3c) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x44);
        uVar4 = *(undefined4 *)(puVar6 + 9);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x4c);
        *(undefined4 *)(puVar9 + 8) = *(undefined4 *)(puVar6 + 8);
        *(undefined4 *)((int64_t)puVar9 + 0x44) = uVar3;
        *(undefined4 *)(puVar9 + 9) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x4c) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x54);
        uVar4 = *(undefined4 *)(puVar6 + 0xb);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x5c);
        *(undefined4 *)(puVar9 + 10) = *(undefined4 *)(puVar6 + 10);
        *(undefined4 *)((int64_t)puVar9 + 0x54) = uVar3;
        *(undefined4 *)(puVar9 + 0xb) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x5c) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 100);
        uVar4 = *(undefined4 *)(puVar6 + 0xd);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x6c);
        *(undefined4 *)(puVar9 + 0xc) = *(undefined4 *)(puVar6 + 0xc);
        *(undefined4 *)((int64_t)puVar9 + 100) = uVar3;
        *(undefined4 *)(puVar9 + 0xd) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x6c) = uVar5;
        uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x74);
        uVar4 = *(undefined4 *)(puVar6 + 0xf);
        uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x7c);
        *(undefined4 *)(puVar9 + 0xe) = *(undefined4 *)(puVar6 + 0xe);
        *(undefined4 *)((int64_t)puVar9 + 0x74) = uVar3;
        *(undefined4 *)(puVar9 + 0xf) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x7c) = uVar5;
        iVar8 = iVar8 + -1;
        puVar6 = puVar2;
        puVar9 = puVar1;
    } while (iVar8 != 0);
    *puVar1 = *puVar2;
    if (arg3 != 0) {
        uVar7 = fcn.180459890(arg3 * 0x10c);
        *(undefined8 *)arg1 = uVar7;
        *(int64_t *)(arg1 + 8) = arg3;
        fcn.1800d4300(uVar7, arg3, arg2);
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800d3fe0
// Address: 0x1800d3fe0
// Size: 182 bytes
// ============================================================
int32_t * fcn.1800d3fe0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    int32_t *piVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    
    if (*(int64_t *)(arg1 + 0x10) != 0) {
        iVar1 = *(int32_t *)arg2;
        iVar2 = *(int32_t *)(arg1 + 0x18);
        if (((iVar1 != iVar2) || (*(int64_t *)(arg2 + 8) != *(int64_t *)(arg1 + 0x20))) ||
           (*(int64_t *)(arg2 + 0x10) != *(int64_t *)(arg1 + 0x28))) {
            uVar5 = *(int64_t *)(arg1 + 8) - 1;
            uVar3 = func_0x0001800cdd90();
            uVar6 = 0;
            while( true ) {
                uVar3 = uVar3 & uVar5;
                piVar4 = (int32_t *)(uVar3 * 0x20 + *(int64_t *)arg1);
                if (((*piVar4 == iVar1) && (*(int64_t *)(piVar4 + 2) == *(int64_t *)(arg2 + 8))) &&
                   (*(int64_t *)(piVar4 + 4) == *(int64_t *)(arg2 + 0x10))) {
                    return piVar4;
                }
                if (((*piVar4 == iVar2) && (*(int64_t *)(piVar4 + 2) == *(int64_t *)(arg1 + 0x20))) &&
                   (*(int64_t *)(piVar4 + 4) == *(int64_t *)(arg1 + 0x28))) break;
                iVar7 = uVar3 + uVar6;
                uVar6 = uVar6 + 1;
                if (uVar5 < uVar6) {
                    return (int32_t *)0x0;
                }
                uVar3 = iVar7 + 1;
            }
        }
    }
    return (int32_t *)0x0;
}

// ============================================================
// Function: FUN_1800d40a0
// Address: 0x1800d40a0
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t * fcn.1800d40a0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int32_t *piVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar6 = *(int64_t *)(arg1 + 8) - 1;
    uVar4 = fcn.1800cdd90();
    uVar7 = 0;
    while( true ) {
        uVar4 = uVar4 & uVar6;
        piVar5 = (int32_t *)(uVar4 * 0x20 + *(int64_t *)arg1);
        if (((*piVar5 == *(int32_t *)(arg1 + 0x18)) && (*(int64_t *)(piVar5 + 2) == *(int64_t *)(arg1 + 0x20))) &&
           (*(int64_t *)(piVar5 + 4) == *(int64_t *)(arg1 + 0x28))) {
            iVar1 = *(int32_t *)(arg2 + 4);
            iVar2 = *(int32_t *)(arg2 + 8);
            iVar3 = *(int32_t *)(arg2 + 0xc);
            *piVar5 = *(int32_t *)arg2;
            piVar5[1] = iVar1;
            piVar5[2] = iVar2;
            piVar5[3] = iVar3;
            *(undefined8 *)(piVar5 + 4) = *(undefined8 *)(arg2 + 0x10);
            *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
            return piVar5;
        }
        if (((*piVar5 == *(int32_t *)arg2) && (*(int64_t *)(piVar5 + 2) == *(int64_t *)(arg2 + 8))) &&
           (*(int64_t *)(piVar5 + 4) == *(int64_t *)(arg2 + 0x10))) break;
        iVar8 = uVar4 + uVar7;
        uVar7 = uVar7 + 1;
        if (uVar6 < uVar7) {
            return (int32_t *)0x0;
        }
        uVar4 = iVar8 + 1;
    }
    return piVar5;
}

// ============================================================
// Function: FUN_1800d4160
// Address: 0x1800d4160
// Size: 407 bytes
// ============================================================
undefined (*) [16] fcn.1800d4160(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined8 *puVar7;
    
    if (arg1 != arg2) {
        puVar7 = (undefined8 *)(arg1 + 0x70);
        do {
            *(undefined (*) [16])arg3 = ZEXT816(0);
            *(undefined8 *)*(undefined (*) [16])(arg3 + 0x10) = 0;
            *(undefined8 *)(*(undefined (*) [16])(arg3 + 0x10) + 8) = 0;
            uVar4 = *(undefined4 *)(arg1 + 4);
            uVar5 = *(undefined4 *)(arg1 + 8);
            uVar6 = *(undefined4 *)(arg1 + 0xc);
            *(undefined4 *)(undefined *)arg3 = *(undefined4 *)arg1;
            *(undefined4 *)((undefined *)arg3 + 4) = uVar4;
            *(undefined4 *)((undefined *)arg3 + 8) = uVar5;
            *(undefined4 *)((undefined *)arg3 + 0xc) = uVar6;
            uVar4 = *(undefined4 *)(arg1 + 0x14);
            uVar5 = *(undefined4 *)(arg1 + 0x18);
            uVar6 = *(undefined4 *)(arg1 + 0x1c);
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0x10) = *(undefined4 *)(arg1 + 0x10);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x10) + 4) = uVar4;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x10) + 8) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x10) + 0xc) = uVar6;
            *(undefined8 *)(arg1 + 0x18) = 0xf;
            *(undefined *)arg1 = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            (*(undefined (*) [16])(arg3 + 0x20))[0] = *(undefined *)(arg1 + 0x20);
            (*(undefined (*) [16])(arg3 + 0x20))[1] = *(undefined *)(arg1 + 0x21);
            (*(undefined (*) [16])(arg3 + 0x20))[2] = *(undefined *)(arg1 + 0x22);
            (*(undefined (*) [16])(arg3 + 0x20))[3] = *(undefined *)(arg1 + 0x23);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x20) + 4) = *(undefined4 *)(arg1 + 0x24);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x20) + 8) = *(undefined4 *)(arg1 + 0x28);
            *(undefined (*) [16])(arg3 + 0x30) = ZEXT816(0);
            *(undefined8 *)*(undefined (*) [16])(arg3 + 0x40) = 0;
            *(undefined8 *)(*(undefined (*) [16])(arg3 + 0x40) + 8) = 0;
            uVar4 = *(undefined4 *)(arg1 + 0x34);
            uVar5 = *(undefined4 *)(arg1 + 0x38);
            uVar6 = *(undefined4 *)(arg1 + 0x3c);
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0x30) = *(undefined4 *)(arg1 + 0x30);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x30) + 4) = uVar4;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x30) + 8) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x30) + 0xc) = uVar6;
            uVar4 = *(undefined4 *)(arg1 + 0x44);
            uVar5 = *(undefined4 *)(arg1 + 0x48);
            uVar6 = *(undefined4 *)(arg1 + 0x4c);
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0x40) = *(undefined4 *)(arg1 + 0x40);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x40) + 4) = uVar4;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x40) + 8) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x40) + 0xc) = uVar6;
            *(undefined8 *)(arg1 + 0x48) = 0xf;
            *(undefined *)(arg1 + 0x30) = 0;
            *(undefined8 *)(arg1 + 0x40) = 0;
            *(undefined (*) [16])(arg3 + 0x50) = ZEXT816(0);
            *(undefined8 *)*(undefined (*) [16])(arg3 + 0x60) = 0;
            *(undefined8 *)(*(undefined (*) [16])(arg3 + 0x60) + 8) = 0;
            uVar4 = *(undefined4 *)(arg1 + 0x54);
            uVar5 = *(undefined4 *)(arg1 + 0x58);
            uVar6 = *(undefined4 *)(arg1 + 0x5c);
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0x50) = *(undefined4 *)(arg1 + 0x50);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x50) + 4) = uVar4;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x50) + 8) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x50) + 0xc) = uVar6;
            uVar4 = *(undefined4 *)(arg1 + 100);
            uVar5 = *(undefined4 *)(arg1 + 0x68);
            uVar6 = *(undefined4 *)(arg1 + 0x6c);
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0x60) = *(undefined4 *)(arg1 + 0x60);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x60) + 4) = uVar4;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x60) + 8) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x60) + 0xc) = uVar6;
            *(undefined8 *)(arg1 + 0x68) = 0xf;
            *(undefined *)(arg1 + 0x50) = 0;
            *(undefined8 *)(arg1 + 0x60) = 0;
            uVar1 = puVar7[2];
            uVar2 = puVar7[1];
            uVar3 = *puVar7;
            puVar7[2] = 0;
            puVar7[1] = 0;
            *puVar7 = 0;
            *(undefined8 *)*(undefined (*) [16])(arg3 + 0x70) = uVar3;
            *(undefined8 *)(*(undefined (*) [16])(arg3 + 0x70) + 8) = uVar2;
            *(undefined8 *)*(undefined (*) [16])(arg3 + 0x80) = uVar1;
            *(undefined (*) [16])(*(undefined (*) [16])(arg3 + 0x80) + 8) = ZEXT816(0);
            *(undefined8 *)(*(undefined (*) [16])(arg3 + 0x90) + 8) = 0;
            *(undefined8 *)*(undefined (*) [16])(arg3 + 0xa0) = 0;
            uVar4 = *(undefined4 *)(arg1 + 0x8c);
            uVar5 = *(undefined4 *)(arg1 + 0x90);
            uVar6 = *(undefined4 *)(arg1 + 0x94);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x80) + 8) = *(undefined4 *)(arg1 + 0x88);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x80) + 0xc) = uVar4;
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0x90) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x90) + 4) = uVar6;
            uVar4 = *(undefined4 *)(arg1 + 0x9c);
            uVar5 = *(undefined4 *)(arg1 + 0xa0);
            uVar6 = *(undefined4 *)(arg1 + 0xa4);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x90) + 8) = *(undefined4 *)(arg1 + 0x98);
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0x90) + 0xc) = uVar4;
            *(undefined4 *)*(undefined (*) [16])(arg3 + 0xa0) = uVar5;
            *(undefined4 *)(*(undefined (*) [16])(arg3 + 0xa0) + 4) = uVar6;
            *(undefined *)(arg1 + 0x88) = 0;
            arg3 = (int64_t)(*(undefined (*) [16])(arg3 + 0xa0) + 8);
            *(undefined8 *)(arg1 + 0x98) = 0;
            *(undefined8 *)(arg1 + 0xa0) = 0xf;
            arg1 = arg1 + 0xa8;
            puVar7 = puVar7 + 0x15;
        } while (arg1 != arg2);
    }
    func_0x0001800c1e20(arg3, arg3);
    return (undefined (*) [16])arg3;
}

// ============================================================
// Function: FUN_1800d4300
// Address: 0x1800d4300
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4300(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 *puVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int64_t var_8h;
    
    uVar10 = 0;
    if (arg2 != 0) {
        do {
            iVar9 = uVar10 * 0x10c;
            iVar7 = 2;
            puVar6 = (undefined8 *)arg3;
            puVar8 = (undefined8 *)(iVar9 + arg1);
            do {
                puVar1 = puVar8 + 0x10;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 4);
                uVar4 = *(undefined4 *)(puVar6 + 1);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0xc);
                puVar2 = puVar6 + 0x10;
                *(undefined4 *)puVar8 = *(undefined4 *)puVar6;
                *(undefined4 *)((int64_t)puVar8 + 4) = uVar3;
                *(undefined4 *)(puVar8 + 1) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0xc) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x14);
                uVar4 = *(undefined4 *)(puVar6 + 3);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x1c);
                *(undefined4 *)(puVar8 + 2) = *(undefined4 *)(puVar6 + 2);
                *(undefined4 *)((int64_t)puVar8 + 0x14) = uVar3;
                *(undefined4 *)(puVar8 + 3) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x1c) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x24);
                uVar4 = *(undefined4 *)(puVar6 + 5);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x2c);
                *(undefined4 *)(puVar8 + 4) = *(undefined4 *)(puVar6 + 4);
                *(undefined4 *)((int64_t)puVar8 + 0x24) = uVar3;
                *(undefined4 *)(puVar8 + 5) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x2c) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x34);
                uVar4 = *(undefined4 *)(puVar6 + 7);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x3c);
                *(undefined4 *)(puVar8 + 6) = *(undefined4 *)(puVar6 + 6);
                *(undefined4 *)((int64_t)puVar8 + 0x34) = uVar3;
                *(undefined4 *)(puVar8 + 7) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x3c) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x44);
                uVar4 = *(undefined4 *)(puVar6 + 9);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x4c);
                *(undefined4 *)(puVar8 + 8) = *(undefined4 *)(puVar6 + 8);
                *(undefined4 *)((int64_t)puVar8 + 0x44) = uVar3;
                *(undefined4 *)(puVar8 + 9) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x4c) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x54);
                uVar4 = *(undefined4 *)(puVar6 + 0xb);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x5c);
                *(undefined4 *)(puVar8 + 10) = *(undefined4 *)(puVar6 + 10);
                *(undefined4 *)((int64_t)puVar8 + 0x54) = uVar3;
                *(undefined4 *)(puVar8 + 0xb) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x5c) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 100);
                uVar4 = *(undefined4 *)(puVar6 + 0xd);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x6c);
                *(undefined4 *)(puVar8 + 0xc) = *(undefined4 *)(puVar6 + 0xc);
                *(undefined4 *)((int64_t)puVar8 + 100) = uVar3;
                *(undefined4 *)(puVar8 + 0xd) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x6c) = uVar5;
                uVar3 = *(undefined4 *)((int64_t)puVar6 + 0x74);
                uVar4 = *(undefined4 *)(puVar6 + 0xf);
                uVar5 = *(undefined4 *)((int64_t)puVar6 + 0x7c);
                *(undefined4 *)(puVar8 + 0xe) = *(undefined4 *)(puVar6 + 0xe);
                *(undefined4 *)((int64_t)puVar8 + 0x74) = uVar3;
                *(undefined4 *)(puVar8 + 0xf) = uVar4;
                *(undefined4 *)((int64_t)puVar8 + 0x7c) = uVar5;
                iVar7 = iVar7 + -1;
                puVar6 = puVar2;
                puVar8 = puVar1;
            } while (iVar7 != 0);
            uVar10 = uVar10 + 1;
            *puVar1 = *puVar2;
            *(undefined4 *)(iVar9 + 0x108 + arg1) = 0;
        } while (uVar10 < (uint64_t)arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d43b0
// Address: 0x1800d43b0
// Size: 235 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

char fcn.1800d43b0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    uint32_t uVar1;
    char cVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar1 = *(uint32_t *)(arg2 + 0x100);
    uVar4 = (uint64_t)uVar1;
    if (*(char *)0x180777fb8 == '\0') {
        if ((uVar1 == *(uint32_t *)(arg3 + 0x100)) && (iVar3 = fcn.180497f30(arg2, arg3, uVar4 << 2), iVar3 == 0)) {
            return '\x01';
        }
        return '\0';
    }
    if (((uVar1 == *(uint32_t *)(arg3 + 0x100)) && (iVar3 = fcn.180497f30(arg2, arg3, uVar4 * 4), iVar3 == 0)) &&
       (*(char *)(arg2 + 0x104) == *(char *)(arg3 + 0x104))) {
        cVar2 = '\x01';
    } else {
        cVar2 = '\0';
    }
    if (*(char *)(arg2 + 0x104) != '\0') {
        if ((cVar2 != '\0') && (iVar3 = fcn.180497f30(arg2 + 0x80, arg3 + 0x80, uVar4 * 4), iVar3 == 0)) {
            return '\x01';
        }
        cVar2 = '\0';
    }
    return cVar2;
}

// ============================================================
// Function: FUN_1800d44a0
// Address: 0x1800d44a0
// Size: 160 bytes
// ============================================================
void fcn.1800d44a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    if (*(int64_t *)arg1 != 0) {
        func_0x0001800c1e20(*(int64_t *)arg1, *(undefined8 *)(arg1 + 8));
        uVar4 = *(uint64_t *)arg1;
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 3) * 8)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800d4518;
        func_0x000180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0xa8 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0xa8 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800d4540
// Address: 0x1800d4540
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x3fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 4;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = fcn.180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = fcn.180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800d4558
// Address: 0x1800d4558
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x3fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 4;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = fcn.180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = fcn.180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800d45c3
// Address: 0x1800d45c3
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x3fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 4;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = fcn.180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = fcn.180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800d45c9
// Address: 0x1800d45c9
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4540(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t var_8h;
    
    if (0x3fffffffffffffff < (uint64_t)arg2) {
        func_0x000180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar1 = arg2 * 4;
    if (uVar1 == 0) {
        uVar4 = 0;
    } else if (uVar1 < 0x1000) {
        uVar4 = fcn.180459890(uVar1);
    } else {
        if (uVar1 + 0x27 <= uVar1) {
            fcn.180004720();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        iVar3 = fcn.180459890();
        iVar5 = iVar3;
        if (iVar3 == 0) {
            iVar5 = 5;
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)();
        }
        uVar4 = iVar3 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar4 - 8) = iVar5;
    }
    *(uint64_t *)arg1 = uVar4;
    *(uint64_t *)(arg1 + 8) = uVar4;
    *(uint64_t *)(arg1 + 0x10) = uVar4 + uVar1;
    return;
}

// ============================================================
// Function: FUN_1800d4630
// Address: 0x1800d4630
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.1800d4630(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        puVar4 = (undefined8 *)(arg1 + 8);
        puVar5 = (undefined8 *)(arg1 + 0x20);
        do {
            *(undefined4 *)arg3 = *(undefined4 *)arg1;
            uVar1 = puVar4[2];
            arg1 = arg1 + 0x38;
            uVar2 = puVar4[1];
            uVar3 = *puVar4;
            puVar4[2] = 0;
            puVar4[1] = 0;
            *puVar4 = 0;
            *(undefined8 *)(arg3 + 8) = uVar3;
            *(undefined8 *)(arg3 + 0x10) = uVar2;
            *(undefined8 *)(arg3 + 0x18) = uVar1;
            uVar1 = puVar5[2];
            uVar2 = puVar5[1];
            uVar3 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x20) = uVar3;
            *(undefined8 *)(arg3 + 0x28) = uVar2;
            *(undefined8 *)(arg3 + 0x30) = uVar1;
            arg3 = arg3 + 0x38;
            puVar4 = puVar4 + 7;
            puVar5 = puVar5 + 7;
        } while (arg1 != arg2);
    }
    return (undefined4 *)arg3;
}

// ============================================================
// Function: FUN_1800d463d
// Address: 0x1800d463d
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.1800d4630(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        puVar4 = (undefined8 *)(arg1 + 8);
        puVar5 = (undefined8 *)(arg1 + 0x20);
        do {
            *(undefined4 *)arg3 = *(undefined4 *)arg1;
            uVar1 = puVar4[2];
            arg1 = arg1 + 0x38;
            uVar2 = puVar4[1];
            uVar3 = *puVar4;
            puVar4[2] = 0;
            puVar4[1] = 0;
            *puVar4 = 0;
            *(undefined8 *)(arg3 + 8) = uVar3;
            *(undefined8 *)(arg3 + 0x10) = uVar2;
            *(undefined8 *)(arg3 + 0x18) = uVar1;
            uVar1 = puVar5[2];
            uVar2 = puVar5[1];
            uVar3 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x20) = uVar3;
            *(undefined8 *)(arg3 + 0x28) = uVar2;
            *(undefined8 *)(arg3 + 0x30) = uVar1;
            arg3 = arg3 + 0x38;
            puVar4 = puVar4 + 7;
            puVar5 = puVar5 + 7;
        } while (arg1 != arg2);
    }
    return (undefined4 *)arg3;
}

// ============================================================
// Function: FUN_1800d46b8
// Address: 0x1800d46b8
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.1800d4630(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        puVar4 = (undefined8 *)(arg1 + 8);
        puVar5 = (undefined8 *)(arg1 + 0x20);
        do {
            *(undefined4 *)arg3 = *(undefined4 *)arg1;
            uVar1 = puVar4[2];
            arg1 = arg1 + 0x38;
            uVar2 = puVar4[1];
            uVar3 = *puVar4;
            puVar4[2] = 0;
            puVar4[1] = 0;
            *puVar4 = 0;
            *(undefined8 *)(arg3 + 8) = uVar3;
            *(undefined8 *)(arg3 + 0x10) = uVar2;
            *(undefined8 *)(arg3 + 0x18) = uVar1;
            uVar1 = puVar5[2];
            uVar2 = puVar5[1];
            uVar3 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x20) = uVar3;
            *(undefined8 *)(arg3 + 0x28) = uVar2;
            *(undefined8 *)(arg3 + 0x30) = uVar1;
            arg3 = arg3 + 0x38;
            puVar4 = puVar4 + 7;
            puVar5 = puVar5 + 7;
        } while (arg1 != arg2);
    }
    return (undefined4 *)arg3;
}

// ============================================================
// Function: FUN_1800d4720
// Address: 0x1800d4720
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_21h
// WARNING: [rz-ghidra] Detected overlap for variable var_22h
// WARNING: [rz-ghidra] Detected overlap for variable var_23h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable arg_28h

void fcn.1800d4720(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
                  int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, undefined8 placeholder_8, int64_t arg_50h,
                  int64_t arg_70h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    fcn.18000b4d0(arg2, arg3);
    *(undefined *)(arg2 + 0x20) = *(undefined *)(arg3 + 0x20);
    *(undefined *)(arg2 + 0x21) = *(undefined *)(arg3 + 0x21);
    *(undefined *)(arg2 + 0x22) = *(undefined *)(arg3 + 0x22);
    *(undefined *)(arg2 + 0x23) = *(undefined *)(arg3 + 0x23);
    *(undefined4 *)(arg2 + 0x24) = *(undefined4 *)(arg3 + 0x24);
    *(undefined4 *)(arg2 + 0x28) = *(undefined4 *)(arg3 + 0x28);
    fcn.18000b4d0(arg2 + 0x30, arg3 + 0x30);
    fcn.18000b4d0(arg2 + 0x50, arg3 + 0x50);
    *(undefined8 *)(arg2 + 0x70) = 0;
    *(undefined8 *)(arg2 + 0x78) = 0;
    *(undefined8 *)(arg2 + 0x80) = 0;
    iVar1 = *(int64_t *)(arg3 + 0x78) - *(int64_t *)(arg3 + 0x70) >> 2;
    if (iVar1 != 0) {
        fcn.1800d4540(arg2 + 0x70, iVar1);
        iVar1 = *(int64_t *)(arg2 + 0x70);
        iVar2 = *(int64_t *)(arg3 + 0x78) - *(int64_t *)(arg3 + 0x70);
        fcn.180498030(iVar1, *(int64_t *)(arg3 + 0x70), iVar2);
        *(int64_t *)(arg2 + 0x78) = iVar1 + (iVar2 >> 2) * 4;
    }
    fcn.18000b4d0(arg2 + 0x88, arg3 + 0x88);
    return;
}

// ============================================================
// Function: FUN_1800d4810
// Address: 0x1800d4810
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d4810(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t iVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (iVar8 = *(int64_t *)(arg1 + 0x18); iVar8 != iVar1; iVar8 = iVar8 + 0x28) {
        func_0x000180004e40(iVar8 + 8);
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar9 = auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = func_0x00018046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d4824
// Address: 0x1800d4824
// Size: 85 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d4810(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t iVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (iVar8 = *(int64_t *)(arg1 + 0x18); iVar8 != iVar1; iVar8 = iVar8 + 0x28) {
        func_0x000180004e40(iVar8 + 8);
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar9 = auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = func_0x00018046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d4879
// Address: 0x1800d4879
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d4810(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    int64_t iVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (iVar8 = *(int64_t *)(arg1 + 0x18); iVar8 != iVar1; iVar8 = iVar8 + 0x28) {
        func_0x000180004e40(iVar8 + 8);
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x28)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar9 = auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = func_0x00018046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d48c0
// Address: 0x1800d48c0
// Size: 107 bytes
// ============================================================
void fcn.1800d48c0(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined *puVar7;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    func_0x0001800c1e20(*(undefined8 *)(arg1 + 0x18), *(undefined8 *)(arg1 + 0x20));
    iVar4 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0xa8)) {
        iVar6 = *(int64_t *)(iVar4 + -8);
        if ((iVar4 - iVar6) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar4 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    unaff_RBX = *(undefined8 *)(puVar7 + 0x20);
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar6 = iVar4;
code_r0x0001800f4640:
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d4930
// Address: 0x1800d4930
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined2 * fcn.1800d4930(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined2 *puVar2;
    undefined2 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined2 *puVar6;
    uint64_t uVar7;
    undefined2 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t iVar11;
    undefined2 *puVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined2 **)(arg1 + 8);
    if (puVar6 != *(undefined2 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined2 *)arg2;
        puVar6 = *(undefined2 **)(arg1 + 8);
        *(undefined2 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar11 = (int64_t)puVar6 - *(int64_t *)arg1 >> 1;
    if (iVar11 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined2 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined2 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 1;
    if (uVar7 <= 0x7fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x8000000000000000) {
            uVar7 = uVar13 * 2;
            if (uVar7 == 0) {
                puVar12 = (undefined2 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar12 = (undefined2 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800d4a92;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar12 = (undefined2 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -4) = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar12 + iVar11;
            *puVar2 = *(undefined2 *)arg2;
            puVar3 = *(undefined2 **)arg1;
            if (puVar6 == *(undefined2 **)(arg1 + 8)) {
                iVar11 = (int64_t)*(undefined2 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar12;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d4a48;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a5b;
            fcn.180498030(puVar8, puVar6, iVar11);
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a6c;
            fcn.1800d4aa0(arg1, puVar12, uVar1, uVar13);
            return puVar2;
        }
    }
code_r0x0001800d4a92:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined2 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800d4975
// Address: 0x1800d4975
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined2 * fcn.1800d4930(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined2 *puVar2;
    undefined2 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined2 *puVar6;
    uint64_t uVar7;
    undefined2 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t iVar11;
    undefined2 *puVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined2 **)(arg1 + 8);
    if (puVar6 != *(undefined2 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined2 *)arg2;
        puVar6 = *(undefined2 **)(arg1 + 8);
        *(undefined2 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar11 = (int64_t)puVar6 - *(int64_t *)arg1 >> 1;
    if (iVar11 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined2 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined2 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 1;
    if (uVar7 <= 0x7fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x8000000000000000) {
            uVar7 = uVar13 * 2;
            if (uVar7 == 0) {
                puVar12 = (undefined2 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar12 = (undefined2 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800d4a92;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar12 = (undefined2 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -4) = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar12 + iVar11;
            *puVar2 = *(undefined2 *)arg2;
            puVar3 = *(undefined2 **)arg1;
            if (puVar6 == *(undefined2 **)(arg1 + 8)) {
                iVar11 = (int64_t)*(undefined2 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar12;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d4a48;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a5b;
            fcn.180498030(puVar8, puVar6, iVar11);
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a6c;
            fcn.1800d4aa0(arg1, puVar12, uVar1, uVar13);
            return puVar2;
        }
    }
code_r0x0001800d4a92:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined2 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800d4a8c
// Address: 0x1800d4a8c
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined2 * fcn.1800d4930(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined2 *puVar2;
    undefined2 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined2 *puVar6;
    uint64_t uVar7;
    undefined2 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t iVar11;
    undefined2 *puVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined2 **)(arg1 + 8);
    if (puVar6 != *(undefined2 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined2 *)arg2;
        puVar6 = *(undefined2 **)(arg1 + 8);
        *(undefined2 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar11 = (int64_t)puVar6 - *(int64_t *)arg1 >> 1;
    if (iVar11 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined2 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined2 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 1;
    if (uVar7 <= 0x7fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x8000000000000000) {
            uVar7 = uVar13 * 2;
            if (uVar7 == 0) {
                puVar12 = (undefined2 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar12 = (undefined2 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800d4a92;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar12 = (undefined2 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -4) = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar12 + iVar11;
            *puVar2 = *(undefined2 *)arg2;
            puVar3 = *(undefined2 **)arg1;
            if (puVar6 == *(undefined2 **)(arg1 + 8)) {
                iVar11 = (int64_t)*(undefined2 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar12;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d4a48;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a5b;
            fcn.180498030(puVar8, puVar6, iVar11);
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a6c;
            fcn.1800d4aa0(arg1, puVar12, uVar1, uVar13);
            return puVar2;
        }
    }
code_r0x0001800d4a92:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined2 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800d4a92
// Address: 0x1800d4a92
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined2 * fcn.1800d4930(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined2 *puVar2;
    undefined2 *puVar3;
    code *pcVar4;
    int64_t iVar5;
    undefined2 *puVar6;
    uint64_t uVar7;
    undefined2 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t iVar11;
    undefined2 *puVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    puVar6 = *(undefined2 **)(arg1 + 8);
    if (puVar6 != *(undefined2 **)(arg1 + 0x10)) {
        *puVar6 = *(undefined2 *)arg2;
        puVar6 = *(undefined2 **)(arg1 + 8);
        *(undefined2 **)(arg1 + 8) = puVar6 + 1;
        return puVar6;
    }
    iVar11 = (int64_t)puVar6 - *(int64_t *)arg1 >> 1;
    if (iVar11 == 0x7fffffffffffffff) {
        fcn.180010010();
        pcVar4 = (code *)swi(3);
        puVar6 = (undefined2 *)(*pcVar4)();
        return puVar6;
    }
    uVar7 = (int64_t)*(undefined2 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 1;
    if (uVar7 <= 0x7fffffffffffffff - (uVar7 >> 1)) {
        uVar1 = iVar11 + 1;
        uVar7 = uVar7 + (uVar7 >> 1);
        uVar13 = uVar1;
        if (uVar1 <= uVar7) {
            uVar13 = uVar7;
        }
        if (uVar13 < 0x8000000000000000) {
            uVar7 = uVar13 * 2;
            if (uVar7 == 0) {
                puVar12 = (undefined2 *)0x0;
                puVar10 = auStack_38;
            } else if (uVar7 < 0x1000) {
                puVar12 = (undefined2 *)fcn.180459890();
            } else {
                if (uVar7 + 0x27 <= uVar7) goto code_r0x0001800d4a92;
                iVar5 = fcn.180459890(uVar7 + 0x27);
                if (iVar5 == 0) {
                    pcVar4 = (code *)swi(0x29);
                    iVar5 = (*pcVar4)(5);
                    puVar9 = auStack_30;
                }
                puVar12 = (undefined2 *)(iVar5 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -4) = iVar5;
                puVar10 = puVar9;
            }
            puVar2 = puVar12 + iVar11;
            *puVar2 = *(undefined2 *)arg2;
            puVar3 = *(undefined2 **)arg1;
            if (puVar6 == *(undefined2 **)(arg1 + 8)) {
                iVar11 = (int64_t)*(undefined2 **)(arg1 + 8) - (int64_t)puVar3;
                puVar8 = puVar12;
                puVar6 = puVar3;
            } else {
                *(undefined8 *)(puVar10 + -8) = 0x1800d4a48;
                fcn.180498030(puVar12, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
                puVar8 = puVar2 + 1;
                iVar11 = *(int64_t *)(arg1 + 8) - (int64_t)puVar6;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a5b;
            fcn.180498030(puVar8, puVar6, iVar11);
            *(undefined8 *)(puVar10 + -8) = 0x1800d4a6c;
            fcn.1800d4aa0(arg1, puVar12, uVar1, uVar13);
            return puVar2;
        }
    }
code_r0x0001800d4a92:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    puVar6 = (undefined2 *)(*pcVar4)();
    return puVar6;
}

// ============================================================
// Function: FUN_1800d4aa0
// Address: 0x1800d4aa0
// Size: 118 bytes
// ============================================================
void fcn.1800d4aa0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 1) * 2)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800d4afa;
        func_0x000180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 2;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 2;
    return;
}

// ============================================================
// Function: FUN_1800d4b20
// Address: 0x1800d4b20
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_1h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1800d4b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = (uint64_t *)func_0x0001800102c0();
    iVar3 = func_0x000180467554(*puVar4 | 2, 0, 0, arg2, 0, arg3);
    if (iVar3 < 0) {
        iVar3 = -1;
    }
    if (0 < iVar3) {
        uVar2 = *(uint64_t *)(arg1 + 0x10);
        uVar6 = (uint64_t)iVar3;
        uVar1 = uVar6 + uVar2;
        if (uVar2 < uVar1) {
            if (*(uint64_t *)(arg1 + 0x18) - uVar2 < uVar6) {
                func_0x00018000f2f0(arg1, uVar6, (undefined)var_18h, uVar6, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                func_0x0001804986e0(uVar2 + iVar5, 0, uVar6);
                *(undefined *)(uVar2 + iVar5 + uVar6) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined *)(uVar1 + iVar5) = 0;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        func_0x000180467554(*puVar4 | 2, uVar2 + arg1, (int64_t)(iVar3 + 1), arg2, 0, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4b74
// Address: 0x1800d4b74
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_1h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1800d4b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = (uint64_t *)func_0x0001800102c0();
    iVar3 = func_0x000180467554(*puVar4 | 2, 0, 0, arg2, 0, arg3);
    if (iVar3 < 0) {
        iVar3 = -1;
    }
    if (0 < iVar3) {
        uVar2 = *(uint64_t *)(arg1 + 0x10);
        uVar6 = (uint64_t)iVar3;
        uVar1 = uVar6 + uVar2;
        if (uVar2 < uVar1) {
            if (*(uint64_t *)(arg1 + 0x18) - uVar2 < uVar6) {
                func_0x00018000f2f0(arg1, uVar6, (undefined)var_18h, uVar6, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                func_0x0001804986e0(uVar2 + iVar5, 0, uVar6);
                *(undefined *)(uVar2 + iVar5 + uVar6) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined *)(uVar1 + iVar5) = 0;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        func_0x000180467554(*puVar4 | 2, uVar2 + arg1, (int64_t)(iVar3 + 1), arg2, 0, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4bb4
// Address: 0x1800d4bb4
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_1h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1800d4b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = (uint64_t *)func_0x0001800102c0();
    iVar3 = func_0x000180467554(*puVar4 | 2, 0, 0, arg2, 0, arg3);
    if (iVar3 < 0) {
        iVar3 = -1;
    }
    if (0 < iVar3) {
        uVar2 = *(uint64_t *)(arg1 + 0x10);
        uVar6 = (uint64_t)iVar3;
        uVar1 = uVar6 + uVar2;
        if (uVar2 < uVar1) {
            if (*(uint64_t *)(arg1 + 0x18) - uVar2 < uVar6) {
                func_0x00018000f2f0(arg1, uVar6, (undefined)var_18h, uVar6, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                func_0x0001804986e0(uVar2 + iVar5, 0, uVar6);
                *(undefined *)(uVar2 + iVar5 + uVar6) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined *)(uVar1 + iVar5) = 0;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        func_0x000180467554(*puVar4 | 2, uVar2 + arg1, (int64_t)(iVar3 + 1), arg2, 0, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4be5
// Address: 0x1800d4be5
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_1h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1800d4b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = (uint64_t *)func_0x0001800102c0();
    iVar3 = func_0x000180467554(*puVar4 | 2, 0, 0, arg2, 0, arg3);
    if (iVar3 < 0) {
        iVar3 = -1;
    }
    if (0 < iVar3) {
        uVar2 = *(uint64_t *)(arg1 + 0x10);
        uVar6 = (uint64_t)iVar3;
        uVar1 = uVar6 + uVar2;
        if (uVar2 < uVar1) {
            if (*(uint64_t *)(arg1 + 0x18) - uVar2 < uVar6) {
                func_0x00018000f2f0(arg1, uVar6, (undefined)var_18h, uVar6, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                func_0x0001804986e0(uVar2 + iVar5, 0, uVar6);
                *(undefined *)(uVar2 + iVar5 + uVar6) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined *)(uVar1 + iVar5) = 0;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        func_0x000180467554(*puVar4 | 2, uVar2 + arg1, (int64_t)(iVar3 + 1), arg2, 0, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4c0a
// Address: 0x1800d4c0a
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_1h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1800d4b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = (uint64_t *)func_0x0001800102c0();
    iVar3 = func_0x000180467554(*puVar4 | 2, 0, 0, arg2, 0, arg3);
    if (iVar3 < 0) {
        iVar3 = -1;
    }
    if (0 < iVar3) {
        uVar2 = *(uint64_t *)(arg1 + 0x10);
        uVar6 = (uint64_t)iVar3;
        uVar1 = uVar6 + uVar2;
        if (uVar2 < uVar1) {
            if (*(uint64_t *)(arg1 + 0x18) - uVar2 < uVar6) {
                func_0x00018000f2f0(arg1, uVar6, (undefined)var_18h, uVar6, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                func_0x0001804986e0(uVar2 + iVar5, 0, uVar6);
                *(undefined *)(uVar2 + iVar5 + uVar6) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined *)(uVar1 + iVar5) = 0;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        func_0x000180467554(*puVar4 | 2, uVar2 + arg1, (int64_t)(iVar3 + 1), arg2, 0, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4c3a
// Address: 0x1800d4c3a
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_1h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1800d4b20(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_68h, int64_t arg_70h)
{
    uint64_t uVar1;
    uint64_t uVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t var_1h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    
    puVar4 = (uint64_t *)func_0x0001800102c0();
    iVar3 = func_0x000180467554(*puVar4 | 2, 0, 0, arg2, 0, arg3);
    if (iVar3 < 0) {
        iVar3 = -1;
    }
    if (0 < iVar3) {
        uVar2 = *(uint64_t *)(arg1 + 0x10);
        uVar6 = (uint64_t)iVar3;
        uVar1 = uVar6 + uVar2;
        if (uVar2 < uVar1) {
            if (*(uint64_t *)(arg1 + 0x18) - uVar2 < uVar6) {
                func_0x00018000f2f0(arg1, uVar6, (undefined)var_18h, uVar6, 0);
            } else {
                *(uint64_t *)(arg1 + 0x10) = uVar1;
                iVar5 = arg1;
                if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                    iVar5 = *(int64_t *)arg1;
                }
                func_0x0001804986e0(uVar2 + iVar5, 0, uVar6);
                *(undefined *)(uVar2 + iVar5 + uVar6) = 0;
            }
        } else {
            *(uint64_t *)(arg1 + 0x10) = uVar1;
            iVar5 = arg1;
            if (0xf < *(uint64_t *)(arg1 + 0x18)) {
                iVar5 = *(int64_t *)arg1;
            }
            *(undefined *)(uVar1 + iVar5) = 0;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        func_0x000180467554(*puVar4 | 2, uVar2 + arg1, (int64_t)(iVar3 + 1), arg2, 0, arg3);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4c50
// Address: 0x1800d4c50
// Size: 82 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

int64_t fcn.1800d4c50(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    var_18h = arg3;
    var_20h = arg4;
    fcn.1800d4b20(arg1, arg2, (int64_t)&var_18h, in_stack_00000028, in_stack_00000030);
    return arg1;
}

// ============================================================
// Function: FUN_1800d4cb0
// Address: 0x1800d4cb0
// Size: 62 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

int64_t fcn.1800d4cb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    int64_t in_stack_00000028;
    int64_t in_stack_00000030;
    int64_t var_18h;
    
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    fcn.1800d4b20(arg1, arg2, arg3, in_stack_00000028, in_stack_00000030);
    return arg1;
}

// ============================================================
// Function: FUN_1800d4cf0
// Address: 0x1800d4cf0
// Size: 12 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4cf0(int64_t arg1, int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)arg1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)*puVar1;
        fcn.1800f4640();
    }
    return;
}

// ============================================================
// Function: FUN_1800d4cfc
// Address: 0x1800d4cfc
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4cf0(int64_t arg1, int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)arg1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)*puVar1;
        fcn.1800f4640();
    }
    return;
}

// ============================================================
// Function: FUN_1800d4d16
// Address: 0x1800d4d16
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4cf0(int64_t arg1, int64_t arg_28h)
{
    undefined8 *puVar1;
    int64_t var_8h;
    
    puVar1 = *(undefined8 **)arg1;
    while (puVar1 != (undefined8 *)0x0) {
        puVar1 = (undefined8 *)*puVar1;
        fcn.1800f4640();
    }
    return;
}

// ============================================================
// Function: FUN_1800d4d20
// Address: 0x1800d4d20
// Size: 147 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800d4d20(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)arg1;
    if (iVar2 != 0) {
        puVar1 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar2 + 8 & 0xfffffffffffffff8);
        if ((uint64_t)((int64_t)puVar1 + arg2) <= iVar2 + 0x2008U) {
            *(int64_t *)(arg1 + 8) = (int64_t)puVar1 + (arg2 - (iVar2 + 8));
            return puVar1;
        }
    }
    iVar2 = 0x2000;
    if (0x2000 < (uint64_t)arg2) {
        iVar2 = arg2;
    }
    puVar1 = (undefined8 *)fcn.180459890(iVar2 + 8);
    *puVar1 = *(undefined8 *)arg1;
    *(undefined8 **)arg1 = puVar1;
    *(int64_t *)(arg1 + 8) = arg2;
    return puVar1 + 1;
}

// ============================================================
// Function: FUN_1800d4de0
// Address: 0x1800d4de0
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4de0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x1f8))(arg2, arg1);
    if ((cVar2 != '\0') && (puVar1 = *(undefined8 **)(arg1 + 0x28), puVar1 != (undefined8 *)0x0)) {
        (**(code **)*puVar1)(puVar1, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4e20
// Address: 0x1800d4e20
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4e20(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t var_8h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x1f0))(arg2, arg1);
    if ((cVar2 != '\0') && (puVar1 = *(undefined8 **)(arg1 + 0x28), puVar1 != (undefined8 *)0x0)) {
        (**(code **)*puVar1)(puVar1, arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4e60
// Address: 0x1800d4e60
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d4e60(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 0x1e0))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
    }
    return;
}

// ============================================================
// Function: FUN_1800d4fa0
// Address: 0x1800d4fa0
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d4fa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x198))(arg2, arg1);
    if (cVar2 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d4fca
// Address: 0x1800d4fca
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d4fa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x198))(arg2, arg1);
    if (cVar2 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d4ffe
// Address: 0x1800d4ffe
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800d4fa0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    cVar2 = (**(code **)(*(int64_t *)arg2 + 0x198))(arg2, arg1);
    if (cVar2 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
        puVar3 = *(undefined8 **)(arg1 + 0x38);
        puVar1 = puVar3 + *(int64_t *)(arg1 + 0x40);
        for (; puVar3 != puVar1; puVar3 = puVar3 + 1) {
            (***(code ***)(undefined8 *)*puVar3)((undefined8 *)*puVar3, arg2);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800d5010
// Address: 0x1800d5010
// Size: 58 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800d5010(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = (**(code **)(*(int64_t *)arg2 + 400))(arg2, arg1);
    if (cVar1 != '\0') {
        (**(code **)**(undefined8 **)(arg1 + 0x20))(*(undefined8 **)(arg1 + 0x20), arg2);
    }
    return;
}

