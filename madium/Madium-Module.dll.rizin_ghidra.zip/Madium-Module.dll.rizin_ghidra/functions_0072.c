// Chunk 72 - 50 functions

// ============================================================
// Function: FUN_1800f1710
// Address: 0x1800f1710
// Size: 166 bytes
// ============================================================
undefined8 * fcn.1800f1710(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    
    iVar6 = *(int64_t *)arg1;
    if (iVar6 != 0) {
        puVar8 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar6 + 8 & 0xfffffffffffffff8);
        if (puVar8 + 5 <= (undefined8 *)(iVar6 + 0x2008)) {
            iVar6 = (int64_t)puVar8 + (0x28 - (iVar6 + 8));
            goto code_r0x0001800f1778;
        }
    }
    puVar7 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar7 = *(undefined8 *)arg1;
    puVar8 = puVar7 + 1;
    *(undefined8 **)arg1 = puVar7;
    iVar6 = 0x28;
code_r0x0001800f1778:
    *(int64_t *)(arg1 + 8) = iVar6;
    uVar2 = *(undefined4 *)0x18078267c;
    uVar1 = *(undefined8 *)arg3;
    *puVar8 = 0x180642298;
    *(undefined4 *)(puVar8 + 1) = uVar2;
    uVar2 = *(undefined4 *)arg2;
    uVar3 = *(undefined4 *)(arg2 + 4);
    uVar4 = *(undefined4 *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg2 + 0xc);
    *puVar8 = 0x1806419c8;
    puVar8[4] = uVar1;
    *(undefined4 *)((int64_t)puVar8 + 0xc) = uVar2;
    *(undefined4 *)(puVar8 + 2) = uVar3;
    *(undefined4 *)((int64_t)puVar8 + 0x14) = uVar4;
    *(undefined4 *)(puVar8 + 3) = uVar5;
    return puVar8;
}

// ============================================================
// Function: FUN_1800f17c0
// Address: 0x1800f17c0
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800f17c0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        puVar3 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar1 + 8 & 0xfffffffffffffff8);
        if ((int64_t)puVar3 + 0xcU <= iVar1 + 0x2008U) {
            iVar1 = (int64_t)puVar3 + (0xc - (iVar1 + 8));
            goto code_r0x0001800f182b;
        }
    }
    puVar2 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar2 = *(undefined8 *)arg1;
    puVar3 = puVar2 + 1;
    *(undefined8 **)arg1 = puVar2;
    iVar1 = 0xc;
code_r0x0001800f182b:
    *(int64_t *)(arg1 + 8) = iVar1;
    *(undefined4 *)puVar3 = *(undefined4 *)0x180782acc;
    *(undefined8 *)((int64_t)puVar3 + 4) = *(undefined8 *)arg2;
    return puVar3;
}

// ============================================================
// Function: FUN_1800f1860
// Address: 0x1800f1860
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.1800f1860(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined8 *puVar2;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar1 = *(int64_t *)arg1;
    if (iVar1 != 0) {
        puVar3 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar1 + 8 & 0xfffffffffffffff8);
        if ((int64_t)puVar3 + 0xcU <= iVar1 + 0x2008U) {
            iVar1 = (int64_t)puVar3 + (0xc - (iVar1 + 8));
            goto code_r0x0001800f18cb;
        }
    }
    puVar2 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar2 = *(undefined8 *)arg1;
    puVar3 = puVar2 + 1;
    *(undefined8 **)arg1 = puVar2;
    iVar1 = 0xc;
code_r0x0001800f18cb:
    *(int64_t *)(arg1 + 8) = iVar1;
    *(undefined4 *)puVar3 = *(undefined4 *)0x180782aac;
    *(undefined8 *)((int64_t)puVar3 + 4) = *(undefined8 *)arg2;
    return puVar3;
}

// ============================================================
// Function: FUN_1800f1900
// Address: 0x1800f1900
// Size: 168 bytes
// ============================================================
undefined8 * fcn.1800f1900(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int64_t iVar7;
    undefined8 *puVar8;
    undefined8 *puVar9;
    
    iVar7 = *(int64_t *)arg1;
    if (iVar7 != 0) {
        puVar9 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar7 + 8 & 0xfffffffffffffff8);
        if (puVar9 + 6 <= (undefined8 *)(iVar7 + 0x2008U)) {
            iVar7 = (int64_t)puVar9 + (0x30 - (iVar7 + 8));
            goto code_r0x0001800f196e;
        }
    }
    puVar8 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar8 = *(undefined8 *)arg1;
    puVar9 = puVar8 + 1;
    *(undefined8 **)arg1 = puVar8;
    iVar7 = 0x30;
code_r0x0001800f196e:
    *(int64_t *)(arg1 + 8) = iVar7;
    uVar6 = *(undefined4 *)0x180782ab4;
    uVar3 = *(undefined4 *)(arg4 + 4);
    uVar4 = *(undefined4 *)(arg4 + 8);
    uVar5 = *(undefined4 *)(arg4 + 0xc);
    uVar1 = *(undefined8 *)arg3;
    uVar2 = *(undefined8 *)arg2;
    *(undefined4 *)(puVar9 + 3) = *(undefined4 *)arg4;
    *(undefined4 *)((int64_t)puVar9 + 0x1c) = uVar3;
    *(undefined4 *)(puVar9 + 4) = uVar4;
    *(undefined4 *)((int64_t)puVar9 + 0x24) = uVar5;
    *(undefined4 *)puVar9 = uVar6;
    *(undefined8 *)((int64_t)puVar9 + 4) = uVar2;
    *(undefined8 *)((int64_t)puVar9 + 0xc) = uVar1;
    puVar9[5] = 0;
    return puVar9;
}

// ============================================================
// Function: FUN_1800f19b0
// Address: 0x1800f19b0
// Size: 146 bytes
// ============================================================
undefined8 * fcn.1800f19b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    
    iVar9 = *(int64_t *)arg1;
    if (iVar9 != 0) {
        puVar11 = (undefined8 *)(*(int64_t *)(arg1 + 8) + 7 + iVar9 + 8 & 0xfffffffffffffff8);
        if (puVar11 + 5 <= (undefined8 *)(iVar9 + 0x2008U)) {
            iVar9 = (int64_t)puVar11 + (0x28 - (iVar9 + 8));
            goto code_r0x0001800f1a18;
        }
    }
    puVar10 = (undefined8 *)func_0x000180459890(0x2008);
    *puVar10 = *(undefined8 *)arg1;
    puVar11 = puVar10 + 1;
    *(undefined8 **)arg1 = puVar10;
    iVar9 = 0x28;
code_r0x0001800f1a18:
    *(int64_t *)(arg1 + 8) = iVar9;
    uVar1 = *(undefined4 *)arg3;
    uVar2 = *(undefined4 *)(arg3 + 4);
    uVar3 = *(undefined4 *)(arg3 + 8);
    uVar4 = *(undefined4 *)(arg3 + 0xc);
    uVar5 = *(undefined4 *)arg2;
    uVar6 = *(undefined4 *)(arg2 + 4);
    uVar7 = *(undefined4 *)(arg2 + 8);
    uVar8 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)puVar11 = *(undefined4 *)0x180782a70;
    *(undefined4 *)(puVar11 + 3) = uVar1;
    *(undefined4 *)((int64_t)puVar11 + 0x1c) = uVar2;
    *(undefined4 *)(puVar11 + 4) = uVar3;
    *(undefined4 *)((int64_t)puVar11 + 0x24) = uVar4;
    *(undefined4 *)(puVar11 + 1) = uVar5;
    *(undefined4 *)((int64_t)puVar11 + 0xc) = uVar6;
    *(undefined4 *)(puVar11 + 2) = uVar7;
    *(undefined4 *)((int64_t)puVar11 + 0x14) = uVar8;
    return puVar11;
}

// ============================================================
// Function: FUN_1800f1a70
// Address: 0x1800f1a70
// Size: 411 bytes
// ============================================================
void fcn.1800f1a70(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint64_t *puVar2;
    undefined8 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    undefined8 *puVar6;
    undefined *puVar7;
    int64_t iVar8;
    uint64_t uVar9;
    uint64_t unaff_RDI;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t var_1h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar2 = *(uint64_t **)arg1;
    puVar6 = (undefined8 *)puVar2[1];
    if (puVar6 != (undefined8 *)puVar2[2]) {
        *puVar6 = *(undefined8 *)arg2;
        puVar2[1] = puVar2[1] + 8;
        goto code_r0x0001800f1bea;
    }
    iVar8 = (int64_t)((int64_t)puVar6 - *puVar2) >> 3;
    if (iVar8 == 0x1fffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar10 = (int64_t)((int64_t)(undefined8 *)puVar2[2] - *puVar2) >> 3;
    if (0x1fffffffffffffff - (uVar10 >> 1) < uVar10) {
code_r0x0001800f1c05:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar1 = iVar8 + 1;
    uVar10 = uVar10 + (uVar10 >> 1);
    uVar9 = uVar1;
    if (uVar1 <= uVar10) {
        uVar9 = uVar10;
    }
    if (0x1fffffffffffffff < uVar9) goto code_r0x0001800f1c05;
    uVar9 = uVar9 * 8;
    if (uVar9 == 0) {
        unaff_RDI = 0;
code_r0x0001800f1b4c:
        *(undefined8 *)(unaff_RDI + iVar8 * 8) = *(undefined8 *)arg2;
        puVar3 = (undefined8 *)*puVar2;
        if (puVar6 == (undefined8 *)puVar2[1]) {
            iVar11 = (int64_t)(undefined8 *)puVar2[1] - (int64_t)puVar3;
            uVar10 = unaff_RDI;
            puVar6 = puVar3;
        } else {
            func_0x000180498030(unaff_RDI, puVar3, (int64_t)puVar6 - (int64_t)puVar3);
            iVar11 = puVar2[1] - (int64_t)puVar6;
            uVar10 = unaff_RDI + (iVar8 + 1) * 8;
        }
        func_0x000180498030(uVar10, puVar6, iVar11);
        uVar10 = *puVar2;
        if (uVar10 != 0) {
            uVar5 = uVar10;
            puVar7 = auStack_68;
            if ((0xfff < (uint64_t)(((int64_t)(puVar2[2] - uVar10) >> 3) * 8)) &&
               (uVar5 = *(uint64_t *)(uVar10 - 8), puVar7 = auStack_68, 0x1f < (uVar10 - uVar5) - 8))
            goto code_r0x0001800f1bc5;
            goto code_r0x0001800f1bcf;
        }
    } else {
        if (uVar9 < 0x1000) {
            unaff_RDI = func_0x000180459890(uVar9);
            goto code_r0x0001800f1b4c;
        }
        if (uVar9 + 0x27 <= uVar9) goto code_r0x0001800f1c05;
        iVar11 = func_0x000180459890();
        if (iVar11 != 0) {
            unaff_RDI = iVar11 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar11;
            goto code_r0x0001800f1b4c;
        }
code_r0x0001800f1bc5:
        uVar5 = 5;
        pcVar4 = (code *)swi(0x29);
        (*pcVar4)(5);
        puVar7 = auStack_60;
code_r0x0001800f1bcf:
        *(undefined8 *)(puVar7 + -8) = 0x1800f1bd7;
        func_0x000180459c3c(uVar5);
    }
    *puVar2 = unaff_RDI;
    puVar2[1] = unaff_RDI + uVar1 * 8;
    puVar2[2] = uVar9 + unaff_RDI;
code_r0x0001800f1bea:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    return;
}

// ============================================================
// Function: FUN_1800f1c30
// Address: 0x1800f1c30
// Size: 289 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800f1c30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    int64_t iVar16;
    undefined8 unaff_R13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar13 = auStack_48;
    puVar14 = auStack_48;
    piVar1 = *(int64_t **)arg1;
    puVar11 = (undefined4 *)piVar1[1];
    if (puVar11 != (undefined4 *)piVar1[2]) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar4;
        puVar11[2] = uVar5;
        puVar11[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar11[4] = *(undefined4 *)(arg2 + 0x10);
        puVar11[5] = uVar4;
        puVar11[6] = uVar5;
        puVar11[7] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x24);
        uVar5 = *(undefined4 *)(arg2 + 0x28);
        uVar6 = *(undefined4 *)(arg2 + 0x2c);
        puVar11[8] = *(undefined4 *)(arg2 + 0x20);
        puVar11[9] = uVar4;
        puVar11[10] = uVar5;
        puVar11[0xb] = uVar6;
        piVar1[1] = piVar1[1] + 0x30;
code_r0x0001800f1dc2:
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
        return;
    }
    iVar9 = (int64_t)puVar11 - *piVar1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 3) - (iVar9 >> 0x3f);
    if (iVar9 == 0x555555555555555) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar15 = ((int64_t)(undefined4 *)piVar1[2] - *piVar1 >> 4) * -0x5555555555555555;
    uVar8 = 0x555555555555555 - (uVar15 >> 1);
    if (uVar15 < uVar8 || uVar15 - uVar8 == 0) {
        uVar15 = uVar15 + (uVar15 >> 1);
        uVar8 = iVar9 + 1U;
        if (iVar9 + 1U <= uVar15) {
            uVar8 = uVar15;
        }
        if (uVar8 < 0x555555555555556) {
            uVar15 = uVar8 * 0x30;
            if (uVar15 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar14 = auStack_48;
            } else if (uVar15 < 0x1000) {
                puVar12 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800f1de3;
                iVar16 = func_0x000180459890(uVar15 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar13 = auStack_40;
                }
                puVar12 = (undefined4 *)(iVar16 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar16;
                puVar14 = puVar13;
            }
            uVar4 = *(undefined4 *)arg2;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined8 *)(puVar14 + 0x50) = unaff_R13;
            puVar10 = puVar12 + iVar9 * 0xc;
            *puVar10 = uVar4;
            puVar10[1] = uVar5;
            puVar10[2] = uVar6;
            puVar10[3] = uVar7;
            uVar4 = *(undefined4 *)(arg2 + 0x14);
            uVar5 = *(undefined4 *)(arg2 + 0x18);
            uVar6 = *(undefined4 *)(arg2 + 0x1c);
            puVar10[4] = *(undefined4 *)(arg2 + 0x10);
            puVar10[5] = uVar4;
            puVar10[6] = uVar5;
            puVar10[7] = uVar6;
            uVar4 = *(undefined4 *)(arg2 + 0x24);
            uVar5 = *(undefined4 *)(arg2 + 0x28);
            uVar6 = *(undefined4 *)(arg2 + 0x2c);
            puVar10[8] = *(undefined4 *)(arg2 + 0x20);
            puVar10[9] = uVar4;
            puVar10[10] = uVar5;
            puVar10[0xb] = uVar6;
            puVar2 = (undefined4 *)*piVar1;
            if (puVar11 == (undefined4 *)piVar1[1]) {
                iVar16 = (int64_t)(undefined4 *)piVar1[1] - (int64_t)puVar2;
                puVar10 = puVar12;
                puVar11 = puVar2;
            } else {
                *(undefined8 *)(puVar14 + -8) = 0x1800f1d97;
                func_0x000180498030(puVar12, puVar2, (int64_t)puVar11 - (int64_t)puVar2);
                puVar10 = puVar10 + 0xc;
                iVar16 = piVar1[1] - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar14 + -8) = 0x1800f1daa;
            func_0x000180498030(puVar10, puVar11, iVar16);
            *(undefined8 *)(puVar14 + -8) = 0x1800f1dbd;
            func_0x0001800f3380(piVar1, puVar12, iVar9 + 1, uVar8);
            goto code_r0x0001800f1dc2;
        }
    }
code_r0x0001800f1de3:
    func_0x000180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800f1d51
// Address: 0x1800f1d51
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800f1c30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    int64_t iVar16;
    undefined8 unaff_R13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar13 = auStack_48;
    puVar14 = auStack_48;
    piVar1 = *(int64_t **)arg1;
    puVar11 = (undefined4 *)piVar1[1];
    if (puVar11 != (undefined4 *)piVar1[2]) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar4;
        puVar11[2] = uVar5;
        puVar11[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar11[4] = *(undefined4 *)(arg2 + 0x10);
        puVar11[5] = uVar4;
        puVar11[6] = uVar5;
        puVar11[7] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x24);
        uVar5 = *(undefined4 *)(arg2 + 0x28);
        uVar6 = *(undefined4 *)(arg2 + 0x2c);
        puVar11[8] = *(undefined4 *)(arg2 + 0x20);
        puVar11[9] = uVar4;
        puVar11[10] = uVar5;
        puVar11[0xb] = uVar6;
        piVar1[1] = piVar1[1] + 0x30;
code_r0x0001800f1dc2:
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
        return;
    }
    iVar9 = (int64_t)puVar11 - *piVar1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 3) - (iVar9 >> 0x3f);
    if (iVar9 == 0x555555555555555) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar15 = ((int64_t)(undefined4 *)piVar1[2] - *piVar1 >> 4) * -0x5555555555555555;
    uVar8 = 0x555555555555555 - (uVar15 >> 1);
    if (uVar15 < uVar8 || uVar15 - uVar8 == 0) {
        uVar15 = uVar15 + (uVar15 >> 1);
        uVar8 = iVar9 + 1U;
        if (iVar9 + 1U <= uVar15) {
            uVar8 = uVar15;
        }
        if (uVar8 < 0x555555555555556) {
            uVar15 = uVar8 * 0x30;
            if (uVar15 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar14 = auStack_48;
            } else if (uVar15 < 0x1000) {
                puVar12 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800f1de3;
                iVar16 = func_0x000180459890(uVar15 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar13 = auStack_40;
                }
                puVar12 = (undefined4 *)(iVar16 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar16;
                puVar14 = puVar13;
            }
            uVar4 = *(undefined4 *)arg2;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined8 *)(puVar14 + 0x50) = unaff_R13;
            puVar10 = puVar12 + iVar9 * 0xc;
            *puVar10 = uVar4;
            puVar10[1] = uVar5;
            puVar10[2] = uVar6;
            puVar10[3] = uVar7;
            uVar4 = *(undefined4 *)(arg2 + 0x14);
            uVar5 = *(undefined4 *)(arg2 + 0x18);
            uVar6 = *(undefined4 *)(arg2 + 0x1c);
            puVar10[4] = *(undefined4 *)(arg2 + 0x10);
            puVar10[5] = uVar4;
            puVar10[6] = uVar5;
            puVar10[7] = uVar6;
            uVar4 = *(undefined4 *)(arg2 + 0x24);
            uVar5 = *(undefined4 *)(arg2 + 0x28);
            uVar6 = *(undefined4 *)(arg2 + 0x2c);
            puVar10[8] = *(undefined4 *)(arg2 + 0x20);
            puVar10[9] = uVar4;
            puVar10[10] = uVar5;
            puVar10[0xb] = uVar6;
            puVar2 = (undefined4 *)*piVar1;
            if (puVar11 == (undefined4 *)piVar1[1]) {
                iVar16 = (int64_t)(undefined4 *)piVar1[1] - (int64_t)puVar2;
                puVar10 = puVar12;
                puVar11 = puVar2;
            } else {
                *(undefined8 *)(puVar14 + -8) = 0x1800f1d97;
                func_0x000180498030(puVar12, puVar2, (int64_t)puVar11 - (int64_t)puVar2);
                puVar10 = puVar10 + 0xc;
                iVar16 = piVar1[1] - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar14 + -8) = 0x1800f1daa;
            func_0x000180498030(puVar10, puVar11, iVar16);
            *(undefined8 *)(puVar14 + -8) = 0x1800f1dbd;
            func_0x0001800f3380(piVar1, puVar12, iVar9 + 1, uVar8);
            goto code_r0x0001800f1dc2;
        }
    }
code_r0x0001800f1de3:
    func_0x000180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800f1dc2
// Address: 0x1800f1dc2
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800f1c30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined *puVar14;
    uint64_t uVar15;
    int64_t iVar16;
    undefined8 unaff_R13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_48 [8];
    undefined auStack_40 [24];
    
    puVar13 = auStack_48;
    puVar14 = auStack_48;
    piVar1 = *(int64_t **)arg1;
    puVar11 = (undefined4 *)piVar1[1];
    if (puVar11 != (undefined4 *)piVar1[2]) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar4;
        puVar11[2] = uVar5;
        puVar11[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar11[4] = *(undefined4 *)(arg2 + 0x10);
        puVar11[5] = uVar4;
        puVar11[6] = uVar5;
        puVar11[7] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x24);
        uVar5 = *(undefined4 *)(arg2 + 0x28);
        uVar6 = *(undefined4 *)(arg2 + 0x2c);
        puVar11[8] = *(undefined4 *)(arg2 + 0x20);
        puVar11[9] = uVar4;
        puVar11[10] = uVar5;
        puVar11[0xb] = uVar6;
        piVar1[1] = piVar1[1] + 0x30;
code_r0x0001800f1dc2:
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
        return;
    }
    iVar9 = (int64_t)puVar11 - *piVar1;
    iVar9 = iVar9 / 6 + (iVar9 >> 0x3f);
    iVar9 = (iVar9 >> 3) - (iVar9 >> 0x3f);
    if (iVar9 == 0x555555555555555) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar15 = ((int64_t)(undefined4 *)piVar1[2] - *piVar1 >> 4) * -0x5555555555555555;
    uVar8 = 0x555555555555555 - (uVar15 >> 1);
    if (uVar15 < uVar8 || uVar15 - uVar8 == 0) {
        uVar15 = uVar15 + (uVar15 >> 1);
        uVar8 = iVar9 + 1U;
        if (iVar9 + 1U <= uVar15) {
            uVar8 = uVar15;
        }
        if (uVar8 < 0x555555555555556) {
            uVar15 = uVar8 * 0x30;
            if (uVar15 == 0) {
                puVar12 = (undefined4 *)0x0;
                puVar14 = auStack_48;
            } else if (uVar15 < 0x1000) {
                puVar12 = (undefined4 *)func_0x000180459890();
            } else {
                if (uVar15 + 0x27 <= uVar15) goto code_r0x0001800f1de3;
                iVar16 = func_0x000180459890(uVar15 + 0x27);
                if (iVar16 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar16 = (*pcVar3)(5);
                    puVar13 = auStack_40;
                }
                puVar12 = (undefined4 *)(iVar16 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar12 + -2) = iVar16;
                puVar14 = puVar13;
            }
            uVar4 = *(undefined4 *)arg2;
            uVar5 = *(undefined4 *)(arg2 + 4);
            uVar6 = *(undefined4 *)(arg2 + 8);
            uVar7 = *(undefined4 *)(arg2 + 0xc);
            *(undefined8 *)(puVar14 + 0x50) = unaff_R13;
            puVar10 = puVar12 + iVar9 * 0xc;
            *puVar10 = uVar4;
            puVar10[1] = uVar5;
            puVar10[2] = uVar6;
            puVar10[3] = uVar7;
            uVar4 = *(undefined4 *)(arg2 + 0x14);
            uVar5 = *(undefined4 *)(arg2 + 0x18);
            uVar6 = *(undefined4 *)(arg2 + 0x1c);
            puVar10[4] = *(undefined4 *)(arg2 + 0x10);
            puVar10[5] = uVar4;
            puVar10[6] = uVar5;
            puVar10[7] = uVar6;
            uVar4 = *(undefined4 *)(arg2 + 0x24);
            uVar5 = *(undefined4 *)(arg2 + 0x28);
            uVar6 = *(undefined4 *)(arg2 + 0x2c);
            puVar10[8] = *(undefined4 *)(arg2 + 0x20);
            puVar10[9] = uVar4;
            puVar10[10] = uVar5;
            puVar10[0xb] = uVar6;
            puVar2 = (undefined4 *)*piVar1;
            if (puVar11 == (undefined4 *)piVar1[1]) {
                iVar16 = (int64_t)(undefined4 *)piVar1[1] - (int64_t)puVar2;
                puVar10 = puVar12;
                puVar11 = puVar2;
            } else {
                *(undefined8 *)(puVar14 + -8) = 0x1800f1d97;
                func_0x000180498030(puVar12, puVar2, (int64_t)puVar11 - (int64_t)puVar2);
                puVar10 = puVar10 + 0xc;
                iVar16 = piVar1[1] - (int64_t)puVar11;
            }
            *(undefined8 *)(puVar14 + -8) = 0x1800f1daa;
            func_0x000180498030(puVar10, puVar11, iVar16);
            *(undefined8 *)(puVar14 + -8) = 0x1800f1dbd;
            func_0x0001800f3380(piVar1, puVar12, iVar9 + 1, uVar8);
            goto code_r0x0001800f1dc2;
        }
    }
code_r0x0001800f1de3:
    func_0x000180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800f1e20
// Address: 0x1800f1e20
// Size: 425 bytes
// ============================================================
void fcn.1800f1e20(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    uint64_t *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    uint64_t unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t var_10h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar3 = *(uint64_t **)arg1;
    puVar9 = (undefined4 *)puVar3[1];
    if (puVar9 != (undefined4 *)puVar3[2]) {
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar5;
        puVar9[2] = uVar6;
        puVar9[3] = uVar7;
        uVar5 = *(undefined4 *)(arg2 + 0x14);
        uVar6 = *(undefined4 *)(arg2 + 0x18);
        uVar7 = *(undefined4 *)(arg2 + 0x1c);
        puVar9[4] = *(undefined4 *)(arg2 + 0x10);
        puVar9[5] = uVar5;
        puVar9[6] = uVar6;
        puVar9[7] = uVar7;
        puVar3[1] = puVar3[1] + 0x20;
        goto code_r0x0001800f1fa7;
    }
    iVar14 = (int64_t)((int64_t)puVar9 - *puVar3) >> 5;
    if (iVar14 == 0x7ffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar12 = (int64_t)((int64_t)(undefined4 *)puVar3[2] - *puVar3) >> 5;
    if (0x7ffffffffffffff - (uVar12 >> 1) < uVar12) {
code_r0x0001800f1fc3:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar1 = iVar14 + 1;
    uVar12 = uVar12 + (uVar12 >> 1);
    uVar11 = uVar1;
    if (uVar1 <= uVar12) {
        uVar11 = uVar12;
    }
    if (0x7ffffffffffffff < uVar11) goto code_r0x0001800f1fc3;
    uVar11 = uVar11 * 0x20;
    if (uVar11 == 0) {
        unaff_RDI = 0;
code_r0x0001800f1f01:
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        iVar14 = iVar14 * 0x20;
        puVar2 = (undefined4 *)(iVar14 + unaff_RDI);
        *puVar2 = *(undefined4 *)arg2;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        uVar5 = *(undefined4 *)(arg2 + 0x14);
        uVar6 = *(undefined4 *)(arg2 + 0x18);
        uVar7 = *(undefined4 *)(arg2 + 0x1c);
        puVar2 = (undefined4 *)(iVar14 + 0x10 + unaff_RDI);
        *puVar2 = *(undefined4 *)(arg2 + 0x10);
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2 = (undefined4 *)*puVar3;
        if (puVar9 == (undefined4 *)puVar3[1]) {
            iVar13 = (int64_t)(undefined4 *)puVar3[1] - (int64_t)puVar2;
            uVar12 = unaff_RDI;
            puVar9 = puVar2;
        } else {
            func_0x000180498030(unaff_RDI, puVar2, (int64_t)puVar9 - (int64_t)puVar2);
            iVar13 = puVar3[1] - (int64_t)puVar9;
            uVar12 = iVar14 + 0x20 + unaff_RDI;
        }
        func_0x000180498030(uVar12, puVar9, iVar13);
        uVar12 = *puVar3;
        if (uVar12 != 0) {
            uVar8 = uVar12;
            puVar10 = auStack_68;
            if ((0xfff < (puVar3[2] - uVar12 & 0xffffffffffffffe0)) &&
               (uVar8 = *(uint64_t *)(uVar12 - 8), puVar10 = auStack_68, 0x1f < (uVar12 - uVar8) - 8))
            goto code_r0x0001800f1f82;
            goto code_r0x0001800f1f8c;
        }
    } else {
        if (uVar11 < 0x1000) {
            unaff_RDI = func_0x000180459890(uVar11);
            goto code_r0x0001800f1f01;
        }
        if (uVar11 + 0x27 <= uVar11) goto code_r0x0001800f1fc3;
        iVar13 = func_0x000180459890();
        if (iVar13 != 0) {
            unaff_RDI = iVar13 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar13;
            goto code_r0x0001800f1f01;
        }
code_r0x0001800f1f82:
        pcVar4 = (code *)swi(0x29);
        uVar8 = (*pcVar4)(5);
        puVar10 = auStack_60;
code_r0x0001800f1f8c:
        *(undefined8 *)(puVar10 + -8) = 0x1800f1f91;
        func_0x000180459c3c(uVar8);
    }
    *puVar3 = unaff_RDI;
    puVar3[1] = uVar1 * 0x20 + unaff_RDI;
    puVar3[2] = uVar11 + unaff_RDI;
code_r0x0001800f1fa7:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    return;
}

// ============================================================
// Function: FUN_1800f1ff0
// Address: 0x1800f1ff0
// Size: 84 bytes
// ============================================================
void fcn.1800f1ff0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t *piVar3;
    int32_t *piVar4;
    
    piVar1 = *(int64_t **)arg1;
    piVar2 = (int32_t *)piVar1[1];
    piVar4 = (int32_t *)(*(int64_t *)(arg1 + 8) * 0x50 + *piVar1);
    piVar3 = piVar4;
    if (piVar4 != piVar2) {
        do {
            (**(code **)((int64_t)*piVar3 * 8 + 0x180644200))(piVar3 + 2);
            piVar3 = piVar3 + 0x14;
        } while (piVar3 != piVar2);
        piVar1[1] = (int64_t)piVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800f2050
// Address: 0x1800f2050
// Size: 776 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f2050(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int32_t **ppiVar2;
    code *pcVar3;
    int64_t iVar4;
    int32_t *piVar5;
    int64_t iVar6;
    int32_t *piVar7;
    int32_t *piVar8;
    undefined *puVar9;
    undefined *puVar10;
    int32_t *piVar11;
    uint64_t uVar12;
    int32_t *piVar13;
    uint64_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_90;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    
    puVar9 = auStack_88;
    puVar10 = auStack_88;
    ppiVar2 = *(int32_t ***)arg1;
    piVar13 = ppiVar2[1];
    if (piVar13 != ppiVar2[2]) {
        iVar1 = *(int32_t *)arg2;
        *piVar13 = iVar1;
        (**(code **)((int64_t)iVar1 * 8 + 0x1806441a0))(piVar13 + 2, arg2 + 8);
        ppiVar2[1] = ppiVar2[1] + 0x14;
code_r0x0001800f2330:
        *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
        return;
    }
    iVar4 = ((int64_t)piVar13 - (int64_t)*ppiVar2) / 0x50;
    if (iVar4 == 0x333333333333333) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar14 = ((int64_t)ppiVar2[2] - (int64_t)*ppiVar2) / 0x50;
    if (uVar14 <= 0x333333333333333 - (uVar14 >> 1)) {
        uVar14 = (uVar14 >> 1) + uVar14;
        uVar12 = iVar4 + 1U;
        if (iVar4 + 1U <= uVar14) {
            uVar12 = uVar14;
        }
        if (uVar12 < 0x333333333333334) {
            uVar14 = uVar12 * 0x50;
            if (uVar14 == 0) {
                piVar11 = (int32_t *)0x0;
                puVar10 = auStack_88;
            } else if (uVar14 < 0x1000) {
                piVar11 = (int32_t *)func_0x000180459890(uVar14);
            } else {
                if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800f2352;
                iVar6 = func_0x000180459890();
                if (iVar6 == 0) {
                    pcVar3 = (code *)swi(0x29);
                    iVar6 = (*pcVar3)(5);
                    puVar9 = auStack_80;
                }
                piVar11 = (int32_t *)(iVar6 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(piVar11 + -2) = iVar6;
                puVar10 = puVar9;
            }
            piVar7 = piVar11 + iVar4 * 0x14;
            *(int32_t ***)(puVar10 + 0x20) = ppiVar2;
            *(int32_t **)(puVar10 + 0x28) = piVar11;
            *(uint64_t *)(puVar10 + 0x30) = uVar12;
            *(int32_t **)(puVar10 + 0x38) = piVar7 + 0x14;
            *(int32_t **)(puVar10 + 0x40) = piVar7 + 0x14;
            iVar1 = *(int32_t *)arg2;
            *piVar7 = iVar1;
            pcVar3 = *(code **)((int64_t)iVar1 * 8 + 0x1806441a0);
            *(undefined8 *)(puVar10 + -8) = 0x1800f21c5;
            (*pcVar3)(piVar7 + 2, arg2 + 8);
            *(int32_t **)(puVar10 + 0x38) = piVar7;
            piVar7 = ppiVar2[1];
            piVar8 = *ppiVar2;
            piVar5 = piVar11;
            if (piVar13 == piVar7) {
                for (; piVar8 != piVar7; piVar8 = piVar8 + 0x14) {
                    iVar1 = *piVar8;
                    *piVar5 = iVar1;
                    pcVar3 = *(code **)((int64_t)iVar1 * 8 + 0x1806441a0);
                    *(undefined8 *)(puVar10 + -8) = 0x1800f21f6;
                    (*pcVar3)(piVar5 + 2, piVar8 + 2);
                    piVar5 = piVar5 + 0x14;
                }
            } else {
                for (; piVar8 != piVar13; piVar8 = piVar8 + 0x14) {
                    iVar1 = *piVar8;
                    *piVar5 = iVar1;
                    pcVar3 = *(code **)((int64_t)iVar1 * 8 + 0x1806441a0);
                    *(undefined8 *)(puVar10 + -8) = 0x1800f2225;
                    (*pcVar3)(piVar5 + 2, piVar8 + 2);
                    piVar5 = piVar5 + 0x14;
                }
                *(int32_t **)(puVar10 + 0x38) = piVar11;
                piVar8 = ppiVar2[1];
                piVar7 = piVar11 + iVar4 * 0x14 + 0x14;
                for (; piVar13 != piVar8; piVar13 = piVar13 + 0x14) {
                    iVar1 = *piVar13;
                    *piVar7 = iVar1;
                    pcVar3 = *(code **)((int64_t)iVar1 * 8 + 0x1806441a0);
                    *(undefined8 *)(puVar10 + -8) = 0x1800f2264;
                    (*pcVar3)(piVar7 + 2, piVar13 + 2);
                    piVar7 = piVar7 + 0x14;
                }
            }
            *(undefined8 *)(puVar10 + 0x28) = 0;
            piVar13 = *ppiVar2;
            if (piVar13 != (int32_t *)0x0) {
                piVar7 = ppiVar2[1];
                for (; piVar13 != piVar7; piVar13 = piVar13 + 0x14) {
                    pcVar3 = *(code **)((int64_t)*piVar13 * 8 + 0x180644200);
                    *(undefined8 *)(puVar10 + -8) = 0x1800f229e;
                    (*pcVar3)(piVar13 + 2);
                }
                piVar13 = *ppiVar2;
                piVar7 = piVar13;
                if (0xfff < (uint64_t)((((int64_t)ppiVar2[2] - (int64_t)piVar13) / 0x50) * 0x50)) {
                    piVar7 = *(int32_t **)(piVar13 + -2);
                    piVar13 = (int32_t *)((int64_t)piVar13 + (-8 - (int64_t)piVar7));
                    if ((int32_t *)0x1f < piVar13) {
                        pcVar3 = (code *)swi(0x29);
                        piVar7 = piVar13;
                        (*pcVar3)(5);
                        puVar10 = puVar10 + 8;
                    }
                }
                *(undefined8 *)(puVar10 + -8) = 0x1800f2304;
                func_0x000180459c3c(piVar7);
            }
            *ppiVar2 = piVar11;
            ppiVar2[1] = piVar11 + *(int64_t *)(puVar10 + 0xa0) * 0x14;
            ppiVar2[2] = piVar11 + uVar12 * 0x14;
            arg1 = *(int64_t *)(puVar10 + 0x90);
            goto code_r0x0001800f2330;
        }
    }
code_r0x0001800f2352:
    func_0x000180004720();
    pcVar3 = (code *)swi(3);
    (*pcVar3)();
    return;
}

// ============================================================
// Function: FUN_1800f23a0
// Address: 0x1800f23a0
// Size: 519 bytes
// ============================================================
void fcn.1800f23a0(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined *puVar12;
    undefined4 *unaff_RDI;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    piVar1 = *(int64_t **)arg1;
    puVar11 = (undefined4 *)piVar1[1];
    if (puVar11 != (undefined4 *)piVar1[2]) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar11 = *(undefined4 *)arg2;
        puVar11[1] = uVar4;
        puVar11[2] = uVar5;
        puVar11[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar11[4] = *(undefined4 *)(arg2 + 0x10);
        puVar11[5] = uVar4;
        puVar11[6] = uVar5;
        puVar11[7] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x24);
        uVar5 = *(undefined4 *)(arg2 + 0x28);
        uVar6 = *(undefined4 *)(arg2 + 0x2c);
        puVar11[8] = *(undefined4 *)(arg2 + 0x20);
        puVar11[9] = uVar4;
        puVar11[10] = uVar5;
        puVar11[0xb] = uVar6;
        *(undefined8 *)(puVar11 + 0xc) = *(undefined8 *)(arg2 + 0x30);
        piVar1[1] = piVar1[1] + 0x38;
        goto code_r0x0001800f2585;
    }
    iVar14 = ((int64_t)puVar11 - *piVar1) / 0x38;
    if (iVar14 == 0x492492492492492) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar13 = ((int64_t)(undefined4 *)piVar1[2] - *piVar1 >> 3) * 0x6db6db6db6db6db7;
    uVar7 = 0x492492492492492 - (uVar13 >> 1);
    if (uVar7 <= uVar13 && uVar13 - uVar7 != 0) {
code_r0x0001800f25a1:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar13 = uVar13 + (uVar13 >> 1);
    uVar7 = iVar14 + 1;
    uVar8 = uVar7;
    if (uVar7 <= uVar13) {
        uVar8 = uVar13;
    }
    if (0x492492492492492 < uVar8) goto code_r0x0001800f25a1;
    uVar13 = uVar8 * 0x38;
    if (uVar13 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800f24ba:
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        puVar9 = unaff_RDI + iVar14 * 0xe;
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar4;
        puVar9[2] = uVar5;
        puVar9[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar9[4] = *(undefined4 *)(arg2 + 0x10);
        puVar9[5] = uVar4;
        puVar9[6] = uVar5;
        puVar9[7] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x24);
        uVar5 = *(undefined4 *)(arg2 + 0x28);
        uVar6 = *(undefined4 *)(arg2 + 0x2c);
        puVar9[8] = *(undefined4 *)(arg2 + 0x20);
        puVar9[9] = uVar4;
        puVar9[10] = uVar5;
        puVar9[0xb] = uVar6;
        *(undefined8 *)(puVar9 + 0xc) = *(undefined8 *)(arg2 + 0x30);
        puVar2 = (undefined4 *)*piVar1;
        if (puVar11 == (undefined4 *)piVar1[1]) {
            iVar14 = (int64_t)(undefined4 *)piVar1[1] - (int64_t)puVar2;
            puVar9 = unaff_RDI;
            puVar11 = puVar2;
        } else {
            func_0x000180498030(unaff_RDI, puVar2, (int64_t)puVar11 - (int64_t)puVar2);
            puVar9 = puVar9 + 0xe;
            iVar14 = piVar1[1] - (int64_t)puVar11;
        }
        func_0x000180498030(puVar9, puVar11, iVar14);
        iVar14 = *piVar1;
        if (iVar14 != 0) {
            iVar10 = iVar14;
            puVar12 = auStack_68;
            if ((0xfff < (uint64_t)((piVar1[2] - iVar14 >> 3) * 8)) &&
               (iVar10 = *(int64_t *)(iVar14 + -8), puVar12 = auStack_68, 0x1f < (iVar14 - iVar10) - 8U))
            goto code_r0x0001800f255d;
            goto code_r0x0001800f2567;
        }
    } else {
        if (uVar13 < 0x1000) {
            unaff_RDI = (undefined4 *)func_0x000180459890(uVar13);
            goto code_r0x0001800f24ba;
        }
        if (uVar13 + 0x27 <= uVar13) goto code_r0x0001800f25a1;
        iVar10 = func_0x000180459890();
        if (iVar10 != 0) {
            unaff_RDI = (undefined4 *)(iVar10 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar10;
            goto code_r0x0001800f24ba;
        }
code_r0x0001800f255d:
        iVar10 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar12 = auStack_60;
code_r0x0001800f2567:
        *(undefined8 *)(puVar12 + -8) = 0x1800f256f;
        func_0x000180459c3c(iVar10);
    }
    *piVar1 = (int64_t)unaff_RDI;
    piVar1[1] = (int64_t)(unaff_RDI + uVar7 * 0xe);
    piVar1[2] = (int64_t)(unaff_RDI + uVar8 * 0xe);
code_r0x0001800f2585:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    return;
}

// ============================================================
// Function: FUN_1800f25b0
// Address: 0x1800f25b0
// Size: 512 bytes
// ============================================================
void fcn.1800f25b0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined4 *unaff_RDI;
    uint64_t uVar14;
    int64_t var_10h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    piVar1 = *(int64_t **)arg1;
    puVar12 = (undefined4 *)piVar1[1];
    if (puVar12 != (undefined4 *)piVar1[2]) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar12 = *(undefined4 *)arg2;
        puVar12[1] = uVar4;
        puVar12[2] = uVar5;
        puVar12[3] = uVar6;
        *(undefined8 *)(puVar12 + 4) = *(undefined8 *)(arg2 + 0x10);
        piVar1[1] = piVar1[1] + 0x18;
        goto code_r0x0001800f278f;
    }
    iVar8 = (int64_t)puVar12 - *piVar1;
    iVar8 = iVar8 / 6 + (iVar8 >> 0x3f);
    iVar8 = (iVar8 >> 2) - (iVar8 >> 0x3f);
    if (iVar8 == 0xaaaaaaaaaaaaaaa) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar14 = ((int64_t)(undefined4 *)piVar1[2] - *piVar1 >> 3) * -0x5555555555555555;
    uVar7 = 0xaaaaaaaaaaaaaaa - (uVar14 >> 1);
    if (uVar7 <= uVar14 && uVar14 - uVar7 != 0) {
code_r0x0001800f27aa:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar14 = uVar14 + (uVar14 >> 1);
    uVar7 = iVar8 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar14) {
        uVar9 = uVar14;
    }
    if (0xaaaaaaaaaaaaaaa < uVar9) goto code_r0x0001800f27aa;
    uVar14 = uVar9 * 0x18;
    if (uVar14 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800f26c2:
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        puVar10 = unaff_RDI + iVar8 * 6;
        *puVar10 = *(undefined4 *)arg2;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        *(undefined8 *)(puVar10 + 4) = *(undefined8 *)(arg2 + 0x10);
        puVar2 = (undefined4 *)*piVar1;
        if (puVar12 == (undefined4 *)piVar1[1]) {
            iVar8 = (int64_t)(undefined4 *)piVar1[1] - (int64_t)puVar2;
            puVar10 = unaff_RDI;
            puVar12 = puVar2;
        } else {
            func_0x000180498030(unaff_RDI, puVar2, (int64_t)puVar12 - (int64_t)puVar2);
            puVar10 = puVar10 + 6;
            iVar8 = piVar1[1] - (int64_t)puVar12;
        }
        func_0x000180498030(puVar10, puVar12, iVar8);
        iVar8 = *piVar1;
        if (iVar8 != 0) {
            iVar11 = iVar8;
            puVar13 = auStack_68;
            if ((0xfff < (uint64_t)((piVar1[2] - iVar8 >> 3) * 8)) &&
               (iVar11 = *(int64_t *)(iVar8 + -8), puVar13 = auStack_68, 0x1f < (iVar8 - iVar11) - 8U))
            goto code_r0x0001800f275f;
            goto code_r0x0001800f2769;
        }
    } else {
        if (uVar14 < 0x1000) {
            unaff_RDI = (undefined4 *)func_0x000180459890(uVar14);
            goto code_r0x0001800f26c2;
        }
        if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800f27aa;
        iVar11 = func_0x000180459890();
        if (iVar11 != 0) {
            unaff_RDI = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar11;
            goto code_r0x0001800f26c2;
        }
code_r0x0001800f275f:
        iVar11 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar13 = auStack_60;
code_r0x0001800f2769:
        *(undefined8 *)(puVar13 + -8) = 0x1800f2771;
        func_0x000180459c3c(iVar11);
    }
    *piVar1 = (int64_t)unaff_RDI;
    piVar1[1] = (int64_t)(unaff_RDI + uVar7 * 6);
    piVar1[2] = (int64_t)(unaff_RDI + uVar9 * 6);
code_r0x0001800f278f:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    return;
}

// ============================================================
// Function: FUN_1800f27d0
// Address: 0x1800f27d0
// Size: 518 bytes
// ============================================================
void fcn.1800f27d0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined4 *puVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    uint64_t uVar9;
    undefined4 *puVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined *puVar13;
    undefined4 *unaff_RDI;
    uint64_t uVar14;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    piVar1 = *(int64_t **)arg1;
    puVar12 = (undefined4 *)piVar1[1];
    if (puVar12 != (undefined4 *)piVar1[2]) {
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        *puVar12 = *(undefined4 *)arg2;
        puVar12[1] = uVar4;
        puVar12[2] = uVar5;
        puVar12[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar12[4] = *(undefined4 *)(arg2 + 0x10);
        puVar12[5] = uVar4;
        puVar12[6] = uVar5;
        puVar12[7] = uVar6;
        puVar12[8] = *(undefined4 *)(arg2 + 0x20);
        piVar1[1] = piVar1[1] + 0x24;
        goto code_r0x0001800f29b4;
    }
    iVar8 = (int64_t)puVar12 - *piVar1;
    iVar8 = iVar8 / 0x12 + (iVar8 >> 0x3f);
    iVar8 = (iVar8 >> 1) - (iVar8 >> 0x3f);
    if (iVar8 == 0x71c71c71c71c71c) {
        func_0x000180010010();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar14 = ((int64_t)(undefined4 *)piVar1[2] - *piVar1 >> 2) * -0x71c71c71c71c71c7;
    uVar7 = 0x71c71c71c71c71c - (uVar14 >> 1);
    if (uVar7 <= uVar14 && uVar14 - uVar7 != 0) {
code_r0x0001800f29d0:
        func_0x000180004720();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar14 = uVar14 + (uVar14 >> 1);
    uVar7 = iVar8 + 1;
    uVar9 = uVar7;
    if (uVar7 <= uVar14) {
        uVar9 = uVar14;
    }
    if (0x71c71c71c71c71c < uVar9) goto code_r0x0001800f29d0;
    uVar14 = uVar9 * 0x24;
    if (uVar14 == 0) {
        unaff_RDI = (undefined4 *)0x0;
code_r0x0001800f28e5:
        uVar4 = *(undefined4 *)(arg2 + 4);
        uVar5 = *(undefined4 *)(arg2 + 8);
        uVar6 = *(undefined4 *)(arg2 + 0xc);
        puVar10 = unaff_RDI + iVar8 * 9;
        *puVar10 = *(undefined4 *)arg2;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        uVar4 = *(undefined4 *)(arg2 + 0x14);
        uVar5 = *(undefined4 *)(arg2 + 0x18);
        uVar6 = *(undefined4 *)(arg2 + 0x1c);
        puVar10[4] = *(undefined4 *)(arg2 + 0x10);
        puVar10[5] = uVar4;
        puVar10[6] = uVar5;
        puVar10[7] = uVar6;
        puVar10[8] = *(undefined4 *)(arg2 + 0x20);
        puVar2 = (undefined4 *)*piVar1;
        if (puVar12 == (undefined4 *)piVar1[1]) {
            iVar8 = (int64_t)(undefined4 *)piVar1[1] - (int64_t)puVar2;
            puVar10 = unaff_RDI;
            puVar12 = puVar2;
        } else {
            func_0x000180498030(unaff_RDI, puVar2, (int64_t)puVar12 - (int64_t)puVar2);
            puVar10 = puVar10 + 9;
            iVar8 = piVar1[1] - (int64_t)puVar12;
        }
        func_0x000180498030(puVar10, puVar12, iVar8);
        iVar8 = *piVar1;
        if (iVar8 != 0) {
            iVar11 = iVar8;
            puVar13 = auStack_68;
            if ((0xfff < (uint64_t)((piVar1[2] - iVar8 >> 2) * 4)) &&
               (iVar11 = *(int64_t *)(iVar8 + -8), puVar13 = auStack_68, 0x1f < (iVar8 - iVar11) - 8U))
            goto code_r0x0001800f2984;
            goto code_r0x0001800f298e;
        }
    } else {
        if (uVar14 < 0x1000) {
            unaff_RDI = (undefined4 *)func_0x000180459890(uVar14);
            goto code_r0x0001800f28e5;
        }
        if (uVar14 + 0x27 <= uVar14) goto code_r0x0001800f29d0;
        iVar11 = func_0x000180459890();
        if (iVar11 != 0) {
            unaff_RDI = (undefined4 *)(iVar11 + 0x27U & 0xffffffffffffffe0);
            *(int64_t *)(unaff_RDI + -2) = iVar11;
            goto code_r0x0001800f28e5;
        }
code_r0x0001800f2984:
        iVar11 = 5;
        pcVar3 = (code *)swi(0x29);
        (*pcVar3)(5);
        puVar13 = auStack_60;
code_r0x0001800f298e:
        *(undefined8 *)(puVar13 + -8) = 0x1800f2996;
        func_0x000180459c3c(iVar11);
    }
    *piVar1 = (int64_t)unaff_RDI;
    piVar1[1] = (int64_t)(unaff_RDI + uVar7 * 9);
    piVar1[2] = (int64_t)(unaff_RDI + uVar9 * 9);
code_r0x0001800f29b4:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    return;
}

// ============================================================
// Function: FUN_1800f2a00
// Address: 0x1800f2a00
// Size: 406 bytes
// ============================================================
void fcn.1800f2a00(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    undefined4 *puVar2;
    uint64_t *puVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint64_t uVar8;
    undefined4 *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    uint64_t unaff_RDI;
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined auStack_68 [8];
    undefined auStack_60 [32];
    
    puVar3 = *(uint64_t **)arg1;
    puVar9 = (undefined4 *)puVar3[1];
    if (puVar9 != (undefined4 *)puVar3[2]) {
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        *puVar9 = *(undefined4 *)arg2;
        puVar9[1] = uVar5;
        puVar9[2] = uVar6;
        puVar9[3] = uVar7;
        puVar3[1] = puVar3[1] + 0x10;
        goto code_r0x0001800f2b74;
    }
    iVar14 = (int64_t)((int64_t)puVar9 - *puVar3) >> 4;
    if (iVar14 == 0xfffffffffffffff) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar12 = (int64_t)((int64_t)(undefined4 *)puVar3[2] - *puVar3) >> 4;
    if (0xfffffffffffffff - (uVar12 >> 1) < uVar12) {
code_r0x0001800f2b90:
        func_0x000180004720();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar1 = iVar14 + 1;
    uVar12 = uVar12 + (uVar12 >> 1);
    uVar11 = uVar1;
    if (uVar1 <= uVar12) {
        uVar11 = uVar12;
    }
    if (0xfffffffffffffff < uVar11) goto code_r0x0001800f2b90;
    uVar11 = uVar11 * 0x10;
    if (uVar11 == 0) {
        unaff_RDI = 0;
code_r0x0001800f2ad9:
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        puVar2 = (undefined4 *)(iVar14 * 0x10 + unaff_RDI);
        *puVar2 = *(undefined4 *)arg2;
        puVar2[1] = uVar5;
        puVar2[2] = uVar6;
        puVar2[3] = uVar7;
        puVar2 = (undefined4 *)*puVar3;
        if (puVar9 == (undefined4 *)puVar3[1]) {
            iVar13 = (int64_t)(undefined4 *)puVar3[1] - (int64_t)puVar2;
            uVar12 = unaff_RDI;
            puVar9 = puVar2;
        } else {
            func_0x000180498030(unaff_RDI, puVar2, (int64_t)puVar9 - (int64_t)puVar2);
            iVar13 = puVar3[1] - (int64_t)puVar9;
            uVar12 = iVar14 * 0x10 + 0x10 + unaff_RDI;
        }
        func_0x000180498030(uVar12, puVar9, iVar13);
        uVar12 = *puVar3;
        if (uVar12 != 0) {
            uVar8 = uVar12;
            puVar10 = auStack_68;
            if ((0xfff < (puVar3[2] - uVar12 & 0xfffffffffffffff0)) &&
               (uVar8 = *(uint64_t *)(uVar12 - 8), puVar10 = auStack_68, 0x1f < (uVar12 - uVar8) - 8))
            goto code_r0x0001800f2b4f;
            goto code_r0x0001800f2b59;
        }
    } else {
        if (uVar11 < 0x1000) {
            unaff_RDI = func_0x000180459890(uVar11);
            goto code_r0x0001800f2ad9;
        }
        if (uVar11 + 0x27 <= uVar11) goto code_r0x0001800f2b90;
        iVar13 = func_0x000180459890();
        if (iVar13 != 0) {
            unaff_RDI = iVar13 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(unaff_RDI - 8) = iVar13;
            goto code_r0x0001800f2ad9;
        }
code_r0x0001800f2b4f:
        pcVar4 = (code *)swi(0x29);
        uVar8 = (*pcVar4)(5);
        puVar10 = auStack_60;
code_r0x0001800f2b59:
        *(undefined8 *)(puVar10 + -8) = 0x1800f2b5e;
        func_0x000180459c3c(uVar8);
    }
    *puVar3 = unaff_RDI;
    puVar3[1] = uVar1 * 0x10 + unaff_RDI;
    puVar3[2] = uVar11 + unaff_RDI;
code_r0x0001800f2b74:
    *(int64_t *)(arg1 + 0x10) = *(int64_t *)(arg1 + 0x10) + 1;
    return;
}

// ============================================================
// Function: FUN_1800f2bb0
// Address: 0x1800f2bb0
// Size: 299 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800f2bb0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined4 *puVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    undefined4 *puVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar9 = auStack_58;
    puVar8 = (undefined4 *)0x0;
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    puVar1 = *(undefined4 **)(arg2 + 8);
    puVar12 = *(undefined4 **)arg2;
    iVar6 = (int64_t)puVar1 - (int64_t)puVar12 >> 4;
    if (iVar6 * -0x5555555555555555 != 0) {
        if (0x555555555555555 < (uint64_t)(iVar6 * -0x5555555555555555)) {
            func_0x000180010010();
            pcVar2 = (code *)swi(3);
            iVar6 = (*pcVar2)();
            return iVar6;
        }
        uVar11 = iVar6 * 0x10;
        puVar10 = auStack_58;
        if (uVar11 != 0) {
            if (uVar11 < 0x1000) {
                puVar8 = (undefined4 *)func_0x000180459890(uVar11);
                puVar10 = auStack_58;
            } else {
                if (uVar11 + 0x27 <= uVar11) {
                    func_0x000180004720();
                    pcVar2 = (code *)swi(3);
                    iVar6 = (*pcVar2)();
                    return iVar6;
                }
                iVar7 = func_0x000180459890();
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar9 = auStack_50;
                }
                puVar8 = (undefined4 *)(iVar7 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(puVar8 + -2) = iVar7;
                puVar10 = puVar9;
            }
        }
        *(undefined4 **)arg1 = puVar8;
        *(undefined4 **)(arg1 + 8) = puVar8;
        *(undefined4 **)(arg1 + 0x10) = puVar8 + iVar6 * 4;
        *(int64_t *)(puVar10 + 0x70) = arg1;
        *(undefined4 **)(puVar10 + 0x20) = puVar8;
        *(undefined4 **)(puVar10 + 0x28) = puVar8;
        *(int64_t *)(puVar10 + 0x30) = arg1;
        for (; puVar12 != puVar1; puVar12 = puVar12 + 0xc) {
            uVar3 = puVar12[1];
            uVar4 = puVar12[2];
            uVar5 = puVar12[3];
            *puVar8 = *puVar12;
            puVar8[1] = uVar3;
            puVar8[2] = uVar4;
            puVar8[3] = uVar5;
            *(undefined8 *)(puVar10 + -8) = 0x1800f2ca3;
            func_0x00018000b4d0(puVar8 + 4, puVar12 + 4);
            puVar8 = puVar8 + 0xc;
            *(undefined4 **)(puVar10 + 0x28) = puVar8;
        }
        *(undefined4 **)(arg1 + 8) = puVar8;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800f2ce0
// Address: 0x1800f2ce0
// Size: 129 bytes
// ============================================================
void fcn.1800f2ce0(int64_t arg1)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_28;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) / 0x18) * 0x18)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_28;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_20;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800f2d4e;
        func_0x000180459c3c(uVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f2d70
// Address: 0x1800f2d70
// Size: 122 bytes
// ============================================================
void fcn.1800f2d70(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar3 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 2) * 4;
        if (0xfff < uVar3) {
            puVar1 = (uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - *puVar1) - 8;
            if (uVar4 < 0x20) {
                uVar3 = uVar3 + 0x27;
                uVar4 = *puVar1;
                puVar5 = auStack_28;
            } else {
                pcVar2 = (code *)swi(0x29);
                uVar3 = (*pcVar2)(5);
                puVar5 = auStack_20;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800f2dd7;
        func_0x000180459c3c(uVar4, uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f2df0
// Address: 0x1800f2df0
// Size: 183 bytes
// ============================================================
void fcn.1800f2df0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    code *pcVar2;
    uint64_t uVar3;
    int32_t *piVar4;
    undefined *puVar5;
    uint64_t uVar6;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    piVar4 = *(int32_t **)arg1;
    if (piVar4 != (int32_t *)0x0) {
        piVar1 = *(int32_t **)(arg1 + 8);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 0x14) {
            (**(code **)((int64_t)*piVar4 * 8 + 0x180644200))(piVar4 + 2);
        }
        uVar6 = *(uint64_t *)arg1;
        uVar3 = uVar6;
        puVar5 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar6) / 0x50) * 0x50)) {
            uVar3 = *(uint64_t *)(uVar6 - 8);
            uVar6 = (uVar6 - uVar3) - 8;
            puVar5 = auStack_48;
            if (0x1f < uVar6) {
                pcVar2 = (code *)swi(0x29);
                uVar3 = uVar6;
                (*pcVar2)(5);
                puVar5 = auStack_40;
            }
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800f2e91;
        func_0x000180459c3c(uVar3);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f2eb0
// Address: 0x1800f2eb0
// Size: 492 bytes
// ============================================================
void fcn.1800f2eb0(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    uint64_t uVar11;
    int64_t var_8h;
    undefined auStack_98 [8];
    undefined auStack_90 [24];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar9 = auStack_98;
    puVar10 = auStack_98;
    puVar1 = *(undefined8 **)(arg1 + 8);
    if (puVar1 != *(undefined8 **)(arg1 + 0x10)) {
        *puVar1 = 0x1804a5358;
        *(undefined (*) [16])(puVar1 + 1) = ZEXT816(0);
        fcn.18045b4e4(arg2 + 8);
        *puVar1 = 0x180640168;
        uVar3 = *(undefined4 *)(arg2 + 0x1c);
        uVar4 = *(undefined4 *)(arg2 + 0x20);
        uVar5 = *(undefined4 *)(arg2 + 0x24);
        *(undefined4 *)(puVar1 + 3) = *(undefined4 *)(arg2 + 0x18);
        *(undefined4 *)((int64_t)puVar1 + 0x1c) = uVar3;
        *(undefined4 *)(puVar1 + 4) = uVar4;
        *(undefined4 *)((int64_t)puVar1 + 0x24) = uVar5;
        fcn.18000b4d0(puVar1 + 5, arg2 + 0x28);
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x48;
        return;
    }
    iVar8 = (int64_t)puVar1 - *(int64_t *)arg1;
    iVar8 = iVar8 / 0x12 + (iVar8 >> 0x3f);
    iVar8 = (iVar8 >> 2) - (iVar8 >> 0x3f);
    if (iVar8 == 0x38e38e38e38e38e) {
        fcn.180010010();
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    uVar11 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - *(int64_t *)arg1 >> 3) * -0x71c71c71c71c71c7;
    uVar6 = 0x38e38e38e38e38e - (uVar11 >> 1);
    if (uVar11 < uVar6 || uVar11 - uVar6 == 0) {
        uVar11 = uVar11 + (uVar11 >> 1);
        uVar6 = iVar8 + 1U;
        if (iVar8 + 1U <= uVar11) {
            uVar6 = uVar11;
        }
        if (uVar6 < 0x38e38e38e38e38f) {
            uVar11 = uVar6 * 0x48;
            if (uVar11 == 0) {
                uVar11 = 0;
                puVar10 = auStack_98;
            } else if (uVar11 < 0x1000) {
                uVar11 = fcn.180459890();
            } else {
                if (uVar11 + 0x27 <= uVar11) goto code_r0x0001800f3096;
                iVar7 = fcn.180459890(uVar11 + 0x27);
                if (iVar7 == 0) {
                    pcVar2 = (code *)swi(0x29);
                    iVar7 = (*pcVar2)(5);
                    puVar9 = auStack_90;
                }
                uVar11 = iVar7 + 0x27U & 0xffffffffffffffe0;
                *(int64_t *)(uVar11 - 8) = iVar7;
                puVar10 = puVar9;
            }
            iVar7 = uVar11 + iVar8 * 0x48;
            *(int64_t *)(puVar10 + 0x20) = arg1;
            *(uint64_t *)(puVar10 + 0x28) = uVar11;
            *(uint64_t *)(puVar10 + 0x30) = uVar6;
            *(int64_t *)(puVar10 + 0x38) = iVar7 + 0x48;
            *(int64_t *)(puVar10 + 0x40) = iVar7 + 0x48;
            *(undefined8 *)(puVar10 + -8) = 0x1800f3036;
            fcn.1800f35b0(iVar8 * 9, iVar7, arg2);
            *(int64_t *)(puVar10 + 0x38) = iVar7;
            if (puVar1 != *(undefined8 **)(arg1 + 8)) {
                *(undefined8 *)(puVar10 + -8) = 0x1800f3052;
                fcn.1800f3480(*(int64_t *)(puVar10 + 0x40));
                *(uint64_t *)(puVar10 + 0x38) = uVar11;
            }
            *(undefined8 *)(puVar10 + -8) = 0x1800f3066;
            fcn.1800f3480(*(int64_t *)(puVar10 + 0x40));
            *(undefined8 *)(puVar10 + 0x28) = 0;
            *(undefined8 *)(puVar10 + -8) = 0x1800f3080;
            fcn.1800f38a0(*(int64_t *)(puVar10 + 0x40));
            *(undefined8 *)(puVar10 + -8) = 0x1800f308b;
            fcn.1800f37f0(*(int64_t *)(puVar10 + 0x30));
            return;
        }
    }
code_r0x0001800f3096:
    fcn.180004720();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800f30a0
// Address: 0x1800f30a0
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800f30a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800f3223;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = fcn.180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800f3140:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = fcn.180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800f3140;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800f31df;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800f31df;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800f31df:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar6[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800f3223:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800f30d3
// Address: 0x1800f30d3
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800f30a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800f3223;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = fcn.180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800f3140:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = fcn.180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800f3140;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800f31df;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800f31df;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800f31df:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar6[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800f3223:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800f30dd
// Address: 0x1800f30dd
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800f30a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800f3223;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = fcn.180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800f3140:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = fcn.180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800f3140;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800f31df;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800f31df;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800f31df:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar6[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800f3223:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800f3180
// Address: 0x1800f3180
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800f30a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800f3223;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = fcn.180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800f3140:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = fcn.180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800f3140;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800f31df;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800f31df;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800f31df:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar6[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800f3223:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800f321e
// Address: 0x1800f321e
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.1800f30a0(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    uint64_t *puVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar3 = *(int64_t *)(arg1 + 8);
    if ((*(uint64_t *)(arg1 + 0x10) < (uint64_t)(iVar3 * 3) >> 2) || (iVar2 = func_0x0001800ac7f0(), iVar2 != 0))
    goto code_r0x0001800f3223;
    uVar1 = *(uint64_t *)(arg1 + 0x18);
    if (iVar3 == 0) {
        uVar7 = 0x10;
        iVar3 = fcn.180459890(0x100);
        uVar4 = 0;
        iVar2 = iVar3;
        uVar9 = 0x10;
code_r0x0001800f3140:
        do {
            uVar5 = uVar4 + 1;
            *(uint64_t *)(iVar2 + uVar4 * 0x10) = *(uint64_t *)(arg1 + 0x18);
            *(undefined8 *)(iVar2 + 8 + uVar4 * 0x10) = 0;
            uVar4 = uVar5;
        } while (uVar5 < uVar7);
    } else {
        uVar7 = iVar3 * 2;
        if (uVar7 == 0) {
            uVar9 = 0;
            iVar3 = 0;
        } else {
            iVar3 = fcn.180459890(iVar3 << 5);
            uVar4 = 0;
            iVar2 = iVar3;
            uVar9 = uVar7;
            if (uVar7 != 0) goto code_r0x0001800f3140;
        }
    }
    uVar7 = 0;
    if (*(int64_t *)(arg1 + 8) != 0) {
        do {
            uVar4 = *(uint64_t *)(*(int64_t *)arg1 + uVar7 * 0x10);
            if (uVar4 != *(uint64_t *)(arg1 + 0x18)) {
                uVar5 = (uVar4 >> 5 ^ uVar4) >> 4;
                uVar8 = 0;
                do {
                    uVar5 = uVar5 & uVar9 - 1;
                    puVar6 = (uint64_t *)(uVar5 * 0x10 + iVar3);
                    if (*puVar6 == uVar1) {
                        *puVar6 = uVar4;
                        goto code_r0x0001800f31df;
                    }
                    if (*puVar6 == uVar4) goto code_r0x0001800f31df;
                    uVar5 = uVar5 + 1 + uVar8;
                    uVar8 = uVar8 + 1;
                } while (uVar8 <= uVar9 - 1);
                puVar6 = (uint64_t *)0x0;
code_r0x0001800f31df:
                iVar2 = *(int64_t *)arg1;
                *puVar6 = *(uint64_t *)(iVar2 + uVar7 * 0x10);
                puVar6[1] = *(uint64_t *)(iVar2 + 8 + uVar7 * 0x10);
            }
            uVar7 = uVar7 + 1;
        } while (uVar7 < *(uint64_t *)(arg1 + 8));
    }
    iVar2 = *(int64_t *)arg1;
    *(int64_t *)arg1 = iVar3;
    *(uint64_t *)(arg1 + 8) = uVar9;
    if (iVar2 != 0) {
        func_0x0001800f4640();
    }
code_r0x0001800f3223:
    iVar3 = func_0x0001800c1340(arg1, arg2);
    return iVar3 + 8;
}

// ============================================================
// Function: FUN_1800f3240
// Address: 0x1800f3240
// Size: 27 bytes
// ============================================================
void fcn.1800f3240(int64_t arg1)
{
    (**(code **)((int64_t)*(int32_t *)arg1 * 8 + 0x180644200))(arg1 + 8);
    return;
}

// ============================================================
// Function: FUN_1800f3260
// Address: 0x1800f3260
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3260(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x000180004e40(iVar3 + 0x10);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800f32f4;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f3279
// Address: 0x1800f3279
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3260(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x000180004e40(iVar3 + 0x10);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800f32f4;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f32cb
// Address: 0x1800f32cb
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3260(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x000180004e40(iVar3 + 0x10);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x1800f32f4;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1800f3320
// Address: 0x1800f3320
// Size: 44 bytes
// ============================================================
int64_t fcn.1800f3320(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    undefined4 uStack_10;
    undefined4 uStack_c;
    
    var_18h._0_4_ = *(undefined4 *)arg3;
    var_18h._4_4_ = *(undefined4 *)(arg3 + 4);
    uStack_10 = *(undefined4 *)(arg3 + 8);
    uStack_c = *(undefined4 *)(arg3 + 0xc);
    (**(code **)(arg1 + 8))(arg2, &var_18h, arg4);
    return arg2;
}

// ============================================================
// Function: FUN_1800f3380
// Address: 0x1800f3380
// Size: 153 bytes
// ============================================================
void fcn.1800f3380(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 4) << 4)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x1800f33ee;
        func_0x000180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x30 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x30 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800f3480
// Address: 0x1800f3480
// Size: 26 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.1800f3480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            *(undefined8 *)arg3 = 0x1804a5358;
            *(undefined (*) [16])(arg3 + 8) = ZEXT816(0);
            fcn.18045b4e4(arg1 + 8);
            *(undefined8 *)arg3 = 0x180640168;
            uVar1 = *(undefined4 *)(arg1 + 0x1c);
            uVar2 = *(undefined4 *)(arg1 + 0x20);
            uVar3 = *(undefined4 *)(arg1 + 0x24);
            *(undefined4 *)(arg3 + 0x18) = *(undefined4 *)(arg1 + 0x18);
            *(undefined4 *)(arg3 + 0x1c) = uVar1;
            *(undefined4 *)(arg3 + 0x20) = uVar2;
            *(undefined4 *)(arg3 + 0x24) = uVar3;
            *(undefined (*) [16])(arg3 + 0x28) = ZEXT816(0);
            *(undefined8 *)(arg3 + 0x38) = 0;
            *(undefined8 *)(arg3 + 0x40) = 0;
            uVar1 = *(undefined4 *)(arg1 + 0x2c);
            uVar2 = *(undefined4 *)(arg1 + 0x30);
            uVar3 = *(undefined4 *)(arg1 + 0x34);
            *(undefined4 *)(arg3 + 0x28) = *(undefined4 *)(arg1 + 0x28);
            *(undefined4 *)(arg3 + 0x2c) = uVar1;
            *(undefined4 *)(arg3 + 0x30) = uVar2;
            *(undefined4 *)(arg3 + 0x34) = uVar3;
            uVar1 = *(undefined4 *)(arg1 + 0x3c);
            uVar2 = *(undefined4 *)(arg1 + 0x40);
            uVar3 = *(undefined4 *)(arg1 + 0x44);
            *(undefined4 *)(arg3 + 0x38) = *(undefined4 *)(arg1 + 0x38);
            *(undefined4 *)(arg3 + 0x3c) = uVar1;
            *(undefined4 *)(arg3 + 0x40) = uVar2;
            *(undefined4 *)(arg3 + 0x44) = uVar3;
            *(undefined *)(arg1 + 0x28) = 0;
            arg3 = arg3 + 0x48;
            *(undefined8 *)(arg1 + 0x38) = 0;
            *(undefined8 *)(arg1 + 0x40) = 0xf;
            arg1 = arg1 + 0x48;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_1800f349a
// Address: 0x1800f349a
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.1800f3480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            *(undefined8 *)arg3 = 0x1804a5358;
            *(undefined (*) [16])(arg3 + 8) = ZEXT816(0);
            fcn.18045b4e4(arg1 + 8);
            *(undefined8 *)arg3 = 0x180640168;
            uVar1 = *(undefined4 *)(arg1 + 0x1c);
            uVar2 = *(undefined4 *)(arg1 + 0x20);
            uVar3 = *(undefined4 *)(arg1 + 0x24);
            *(undefined4 *)(arg3 + 0x18) = *(undefined4 *)(arg1 + 0x18);
            *(undefined4 *)(arg3 + 0x1c) = uVar1;
            *(undefined4 *)(arg3 + 0x20) = uVar2;
            *(undefined4 *)(arg3 + 0x24) = uVar3;
            *(undefined (*) [16])(arg3 + 0x28) = ZEXT816(0);
            *(undefined8 *)(arg3 + 0x38) = 0;
            *(undefined8 *)(arg3 + 0x40) = 0;
            uVar1 = *(undefined4 *)(arg1 + 0x2c);
            uVar2 = *(undefined4 *)(arg1 + 0x30);
            uVar3 = *(undefined4 *)(arg1 + 0x34);
            *(undefined4 *)(arg3 + 0x28) = *(undefined4 *)(arg1 + 0x28);
            *(undefined4 *)(arg3 + 0x2c) = uVar1;
            *(undefined4 *)(arg3 + 0x30) = uVar2;
            *(undefined4 *)(arg3 + 0x34) = uVar3;
            uVar1 = *(undefined4 *)(arg1 + 0x3c);
            uVar2 = *(undefined4 *)(arg1 + 0x40);
            uVar3 = *(undefined4 *)(arg1 + 0x44);
            *(undefined4 *)(arg3 + 0x38) = *(undefined4 *)(arg1 + 0x38);
            *(undefined4 *)(arg3 + 0x3c) = uVar1;
            *(undefined4 *)(arg3 + 0x40) = uVar2;
            *(undefined4 *)(arg3 + 0x44) = uVar3;
            *(undefined *)(arg1 + 0x28) = 0;
            arg3 = arg3 + 0x48;
            *(undefined8 *)(arg1 + 0x38) = 0;
            *(undefined8 *)(arg1 + 0x40) = 0xf;
            arg1 = arg1 + 0x48;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_1800f352c
// Address: 0x1800f352c
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 * fcn.1800f3480(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_48h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        do {
            *(undefined8 *)arg3 = 0x1804a5358;
            *(undefined (*) [16])(arg3 + 8) = ZEXT816(0);
            fcn.18045b4e4(arg1 + 8);
            *(undefined8 *)arg3 = 0x180640168;
            uVar1 = *(undefined4 *)(arg1 + 0x1c);
            uVar2 = *(undefined4 *)(arg1 + 0x20);
            uVar3 = *(undefined4 *)(arg1 + 0x24);
            *(undefined4 *)(arg3 + 0x18) = *(undefined4 *)(arg1 + 0x18);
            *(undefined4 *)(arg3 + 0x1c) = uVar1;
            *(undefined4 *)(arg3 + 0x20) = uVar2;
            *(undefined4 *)(arg3 + 0x24) = uVar3;
            *(undefined (*) [16])(arg3 + 0x28) = ZEXT816(0);
            *(undefined8 *)(arg3 + 0x38) = 0;
            *(undefined8 *)(arg3 + 0x40) = 0;
            uVar1 = *(undefined4 *)(arg1 + 0x2c);
            uVar2 = *(undefined4 *)(arg1 + 0x30);
            uVar3 = *(undefined4 *)(arg1 + 0x34);
            *(undefined4 *)(arg3 + 0x28) = *(undefined4 *)(arg1 + 0x28);
            *(undefined4 *)(arg3 + 0x2c) = uVar1;
            *(undefined4 *)(arg3 + 0x30) = uVar2;
            *(undefined4 *)(arg3 + 0x34) = uVar3;
            uVar1 = *(undefined4 *)(arg1 + 0x3c);
            uVar2 = *(undefined4 *)(arg1 + 0x40);
            uVar3 = *(undefined4 *)(arg1 + 0x44);
            *(undefined4 *)(arg3 + 0x38) = *(undefined4 *)(arg1 + 0x38);
            *(undefined4 *)(arg3 + 0x3c) = uVar1;
            *(undefined4 *)(arg3 + 0x40) = uVar2;
            *(undefined4 *)(arg3 + 0x44) = uVar3;
            *(undefined *)(arg1 + 0x28) = 0;
            arg3 = arg3 + 0x48;
            *(undefined8 *)(arg1 + 0x38) = 0;
            *(undefined8 *)(arg1 + 0x40) = 0xf;
            arg1 = arg1 + 0x48;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_1800f35b0
// Address: 0x1800f35b0
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f35b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg2 = 0x1804a5358;
    *(undefined (*) [16])(arg2 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg3 + 8);
    *(undefined8 *)arg2 = 0x180640168;
    uVar1 = *(undefined4 *)(arg3 + 0x1c);
    uVar2 = *(undefined4 *)(arg3 + 0x20);
    uVar3 = *(undefined4 *)(arg3 + 0x24);
    *(undefined4 *)(arg2 + 0x18) = *(undefined4 *)(arg3 + 0x18);
    *(undefined4 *)(arg2 + 0x1c) = uVar1;
    *(undefined4 *)(arg2 + 0x20) = uVar2;
    *(undefined4 *)(arg2 + 0x24) = uVar3;
    fcn.18000b4d0(arg2 + 0x28, arg3 + 0x28);
    return;
}

// ============================================================
// Function: FUN_1800f3620
// Address: 0x1800f3620
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3620(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    for (arg1 = *(int64_t *)arg1; arg1 != iVar1; arg1 = arg1 + 0x30) {
        func_0x000180004e40(arg1 + 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_1800f3660
// Address: 0x1800f3660
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.1800f3660(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 *in_RAX;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar1; iVar6 = iVar6 + 0x30) {
        func_0x000180004e40(iVar6 + 0x10);
    }
    puVar5 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x30)) {
        puVar4 = *(undefined4 **)(puVar5 + -2);
        if ((uint64_t)((int64_t)puVar5 + (-8 - (int64_t)puVar4)) < 0x20) goto code_r0x0001800f4640;
        puVar5 = (undefined4 *)0x5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    puVar4 = puVar5;
code_r0x0001800f4640:
    if (puVar4 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar4 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar4);
        if ((int32_t)puVar4 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)func_0x00018046b77c();
            *puVar4 = uVar3;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800f3674
// Address: 0x1800f3674
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.1800f3660(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 *in_RAX;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar1; iVar6 = iVar6 + 0x30) {
        func_0x000180004e40(iVar6 + 0x10);
    }
    puVar5 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x30)) {
        puVar4 = *(undefined4 **)(puVar5 + -2);
        if ((uint64_t)((int64_t)puVar5 + (-8 - (int64_t)puVar4)) < 0x20) goto code_r0x0001800f4640;
        puVar5 = (undefined4 *)0x5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    puVar4 = puVar5;
code_r0x0001800f4640:
    if (puVar4 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar4 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar4);
        if ((int32_t)puVar4 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)func_0x00018046b77c();
            *puVar4 = uVar3;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800f36c5
// Address: 0x1800f36c5
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined4 * fcn.1800f3660(int64_t arg1, int64_t arg_38h)
{
    int64_t iVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 *in_RAX;
    undefined4 *puVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return in_RAX;
    }
    iVar1 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar1; iVar6 = iVar6 + 0x30) {
        func_0x000180004e40(iVar6 + 0x10);
    }
    puVar5 = *(undefined4 **)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x30)) {
        puVar4 = *(undefined4 **)(puVar5 + -2);
        if ((uint64_t)((int64_t)puVar5 + (-8 - (int64_t)puVar4)) < 0x20) goto code_r0x0001800f4640;
        puVar5 = (undefined4 *)0x5;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)();
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    puVar4 = puVar5;
code_r0x0001800f4640:
    if (puVar4 != (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        puVar4 = (undefined4 *)(*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, puVar4);
        if ((int32_t)puVar4 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = func_0x00018046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)func_0x00018046b77c();
            *puVar4 = uVar3;
        }
    }
    return puVar4;
}

// ============================================================
// Function: FUN_1800f3710
// Address: 0x1800f3710
// Size: 39 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3710(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x000180004e40(iVar3 + 0x10);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x1800f37b2;
        func_0x000180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x30 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x30 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800f3737
// Address: 0x1800f3737
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3710(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x000180004e40(iVar3 + 0x10);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x1800f37b2;
        func_0x000180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x30 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x30 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800f3789
// Address: 0x1800f3789
// Size: 94 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f3710(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x30) {
            func_0x000180004e40(iVar3 + 0x10);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        piVar4 = &var_38h;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 4) << 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), piVar4 = &var_38h, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            piVar4 = (int64_t *)auStack_30;
        }
        *(undefined8 *)((int64_t)piVar4 + -8) = 0x1800f37b2;
        func_0x000180459c3c(iVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg3 * 0x30 + arg2;
    *(int64_t *)(arg1 + 0x10) = arg4 * 0x30 + arg2;
    return;
}

// ============================================================
// Function: FUN_1800f37f0
// Address: 0x1800f37f0
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f37f0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 *puVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    puVar1 = *(undefined8 **)(arg1 + 0x20);
    for (puVar8 = *(undefined8 **)(arg1 + 0x18); puVar8 != puVar1; puVar8 = puVar8 + 9) {
        (**(code **)*puVar8)(puVar8, 0);
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x48)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar9 = auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = func_0x00018046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f3804
// Address: 0x1800f3804
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f37f0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 *puVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    puVar1 = *(undefined8 **)(arg1 + 0x20);
    for (puVar8 = *(undefined8 **)(arg1 + 0x18); puVar8 != puVar1; puVar8 = puVar8 + 9) {
        (**(code **)*puVar8)(puVar8, 0);
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x48)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar9 = auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = func_0x00018046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f385a
// Address: 0x1800f385a
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800f37f0(int64_t arg1, int64_t arg_38h)
{
    undefined8 *puVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    uint64_t uVar6;
    uint64_t uVar7;
    undefined8 unaff_RBX;
    undefined8 *puVar8;
    undefined *puVar9;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar9 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    puVar1 = *(undefined8 **)(arg1 + 0x20);
    for (puVar8 = *(undefined8 **)(arg1 + 0x18); puVar8 != puVar1; puVar8 = puVar8 + 9) {
        (**(code **)*puVar8)(puVar8, 0);
    }
    uVar7 = *(uint64_t *)(arg1 + 8);
    uVar6 = uVar7;
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x48)) {
        uVar6 = *(uint64_t *)(uVar7 - 8);
        uVar7 = (uVar7 - uVar6) - 8;
        if (uVar7 < 0x20) goto code_r0x0001800f4640;
        pcVar2 = (code *)swi(0x29);
        (*pcVar2)(5);
        puVar9 = auStack_20;
        uVar6 = uVar7;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar9 + 0x28);
code_r0x0001800f4640:
    if (uVar6 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, uVar6);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar4 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar4 = func_0x00018046b63c(uVar4);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar5 = (undefined4 *)func_0x00018046b77c();
            *puVar5 = uVar4;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f38a0
// Address: 0x1800f38a0
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f38a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)arg1;
    if (puVar5 != (undefined8 *)0x0) {
        puVar1 = *(undefined8 **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 9) {
            (**(code **)*puVar5)(puVar5, 0);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_38, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_30;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800f3952;
        func_0x000180459c3c(iVar4);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 0x48;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 0x48;
    return;
}

// ============================================================
// Function: FUN_1800f38cc
// Address: 0x1800f38cc
// Size: 93 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f38a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)arg1;
    if (puVar5 != (undefined8 *)0x0) {
        puVar1 = *(undefined8 **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 9) {
            (**(code **)*puVar5)(puVar5, 0);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_38, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_30;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800f3952;
        func_0x000180459c3c(iVar4);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 0x48;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 0x48;
    return;
}

// ============================================================
// Function: FUN_1800f3929
// Address: 0x1800f3929
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800f38a0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h)
{
    undefined8 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined *puVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar5 = *(undefined8 **)arg1;
    if (puVar5 != (undefined8 *)0x0) {
        puVar1 = *(undefined8 **)(arg1 + 8);
        for (; puVar5 != puVar1; puVar5 = puVar5 + 9) {
            (**(code **)*puVar5)(puVar5, 0);
        }
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar6 = auStack_38;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar2 >> 3) * 8)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_38, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_30;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800f3952;
        func_0x000180459c3c(iVar4);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 0x48;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 0x48;
    return;
}

// ============================================================
// Function: FUN_1800f3990
// Address: 0x1800f3990
// Size: 145 bytes
// ============================================================
void fcn.1800f3990(int64_t arg1)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int32_t *piVar5;
    undefined *puVar6;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    if (*(int64_t *)(arg1 + 8) != 0) {
        piVar1 = *(int32_t **)(arg1 + 0x20);
        for (piVar5 = *(int32_t **)(arg1 + 0x18); piVar5 != piVar1; piVar5 = piVar5 + 0x14) {
            (**(code **)((int64_t)*piVar5 * 8 + 0x180644200))(piVar5 + 2);
        }
        iVar2 = *(int64_t *)(arg1 + 8);
        iVar4 = iVar2;
        puVar6 = auStack_48;
        if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x50)) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar6 = auStack_48, 0x1f < (iVar2 - iVar4) - 8U)) {
            iVar4 = 5;
            pcVar3 = (code *)swi(0x29);
            (*pcVar3)(5);
            puVar6 = auStack_40;
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800f3a17;
        func_0x000180459c3c(iVar4);
    }
    return;
}

