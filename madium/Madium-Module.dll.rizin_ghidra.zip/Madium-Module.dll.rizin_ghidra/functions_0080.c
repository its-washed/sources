// Chunk 80 - 50 functions

// ============================================================
// Function: FUN_18010df49
// Address: 0x18010df49
// Size: 95 bytes
// ============================================================
void fcn.18010df49(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int16_t *piVar1;
    int32_t iVar2;
    int64_t unaff_RDI;
    uint32_t uVar3;
    int64_t in_R10;
    int64_t var_10h;
    uint64_t uVar4;
    
    iVar2 = (int32_t)unaff_RDI + -1;
    uVar3 = (uint32_t)arg4;
    uVar4 = arg4;
    while ((int32_t)uVar3 < iVar2) {
        arg4 = arg4 + 1;
        uVar3 = (int32_t)uVar4 + 1;
        uVar4 = (uint64_t)uVar3;
        *(undefined8 *)(*(int64_t *)(arg3 + 0x1598) + -8 + arg4 * 8) =
             *(undefined8 *)(*(int64_t *)(arg3 + 0x1598) + arg4 * 8);
        piVar1 = (int16_t *)(*(int64_t *)(*(int64_t *)(arg3 + 0x1598) + -8 + arg4 * 8) + 0x120);
        *piVar1 = *piVar1 + -1;
    }
    *(int64_t *)(*(int64_t *)(arg3 + 0x1598) + -8 + unaff_RDI * 8) = in_R10;
    *(int16_t *)(in_R10 + 0x120) = (int16_t)iVar2;
    return;
}

// ============================================================
// Function: FUN_18010dfa8
// Address: 0x18010dfa8
// Size: 2 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18010df49(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int16_t *piVar1;
    int32_t iVar2;
    int64_t unaff_RDI;
    uint32_t uVar3;
    int64_t in_R10;
    int64_t var_10h;
    uint64_t uVar4;
    
    iVar2 = (int32_t)unaff_RDI + -1;
    uVar3 = (uint32_t)arg4;
    uVar4 = arg4;
    while ((int32_t)uVar3 < iVar2) {
        arg4 = arg4 + 1;
        uVar3 = (int32_t)uVar4 + 1;
        uVar4 = (uint64_t)uVar3;
        *(undefined8 *)(*(int64_t *)(arg3 + 0x1598) + -8 + arg4 * 8) =
             *(undefined8 *)(*(int64_t *)(arg3 + 0x1598) + arg4 * 8);
        piVar1 = (int16_t *)(*(int64_t *)(*(int64_t *)(arg3 + 0x1598) + -8 + arg4 * 8) + 0x120);
        *piVar1 = *piVar1 + -1;
    }
    *(int64_t *)(*(int64_t *)(arg3 + 0x1598) + -8 + unaff_RDI * 8) = in_R10;
    *(int16_t *)(in_R10 + 0x120) = (int16_t)iVar2;
    return;
}

// ============================================================
// Function: FUN_18010dfb0
// Address: 0x18010dfb0
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010dfb0(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int64_t var_8h;
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar1 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x1588);
    iVar3 = *(int64_t *)(iVar2 + -8 + (int64_t)iVar1 * 8);
    if (((iVar3 != arg1) && (*(int64_t *)(iVar3 + 0x428) != arg1)) && (uVar5 = iVar1 - 2, -1 < (int32_t)uVar5)) {
        while (*(int64_t *)((uint64_t)uVar5 * 8 + iVar2) != arg1) {
            uVar5 = uVar5 - 1;
            if ((int32_t)uVar5 < 0) {
                return;
            }
        }
        fcn.180498030(iVar2 + (uint64_t)uVar5 * 8, iVar2 + (int64_t)(int32_t)(uVar5 + 1) * 8, 
                      (int64_t)(int32_t)(~uVar5 + iVar1) << 3);
        *(int64_t *)(*(int64_t *)(iVar4 + 0x1588) + -8 + (int64_t)*(int32_t *)(iVar4 + 0x1580) * 8) = arg1;
    }
    return;
}

// ============================================================
// Function: FUN_18010e050
// Address: 0x18010e050
// Size: 809 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018010e2cf: Changing call to branch

void fcn.18010e050(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined4 uVar6;
    int64_t iVar7;
    int64_t unaff_RBX;
    int64_t iVar8;
    int32_t iVar9;
    undefined8 unaff_RDI;
    int64_t *piVar10;
    uint32_t uVar11;
    uint64_t uVar12;
    int32_t iVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t var_8h;
    int64_t var_14h;
    undefined8 auStack_50 [6];
    
    iVar4 = *(int64_t *)0x180781f28;
    iVar7 = arg2;
    if ((((arg2 & 2U) != 0) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != arg1)) &&
       (0 < *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120))) {
        iVar7 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128);
        arg3 = (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) * 0x38 + iVar7;
        for (; iVar7 != arg3; iVar7 = iVar7 + 0x38) {
            iVar8 = *(int64_t *)(iVar7 + 8);
            if (((iVar8 != 0) && ((*(uint32_t *)(iVar8 + 0x14) & 0x8000000) != 0)) &&
               ((*(char *)(iVar8 + 0x109) != '\0' || (*(char *)(iVar8 + 0x10a) != '\0')))) {
                if (arg1 == 0) goto code_r0x00018010e286;
                iVar5 = arg1;
                if (*(int64_t *)(arg1 + 0x418) != iVar8) {
                    while (iVar5 != iVar8) {
                        piVar1 = (int64_t *)(iVar5 + 0x410);
                        iVar5 = *piVar1;
                        if (*piVar1 == 0) {
                            iVar7 = *(int64_t *)(arg1 + 0x418);
                            if ((arg1 == iVar7) && ((*(uint32_t *)(arg1 + 0x14) & 0x2000) == 0)) {
                                piVar1 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x1588);
                                for (piVar15 = piVar1;
                                    (piVar15 < piVar1 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580) &&
                                    (*piVar15 != iVar7)); piVar15 = piVar15 + 1) {
                                }
                                for (piVar10 = piVar1;
                                    (piVar10 < piVar1 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x1580) &&
                                    (*piVar10 != *(int64_t *)(iVar8 + 0x418))); piVar10 = piVar10 + 1) {
                                }
                                iVar9 = (int32_t)((int64_t)piVar10 - (int64_t)piVar1 >> 3);
                                iVar13 = (int32_t)((int64_t)piVar15 - (int64_t)piVar1 >> 3);
                                if (iVar9 <= iVar13) {
                                    auStack_50[0] = 0x18010e27b;
                                    fcn.180498030(piVar1 + (iVar9 + 1), piVar1 + iVar9, (int64_t)(iVar13 - iVar9) << 3);
                                    *(int64_t *)((int64_t)iVar9 * 8 + *(int64_t *)(iVar4 + 0x1588)) = iVar7;
                                    goto code_r0x00018010e286;
                                }
                                auStack_50[0] = 0x18010e1a6;
                                fcn.180498030(piVar1 + iVar13, piVar1 + (iVar13 + 1), 
                                              (int64_t)((iVar9 - iVar13) + -1) << 3);
                                *(int64_t *)(*(int64_t *)(iVar4 + 0x1588) + -8 + (int64_t)iVar9 * 8) = iVar7;
                                auStack_50[0] = 0x18010e1ba;
                                arg1 = func_0x00018010cfa0();
                                goto code_r0x00018010d210;
                            }
                            goto code_r0x00018010e286;
                        }
                    }
                }
            }
        }
    }
    if (((arg2 & 1U) != 0) && (arg1 != 0)) {
        auStack_50[0] = 0x18010e1ec;
        arg1 = func_0x00018010ecf0(arg1, iVar7, arg3);
    }
    if (*(int64_t *)(iVar4 + 0x21d8) == arg1) {
        if (arg1 == 0) {
            iVar7 = 0;
            iVar8 = 0;
            iVar5 = 0;
        } else {
            iVar7 = *(int64_t *)(arg1 + 0x418);
            iVar8 = *(int64_t *)(arg1 + 0x428);
            iVar5 = *(int64_t *)(arg1 + 0x4c0);
        }
        iVar2 = *(int64_t *)(iVar4 + 0x1678);
        if (((iVar2 == 0) || (iVar5 == 0)) || (*(int64_t *)(iVar5 + 0x98) != iVar2)) {
            bVar3 = false;
        } else {
            bVar3 = true;
        }
        if (((*(int32_t *)(iVar4 + 0x1654) != 0) && (iVar2 != 0)) &&
           ((*(int64_t *)(iVar2 + 0x418) != iVar7 && ((*(char *)(iVar4 + 0x1662) == '\0' && (!bVar3)))))) {
            auStack_50[0] = 0x18010e343;
            func_0x0001800f9f30(0, 0);
        }
        if (arg1 != 0) {
            *(undefined4 *)(arg1 + 0x2e4) = *(undefined4 *)(iVar4 + 4);
            auStack_50[0] = 0x18010e359;
            func_0x00018010df20(iVar7);
            if (((*(uint32_t *)(iVar8 + 0x14) | *(uint32_t *)(iVar7 + 0x14) | *(uint32_t *)(arg1 + 0x14)) >> 0xd & 1) ==
                0) {
                auStack_50[0] = 0x18010e370;
                fcn.18010dfb0(iVar8);
            }
        }
        return;
    }
    *(int64_t *)(iVar4 + 0x21d8) = arg1;
    *(undefined8 *)(iVar4 + 0x2230) = 0xffffffffffffffff;
    *(undefined2 *)(iVar4 + 0x2278) = 0;
    *(undefined2 *)(iVar4 + 0x2239) = 0;
    if (arg1 == 0) {
        *(undefined4 *)(iVar4 + 0x21d0) = 0;
        uVar6 = 0;
        *(undefined4 *)(iVar4 + 0x21e4) = 0;
    } else {
        if (*(char *)(iVar4 + 0x21cd) != '\0') {
            *(undefined *)(iVar4 + 0x21ce) = 1;
        }
        *(undefined4 *)(iVar4 + 0x21d0) = *(undefined4 *)(arg1 + 0x450);
        *(undefined4 *)(iVar4 + 0x21e4) = 0;
        uVar6 = *(undefined4 *)(arg1 + 0x488);
    }
    auStack_50[0] = 0x18010e2b8;
    func_0x000180106840(uVar6);
    *(undefined *)(iVar4 + 0x21cf) = 0;
    *(undefined8 *)(iVar4 + 0x2230) = 0xffffffffffffffff;
    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_50;
    auStack_50[0] = 0x18010e2d4;
    unaff_RBX = arg1;
code_r0x00018010d210:
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RDI;
    iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120);
    if (iVar9 != 0) {
        uVar14 = 0;
        *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = unaff_RBX;
        if ((arg1 != 0) && (0 < iVar9)) {
            do {
                uVar12 = uVar14;
                if (*(int64_t *)(uVar14 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128)) != 0) {
                    do {
                        iVar7 = *(int64_t *)
                                 ((int64_t)(int32_t)uVar12 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
                        if (iVar7 != 0) {
                            iVar4 = arg1;
                            if (*(int64_t *)(arg1 + 0x418) == iVar7) break;
                            do {
                                if (iVar4 == iVar7) goto code_r0x00018010d2ab;
                                iVar4 = *(int64_t *)(iVar4 + 0x410);
                            } while (iVar4 != 0);
                        }
                        uVar11 = (int32_t)uVar12 + 1;
                        uVar12 = (uint64_t)uVar11;
                        if (iVar9 <= (int32_t)uVar11) goto code_r0x00018010d2b8;
                    } while( true );
                }
code_r0x00018010d2ab:
                uVar11 = (int32_t)uVar14 + 1;
                uVar14 = (uint64_t)uVar11;
            } while ((int32_t)uVar11 < iVar9);
        }
        if ((int32_t)uVar14 < iVar9) {
code_r0x00018010d2b8:
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18010d2c4;
            func_0x00018010d2d0(uVar14, 0);
        }
    }
    return;
code_r0x00018010e286:
    auStack_50[0] = 0x18010e28b;
    arg1 = func_0x00018010cfa0();
    goto code_r0x00018010d210;
}

// ============================================================
// Function: FUN_18010e3f0
// Address: 0x18010e3f0
// Size: 163 bytes
// ============================================================
void fcn.18010e3f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t unaff_RSI;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar7 = (int32_t)arg2;
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0) = (int32_t)arg1;
    *(int32_t *)(iVar5 + 0x21e4) = iVar7;
    fcn.180106840(unaff_RSI);
    iVar6 = *(int64_t *)0x180781f28;
    *(int32_t *)(*(int64_t *)(iVar5 + 0x21d8) + 0x450 + (int64_t)iVar7 * 4) = (int32_t)arg1;
    uVar2 = *(undefined4 *)(arg4 + 4);
    uVar3 = *(undefined4 *)(arg4 + 8);
    uVar4 = *(undefined4 *)(arg4 + 0xc);
    puVar1 = (undefined4 *)(*(int64_t *)(iVar5 + 0x21d8) + 0x458 + (int64_t)iVar7 * 0x10);
    *puVar1 = *(undefined4 *)arg4;
    puVar1[1] = uVar2;
    puVar1[2] = uVar3;
    puVar1[3] = uVar4;
    *(undefined4 *)
     (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x438) + 0x478 + (int64_t)*(int32_t *)(iVar6 + 0x21e4) * 8) =
         0x7f7fffff;
    *(undefined4 *)
     (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x438) + 0x47c + (int64_t)*(int32_t *)(iVar6 + 0x21e4) * 8) =
         0x7f7fffff;
    return;
}

// ============================================================
// Function: FUN_18010e4a0
// Address: 0x18010e4a0
// Size: 372 bytes
// ============================================================
void fcn.18010e4a0(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    int64_t iVar6;
    undefined4 uVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t unaff_RSI;
    
    iVar6 = *(int64_t *)0x180781f28;
    if (*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != arg2) {
        *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) = arg2;
        *(undefined8 *)(iVar6 + 0x2230) = 0xffffffffffffffff;
        *(undefined2 *)(iVar6 + 0x2278) = 0;
        *(undefined2 *)(iVar6 + 0x2239) = 0;
    }
    iVar8 = (int64_t)*(int32_t *)(arg2 + 0x1b0);
    *(int32_t *)(iVar6 + 0x21e4) = *(int32_t *)(arg2 + 0x1b0);
    iVar9 = (int32_t)arg1;
    *(int32_t *)(iVar6 + 0x21d0) = iVar9;
    fcn.180106840(unaff_RSI);
    *(int32_t *)(arg2 + 0x450 + iVar8 * 4) = iVar9;
    if (*(int32_t *)(iVar6 + 0x1fb8) == iVar9) {
        fVar1 = *(float *)(arg2 + 0x16c);
        fVar2 = *(float *)(arg2 + 0x168);
        fVar3 = *(float *)(iVar6 + 0x1fd8);
        fVar4 = *(float *)(iVar6 + 0x1fe0);
        fVar5 = *(float *)(iVar6 + 0x1fdc);
        *(float *)(arg2 + 0x458 + iVar8 * 0x10) = *(float *)(iVar6 + 0x1fd4) - fVar2;
        *(float *)(arg2 + 0x45c + iVar8 * 0x10) = fVar3 - fVar1;
        *(float *)(arg2 + 0x460 + iVar8 * 0x10) = fVar5 - fVar2;
        *(float *)(arg2 + 0x464 + iVar8 * 0x10) = fVar4 - fVar1;
        if (*(int32_t *)(iVar6 + 0x1fb8) == iVar9) {
            uVar7 = *(undefined4 *)(iVar6 + 0x1fbc);
            goto code_r0x00018010e58b;
        }
    }
    uVar7 = 0;
code_r0x00018010e58b:
    *(undefined4 *)(iVar6 + 0x21e8) = uVar7;
    if (iVar9 == *(int32_t *)(iVar6 + 0x1658)) {
        *(undefined *)(iVar6 + 0x21cf) = 1;
    }
    if (*(int32_t *)(iVar6 + 0x1674) - 2U < 2) {
        *(undefined *)(iVar6 + 0x21cd) = 1;
    } else if (*(char *)(iVar6 + 0x7e) != '\0') {
        *(undefined *)(iVar6 + 0x21cc) = 0;
    }
    iVar6 = *(int64_t *)0x180781f28;
    *(undefined4 *)
     (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x438) + 0x478 +
     (int64_t)*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) * 8) = 0x7f7fffff;
    *(undefined4 *)
     (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x438) + 0x47c + (int64_t)*(int32_t *)(iVar6 + 0x21e4) * 8) =
         0x7f7fffff;
    return;
}

// ============================================================
// Function: FUN_18010e620
// Address: 0x18010e620
// Size: 264 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e728
// Address: 0x18010e728
// Size: 9 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e731
// Address: 0x18010e731
// Size: 27 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e74c
// Address: 0x18010e74c
// Size: 362 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e8b6
// Address: 0x18010e8b6
// Size: 144 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e946
// Address: 0x18010e946
// Size: 32 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e966
// Address: 0x18010e966
// Size: 30 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010e984
// Address: 0x18010e984
// Size: 199 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010ea4b
// Address: 0x18010ea4b
// Size: 7 bytes
// ============================================================
uint64_t fcn.18010e620(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    uint32_t uVar5;
    uint8_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    uVar4 = (uint64_t)*(uint32_t *)(iVar2 + 0x1b0);
    if (*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4) != *(uint32_t *)(iVar2 + 0x1b0)) {
code_r0x00018010ea4b:
        return uVar4 & 0xffffffffffffff00;
    }
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) = *(int32_t *)(*(int64_t *)0x180781f28 + 0x22b4) + 1;
    uVar4 = *(uint64_t *)(iVar3 + 0x21d8);
    fVar10 = *(float *)arg2;
    fVar7 = *(float *)(arg2 + 4);
    fVar12 = *(float *)(arg2 + 8);
    fVar8 = *(float *)(arg2 + 0xc);
    fVar9 = fVar10;
    fVar11 = fVar7;
    fVar14 = fVar12;
    fVar15 = fVar8;
    if (*(uint64_t *)(iVar2 + 0x408) == uVar4) {
        fVar13 = *(float *)(iVar2 + 0x2c4);
        if ((((fVar13 <= fVar7) || (fVar15 = *(float *)(iVar2 + 700), fVar8 <= fVar15)) ||
            (fVar16 = *(float *)(iVar2 + 0x2c0), fVar16 <= fVar10)) ||
           (fVar14 = *(float *)(iVar2 + 0x2b8), fVar12 <= fVar14)) goto code_r0x00018010ea4b;
        fVar11 = fVar15;
        if ((fVar15 <= fVar7) && (fVar11 = fVar13, fVar7 <= fVar13)) {
            fVar11 = fVar7;
        }
        fVar9 = fVar14;
        if ((fVar14 <= fVar10) && (fVar9 = fVar16, fVar10 <= fVar16)) {
            fVar9 = fVar10;
        }
        if ((fVar15 <= fVar8) && (fVar15 = fVar13, fVar8 <= fVar13)) {
            fVar15 = fVar8;
        }
        if ((fVar14 <= fVar12) && (fVar14 = fVar16, fVar12 <= fVar16)) {
            fVar14 = fVar12;
        }
    }
    fVar10 = *(float *)(iVar3 + 0x229c);
    fVar7 = *(float *)(iVar3 + 0x2294);
    fVar12 = *(float *)(iVar3 + 0x2298);
    if (fVar7 <= fVar14) {
        if (fVar9 <= fVar10) {
            fVar8 = 0.0;
        } else {
            fVar8 = fVar9 - fVar10;
        }
    } else {
        fVar8 = fVar14 - fVar7;
    }
    fVar17 = *(float *)(iVar3 + 0x22a0) - fVar12;
    fVar16 = (fVar15 - fVar11) * 0.2 + fVar11;
    fVar13 = (fVar15 - fVar11) * 0.8 + fVar11;
    fVar18 = fVar17 * 0.2 + fVar12;
    fVar17 = fVar17 * 0.8 + fVar12;
    if (fVar18 <= fVar13) {
        if (fVar17 < fVar16) {
            fVar13 = fVar16 - fVar17;
            goto code_r0x00018010e807;
        }
        fVar13 = 0.0;
    } else {
        fVar13 = fVar13 - fVar18;
code_r0x00018010e807:
        if ((fVar13 != 0.0) && (fVar8 != 0.0)) {
            if (fVar8 <= 0.0) {
                fVar8 = fVar8 / 1000.0 + -1.0;
            } else {
                fVar8 = fVar8 / 1000.0 + 1.0;
            }
        }
    }
    fVar16 = (float)((uint32_t)fVar13 & 0x7fffffff) + (float)((uint32_t)fVar8 & 0x7fffffff);
    fVar12 = (fVar11 + fVar15) - (*(float *)(iVar3 + 0x22a0) + fVar12);
    fVar10 = (fVar9 + fVar14) - (fVar10 + fVar7);
    fVar7 = (float)((uint32_t)fVar12 & 0x7fffffff) + (float)((uint32_t)fVar10 & 0x7fffffff);
    if ((fVar8 == 0.0) && (fVar13 == 0.0)) {
        if ((fVar10 == 0.0) && (fVar12 == 0.0)) {
            uVar4 = (uint64_t)*(uint32_t *)(iVar3 + 0x21d0);
            uVar5 = (uint32_t)(*(uint32_t *)(iVar3 + 0x21d0) <= *(uint32_t *)(iVar3 + 0x1fb8));
            fVar10 = 0.0;
            fVar12 = 0.0;
            fVar15 = 0.0;
        } else {
            fVar15 = fVar7;
            if ((float)((uint32_t)fVar10 & 0x7fffffff) <= (float)((uint32_t)fVar12 & 0x7fffffff))
            goto code_r0x00018010e920;
            uVar5 = (uint32_t)(0.0 < fVar10);
        }
    } else {
        fVar10 = fVar8;
        fVar12 = fVar13;
        fVar15 = fVar16;
        if ((float)((uint32_t)fVar8 & 0x7fffffff) <= (float)((uint32_t)fVar13 & 0x7fffffff)) {
code_r0x00018010e920:
            uVar5 = (0.0 < fVar12) + 2;
        } else {
            uVar5 = (uint32_t)(0.0 < fVar8);
        }
    }
    uVar1 = *(uint32_t *)(iVar3 + 0x2288);
    uVar6 = 0;
    if (uVar5 == uVar1) {
        if (fVar16 < *(float *)(arg1 + 0x24)) {
            *(float *)(arg1 + 0x24) = fVar16;
            *(float *)(arg1 + 0x28) = fVar7;
            return CONCAT71((unkint7)(uVar4 >> 8), 1);
        }
        if (fVar16 == *(float *)(arg1 + 0x24)) {
            if (*(float *)(arg1 + 0x28) <= fVar7) {
                if (fVar7 == *(float *)(arg1 + 0x28)) {
                    if (uVar1 - 2 < 2) {
                        fVar8 = fVar13;
                    }
                    uVar6 = 0;
                    if (fVar8 < 0.0) {
                        uVar6 = 1;
                    }
                }
            } else {
                *(float *)(arg1 + 0x28) = fVar7;
                uVar6 = 1;
            }
        }
    }
    if ((((*(float *)(arg1 + 0x24) == 3.402823e+38) && (fVar15 < *(float *)(arg1 + 0x2c))) &&
        (*(int32_t *)(iVar3 + 0x21e4) == 1)) && ((*(uint32_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x14) & 0x10000000) == 0)
       ) {
        if (uVar1 == 0) {
            if (0.0 <= fVar10) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 1) {
            if (fVar10 <= 0.0) {
                return (uint64_t)uVar6;
            }
        } else if (uVar1 == 2) {
            if (0.0 <= fVar12) {
                return (uint64_t)uVar6;
            }
        } else if ((uVar1 != 3) || (fVar12 <= 0.0)) goto code_r0x00018010ea43;
        *(float *)(arg1 + 0x2c) = fVar15;
        uVar6 = 1;
    }
code_r0x00018010ea43:
    return (uint64_t)uVar6;
}

// ============================================================
// Function: FUN_18010eca0
// Address: 0x18010eca0
// Size: 70 bytes
// ============================================================
void fcn.18010eca0(void)
{
    int64_t iVar1;
    
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)0x180781f28 + 0x2279) = 0;
    fcn.18010ea60();
    if ((*(char *)(iVar1 + 0x2279) == '\0') && (*(char *)(iVar1 + 0x223a) == '\0')) {
        *(undefined *)(iVar1 + 0x2239) = 0;
        return;
    }
    *(undefined *)(iVar1 + 0x2239) = 1;
    return;
}

// ============================================================
// Function: FUN_18010ecf0
// Address: 0x18010ecf0
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18010ecf0(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x448);
    if ((((iVar2 == 0) || (*(char *)(iVar2 + 0x10a) == '\0')) && (iVar2 = arg1, *(int64_t *)(arg1 + 0x4c8) != 0)) &&
       ((iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c8) + 0x40), iVar1 != 0 && (0 < *(int32_t *)(iVar1 + 8))))) {
        iVar3 = 0;
        uVar5 = 0;
        do {
            iVar6 = uVar5 * 0x38 + *(int64_t *)(iVar1 + 0x10);
            if (((iVar3 == 0) || (*(int32_t *)(iVar3 + 0x14) < *(int32_t *)(iVar6 + 0x14))) &&
               ((*(int64_t *)(iVar6 + 8) != 0 && (*(char *)(*(int64_t *)(iVar6 + 8) + 0x10a) != '\0')))) {
                iVar3 = iVar6;
            }
            uVar4 = (int32_t)uVar5 + 1;
            uVar5 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 8));
        if (iVar3 != 0) {
            return *(int64_t *)(iVar3 + 8);
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18010ed2d
// Address: 0x18010ed2d
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18010ecf0(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x448);
    if ((((iVar2 == 0) || (*(char *)(iVar2 + 0x10a) == '\0')) && (iVar2 = arg1, *(int64_t *)(arg1 + 0x4c8) != 0)) &&
       ((iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c8) + 0x40), iVar1 != 0 && (0 < *(int32_t *)(iVar1 + 8))))) {
        iVar3 = 0;
        uVar5 = 0;
        do {
            iVar6 = uVar5 * 0x38 + *(int64_t *)(iVar1 + 0x10);
            if (((iVar3 == 0) || (*(int32_t *)(iVar3 + 0x14) < *(int32_t *)(iVar6 + 0x14))) &&
               ((*(int64_t *)(iVar6 + 8) != 0 && (*(char *)(*(int64_t *)(iVar6 + 8) + 0x10a) != '\0')))) {
                iVar3 = iVar6;
            }
            uVar4 = (int32_t)uVar5 + 1;
            uVar5 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 8));
        if (iVar3 != 0) {
            return *(int64_t *)(iVar3 + 8);
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18010ed7d
// Address: 0x18010ed7d
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.18010ecf0(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x448);
    if ((((iVar2 == 0) || (*(char *)(iVar2 + 0x10a) == '\0')) && (iVar2 = arg1, *(int64_t *)(arg1 + 0x4c8) != 0)) &&
       ((iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x4c8) + 0x40), iVar1 != 0 && (0 < *(int32_t *)(iVar1 + 8))))) {
        iVar3 = 0;
        uVar5 = 0;
        do {
            iVar6 = uVar5 * 0x38 + *(int64_t *)(iVar1 + 0x10);
            if (((iVar3 == 0) || (*(int32_t *)(iVar3 + 0x14) < *(int32_t *)(iVar6 + 0x14))) &&
               ((*(int64_t *)(iVar6 + 8) != 0 && (*(char *)(*(int64_t *)(iVar6 + 8) + 0x10a) != '\0')))) {
                iVar3 = iVar6;
            }
            uVar4 = (int32_t)uVar5 + 1;
            uVar5 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < *(int32_t *)(iVar1 + 8));
        if (iVar3 != 0) {
            return *(int64_t *)(iVar3 + 8);
        }
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18010ed90
// Address: 0x18010ed90
// Size: 137 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018010ee9c)
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010ed90(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t unaff_RSI;
    uint32_t uVar14;
    undefined8 in_R8;
    int64_t in_R9;
    undefined4 *puVar15;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar10 = *(int64_t *)0x180781f28;
    iVar13 = (int32_t)arg1;
    if (iVar13 == 0) {
        uVar12 = fcn.18010ecf0(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), arg2, in_R8, in_R9);
        *(undefined8 *)(iVar10 + 0x21d8) = uVar12;
        *(undefined8 *)(iVar10 + 0x2230) = 0xffffffffffffffff;
    }
    iVar6 = *(int64_t *)0x180781f28;
    iVar7 = *(int64_t *)(iVar10 + 0x21d8);
    iVar11 = *(int32_t *)(iVar7 + 0x450 + (int64_t)iVar13 * 4);
    if (iVar11 != 0) {
        puVar15 = (undefined4 *)(iVar7 + 0x458 + (int64_t)iVar13 * 0x10);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0) = iVar11;
        *(int32_t *)(iVar6 + 0x21e4) = iVar13;
        fcn.180106840(unaff_RSI);
        iVar10 = *(int64_t *)0x180781f28;
        *(int32_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x450 + (int64_t)iVar13 * 4) = iVar11;
        uVar4 = puVar15[1];
        uVar5 = puVar15[2];
        uVar9 = puVar15[3];
        puVar3 = (undefined4 *)(*(int64_t *)(iVar6 + 0x21d8) + 0x458 + (int64_t)iVar13 * 0x10);
        *puVar3 = *puVar15;
        puVar3[1] = uVar4;
        puVar3[2] = uVar5;
        puVar3[3] = uVar9;
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x438) + 0x478 + (int64_t)*(int32_t *)(iVar10 + 0x21e4) * 8) =
             0x7f7fffff;
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x438) + 0x47c + (int64_t)*(int32_t *)(iVar10 + 0x21e4) * 8) =
             0x7f7fffff;
        return;
    }
    *(int32_t *)(iVar10 + 0x21e4) = iVar13;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x10 & 1) == 0) {
        _var_18h = ZEXT816(0);
        fcn.18010e3f0(0, (uint64_t)*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4), 
                      (uint64_t)*(uint32_t *)(iVar7 + 0x488), (int64_t)&var_18h);
        iVar7 = *(int64_t *)0x180781f28;
        *(undefined2 *)(iVar10 + 0x223a) = 1;
        *(undefined4 *)(iVar10 + 0x2248) = 0;
        if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
            *(undefined *)(iVar7 + 0x2239) = 0;
            return;
        }
        *(undefined *)(iVar7 + 0x2239) = 1;
        return;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x21d0) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    iVar11 = *(int32_t *)(iVar7 + 0x488);
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2200);
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x21e0) = iVar11;
    iVar13 = *(int32_t *)(iVar10 + 0x2204);
    if (iVar13 < 0) {
        iVar13 = iVar13 + iVar13 / 2;
        iVar8 = 0;
        if (0 < iVar13) {
            iVar8 = iVar13;
        }
        func_0x00018011f4f0(piVar1, iVar8);
    }
    *piVar1 = 0;
    if (iVar11 != 0) {
        if (iVar11 == *(int32_t *)(iVar10 + 0x1f74)) {
            iVar13 = 0;
            uVar14 = *(int32_t *)(iVar10 + 0x20f0) - 1;
            if (-1 < (int32_t)uVar14) {
                iVar13 = 0;
                do {
                    puVar2 = (undefined8 *)(*(int64_t *)(iVar10 + 0x20f8) + (uint64_t)uVar14 * 8);
                    if (*(int32_t *)((int64_t)puVar2 + 4) != *(int32_t *)(*(int64_t *)(iVar10 + 0x15e0) + 0x10)) break;
                    iVar11 = *(int32_t *)(iVar10 + 0x2204);
                    if (iVar13 == iVar11) {
                        if (iVar11 == 0) {
                            iVar11 = 8;
                        } else {
                            iVar11 = iVar11 / 2 + iVar11;
                        }
                        iVar8 = iVar13 + 1;
                        if (iVar13 + 1 < iVar11) {
                            iVar8 = iVar11;
                        }
                        func_0x00018011f4f0(piVar1, iVar8);
                    }
                    *(undefined8 *)(*(int64_t *)(iVar10 + 0x2208) + (int64_t)*piVar1 * 8) = *puVar2;
                    *piVar1 = *piVar1 + 1;
                    uVar14 = uVar14 - 1;
                    iVar13 = *piVar1;
                } while (-1 < (int32_t)uVar14);
            }
        } else {
            if (iVar11 != *(int32_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x488)) {
                return;
            }
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar10 + 0x21d8) + 0x10);
            if (*(int32_t *)(iVar10 + 0x2204) == 0) {
                func_0x00018011f4f0(piVar1, 8);
            }
            iVar13 = *piVar1;
            iVar7 = *(int64_t *)(iVar10 + 0x2208);
            *(int32_t *)(iVar7 + (int64_t)iVar13 * 8) = iVar11;
            *(undefined4 *)(iVar7 + 4 + (int64_t)iVar13 * 8) = uVar4;
            *piVar1 = *piVar1 + 1;
            iVar13 = *piVar1;
        }
        for (iVar7 = *(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x440); iVar7 != 0;
            iVar7 = *(int64_t *)(iVar7 + 0x440)) {
            iVar11 = *(int32_t *)(iVar10 + 0x2204);
            uVar4 = *(undefined4 *)(iVar7 + 0x488);
            uVar5 = *(undefined4 *)(iVar7 + 0x10);
            if (iVar13 == iVar11) {
                if (iVar11 == 0) {
                    iVar11 = 8;
                } else {
                    iVar11 = iVar11 / 2 + iVar11;
                }
                iVar8 = iVar13 + 1;
                if (iVar13 + 1 < iVar11) {
                    iVar8 = iVar11;
                }
                func_0x00018011f4f0(piVar1, iVar8);
            }
            iVar13 = *piVar1;
            iVar6 = *(int64_t *)(iVar10 + 0x2208);
            *(undefined4 *)(iVar6 + (int64_t)iVar13 * 8) = uVar4;
            *(undefined4 *)(iVar6 + 4 + (int64_t)iVar13 * 8) = uVar5;
            *piVar1 = *piVar1 + 1;
            iVar13 = *piVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010ee50
// Address: 0x18010ee50
// Size: 209 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018010ee9c)
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18010ed90(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    undefined8 *puVar2;
    undefined4 *puVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int32_t iVar8;
    undefined4 uVar9;
    int64_t iVar10;
    int32_t iVar11;
    undefined8 uVar12;
    int32_t iVar13;
    int64_t unaff_RSI;
    uint32_t uVar14;
    undefined8 in_R8;
    int64_t in_R9;
    undefined4 *puVar15;
    int64_t var_8h;
    int64_t var_18h;
    
    iVar10 = *(int64_t *)0x180781f28;
    iVar13 = (int32_t)arg1;
    if (iVar13 == 0) {
        uVar12 = fcn.18010ecf0(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), arg2, in_R8, in_R9);
        *(undefined8 *)(iVar10 + 0x21d8) = uVar12;
        *(undefined8 *)(iVar10 + 0x2230) = 0xffffffffffffffff;
    }
    iVar6 = *(int64_t *)0x180781f28;
    iVar7 = *(int64_t *)(iVar10 + 0x21d8);
    iVar11 = *(int32_t *)(iVar7 + 0x450 + (int64_t)iVar13 * 4);
    if (iVar11 != 0) {
        puVar15 = (undefined4 *)(iVar7 + 0x458 + (int64_t)iVar13 * 0x10);
        *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0) = iVar11;
        *(int32_t *)(iVar6 + 0x21e4) = iVar13;
        fcn.180106840(unaff_RSI);
        iVar10 = *(int64_t *)0x180781f28;
        *(int32_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x450 + (int64_t)iVar13 * 4) = iVar11;
        uVar4 = puVar15[1];
        uVar5 = puVar15[2];
        uVar9 = puVar15[3];
        puVar3 = (undefined4 *)(*(int64_t *)(iVar6 + 0x21d8) + 0x458 + (int64_t)iVar13 * 0x10);
        *puVar3 = *puVar15;
        puVar3[1] = uVar4;
        puVar3[2] = uVar5;
        puVar3[3] = uVar9;
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x438) + 0x478 + (int64_t)*(int32_t *)(iVar10 + 0x21e4) * 8) =
             0x7f7fffff;
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x438) + 0x47c + (int64_t)*(int32_t *)(iVar10 + 0x21e4) * 8) =
             0x7f7fffff;
        return;
    }
    *(int32_t *)(iVar10 + 0x21e4) = iVar13;
    iVar10 = *(int64_t *)0x180781f28;
    if ((*(uint32_t *)(iVar7 + 0x14) >> 0x10 & 1) == 0) {
        _var_18h = ZEXT816(0);
        fcn.18010e3f0(0, (uint64_t)*(uint32_t *)(*(int64_t *)0x180781f28 + 0x21e4), 
                      (uint64_t)*(uint32_t *)(iVar7 + 0x488), (int64_t)&var_18h);
        iVar7 = *(int64_t *)0x180781f28;
        *(undefined2 *)(iVar10 + 0x223a) = 1;
        *(undefined4 *)(iVar10 + 0x2248) = 0;
        if ((*(char *)(iVar7 + 0x2279) == '\0') && (*(char *)(iVar7 + 0x223a) == '\0')) {
            *(undefined *)(iVar7 + 0x2239) = 0;
            return;
        }
        *(undefined *)(iVar7 + 0x2239) = 1;
        return;
    }
    *(undefined4 *)(*(int64_t *)0x180781f28 + 0x21d0) = 0;
    iVar10 = *(int64_t *)0x180781f28;
    iVar11 = *(int32_t *)(iVar7 + 0x488);
    piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x2200);
    *(int32_t *)(*(int64_t *)0x180781f28 + 0x21e0) = iVar11;
    iVar13 = *(int32_t *)(iVar10 + 0x2204);
    if (iVar13 < 0) {
        iVar13 = iVar13 + iVar13 / 2;
        iVar8 = 0;
        if (0 < iVar13) {
            iVar8 = iVar13;
        }
        func_0x00018011f4f0(piVar1, iVar8);
    }
    *piVar1 = 0;
    if (iVar11 != 0) {
        if (iVar11 == *(int32_t *)(iVar10 + 0x1f74)) {
            iVar13 = 0;
            uVar14 = *(int32_t *)(iVar10 + 0x20f0) - 1;
            if (-1 < (int32_t)uVar14) {
                iVar13 = 0;
                do {
                    puVar2 = (undefined8 *)(*(int64_t *)(iVar10 + 0x20f8) + (uint64_t)uVar14 * 8);
                    if (*(int32_t *)((int64_t)puVar2 + 4) != *(int32_t *)(*(int64_t *)(iVar10 + 0x15e0) + 0x10)) break;
                    iVar11 = *(int32_t *)(iVar10 + 0x2204);
                    if (iVar13 == iVar11) {
                        if (iVar11 == 0) {
                            iVar11 = 8;
                        } else {
                            iVar11 = iVar11 / 2 + iVar11;
                        }
                        iVar8 = iVar13 + 1;
                        if (iVar13 + 1 < iVar11) {
                            iVar8 = iVar11;
                        }
                        func_0x00018011f4f0(piVar1, iVar8);
                    }
                    *(undefined8 *)(*(int64_t *)(iVar10 + 0x2208) + (int64_t)*piVar1 * 8) = *puVar2;
                    *piVar1 = *piVar1 + 1;
                    uVar14 = uVar14 - 1;
                    iVar13 = *piVar1;
                } while (-1 < (int32_t)uVar14);
            }
        } else {
            if (iVar11 != *(int32_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x488)) {
                return;
            }
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar10 + 0x21d8) + 0x10);
            if (*(int32_t *)(iVar10 + 0x2204) == 0) {
                func_0x00018011f4f0(piVar1, 8);
            }
            iVar13 = *piVar1;
            iVar7 = *(int64_t *)(iVar10 + 0x2208);
            *(int32_t *)(iVar7 + (int64_t)iVar13 * 8) = iVar11;
            *(undefined4 *)(iVar7 + 4 + (int64_t)iVar13 * 8) = uVar4;
            *piVar1 = *piVar1 + 1;
            iVar13 = *piVar1;
        }
        for (iVar7 = *(int64_t *)(*(int64_t *)(iVar10 + 0x21d8) + 0x440); iVar7 != 0;
            iVar7 = *(int64_t *)(iVar7 + 0x440)) {
            iVar11 = *(int32_t *)(iVar10 + 0x2204);
            uVar4 = *(undefined4 *)(iVar7 + 0x488);
            uVar5 = *(undefined4 *)(iVar7 + 0x10);
            if (iVar13 == iVar11) {
                if (iVar11 == 0) {
                    iVar11 = 8;
                } else {
                    iVar11 = iVar11 / 2 + iVar11;
                }
                iVar8 = iVar13 + 1;
                if (iVar13 + 1 < iVar11) {
                    iVar8 = iVar11;
                }
                func_0x00018011f4f0(piVar1, iVar8);
            }
            iVar13 = *piVar1;
            iVar6 = *(int64_t *)(iVar10 + 0x2208);
            *(undefined4 *)(iVar6 + (int64_t)iVar13 * 8) = uVar4;
            *(undefined4 *)(iVar6 + 4 + (int64_t)iVar13 * 8) = uVar5;
            *piVar1 = *piVar1 + 1;
            iVar13 = *piVar1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18010ef90
// Address: 0x18010ef90
// Size: 137 bytes
// ============================================================
float * fcn.18010ef90(int64_t arg1, int64_t arg2)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fStackX_18;
    float fStackX_1c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = (uint32_t)arg2;
    iVar5 = *(int64_t *)0x180781f28;
    iVar2 = func_0x00018010ef30();
    if (iVar2 == 1) {
        if ((*(float *)(iVar5 + 0x118) < -256000.0) || (*(float *)(iVar5 + 0x11c) < -256000.0)) {
            bVar1 = false;
        } else {
            bVar1 = true;
        }
        iVar3 = 0x118;
        if (!bVar1) {
            iVar3 = 0x2658;
        }
        fVar8 = *(float *)(iVar3 + iVar5);
        *(float *)(arg1 + 4) = *(float *)(iVar3 + 4 + iVar5);
        *(float *)arg1 = fVar8 + 1.0;
        return (float *)arg1;
    }
    iVar3 = *(int64_t *)(iVar5 + 0x21d8);
    if ((((*(int32_t *)(iVar5 + 0x1654) == 0) || (*(char *)(iVar5 + 0x1666) == '\0')) ||
        (*(int32_t *)(iVar5 + 0x1654) != *(int32_t *)(iVar5 + 0x1fb8))) || ((uVar6 >> 0x1a & 1) == 0)) {
        fVar9 = 0.0;
        fVar10 = 0.0;
        fVar11 = 0.0;
        fVar8 = 0.0;
        if (iVar3 == 0) goto code_r0x00018010f14f;
        iVar4 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        fVar8 = *(float *)(iVar3 + 0x168) + *(float *)(iVar3 + 0x458 + iVar4 * 0x10);
        fVar11 = *(float *)(iVar3 + 0x16c) + *(float *)(iVar3 + 0x45c + iVar4 * 0x10);
        fVar10 = *(float *)(iVar3 + 0x168) + *(float *)(iVar3 + 0x460 + iVar4 * 0x10);
        fVar9 = *(float *)(iVar3 + 0x16c) + *(float *)(iVar3 + 0x464 + iVar4 * 0x10);
    } else {
        fVar8 = *(float *)(iVar5 + 0x1fd4);
        fVar11 = *(float *)(iVar5 + 0x1fd8);
        fVar10 = *(float *)(iVar5 + 0x1fdc);
        fVar9 = *(float *)(iVar5 + 0x1fe0);
        if (iVar3 == 0) goto code_r0x00018010f14f;
    }
    if ((*(int32_t *)(iVar3 + 0x2e0) != *(int32_t *)(iVar5 + 4)) &&
       ((*(float *)(iVar3 + 0xe4) != 3.402823e+38 || (*(float *)(iVar3 + 0xe8) != 3.402823e+38)))) {
        func_0x00018010c510(&fStackX_18);
        fStackX_18 = *(float *)(iVar3 + 0xd4) - fStackX_18;
        fStackX_1c = *(float *)(iVar3 + 0xd8) - fStackX_1c;
        fVar8 = fVar8 + fStackX_18;
        fVar10 = fVar10 + fStackX_18;
        fVar11 = fVar11 + fStackX_1c;
        fVar9 = fVar9 + fStackX_1c;
    }
code_r0x00018010f14f:
    fVar7 = *(float *)(iVar5 + 0xddc) * 4.0;
    if (fVar10 - fVar8 <= fVar7) {
        fVar7 = fVar10 - fVar8;
    }
    fVar10 = *(float *)(iVar5 + 0xde0);
    if (fVar9 - fVar11 <= *(float *)(iVar5 + 0xde0)) {
        fVar10 = fVar9 - fVar11;
    }
    fVar7 = fVar7 + fVar8;
    fVar9 = fVar9 - fVar10;
    fVar8 = fVar7;
    if ((iVar3 != 0) && (iVar5 = *(int64_t *)(iVar3 + 0x48), iVar5 != 0)) {
        fVar11 = *(float *)(iVar5 + 0xc);
        fVar8 = *(float *)(iVar5 + 8);
        if ((fVar11 <= fVar9) && (fVar11 = fVar11 + *(float *)(iVar5 + 0x14), fVar9 <= fVar11)) {
            fVar11 = fVar9;
        }
        fVar9 = fVar11;
        if ((fVar8 <= fVar7) && (fVar8 = fVar8 + *(float *)(iVar5 + 0x10), fVar7 <= fVar8)) {
            fVar8 = fVar7;
        }
    }
    *(float *)arg1 = (float)(int32_t)fVar8;
    *(float *)(arg1 + 4) = (float)(int32_t)fVar9;
    return (float *)arg1;
}

// ============================================================
// Function: FUN_18010f019
// Address: 0x18010f019
// Size: 388 bytes
// ============================================================
float * fcn.18010ef90(int64_t arg1, int64_t arg2)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fStackX_18;
    float fStackX_1c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = (uint32_t)arg2;
    iVar5 = *(int64_t *)0x180781f28;
    iVar2 = func_0x00018010ef30();
    if (iVar2 == 1) {
        if ((*(float *)(iVar5 + 0x118) < -256000.0) || (*(float *)(iVar5 + 0x11c) < -256000.0)) {
            bVar1 = false;
        } else {
            bVar1 = true;
        }
        iVar3 = 0x118;
        if (!bVar1) {
            iVar3 = 0x2658;
        }
        fVar8 = *(float *)(iVar3 + iVar5);
        *(float *)(arg1 + 4) = *(float *)(iVar3 + 4 + iVar5);
        *(float *)arg1 = fVar8 + 1.0;
        return (float *)arg1;
    }
    iVar3 = *(int64_t *)(iVar5 + 0x21d8);
    if ((((*(int32_t *)(iVar5 + 0x1654) == 0) || (*(char *)(iVar5 + 0x1666) == '\0')) ||
        (*(int32_t *)(iVar5 + 0x1654) != *(int32_t *)(iVar5 + 0x1fb8))) || ((uVar6 >> 0x1a & 1) == 0)) {
        fVar9 = 0.0;
        fVar10 = 0.0;
        fVar11 = 0.0;
        fVar8 = 0.0;
        if (iVar3 == 0) goto code_r0x00018010f14f;
        iVar4 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        fVar8 = *(float *)(iVar3 + 0x168) + *(float *)(iVar3 + 0x458 + iVar4 * 0x10);
        fVar11 = *(float *)(iVar3 + 0x16c) + *(float *)(iVar3 + 0x45c + iVar4 * 0x10);
        fVar10 = *(float *)(iVar3 + 0x168) + *(float *)(iVar3 + 0x460 + iVar4 * 0x10);
        fVar9 = *(float *)(iVar3 + 0x16c) + *(float *)(iVar3 + 0x464 + iVar4 * 0x10);
    } else {
        fVar8 = *(float *)(iVar5 + 0x1fd4);
        fVar11 = *(float *)(iVar5 + 0x1fd8);
        fVar10 = *(float *)(iVar5 + 0x1fdc);
        fVar9 = *(float *)(iVar5 + 0x1fe0);
        if (iVar3 == 0) goto code_r0x00018010f14f;
    }
    if ((*(int32_t *)(iVar3 + 0x2e0) != *(int32_t *)(iVar5 + 4)) &&
       ((*(float *)(iVar3 + 0xe4) != 3.402823e+38 || (*(float *)(iVar3 + 0xe8) != 3.402823e+38)))) {
        func_0x00018010c510(&fStackX_18);
        fStackX_18 = *(float *)(iVar3 + 0xd4) - fStackX_18;
        fStackX_1c = *(float *)(iVar3 + 0xd8) - fStackX_1c;
        fVar8 = fVar8 + fStackX_18;
        fVar10 = fVar10 + fStackX_18;
        fVar11 = fVar11 + fStackX_1c;
        fVar9 = fVar9 + fStackX_1c;
    }
code_r0x00018010f14f:
    fVar7 = *(float *)(iVar5 + 0xddc) * 4.0;
    if (fVar10 - fVar8 <= fVar7) {
        fVar7 = fVar10 - fVar8;
    }
    fVar10 = *(float *)(iVar5 + 0xde0);
    if (fVar9 - fVar11 <= *(float *)(iVar5 + 0xde0)) {
        fVar10 = fVar9 - fVar11;
    }
    fVar7 = fVar7 + fVar8;
    fVar9 = fVar9 - fVar10;
    fVar8 = fVar7;
    if ((iVar3 != 0) && (iVar5 = *(int64_t *)(iVar3 + 0x48), iVar5 != 0)) {
        fVar11 = *(float *)(iVar5 + 0xc);
        fVar8 = *(float *)(iVar5 + 8);
        if ((fVar11 <= fVar9) && (fVar11 = fVar11 + *(float *)(iVar5 + 0x14), fVar9 <= fVar11)) {
            fVar11 = fVar9;
        }
        fVar9 = fVar11;
        if ((fVar8 <= fVar7) && (fVar8 = fVar8 + *(float *)(iVar5 + 0x10), fVar7 <= fVar8)) {
            fVar8 = fVar7;
        }
    }
    *(float *)arg1 = (float)(int32_t)fVar8;
    *(float *)(arg1 + 4) = (float)(int32_t)fVar9;
    return (float *)arg1;
}

// ============================================================
// Function: FUN_18010f19d
// Address: 0x18010f19d
// Size: 99 bytes
// ============================================================
float * fcn.18010ef90(int64_t arg1, int64_t arg2)
{
    bool bVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint32_t uVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    float fVar10;
    float fVar11;
    float fStackX_18;
    float fStackX_1c;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar6 = (uint32_t)arg2;
    iVar5 = *(int64_t *)0x180781f28;
    iVar2 = func_0x00018010ef30();
    if (iVar2 == 1) {
        if ((*(float *)(iVar5 + 0x118) < -256000.0) || (*(float *)(iVar5 + 0x11c) < -256000.0)) {
            bVar1 = false;
        } else {
            bVar1 = true;
        }
        iVar3 = 0x118;
        if (!bVar1) {
            iVar3 = 0x2658;
        }
        fVar8 = *(float *)(iVar3 + iVar5);
        *(float *)(arg1 + 4) = *(float *)(iVar3 + 4 + iVar5);
        *(float *)arg1 = fVar8 + 1.0;
        return (float *)arg1;
    }
    iVar3 = *(int64_t *)(iVar5 + 0x21d8);
    if ((((*(int32_t *)(iVar5 + 0x1654) == 0) || (*(char *)(iVar5 + 0x1666) == '\0')) ||
        (*(int32_t *)(iVar5 + 0x1654) != *(int32_t *)(iVar5 + 0x1fb8))) || ((uVar6 >> 0x1a & 1) == 0)) {
        fVar9 = 0.0;
        fVar10 = 0.0;
        fVar11 = 0.0;
        fVar8 = 0.0;
        if (iVar3 == 0) goto code_r0x00018010f14f;
        iVar4 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        fVar8 = *(float *)(iVar3 + 0x168) + *(float *)(iVar3 + 0x458 + iVar4 * 0x10);
        fVar11 = *(float *)(iVar3 + 0x16c) + *(float *)(iVar3 + 0x45c + iVar4 * 0x10);
        fVar10 = *(float *)(iVar3 + 0x168) + *(float *)(iVar3 + 0x460 + iVar4 * 0x10);
        fVar9 = *(float *)(iVar3 + 0x16c) + *(float *)(iVar3 + 0x464 + iVar4 * 0x10);
    } else {
        fVar8 = *(float *)(iVar5 + 0x1fd4);
        fVar11 = *(float *)(iVar5 + 0x1fd8);
        fVar10 = *(float *)(iVar5 + 0x1fdc);
        fVar9 = *(float *)(iVar5 + 0x1fe0);
        if (iVar3 == 0) goto code_r0x00018010f14f;
    }
    if ((*(int32_t *)(iVar3 + 0x2e0) != *(int32_t *)(iVar5 + 4)) &&
       ((*(float *)(iVar3 + 0xe4) != 3.402823e+38 || (*(float *)(iVar3 + 0xe8) != 3.402823e+38)))) {
        func_0x00018010c510(&fStackX_18);
        fStackX_18 = *(float *)(iVar3 + 0xd4) - fStackX_18;
        fStackX_1c = *(float *)(iVar3 + 0xd8) - fStackX_1c;
        fVar8 = fVar8 + fStackX_18;
        fVar10 = fVar10 + fStackX_18;
        fVar11 = fVar11 + fStackX_1c;
        fVar9 = fVar9 + fStackX_1c;
    }
code_r0x00018010f14f:
    fVar7 = *(float *)(iVar5 + 0xddc) * 4.0;
    if (fVar10 - fVar8 <= fVar7) {
        fVar7 = fVar10 - fVar8;
    }
    fVar10 = *(float *)(iVar5 + 0xde0);
    if (fVar9 - fVar11 <= *(float *)(iVar5 + 0xde0)) {
        fVar10 = fVar9 - fVar11;
    }
    fVar7 = fVar7 + fVar8;
    fVar9 = fVar9 - fVar10;
    fVar8 = fVar7;
    if ((iVar3 != 0) && (iVar5 = *(int64_t *)(iVar3 + 0x48), iVar5 != 0)) {
        fVar11 = *(float *)(iVar5 + 0xc);
        fVar8 = *(float *)(iVar5 + 8);
        if ((fVar11 <= fVar9) && (fVar11 = fVar11 + *(float *)(iVar5 + 0x14), fVar9 <= fVar11)) {
            fVar11 = fVar9;
        }
        fVar9 = fVar11;
        if ((fVar8 <= fVar7) && (fVar8 = fVar8 + *(float *)(iVar5 + 0x10), fVar7 <= fVar8)) {
            fVar8 = fVar7;
        }
    }
    *(float *)arg1 = (float)(int32_t)fVar8;
    *(float *)(arg1 + 4) = (float)(int32_t)fVar9;
    return (float *)arg1;
}

// ============================================================
// Function: FUN_18010f200
// Address: 0x18010f200
// Size: 226 bytes
// ============================================================
undefined8 fcn.18010f200(int64_t arg1)
{
    char cVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint64_t uVar5;
    uint64_t uVar6;
    float extraout_XMM0_Da;
    float fVar7;
    undefined4 extraout_XMM0_Db;
    undefined4 uVar8;
    float fVar9;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar7 = *(float *)(*(int64_t *)0x180781f28 + 0xac);
    fVar9 = *(float *)(*(int64_t *)0x180781f28 + 0xa8) * 0.72;
    iVar3 = (int32_t)arg1;
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) == 3) {
        uVar6 = 0x281;
        uVar5 = 0x280;
        if (iVar3 == 0) {
            uVar5 = 0x27e;
        }
        uVar2 = 0x27f;
    } else {
        uVar6 = 0x204;
        uVar5 = 0x203;
        if (iVar3 == 0) {
            uVar5 = 0x201;
        }
        uVar2 = 0x202;
    }
    if (iVar3 == 0) {
        uVar6 = (uint64_t)uVar2;
    }
    iVar3 = func_0x0001801078b0(uVar6, fVar9, uVar5);
    iVar4 = func_0x0001801078b0(uVar5 & 0xffffffff, fVar9, fVar7 * 0.3);
    if ((((float)iVar3 - (float)iVar4 == 0.0) || (cVar1 = func_0x000180107d30(uVar5 & 0xffffffff, 0), cVar1 == '\0')) ||
       (cVar1 = func_0x000180107d30(uVar6 & 0xffffffff, 0), fVar7 = extraout_XMM0_Da, uVar8 = extraout_XMM0_Db,
       cVar1 == '\0')) {
        fVar7 = (float)iVar3 - (float)iVar4;
        uVar8 = 0;
    }
    return CONCAT44(uVar8, fVar7);
}

// ============================================================
// Function: FUN_18010f2f0
// Address: 0x18010f2f0
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010f314
// Address: 0x18010f314
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010f31c
// Address: 0x18010f31c
// Size: 733 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010f5f9
// Address: 0x18010f5f9
// Size: 152 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010f691
// Address: 0x18010f691
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010f6b3
// Address: 0x18010f6b3
// Size: 738 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010f995
// Address: 0x18010f995
// Size: 436 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010fb49
// Address: 0x18010fb49
// Size: 531 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010fd5c
// Address: 0x18010fd5c
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_94h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h

void fcn.18010f2f0(void)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    bool bVar8;
    int64_t iVar9;
    char cVar10;
    undefined uVar11;
    char cVar12;
    char cVar13;
    int32_t iVar14;
    int64_t iVar15;
    undefined4 *puVar16;
    undefined8 uVar17;
    int64_t *piVar18;
    uint32_t uVar19;
    uint8_t uVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_b8 [32];
    int64_t var_98h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    undefined4 var_70h;
    undefined var_6ch [4];
    int64_t var_68h;
    undefined8 uStack_60;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    puVar1 = (uint8_t *)(*(int64_t *)0x180781f28 + 0x30);
    *(undefined *)(*(int64_t *)0x180781f28 + 0xeb) = 0;
    if (((*puVar1 & 2) == 0) || ((*(uint8_t *)(iVar9 + 0x34) & 1) == 0)) {
        cVar12 = '\0';
        var_98h._0_1_ = '\0';
    } else {
        piVar18 = &var_68h;
        cVar12 = '\x01';
        var_68h = 0x27a0000027b;
        uStack_60 = 0x27d0000027c;
        var_98h._0_1_ = '\x01';
        _var_58h = *(undefined (*) [16])0x180646ac0;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 3;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != &var_48h);
    }
    uVar20 = *(uint8_t *)(iVar9 + 0x30) & 1;
    var_88h = 0x20d0000020c;
    uStack_80 = 0x2020000020e;
    var_78h._0_4_ = 0x201;
    var_78h._4_4_ = 0x203;
    var_70h = 0x204;
    var_98h._1_1_ = uVar20;
    if (uVar20 != 0) {
        piVar18 = &var_88h;
        do {
            cVar10 = func_0x000180107d30(*(undefined4 *)piVar18, 0);
            if (cVar10 != '\0') {
                *(undefined4 *)(iVar9 + 0x2228) = 2;
            }
            piVar18 = (int64_t *)((int64_t)piVar18 + 4);
        } while (piVar18 != (int64_t *)var_6ch);
    }
    uVar19 = *(uint32_t *)(iVar9 + 0x2248);
    *(undefined8 *)(iVar9 + 0x23a0) = 0;
    *(undefined4 *)(iVar9 + 0x23a8) = 0;
    if ((uVar19 != 0) && (*(int64_t *)(iVar9 + 0x21d8) != 0)) {
        if (*(uint32_t *)(iVar9 + 0x21d0) != uVar19) {
            *(undefined4 *)(iVar9 + 0x23a0) = *(undefined4 *)(iVar9 + 0x21e0);
            *(uint32_t *)(iVar9 + 0x23a4) = uVar19;
            *(undefined4 *)(iVar9 + 0x23a8) = *(undefined4 *)(iVar9 + 0x224c);
            *(undefined4 *)(iVar9 + 0x23ac) = 0;
            *(undefined *)(iVar9 + 0x23b0) = 0;
            *(uint8_t *)(iVar9 + 0x23b1) = (uint8_t)(*(uint32_t *)(iVar9 + 0x2260) >> 0x15) & 1;
        }
        fcn.18010e3f0((uint64_t)uVar19, (uint64_t)*(uint32_t *)(iVar9 + 0x21e4), (uint64_t)*(uint32_t *)(iVar9 + 0x224c)
                      , iVar9 + 0x2250);
        *(undefined *)(iVar9 + 0x21cf) = 1;
        if (*(int64_t *)(iVar9 + 0x2270) != -1) {
            *(int64_t *)(iVar9 + 0x2230) = *(int64_t *)(iVar9 + 0x2270);
        }
        if (*(char *)(iVar9 + 0x223b) != '\0') {
            func_0x00018010e380();
        }
    }
    *(undefined2 *)(iVar9 + 0x223a) = 0;
    *(undefined4 *)(iVar9 + 0x2248) = 0;
    if (*(char *)(iVar9 + 0x2278) != '\0') {
        func_0x000180110530();
    }
    *(undefined4 *)(iVar9 + 0x22bc) = 0;
    *(undefined2 *)(iVar9 + 0x2278) = 0;
    if (('\0' < *(char *)(iVar9 + 0x2238)) &&
       (cVar10 = *(char *)(iVar9 + 0x2238) + -1, *(char *)(iVar9 + 0x2238) = cVar10, cVar10 == '\0')) {
        *(undefined *)(iVar9 + 0x21cc) = 1;
    }
    var_98h._4_4_ = 0;
    if ((((*(char *)(iVar9 + 0x21ce) != '\0') && (*(char *)(iVar9 + 0x21cf) != '\0')) &&
        (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(char *)(iVar9 + 0x21cd) != '\0')) {
        var_98h._4_4_ = (uint32_t)(*(int64_t *)(iVar9 + 0x21d8) != 0);
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21ce) = 0;
    for (iVar15 = iVar5; iVar15 != 0; iVar15 = *(int64_t *)(iVar15 + 0x408)) {
        if ((*(int64_t *)(iVar15 + 0x418) == iVar15) || ((*(uint32_t *)(iVar15 + 0x14) & 0x14000000) != 0)) {
            if (iVar15 != iVar5) {
                *(int64_t *)(iVar15 + 0x448) = iVar5;
            }
            break;
        }
    }
    iVar5 = *(int64_t *)(iVar9 + 0x21d8);
    if (((iVar5 != 0) && (*(int64_t *)(iVar5 + 0x448) != 0)) && (*(int32_t *)(iVar9 + 0x21e4) == 0)) {
        *(undefined8 *)(iVar5 + 0x448) = 0;
    }
    func_0x0001801111e0();
    if ((((uVar20 == 0) && (cVar12 == '\0')) || (*(int64_t *)(iVar9 + 0x21d8) == 0)) ||
       ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) != 0)) {
        *(undefined *)(iVar9 + 0xed) = 0;
code_r0x00018010f69f:
        if (*(int64_t *)(iVar9 + 0x23c0) != 0) goto code_r0x00018010f5f5;
        uVar11 = 0;
    } else {
        *(undefined *)(iVar9 + 0xed) = 1;
        if ((*(int32_t *)(iVar9 + 0x21d0) == 0) || (*(char *)(iVar9 + 0x21cc) == '\0')) goto code_r0x00018010f69f;
code_r0x00018010f5f5:
        uVar11 = 1;
    }
    *(undefined *)(iVar9 + 0xee) = uVar11;
    func_0x000180110910();
    iVar5 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2218) = 0;
    bVar7 = true;
    if (((*(uint8_t *)(iVar5 + 0x30) & 1) != 0) &&
       (iVar15 = *(int64_t *)(iVar5 + 0x21d8), uVar20 = var_98h._1_1_, iVar15 != 0)) {
        var_98h._0_1_ = cVar12;
        bVar6 = bVar7;
        if ((((*(float *)(iVar5 + 0x2b8) <= 0.0 && *(float *)(iVar5 + 0x2b8) != 0.0) ||
             (*(char *)(iVar5 + 0x2b0) != '\0')) ||
            (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
             (*(int32_t *)(iVar5 + 0x17e0) != -1)))) &&
           ((cVar10 = func_0x000180107dc0(0x245, 0, 0xffffffff), cVar10 == '\0' ||
            (*(int32_t *)(iVar5 + 0x13c) != 0x2000)))) {
            var_98h._0_1_ = cVar12;
            bVar6 = false;
        }
        cVar10 = func_0x000180107dc0(0x27c, 0, 0xffffffff);
        uVar20 = var_98h._1_1_;
        if ((bool)(bVar6 | cVar10 != '\0')) {
            iVar3 = *(int32_t *)(iVar5 + 0x21d0);
            *(int32_t *)(iVar5 + 0x2218) = iVar3;
            *(undefined4 *)(iVar5 + 0x221c) = *(undefined4 *)(iVar15 + 0x10);
            uVar4 = *(undefined4 *)(*(int64_t *)(iVar15 + 0x150) + -4 + (int64_t)*(int32_t *)(iVar15 + 0x148) * 4);
            iVar14 = func_0x0001800f5a90(0x1806445a0, 0, uVar4);
            if ((iVar3 == iVar14) || (iVar14 = func_0x0001800f5a90(0x180644220, 0, uVar4), iVar3 == iVar14)) {
                *(undefined4 *)(iVar5 + 0x2218) = *(undefined4 *)(iVar15 + 0xc4);
            }
            *(undefined4 *)(iVar5 + 0x2228) = 2;
            func_0x00018010e380();
            uVar20 = var_98h._1_1_;
        }
    }
    iVar3 = *(int32_t *)(iVar9 + 0x21d0);
    *(undefined8 *)(iVar9 + 0x21f0) = 0;
    *(undefined4 *)(iVar9 + 0x21ec) = 0;
    *(undefined4 *)(iVar9 + 0x21f8) = 0;
    if ((((iVar3 != 0) && (*(char *)(iVar9 + 0x21cc) != '\0')) && (*(int64_t *)(iVar9 + 0x23c0) == 0)) &&
       ((*(int64_t *)(iVar9 + 0x21d8) != 0 && ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)))) {
        if (((uVar20 == 0) || (*(char *)(iVar5 + 0x200) == '\0')) ||
           (((*(char *)(iVar5 + 0x1f6c) != '\0' && (*(int32_t *)(iVar5 + 0x1654) != -1)) ||
            (*(int32_t *)(iVar5 + 0x175c) != -1)))) {
            if (cVar12 != '\0') {
                uVar17 = 0x27d;
                if (*(char *)(iVar9 + 0x79) != '\0') {
                    uVar17 = 0x27b;
                }
                cVar12 = func_0x000180107d30(uVar17, 0xffffffff);
                if (cVar12 != '\0') goto code_r0x00018010f805;
            }
            bVar6 = false;
code_r0x00018010f851:
            bVar7 = bVar6;
            bVar8 = false;
        } else {
code_r0x00018010f805:
            bVar8 = bVar7;
            if ((var_98h._1_1_ == 0) || (cVar12 = func_0x000180107dc0(0x20c, 0, 0xffffffff), cVar12 == '\0')) {
                bVar6 = bVar7;
                if ((char)var_98h != '\0') {
                    uVar17 = 0x27d;
                    if (*(char *)(iVar9 + 0x79) != '\0') {
                        uVar17 = 0x27b;
                    }
                    cVar12 = func_0x000180107dc0(uVar17, 0, 0xffffffff);
                    bVar6 = true;
                    if (cVar12 != '\0') goto code_r0x00018010f854;
                }
                goto code_r0x00018010f851;
            }
        }
code_r0x00018010f854:
        if ((var_98h._1_1_ == 0) ||
           ((cVar12 = func_0x000180107dc0(0x20d, 0, 0xffffffff), cVar12 == '\0' &&
            (cVar12 = func_0x000180107dc0(0x273, 0, 0xffffffff), cVar12 == '\0')))) {
            cVar12 = '\0';
        } else {
            cVar12 = '\x01';
        }
        cVar10 = '\0';
        if ((bVar7) && ((char)var_98h != '\0')) {
            uVar17 = 0x27d;
            if (*(char *)(iVar9 + 0x79) != '\0') {
                uVar17 = 0x27b;
            }
            cVar10 = '\0';
            cVar13 = func_0x000180107d30(uVar17, 0xffffffff);
            if ((((cVar13 != '\0') && ((*(uint32_t *)(iVar9 + 0x21e8) & 0x100000) != 0)) &&
                (iVar15 = func_0x0001800f4560(uVar17), *(float *)(iVar15 + 8) <= 0.6 && *(float *)(iVar15 + 8) != 0.6))
               && (0.6 <= *(float *)(iVar15 + 4))) {
                cVar10 = '\x01';
            }
        }
        iVar14 = *(int32_t *)(iVar9 + 0x1654);
        if (iVar14 == 0) {
            if (bVar8) {
                *(int32_t *)(iVar9 + 0x21ec) = iVar3;
                *(undefined4 *)(iVar9 + 0x21f8) = 2;
            }
        } else if (iVar14 != iVar3) goto code_r0x00018010f971;
        if ((cVar12 != '\0') || (cVar10 != '\0')) {
            *(int32_t *)(iVar9 + 0x21ec) = iVar3;
            *(undefined4 *)(iVar9 + 0x21f8) = 1;
        }
        if ((iVar14 == 0) || (iVar14 == iVar3)) {
            if ((bVar7) || ((cVar12 != '\0' || (cVar10 != '\0')))) {
                *(int32_t *)(iVar9 + 0x21f0) = iVar3;
            }
            if (((iVar14 == 0) || (iVar14 == iVar3)) && ((bVar8 || ((cVar12 != '\0' || (cVar10 != '\0')))))) {
                *(int32_t *)(iVar9 + 0x21f4) = iVar3;
                *(int32_t *)(iVar5 + 0x2210) = iVar3;
                *(undefined4 *)(iVar5 + 0x2214) = 0x3dcccccd;
            }
        }
    }
code_r0x00018010f971:
    if ((*(int64_t *)(iVar9 + 0x21d8) == 0) || ((*(uint32_t *)(*(int64_t *)(iVar9 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if ((*(char *)(iVar9 + 0x7f) != '\0') && (*(char *)(iVar9 + 0x2238) == '\0')) {
            *(undefined *)(iVar9 + 0x21cc) = 1;
        }
    } else {
        *(undefined *)(iVar9 + 0x21cc) = 0;
    }
    fVar24 = *(float *)(iVar9 + 0x2214);
    if (0.0 < fVar24) {
        fVar21 = fVar24 - *(float *)(iVar9 + 0x48);
        fVar24 = 0.0;
        if (0.0 <= fVar21) {
            fVar24 = fVar21;
        }
        *(float *)(iVar9 + 0x2214) = fVar24;
    }
    if (fVar24 == 0.0) {
        *(undefined4 *)(iVar9 + 0x2210) = 0;
    }
    iVar3 = *(int32_t *)(iVar9 + 0x2220);
    if (iVar3 != 0) {
        *(int32_t *)(iVar9 + 0x21f4) = iVar3;
        *(int32_t *)(iVar9 + 0x21f0) = iVar3;
        *(int32_t *)(iVar9 + 0x21ec) = iVar3;
        *(undefined4 *)(iVar9 + 0x21f8) = *(undefined4 *)(iVar9 + 0x2224);
    }
    *(undefined4 *)(iVar9 + 0x2220) = 0;
    func_0x00018010fdf0();
    iVar5 = *(int64_t *)0x180781f28;
    if ((((*(int32_t *)(iVar9 + 0x2288) == -1) && (iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8), iVar15 != 0)
         ) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) &&
       ((((*(uint32_t *)(iVar15 + 0x14) & 0x10000) == 0 && (*(char *)(*(int64_t *)0x180781f28 + 0x23b2) != '\0')) &&
        ((cVar12 = func_0x000180107dc0(0x200, 1, 0xffffffff), cVar12 != '\0' &&
         ((*(char *)(iVar5 + 0x138) == '\0' && (*(char *)(iVar5 + 0x13a) == '\0')))))))) {
        if ((*(uint8_t *)(iVar5 + 0x30) & 1) == 0) {
            if (*(char *)(iVar5 + 0x139) == '\0') {
                uVar19 = (uint32_t)(*(int32_t *)(iVar5 + 0x1654) != 0);
            } else {
                uVar19 = 0xffffffff;
            }
        } else if (*(char *)(iVar5 + 0x139) == '\0') {
            uVar19 = 1;
            if ((*(char *)(iVar5 + 0x21cc) == '\0') && (*(int32_t *)(iVar5 + 0x1654) == 0)) {
                uVar19 = 0;
            }
        } else {
            uVar19 = 0xffffffff;
        }
        *(uint32_t *)(iVar5 + 0x22b8) = uVar19;
        uVar17 = 3;
        if (*(char *)(iVar15 + 0x110) != '\0') {
            uVar17 = 0x21;
        }
        func_0x00018010eb00(0xffffffff, ((int32_t)uVar19 >> 0x1f) + 3, 0x1400, uVar17);
        *(undefined4 *)(iVar5 + 0x22bc) = 0xffffffff;
    }
    if ((*(char *)(iVar5 + 0x2279) == '\0') && (*(char *)(iVar5 + 0x223a) == '\0')) {
        uVar11 = 0;
    } else {
        uVar11 = 1;
    }
    *(undefined *)(iVar5 + 0x2239) = uVar11;
    iVar15 = *(int64_t *)(iVar9 + 0x21d8);
    *(undefined *)(iVar9 + 0x21cf) = 0;
    if (((iVar15 == 0) || ((*(uint32_t *)(iVar15 + 0x14) & 0x10000) != 0)) || (*(int64_t *)(iVar9 + 0x23c0) != 0))
    goto code_r0x00018010fd4d;
    fVar24 = 1.0;
    fVar21 = (float)(int32_t)(*(float *)(iVar15 + 0x318) * 100.0 * *(float *)(iVar9 + 0x48) + 0.5);
    if (((*(int16_t *)(iVar15 + 0x1b4) == 0) && (*(char *)(iVar15 + 0x1ba) != '\0')) &&
       (iVar3 = *(int32_t *)(iVar9 + 0x2288), iVar3 != -1)) {
        fVar22 = -1.0;
        if (iVar3 == 0) {
            fVar23 = -1.0;
code_r0x00018010fc03:
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar23 * fVar21 + *(float *)(iVar15 + 0xd4));
        } else if (iVar3 == 1) {
            fVar23 = 1.0;
            goto code_r0x00018010fc03;
        }
        if (iVar3 != 2) {
            if (iVar3 != 3) goto code_r0x00018010fc6a;
            fVar22 = 1.0;
        }
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar22 * fVar21 + *(float *)(iVar15 + 0xd8));
    }
code_r0x00018010fc6a:
    if ((char)var_98h != '\0') {
        fVar23 = *(float *)(iVar5 + 0x9fc) - *(float *)(iVar5 + 0x9ec);
        fVar22 = *(float *)(iVar5 + 0x9dc) - *(float *)(iVar5 + 0x9cc);
        if ((*(char *)(iVar5 + 0x960) == '\0') || (*(char *)(iVar5 + 0x1cec) != '\0')) {
            if ((*(char *)(iVar5 + 0x970) != '\0') && (*(char *)(iVar5 + 0x1cf8) == '\0')) {
                fVar24 = 10.0;
            }
        } else {
            fVar24 = 0.1;
        }
        if ((fVar22 != 0.0) && (*(char *)(iVar15 + 0x104) != '\0')) {
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            *(float *)(iVar15 + 0xe4) = (float)(int32_t)(fVar22 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd4));
        }
        if (fVar23 != 0.0) {
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(float *)(iVar15 + 0xe8) = (float)(int32_t)(fVar23 * fVar21 * fVar24 + *(float *)(iVar15 + 0xd8));
        }
    }
code_r0x00018010fd4d:
    if ((var_98h._1_1_ == 0) && ((char)var_98h == '\0')) {
        *(undefined2 *)(iVar9 + 0x21cc) = 0;
    } else if ((var_98h._4_1_ != '\0') && ((*(char *)(iVar9 + 0x7a) != '\0' && ((*(uint8_t *)(iVar9 + 0x34) & 4) != 0)))
              ) {
        puVar16 = (undefined4 *)fcn.18010ef90((int64_t)&var_98h + 4, 0x4000000);
        uVar4 = *puVar16;
        uVar2 = puVar16[1];
        *(undefined4 *)(iVar5 + 0xaf4) = uVar4;
        *(undefined4 *)(iVar5 + 0xaf8) = uVar2;
        *(undefined4 *)(iVar5 + 0x118) = uVar4;
        *(undefined4 *)(iVar5 + 0x11c) = uVar2;
        *(undefined8 *)(iVar5 + 0x104) = 0;
        *(undefined *)(iVar5 + 0xeb) = 1;
    }
    *(undefined4 *)(iVar9 + 0x22b4) = 0;
    func_0x000180459870(var_48h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_18010fdf0
// Address: 0x18010fdf0
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_18010fe22
// Address: 0x18010fe22
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_18010fea0
// Address: 0x18010fea0
// Size: 256 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_18010ffa0
// Address: 0x18010ffa0
// Size: 207 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_18011006f
// Address: 0x18011006f
// Size: 241 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_180110160
// Address: 0x180110160
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_1801101b9
// Address: 0x1801101b9
// Size: 873 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_cch

void fcn.18010fdf0(void)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    char cVar6;
    float *pfVar7;
    int64_t iVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    int64_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    float fVar17;
    float fVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    uVar10 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x30);
    if (((uVar10 & 2) == 0) || ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar4 = false;
    } else {
        bVar4 = true;
    }
    iVar11 = iVar5;
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x227a) == '\0') || (iVar3 == 0)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2288) = 0xffffffff;
        *(undefined8 *)(iVar5 + 0x227c) = 0;
        if ((iVar3 != 0) && ((*(int64_t *)(iVar5 + 0x23c0) == 0 && ((*(uint32_t *)(iVar3 + 0x14) & 0x10000) == 0)))) {
            uVar9 = *(uint32_t *)(iVar5 + 0x1f68);
            if (((uVar9 & 1) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27e, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x201, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 0;
            }
            if (((uVar9 & 2) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x27f, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x202, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 1;
            }
            if (((uVar9 & 4) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x280, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x203, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 2;
            }
            if (((uVar9 & 8) == 0) &&
               (((bVar4 && (cVar6 = func_0x000180107dc0(0x281, 5, 0xffffffff), cVar6 != '\0')) ||
                (((uVar10 & 1) != 0 && (cVar6 = func_0x000180107dc0(0x204, 5, 0xffffffff), cVar6 != '\0')))))) {
                *(undefined4 *)(iVar5 + 0x2288) = 3;
            }
        }
        *(undefined4 *)(iVar5 + 0x2290) = *(undefined4 *)(iVar5 + 0x2288);
        fVar12 = 0.0;
        *(undefined4 *)(iVar5 + 0x22a4) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22a8) = 0x7f7fffff;
        *(undefined4 *)(iVar5 + 0x22ac) = 0xff7fffff;
        *(undefined4 *)(iVar5 + 0x22b0) = 0xff7fffff;
        if (iVar3 != 0) goto code_r0x00018011002e;
    } else {
code_r0x00018011002e:
        fVar12 = 0.0;
        if ((*(int32_t *)(iVar5 + 0x2288) == -1) && ((uVar10 & 1) != 0)) {
            fVar12 = (float)func_0x000180110b40();
            iVar11 = *(int64_t *)0x180781f28;
        }
    }
    fVar17 = 0.0;
    *(undefined *)(iVar5 + 0x227a) = 0;
    if (*(int32_t *)(iVar5 + 0x2288) != -1) {
        func_0x00018010eb00(*(int32_t *)(iVar5 + 0x2288), *(undefined4 *)(iVar5 + 0x2290), 
                            *(undefined4 *)(iVar5 + 0x227c), *(undefined4 *)(iVar5 + 0x2280));
    }
    if (*(char *)(iVar5 + 0x2278) == '\0') {
code_r0x0001801102b3:
        if (iVar3 == 0) {
code_r0x0001801104a9:
            fVar16 = 0.0;
            fVar18 = 0.0;
            fVar19 = 0.0;
            goto code_r0x0001801104b2;
        }
    } else {
        if (*(int32_t *)(iVar5 + 0x21d0) == 0) {
            *(undefined2 *)(iVar5 + 0x223a) = 0x101;
            *(undefined4 *)(iVar5 + 0x2248) = 0;
            if (*(char *)(iVar5 + 0x7e) != '\0') {
                *(undefined *)(iVar5 + 0x21cc) = 1;
            }
        }
        if ((*(int32_t *)(iVar5 + 0x2228) != 3) || (*(int32_t *)(iVar5 + 0x21e4) != 0)) goto code_r0x0001801102b3;
        if (iVar3 == 0) goto code_r0x0001801104a9;
        uVar10 = *(uint32_t *)(iVar5 + 0x227c);
        fVar18 = *(float *)(iVar3 + 0x284);
        fVar16 = *(float *)(iVar3 + 0x168);
        fVar19 = *(float *)(iVar3 + 0x16c);
        fVar1 = *(float *)(iVar3 + 0x278);
        uVar9 = uVar10 & 10;
        fVar14 = *(float *)(iVar3 + 0x27c);
        fVar2 = *(float *)(iVar3 + 0x280);
        pfVar7 = (float *)func_0x00018010c510(&var_8h, iVar3);
        fVar13 = *pfVar7 - *(float *)(iVar3 + 0xd4);
        fVar15 = pfVar7[1] - *(float *)(iVar3 + 0xd8);
        var_d0h._0_4_ = fVar13 + ((fVar2 + 1.0) - fVar16);
        var_d0h._4_4_ = fVar15 + ((fVar18 + 1.0) - fVar19);
        if (((uVar10 & 5) != 0) && (uVar9 != 0)) goto code_r0x0001801102b3;
        pfVar7 = (float *)((int64_t)*(int32_t *)(iVar5 + 0x21e4) * 0x10 + 0x458 + iVar3);
        fVar13 = ((fVar1 - 1.0) - fVar16) + fVar13;
        fVar15 = ((fVar14 - 1.0) - fVar19) + fVar15;
        if ((((*pfVar7 < fVar13) || (pfVar7[1] < fVar15)) || ((float)var_d0h < pfVar7[2])) ||
           (var_d0h._4_4_ < pfVar7[3])) {
            fVar17 = *(float *)(iVar3 + 0x318) * 0.5;
            if ((uVar10 & 5) == 0) {
                var_d8h._0_4_ = (float)var_d0h - fVar13;
                if (fVar17 <= (float)var_d0h - fVar13) {
                    var_d8h._0_4_ = fVar17;
                }
                var_d0h._0_4_ = (float)var_d0h - (float)var_d8h;
                var_d8h._0_4_ = (float)var_d8h + fVar13;
            } else {
                var_d8h._0_4_ = -3.402823e+38;
                var_d0h._0_4_ = 3.402823e+38;
            }
            if (uVar9 == 0) {
                var_d8h._4_4_ = var_d0h._4_4_ - fVar15;
                if (fVar17 <= var_d0h._4_4_ - fVar15) {
                    var_d8h._4_4_ = fVar17;
                }
                var_d0h._4_4_ = var_d0h._4_4_ - var_d8h._4_4_;
                var_d8h._4_4_ = var_d8h._4_4_ + fVar15;
            } else {
                var_d8h._4_4_ = -3.402823e+38;
                var_d0h._4_4_ = 3.402823e+38;
            }
            func_0x0001800f41b0(pfVar7, &var_d8h);
            *(undefined4 *)(iVar5 + 0x21d0) = 0;
        }
    }
    iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
    fVar17 = *(float *)(iVar3 + 0x458 + iVar8 * 0x10);
    fVar18 = *(float *)(iVar3 + 0x460 + iVar8 * 0x10);
    if (fVar18 < fVar17) {
code_r0x0001801102f4:
        fVar17 = 0.0;
        fVar16 = 0.0;
        fVar18 = 0.0;
        fVar19 = 0.0;
    } else {
        fVar16 = *(float *)(iVar3 + 0x45c + iVar8 * 0x10);
        fVar19 = *(float *)(iVar3 + 0x464 + iVar8 * 0x10);
        if (fVar19 < fVar16) goto code_r0x0001801102f4;
    }
    fVar17 = *(float *)(iVar3 + 0x168) + fVar17;
    fVar18 = *(float *)(iVar3 + 0x168) + fVar18;
    fVar16 = *(float *)(iVar3 + 0x16c) + fVar16;
    fVar19 = *(float *)(iVar3 + 0x16c) + fVar19;
    if ((*(uint32_t *)(iVar5 + 0x227c) >> 0xb & 1) != 0) {
        if (((*(float *)(iVar3 + 0x278) <= fVar17) && (*(float *)(iVar3 + 0x27c) <= fVar16)) &&
           ((fVar18 <= *(float *)(iVar3 + 0x280) && (fVar19 <= *(float *)(iVar3 + 0x284))))) {
            *(uint32_t *)(iVar5 + 0x227c) = *(uint32_t *)(iVar5 + 0x227c) | 0x20;
        }
        *(float *)(iVar5 + 0x22a8) = fVar16;
        fVar16 = fVar16 + fVar12;
        *(float *)(iVar5 + 0x22a4) = fVar17;
        *(float *)(iVar5 + 0x22ac) = fVar18;
        fVar12 = fVar19 + fVar12;
        *(float *)(iVar5 + 0x22b0) = fVar19;
        if (fVar16 < *(float *)(iVar5 + 0x22a8)) {
            *(float *)(iVar5 + 0x22a8) = fVar16;
        }
        bVar4 = fVar19 < fVar12;
        fVar19 = fVar12;
        if (bVar4) {
            *(float *)(iVar5 + 0x22b0) = fVar12;
        }
    }
    if (*(char *)(iVar5 + 0x2278) != '\0') {
        uVar10 = *(uint32_t *)(iVar5 + 0x2288);
        iVar8 = (int64_t)*(int32_t *)(iVar5 + 0x21e4);
        iVar3 = *(int64_t *)(iVar3 + 0x438);
        fVar12 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x168);
        fVar1 = *(float *)(*(int64_t *)(iVar11 + 0x21d8) + 0x16c);
        if ((*(uint8_t *)(iVar5 + 0x227c) & 0x80) == 0) {
            if (*(float *)(iVar3 + 0x478 + iVar8 * 8) == 3.402823e+38) {
                fVar14 = fVar17 + 1.0;
                if (fVar18 <= fVar17 + 1.0) {
                    fVar14 = fVar18;
                }
                *(float *)(iVar3 + 0x478 + iVar8 * 8) = fVar14 - fVar12;
            }
            if (*(float *)(iVar3 + 0x47c + iVar8 * 8) == 3.402823e+38) {
                *(float *)(iVar3 + 0x47c + iVar8 * 8) = (fVar19 + fVar16) * 0.5 - fVar1;
            }
        }
        if ((uVar10 - 2 < 2) && (fVar14 = *(float *)(iVar3 + 0x478 + iVar8 * 8), fVar14 != 3.402823e+38)) {
            fVar18 = fVar14 + fVar12;
            fVar17 = fVar18;
        } else if ((uVar10 < 2) && (fVar12 = *(float *)(iVar3 + 0x47c + iVar8 * 8), fVar12 != 3.402823e+38)) {
            fVar16 = fVar12 + fVar1;
            fVar19 = fVar16;
        }
    }
code_r0x0001801104b2:
    *(float *)(iVar5 + 0x2294) = fVar17;
    *(float *)(iVar5 + 0x2298) = fVar16;
    *(float *)(iVar5 + 0x229c) = fVar18;
    *(float *)(iVar5 + 0x22a0) = fVar19;
    return;
}

// ============================================================
// Function: FUN_180110530
// Address: 0x180110530
// Size: 244 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180110530(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined4 uVar11;
    float var_8h;
    int64_t var_ch;
    int64_t var_14h;
    int64_t var_20h;
    int64_t var_28h;
    float fStack_20;
    float var_1ch;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x22c0);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0) {
        piVar6 = (int64_t *)0x0;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) != 0) {
            piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2330);
        }
    }
    uVar5 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c);
    if (((((uVar5 & 0x400) != 0) && (piVar6 == (int64_t *)0x0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x22bc) == 1 || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22b8) == 0)))
        ) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2370) != 0)) {
        piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2368);
    }
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2288) - 2U < 2) {
        piVar9 = &var_ch;
        iVar7 = 4;
        piVar10 = &var_14h;
    } else {
        piVar9 = (int64_t *)&var_8h;
        iVar7 = 0;
        piVar10 = (int64_t *)((int64_t)&var_ch + 4);
    }
    if (piVar6 == (int64_t *)0x0) {
        if ((uVar5 & 0x400) != 0) {
            uVar5 = uVar5 | 0x4000;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) = uVar5;
        }
        if ((*(int32_t *)(iVar3 + 0x21d0) != 0) && ((uVar5 >> 0xe & 1) == 0)) {
            func_0x00018010e380();
        }
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x438) + (int64_t)*(int32_t *)(iVar3 + 0x21e4) * 8 + 0x478 + iVar7
         ) = 0x7f7fffff;
        return;
    }
    if ((uVar5 & 0x20) != 0) {
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2300) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2300) != *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0))) {
            piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x22f8);
        }
    }
    piVar1 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2330);
    if (((piVar6 != piVar1) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) != 0)) &&
       (*(int64_t *)(*piVar1 + 0x408) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8))) {
        if ((*(float *)(*(int64_t *)0x180781f28 + 0x2354) < *(float *)((int64_t)piVar6 + 0x24)) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x2354) == *(float *)((int64_t)piVar6 + 0x24) &&
            (*(float *)(*(int64_t *)0x180781f28 + 0x2358) <= *(float *)(piVar6 + 5) &&
             *(float *)(piVar6 + 5) != *(float *)(*(int64_t *)0x180781f28 + 0x2358))))) {
            piVar6 = piVar1;
        }
    }
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) == 0) {
        iVar7 = *piVar6;
        var_28h._0_4_ = *(float *)(iVar7 + 0x168) + *(float *)(piVar6 + 2);
        fStack_20 = *(float *)(iVar7 + 0x168) + *(float *)(piVar6 + 3);
        var_28h._4_4_ = *(float *)(iVar7 + 0x16c) + *(float *)((int64_t)piVar6 + 0x14);
        var_1ch = *(float *)(iVar7 + 0x16c) + *(float *)((int64_t)piVar6 + 0x1c);
        func_0x00018010c730(&var_8h, iVar7, &var_28h, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2280));
        if ((*(uint8_t *)(iVar3 + 0x227c) & 0x40) != 0) {
            if (*(int32_t *)(iVar3 + 0x2288) == 2) {
                uVar11 = *(undefined4 *)(*piVar6 + 0xe0);
            } else {
                uVar11 = 0;
            }
            iVar7 = *piVar6;
            *(undefined4 *)(iVar7 + 0xe8) = uVar11;
            *(undefined4 *)(iVar7 + 0xf0) = 0;
            *(undefined4 *)(iVar7 + 0xf8) = 0;
        }
    }
    iVar7 = *piVar6;
    iVar8 = *(int64_t *)(iVar3 + 0x21d8);
    if (iVar8 != iVar7) {
        *(int64_t *)(iVar3 + 0x21d8) = iVar7;
        *(undefined8 *)(iVar3 + 0x2230) = 0xffffffffffffffff;
        iVar8 = iVar7;
    }
    if ((*(int32_t *)(iVar3 + 0x1654) != *(int32_t *)(piVar6 + 1)) && ((*(uint32_t *)(iVar3 + 0x227c) & 0x8000) == 0)) {
        func_0x0001800f9f30(0, 0);
        iVar8 = *(int64_t *)(iVar3 + 0x21d8);
    }
    uVar5 = *(uint32_t *)(iVar3 + 0x227c);
    if (((*(int32_t *)(iVar3 + 0x21d0) != *(int32_t *)(piVar6 + 1)) || ((uVar5 >> 0xb & 1) != 0)) &&
       ((uVar5 >> 0xd & 1) == 0)) {
        *(undefined4 *)(iVar3 + 0x23a0) = *(undefined4 *)(iVar3 + 0x21e0);
        *(undefined4 *)(iVar3 + 0x23a4) = *(undefined4 *)(piVar6 + 1);
        *(undefined4 *)(iVar3 + 0x23a8) = *(undefined4 *)((int64_t)piVar6 + 0xc);
        *(undefined4 *)(iVar3 + 0x23ac) = *(undefined4 *)(iVar3 + 0x2284);
        *(uint8_t *)(iVar3 + 0x23b0) = (uint8_t)(uVar5 >> 10) & 1;
        *(uint8_t *)(iVar3 + 0x23b1) = (uint8_t)(*(uint32_t *)(piVar6 + 4) >> 0x15) & 1;
    }
    unique0x00005500 = *(undefined8 *)(*(int64_t *)(iVar8 + 0x438) + 0x478 + (int64_t)*(int32_t *)(iVar3 + 0x21e4) * 8);
    fcn.18010e3f0((uint64_t)*(uint32_t *)(piVar6 + 1), (int64_t)*(int32_t *)(iVar3 + 0x21e4), 
                  (uint64_t)*(uint32_t *)((int64_t)piVar6 + 0xc), (int64_t)(piVar6 + 2));
    if (piVar6[6] != -1) {
        *(int64_t *)(iVar3 + 0x2230) = piVar6[6];
    }
    if ((*(uint32_t *)(iVar3 + 0x227c) & 0x400) == 0) {
        iVar2 = *(int32_t *)(iVar3 + 0x21e4);
        var_8h = (*(float *)(piVar6 + 3) + *(float *)(piVar6 + 2)) * 0.5;
        var_ch._0_4_ = (*(float *)((int64_t)piVar6 + 0x1c) + *(float *)((int64_t)piVar6 + 0x14)) * 0.5;
        *(undefined4 *)piVar10 = *(undefined4 *)piVar9;
        *(undefined8 *)(*(int64_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x438) + 0x478 + (int64_t)iVar2 * 8) =
             stack0x00000010;
    }
    uVar5 = *(uint32_t *)(iVar3 + 0x227c);
    if (((uVar5 >> 10 & 1) != 0) && ((*(uint32_t *)(piVar6 + 4) & 0x100000) == 0)) {
        uVar5 = uVar5 & 0xffffefff;
        *(uint32_t *)(iVar3 + 0x227c) = uVar5;
    }
    if ((uVar5 >> 0xc & 1) != 0) {
        *(undefined4 *)(iVar3 + 0x2220) = *(undefined4 *)(piVar6 + 1);
        uVar4 = 0;
        *(undefined4 *)(iVar3 + 0x2224) = 0;
        if ((uVar5 >> 9 & 1) != 0) {
            uVar4 = 0x20;
            *(undefined4 *)(iVar3 + 0x2224) = 0x20;
        }
        if ((uVar5 >> 10 & 1) != 0) {
            *(uint32_t *)(iVar3 + 0x2224) = uVar4 | 0xd;
        }
    }
    if ((uVar5 >> 0xe & 1) == 0) {
        func_0x00018010e380();
    }
    return;
}

// ============================================================
// Function: FUN_180110624
// Address: 0x180110624
// Size: 640 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180110530(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined4 uVar11;
    float var_8h;
    int64_t var_ch;
    int64_t var_14h;
    int64_t var_20h;
    int64_t var_28h;
    float fStack_20;
    float var_1ch;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x22c0);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0) {
        piVar6 = (int64_t *)0x0;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) != 0) {
            piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2330);
        }
    }
    uVar5 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c);
    if (((((uVar5 & 0x400) != 0) && (piVar6 == (int64_t *)0x0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x22bc) == 1 || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22b8) == 0)))
        ) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2370) != 0)) {
        piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2368);
    }
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2288) - 2U < 2) {
        piVar9 = &var_ch;
        iVar7 = 4;
        piVar10 = &var_14h;
    } else {
        piVar9 = (int64_t *)&var_8h;
        iVar7 = 0;
        piVar10 = (int64_t *)((int64_t)&var_ch + 4);
    }
    if (piVar6 == (int64_t *)0x0) {
        if ((uVar5 & 0x400) != 0) {
            uVar5 = uVar5 | 0x4000;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) = uVar5;
        }
        if ((*(int32_t *)(iVar3 + 0x21d0) != 0) && ((uVar5 >> 0xe & 1) == 0)) {
            func_0x00018010e380();
        }
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x438) + (int64_t)*(int32_t *)(iVar3 + 0x21e4) * 8 + 0x478 + iVar7
         ) = 0x7f7fffff;
        return;
    }
    if ((uVar5 & 0x20) != 0) {
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2300) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2300) != *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0))) {
            piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x22f8);
        }
    }
    piVar1 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2330);
    if (((piVar6 != piVar1) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) != 0)) &&
       (*(int64_t *)(*piVar1 + 0x408) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8))) {
        if ((*(float *)(*(int64_t *)0x180781f28 + 0x2354) < *(float *)((int64_t)piVar6 + 0x24)) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x2354) == *(float *)((int64_t)piVar6 + 0x24) &&
            (*(float *)(*(int64_t *)0x180781f28 + 0x2358) <= *(float *)(piVar6 + 5) &&
             *(float *)(piVar6 + 5) != *(float *)(*(int64_t *)0x180781f28 + 0x2358))))) {
            piVar6 = piVar1;
        }
    }
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) == 0) {
        iVar7 = *piVar6;
        var_28h._0_4_ = *(float *)(iVar7 + 0x168) + *(float *)(piVar6 + 2);
        fStack_20 = *(float *)(iVar7 + 0x168) + *(float *)(piVar6 + 3);
        var_28h._4_4_ = *(float *)(iVar7 + 0x16c) + *(float *)((int64_t)piVar6 + 0x14);
        var_1ch = *(float *)(iVar7 + 0x16c) + *(float *)((int64_t)piVar6 + 0x1c);
        func_0x00018010c730(&var_8h, iVar7, &var_28h, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2280));
        if ((*(uint8_t *)(iVar3 + 0x227c) & 0x40) != 0) {
            if (*(int32_t *)(iVar3 + 0x2288) == 2) {
                uVar11 = *(undefined4 *)(*piVar6 + 0xe0);
            } else {
                uVar11 = 0;
            }
            iVar7 = *piVar6;
            *(undefined4 *)(iVar7 + 0xe8) = uVar11;
            *(undefined4 *)(iVar7 + 0xf0) = 0;
            *(undefined4 *)(iVar7 + 0xf8) = 0;
        }
    }
    iVar7 = *piVar6;
    iVar8 = *(int64_t *)(iVar3 + 0x21d8);
    if (iVar8 != iVar7) {
        *(int64_t *)(iVar3 + 0x21d8) = iVar7;
        *(undefined8 *)(iVar3 + 0x2230) = 0xffffffffffffffff;
        iVar8 = iVar7;
    }
    if ((*(int32_t *)(iVar3 + 0x1654) != *(int32_t *)(piVar6 + 1)) && ((*(uint32_t *)(iVar3 + 0x227c) & 0x8000) == 0)) {
        func_0x0001800f9f30(0, 0);
        iVar8 = *(int64_t *)(iVar3 + 0x21d8);
    }
    uVar5 = *(uint32_t *)(iVar3 + 0x227c);
    if (((*(int32_t *)(iVar3 + 0x21d0) != *(int32_t *)(piVar6 + 1)) || ((uVar5 >> 0xb & 1) != 0)) &&
       ((uVar5 >> 0xd & 1) == 0)) {
        *(undefined4 *)(iVar3 + 0x23a0) = *(undefined4 *)(iVar3 + 0x21e0);
        *(undefined4 *)(iVar3 + 0x23a4) = *(undefined4 *)(piVar6 + 1);
        *(undefined4 *)(iVar3 + 0x23a8) = *(undefined4 *)((int64_t)piVar6 + 0xc);
        *(undefined4 *)(iVar3 + 0x23ac) = *(undefined4 *)(iVar3 + 0x2284);
        *(uint8_t *)(iVar3 + 0x23b0) = (uint8_t)(uVar5 >> 10) & 1;
        *(uint8_t *)(iVar3 + 0x23b1) = (uint8_t)(*(uint32_t *)(piVar6 + 4) >> 0x15) & 1;
    }
    unique0x00005500 = *(undefined8 *)(*(int64_t *)(iVar8 + 0x438) + 0x478 + (int64_t)*(int32_t *)(iVar3 + 0x21e4) * 8);
    fcn.18010e3f0((uint64_t)*(uint32_t *)(piVar6 + 1), (int64_t)*(int32_t *)(iVar3 + 0x21e4), 
                  (uint64_t)*(uint32_t *)((int64_t)piVar6 + 0xc), (int64_t)(piVar6 + 2));
    if (piVar6[6] != -1) {
        *(int64_t *)(iVar3 + 0x2230) = piVar6[6];
    }
    if ((*(uint32_t *)(iVar3 + 0x227c) & 0x400) == 0) {
        iVar2 = *(int32_t *)(iVar3 + 0x21e4);
        var_8h = (*(float *)(piVar6 + 3) + *(float *)(piVar6 + 2)) * 0.5;
        var_ch._0_4_ = (*(float *)((int64_t)piVar6 + 0x1c) + *(float *)((int64_t)piVar6 + 0x14)) * 0.5;
        *(undefined4 *)piVar10 = *(undefined4 *)piVar9;
        *(undefined8 *)(*(int64_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x438) + 0x478 + (int64_t)iVar2 * 8) =
             stack0x00000010;
    }
    uVar5 = *(uint32_t *)(iVar3 + 0x227c);
    if (((uVar5 >> 10 & 1) != 0) && ((*(uint32_t *)(piVar6 + 4) & 0x100000) == 0)) {
        uVar5 = uVar5 & 0xffffefff;
        *(uint32_t *)(iVar3 + 0x227c) = uVar5;
    }
    if ((uVar5 >> 0xc & 1) != 0) {
        *(undefined4 *)(iVar3 + 0x2220) = *(undefined4 *)(piVar6 + 1);
        uVar4 = 0;
        *(undefined4 *)(iVar3 + 0x2224) = 0;
        if ((uVar5 >> 9 & 1) != 0) {
            uVar4 = 0x20;
            *(undefined4 *)(iVar3 + 0x2224) = 0x20;
        }
        if ((uVar5 >> 10 & 1) != 0) {
            *(uint32_t *)(iVar3 + 0x2224) = uVar4 | 0xd;
        }
    }
    if ((uVar5 >> 0xe & 1) == 0) {
        func_0x00018010e380();
    }
    return;
}

// ============================================================
// Function: FUN_1801108a4
// Address: 0x1801108a4
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch

void fcn.180110530(void)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    undefined4 uVar11;
    float var_8h;
    int64_t var_ch;
    int64_t var_14h;
    int64_t var_20h;
    int64_t var_28h;
    float fStack_20;
    float var_1ch;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)0x180781f28;
    piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x22c0);
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22c8) == 0) {
        piVar6 = (int64_t *)0x0;
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) != 0) {
            piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2330);
        }
    }
    uVar5 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c);
    if (((((uVar5 & 0x400) != 0) && (piVar6 == (int64_t *)0x0)) &&
        ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x22bc) == 1 || (*(int32_t *)(*(int64_t *)0x180781f28 + 0x22b8) == 0)))
        ) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2370) != 0)) {
        piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2368);
    }
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2288) - 2U < 2) {
        piVar9 = &var_ch;
        iVar7 = 4;
        piVar10 = &var_14h;
    } else {
        piVar9 = (int64_t *)&var_8h;
        iVar7 = 0;
        piVar10 = (int64_t *)((int64_t)&var_ch + 4);
    }
    if (piVar6 == (int64_t *)0x0) {
        if ((uVar5 & 0x400) != 0) {
            uVar5 = uVar5 | 0x4000;
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x227c) = uVar5;
        }
        if ((*(int32_t *)(iVar3 + 0x21d0) != 0) && ((uVar5 >> 0xe & 1) == 0)) {
            func_0x00018010e380();
        }
        *(undefined4 *)
         (*(int64_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x438) + (int64_t)*(int32_t *)(iVar3 + 0x21e4) * 8 + 0x478 + iVar7
         ) = 0x7f7fffff;
        return;
    }
    if ((uVar5 & 0x20) != 0) {
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x2300) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2300) != *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0))) {
            piVar6 = (int64_t *)(*(int64_t *)0x180781f28 + 0x22f8);
        }
    }
    piVar1 = (int64_t *)(*(int64_t *)0x180781f28 + 0x2330);
    if (((piVar6 != piVar1) && (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2338) != 0)) &&
       (*(int64_t *)(*piVar1 + 0x408) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8))) {
        if ((*(float *)(*(int64_t *)0x180781f28 + 0x2354) < *(float *)((int64_t)piVar6 + 0x24)) ||
           ((*(float *)(*(int64_t *)0x180781f28 + 0x2354) == *(float *)((int64_t)piVar6 + 0x24) &&
            (*(float *)(*(int64_t *)0x180781f28 + 0x2358) <= *(float *)(piVar6 + 5) &&
             *(float *)(piVar6 + 5) != *(float *)(*(int64_t *)0x180781f28 + 0x2358))))) {
            piVar6 = piVar1;
        }
    }
    if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x21e4) == 0) {
        iVar7 = *piVar6;
        var_28h._0_4_ = *(float *)(iVar7 + 0x168) + *(float *)(piVar6 + 2);
        fStack_20 = *(float *)(iVar7 + 0x168) + *(float *)(piVar6 + 3);
        var_28h._4_4_ = *(float *)(iVar7 + 0x16c) + *(float *)((int64_t)piVar6 + 0x14);
        var_1ch = *(float *)(iVar7 + 0x16c) + *(float *)((int64_t)piVar6 + 0x1c);
        func_0x00018010c730(&var_8h, iVar7, &var_28h, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2280));
        if ((*(uint8_t *)(iVar3 + 0x227c) & 0x40) != 0) {
            if (*(int32_t *)(iVar3 + 0x2288) == 2) {
                uVar11 = *(undefined4 *)(*piVar6 + 0xe0);
            } else {
                uVar11 = 0;
            }
            iVar7 = *piVar6;
            *(undefined4 *)(iVar7 + 0xe8) = uVar11;
            *(undefined4 *)(iVar7 + 0xf0) = 0;
            *(undefined4 *)(iVar7 + 0xf8) = 0;
        }
    }
    iVar7 = *piVar6;
    iVar8 = *(int64_t *)(iVar3 + 0x21d8);
    if (iVar8 != iVar7) {
        *(int64_t *)(iVar3 + 0x21d8) = iVar7;
        *(undefined8 *)(iVar3 + 0x2230) = 0xffffffffffffffff;
        iVar8 = iVar7;
    }
    if ((*(int32_t *)(iVar3 + 0x1654) != *(int32_t *)(piVar6 + 1)) && ((*(uint32_t *)(iVar3 + 0x227c) & 0x8000) == 0)) {
        func_0x0001800f9f30(0, 0);
        iVar8 = *(int64_t *)(iVar3 + 0x21d8);
    }
    uVar5 = *(uint32_t *)(iVar3 + 0x227c);
    if (((*(int32_t *)(iVar3 + 0x21d0) != *(int32_t *)(piVar6 + 1)) || ((uVar5 >> 0xb & 1) != 0)) &&
       ((uVar5 >> 0xd & 1) == 0)) {
        *(undefined4 *)(iVar3 + 0x23a0) = *(undefined4 *)(iVar3 + 0x21e0);
        *(undefined4 *)(iVar3 + 0x23a4) = *(undefined4 *)(piVar6 + 1);
        *(undefined4 *)(iVar3 + 0x23a8) = *(undefined4 *)((int64_t)piVar6 + 0xc);
        *(undefined4 *)(iVar3 + 0x23ac) = *(undefined4 *)(iVar3 + 0x2284);
        *(uint8_t *)(iVar3 + 0x23b0) = (uint8_t)(uVar5 >> 10) & 1;
        *(uint8_t *)(iVar3 + 0x23b1) = (uint8_t)(*(uint32_t *)(piVar6 + 4) >> 0x15) & 1;
    }
    unique0x00005500 = *(undefined8 *)(*(int64_t *)(iVar8 + 0x438) + 0x478 + (int64_t)*(int32_t *)(iVar3 + 0x21e4) * 8);
    fcn.18010e3f0((uint64_t)*(uint32_t *)(piVar6 + 1), (int64_t)*(int32_t *)(iVar3 + 0x21e4), 
                  (uint64_t)*(uint32_t *)((int64_t)piVar6 + 0xc), (int64_t)(piVar6 + 2));
    if (piVar6[6] != -1) {
        *(int64_t *)(iVar3 + 0x2230) = piVar6[6];
    }
    if ((*(uint32_t *)(iVar3 + 0x227c) & 0x400) == 0) {
        iVar2 = *(int32_t *)(iVar3 + 0x21e4);
        var_8h = (*(float *)(piVar6 + 3) + *(float *)(piVar6 + 2)) * 0.5;
        var_ch._0_4_ = (*(float *)((int64_t)piVar6 + 0x1c) + *(float *)((int64_t)piVar6 + 0x14)) * 0.5;
        *(undefined4 *)piVar10 = *(undefined4 *)piVar9;
        *(undefined8 *)(*(int64_t *)(*(int64_t *)(iVar3 + 0x21d8) + 0x438) + 0x478 + (int64_t)iVar2 * 8) =
             stack0x00000010;
    }
    uVar5 = *(uint32_t *)(iVar3 + 0x227c);
    if (((uVar5 >> 10 & 1) != 0) && ((*(uint32_t *)(piVar6 + 4) & 0x100000) == 0)) {
        uVar5 = uVar5 & 0xffffefff;
        *(uint32_t *)(iVar3 + 0x227c) = uVar5;
    }
    if ((uVar5 >> 0xc & 1) != 0) {
        *(undefined4 *)(iVar3 + 0x2220) = *(undefined4 *)(piVar6 + 1);
        uVar4 = 0;
        *(undefined4 *)(iVar3 + 0x2224) = 0;
        if ((uVar5 >> 9 & 1) != 0) {
            uVar4 = 0x20;
            *(undefined4 *)(iVar3 + 0x2224) = 0x20;
        }
        if ((uVar5 >> 10 & 1) != 0) {
            *(uint32_t *)(iVar3 + 0x2224) = uVar4 | 0xd;
        }
    }
    if ((uVar5 >> 0xe & 1) == 0) {
        func_0x00018010e380();
    }
    return;
}

// ============================================================
// Function: FUN_180110910
// Address: 0x180110910
// Size: 177 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x0001800f9feb)
// WARNING: Removing unreachable block (ram,0x0001800fa01c)
// WARNING: Removing unreachable block (ram,0x0001800fa02a)
// WARNING: Removing unreachable block (ram,0x0001800fa037)
// WARNING: Removing unreachable block (ram,0x0001800fa03d)
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180110910(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t arg1;
    uint8_t uVar4;
    int32_t iVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint64_t arg1_00;
    uint32_t uVar12;
    uint64_t arg2;
    int64_t iVar13;
    uint64_t arg3;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_10 [4];
    int64_t var_ch;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 2) == 0) ||
       ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar6 = false;
    } else {
        bVar6 = true;
    }
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 1) == 0) {
code_r0x000180110950:
        if (!bVar6) {
            return;
        }
        iVar14 = 0xffffffff;
        iVar13 = 0;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') {
            return;
        }
    } else {
        iVar13 = 0;
        iVar14 = 0xffffffff;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') goto code_r0x000180110950;
    }
    iVar7 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(iVar2 + 0x1654) != 0) {
        iVar11 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        if (iVar11 != 0) {
            piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) = iVar11;
            iVar10 = *(int32_t *)(iVar7 + 4);
            if (*piVar1 != iVar11) {
                iVar10 = *(int32_t *)(iVar7 + 4) + 1;
            }
            *(int32_t *)(iVar7 + 0x1688) = iVar10;
            *(undefined *)(iVar7 + 0x168c) = *(undefined *)(iVar7 + 0x1664);
            *(bool *)(iVar7 + 0x168d) = *(int32_t *)(iVar7 + 0x1658) == iVar11;
            if (*(int32_t *)(iVar7 + 0x2674) == iVar11) {
                func_0x000180143150();
            }
            if ((*(int64_t *)(iVar7 + 0x1600) != 0) &&
               (*(int32_t *)(iVar7 + 0x1654) == *(int32_t *)(*(int64_t *)(iVar7 + 0x1600) + 0xc4))) {
                func_0x0001800fac90();
            }
        }
        *(bool *)(iVar7 + 0x1660) = *(int32_t *)(iVar7 + 0x1654) != 0;
        if (*(int32_t *)(iVar7 + 0x1654) != 0) {
            *(undefined4 *)(iVar7 + 0x165c) = 0;
            *(undefined2 *)(iVar7 + 0x1663) = 0;
            *(undefined *)(iVar7 + 0x1667) = 0xff;
        }
        *(undefined4 *)(iVar7 + 0x1654) = 0;
        *(undefined2 *)(iVar7 + 0x1661) = 0;
        *(undefined8 *)(iVar7 + 0x1678) = 0;
        *(undefined2 *)(iVar7 + 0x1665) = 0;
        *(undefined4 *)(iVar7 + 0x1668) = 0;
        *(undefined *)(iVar7 + 0x1f6c) = 0;
        *(undefined4 *)(iVar7 + 0x1f68) = 0;
        return;
    }
    if (*(int32_t *)(iVar2 + 0x21e4) == 0) {
        iVar13 = *(int64_t *)(iVar2 + 0x21d8);
        if ((((iVar13 == 0) || (iVar13 == *(int64_t *)(iVar13 + 0x418))) ||
            (iVar3 = *(int64_t *)(iVar13 + 0x438), (*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0)) ||
           (arg1 = *(int64_t *)(iVar3 + 0x408), arg1 == 0)) {
            iVar11 = *(int32_t *)(iVar2 + 0x2120);
            if (((iVar11 < 1) ||
                (iVar14 = *(int64_t *)((int64_t)iVar11 * 0x38 + -0x30 + *(int64_t *)(iVar2 + 0x2128)), iVar14 == 0)) ||
               ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) {
                cVar8 = *(char *)(iVar2 + 0x7d);
                if ((*(char *)(iVar2 + 0x7c) == '\0') && (cVar8 == '\0')) {
                    cVar9 = '\0';
                } else {
                    cVar9 = cVar8;
                    if ((iVar13 != 0) && ((*(uint32_t *)(iVar13 + 0x14) & 0x4000000) != 0)) {
                        *(undefined4 *)(iVar13 + 0x450) = 0;
                        cVar8 = *(char *)(iVar2 + 0x7d);
                        cVar9 = cVar8;
                    }
                }
                if (((*(char *)(iVar2 + 0x7c) != '\0') || (cVar9 = cVar8, cVar8 != '\0')) &&
                   (*(undefined4 *)(iVar2 + 0x21d0) = 0, cVar9 != '\0')) {
                    fcn.18010e050(0, 0, 0);
                }
                return;
            }
            iVar11 = iVar11 + -1;
            iVar10 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2124);
            iVar2 = *(int64_t *)((int64_t)iVar11 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            arg1_00 = *(uint64_t *)((int64_t)iVar11 * 0x38 + 0x10 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if (iVar10 < iVar11) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar5 = iVar11;
                if (iVar11 < iVar10) {
                    iVar5 = iVar10;
                }
                func_0x00018011f970(*(int64_t *)0x180781f28 + 0x2120, iVar5);
            }
            iVar13 = *(int64_t *)0x180781f28;
            *(int32_t *)(iVar7 + 0x2120) = iVar11;
            if (iVar2 != 0) {
                if ((*(uint32_t *)(iVar2 + 0x14) >> 0x1c & 1) != 0) {
                    arg1_00 = *(uint64_t *)(iVar2 + 0x408);
                }
                if ((arg1_00 == 0) || (*(char *)(arg1_00 + 0x10a) != '\0')) {
                    arg2 = (uint64_t)(*(int32_t *)(iVar7 + 0x21e4) == 0);
                    arg3 = arg2;
                } else {
                    arg3 = 0;
                    iVar11 = -1;
                    uVar12 = *(uint32_t *)(iVar2 + 0x14) >> 0x18 & 1;
                    while (uVar12 != 0) {
                        iVar2 = *(int64_t *)(iVar2 + 0x408);
                        iVar11 = 0;
                        uVar12 = *(uint32_t *)(iVar2 + 0x14) & 0x1000000;
                    }
                    uVar12 = *(int16_t *)(iVar2 + 0x120) + iVar11;
                    arg1_00 = arg3;
                    if (-1 < (int32_t)uVar12) {
                        do {
                            arg1_00 = *(uint64_t *)(*(int64_t *)(iVar13 + 0x1598) + (uint64_t)uVar12 * 8);
                            if (((arg1_00 != 0) && (*(char *)(arg1_00 + 0x10a) != '\0')) &&
                               ((*(uint32_t *)(arg1_00 + 0x14) & 0x10200) != 0x10200)) break;
                            uVar12 = uVar12 - 1;
                            arg1_00 = arg3;
                        } while (-1 < (int32_t)uVar12);
                    }
                    arg2 = 1;
                }
                fcn.18010e050(arg1_00, arg2, arg3);
            }
            return;
        }
        fcn.18010e050(arg1, 0, iVar14);
        var_18h = CONCAT44(*(float *)(iVar3 + 100) - *(float *)(arg1 + 0x16c), 
                           *(float *)(iVar3 + 0x60) - *(float *)(arg1 + 0x168));
        _auStack_10 = CONCAT44((*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - *(float *)(arg1 + 0x16c), 
                               (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(arg1 + 0x168));
        fcn.18010e3f0((uint64_t)*(uint32_t *)(iVar3 + 0xcc), 0, 0, (int64_t)&var_18h);
    } else {
        fcn.18010ed90(0, iVar13);
    }
    iVar2 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == 0) ||
       ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) == 2) {
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 1;
        } else {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) != 3) goto code_r0x00018010e3ad;
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 2;
        }
        if (uVar4 != 0) {
code_r0x00018010e3ad:
            if (*(char *)(*(int64_t *)0x180781f28 + 0x7e) == '\0') {
                *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cd) = 0x101;
                return;
            }
            *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x101;
            *(undefined *)(iVar2 + 0x21ce) = 1;
            return;
        }
    }
    *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x100;
    *(undefined *)(iVar2 + 0x21ce) = 1;
    return;
}

// ============================================================
// Function: FUN_1801109c1
// Address: 0x1801109c1
// Size: 196 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x0001800f9feb)
// WARNING: Removing unreachable block (ram,0x0001800fa01c)
// WARNING: Removing unreachable block (ram,0x0001800fa02a)
// WARNING: Removing unreachable block (ram,0x0001800fa037)
// WARNING: Removing unreachable block (ram,0x0001800fa03d)
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180110910(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t arg1;
    uint8_t uVar4;
    int32_t iVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint64_t arg1_00;
    uint32_t uVar12;
    uint64_t arg2;
    int64_t iVar13;
    uint64_t arg3;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_10 [4];
    int64_t var_ch;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 2) == 0) ||
       ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar6 = false;
    } else {
        bVar6 = true;
    }
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 1) == 0) {
code_r0x000180110950:
        if (!bVar6) {
            return;
        }
        iVar14 = 0xffffffff;
        iVar13 = 0;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') {
            return;
        }
    } else {
        iVar13 = 0;
        iVar14 = 0xffffffff;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') goto code_r0x000180110950;
    }
    iVar7 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(iVar2 + 0x1654) != 0) {
        iVar11 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        if (iVar11 != 0) {
            piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) = iVar11;
            iVar10 = *(int32_t *)(iVar7 + 4);
            if (*piVar1 != iVar11) {
                iVar10 = *(int32_t *)(iVar7 + 4) + 1;
            }
            *(int32_t *)(iVar7 + 0x1688) = iVar10;
            *(undefined *)(iVar7 + 0x168c) = *(undefined *)(iVar7 + 0x1664);
            *(bool *)(iVar7 + 0x168d) = *(int32_t *)(iVar7 + 0x1658) == iVar11;
            if (*(int32_t *)(iVar7 + 0x2674) == iVar11) {
                func_0x000180143150();
            }
            if ((*(int64_t *)(iVar7 + 0x1600) != 0) &&
               (*(int32_t *)(iVar7 + 0x1654) == *(int32_t *)(*(int64_t *)(iVar7 + 0x1600) + 0xc4))) {
                func_0x0001800fac90();
            }
        }
        *(bool *)(iVar7 + 0x1660) = *(int32_t *)(iVar7 + 0x1654) != 0;
        if (*(int32_t *)(iVar7 + 0x1654) != 0) {
            *(undefined4 *)(iVar7 + 0x165c) = 0;
            *(undefined2 *)(iVar7 + 0x1663) = 0;
            *(undefined *)(iVar7 + 0x1667) = 0xff;
        }
        *(undefined4 *)(iVar7 + 0x1654) = 0;
        *(undefined2 *)(iVar7 + 0x1661) = 0;
        *(undefined8 *)(iVar7 + 0x1678) = 0;
        *(undefined2 *)(iVar7 + 0x1665) = 0;
        *(undefined4 *)(iVar7 + 0x1668) = 0;
        *(undefined *)(iVar7 + 0x1f6c) = 0;
        *(undefined4 *)(iVar7 + 0x1f68) = 0;
        return;
    }
    if (*(int32_t *)(iVar2 + 0x21e4) == 0) {
        iVar13 = *(int64_t *)(iVar2 + 0x21d8);
        if ((((iVar13 == 0) || (iVar13 == *(int64_t *)(iVar13 + 0x418))) ||
            (iVar3 = *(int64_t *)(iVar13 + 0x438), (*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0)) ||
           (arg1 = *(int64_t *)(iVar3 + 0x408), arg1 == 0)) {
            iVar11 = *(int32_t *)(iVar2 + 0x2120);
            if (((iVar11 < 1) ||
                (iVar14 = *(int64_t *)((int64_t)iVar11 * 0x38 + -0x30 + *(int64_t *)(iVar2 + 0x2128)), iVar14 == 0)) ||
               ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) {
                cVar8 = *(char *)(iVar2 + 0x7d);
                if ((*(char *)(iVar2 + 0x7c) == '\0') && (cVar8 == '\0')) {
                    cVar9 = '\0';
                } else {
                    cVar9 = cVar8;
                    if ((iVar13 != 0) && ((*(uint32_t *)(iVar13 + 0x14) & 0x4000000) != 0)) {
                        *(undefined4 *)(iVar13 + 0x450) = 0;
                        cVar8 = *(char *)(iVar2 + 0x7d);
                        cVar9 = cVar8;
                    }
                }
                if (((*(char *)(iVar2 + 0x7c) != '\0') || (cVar9 = cVar8, cVar8 != '\0')) &&
                   (*(undefined4 *)(iVar2 + 0x21d0) = 0, cVar9 != '\0')) {
                    fcn.18010e050(0, 0, 0);
                }
                return;
            }
            iVar11 = iVar11 + -1;
            iVar10 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2124);
            iVar2 = *(int64_t *)((int64_t)iVar11 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            arg1_00 = *(uint64_t *)((int64_t)iVar11 * 0x38 + 0x10 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if (iVar10 < iVar11) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar5 = iVar11;
                if (iVar11 < iVar10) {
                    iVar5 = iVar10;
                }
                func_0x00018011f970(*(int64_t *)0x180781f28 + 0x2120, iVar5);
            }
            iVar13 = *(int64_t *)0x180781f28;
            *(int32_t *)(iVar7 + 0x2120) = iVar11;
            if (iVar2 != 0) {
                if ((*(uint32_t *)(iVar2 + 0x14) >> 0x1c & 1) != 0) {
                    arg1_00 = *(uint64_t *)(iVar2 + 0x408);
                }
                if ((arg1_00 == 0) || (*(char *)(arg1_00 + 0x10a) != '\0')) {
                    arg2 = (uint64_t)(*(int32_t *)(iVar7 + 0x21e4) == 0);
                    arg3 = arg2;
                } else {
                    arg3 = 0;
                    iVar11 = -1;
                    uVar12 = *(uint32_t *)(iVar2 + 0x14) >> 0x18 & 1;
                    while (uVar12 != 0) {
                        iVar2 = *(int64_t *)(iVar2 + 0x408);
                        iVar11 = 0;
                        uVar12 = *(uint32_t *)(iVar2 + 0x14) & 0x1000000;
                    }
                    uVar12 = *(int16_t *)(iVar2 + 0x120) + iVar11;
                    arg1_00 = arg3;
                    if (-1 < (int32_t)uVar12) {
                        do {
                            arg1_00 = *(uint64_t *)(*(int64_t *)(iVar13 + 0x1598) + (uint64_t)uVar12 * 8);
                            if (((arg1_00 != 0) && (*(char *)(arg1_00 + 0x10a) != '\0')) &&
                               ((*(uint32_t *)(arg1_00 + 0x14) & 0x10200) != 0x10200)) break;
                            uVar12 = uVar12 - 1;
                            arg1_00 = arg3;
                        } while (-1 < (int32_t)uVar12);
                    }
                    arg2 = 1;
                }
                fcn.18010e050(arg1_00, arg2, arg3);
            }
            return;
        }
        fcn.18010e050(arg1, 0, iVar14);
        var_18h = CONCAT44(*(float *)(iVar3 + 100) - *(float *)(arg1 + 0x16c), 
                           *(float *)(iVar3 + 0x60) - *(float *)(arg1 + 0x168));
        _auStack_10 = CONCAT44((*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - *(float *)(arg1 + 0x16c), 
                               (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(arg1 + 0x168));
        fcn.18010e3f0((uint64_t)*(uint32_t *)(iVar3 + 0xcc), 0, 0, (int64_t)&var_18h);
    } else {
        fcn.18010ed90(0, iVar13);
    }
    iVar2 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == 0) ||
       ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) == 2) {
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 1;
        } else {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) != 3) goto code_r0x00018010e3ad;
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 2;
        }
        if (uVar4 != 0) {
code_r0x00018010e3ad:
            if (*(char *)(*(int64_t *)0x180781f28 + 0x7e) == '\0') {
                *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cd) = 0x101;
                return;
            }
            *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x101;
            *(undefined *)(iVar2 + 0x21ce) = 1;
            return;
        }
    }
    *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x100;
    *(undefined *)(iVar2 + 0x21ce) = 1;
    return;
}

// ============================================================
// Function: FUN_180110a85
// Address: 0x180110a85
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x0001800f9feb)
// WARNING: Removing unreachable block (ram,0x0001800fa01c)
// WARNING: Removing unreachable block (ram,0x0001800fa02a)
// WARNING: Removing unreachable block (ram,0x0001800fa037)
// WARNING: Removing unreachable block (ram,0x0001800fa03d)
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180110910(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t arg1;
    uint8_t uVar4;
    int32_t iVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint64_t arg1_00;
    uint32_t uVar12;
    uint64_t arg2;
    int64_t iVar13;
    uint64_t arg3;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_10 [4];
    int64_t var_ch;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 2) == 0) ||
       ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar6 = false;
    } else {
        bVar6 = true;
    }
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 1) == 0) {
code_r0x000180110950:
        if (!bVar6) {
            return;
        }
        iVar14 = 0xffffffff;
        iVar13 = 0;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') {
            return;
        }
    } else {
        iVar13 = 0;
        iVar14 = 0xffffffff;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') goto code_r0x000180110950;
    }
    iVar7 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(iVar2 + 0x1654) != 0) {
        iVar11 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        if (iVar11 != 0) {
            piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) = iVar11;
            iVar10 = *(int32_t *)(iVar7 + 4);
            if (*piVar1 != iVar11) {
                iVar10 = *(int32_t *)(iVar7 + 4) + 1;
            }
            *(int32_t *)(iVar7 + 0x1688) = iVar10;
            *(undefined *)(iVar7 + 0x168c) = *(undefined *)(iVar7 + 0x1664);
            *(bool *)(iVar7 + 0x168d) = *(int32_t *)(iVar7 + 0x1658) == iVar11;
            if (*(int32_t *)(iVar7 + 0x2674) == iVar11) {
                func_0x000180143150();
            }
            if ((*(int64_t *)(iVar7 + 0x1600) != 0) &&
               (*(int32_t *)(iVar7 + 0x1654) == *(int32_t *)(*(int64_t *)(iVar7 + 0x1600) + 0xc4))) {
                func_0x0001800fac90();
            }
        }
        *(bool *)(iVar7 + 0x1660) = *(int32_t *)(iVar7 + 0x1654) != 0;
        if (*(int32_t *)(iVar7 + 0x1654) != 0) {
            *(undefined4 *)(iVar7 + 0x165c) = 0;
            *(undefined2 *)(iVar7 + 0x1663) = 0;
            *(undefined *)(iVar7 + 0x1667) = 0xff;
        }
        *(undefined4 *)(iVar7 + 0x1654) = 0;
        *(undefined2 *)(iVar7 + 0x1661) = 0;
        *(undefined8 *)(iVar7 + 0x1678) = 0;
        *(undefined2 *)(iVar7 + 0x1665) = 0;
        *(undefined4 *)(iVar7 + 0x1668) = 0;
        *(undefined *)(iVar7 + 0x1f6c) = 0;
        *(undefined4 *)(iVar7 + 0x1f68) = 0;
        return;
    }
    if (*(int32_t *)(iVar2 + 0x21e4) == 0) {
        iVar13 = *(int64_t *)(iVar2 + 0x21d8);
        if ((((iVar13 == 0) || (iVar13 == *(int64_t *)(iVar13 + 0x418))) ||
            (iVar3 = *(int64_t *)(iVar13 + 0x438), (*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0)) ||
           (arg1 = *(int64_t *)(iVar3 + 0x408), arg1 == 0)) {
            iVar11 = *(int32_t *)(iVar2 + 0x2120);
            if (((iVar11 < 1) ||
                (iVar14 = *(int64_t *)((int64_t)iVar11 * 0x38 + -0x30 + *(int64_t *)(iVar2 + 0x2128)), iVar14 == 0)) ||
               ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) {
                cVar8 = *(char *)(iVar2 + 0x7d);
                if ((*(char *)(iVar2 + 0x7c) == '\0') && (cVar8 == '\0')) {
                    cVar9 = '\0';
                } else {
                    cVar9 = cVar8;
                    if ((iVar13 != 0) && ((*(uint32_t *)(iVar13 + 0x14) & 0x4000000) != 0)) {
                        *(undefined4 *)(iVar13 + 0x450) = 0;
                        cVar8 = *(char *)(iVar2 + 0x7d);
                        cVar9 = cVar8;
                    }
                }
                if (((*(char *)(iVar2 + 0x7c) != '\0') || (cVar9 = cVar8, cVar8 != '\0')) &&
                   (*(undefined4 *)(iVar2 + 0x21d0) = 0, cVar9 != '\0')) {
                    fcn.18010e050(0, 0, 0);
                }
                return;
            }
            iVar11 = iVar11 + -1;
            iVar10 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2124);
            iVar2 = *(int64_t *)((int64_t)iVar11 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            arg1_00 = *(uint64_t *)((int64_t)iVar11 * 0x38 + 0x10 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if (iVar10 < iVar11) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar5 = iVar11;
                if (iVar11 < iVar10) {
                    iVar5 = iVar10;
                }
                func_0x00018011f970(*(int64_t *)0x180781f28 + 0x2120, iVar5);
            }
            iVar13 = *(int64_t *)0x180781f28;
            *(int32_t *)(iVar7 + 0x2120) = iVar11;
            if (iVar2 != 0) {
                if ((*(uint32_t *)(iVar2 + 0x14) >> 0x1c & 1) != 0) {
                    arg1_00 = *(uint64_t *)(iVar2 + 0x408);
                }
                if ((arg1_00 == 0) || (*(char *)(arg1_00 + 0x10a) != '\0')) {
                    arg2 = (uint64_t)(*(int32_t *)(iVar7 + 0x21e4) == 0);
                    arg3 = arg2;
                } else {
                    arg3 = 0;
                    iVar11 = -1;
                    uVar12 = *(uint32_t *)(iVar2 + 0x14) >> 0x18 & 1;
                    while (uVar12 != 0) {
                        iVar2 = *(int64_t *)(iVar2 + 0x408);
                        iVar11 = 0;
                        uVar12 = *(uint32_t *)(iVar2 + 0x14) & 0x1000000;
                    }
                    uVar12 = *(int16_t *)(iVar2 + 0x120) + iVar11;
                    arg1_00 = arg3;
                    if (-1 < (int32_t)uVar12) {
                        do {
                            arg1_00 = *(uint64_t *)(*(int64_t *)(iVar13 + 0x1598) + (uint64_t)uVar12 * 8);
                            if (((arg1_00 != 0) && (*(char *)(arg1_00 + 0x10a) != '\0')) &&
                               ((*(uint32_t *)(arg1_00 + 0x14) & 0x10200) != 0x10200)) break;
                            uVar12 = uVar12 - 1;
                            arg1_00 = arg3;
                        } while (-1 < (int32_t)uVar12);
                    }
                    arg2 = 1;
                }
                fcn.18010e050(arg1_00, arg2, arg3);
            }
            return;
        }
        fcn.18010e050(arg1, 0, iVar14);
        var_18h = CONCAT44(*(float *)(iVar3 + 100) - *(float *)(arg1 + 0x16c), 
                           *(float *)(iVar3 + 0x60) - *(float *)(arg1 + 0x168));
        _auStack_10 = CONCAT44((*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - *(float *)(arg1 + 0x16c), 
                               (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(arg1 + 0x168));
        fcn.18010e3f0((uint64_t)*(uint32_t *)(iVar3 + 0xcc), 0, 0, (int64_t)&var_18h);
    } else {
        fcn.18010ed90(0, iVar13);
    }
    iVar2 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == 0) ||
       ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) == 2) {
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 1;
        } else {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) != 3) goto code_r0x00018010e3ad;
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 2;
        }
        if (uVar4 != 0) {
code_r0x00018010e3ad:
            if (*(char *)(*(int64_t *)0x180781f28 + 0x7e) == '\0') {
                *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cd) = 0x101;
                return;
            }
            *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x101;
            *(undefined *)(iVar2 + 0x21ce) = 1;
            return;
        }
    }
    *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x100;
    *(undefined *)(iVar2 + 0x21ce) = 1;
    return;
}

// ============================================================
// Function: FUN_180110aca
// Address: 0x180110aca
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x0001800f9feb)
// WARNING: Removing unreachable block (ram,0x0001800fa01c)
// WARNING: Removing unreachable block (ram,0x0001800fa02a)
// WARNING: Removing unreachable block (ram,0x0001800fa037)
// WARNING: Removing unreachable block (ram,0x0001800fa03d)
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180110910(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t arg1;
    uint8_t uVar4;
    int32_t iVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint64_t arg1_00;
    uint32_t uVar12;
    uint64_t arg2;
    int64_t iVar13;
    uint64_t arg3;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_10 [4];
    int64_t var_ch;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 2) == 0) ||
       ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar6 = false;
    } else {
        bVar6 = true;
    }
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 1) == 0) {
code_r0x000180110950:
        if (!bVar6) {
            return;
        }
        iVar14 = 0xffffffff;
        iVar13 = 0;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') {
            return;
        }
    } else {
        iVar13 = 0;
        iVar14 = 0xffffffff;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') goto code_r0x000180110950;
    }
    iVar7 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(iVar2 + 0x1654) != 0) {
        iVar11 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        if (iVar11 != 0) {
            piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) = iVar11;
            iVar10 = *(int32_t *)(iVar7 + 4);
            if (*piVar1 != iVar11) {
                iVar10 = *(int32_t *)(iVar7 + 4) + 1;
            }
            *(int32_t *)(iVar7 + 0x1688) = iVar10;
            *(undefined *)(iVar7 + 0x168c) = *(undefined *)(iVar7 + 0x1664);
            *(bool *)(iVar7 + 0x168d) = *(int32_t *)(iVar7 + 0x1658) == iVar11;
            if (*(int32_t *)(iVar7 + 0x2674) == iVar11) {
                func_0x000180143150();
            }
            if ((*(int64_t *)(iVar7 + 0x1600) != 0) &&
               (*(int32_t *)(iVar7 + 0x1654) == *(int32_t *)(*(int64_t *)(iVar7 + 0x1600) + 0xc4))) {
                func_0x0001800fac90();
            }
        }
        *(bool *)(iVar7 + 0x1660) = *(int32_t *)(iVar7 + 0x1654) != 0;
        if (*(int32_t *)(iVar7 + 0x1654) != 0) {
            *(undefined4 *)(iVar7 + 0x165c) = 0;
            *(undefined2 *)(iVar7 + 0x1663) = 0;
            *(undefined *)(iVar7 + 0x1667) = 0xff;
        }
        *(undefined4 *)(iVar7 + 0x1654) = 0;
        *(undefined2 *)(iVar7 + 0x1661) = 0;
        *(undefined8 *)(iVar7 + 0x1678) = 0;
        *(undefined2 *)(iVar7 + 0x1665) = 0;
        *(undefined4 *)(iVar7 + 0x1668) = 0;
        *(undefined *)(iVar7 + 0x1f6c) = 0;
        *(undefined4 *)(iVar7 + 0x1f68) = 0;
        return;
    }
    if (*(int32_t *)(iVar2 + 0x21e4) == 0) {
        iVar13 = *(int64_t *)(iVar2 + 0x21d8);
        if ((((iVar13 == 0) || (iVar13 == *(int64_t *)(iVar13 + 0x418))) ||
            (iVar3 = *(int64_t *)(iVar13 + 0x438), (*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0)) ||
           (arg1 = *(int64_t *)(iVar3 + 0x408), arg1 == 0)) {
            iVar11 = *(int32_t *)(iVar2 + 0x2120);
            if (((iVar11 < 1) ||
                (iVar14 = *(int64_t *)((int64_t)iVar11 * 0x38 + -0x30 + *(int64_t *)(iVar2 + 0x2128)), iVar14 == 0)) ||
               ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) {
                cVar8 = *(char *)(iVar2 + 0x7d);
                if ((*(char *)(iVar2 + 0x7c) == '\0') && (cVar8 == '\0')) {
                    cVar9 = '\0';
                } else {
                    cVar9 = cVar8;
                    if ((iVar13 != 0) && ((*(uint32_t *)(iVar13 + 0x14) & 0x4000000) != 0)) {
                        *(undefined4 *)(iVar13 + 0x450) = 0;
                        cVar8 = *(char *)(iVar2 + 0x7d);
                        cVar9 = cVar8;
                    }
                }
                if (((*(char *)(iVar2 + 0x7c) != '\0') || (cVar9 = cVar8, cVar8 != '\0')) &&
                   (*(undefined4 *)(iVar2 + 0x21d0) = 0, cVar9 != '\0')) {
                    fcn.18010e050(0, 0, 0);
                }
                return;
            }
            iVar11 = iVar11 + -1;
            iVar10 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2124);
            iVar2 = *(int64_t *)((int64_t)iVar11 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            arg1_00 = *(uint64_t *)((int64_t)iVar11 * 0x38 + 0x10 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if (iVar10 < iVar11) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar5 = iVar11;
                if (iVar11 < iVar10) {
                    iVar5 = iVar10;
                }
                func_0x00018011f970(*(int64_t *)0x180781f28 + 0x2120, iVar5);
            }
            iVar13 = *(int64_t *)0x180781f28;
            *(int32_t *)(iVar7 + 0x2120) = iVar11;
            if (iVar2 != 0) {
                if ((*(uint32_t *)(iVar2 + 0x14) >> 0x1c & 1) != 0) {
                    arg1_00 = *(uint64_t *)(iVar2 + 0x408);
                }
                if ((arg1_00 == 0) || (*(char *)(arg1_00 + 0x10a) != '\0')) {
                    arg2 = (uint64_t)(*(int32_t *)(iVar7 + 0x21e4) == 0);
                    arg3 = arg2;
                } else {
                    arg3 = 0;
                    iVar11 = -1;
                    uVar12 = *(uint32_t *)(iVar2 + 0x14) >> 0x18 & 1;
                    while (uVar12 != 0) {
                        iVar2 = *(int64_t *)(iVar2 + 0x408);
                        iVar11 = 0;
                        uVar12 = *(uint32_t *)(iVar2 + 0x14) & 0x1000000;
                    }
                    uVar12 = *(int16_t *)(iVar2 + 0x120) + iVar11;
                    arg1_00 = arg3;
                    if (-1 < (int32_t)uVar12) {
                        do {
                            arg1_00 = *(uint64_t *)(*(int64_t *)(iVar13 + 0x1598) + (uint64_t)uVar12 * 8);
                            if (((arg1_00 != 0) && (*(char *)(arg1_00 + 0x10a) != '\0')) &&
                               ((*(uint32_t *)(arg1_00 + 0x14) & 0x10200) != 0x10200)) break;
                            uVar12 = uVar12 - 1;
                            arg1_00 = arg3;
                        } while (-1 < (int32_t)uVar12);
                    }
                    arg2 = 1;
                }
                fcn.18010e050(arg1_00, arg2, arg3);
            }
            return;
        }
        fcn.18010e050(arg1, 0, iVar14);
        var_18h = CONCAT44(*(float *)(iVar3 + 100) - *(float *)(arg1 + 0x16c), 
                           *(float *)(iVar3 + 0x60) - *(float *)(arg1 + 0x168));
        _auStack_10 = CONCAT44((*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - *(float *)(arg1 + 0x16c), 
                               (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(arg1 + 0x168));
        fcn.18010e3f0((uint64_t)*(uint32_t *)(iVar3 + 0xcc), 0, 0, (int64_t)&var_18h);
    } else {
        fcn.18010ed90(0, iVar13);
    }
    iVar2 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == 0) ||
       ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) == 2) {
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 1;
        } else {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) != 3) goto code_r0x00018010e3ad;
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 2;
        }
        if (uVar4 != 0) {
code_r0x00018010e3ad:
            if (*(char *)(*(int64_t *)0x180781f28 + 0x7e) == '\0') {
                *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cd) = 0x101;
                return;
            }
            *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x101;
            *(undefined *)(iVar2 + 0x21ce) = 1;
            return;
        }
    }
    *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x100;
    *(undefined *)(iVar2 + 0x21ce) = 1;
    return;
}

// ============================================================
// Function: FUN_180110b26
// Address: 0x180110b26
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Removing unreachable block (ram,0x0001800f9feb)
// WARNING: Removing unreachable block (ram,0x0001800fa01c)
// WARNING: Removing unreachable block (ram,0x0001800fa02a)
// WARNING: Removing unreachable block (ram,0x0001800fa037)
// WARNING: Removing unreachable block (ram,0x0001800fa03d)
// WARNING: [rz-ghidra] Removing arg arg_2120h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_21e4h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.180110910(void)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t arg1;
    uint8_t uVar4;
    int32_t iVar5;
    bool bVar6;
    int64_t iVar7;
    char cVar8;
    char cVar9;
    int32_t iVar10;
    int32_t iVar11;
    uint64_t arg1_00;
    uint32_t uVar12;
    uint64_t arg2;
    int64_t iVar13;
    uint64_t arg3;
    int64_t iVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_10 [4];
    int64_t var_ch;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 2) == 0) ||
       ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x34) & 1) == 0)) {
        bVar6 = false;
    } else {
        bVar6 = true;
    }
    if ((*(uint32_t *)(*(int64_t *)0x180781f28 + 0x30) & 1) == 0) {
code_r0x000180110950:
        if (!bVar6) {
            return;
        }
        iVar14 = 0xffffffff;
        iVar13 = 0;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') {
            return;
        }
    } else {
        iVar13 = 0;
        iVar14 = 0xffffffff;
        cVar8 = func_0x000180107dc0();
        if (cVar8 == '\0') goto code_r0x000180110950;
    }
    iVar7 = *(int64_t *)0x180781f28;
    if (*(int32_t *)(iVar2 + 0x1654) != 0) {
        iVar11 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x1654);
        if (iVar11 != 0) {
            piVar1 = (int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8);
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1684) = iVar11;
            iVar10 = *(int32_t *)(iVar7 + 4);
            if (*piVar1 != iVar11) {
                iVar10 = *(int32_t *)(iVar7 + 4) + 1;
            }
            *(int32_t *)(iVar7 + 0x1688) = iVar10;
            *(undefined *)(iVar7 + 0x168c) = *(undefined *)(iVar7 + 0x1664);
            *(bool *)(iVar7 + 0x168d) = *(int32_t *)(iVar7 + 0x1658) == iVar11;
            if (*(int32_t *)(iVar7 + 0x2674) == iVar11) {
                func_0x000180143150();
            }
            if ((*(int64_t *)(iVar7 + 0x1600) != 0) &&
               (*(int32_t *)(iVar7 + 0x1654) == *(int32_t *)(*(int64_t *)(iVar7 + 0x1600) + 0xc4))) {
                func_0x0001800fac90();
            }
        }
        *(bool *)(iVar7 + 0x1660) = *(int32_t *)(iVar7 + 0x1654) != 0;
        if (*(int32_t *)(iVar7 + 0x1654) != 0) {
            *(undefined4 *)(iVar7 + 0x165c) = 0;
            *(undefined2 *)(iVar7 + 0x1663) = 0;
            *(undefined *)(iVar7 + 0x1667) = 0xff;
        }
        *(undefined4 *)(iVar7 + 0x1654) = 0;
        *(undefined2 *)(iVar7 + 0x1661) = 0;
        *(undefined8 *)(iVar7 + 0x1678) = 0;
        *(undefined2 *)(iVar7 + 0x1665) = 0;
        *(undefined4 *)(iVar7 + 0x1668) = 0;
        *(undefined *)(iVar7 + 0x1f6c) = 0;
        *(undefined4 *)(iVar7 + 0x1f68) = 0;
        return;
    }
    if (*(int32_t *)(iVar2 + 0x21e4) == 0) {
        iVar13 = *(int64_t *)(iVar2 + 0x21d8);
        if ((((iVar13 == 0) || (iVar13 == *(int64_t *)(iVar13 + 0x418))) ||
            (iVar3 = *(int64_t *)(iVar13 + 0x438), (*(uint32_t *)(iVar3 + 0x14) & 0x4000000) != 0)) ||
           (arg1 = *(int64_t *)(iVar3 + 0x408), arg1 == 0)) {
            iVar11 = *(int32_t *)(iVar2 + 0x2120);
            if (((iVar11 < 1) ||
                (iVar14 = *(int64_t *)((int64_t)iVar11 * 0x38 + -0x30 + *(int64_t *)(iVar2 + 0x2128)), iVar14 == 0)) ||
               ((*(uint32_t *)(iVar14 + 0x14) & 0x8000000) != 0)) {
                cVar8 = *(char *)(iVar2 + 0x7d);
                if ((*(char *)(iVar2 + 0x7c) == '\0') && (cVar8 == '\0')) {
                    cVar9 = '\0';
                } else {
                    cVar9 = cVar8;
                    if ((iVar13 != 0) && ((*(uint32_t *)(iVar13 + 0x14) & 0x4000000) != 0)) {
                        *(undefined4 *)(iVar13 + 0x450) = 0;
                        cVar8 = *(char *)(iVar2 + 0x7d);
                        cVar9 = cVar8;
                    }
                }
                if (((*(char *)(iVar2 + 0x7c) != '\0') || (cVar9 = cVar8, cVar8 != '\0')) &&
                   (*(undefined4 *)(iVar2 + 0x21d0) = 0, cVar9 != '\0')) {
                    fcn.18010e050(0, 0, 0);
                }
                return;
            }
            iVar11 = iVar11 + -1;
            iVar10 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2124);
            iVar2 = *(int64_t *)((int64_t)iVar11 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            arg1_00 = *(uint64_t *)((int64_t)iVar11 * 0x38 + 0x10 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
            if (iVar10 < iVar11) {
                if (iVar10 == 0) {
                    iVar10 = 8;
                } else {
                    iVar10 = iVar10 / 2 + iVar10;
                }
                iVar5 = iVar11;
                if (iVar11 < iVar10) {
                    iVar5 = iVar10;
                }
                func_0x00018011f970(*(int64_t *)0x180781f28 + 0x2120, iVar5);
            }
            iVar13 = *(int64_t *)0x180781f28;
            *(int32_t *)(iVar7 + 0x2120) = iVar11;
            if (iVar2 != 0) {
                if ((*(uint32_t *)(iVar2 + 0x14) >> 0x1c & 1) != 0) {
                    arg1_00 = *(uint64_t *)(iVar2 + 0x408);
                }
                if ((arg1_00 == 0) || (*(char *)(arg1_00 + 0x10a) != '\0')) {
                    arg2 = (uint64_t)(*(int32_t *)(iVar7 + 0x21e4) == 0);
                    arg3 = arg2;
                } else {
                    arg3 = 0;
                    iVar11 = -1;
                    uVar12 = *(uint32_t *)(iVar2 + 0x14) >> 0x18 & 1;
                    while (uVar12 != 0) {
                        iVar2 = *(int64_t *)(iVar2 + 0x408);
                        iVar11 = 0;
                        uVar12 = *(uint32_t *)(iVar2 + 0x14) & 0x1000000;
                    }
                    uVar12 = *(int16_t *)(iVar2 + 0x120) + iVar11;
                    arg1_00 = arg3;
                    if (-1 < (int32_t)uVar12) {
                        do {
                            arg1_00 = *(uint64_t *)(*(int64_t *)(iVar13 + 0x1598) + (uint64_t)uVar12 * 8);
                            if (((arg1_00 != 0) && (*(char *)(arg1_00 + 0x10a) != '\0')) &&
                               ((*(uint32_t *)(arg1_00 + 0x14) & 0x10200) != 0x10200)) break;
                            uVar12 = uVar12 - 1;
                            arg1_00 = arg3;
                        } while (-1 < (int32_t)uVar12);
                    }
                    arg2 = 1;
                }
                fcn.18010e050(arg1_00, arg2, arg3);
            }
            return;
        }
        fcn.18010e050(arg1, 0, iVar14);
        var_18h = CONCAT44(*(float *)(iVar3 + 100) - *(float *)(arg1 + 0x16c), 
                           *(float *)(iVar3 + 0x60) - *(float *)(arg1 + 0x168));
        _auStack_10 = CONCAT44((*(float *)(iVar3 + 100) + *(float *)(iVar3 + 0x6c)) - *(float *)(arg1 + 0x16c), 
                               (*(float *)(iVar3 + 0x60) + *(float *)(iVar3 + 0x68)) - *(float *)(arg1 + 0x168));
        fcn.18010e3f0((uint64_t)*(uint32_t *)(iVar3 + 0xcc), 0, 0, (int64_t)&var_18h);
    } else {
        fcn.18010ed90(0, iVar13);
    }
    iVar2 = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == 0) ||
       ((*(uint32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) + 0x14) & 0x10000) == 0)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) == 2) {
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 1;
        } else {
            if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x2228) != 3) goto code_r0x00018010e3ad;
            uVar4 = *(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 2;
        }
        if (uVar4 != 0) {
code_r0x00018010e3ad:
            if (*(char *)(*(int64_t *)0x180781f28 + 0x7e) == '\0') {
                *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cd) = 0x101;
                return;
            }
            *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x101;
            *(undefined *)(iVar2 + 0x21ce) = 1;
            return;
        }
    }
    *(undefined2 *)(*(int64_t *)0x180781f28 + 0x21cc) = 0x100;
    *(undefined *)(iVar2 + 0x21ce) = 1;
    return;
}

// ============================================================
// Function: FUN_180110b40
// Address: 0x180110b40
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180110b40(void)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    char cVar4;
    char cVar5;
    char cVar6;
    int64_t iVar7;
    char cVar8;
    float fVar9;
    undefined4 uVar10;
    float fVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8);
    if (((*(uint32_t *)(iVar2 + 0x14) & 0x10000) == 0) && (*(int64_t *)(*(int64_t *)0x180781f28 + 0x23c0) == 0)) {
        if (*(char *)(*(int64_t *)0x180781f28 + 400) == '\0') {
            cVar6 = '\0';
        } else if (((*(char *)(*(int64_t *)0x180781f28 + 0x1f6c) == '\0') ||
                   (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == -1)) &&
                  (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1708) == -1)) {
            cVar6 = '\x01';
        } else {
            cVar6 = '\0';
        }
        if (*(char *)(*(int64_t *)0x180781f28 + 0x1a0) == '\0') {
            cVar8 = '\0';
        } else if (((*(char *)(*(int64_t *)0x180781f28 + 0x1f6c) == '\0') ||
                   (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == -1)) &&
                  (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1714) == -1)) {
            cVar8 = '\x01';
        } else {
            cVar8 = '\0';
        }
        cVar4 = func_0x000180107dc0(0x207, 1, 0xffffffff);
        iVar7 = 1;
        cVar5 = func_0x000180107dc0(0x208, 1, 0xffffffff);
        if ((cVar6 != cVar8) || (cVar4 != cVar5)) {
            if (*(int32_t *)(iVar3 + 0x21e4) != 0) {
                fcn.18010ed90(0, iVar7);
            }
            if (((*(uint8_t *)(iVar2 + 0x1b4) & 1) != 0) || (*(char *)(iVar2 + 0x1ba) == '\0')) {
                iVar7 = (int64_t)*(int32_t *)(iVar3 + 0x21e4);
                fVar11 = ((*(float *)(iVar2 + 0x284) - *(float *)(iVar2 + 0x27c)) - *(float *)(iVar2 + 0x318)) +
                         (*(float *)(iVar2 + 0x464 + iVar7 * 0x10) - *(float *)(iVar2 + 0x45c + iVar7 * 0x10));
                fVar9 = 0.0;
                if (0.0 <= fVar11) {
                    fVar9 = fVar11;
                }
                cVar6 = func_0x000180107dc0(0x205, 1, 0);
                if (cVar6 != '\0') {
                    uVar10 = 0x80000000;
                    fVar9 = (float)((uint32_t)fVar9 ^ 0x80000000);
                    *(undefined4 *)(iVar3 + 0x2288) = 3;
                    *(undefined4 *)(iVar3 + 0x2290) = 2;
                    *(undefined4 *)(iVar3 + 0x227c) = 0x810;
                    goto code_r0x000180110cd3;
                }
                cVar6 = func_0x000180107dc0(0x206, 1, 0);
                if (cVar6 == '\0') {
                    fVar9 = 0.0;
                    if (cVar4 != '\0') {
                        fVar9 = *(float *)(iVar2 + 0x458 + iVar7 * 0x10);
                        pfVar1 = (float *)(iVar2 + 0x460 + iVar7 * 0x10);
                        *(undefined4 *)(iVar2 + 0x464 + iVar7 * 0x10) = 0;
                        *(undefined4 *)(iVar2 + 0x45c + iVar7 * 0x10) = 0;
                        if (*pfVar1 <= fVar9 && fVar9 != *pfVar1) {
                            *(undefined4 *)(iVar2 + 0x460 + iVar7 * 0x10) = 0;
                            *(undefined4 *)(iVar2 + 0x458 + iVar7 * 0x10) = 0;
                        }
                        fVar9 = 0.0;
                        uVar10 = 0;
                        *(undefined4 *)(iVar3 + 0x2288) = 3;
                        *(undefined4 *)(iVar3 + 0x227c) = 0x50;
                        goto code_r0x000180110cd3;
                    }
                    if (cVar5 != '\0') {
                        uVar10 = *(undefined4 *)(iVar2 + 0x7c);
                        fVar11 = *(float *)(iVar2 + 0x458 + iVar7 * 0x10);
                        pfVar1 = (float *)(iVar2 + 0x460 + iVar7 * 0x10);
                        *(undefined4 *)(iVar2 + 0x464 + iVar7 * 0x10) = uVar10;
                        *(undefined4 *)(iVar2 + 0x45c + iVar7 * 0x10) = uVar10;
                        if (*pfVar1 <= fVar11 && fVar11 != *pfVar1) {
                            *(undefined4 *)(iVar2 + 0x460 + iVar7 * 0x10) = 0;
                            *(undefined4 *)(iVar2 + 0x458 + iVar7 * 0x10) = 0;
                        }
                        *(undefined4 *)(iVar3 + 0x227c) = 0x50;
                        goto code_r0x000180110e6c;
                    }
                } else {
                    *(undefined4 *)(iVar3 + 0x2290) = 3;
                    *(undefined4 *)(iVar3 + 0x227c) = 0x810;
code_r0x000180110e6c:
                    *(undefined4 *)(iVar3 + 0x2288) = 2;
                }
                uVar10 = 0;
                goto code_r0x000180110cd3;
            }
            cVar6 = func_0x000180107dc0(0x205, 1, 0xffffffff);
            if (cVar6 == '\0') {
                cVar6 = func_0x000180107dc0(0x206, 1, 0xffffffff);
                if (cVar6 != '\0') {
                    fVar9 = (*(float *)(iVar2 + 0x284) - *(float *)(iVar2 + 0x27c)) + *(float *)(iVar2 + 0xd8);
                    goto code_r0x000180110cba;
                }
                if (cVar4 == '\0') {
                    if (cVar5 == '\0') goto code_r0x000180110cd0;
                    *(undefined4 *)(iVar2 + 0xe8) = *(undefined4 *)(iVar2 + 0xe0);
                } else {
                    *(undefined4 *)(iVar2 + 0xe8) = 0;
                }
            } else {
                fVar9 = *(float *)(iVar2 + 0xd8) - (*(float *)(iVar2 + 0x284) - *(float *)(iVar2 + 0x27c));
code_r0x000180110cba:
                *(float *)(iVar2 + 0xe8) = fVar9;
            }
            *(undefined4 *)(iVar2 + 0xf8) = 0;
            *(undefined4 *)(iVar2 + 0xf0) = 0;
        }
    }
code_r0x000180110cd0:
    fVar9 = 0.0;
    uVar10 = 0;
code_r0x000180110cd3:
    return CONCAT44(uVar10, fVar9);
}

