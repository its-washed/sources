// Chunk 183 - 50 functions

// ============================================================
// Function: FUN_1802416c0
// Address: 0x1802416c0
// Size: 41 bytes
// ============================================================
void fcn.1802416c0(int64_t arg_28h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802416ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_28h + iVar1) = 2;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_60h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802416e4;
    fcn.1802416f0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802416f0
// Address: 0x1802416f0
// Size: 39 bytes
// ============================================================
int64_t fcn.1802416f0(int64_t arg1, int64_t arg2, int64_t *placeholder_2, int64_t *placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024170e;
    puVar10 = (undefined8 *)arg2;
    iVar5 = fcn.18045a350();
    iVar2 = arg_30h;
    uVar1 = (uint32_t)arg_30h;
    iVar5 = -iVar5;
    iVar9 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
    iVar11 = 0;
    *(undefined4 *)arg_28h = 0;
    *placeholder_2 = 0;
    *puVar10 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *placeholder_3 = 0;
    var_58h = 0;
    var_78h = 0;
    var_60h = 0;
    iVar13 = iVar9;
    if (((uint8_t)arg_30h & 6) == 6) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024175b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241773;
        func_0x0001802295a0(0x1804e3ed0, 0x3c5, 0x1804e40f8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241785;
        func_0x0001802296d0(9, 0x80106, 0);
        iVar11 = iVar9;
        iVar8 = iVar9;
        goto code_r0x000180241a8e;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RBX;
    var_20h._0_4_ = (uint32_t)arg_30h & 1;
    if ((arg_30h & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a9;
        uVar6 = func_0x0001802199b0();
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a2;
        uVar6 = func_0x0001802199c0();
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417b4;
    iVar7 = func_0x00018021a7c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417c3;
    var_78h = iVar7;
    iVar8 = func_0x00018021a7c0(uVar6);
    var_68h = iVar8;
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a5c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a74;
        func_0x0001802295a0(0x1804e3ed0, 0x3cd, 0x1804e40f8);
        uVar6 = 0x80020;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417ef;
        iVar3 = func_0x000180242310(arg1, &var_60h, iVar2 & 0xffffffff);
        iVar11 = var_60h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        var_10h = arg2;
        *(uint32_t *)(&stack0x00000000 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241813;
        iVar3 = func_0x000180242060(arg1, &var_78h, &var_68h, iVar11);
        iVar8 = var_68h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241833;
        func_0x000180219d10(var_68h, 0x73, 0, &var_70h);
        if (*(uint64_t *)var_70h < 0x80000000) {
            arg_30h._0_4_ = (uint32_t)*(uint64_t *)var_70h;
            iVar13 = iVar12;
            if ((uint32_t)arg_30h == 0) goto code_r0x000180241a8e;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024187a;
            var_58h = func_0x00018028de90();
            if (var_58h == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241888;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418a0;
                func_0x0001802295a0(0x1804e3ed0, 0x3e3, 0x1804e40f8);
                uVar6 = 0x80006;
                goto code_r0x000180241a79;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418b2;
            func_0x00018028dc60(var_58h);
            iVar12 = var_58h;
            uVar6 = *(undefined8 *)(var_70h + 8);
            *(uint32_t *)(&stack0x00000000 + iVar5) = (uint32_t)arg_30h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418d4;
            iVar3 = func_0x00018028dc70(iVar12, uVar6, &arg_30h, uVar6);
            if (-1 < iVar3) {
                iVar7 = *(int64_t *)(var_70h + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418f4;
                iVar3 = func_0x00018028dbf0(iVar12, (int32_t)(uint32_t)arg_30h + iVar7, &var_18h);
                if (-1 < iVar3) {
                    arg_30h._0_4_ = (uint32_t)arg_30h + (int32_t)var_18h;
                    *(int64_t *)var_70h = (int64_t)(int32_t)(uint32_t)arg_30h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241923;
                    iVar3 = func_0x000180219d10(var_78h, 3, 0, 0);
                    if ((uint32_t)var_20h == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241963;
                        iVar9 = func_0x0001802248d0((int64_t)(iVar3 + 1), 0x1804e3ed0, 0x3f3);
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024197c;
                        iVar9 = func_0x0001802248d0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241943;
                        iVar9 = func_0x0001802252b0();
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024195c;
                        iVar9 = func_0x0001802252b0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    }
                    *placeholder_3 = iVar9;
                    iVar12 = *placeholder_2;
                    if ((iVar12 != 0) && (iVar9 != 0)) {
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024199d;
                            iVar4 = func_0x00018021ac80(var_78h, iVar12, iVar3);
                            if (iVar4 != iVar3) goto code_r0x0001802419d9;
                        }
                        *(undefined *)((int64_t)iVar3 + *placeholder_2) = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419b8;
                        iVar3 = func_0x00018021ac80(iVar8, iVar9, (uint32_t)arg_30h);
                        if (iVar3 == (uint32_t)arg_30h) {
                            *(uint32_t *)arg_28h = (uint32_t)arg_30h;
                            *(int64_t *)var_10h = iVar11;
                            iVar11 = 0;
                            iVar13 = 1;
                            goto code_r0x000180241a8e;
                        }
                    }
code_r0x0001802419d9:
                    iVar9 = *placeholder_2;
                    if ((iVar2 & 1U) == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a29;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a42;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419f6;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a11;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    }
                    goto code_r0x000180241a8e;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a4d;
            func_0x000180229480();
            uVar6 = 0x3ec;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241848;
            func_0x000180229480();
            uVar6 = 0x3d8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241860;
        func_0x0001802295a0(0x1804e3ed0, uVar6, 0x1804e40f8);
        uVar6 = 100;
    }
code_r0x000180241a79:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a86;
    func_0x0001802296d0(9, uVar6, 0);
    iVar13 = iVar9;
code_r0x000180241a8e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a97;
    func_0x00018028de60(var_58h);
    if ((iVar2 & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ad7;
        func_0x000180224990(iVar11, 0x1804e3ed0, 0x409);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ac3;
        func_0x000180225130(iVar11, 0, 0x1804e3ed0, 0x409);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae0;
    func_0x000180219f80(var_78h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae8;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_180241717
// Address: 0x180241717
// Size: 118 bytes
// ============================================================
int64_t fcn.1802416f0(int64_t arg1, int64_t arg2, int64_t *placeholder_2, int64_t *placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024170e;
    puVar10 = (undefined8 *)arg2;
    iVar5 = fcn.18045a350();
    iVar2 = arg_30h;
    uVar1 = (uint32_t)arg_30h;
    iVar5 = -iVar5;
    iVar9 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
    iVar11 = 0;
    *(undefined4 *)arg_28h = 0;
    *placeholder_2 = 0;
    *puVar10 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *placeholder_3 = 0;
    var_58h = 0;
    var_78h = 0;
    var_60h = 0;
    iVar13 = iVar9;
    if (((uint8_t)arg_30h & 6) == 6) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024175b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241773;
        func_0x0001802295a0(0x1804e3ed0, 0x3c5, 0x1804e40f8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241785;
        func_0x0001802296d0(9, 0x80106, 0);
        iVar11 = iVar9;
        iVar8 = iVar9;
        goto code_r0x000180241a8e;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RBX;
    var_20h._0_4_ = (uint32_t)arg_30h & 1;
    if ((arg_30h & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a9;
        uVar6 = func_0x0001802199b0();
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a2;
        uVar6 = func_0x0001802199c0();
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417b4;
    iVar7 = func_0x00018021a7c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417c3;
    var_78h = iVar7;
    iVar8 = func_0x00018021a7c0(uVar6);
    var_68h = iVar8;
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a5c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a74;
        func_0x0001802295a0(0x1804e3ed0, 0x3cd, 0x1804e40f8);
        uVar6 = 0x80020;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417ef;
        iVar3 = func_0x000180242310(arg1, &var_60h, iVar2 & 0xffffffff);
        iVar11 = var_60h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        var_10h = arg2;
        *(uint32_t *)(&stack0x00000000 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241813;
        iVar3 = func_0x000180242060(arg1, &var_78h, &var_68h, iVar11);
        iVar8 = var_68h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241833;
        func_0x000180219d10(var_68h, 0x73, 0, &var_70h);
        if (*(uint64_t *)var_70h < 0x80000000) {
            arg_30h._0_4_ = (uint32_t)*(uint64_t *)var_70h;
            iVar13 = iVar12;
            if ((uint32_t)arg_30h == 0) goto code_r0x000180241a8e;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024187a;
            var_58h = func_0x00018028de90();
            if (var_58h == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241888;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418a0;
                func_0x0001802295a0(0x1804e3ed0, 0x3e3, 0x1804e40f8);
                uVar6 = 0x80006;
                goto code_r0x000180241a79;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418b2;
            func_0x00018028dc60(var_58h);
            iVar12 = var_58h;
            uVar6 = *(undefined8 *)(var_70h + 8);
            *(uint32_t *)(&stack0x00000000 + iVar5) = (uint32_t)arg_30h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418d4;
            iVar3 = func_0x00018028dc70(iVar12, uVar6, &arg_30h, uVar6);
            if (-1 < iVar3) {
                iVar7 = *(int64_t *)(var_70h + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418f4;
                iVar3 = func_0x00018028dbf0(iVar12, (int32_t)(uint32_t)arg_30h + iVar7, &var_18h);
                if (-1 < iVar3) {
                    arg_30h._0_4_ = (uint32_t)arg_30h + (int32_t)var_18h;
                    *(int64_t *)var_70h = (int64_t)(int32_t)(uint32_t)arg_30h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241923;
                    iVar3 = func_0x000180219d10(var_78h, 3, 0, 0);
                    if ((uint32_t)var_20h == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241963;
                        iVar9 = func_0x0001802248d0((int64_t)(iVar3 + 1), 0x1804e3ed0, 0x3f3);
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024197c;
                        iVar9 = func_0x0001802248d0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241943;
                        iVar9 = func_0x0001802252b0();
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024195c;
                        iVar9 = func_0x0001802252b0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    }
                    *placeholder_3 = iVar9;
                    iVar12 = *placeholder_2;
                    if ((iVar12 != 0) && (iVar9 != 0)) {
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024199d;
                            iVar4 = func_0x00018021ac80(var_78h, iVar12, iVar3);
                            if (iVar4 != iVar3) goto code_r0x0001802419d9;
                        }
                        *(undefined *)((int64_t)iVar3 + *placeholder_2) = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419b8;
                        iVar3 = func_0x00018021ac80(iVar8, iVar9, (uint32_t)arg_30h);
                        if (iVar3 == (uint32_t)arg_30h) {
                            *(uint32_t *)arg_28h = (uint32_t)arg_30h;
                            *(int64_t *)var_10h = iVar11;
                            iVar11 = 0;
                            iVar13 = 1;
                            goto code_r0x000180241a8e;
                        }
                    }
code_r0x0001802419d9:
                    iVar9 = *placeholder_2;
                    if ((iVar2 & 1U) == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a29;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a42;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419f6;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a11;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    }
                    goto code_r0x000180241a8e;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a4d;
            func_0x000180229480();
            uVar6 = 0x3ec;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241848;
            func_0x000180229480();
            uVar6 = 0x3d8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241860;
        func_0x0001802295a0(0x1804e3ed0, uVar6, 0x1804e40f8);
        uVar6 = 100;
    }
code_r0x000180241a79:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a86;
    func_0x0001802296d0(9, uVar6, 0);
    iVar13 = iVar9;
code_r0x000180241a8e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a97;
    func_0x00018028de60(var_58h);
    if ((iVar2 & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ad7;
        func_0x000180224990(iVar11, 0x1804e3ed0, 0x409);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ac3;
        func_0x000180225130(iVar11, 0, 0x1804e3ed0, 0x409);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae0;
    func_0x000180219f80(var_78h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae8;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_18024178d
// Address: 0x18024178d
// Size: 769 bytes
// ============================================================
int64_t fcn.1802416f0(int64_t arg1, int64_t arg2, int64_t *placeholder_2, int64_t *placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024170e;
    puVar10 = (undefined8 *)arg2;
    iVar5 = fcn.18045a350();
    iVar2 = arg_30h;
    uVar1 = (uint32_t)arg_30h;
    iVar5 = -iVar5;
    iVar9 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
    iVar11 = 0;
    *(undefined4 *)arg_28h = 0;
    *placeholder_2 = 0;
    *puVar10 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *placeholder_3 = 0;
    var_58h = 0;
    var_78h = 0;
    var_60h = 0;
    iVar13 = iVar9;
    if (((uint8_t)arg_30h & 6) == 6) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024175b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241773;
        func_0x0001802295a0(0x1804e3ed0, 0x3c5, 0x1804e40f8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241785;
        func_0x0001802296d0(9, 0x80106, 0);
        iVar11 = iVar9;
        iVar8 = iVar9;
        goto code_r0x000180241a8e;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RBX;
    var_20h._0_4_ = (uint32_t)arg_30h & 1;
    if ((arg_30h & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a9;
        uVar6 = func_0x0001802199b0();
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a2;
        uVar6 = func_0x0001802199c0();
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417b4;
    iVar7 = func_0x00018021a7c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417c3;
    var_78h = iVar7;
    iVar8 = func_0x00018021a7c0(uVar6);
    var_68h = iVar8;
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a5c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a74;
        func_0x0001802295a0(0x1804e3ed0, 0x3cd, 0x1804e40f8);
        uVar6 = 0x80020;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417ef;
        iVar3 = func_0x000180242310(arg1, &var_60h, iVar2 & 0xffffffff);
        iVar11 = var_60h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        var_10h = arg2;
        *(uint32_t *)(&stack0x00000000 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241813;
        iVar3 = func_0x000180242060(arg1, &var_78h, &var_68h, iVar11);
        iVar8 = var_68h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241833;
        func_0x000180219d10(var_68h, 0x73, 0, &var_70h);
        if (*(uint64_t *)var_70h < 0x80000000) {
            arg_30h._0_4_ = (uint32_t)*(uint64_t *)var_70h;
            iVar13 = iVar12;
            if ((uint32_t)arg_30h == 0) goto code_r0x000180241a8e;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024187a;
            var_58h = func_0x00018028de90();
            if (var_58h == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241888;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418a0;
                func_0x0001802295a0(0x1804e3ed0, 0x3e3, 0x1804e40f8);
                uVar6 = 0x80006;
                goto code_r0x000180241a79;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418b2;
            func_0x00018028dc60(var_58h);
            iVar12 = var_58h;
            uVar6 = *(undefined8 *)(var_70h + 8);
            *(uint32_t *)(&stack0x00000000 + iVar5) = (uint32_t)arg_30h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418d4;
            iVar3 = func_0x00018028dc70(iVar12, uVar6, &arg_30h, uVar6);
            if (-1 < iVar3) {
                iVar7 = *(int64_t *)(var_70h + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418f4;
                iVar3 = func_0x00018028dbf0(iVar12, (int32_t)(uint32_t)arg_30h + iVar7, &var_18h);
                if (-1 < iVar3) {
                    arg_30h._0_4_ = (uint32_t)arg_30h + (int32_t)var_18h;
                    *(int64_t *)var_70h = (int64_t)(int32_t)(uint32_t)arg_30h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241923;
                    iVar3 = func_0x000180219d10(var_78h, 3, 0, 0);
                    if ((uint32_t)var_20h == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241963;
                        iVar9 = func_0x0001802248d0((int64_t)(iVar3 + 1), 0x1804e3ed0, 0x3f3);
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024197c;
                        iVar9 = func_0x0001802248d0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241943;
                        iVar9 = func_0x0001802252b0();
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024195c;
                        iVar9 = func_0x0001802252b0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    }
                    *placeholder_3 = iVar9;
                    iVar12 = *placeholder_2;
                    if ((iVar12 != 0) && (iVar9 != 0)) {
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024199d;
                            iVar4 = func_0x00018021ac80(var_78h, iVar12, iVar3);
                            if (iVar4 != iVar3) goto code_r0x0001802419d9;
                        }
                        *(undefined *)((int64_t)iVar3 + *placeholder_2) = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419b8;
                        iVar3 = func_0x00018021ac80(iVar8, iVar9, (uint32_t)arg_30h);
                        if (iVar3 == (uint32_t)arg_30h) {
                            *(uint32_t *)arg_28h = (uint32_t)arg_30h;
                            *(int64_t *)var_10h = iVar11;
                            iVar11 = 0;
                            iVar13 = 1;
                            goto code_r0x000180241a8e;
                        }
                    }
code_r0x0001802419d9:
                    iVar9 = *placeholder_2;
                    if ((iVar2 & 1U) == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a29;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a42;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419f6;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a11;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    }
                    goto code_r0x000180241a8e;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a4d;
            func_0x000180229480();
            uVar6 = 0x3ec;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241848;
            func_0x000180229480();
            uVar6 = 0x3d8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241860;
        func_0x0001802295a0(0x1804e3ed0, uVar6, 0x1804e40f8);
        uVar6 = 100;
    }
code_r0x000180241a79:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a86;
    func_0x0001802296d0(9, uVar6, 0);
    iVar13 = iVar9;
code_r0x000180241a8e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a97;
    func_0x00018028de60(var_58h);
    if ((iVar2 & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ad7;
        func_0x000180224990(iVar11, 0x1804e3ed0, 0x409);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ac3;
        func_0x000180225130(iVar11, 0, 0x1804e3ed0, 0x409);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae0;
    func_0x000180219f80(var_78h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae8;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_180241a8e
// Address: 0x180241a8e
// Size: 33 bytes
// ============================================================
int64_t fcn.1802416f0(int64_t arg1, int64_t arg2, int64_t *placeholder_2, int64_t *placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024170e;
    puVar10 = (undefined8 *)arg2;
    iVar5 = fcn.18045a350();
    iVar2 = arg_30h;
    uVar1 = (uint32_t)arg_30h;
    iVar5 = -iVar5;
    iVar9 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
    iVar11 = 0;
    *(undefined4 *)arg_28h = 0;
    *placeholder_2 = 0;
    *puVar10 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *placeholder_3 = 0;
    var_58h = 0;
    var_78h = 0;
    var_60h = 0;
    iVar13 = iVar9;
    if (((uint8_t)arg_30h & 6) == 6) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024175b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241773;
        func_0x0001802295a0(0x1804e3ed0, 0x3c5, 0x1804e40f8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241785;
        func_0x0001802296d0(9, 0x80106, 0);
        iVar11 = iVar9;
        iVar8 = iVar9;
        goto code_r0x000180241a8e;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RBX;
    var_20h._0_4_ = (uint32_t)arg_30h & 1;
    if ((arg_30h & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a9;
        uVar6 = func_0x0001802199b0();
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a2;
        uVar6 = func_0x0001802199c0();
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417b4;
    iVar7 = func_0x00018021a7c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417c3;
    var_78h = iVar7;
    iVar8 = func_0x00018021a7c0(uVar6);
    var_68h = iVar8;
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a5c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a74;
        func_0x0001802295a0(0x1804e3ed0, 0x3cd, 0x1804e40f8);
        uVar6 = 0x80020;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417ef;
        iVar3 = func_0x000180242310(arg1, &var_60h, iVar2 & 0xffffffff);
        iVar11 = var_60h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        var_10h = arg2;
        *(uint32_t *)(&stack0x00000000 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241813;
        iVar3 = func_0x000180242060(arg1, &var_78h, &var_68h, iVar11);
        iVar8 = var_68h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241833;
        func_0x000180219d10(var_68h, 0x73, 0, &var_70h);
        if (*(uint64_t *)var_70h < 0x80000000) {
            arg_30h._0_4_ = (uint32_t)*(uint64_t *)var_70h;
            iVar13 = iVar12;
            if ((uint32_t)arg_30h == 0) goto code_r0x000180241a8e;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024187a;
            var_58h = func_0x00018028de90();
            if (var_58h == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241888;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418a0;
                func_0x0001802295a0(0x1804e3ed0, 0x3e3, 0x1804e40f8);
                uVar6 = 0x80006;
                goto code_r0x000180241a79;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418b2;
            func_0x00018028dc60(var_58h);
            iVar12 = var_58h;
            uVar6 = *(undefined8 *)(var_70h + 8);
            *(uint32_t *)(&stack0x00000000 + iVar5) = (uint32_t)arg_30h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418d4;
            iVar3 = func_0x00018028dc70(iVar12, uVar6, &arg_30h, uVar6);
            if (-1 < iVar3) {
                iVar7 = *(int64_t *)(var_70h + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418f4;
                iVar3 = func_0x00018028dbf0(iVar12, (int32_t)(uint32_t)arg_30h + iVar7, &var_18h);
                if (-1 < iVar3) {
                    arg_30h._0_4_ = (uint32_t)arg_30h + (int32_t)var_18h;
                    *(int64_t *)var_70h = (int64_t)(int32_t)(uint32_t)arg_30h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241923;
                    iVar3 = func_0x000180219d10(var_78h, 3, 0, 0);
                    if ((uint32_t)var_20h == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241963;
                        iVar9 = func_0x0001802248d0((int64_t)(iVar3 + 1), 0x1804e3ed0, 0x3f3);
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024197c;
                        iVar9 = func_0x0001802248d0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241943;
                        iVar9 = func_0x0001802252b0();
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024195c;
                        iVar9 = func_0x0001802252b0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    }
                    *placeholder_3 = iVar9;
                    iVar12 = *placeholder_2;
                    if ((iVar12 != 0) && (iVar9 != 0)) {
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024199d;
                            iVar4 = func_0x00018021ac80(var_78h, iVar12, iVar3);
                            if (iVar4 != iVar3) goto code_r0x0001802419d9;
                        }
                        *(undefined *)((int64_t)iVar3 + *placeholder_2) = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419b8;
                        iVar3 = func_0x00018021ac80(iVar8, iVar9, (uint32_t)arg_30h);
                        if (iVar3 == (uint32_t)arg_30h) {
                            *(uint32_t *)arg_28h = (uint32_t)arg_30h;
                            *(int64_t *)var_10h = iVar11;
                            iVar11 = 0;
                            iVar13 = 1;
                            goto code_r0x000180241a8e;
                        }
                    }
code_r0x0001802419d9:
                    iVar9 = *placeholder_2;
                    if ((iVar2 & 1U) == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a29;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a42;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419f6;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a11;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    }
                    goto code_r0x000180241a8e;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a4d;
            func_0x000180229480();
            uVar6 = 0x3ec;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241848;
            func_0x000180229480();
            uVar6 = 0x3d8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241860;
        func_0x0001802295a0(0x1804e3ed0, uVar6, 0x1804e40f8);
        uVar6 = 100;
    }
code_r0x000180241a79:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a86;
    func_0x0001802296d0(9, uVar6, 0);
    iVar13 = iVar9;
code_r0x000180241a8e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a97;
    func_0x00018028de60(var_58h);
    if ((iVar2 & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ad7;
        func_0x000180224990(iVar11, 0x1804e3ed0, 0x409);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ac3;
        func_0x000180225130(iVar11, 0, 0x1804e3ed0, 0x409);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae0;
    func_0x000180219f80(var_78h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae8;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_180241aaf
// Address: 0x180241aaf
// Size: 72 bytes
// ============================================================
int64_t fcn.1802416f0(int64_t arg1, int64_t arg2, int64_t *placeholder_2, int64_t *placeholder_3, int64_t arg_28h,
                     int64_t arg_30h, undefined8 placeholder_6, undefined8 placeholder_7, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined8 *puVar10;
    undefined8 unaff_RBX;
    int64_t iVar11;
    int64_t iVar12;
    int64_t iVar13;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_28;
    
    uStack_28 = 0x18024170e;
    puVar10 = (undefined8 *)arg2;
    iVar5 = fcn.18045a350();
    iVar2 = arg_30h;
    uVar1 = (uint32_t)arg_30h;
    iVar5 = -iVar5;
    iVar9 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&arg_58h + iVar5) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_50h + iVar5) = unaff_R13;
    iVar11 = 0;
    *(undefined4 *)arg_28h = 0;
    *placeholder_2 = 0;
    *puVar10 = 0;
    *(undefined8 *)((int64_t)&arg_48h + iVar5) = unaff_R15;
    *placeholder_3 = 0;
    var_58h = 0;
    var_78h = 0;
    var_60h = 0;
    iVar13 = iVar9;
    if (((uint8_t)arg_30h & 6) == 6) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024175b;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241773;
        func_0x0001802295a0(0x1804e3ed0, 0x3c5, 0x1804e40f8);
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241785;
        func_0x0001802296d0(9, 0x80106, 0);
        iVar11 = iVar9;
        iVar8 = iVar9;
        goto code_r0x000180241a8e;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RBX;
    var_20h._0_4_ = (uint32_t)arg_30h & 1;
    if ((arg_30h & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a9;
        uVar6 = func_0x0001802199b0();
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417a2;
        uVar6 = func_0x0001802199c0();
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417b4;
    iVar7 = func_0x00018021a7c0(uVar6);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417c3;
    var_78h = iVar7;
    iVar8 = func_0x00018021a7c0(uVar6);
    var_68h = iVar8;
    if ((iVar7 == 0) || (iVar8 == 0)) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a5c;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a74;
        func_0x0001802295a0(0x1804e3ed0, 0x3cd, 0x1804e40f8);
        uVar6 = 0x80020;
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802417ef;
        iVar3 = func_0x000180242310(arg1, &var_60h, iVar2 & 0xffffffff);
        iVar11 = var_60h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        var_10h = arg2;
        *(uint32_t *)(&stack0x00000000 + iVar5) = uVar1;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241813;
        iVar3 = func_0x000180242060(arg1, &var_78h, &var_68h, iVar11);
        iVar8 = var_68h;
        if (iVar3 == 0) goto code_r0x000180241a8e;
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241833;
        func_0x000180219d10(var_68h, 0x73, 0, &var_70h);
        if (*(uint64_t *)var_70h < 0x80000000) {
            arg_30h._0_4_ = (uint32_t)*(uint64_t *)var_70h;
            iVar13 = iVar12;
            if ((uint32_t)arg_30h == 0) goto code_r0x000180241a8e;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024187a;
            var_58h = func_0x00018028de90();
            if (var_58h == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241888;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418a0;
                func_0x0001802295a0(0x1804e3ed0, 0x3e3, 0x1804e40f8);
                uVar6 = 0x80006;
                goto code_r0x000180241a79;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418b2;
            func_0x00018028dc60(var_58h);
            iVar12 = var_58h;
            uVar6 = *(undefined8 *)(var_70h + 8);
            *(uint32_t *)(&stack0x00000000 + iVar5) = (uint32_t)arg_30h;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418d4;
            iVar3 = func_0x00018028dc70(iVar12, uVar6, &arg_30h, uVar6);
            if (-1 < iVar3) {
                iVar7 = *(int64_t *)(var_70h + 8);
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802418f4;
                iVar3 = func_0x00018028dbf0(iVar12, (int32_t)(uint32_t)arg_30h + iVar7, &var_18h);
                if (-1 < iVar3) {
                    arg_30h._0_4_ = (uint32_t)arg_30h + (int32_t)var_18h;
                    *(int64_t *)var_70h = (int64_t)(int32_t)(uint32_t)arg_30h;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241923;
                    iVar3 = func_0x000180219d10(var_78h, 3, 0, 0);
                    if ((uint32_t)var_20h == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241963;
                        iVar9 = func_0x0001802248d0((int64_t)(iVar3 + 1), 0x1804e3ed0, 0x3f3);
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024197c;
                        iVar9 = func_0x0001802248d0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241943;
                        iVar9 = func_0x0001802252b0();
                        *placeholder_2 = iVar9;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024195c;
                        iVar9 = func_0x0001802252b0((int64_t)(int32_t)(uint32_t)arg_30h, 0x1804e3ed0, 0x3f4);
                    }
                    *placeholder_3 = iVar9;
                    iVar12 = *placeholder_2;
                    if ((iVar12 != 0) && (iVar9 != 0)) {
                        if (iVar3 != 0) {
                            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024199d;
                            iVar4 = func_0x00018021ac80(var_78h, iVar12, iVar3);
                            if (iVar4 != iVar3) goto code_r0x0001802419d9;
                        }
                        *(undefined *)((int64_t)iVar3 + *placeholder_2) = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419b8;
                        iVar3 = func_0x00018021ac80(iVar8, iVar9, (uint32_t)arg_30h);
                        if (iVar3 == (uint32_t)arg_30h) {
                            *(uint32_t *)arg_28h = (uint32_t)arg_30h;
                            *(int64_t *)var_10h = iVar11;
                            iVar11 = 0;
                            iVar13 = 1;
                            goto code_r0x000180241a8e;
                        }
                    }
code_r0x0001802419d9:
                    iVar9 = *placeholder_2;
                    if ((iVar2 & 1U) == 0) {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a29;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a42;
                        func_0x000180224990(iVar9, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1802419f6;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x403);
                        *placeholder_2 = 0;
                        iVar9 = *placeholder_3;
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a11;
                        func_0x000180225130(iVar9, 0, 0x1804e3ed0, 0x405);
                        *placeholder_3 = 0;
                    }
                    goto code_r0x000180241a8e;
                }
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a4d;
            func_0x000180229480();
            uVar6 = 0x3ec;
        } else {
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241848;
            func_0x000180229480();
            uVar6 = 0x3d8;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241860;
        func_0x0001802295a0(0x1804e3ed0, uVar6, 0x1804e40f8);
        uVar6 = 100;
    }
code_r0x000180241a79:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a86;
    func_0x0001802296d0(9, uVar6, 0);
    iVar13 = iVar9;
code_r0x000180241a8e:
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241a97;
    func_0x00018028de60(var_58h);
    if ((iVar2 & 1U) == 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ad7;
        func_0x000180224990(iVar11, 0x1804e3ed0, 0x409);
    } else {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ac3;
        func_0x000180225130(iVar11, 0, 0x1804e3ed0, 0x409);
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae0;
    func_0x000180219f80(var_78h);
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x180241ae8;
    func_0x000180219f80(iVar8);
    return iVar13;
}

// ============================================================
// Function: FUN_180241b00
// Address: 0x180241b00
// Size: 638 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.180241b00(undefined8 placeholder_0, int64_t arg2, int64_t placeholder_2, int64_t arg4, int64_t arg_48h,
                     int64_t arg_50h, int64_t arg_60h, int64_t arg_68h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint32_t uVar7;
    undefined8 uVar8;
    uint32_t uVar9;
    int32_t iVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x180241b24;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar10 = 0;
    iVar6 = 0;
    iVar11 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241b3b;
    iVar4 = func_0x00018028de90();
    if (iVar4 == 0) {
code_r0x000180241b43:
        uVar8 = 0x80006;
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241b55;
        func_0x00018028df70(iVar4);
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241b5d;
        uVar5 = func_0x000180498cd0(arg2);
        *(uint64_t *)(&stack0x00000000 + iVar3) = uVar5;
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241b7a;
        iVar1 = func_0x00018021b2c0(placeholder_0, 0x1804e4098, 0xb);
        if (iVar1 == 0xb) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241b91;
            iVar1 = func_0x00018021b2c0(placeholder_0, arg2, uVar5 & 0xffffffff);
            if (iVar1 == (int32_t)uVar5) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241bae;
                iVar1 = func_0x00018021b2c0(placeholder_0, 0x1804e40a4, 6);
                iVar6 = iVar11;
                if (iVar1 == 6) {
                    if (placeholder_2 != 0) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241bc4;
                        iVar1 = func_0x000180498cd0(placeholder_2);
                        if (0 < iVar1) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241bd9;
                            iVar2 = func_0x00018021b2c0(placeholder_0, placeholder_2, iVar1);
                            if (iVar2 == iVar1) {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241bf6;
                                iVar1 = func_0x00018021b2c0(placeholder_0, 0x1805ab2a0, 1);
                                if (iVar1 == 1) goto code_r0x000180241bff;
                            }
                            goto code_r0x000180241d10;
                        }
                    }
code_r0x000180241bff:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241c1b;
                    iVar6 = func_0x000180224ed0(0x400, 8, 0x1804e3ed0, 0x29c);
                    if (iVar6 == 0) goto code_r0x000180241d41;
                    iVar10 = 0;
                    for (uVar7 = *(uint32_t *)((int64_t)&arg_68h + iVar3); 0 < (int32_t)uVar7; uVar7 = uVar7 - uVar9) {
                        uVar9 = uVar7;
                        if (0x1400 < uVar7) {
                            uVar9 = 0x1400;
                        }
                        *(uint32_t *)((int64_t)&var_18h + iVar3) = uVar9;
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241c63;
                        iVar1 = func_0x00018028df80();
                        if (iVar1 == 0) goto code_r0x000180241b43;
                        iVar1 = *(int32_t *)(&stack0xfffffffffffffff8 + iVar3);
                        if (iVar1 != 0) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241c81;
                            iVar2 = func_0x00018021b2c0(placeholder_0, iVar6, iVar1);
                            iVar1 = *(int32_t *)(&stack0xfffffffffffffff8 + iVar3);
                            if (iVar2 != iVar1) goto code_r0x000180241d10;
                        }
                        iVar10 = iVar10 + iVar1;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241c9b;
                    func_0x00018028def0(iVar4, iVar6, &stack0xfffffffffffffff8 + iVar3);
                    if (0 < *(int32_t *)(&stack0xfffffffffffffff8 + iVar3)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241cb0;
                        iVar1 = func_0x00018021b2c0(placeholder_0, iVar6);
                        if (iVar1 != *(int32_t *)(&stack0xfffffffffffffff8 + iVar3)) goto code_r0x000180241d10;
                    }
                    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241ccb;
                    iVar1 = func_0x00018021b2c0(placeholder_0, 0x1804e40b0, 9);
                    if (iVar1 == 9) {
                        uVar5 = *(uint64_t *)(&stack0x00000000 + iVar3);
                        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241ce8;
                        iVar1 = func_0x00018021b2c0(placeholder_0, *(undefined8 *)((int64_t)&arg_50h + iVar3), 
                                                    uVar5 & 0xffffffff);
                        if (iVar1 == (int32_t)uVar5) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241d01;
                            iVar1 = func_0x00018021b2c0(placeholder_0, 0x1804e40a4, 6);
                            if (iVar1 == 6) {
                                iVar10 = *(int32_t *)(&stack0xfffffffffffffff8 + iVar3) + iVar10;
                                goto code_r0x000180241d41;
                            }
                        }
                    }
                }
            }
        }
code_r0x000180241d10:
        uVar8 = 0x80020;
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241d1a;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241d32;
    func_0x0001802295a0(0x1804e3ed0, 0x2be, 0x1804e40c0);
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241d41;
    func_0x0001802296d0(9, uVar8, 0);
    iVar10 = 0;
code_r0x000180241d41:
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241d49;
    func_0x00018028de60(iVar4);
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180241d63;
    func_0x000180224b90(iVar6, 0x2000, 0x1804e3ed0, 0x2c0);
    return iVar10;
}

// ============================================================
// Function: FUN_180241d80
// Address: 0x180241d80
// Size: 731 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.180241d80(int64_t arg_28h, int64_t arg_38h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    char *pcVar5;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180241d90;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241d9e;
    iVar1 = func_0x000180498f10();
    if (iVar1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241db5;
        iVar1 = func_0x000180498f10(in_RDX, 0x1804e3f20);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241e5d;
            iVar1 = func_0x000180498f10(in_RDX, 0x1804e3f58);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241e69;
                iVar1 = func_0x000180498cd0();
                if (0xb < iVar1) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241e84;
                    iVar2 = func_0x000180498f10(iVar1 + in_RCX + -10, 0x1804e3f58);
                    if (((iVar2 == 0) && (pcVar5 = (char *)(iVar1 + in_RCX + -0xb), *pcVar5 == ' ')) &&
                       (iVar1 = (int32_t)pcVar5 - (int32_t)in_RCX, 0 < iVar1)) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241ea7;
                        iVar4 = func_0x0001802479a0((int64_t)&arg_38h + iVar3, in_RCX, iVar1);
                        if (iVar4 != 0) {
                            iVar4 = *(int64_t *)(iVar4 + 0x70);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241ebf;
                            func_0x00018026aee0(*(undefined8 *)((int64_t)&arg_38h + iVar3));
                            return iVar4 != 0;
                        }
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241ed8;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804e3f68);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241eeb;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e3f80);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f02;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804e3f90);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f15;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804bedb8);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f2c;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804e3fa8);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f3f;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e3fc0);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f56;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804bedb8);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f69;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e3fd8);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f80;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804e3f90);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241f93;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e3fd8);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241faa;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804bedb8);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241fbd;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e3fec);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241fd4;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804e3ff8);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241fe7;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e3fec);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241ffa;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804bedb8);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024200d;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e400c);
                    if (iVar1 == 0) {
                        return true;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180242020;
                iVar1 = func_0x000180498f10(in_RCX, 0x1804e3fec);
                if (iVar1 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180242037;
                    iVar1 = func_0x000180498f10(in_RDX, 0x1804e400c);
                    return iVar1 == 0;
                }
            }
            return false;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241dcc;
        iVar1 = func_0x000180498f10(in_RCX, 0x1804e3f30);
        if (iVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241de3;
            iVar1 = func_0x000180498f10(in_RCX, 0x1804e3f48);
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241df3;
                iVar1 = func_0x000180498cd0(in_RCX);
                if (iVar1 < 0xd) {
                    return false;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241e0e;
                iVar2 = func_0x000180498f10(iVar1 + in_RCX + -0xb, 0x1804e3f48);
                if (iVar2 != 0) {
                    return false;
                }
                pcVar5 = (char *)(iVar1 + in_RCX + -0xc);
                if (*pcVar5 != ' ') {
                    return false;
                }
                iVar1 = (int32_t)pcVar5 - (int32_t)in_RCX;
                if (iVar1 < 1) {
                    return false;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180241e2e;
                iVar3 = func_0x0001802479a0(0, in_RCX, iVar1);
                if (iVar3 == 0) {
                    return false;
                }
                if (*(int64_t *)(iVar3 + 0xb8) == 0) {
                    return false;
                }
                return true;
            }
        }
    }
    return true;
}

// ============================================================
// Function: FUN_180242060
// Address: 0x180242060
// Size: 130 bytes
// ============================================================
undefined4
fcn.180242060(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined8 *puVar1;
    bool bVar2;
    bool bVar3;
    bool bVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    char *pcVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x180242088;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar13 = 0;
    uVar11 = *(undefined8 *)arg2;
    uVar5 = *(uint32_t *)((int64_t)&arg_68h + iVar8) & 1;
    *(uint32_t *)(&stack0xffffffffffffffe8 + iVar8) = uVar5;
    bVar4 = false;
    iVar12 = 0;
    if (uVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420cb;
        pcVar9 = (char *)func_0x0001802248d0(0x100, 0x1804e3ed0, 0x357);
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420c4;
        pcVar9 = (char *)func_0x0001802252b0();
    }
    if (pcVar9 == (char *)0x0) {
        return 0;
    }
    *(undefined8 *)(&stack0x00000000 + iVar8) = unaff_R14;
    bVar2 = false;
code_r0x0001802420ea:
    do {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420f8;
        iVar6 = func_0x00018021a200(arg1, pcVar9, 0xff);
        if (iVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242299;
            func_0x000180229480();
            uVar11 = 0x35f;
code_r0x00018024229e:
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422b1;
            func_0x0001802295a0(0x1804e3ed0, uVar11, 0x1804e40e0);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422c3;
            func_0x0001802296d0(9, 0x66, 0);
            uVar13 = 0;
code_r0x0001802422c3:
            if (*(int32_t *)(&stack0xffffffffffffffe8 + iVar8) == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422fd;
                func_0x000180224990(pcVar9, 0x1804e3ed0, 0x3ac);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422e9;
                func_0x000180225130(pcVar9, 0x100, 0x1804e3ed0, 0x3ac);
            }
            return uVar13;
        }
        if ((iVar6 != 0xfe) || (bVar3 = true, pcVar9[0xfd] == '\n')) {
            bVar3 = false;
        }
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242135;
            iVar10 = func_0x000180498a80(pcVar9, 0x3a, iVar6);
            if (iVar10 != 0) {
                iVar12 = 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242155;
        iVar7 = func_0x000180498f90(pcVar9, 0x1804e40b0, 9);
        if ((iVar7 == 0) || (uVar5 = 0xffffffff, iVar12 == 1)) {
            uVar5 = 0xfffffffb;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024217f;
        iVar6 = func_0x000180242b30(pcVar9, iVar6, uVar5 & *(uint32_t *)((int64_t)&arg_68h + iVar8), 0);
        if (*pcVar9 == '\n') {
            if (!bVar2) {
                if (iVar12 == 2) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242205;
                    func_0x000180229480();
                    uVar11 = 0x37c;
                    goto code_r0x00018024229e;
                }
                iVar12 = 2;
                arg1 = *(int64_t *)((int64_t)&arg_48h + iVar8);
                uVar11 = **(undefined8 **)((int64_t)&arg_58h + iVar8);
                bVar2 = bVar3;
                goto code_r0x0001802420ea;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802421c2;
            iVar7 = func_0x000180498f90(pcVar9, 0x1804e40b0, 9);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024222f;
                iVar10 = func_0x000180498cd0(*(undefined8 *)((int64_t)&arg_60h + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242245;
                iVar6 = func_0x000180498f90(pcVar9 + 9, *(undefined8 *)((int64_t)&arg_60h + iVar8), iVar10);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024225f;
                    iVar6 = func_0x000180498f90(pcVar9 + 9 + iVar10, 0x1804e40a4, 6);
                    if (iVar6 == 0) {
                        if (iVar12 == 0) {
                            puVar1 = *(undefined8 **)((int64_t)&arg_58h + iVar8);
                            **(undefined8 **)((int64_t)&arg_50h + iVar8) = *puVar1;
                            *puVar1 = uVar11;
                        }
                        uVar13 = 1;
                        goto code_r0x0001802422c3;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024228d;
                func_0x000180229480();
                uVar11 = 0x38b;
                goto code_r0x00018024229e;
            }
            if (bVar4) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242214;
                func_0x000180229480();
                uVar11 = 0x395;
                goto code_r0x00018024229e;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802421d5;
            iVar7 = func_0x00018021a9d0(uVar11, pcVar9);
            if (iVar7 < 0) goto code_r0x0001802422c3;
            if (iVar12 == 2) {
                if (0x41 < iVar6) goto code_r0x0001802422c3;
                if (iVar6 < 0x41) {
                    bVar4 = true;
                }
            }
        }
        arg1 = *(int64_t *)((int64_t)&arg_48h + iVar8);
        bVar2 = bVar3;
    } while( true );
}

// ============================================================
// Function: FUN_1802420e2
// Address: 0x1802420e2
// Size: 496 bytes
// ============================================================
undefined4
fcn.180242060(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined8 *puVar1;
    bool bVar2;
    bool bVar3;
    bool bVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    char *pcVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x180242088;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar13 = 0;
    uVar11 = *(undefined8 *)arg2;
    uVar5 = *(uint32_t *)((int64_t)&arg_68h + iVar8) & 1;
    *(uint32_t *)(&stack0xffffffffffffffe8 + iVar8) = uVar5;
    bVar4 = false;
    iVar12 = 0;
    if (uVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420cb;
        pcVar9 = (char *)func_0x0001802248d0(0x100, 0x1804e3ed0, 0x357);
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420c4;
        pcVar9 = (char *)func_0x0001802252b0();
    }
    if (pcVar9 == (char *)0x0) {
        return 0;
    }
    *(undefined8 *)(&stack0x00000000 + iVar8) = unaff_R14;
    bVar2 = false;
code_r0x0001802420ea:
    do {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420f8;
        iVar6 = func_0x00018021a200(arg1, pcVar9, 0xff);
        if (iVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242299;
            func_0x000180229480();
            uVar11 = 0x35f;
code_r0x00018024229e:
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422b1;
            func_0x0001802295a0(0x1804e3ed0, uVar11, 0x1804e40e0);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422c3;
            func_0x0001802296d0(9, 0x66, 0);
            uVar13 = 0;
code_r0x0001802422c3:
            if (*(int32_t *)(&stack0xffffffffffffffe8 + iVar8) == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422fd;
                func_0x000180224990(pcVar9, 0x1804e3ed0, 0x3ac);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422e9;
                func_0x000180225130(pcVar9, 0x100, 0x1804e3ed0, 0x3ac);
            }
            return uVar13;
        }
        if ((iVar6 != 0xfe) || (bVar3 = true, pcVar9[0xfd] == '\n')) {
            bVar3 = false;
        }
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242135;
            iVar10 = func_0x000180498a80(pcVar9, 0x3a, iVar6);
            if (iVar10 != 0) {
                iVar12 = 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242155;
        iVar7 = func_0x000180498f90(pcVar9, 0x1804e40b0, 9);
        if ((iVar7 == 0) || (uVar5 = 0xffffffff, iVar12 == 1)) {
            uVar5 = 0xfffffffb;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024217f;
        iVar6 = func_0x000180242b30(pcVar9, iVar6, uVar5 & *(uint32_t *)((int64_t)&arg_68h + iVar8), 0);
        if (*pcVar9 == '\n') {
            if (!bVar2) {
                if (iVar12 == 2) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242205;
                    func_0x000180229480();
                    uVar11 = 0x37c;
                    goto code_r0x00018024229e;
                }
                iVar12 = 2;
                arg1 = *(int64_t *)((int64_t)&arg_48h + iVar8);
                uVar11 = **(undefined8 **)((int64_t)&arg_58h + iVar8);
                bVar2 = bVar3;
                goto code_r0x0001802420ea;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802421c2;
            iVar7 = func_0x000180498f90(pcVar9, 0x1804e40b0, 9);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024222f;
                iVar10 = func_0x000180498cd0(*(undefined8 *)((int64_t)&arg_60h + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242245;
                iVar6 = func_0x000180498f90(pcVar9 + 9, *(undefined8 *)((int64_t)&arg_60h + iVar8), iVar10);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024225f;
                    iVar6 = func_0x000180498f90(pcVar9 + 9 + iVar10, 0x1804e40a4, 6);
                    if (iVar6 == 0) {
                        if (iVar12 == 0) {
                            puVar1 = *(undefined8 **)((int64_t)&arg_58h + iVar8);
                            **(undefined8 **)((int64_t)&arg_50h + iVar8) = *puVar1;
                            *puVar1 = uVar11;
                        }
                        uVar13 = 1;
                        goto code_r0x0001802422c3;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024228d;
                func_0x000180229480();
                uVar11 = 0x38b;
                goto code_r0x00018024229e;
            }
            if (bVar4) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242214;
                func_0x000180229480();
                uVar11 = 0x395;
                goto code_r0x00018024229e;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802421d5;
            iVar7 = func_0x00018021a9d0(uVar11, pcVar9);
            if (iVar7 < 0) goto code_r0x0001802422c3;
            if (iVar12 == 2) {
                if (0x41 < iVar6) goto code_r0x0001802422c3;
                if (iVar6 < 0x41) {
                    bVar4 = true;
                }
            }
        }
        arg1 = *(int64_t *)((int64_t)&arg_48h + iVar8);
        bVar2 = bVar3;
    } while( true );
}

// ============================================================
// Function: FUN_1802422d2
// Address: 0x1802422d2
// Size: 61 bytes
// ============================================================
undefined4
fcn.180242060(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    undefined8 *puVar1;
    bool bVar2;
    bool bVar3;
    bool bVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    char *pcVar9;
    int64_t iVar10;
    undefined8 uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x180242088;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    uVar13 = 0;
    uVar11 = *(undefined8 *)arg2;
    uVar5 = *(uint32_t *)((int64_t)&arg_68h + iVar8) & 1;
    *(uint32_t *)(&stack0xffffffffffffffe8 + iVar8) = uVar5;
    bVar4 = false;
    iVar12 = 0;
    if (uVar5 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420cb;
        pcVar9 = (char *)func_0x0001802248d0(0x100, 0x1804e3ed0, 0x357);
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420c4;
        pcVar9 = (char *)func_0x0001802252b0();
    }
    if (pcVar9 == (char *)0x0) {
        return 0;
    }
    *(undefined8 *)(&stack0x00000000 + iVar8) = unaff_R14;
    bVar2 = false;
code_r0x0001802420ea:
    do {
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802420f8;
        iVar6 = func_0x00018021a200(arg1, pcVar9, 0xff);
        if (iVar6 < 1) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242299;
            func_0x000180229480();
            uVar11 = 0x35f;
code_r0x00018024229e:
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422b1;
            func_0x0001802295a0(0x1804e3ed0, uVar11, 0x1804e40e0);
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422c3;
            func_0x0001802296d0(9, 0x66, 0);
            uVar13 = 0;
code_r0x0001802422c3:
            if (*(int32_t *)(&stack0xffffffffffffffe8 + iVar8) == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422fd;
                func_0x000180224990(pcVar9, 0x1804e3ed0, 0x3ac);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802422e9;
                func_0x000180225130(pcVar9, 0x100, 0x1804e3ed0, 0x3ac);
            }
            return uVar13;
        }
        if ((iVar6 != 0xfe) || (bVar3 = true, pcVar9[0xfd] == '\n')) {
            bVar3 = false;
        }
        if (iVar12 == 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242135;
            iVar10 = func_0x000180498a80(pcVar9, 0x3a, iVar6);
            if (iVar10 != 0) {
                iVar12 = 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242155;
        iVar7 = func_0x000180498f90(pcVar9, 0x1804e40b0, 9);
        if ((iVar7 == 0) || (uVar5 = 0xffffffff, iVar12 == 1)) {
            uVar5 = 0xfffffffb;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024217f;
        iVar6 = func_0x000180242b30(pcVar9, iVar6, uVar5 & *(uint32_t *)((int64_t)&arg_68h + iVar8), 0);
        if (*pcVar9 == '\n') {
            if (!bVar2) {
                if (iVar12 == 2) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242205;
                    func_0x000180229480();
                    uVar11 = 0x37c;
                    goto code_r0x00018024229e;
                }
                iVar12 = 2;
                arg1 = *(int64_t *)((int64_t)&arg_48h + iVar8);
                uVar11 = **(undefined8 **)((int64_t)&arg_58h + iVar8);
                bVar2 = bVar3;
                goto code_r0x0001802420ea;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802421c2;
            iVar7 = func_0x000180498f90(pcVar9, 0x1804e40b0, 9);
            if (iVar7 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024222f;
                iVar10 = func_0x000180498cd0(*(undefined8 *)((int64_t)&arg_60h + iVar8));
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242245;
                iVar6 = func_0x000180498f90(pcVar9 + 9, *(undefined8 *)((int64_t)&arg_60h + iVar8), iVar10);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024225f;
                    iVar6 = func_0x000180498f90(pcVar9 + 9 + iVar10, 0x1804e40a4, 6);
                    if (iVar6 == 0) {
                        if (iVar12 == 0) {
                            puVar1 = *(undefined8 **)((int64_t)&arg_58h + iVar8);
                            **(undefined8 **)((int64_t)&arg_50h + iVar8) = *puVar1;
                            *puVar1 = uVar11;
                        }
                        uVar13 = 1;
                        goto code_r0x0001802422c3;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x18024228d;
                func_0x000180229480();
                uVar11 = 0x38b;
                goto code_r0x00018024229e;
            }
            if (bVar4) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x180242214;
                func_0x000180229480();
                uVar11 = 0x395;
                goto code_r0x00018024229e;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar8) = 0x1802421d5;
            iVar7 = func_0x00018021a9d0(uVar11, pcVar9);
            if (iVar7 < 0) goto code_r0x0001802422c3;
            if (iVar12 == 2) {
                if (0x41 < iVar6) goto code_r0x0001802422c3;
                if (iVar6 < 0x41) {
                    bVar4 = true;
                }
            }
        }
        arg1 = *(int64_t *)((int64_t)&arg_48h + iVar8);
        bVar2 = bVar3;
    } while( true );
}

// ============================================================
// Function: FUN_180242310
// Address: 0x180242310
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180242310(undefined8 placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024232d;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242365;
        iVar4 = func_0x0001802248d0(0x100, 0x1804e3ed0, 0x317);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024235e;
        iVar4 = func_0x0001802252b0();
    }
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    uVar6 = 1;
    do {
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423a1;
            iVar1 = func_0x00018021a200(placeholder_0, iVar4, 0xff);
            if (iVar1 < 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242452;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024246a;
                func_0x0001802295a0(0x1804e3ed0, 799, 0x1804e40d0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024247c;
                func_0x0001802296d0(9, 0x6c, 0);
                goto code_r0x00018024247c;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423bd;
            iVar1 = func_0x000180242b30(iVar4, iVar1, (uint32_t)placeholder_2 & 0xfffffffb, uVar6);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423d8;
            iVar2 = func_0x000180498f90(iVar4, 0x1804e4098, 0xb);
            uVar6 = uVar7;
        } while ((iVar2 != 0) || (uVar6 = 0, iVar1 < 6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423fa;
        iVar2 = func_0x000180498f90((int64_t)iVar1 + -6 + iVar4, 0x1804e40a4, 6);
    } while (iVar2 != 0);
    *(undefined *)((int64_t)iVar1 + -6 + iVar4) = 0;
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242429;
        iVar5 = func_0x0001802248d0((int64_t)(iVar1 + -0x10), 0x1804e3ed0, 0x32d);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242422;
        iVar5 = func_0x0001802252b0();
    }
    **(int64_t **)((int64_t)&arg_30h + iVar3) = iVar5;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242445;
        func_0x000180498030(iVar5, iVar4 + 0xb, (int64_t)(iVar1 + -0x10));
        uVar7 = 1;
    }
code_r0x00018024247c:
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802424b8;
        func_0x000180224990(iVar4, 0x1804e3ed0, 0x334);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802424a4;
        func_0x000180225130(iVar4, 0x100, 0x1804e3ed0, 0x334);
    }
    return uVar7;
}

// ============================================================
// Function: FUN_180242380
// Address: 0x180242380
// Size: 269 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180242310(undefined8 placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024232d;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242365;
        iVar4 = func_0x0001802248d0(0x100, 0x1804e3ed0, 0x317);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024235e;
        iVar4 = func_0x0001802252b0();
    }
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    uVar6 = 1;
    do {
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423a1;
            iVar1 = func_0x00018021a200(placeholder_0, iVar4, 0xff);
            if (iVar1 < 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242452;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024246a;
                func_0x0001802295a0(0x1804e3ed0, 799, 0x1804e40d0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024247c;
                func_0x0001802296d0(9, 0x6c, 0);
                goto code_r0x00018024247c;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423bd;
            iVar1 = func_0x000180242b30(iVar4, iVar1, (uint32_t)placeholder_2 & 0xfffffffb, uVar6);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423d8;
            iVar2 = func_0x000180498f90(iVar4, 0x1804e4098, 0xb);
            uVar6 = uVar7;
        } while ((iVar2 != 0) || (uVar6 = 0, iVar1 < 6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423fa;
        iVar2 = func_0x000180498f90((int64_t)iVar1 + -6 + iVar4, 0x1804e40a4, 6);
    } while (iVar2 != 0);
    *(undefined *)((int64_t)iVar1 + -6 + iVar4) = 0;
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242429;
        iVar5 = func_0x0001802248d0((int64_t)(iVar1 + -0x10), 0x1804e3ed0, 0x32d);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242422;
        iVar5 = func_0x0001802252b0();
    }
    **(int64_t **)((int64_t)&arg_30h + iVar3) = iVar5;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242445;
        func_0x000180498030(iVar5, iVar4 + 0xb, (int64_t)(iVar1 + -0x10));
        uVar7 = 1;
    }
code_r0x00018024247c:
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802424b8;
        func_0x000180224990(iVar4, 0x1804e3ed0, 0x334);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802424a4;
        func_0x000180225130(iVar4, 0x100, 0x1804e3ed0, 0x334);
    }
    return uVar7;
}

// ============================================================
// Function: FUN_18024248d
// Address: 0x18024248d
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8
fcn.180242310(undefined8 placeholder_0, int64_t arg2, uint64_t placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uVar6;
    undefined8 uVar7;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18024232d;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar7 = 0;
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242365;
        iVar4 = func_0x0001802248d0(0x100, 0x1804e3ed0, 0x317);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024235e;
        iVar4 = func_0x0001802252b0();
    }
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    uVar6 = 1;
    do {
        do {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423a1;
            iVar1 = func_0x00018021a200(placeholder_0, iVar4, 0xff);
            if (iVar1 < 1) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242452;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024246a;
                func_0x0001802295a0(0x1804e3ed0, 799, 0x1804e40d0);
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18024247c;
                func_0x0001802296d0(9, 0x6c, 0);
                goto code_r0x00018024247c;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423bd;
            iVar1 = func_0x000180242b30(iVar4, iVar1, (uint32_t)placeholder_2 & 0xfffffffb, uVar6);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423d8;
            iVar2 = func_0x000180498f90(iVar4, 0x1804e4098, 0xb);
            uVar6 = uVar7;
        } while ((iVar2 != 0) || (uVar6 = 0, iVar1 < 6));
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802423fa;
        iVar2 = func_0x000180498f90((int64_t)iVar1 + -6 + iVar4, 0x1804e40a4, 6);
    } while (iVar2 != 0);
    *(undefined *)((int64_t)iVar1 + -6 + iVar4) = 0;
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242429;
        iVar5 = func_0x0001802248d0((int64_t)(iVar1 + -0x10), 0x1804e3ed0, 0x32d);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242422;
        iVar5 = func_0x0001802252b0();
    }
    **(int64_t **)((int64_t)&arg_30h + iVar3) = iVar5;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180242445;
        func_0x000180498030(iVar5, iVar4 + 0xb, (int64_t)(iVar1 + -0x10));
        uVar7 = 1;
    }
code_r0x00018024247c:
    if ((placeholder_2 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802424b8;
        func_0x000180224990(iVar4, 0x1804e3ed0, 0x334);
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802424a4;
        func_0x000180225130(iVar4, 0x100, 0x1804e3ed0, 0x334);
    }
    return uVar7;
}

// ============================================================
// Function: FUN_1802424d0
// Address: 0x1802424d0
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.1802424d0(int64_t arg_28h, int64_t arg_30h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t iVar4;
    char *pcVar5;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802424e5;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802424f3;
    iVar1 = fcn.180498cd0();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802424fe;
    iVar2 = fcn.180498cd0(in_RDX);
    if (iVar2 + 1 < iVar1) {
        iVar4 = ((int64_t)iVar1 - (int64_t)iVar2) + in_RCX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024251e;
        iVar1 = fcn.180498f10(iVar4, in_RDX);
        if ((iVar1 == 0) && (pcVar5 = (char *)(iVar4 + -1), *pcVar5 == ' ')) {
            return (int32_t)pcVar5 - (int32_t)in_RCX;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180242550
// Address: 0x180242550
// Size: 1497 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180242550(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined *puVar1;
    undefined uVar2;
    char cVar3;
    bool bVar4;
    int64_t iVar5;
    bool bVar6;
    int32_t iVar7;
    int32_t iVar8;
    uint32_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 uVar13;
    uint8_t *puVar14;
    uint32_t uVar15;
    int64_t iVar16;
    uint64_t uVar18;
    int64_t iVar19;
    char *pcVar20;
    int64_t in_R8;
    undefined8 in_R9;
    uint64_t uVar21;
    int64_t aiStackX_8 [4];
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_50h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_18h;
    uint64_t uVar17;
    
    uStack_48 = 0x18024256c;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar10);
    uVar17 = 0;
    bVar6 = false;
    var_a0h = arg_28h;
    var_88h = arg_30h;
    var_90h = arg_38h;
    var_98h = 0;
    var_a8h = 0;
    var_b8h = 0;
    var_b0h._0_4_ = 0;
    uVar18 = uVar17;
    uVar21 = uVar17;
    var_80h = in_RCX;
    var_78h = in_RDX;
    var_70h = in_R8;
    while( true ) {
        iVar12 = var_a8h;
        iVar5 = var_b8h;
        if ((arg_40h & 1U) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024262f;
            func_0x000180224990(uVar21, 0x1804e3ed0, 0x100);
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242644;
            func_0x000180224990(iVar12, 0x1804e3ed0, 0x101);
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242659;
            func_0x000180224990(iVar5, 0x1804e3ed0, 0x102);
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802425ec;
            func_0x000180225130(uVar21, 0, 0x1804e3ed0, 0x100);
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242603;
            func_0x000180225130(iVar12, 0, 0x1804e3ed0, 0x101);
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024261b;
            func_0x000180225130(iVar5, (int64_t)(int32_t)uVar18, 0x1804e3ed0, 0x102);
        }
        *(undefined4 *)((int64_t)&var_18h + iVar10) = (undefined4)arg_40h;
        *(int64_t **)((int64_t)&var_20h + iVar10) = &var_b0h;
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242681;
        iVar7 = fcn.1802416f0(var_a0h, (int64_t)&var_98h, &var_a8h, &var_b8h, *(int64_t *)((int64_t)&var_20h + iVar10), 
                              *(int64_t *)((int64_t)&var_18h + iVar10), 
                              *(undefined8 *)(&stack0xfffffffffffffff0 + iVar10), 
                              *(undefined8 *)(&stack0xfffffffffffffff8 + iVar10), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar10 + -8), 
                              *(int64_t *)((int64_t)aiStackX_8 + iVar10), *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 8)
                              , *(int64_t *)((int64_t)aiStackX_8 + iVar10 + 0x10));
        uVar21 = var_98h;
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242adb;
            uVar9 = func_0x000180220920();
            if ((((int32_t)uVar9 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar9) == 0x6c) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242b07;
                func_0x000180220250(2, 0x1804e4010, in_R9);
            }
            goto code_r0x000180242b09;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242698;
        iVar7 = fcn.180241d80(*(int64_t *)((int64_t)&var_20h + iVar10), *(int64_t *)(&stack0xfffffffffffffff0 + iVar10))
        ;
        iVar5 = var_a8h;
        if (iVar7 != 0) break;
        uVar18 = (uint64_t)(uint32_t)var_b0h;
    }
    var_68h = 0;
    _var_60h = ZEXT816(0);
    if (((var_a8h == 0) || (*(char *)var_a8h == '\0')) || (*(char *)var_a8h == '\n')) {
code_r0x00018024296b:
        iVar16 = var_b8h;
        *(int64_t *)((int64_t)&var_20h + iVar10) = var_90h;
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024298c;
        iVar7 = func_0x000180241020(&var_68h, var_b8h, &var_b0h, var_88h);
        if (iVar7 == 0) goto code_r0x0001802427bd;
        bVar4 = true;
        *(int64_t *)var_80h = iVar16;
        *(uint32_t *)var_78h = (uint32_t)var_b0h;
        bVar6 = true;
        if (var_70h == 0) goto code_r0x0001802427bd;
        *(uint64_t *)var_70h = uVar21;
        bVar6 = true;
        if ((arg_40h & 1U) != 0) goto code_r0x0001802427dd;
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802426ed;
        iVar7 = func_0x000180498f90(var_a8h, 0x1804e4050, 10);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a4b;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a63;
            func_0x0001802295a0(0x1804e3ed0, 0x215, 0x1804e4060);
            uVar13 = 0x6b;
            goto code_r0x0001802427af;
        }
        iVar12 = iVar5 + 10;
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242708;
        iVar11 = func_0x00018046ed00(iVar12, 0x180645718);
        iVar16 = var_b8h;
        if ((*(char *)(iVar11 + iVar12) != '4') || (iVar19 = iVar11 + iVar12 + 2, *(char *)(iVar11 + iVar12 + 1) != ',')
           ) goto code_r0x0001802427bd;
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242735;
        iVar12 = func_0x00018046ed00(iVar19, 0x180645718);
        iVar19 = iVar19 + iVar12;
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024274d;
        iVar7 = func_0x000180498f90(iVar19, 0x1804e3ee8, 9);
        if (iVar7 == 0) {
            iVar19 = iVar19 + 9;
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242768;
            iVar12 = func_0x00018046ed00(iVar19, 0x1804a6100);
            if (iVar12 == 0) goto code_r0x000180242a1c;
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242780;
            iVar12 = func_0x00018046ed00(iVar19, 0x1804e4078);
            if (*(char *)(iVar12 + iVar19) == '\n') {
                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024280f;
                iVar7 = func_0x000180498f90(iVar12 + iVar19 + 1, 0x1804e4080, 9);
                if (iVar7 == 0) {
                    iVar16 = iVar12 + iVar19 + 10;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024282a;
                    iVar12 = func_0x00018046ed00(iVar16, 0x180645718);
                    iVar12 = iVar12 + iVar16;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024283d;
                    iVar16 = func_0x000180461e90(iVar12, 0x1804e408c);
                    uVar2 = *(undefined *)(iVar16 + iVar12);
                    *(undefined *)(iVar16 + iVar12) = 0;
                    puVar1 = (undefined *)(iVar16 + iVar12);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242851;
                    var_a0h = func_0x00018022e080(iVar12);
                    *puVar1 = uVar2;
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024286a;
                    var_68h = var_a0h;
                    iVar16 = func_0x00018046ed00(puVar1, 0x180645718);
                    iVar12 = var_a0h;
                    pcVar20 = puVar1 + iVar16;
                    if (var_a0h == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024287c;
                        func_0x000180229480();
                        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242894;
                        func_0x0001802295a0(0x1804e3ed0, 0x241, 0x1804e4060);
                        uVar13 = 0x72;
                    } else {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802428a9;
                        iVar7 = func_0x00018020ef90(var_a0h);
                        if (iVar7 < 1) {
                            if ((iVar7 != 0) || (*pcVar20 != ',')) goto code_r0x000180242912;
                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802428ed;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242905;
                            func_0x0001802295a0(0x1804e3ed0, 0x249, 0x1804e4060);
                            uVar13 = 0x82;
                        } else {
                            cVar3 = *pcVar20;
                            pcVar20 = pcVar20 + 1;
                            if (cVar3 == ',') {
code_r0x000180242912:
                                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024291a;
                                iVar7 = func_0x00018020ef90(iVar12);
                                if (0 < iVar7) {
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024292f;
                                    func_0x0001804986e0(&var_60h, 0, (int64_t)iVar7);
                                }
                                if (0 < iVar7 * 2) {
                                    do {
                                        cVar3 = *pcVar20;
                                        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242940;
                                        iVar8 = func_0x000180223440(cVar3);
                                        if (iVar8 < 0) {
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802429cd;
                                            func_0x000180229480();
                                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802429e5;
                                            func_0x0001802295a0(0x1804e3ed0, 0x25f, 0x1804e4090);
                                            uVar13 = 0x67;
                                            goto code_r0x0001802427af;
                                        }
                                        uVar9 = (uint32_t)uVar17;
                                        pcVar20 = pcVar20 + 1;
                                        puVar14 = (uint8_t *)((int64_t)&var_60h + (uVar17 >> 1));
                                        uVar15 = uVar9 + 1;
                                        uVar17 = (uint64_t)uVar15;
                                        *puVar14 = *puVar14 | (char)iVar8 << (int8_t)((~uVar9 & 1) << 2);
                                    } while ((int32_t)uVar15 < iVar7 * 2);
                                }
                                goto code_r0x00018024296b;
                            }
                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802428bc;
                            func_0x000180229480();
                            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802428d4;
                            func_0x0001802295a0(0x1804e3ed0, 0x246, 0x1804e4060);
                            uVar13 = 0x81;
                        }
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802429f7;
                    func_0x000180229480();
                    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a0f;
                    func_0x0001802295a0(0x1804e3ed0, 0x22f, 0x1804e4060);
                    uVar13 = 0x69;
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x18024278f;
                func_0x000180229480();
                *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802427a7;
                func_0x0001802295a0(0x1804e3ed0, 0x226, 0x1804e4060);
                uVar13 = 0x70;
            }
        } else {
code_r0x000180242a1c:
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a21;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a39;
            func_0x0001802295a0(0x1804e3ed0, 0x221, 0x1804e4060);
            uVar13 = 0x6a;
        }
code_r0x0001802427af:
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802427b9;
        func_0x0001802296d0(9, uVar13, 0);
        iVar16 = var_b8h;
code_r0x0001802427bd:
        bVar4 = bVar6;
        if ((arg_40h & 1U) != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802427dd;
            func_0x000180225130(uVar21, 0, 0x1804e3ed0, 0x118);
            bVar6 = bVar4;
code_r0x0001802427dd:
            bVar4 = bVar6;
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x1802427f4;
            func_0x000180225130(iVar5, 0, 0x1804e3ed0, 0x119);
            goto code_r0x000180242a97;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a82;
        func_0x000180224990(uVar21, 0x1804e3ed0, 0x118);
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242a97;
    func_0x000180224990(iVar5, 0x1804e3ed0, 0x119);
code_r0x000180242a97:
    if (!bVar4) {
        if ((arg_40h & 1U) == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242ad1;
            func_0x000180224990(iVar16, 0x1804e3ed0, 0x11b);
        } else {
            *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242aba;
            func_0x000180225130(iVar16, (int64_t)(int32_t)(uint32_t)var_b0h, 0x1804e3ed0, 0x11b);
        }
    }
code_r0x000180242b09:
    *(undefined8 *)((int64_t)&uStack_48 + iVar10) = 0x180242b15;
    func_0x000180459870(var_50h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_180242b30
// Address: 0x180242b30
// Size: 289 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.180242b30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    int16_t *in_RCX;
    int32_t in_EDX;
    int64_t iVar4;
    int16_t *piVar5;
    uint32_t uVar6;
    int32_t iVar7;
    uint64_t uVar8;
    uint64_t in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180242b4b;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = (uint64_t)in_EDX;
    if ((((in_R9D != 0) && (*(undefined2 *)((int64_t)&arg_30h + iVar3) = 0xbbef, 3 < in_EDX)) &&
        (*in_RCX == *(int16_t *)((int64_t)&arg_30h + iVar3))) && (*(char *)(in_RCX + 1) == -0x41)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180242b85;
        func_0x000180498030();
        *(char *)((uVar8 - 3) + (int64_t)in_RCX) = '\0';
        uVar8 = (uint64_t)(in_EDX - 3);
    }
    uVar6 = (uint32_t)uVar8;
    iVar4 = (int64_t)(int32_t)uVar6;
    if ((in_R8 & 2) == 0) {
        iVar7 = 0;
        if ((in_R8 & 4) == 0) {
            piVar5 = in_RCX;
            if (0 < iVar4) {
                do {
                    cVar1 = *(char *)piVar5;
                    if ((cVar1 == '\n') || (cVar1 == '\r')) break;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180242c17;
                    iVar2 = func_0x000180275490((int32_t)cVar1, 0x40);
                    if (iVar2 != 0) {
                        *(char *)piVar5 = ' ';
                    }
                    piVar5 = (int16_t *)((int64_t)piVar5 + 1);
                    iVar7 = iVar7 + 1;
                } while ((int64_t)piVar5 - (int64_t)in_RCX < iVar4);
            }
        } else {
            piVar5 = in_RCX;
            if (0 < iVar4) {
                do {
                    cVar1 = *(char *)piVar5;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180242bd0;
                    iVar2 = func_0x000180275490((int32_t)cVar1, 0x400);
                    if (((iVar2 == 0) || (*(char *)piVar5 == '\n')) || (*(char *)piVar5 == '\r')) break;
                    piVar5 = (int16_t *)((int64_t)piVar5 + 1);
                    iVar7 = iVar7 + 1;
                } while ((int64_t)piVar5 - (int64_t)in_RCX < iVar4);
            }
        }
    } else {
        if (-1 < (int32_t)uVar6) {
            do {
                uVar6 = (uint32_t)uVar8;
                if (' ' < *(char *)((int64_t)in_RCX + iVar4)) break;
                uVar6 = uVar6 - 1;
                uVar8 = (uint64_t)uVar6;
                iVar4 = iVar4 + -1;
            } while (-1 < iVar4);
        }
        iVar7 = uVar6 + 1;
    }
    *(undefined2 *)((int64_t)iVar7 + (int64_t)in_RCX) = 10;
    return iVar7 + 1;
}

// ============================================================
// Function: FUN_180242c60
// Address: 0x180242c60
// Size: 53 bytes
// ============================================================
void fcn.180242c60(int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180242c6a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = in_R8;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180242c90;
    fcn.180244fe0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                  *(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000040 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                  *(int64_t *)(&stack0x00000088 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180242ca0
// Address: 0x180242ca0
// Size: 43 bytes
// ============================================================
void fcn.180242ca0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180242caa;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_30h + iVar1) = 0x87;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180242cc6;
    fcn.180242d10(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                  *(int64_t *)(&stack0x00000090 + iVar1), *(int64_t *)(&stack0x00000098 + iVar1), 
                  *(int64_t *)(&stack0x000000a0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180242cd0
// Address: 0x180242cd0
// Size: 51 bytes
// ============================================================
void fcn.180242cd0(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180242cda;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined4 *)((int64_t)&arg_30h + iVar1) = 0x87;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = *(undefined8 *)((int64_t)&arg_78h + iVar1);
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180242cfe;
    fcn.180242d10(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)((int64_t)&arg_70h + iVar1), 
                  *(int64_t *)(&stack0x00000090 + iVar1), *(int64_t *)(&stack0x00000098 + iVar1), 
                  *(int64_t *)(&stack0x000000a0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180242d10
// Address: 0x180242d10
// Size: 202 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180242d10(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_78h, int64_t arg_98h,
                     int64_t arg_a0h, int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180242d2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = 0;
    *(undefined (*) [16])((int64_t)&var_18h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar5) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d61;
    iVar3 = func_0x000180219d10(0, 0x85, 0, 0);
    iVar7 = iVar8;
    if (iVar3 < 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d6d;
        uVar6 = func_0x0001802b3f00();
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d75;
        iVar7 = func_0x00018021a7c0(uVar6);
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d8c;
        in_RCX = func_0x00018021a960(iVar7, in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242da2;
        iVar3 = func_0x000180219d10(in_RCX, 0x85, 0, 0);
    }
    iVar9 = 0x180240f40;
    if (in_R8 != 0) {
        iVar9 = in_R8;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242dc0;
    iVar4 = func_0x0001802b4970((int64_t)&var_18h + iVar5, iVar9, in_R9);
    if (iVar4 == 0) goto code_r0x000180242e83;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242dd2;
    iVar4 = func_0x0001802b44d0((int64_t)&var_18h + iVar5);
    if (iVar4 == 0) goto code_r0x000180242e83;
    *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242de7;
    func_0x000180229b10();
    uVar1 = *(undefined4 *)((int64_t)&arg_a8h + iVar5);
    uVar6 = *(undefined8 *)((int64_t)&arg_a0h + iVar5);
    uVar2 = *(undefined8 *)((int64_t)&arg_98h + iVar5);
    *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar1;
    *(undefined8 *)(&stack0x00000000 + iVar5) = uVar6;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e23;
    iVar8 = func_0x000180242ec0(in_RCX, in_RDX, 0x1802b4830, (int64_t)&var_18h + iVar5);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e3e;
        iVar3 = func_0x000180219d10(in_RCX, 0x80, iVar3, 0);
        if (-1 < iVar3) {
            *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar1;
            *(undefined8 *)(&stack0x00000000 + iVar5) = uVar6;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e67;
            iVar8 = func_0x0001802430f0(in_RCX, in_RDX, 0x1802b4830, (int64_t)&var_18h + iVar5);
            if (iVar8 != 0) goto code_r0x000180242e76;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e74;
        func_0x000180229900();
    } else {
code_r0x000180242e76:
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e7b;
        func_0x0001802299d0();
    }
code_r0x000180242e83:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e8d;
    func_0x0001802b4460((int64_t)&var_18h + iVar5);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e9a;
        func_0x00018021a8e0(iVar7);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242ea2;
        func_0x000180219f80(iVar7);
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180242dda
// Address: 0x180242dda
// Size: 169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180242d10(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_78h, int64_t arg_98h,
                     int64_t arg_a0h, int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180242d2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = 0;
    *(undefined (*) [16])((int64_t)&var_18h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar5) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d61;
    iVar3 = func_0x000180219d10(0, 0x85, 0, 0);
    iVar7 = iVar8;
    if (iVar3 < 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d6d;
        uVar6 = func_0x0001802b3f00();
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d75;
        iVar7 = func_0x00018021a7c0(uVar6);
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d8c;
        in_RCX = func_0x00018021a960(iVar7, in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242da2;
        iVar3 = func_0x000180219d10(in_RCX, 0x85, 0, 0);
    }
    iVar9 = 0x180240f40;
    if (in_R8 != 0) {
        iVar9 = in_R8;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242dc0;
    iVar4 = func_0x0001802b4970((int64_t)&var_18h + iVar5, iVar9, in_R9);
    if (iVar4 == 0) goto code_r0x000180242e83;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242dd2;
    iVar4 = func_0x0001802b44d0((int64_t)&var_18h + iVar5);
    if (iVar4 == 0) goto code_r0x000180242e83;
    *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242de7;
    func_0x000180229b10();
    uVar1 = *(undefined4 *)((int64_t)&arg_a8h + iVar5);
    uVar6 = *(undefined8 *)((int64_t)&arg_a0h + iVar5);
    uVar2 = *(undefined8 *)((int64_t)&arg_98h + iVar5);
    *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar1;
    *(undefined8 *)(&stack0x00000000 + iVar5) = uVar6;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e23;
    iVar8 = func_0x000180242ec0(in_RCX, in_RDX, 0x1802b4830, (int64_t)&var_18h + iVar5);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e3e;
        iVar3 = func_0x000180219d10(in_RCX, 0x80, iVar3, 0);
        if (-1 < iVar3) {
            *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar1;
            *(undefined8 *)(&stack0x00000000 + iVar5) = uVar6;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e67;
            iVar8 = func_0x0001802430f0(in_RCX, in_RDX, 0x1802b4830, (int64_t)&var_18h + iVar5);
            if (iVar8 != 0) goto code_r0x000180242e76;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e74;
        func_0x000180229900();
    } else {
code_r0x000180242e76:
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e7b;
        func_0x0001802299d0();
    }
code_r0x000180242e83:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e8d;
    func_0x0001802b4460((int64_t)&var_18h + iVar5);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e9a;
        func_0x00018021a8e0(iVar7);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242ea2;
        func_0x000180219f80(iVar7);
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180242e83
// Address: 0x180242e83
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180242d10(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_78h, int64_t arg_98h,
                     int64_t arg_a0h, int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 in_RCX;
    undefined8 in_RDX;
    int64_t iVar9;
    int64_t in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180242d2c;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar8 = 0;
    *(undefined (*) [16])((int64_t)&var_18h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_28h + iVar5) = ZEXT816(0);
    *(undefined (*) [16])((int64_t)&arg_38h + iVar5) = ZEXT816(0);
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d61;
    iVar3 = func_0x000180219d10(0, 0x85, 0, 0);
    iVar7 = iVar8;
    if (iVar3 < 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d6d;
        uVar6 = func_0x0001802b3f00();
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d75;
        iVar7 = func_0x00018021a7c0(uVar6);
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242d8c;
        in_RCX = func_0x00018021a960(iVar7, in_RCX);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242da2;
        iVar3 = func_0x000180219d10(in_RCX, 0x85, 0, 0);
    }
    iVar9 = 0x180240f40;
    if (in_R8 != 0) {
        iVar9 = in_R8;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242dc0;
    iVar4 = func_0x0001802b4970((int64_t)&var_18h + iVar5, iVar9, in_R9);
    if (iVar4 == 0) goto code_r0x000180242e83;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242dd2;
    iVar4 = func_0x0001802b44d0((int64_t)&var_18h + iVar5);
    if (iVar4 == 0) goto code_r0x000180242e83;
    *(undefined8 *)((int64_t)&arg_78h + iVar5) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242de7;
    func_0x000180229b10();
    uVar1 = *(undefined4 *)((int64_t)&arg_a8h + iVar5);
    uVar6 = *(undefined8 *)((int64_t)&arg_a0h + iVar5);
    uVar2 = *(undefined8 *)((int64_t)&arg_98h + iVar5);
    *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar1;
    *(undefined8 *)(&stack0x00000000 + iVar5) = uVar6;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e23;
    iVar8 = func_0x000180242ec0(in_RCX, in_RDX, 0x1802b4830, (int64_t)&var_18h + iVar5);
    if (iVar8 == 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e3e;
        iVar3 = func_0x000180219d10(in_RCX, 0x80, iVar3, 0);
        if (-1 < iVar3) {
            *(undefined4 *)((int64_t)&var_8h + iVar5) = uVar1;
            *(undefined8 *)(&stack0x00000000 + iVar5) = uVar6;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = uVar2;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e67;
            iVar8 = func_0x0001802430f0(in_RCX, in_RDX, 0x1802b4830, (int64_t)&var_18h + iVar5);
            if (iVar8 != 0) goto code_r0x000180242e76;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e74;
        func_0x000180229900();
    } else {
code_r0x000180242e76:
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e7b;
        func_0x0001802299d0();
    }
code_r0x000180242e83:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e8d;
    func_0x0001802b4460((int64_t)&var_18h + iVar5);
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242e9a;
        func_0x00018021a8e0(iVar7);
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180242ea2;
        func_0x000180219f80(iVar7);
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180242ec0
// Address: 0x180242ec0
// Size: 551 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180242ec0(int64_t arg_28h, int64_t arg_38h, int64_t arg_78h, int64_t arg_88h, int64_t arg_a0h)
{
    uint32_t uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 in_RCX;
    undefined8 *in_RDX;
    int64_t iVar8;
    int64_t in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180242ee4;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242f0c;
    iVar3 = func_0x000180219d10();
    if (-1 < iVar3) {
        uVar1 = *(uint32_t *)((int64_t)&arg_88h + iVar6);
        *(undefined8 *)((int64_t)&var_18h + iVar6) = *(undefined8 *)(&stack0x00000080 + iVar6);
        *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)((int64_t)&arg_78h + iVar6);
        *(uint32_t *)((int64_t)&var_8h + iVar6) = uVar1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242f54;
        iVar7 = func_0x000180271890((int64_t)&arg_28h + iVar6, 0x1804b62d8, 0, 0);
        if (iVar7 != 0) {
            iVar8 = 0x180240f40;
            if (in_R8 != 0) {
                iVar8 = in_R8;
            }
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242f79;
            iVar4 = func_0x000180271d50(iVar7, iVar8, in_R9);
            if (iVar4 != 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242f86;
                func_0x000180229b10();
                while( true ) {
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242f9b;
                    iVar4 = func_0x000180270860(iVar7, in_RCX);
                    if ((iVar4 != 0) && (*(int64_t *)((int64_t)&arg_28h + iVar6) != 0)) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243021;
                        func_0x0001802299d0();
                        uVar5 = uVar1 & 0xfffffffd;
                        if ((uVar1 & 1) == 0) {
                            uVar5 = uVar1;
                        }
                        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243039;
                        iVar3 = func_0x00018029f040(*(undefined8 *)((int64_t)&arg_28h + iVar6), uVar5);
                        if (iVar3 == 0) {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243047;
                            func_0x00018022ecc0(*(undefined8 *)((int64_t)&arg_28h + iVar6));
                            *(undefined8 *)((int64_t)&arg_28h + iVar6) = 0;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243055;
                            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18024306d;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                          *(int64_t *)((int64_t)&var_10h + iVar6), 
                                          *(int64_t *)((int64_t)&var_18h + iVar6), 
                                          *(int64_t *)((int64_t)&var_20h + iVar6), 
                                          *(int64_t *)((int64_t)&arg_38h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18024307f;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar6));
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243087;
                            func_0x00018026f440(iVar7);
                            return *(undefined8 *)((int64_t)&arg_28h + iVar6);
                        }
                        if (in_RDX != (undefined8 *)0x0) {
                            uVar2 = *in_RDX;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x18024309b;
                            func_0x00018022ecc0(uVar2);
                            *in_RDX = *(undefined8 *)((int64_t)&arg_28h + iVar6);
                            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802430ab;
                            func_0x00018026f440(iVar7);
                            return *(undefined8 *)((int64_t)&arg_28h + iVar6);
                        }
                        goto code_r0x0001802430b7;
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242fba;
                    iVar4 = func_0x000180219d10(in_RCX, 2, 0, 0);
                    if (iVar4 != 0) break;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242fd5;
                    iVar4 = func_0x000180219d10(in_RCX, 0x85, 0, 0);
                    if ((iVar4 < 0) || (iVar4 <= iVar3)) break;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180242fec;
                    uVar5 = func_0x000180220920();
                    if ((((int32_t)uVar5 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar5) != 0x8010c) break;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243010;
                    func_0x0001802299d0();
                    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180243015;
                    func_0x000180229b10();
                    iVar3 = iVar4;
                }
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802430b7;
                func_0x000180229900();
            }
code_r0x0001802430b7:
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x1802430bf;
            func_0x00018026f440(iVar7);
            return *(undefined8 *)((int64_t)&arg_28h + iVar6);
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802430f0
// Address: 0x1802430f0
// Size: 1028 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_4e8h because it doesn't fit into ProtoModel

void fcn.1802430f0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    int64_t iVar4;
    code *pcVar5;
    uint64_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined4 *puVar11;
    undefined8 in_RCX;
    int64_t *in_RDX;
    code *in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t iStackX_10;
    int64_t var_18h;
    uint32_t auStackX_20 [2];
    int64_t var_458h;
    int64_t var_58h;
    undefined8 uStack_48;
    int64_t var_20h;
    int64_t var_10h;
    
    uStack_48 = 0x18024310f;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar8);
    *(int64_t *)((int64_t)&arg_30h + iVar8) = arg_28h;
    *(int64_t *)((int64_t)&arg_28h + iVar8) = arg_30h;
    *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8) = 0;
    *(undefined8 *)((int64_t)auStackX_20 + iVar8 + -8) = 0;
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024315a;
    func_0x000180229b10();
    iVar10 = arg_38h;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = in_R9;
    *(code **)(&stack0xffffffffffffffe8 + iVar8) = in_R8;
    uVar6 = arg_38h & 1;
    *(undefined8 *)((int64_t)&var_20h + iVar8) = in_RCX;
    *(uint32_t *)((int64_t)auStackX_20 + iVar8) = (uint32_t)arg_38h & 1;
    if (uVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243241;
        iVar7 = fcn.180240ec0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                              *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)((int64_t)&arg_28h + iVar8), 
                              *(int64_t *)((int64_t)&arg_30h + iVar8), *(int64_t *)((int64_t)&arg_38h + iVar8));
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802431a2;
        iVar7 = func_0x000180240f00((int64_t)auStackX_20 + iVar8 + -8, (int64_t)auStackX_20 + iVar8 + -0x20, 
                                    (int64_t)&iStackX_10 + iVar8 + -8, 0x1804e3f20);
    }
    if (iVar7 == 0) {
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024324e;
        func_0x0001802299d0();
        goto code_r0x00018024343e;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802431b5;
    func_0x000180229900();
    uVar3 = *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8);
    *(undefined8 *)((int64_t)&iStackX_10 + iVar8) = *(undefined8 *)((int64_t)auStackX_20 + iVar8 + -8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802431d3;
    iVar7 = fcn.180498f10(uVar3, 0x1804e3f48);
    if (iVar7 == 0) {
        uVar1 = *(undefined4 *)((int64_t)auStackX_20 + iVar8 + -0x20);
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802431e8;
        iVar9 = func_0x0001802af1a0(0, (int64_t)&iStackX_10 + iVar8, uVar1);
        if (iVar9 != 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243206;
            iVar10 = func_0x0001802af520(iVar9, *(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                         *(undefined8 *)((int64_t)&arg_28h + iVar8));
            if (in_RDX != (int64_t *)0x0) {
                iVar4 = *in_RDX;
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243216;
                func_0x00018022ecc0(iVar4);
                *in_RDX = iVar10;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243221;
            func_0x0001802af020(iVar9);
            goto code_r0x0001802433cb;
        }
code_r0x0001802433d0:
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802433d5;
        iVar7 = func_0x000180220a00();
        if (iVar7 == 0) {
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802433de;
            fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802433f6;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                          *(int64_t *)((int64_t)&var_10h + iVar8), *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                          *(int64_t *)((int64_t)&iStackX_10 + iVar8));
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243408;
            fcn.1802296d0(*(int64_t *)((int64_t)auStackX_20 + iVar8 + -0x20));
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243264;
        iVar7 = fcn.180498f10(uVar3, 0x1804e3f30);
        if (iVar7 == 0) {
            uVar1 = *(undefined4 *)((int64_t)auStackX_20 + iVar8 + -0x20);
            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024327d;
            iVar10 = func_0x0001802b2c20(0, (int64_t)&iStackX_10 + iVar8, uVar1);
            if (iVar10 != 0) {
                if (in_R8 == (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432a7;
                    iVar7 = func_0x000180240f40(&var_458h, 0x400, 0, in_R9);
                } else {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432a0;
                    iVar7 = (*in_R8)();
                }
                if (iVar7 < 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432b2;
                    fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432ca;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                  *(int64_t *)(&stack0xffffffffffffffe8 + iVar8), 
                                  *(int64_t *)((int64_t)&var_10h + iVar8), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar8), 
                                  *(int64_t *)((int64_t)&iStackX_10 + iVar8));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432dc;
                    fcn.1802296d0(*(int64_t *)((int64_t)auStackX_20 + iVar8 + -0x20));
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432e4;
                    func_0x0001802b2bf0(iVar10);
                    goto code_r0x000180243408;
                }
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802432f8;
                iVar9 = func_0x0001802b3f90(iVar10, &var_458h, iVar7);
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243303;
                func_0x0001802b2bf0(iVar10);
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024330f;
                func_0x000180244fc0(&var_458h, (int64_t)iVar7);
                if (iVar9 != 0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024332a;
                    iVar10 = func_0x0001802af520(iVar9, *(undefined8 *)((int64_t)&arg_30h + iVar8), 
                                                 *(undefined8 *)((int64_t)&arg_28h + iVar8));
                    if (in_RDX != (int64_t *)0x0) {
                        iVar4 = *in_RDX;
                        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024333a;
                        func_0x00018022ecc0(iVar4);
                        *in_RDX = iVar10;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243345;
                    func_0x0001802af020(iVar9);
                    goto code_r0x0001802433cb;
                }
            }
            goto code_r0x0001802433d0;
        }
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x180243359;
        iVar7 = fcn.1802424d0(*(int64_t *)((int64_t)&var_20h + iVar8), *(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
        if (iVar7 < 1) {
            if ((*(int32_t *)((int64_t)auStackX_20 + iVar8) == 0) && ((iVar10 & 2U) != 0)) {
                uVar1 = *(undefined4 *)((int64_t)auStackX_20 + iVar8 + -0x20);
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802433c8;
                iVar10 = func_0x000180236e50(in_RDX, (int64_t)&iStackX_10 + iVar8, uVar1);
                goto code_r0x0001802433cb;
            }
            if ((iVar10 & 0x87U) == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024347c;
                iVar7 = fcn.1802424d0(*(int64_t *)((int64_t)&var_20h + iVar8), 
                                      *(int64_t *)(&stack0xffffffffffffffe8 + iVar8));
                if (0 < iVar7) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024348b;
                    iVar10 = func_0x00018022fd80();
                    if (iVar10 != 0) {
                        uVar3 = *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8);
                        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802434a7;
                        iVar7 = func_0x0001802307c0(iVar10, uVar3, iVar7);
                        if ((iVar7 != 0) &&
                           (pcVar5 = *(code **)(*(int64_t *)(iVar10 + 8) + 0x70), pcVar5 != (code *)0x0)) {
                            uVar1 = *(undefined4 *)((int64_t)auStackX_20 + iVar8 + -0x20);
                            *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802434c8;
                            iVar7 = (*pcVar5)(iVar10, (int64_t)&iStackX_10 + iVar8, uVar1);
                            if (iVar7 != 0) {
                                if (in_RDX != (int64_t *)0x0) {
                                    iVar9 = *in_RDX;
                                    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802434dd;
                                    func_0x00018022ecc0(iVar9);
                                    *in_RDX = iVar10;
                                }
                                goto code_r0x000180243408;
                            }
                        }
                        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802434ed;
                        func_0x00018022ecc0(iVar10);
                    }
                    goto code_r0x000180243408;
                }
            }
            goto code_r0x0001802433d0;
        }
        uVar3 = *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8);
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024336c;
        puVar11 = (undefined4 *)func_0x0001802479a0(0, uVar3, iVar7);
        if ((puVar11 == (undefined4 *)0x0) || (*(int64_t *)(puVar11 + 0x2e) == 0)) goto code_r0x0001802433d0;
        uVar1 = *(undefined4 *)((int64_t)auStackX_20 + iVar8 + -0x20);
        *(undefined8 *)(&stack0xffffffffffffffe8 + iVar8) = *(undefined8 *)((int64_t)&arg_28h + iVar8);
        *(undefined8 *)((int64_t)&var_20h + iVar8) = *(undefined8 *)((int64_t)&arg_30h + iVar8);
        uVar2 = *puVar11;
        *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x1802433a2;
        iVar10 = func_0x0001802400c0(uVar2, in_RDX, (int64_t)&iStackX_10 + iVar8, uVar1);
code_r0x0001802433cb:
        if (iVar10 == 0) goto code_r0x0001802433d0;
    }
code_r0x000180243408:
    uVar3 = *(undefined8 *)((int64_t)&iStackX_10 + iVar8 + -8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024341f;
    func_0x000180225200(uVar3, 0x1804e4128, 0xd3);
    iVar7 = *(int32_t *)((int64_t)auStackX_20 + iVar8 + -0x20);
    uVar3 = *(undefined8 *)((int64_t)auStackX_20 + iVar8 + -8);
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024343b;
    func_0x000180225130(uVar3, (int64_t)iVar7, 0x1804e4128, 0xd4);
code_r0x00018024343e:
    *(undefined8 *)((int64_t)&uStack_48 + iVar8) = 0x18024344d;
    func_0x000180459870(var_58h ^ (uint64_t)(&stack0xffffffffffffffc0 + iVar8));
    return;
}

// ============================================================
// Function: FUN_180243500
// Address: 0x180243500
// Size: 87 bytes
// ============================================================
undefined8 fcn.180243500(undefined8 param_1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024350c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180243529;
    puVar2 = (undefined8 *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (puVar2 == (undefined8 *)0x0) {
        return 0;
    }
    *puVar2 = param_1;
    puVar2[1] = *(undefined8 *)0x18077e4d8;
    *(undefined8 **)0x18077e4d8 = puVar2;
    return 1;
}

// ============================================================
// Function: FUN_180243560
// Address: 0x180243560
// Size: 1280 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

bool fcn.180243560(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t iStackX_18;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024357a;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar4 = 0;
    if (*(int32_t *)0x18077e4c8 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802435f0;
        iVar1 = fcn.1802229a0(0x18077e4d0, (int64_t)&arg_38h + iVar5, 0);
        iVar3 = iVar4;
        if (iVar1 != 0) {
            if ((*(uint64_t *)((int64_t)&arg_38h + iVar5) & in_RCX) == in_RCX) {
                return true;
            }
            iVar3 = 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024361d;
        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
        iVar1 = iVar4;
        if (iVar2 != 0) {
            iVar1 = *(int32_t *)0x18077e4f8;
        }
        if (iVar1 != 0) {
            if ((in_RCX >> 0x12 & 1) != 0) {
                return true;
            }
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243653;
                iVar3 = fcn.1802229a0(0x18077e4d0, (int64_t)&arg_38h + iVar5, *(undefined8 *)0x18077e4e0);
                if (iVar3 == 0) {
                    return false;
                }
                if ((*(uint64_t *)((int64_t)&arg_38h + iVar5) & in_RCX) == in_RCX) {
                    return true;
                }
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024368d;
            iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
            iVar3 = iVar4;
            if (iVar1 != 0) {
                iVar3 = *(int32_t *)0x18077e500;
            }
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802436b3;
                iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                iVar3 = iVar4;
                if (iVar1 != 0) {
                    iVar3 = *(int32_t *)0x18077e508;
                }
                if (iVar3 != 0) {
                    if ((in_RCX & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802436de;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar3 = iVar4;
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e510;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    iVar3 = 0;
                    if ((in_RCX & 2) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243709;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e510;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 0x14 & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243736;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e518;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 0x15 & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243763;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e518;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX & 0x10) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024378e;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e520;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX & 4) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802437b9;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e520;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX & 0x20) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802437e4;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e528;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX & 8) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024380f;
                        iVar2 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar1 = iVar3;
                        if (iVar2 != 0) {
                            iVar1 = *(int32_t *)0x18077e528;
                        }
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 0x11 & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024382e;
                        iVar1 = fcn.180005d40();
                        if (iVar1 == 0) {
                            return false;
                        }
                    }
                    if ((char)in_RCX < '\0') {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024384d;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e534;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX & 0x40) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243875;
                        iVar6 = fcn.180222760(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        if (iVar6 == 0) {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243891;
                            iVar3 = fcn.1802228e0(0x18077e4cc, 0xffffffffffffffff);
                            if (iVar3 == 0) {
                                return false;
                            }
                            if (in_RDX == 0) {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802438b1;
                                iVar3 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                                if (iVar3 != 0) {
                                    iVar4 = *(int32_t *)0x18077e534;
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802438ca;
                                iVar3 = fcn.180222950(*(undefined8 *)0x18077e4e8);
                                if (iVar3 == 0) {
                                    return false;
                                }
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802438ec;
                                iVar3 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                                *(undefined8 *)0x18077e538 = 0;
                                if (iVar3 != 0) {
                                    iVar4 = *(int32_t *)0x18077e534;
                                }
                                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024390a;
                                fcn.180222910(*(undefined8 *)0x18077e4e8);
                            }
                            if (iVar4 < 1) {
                                return false;
                            }
                        }
                    }
                    iVar4 = 0;
                    if ((in_RCX >> 8 & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024392c;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar3 = iVar4;
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e548;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 0xb & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243959;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar3 = iVar4;
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e550;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 9 & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243986;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar3 = iVar4;
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e558;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 10 & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802439b3;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar3 = iVar4;
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e560;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 0xe & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802439e0;
                        iVar1 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        iVar3 = iVar4;
                        if (iVar1 != 0) {
                            iVar3 = *(int32_t *)0x18077e568;
                        }
                        if (iVar3 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX >> 0xd & 1) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243a0d;
                        iVar3 = fcn.180222870(*(int64_t *)((int64_t)&iStackX_18 + iVar5));
                        if (iVar3 != 0) {
                            iVar4 = *(int32_t *)0x18077e570;
                        }
                        if (iVar4 == 0) {
                            return false;
                        }
                    }
                    if ((in_RCX & 0xfe00) != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243a2e;
                        fcn.1802b59a0();
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180243a49;
                    iVar4 = fcn.1802229c0(0x18077e4d0, in_RCX, (int64_t)&arg_38h + iVar5, *(undefined8 *)0x18077e4e0);
                    return iVar4 != 0;
                }
            }
        }
    } else if ((in_RCX >> 0x12 & 1) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024359b;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_18 + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802435b3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_18 + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_28h + iVar5), *(int64_t *)((int64_t)&arg_30h + iVar5), 
                      *(int64_t *)(&stack0x00000048 + iVar5));
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1802435c5;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar5));
    }
    return false;
}

// ============================================================
// Function: FUN_180243a60
// Address: 0x180243a60
// Size: 33 bytes
// ============================================================
void fcn.180243a60(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243a6a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180243a72;
    fcn.1802b4b30(*(int64_t *)(&stack0x00000038 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1), 
                  *(int64_t *)(&stack0x00000070 + iVar1), *(int64_t *)(&stack0x00000078 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1));
    *(undefined4 *)0x18077e520 = 1;
    return;
}

// ============================================================
// Function: FUN_180243a90
// Address: 0x180243a90
// Size: 33 bytes
// ============================================================
void fcn.180243a90(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243a9a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180243aa2;
    fcn.1802b5760(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined4 *)0x18077e528 = 1;
    return;
}

// ============================================================
// Function: FUN_180243ac0
// Address: 0x180243ac0
// Size: 58 bytes
// ============================================================
void fcn.180243ac0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243aca;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243ad2;
    *(int32_t *)0x18077e548 = fcn.1800066d0();
    if (*(int32_t *)0x18077e548 == 0) {
        return;
    }
    *(undefined4 *)0x18077e544 = 1;
    *(undefined4 *)0x18077e548 = 1;
    return;
}

// ============================================================
// Function: FUN_180243b00
// Address: 0x180243b00
// Size: 168 bytes
// ============================================================
void fcn.180243b00(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243b0a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b12;
    *(int64_t *)0x18077e4e0 = fcn.180222800();
    if (*(int64_t *)0x18077e4e0 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b23;
        *(int64_t *)0x18077e4e8 = fcn.180222800();
        if (*(int64_t *)0x18077e4e8 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b34;
            fcn.1800086f0();
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b39;
            iVar1 = fcn.18028c520();
            if (iVar1 != 0) {
                *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b4b;
                iVar1 = fcn.1802227a0(0x18077e4cc, 0);
                if (iVar1 != 0) {
                    *(undefined4 *)0x18077e4f4 = 1;
                    *(undefined4 *)0x18077e4f8 = 1;
                    return;
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b77;
    fcn.1802227d0(*(int64_t *)0x18077e4e0);
    *(undefined8 *)0x18077e4e0 = 0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180243b8e;
    fcn.1802227d0(*(int64_t *)0x18077e4e8);
    *(undefined8 *)0x18077e4e8 = 0;
    *(undefined4 *)0x18077e4f8 = 0;
    return;
}

// ============================================================
// Function: FUN_180243bb0
// Address: 0x180243bb0
// Size: 41 bytes
// ============================================================
void fcn.180243bb0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243bba;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180243bc4;
    *(undefined4 *)0x18077e534 =
         fcn.1802b5910(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
    *(undefined4 *)0x18077e530 = 1;
    return;
}

// ============================================================
// Function: FUN_180243be0
// Address: 0x180243be0
// Size: 46 bytes
// ============================================================
void fcn.180243be0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243bea;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180243bf9;
    *(undefined4 *)0x18077e534 =
         fcn.1802b5910(*(int64_t *)(&stack0x00000028 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
    *(undefined4 *)0x18077e530 = 1;
    return;
}

// ============================================================
// Function: FUN_180243c10
// Address: 0x180243c10
// Size: 33 bytes
// ============================================================
void fcn.180243c10(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243c1a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180243c22;
    fcn.1802ba830(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined4 *)0x18077e570 = 1;
    return;
}

// ============================================================
// Function: FUN_180243c40
// Address: 0x180243c40
// Size: 33 bytes
// ============================================================
void fcn.180243c40(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243c4a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243c52;
    fcn.1802b7090();
    *(undefined4 *)0x18077e560 = 1;
    return;
}

// ============================================================
// Function: FUN_180243c70
// Address: 0x180243c70
// Size: 33 bytes
// ============================================================
void fcn.180243c70(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243c7a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243c82;
    fcn.1802b5ec0();
    *(undefined4 *)0x18077e550 = 1;
    return;
}

// ============================================================
// Function: FUN_180243ca0
// Address: 0x180243ca0
// Size: 33 bytes
// ============================================================
void fcn.180243ca0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243caa;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243cb2;
    fcn.1800086f0();
    *(undefined4 *)0x18077e568 = 1;
    return;
}

// ============================================================
// Function: FUN_180243cd0
// Address: 0x180243cd0
// Size: 33 bytes
// ============================================================
void fcn.180243cd0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243cda;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243ce2;
    fcn.1800086f0();
    *(undefined4 *)0x18077e558 = 1;
    return;
}

// ============================================================
// Function: FUN_180243d10
// Address: 0x180243d10
// Size: 76 bytes
// ============================================================
void fcn.180243d10(int64_t arg_30h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243d1a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180243d27;
    iVar1 = fcn.180221170(*(int64_t *)((int64_t)&var_20h + iVar3));
    if (iVar1 == 0) {
        *(int32_t *)0x18077e510 = iVar1;
        return;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar3) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180243d40;
    uVar2 = fcn.1802bac60();
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x180243d4c;
    fcn.180221250(*(undefined8 *)((int64_t)&arg_30h + iVar3));
    *(undefined4 *)0x18077e510 = uVar2;
    return;
}

// ============================================================
// Function: FUN_180243d60
// Address: 0x180243d60
// Size: 33 bytes
// ============================================================
void fcn.180243d60(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243d6a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243d72;
    fcn.1802bae50();
    *(undefined4 *)0x18077e518 = 1;
    return;
}

// ============================================================
// Function: FUN_180243db0
// Address: 0x180243db0
// Size: 43 bytes
// ============================================================
void fcn.180243db0(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243dba;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243dc2;
    fcn.1802b5990();
    *(undefined4 *)0x18077e530 = 1;
    *(undefined4 *)0x18077e534 = 1;
    return;
}

// ============================================================
// Function: FUN_180243e10
// Address: 0x180243e10
// Size: 44 bytes
// ============================================================
void fcn.180243e10(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243e1a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x180243e29;
    iVar1 = fcn.180459be8(0x180243e40);
    *(uint32_t *)0x18077e500 = (uint32_t)(iVar1 != 0);
    return;
}

// ============================================================
// Function: FUN_180243e40
// Address: 0x180243e40
// Size: 39 bytes
// ============================================================
undefined8 fcn.180243e40(void)
{
    code *pcVar1;
    code **ppcVar2;
    code **ppcVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243e4a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((*(int32_t *)0x18077e4f4 != 0) && (*(int32_t *)0x18077e4c8 == 0)) {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RBX;
        *(int32_t *)0x18077e4c8 = 1;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243e7b;
        func_0x00018028be00();
        ppcVar3 = *(code ***)0x18077e4d8;
        while (ppcVar3 != (code **)0x0) {
            pcVar1 = *ppcVar3;
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243e89;
            (*pcVar1)();
            ppcVar2 = (code **)ppcVar3[1];
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ea2;
            fcn.180224990(ppcVar3, 0x1804e4168, 0x196);
            ppcVar3 = ppcVar2;
        }
        *(code ***)0x18077e4d8 = (code **)0x0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ebc;
        fcn.1802227d0(*(undefined8 *)0x18077e4e0);
        *(undefined8 *)0x18077e4e0 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ecf;
        fcn.1802227d0(*(undefined8 *)0x18077e4e8);
        *(undefined8 *)0x18077e4e8 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ee2;
        func_0x000180222710(0x18077e4cc);
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ee7;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243eec;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ef1;
        fcn.1800086f0();
        if (*(int32_t *)0x18077e544 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243efe;
            fcn.1800086f0();
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f03;
        func_0x00018021c1b0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f08;
        func_0x00018024b280();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f0d;
        func_0x00018029b500();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f12;
        func_0x0001802bae10();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f17;
        func_0x000180245aa0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f1c;
        func_0x00018028c2e0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f21;
        func_0x00018021b350();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f26;
        func_0x00018022e2a0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f2b;
        func_0x00018022dd50();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f30;
        func_0x000180220e20();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f35;
        func_0x000180225390();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f3a;
        func_0x0001802bae30();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f3f;
        fcn.1800086f0();
        *(int32_t *)0x18077e4f4 = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_180243e67
// Address: 0x180243e67
// Size: 227 bytes
// ============================================================
undefined8 fcn.180243e40(void)
{
    code *pcVar1;
    code **ppcVar2;
    code **ppcVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243e4a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((*(int32_t *)0x18077e4f4 != 0) && (*(int32_t *)0x18077e4c8 == 0)) {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RBX;
        *(int32_t *)0x18077e4c8 = 1;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243e7b;
        func_0x00018028be00();
        ppcVar3 = *(code ***)0x18077e4d8;
        while (ppcVar3 != (code **)0x0) {
            pcVar1 = *ppcVar3;
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243e89;
            (*pcVar1)();
            ppcVar2 = (code **)ppcVar3[1];
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ea2;
            fcn.180224990(ppcVar3, 0x1804e4168, 0x196);
            ppcVar3 = ppcVar2;
        }
        *(code ***)0x18077e4d8 = (code **)0x0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ebc;
        fcn.1802227d0(*(undefined8 *)0x18077e4e0);
        *(undefined8 *)0x18077e4e0 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ecf;
        fcn.1802227d0(*(undefined8 *)0x18077e4e8);
        *(undefined8 *)0x18077e4e8 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ee2;
        func_0x000180222710(0x18077e4cc);
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ee7;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243eec;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ef1;
        fcn.1800086f0();
        if (*(int32_t *)0x18077e544 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243efe;
            fcn.1800086f0();
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f03;
        func_0x00018021c1b0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f08;
        func_0x00018024b280();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f0d;
        func_0x00018029b500();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f12;
        func_0x0001802bae10();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f17;
        func_0x000180245aa0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f1c;
        func_0x00018028c2e0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f21;
        func_0x00018021b350();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f26;
        func_0x00018022e2a0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f2b;
        func_0x00018022dd50();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f30;
        func_0x000180220e20();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f35;
        func_0x000180225390();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f3a;
        func_0x0001802bae30();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f3f;
        fcn.1800086f0();
        *(int32_t *)0x18077e4f4 = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_180243f4a
// Address: 0x180243f4a
// Size: 7 bytes
// ============================================================
undefined8 fcn.180243e40(void)
{
    code *pcVar1;
    code **ppcVar2;
    code **ppcVar3;
    int64_t iVar4;
    undefined8 unaff_RBX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180243e4a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((*(int32_t *)0x18077e4f4 != 0) && (*(int32_t *)0x18077e4c8 == 0)) {
        *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_RBX;
        *(int32_t *)0x18077e4c8 = 1;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243e7b;
        func_0x00018028be00();
        ppcVar3 = *(code ***)0x18077e4d8;
        while (ppcVar3 != (code **)0x0) {
            pcVar1 = *ppcVar3;
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243e89;
            (*pcVar1)();
            ppcVar2 = (code **)ppcVar3[1];
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ea2;
            fcn.180224990(ppcVar3, 0x1804e4168, 0x196);
            ppcVar3 = ppcVar2;
        }
        *(code ***)0x18077e4d8 = (code **)0x0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ebc;
        fcn.1802227d0(*(undefined8 *)0x18077e4e0);
        *(undefined8 *)0x18077e4e0 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ecf;
        fcn.1802227d0(*(undefined8 *)0x18077e4e8);
        *(undefined8 *)0x18077e4e8 = 0;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ee2;
        func_0x000180222710(0x18077e4cc);
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ee7;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243eec;
        fcn.1800086f0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243ef1;
        fcn.1800086f0();
        if (*(int32_t *)0x18077e544 != 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243efe;
            fcn.1800086f0();
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f03;
        func_0x00018021c1b0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f08;
        func_0x00018024b280();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f0d;
        func_0x00018029b500();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f12;
        func_0x0001802bae10();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f17;
        func_0x000180245aa0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f1c;
        func_0x00018028c2e0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f21;
        func_0x00018021b350();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f26;
        func_0x00018022e2a0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f2b;
        func_0x00018022dd50();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f30;
        func_0x000180220e20();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f35;
        func_0x000180225390();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f3a;
        func_0x0001802bae30();
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180243f3f;
        fcn.1800086f0();
        *(int32_t *)0x18077e4f4 = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_180243f60
// Address: 0x180243f60
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180243f60(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180243f70;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180243f7e;
    uVar2 = fcn.180244860(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if ((int32_t)uVar2 == 0) {
        return uVar2;
    }
    *(int64_t *)(in_RCX + 0x18) = *(int64_t *)(in_RCX + 0x18) + in_RDX;
    *(int64_t *)(in_RCX + 0x10) = *(int64_t *)(in_RCX + 0x10) + in_RDX;
    return 1;
}

// ============================================================
// Function: FUN_180243fb0
// Address: 0x180243fb0
// Size: 27 bytes
// ============================================================
void fcn.180243fb0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t *piVar3;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x180243fbc;
    iVar2 = fcn.18045a350();
    piVar3 = *(int64_t **)(in_RCX + 0x28);
    if (piVar3 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RBX;
        do {
            piVar1 = (int64_t *)*piVar3;
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180243fe5;
            fcn.180224990(piVar3, 0x1804e4190, 0x214);
            piVar3 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
    }
    *(undefined8 *)(in_RCX + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_180243fcb
// Address: 0x180243fcb
// Size: 39 bytes
// ============================================================
void fcn.180243fb0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t *piVar3;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x180243fbc;
    iVar2 = fcn.18045a350();
    piVar3 = *(int64_t **)(in_RCX + 0x28);
    if (piVar3 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RBX;
        do {
            piVar1 = (int64_t *)*piVar3;
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180243fe5;
            fcn.180224990(piVar3, 0x1804e4190, 0x214);
            piVar3 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
    }
    *(undefined8 *)(in_RCX + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_180243ff2
// Address: 0x180243ff2
// Size: 14 bytes
// ============================================================
void fcn.180243fb0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t *piVar3;
    undefined8 unaff_RBX;
    undefined8 uStack_10;
    
    uStack_10 = 0x180243fbc;
    iVar2 = fcn.18045a350();
    piVar3 = *(int64_t **)(in_RCX + 0x28);
    if (piVar3 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&arg_28h + -iVar2) = unaff_RBX;
        do {
            piVar1 = (int64_t *)*piVar3;
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180243fe5;
            fcn.180224990(piVar3, 0x1804e4190, 0x214);
            piVar3 = piVar1;
        } while (piVar1 != (int64_t *)0x0);
    }
    *(undefined8 *)(in_RCX + 0x28) = 0;
    return;
}

// ============================================================
// Function: FUN_180244000
// Address: 0x180244000
// Size: 50 bytes
// ============================================================
undefined8
fcn.180244000(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    uint64_t uVar5;
    int64_t *in_RCX;
    int64_t iVar6;
    int64_t *piVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar9;
    uint64_t uVar10;
    undefined8 unaff_R14;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    piVar7 = (int64_t *)in_RCX[5];
    if ((piVar7 == (int64_t *)0x0) || (*piVar7 == 0)) {
        return 0;
    }
    iVar9 = 1;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar2) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180244d20;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar8 = in_RCX[3] - piVar7[3];
    if (uVar8 == 0) {
        if ((*(uint32_t *)(piVar7 + 4) & 1) != 0) {
            return 0;
        }
        if ((*(uint32_t *)(piVar7 + 4) & 2) != 0) {
            if (iVar9 == 0) {
                return 0;
            }
            if (in_RCX[2] - piVar7[2] == piVar7[1]) {
                in_RCX[3] = in_RCX[3] - piVar7[2];
                in_RCX[2] = in_RCX[2] - piVar7[2];
            }
            piVar7[1] = 0;
            piVar7[2] = 0;
        }
    }
    uVar10 = piVar7[2];
    if (uVar10 == 0) {
        if ((((*(uint8_t *)(in_RCX + 6) & 1) != 0) && (*piVar7 != 0)) &&
           ((uVar8 != 0 || ((*(uint8_t *)(piVar7 + 4) & 2) == 0)))) {
            uVar10 = 1;
            uVar5 = uVar8;
            while (uVar5 = uVar5 >> 8, uVar5 != 0) {
                uVar10 = uVar10 + 1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180244eca;
            iVar1 = func_0x0001802446f0(in_RCX, uVar8, uVar10);
            if (iVar1 == 0) {
                return 0;
            }
            if (0x7f < uVar8) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180244eee;
                iVar1 = func_0x0001802446f0(in_RCX, uVar10 | 0x80, 1);
                if (iVar1 == 0) {
                    return 0;
                }
            }
        }
        goto code_r0x000180244dd9;
    }
    iVar6 = in_RCX[1];
    if ((iVar6 == 0) && ((*in_RCX == 0 || (iVar6 = *(int64_t *)(*in_RCX + 8), iVar6 == 0)))) goto code_r0x000180244dd9;
    iVar6 = iVar6 + piVar7[1];
    if ((*(uint8_t *)(piVar7 + 4) & 4) == 0) {
        if (iVar6 != 0) {
            puVar4 = (undefined *)((uVar10 - 1) + iVar6);
            do {
                *puVar4 = (char)uVar8;
                puVar4 = puVar4 + -1;
                uVar8 = uVar8 >> 8;
                uVar10 = uVar10 - 1;
            } while (uVar10 != 0);
            if (uVar8 != 0) {
                return 0;
            }
        }
        goto code_r0x000180244dd9;
    }
    if (iVar6 == 0) goto code_r0x000180244dd9;
    if (uVar8 < 0x40) {
        uVar5 = 1;
code_r0x000180244e5f:
        if (uVar10 < uVar5) {
            return 0;
        }
    } else {
        if (uVar8 < 0x4000) {
            uVar5 = 2;
            goto code_r0x000180244e5f;
        }
        if (uVar8 < 0x40000000) {
            uVar5 = 4;
            goto code_r0x000180244e5f;
        }
        if (uVar8 < 0x4000000000000000) {
            uVar5 = 8;
            goto code_r0x000180244e5f;
        }
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180244e70;
    func_0x000180274fd0(iVar6, uVar8);
code_r0x000180244dd9:
    if (iVar9 != 0) {
        in_RCX[5] = *piVar7;
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180244df9;
        fcn.180224990(piVar7, 0x1804e4190, 0x139);
    }
    return 1;
}

