// Chunk 199 - 50 functions

// ============================================================
// Function: FUN_180268f60
// Address: 0x180268f60
// Size: 27 bytes
// ============================================================
int64_t * fcn.180268f60(int64_t arg_38h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t iVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t *in_RCX;
    uint64_t uVar8;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar8 = 0x87;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1802a4b60;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (int64_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4b72;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4b8a;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_58h + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000070 + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4b9c;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar5 + iVar4));
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4bbf;
    piVar6 = (int64_t *)
             fcn.1802dd7b0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                           *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                           *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4));
    if (piVar6 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    if ((in_RCX[3] != 0) && ((uVar8 & 4) != 0)) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4bea;
        iVar7 = fcn.180268ae0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4));
        piVar6[3] = iVar7;
        if (iVar7 == 0) goto code_r0x0001802a4d21;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4c03;
        iVar3 = fcn.180266590(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4));
        if (iVar3 == 0) goto code_r0x0001802a4d21;
        if (*in_RCX != 0) {
            *piVar6 = *in_RCX;
        }
    }
    if ((in_RCX[4] != 0) && ((uVar8 & 2) != 0)) {
        if (piVar6[3] == 0) goto code_r0x0001802a4d21;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4c35;
        iVar7 = fcn.1802685b0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4));
        piVar6[4] = iVar7;
        if (iVar7 == 0) goto code_r0x0001802a4d21;
        iVar1 = in_RCX[4];
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4c4e;
        iVar3 = fcn.180267e30(iVar7, iVar1);
        if (iVar3 == 0) goto code_r0x0001802a4d21;
    }
    if ((in_RCX[5] != 0) && ((uVar8 & 1) != 0)) {
        if (piVar6[3] == 0) goto code_r0x0001802a4d21;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4c73;
        iVar7 = fcn.1802554c0();
        piVar6[5] = iVar7;
        if (iVar7 == 0) goto code_r0x0001802a4d21;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4c8c;
        iVar7 = fcn.180255110(*(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_50h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000078 + iVar5 + iVar4));
        if (iVar7 == 0) goto code_r0x0001802a4d21;
        pcVar2 = *(code **)(*(int64_t *)piVar6[3] + 0x160);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4cb0;
            iVar3 = (*pcVar2)(piVar6, in_RCX);
            if (iVar3 == 0) goto code_r0x0001802a4d21;
        }
    }
    if ((char)(uint8_t)uVar8 < '\0') {
        *(undefined4 *)(piVar6 + 6) = *(undefined4 *)(in_RCX + 6);
        *(undefined4 *)((int64_t)piVar6 + 0x34) = *(undefined4 *)((int64_t)in_RCX + 0x34);
    }
    *(undefined4 *)(piVar6 + 2) = *(undefined4 *)(in_RCX + 2);
    *(undefined4 *)((int64_t)piVar6 + 0x3c) = *(undefined4 *)((int64_t)in_RCX + 0x3c);
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4ce3;
    iVar3 = fcn.180223d20(*(int64_t *)(&stack0x00000080 + iVar5 + iVar4), *(int64_t *)(&stack0x000000e8 + iVar5 + iVar4)
                         );
    if (iVar3 != 0) {
        if ((*piVar6 == 0) || (pcVar2 = *(code **)(*piVar6 + 0x20), pcVar2 == (code *)0x0)) {
            return piVar6;
        }
        if (((uint8_t)uVar8 & 3) == 3) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4d0a;
            iVar3 = (*pcVar2)(piVar6, in_RCX);
            if (iVar3 != 0) {
                return piVar6;
            }
        }
    }
code_r0x0001802a4d21:
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4) = 0x1802a4d29;
    fcn.180268f80(piVar6);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180268f80
// Address: 0x180268f80
// Size: 200 bytes
// ============================================================
void fcn.180268f80(int64_t arg1)
{
    int64_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180268f94;
        iVar5 = fcn.18045a350();
        iVar5 = -iVar5;
        LOCK();
        piVar1 = (int64_t *)(arg1 + 0x38);
        iVar2 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            if ((*(int64_t *)arg1 != 0) && (pcVar3 = *(code **)(*(int64_t *)arg1 + 0x18), pcVar3 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180268fc0;
                (*pcVar3)();
            }
            iVar4 = *(int64_t *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180268fc9;
            func_0x00018026aee0(iVar4);
            if ((*(int64_t **)(arg1 + 0x18) != (int64_t *)0x0) &&
               (pcVar3 = *(code **)(**(int64_t **)(arg1 + 0x18) + 0x168), pcVar3 != (code *)0x0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180268fe6;
                (*pcVar3)(arg1);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180268ff7;
            func_0x000180223fb0(8, arg1, (int64_t *)(arg1 + 0x40));
            iVar4 = *(int64_t *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269000;
            func_0x0001802668c0(iVar4);
            iVar4 = *(int64_t *)(arg1 + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269009;
            func_0x000180268030(iVar4);
            iVar4 = *(int64_t *)(arg1 + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269012;
            fcn.180254e90(iVar4);
            iVar4 = *(int64_t *)(arg1 + 0x58);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269028;
            fcn.180224990(iVar4, 0x1804e7210, 0x65);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269042;
            fcn.180224b90(*(int64_t *)((int64_t)aiStackX_18 + iVar5), *(int64_t *)((int64_t)aiStackX_18 + iVar5 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180269050
// Address: 0x180269050
// Size: 150 bytes
// ============================================================
undefined8 fcn.180269050(int64_t *param_1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026905c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((param_1 == (int64_t *)0x0) || (param_1[3] == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802690b4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802690cc;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
    } else {
        pcVar1 = *(code **)(*param_1 + 0x40);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026907c;
            uVar3 = (*pcVar1)();
            if ((int32_t)uVar3 != 1) {
                return uVar3;
            }
            param_1[0xc] = param_1[0xc] + 1;
            return uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180269090;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802690a8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802690de;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
    return 0;
}

// ============================================================
// Function: FUN_180269100
// Address: 0x180269100
// Size: 66 bytes
// ============================================================
undefined8 fcn.180269100(int64_t param_1, undefined8 param_2, undefined8 param_3, undefined8 param_4)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026910a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (((param_1 != 0) && (*(int64_t *)(param_1 + 0x20) != 0)) && (*(int64_t *)(param_1 + 0x18) != 0)) {
        *(undefined8 *)((int64_t)&var_20h + iVar1) = param_4;
        *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180269136;
        uVar2 = fcn.1802d5fc0(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                              *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000050 + iVar1));
        return uVar2;
    }
    return 0;
}

// ============================================================
// Function: FUN_180269150
// Address: 0x180269150
// Size: 29 bytes
// ============================================================
int64_t * fcn.180269150(void)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *arg1;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 0;
    iVar7 = 0;
    iVar5 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802dd7ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd7ed;
    arg1 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
    if (arg1 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    *(undefined4 *)(arg1 + 7) = 1;
    arg1[10] = iVar5;
    if (iVar7 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd81e;
        iVar5 = fcn.1802231e0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        arg1[0xb] = iVar5;
        if (iVar5 == 0) goto code_r0x0001802dd92b;
    }
    *arg1 = *(int64_t *)0x1806a0d20;
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd878;
        iVar6 = func_0x000180315860();
        arg1[1] = iVar6;
        if (iVar6 != 0) goto code_r0x0001802dd884;
code_r0x0001802dd8a0:
        *(undefined4 *)(arg1 + 2) = 1;
        *(undefined4 *)((int64_t)arg1 + 0x34) = 4;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8bf;
        iVar2 = func_0x000180224430(8, arg1, arg1 + 8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8c8;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8e0;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3)
                         );
        } else {
            pcVar1 = *(code **)(*arg1 + 0x10);
            if (pcVar1 == (code *)0x0) {
                return arg1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8f8;
            iVar2 = (*pcVar1)(arg1);
            if (iVar2 != 0) {
                return arg1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd901;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd919;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3)
                         );
        }
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd842;
        iVar2 = func_0x00018026b010(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd84b;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
        } else {
            arg1[1] = iVar6;
code_r0x0001802dd884:
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + 0x20 + -0x20) = 0x1802dd88c;
            iVar6 = func_0x000180192480(iVar6);
            *arg1 = iVar6;
            if (iVar6 != 0) goto code_r0x0001802dd8a0;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + 0x20 + -0x20) = 0x1802dd899;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd863;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd92b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
code_r0x0001802dd92b:
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd933;
    fcn.180268f80((int64_t)arg1);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180269170
// Address: 0x180269170
// Size: 138 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t * fcn.180269170(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *arg1;
    int64_t iVar4;
    undefined8 in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026918a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026919e;
    arg1 = (int64_t *)
           fcn.1802dd7b0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                         *(int64_t *)((int64_t)&arg_28h + iVar3));
    if (arg1 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802691b4;
        iVar4 = func_0x0001802d56c0(in_RCX, in_RDX, in_R8 & 0xffffffff);
        arg1[3] = iVar4;
        if (iVar4 != 0) {
            pcVar1 = *(code **)(*arg1 + 0x28);
            if (pcVar1 == (code *)0x0) {
                return arg1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802691d2;
            iVar2 = (*pcVar1)(arg1, iVar4);
            if (iVar2 != 0) {
                return arg1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802691e3;
        fcn.180268f80((int64_t)arg1);
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180269200
// Address: 0x180269200
// Size: 25 bytes
// ============================================================
int64_t * fcn.180269200(int64_t param_1, int64_t param_2)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *arg1;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    iVar6 = 0;
    *(undefined8 *)(&stack0x00000030 + iVar3) = unaff_RBX;
    *(undefined8 *)(&stack0x00000038 + iVar3) = unaff_RBP;
    *(undefined8 *)(&stack0x00000040 + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x1802dd7ca;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd7ed;
    arg1 = (int64_t *)fcn.180224d60(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3));
    if (arg1 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    *(undefined4 *)(arg1 + 7) = 1;
    arg1[10] = param_1;
    if (param_2 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd81e;
        iVar5 = fcn.1802231e0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar4 + iVar3));
        arg1[0xb] = iVar5;
        if (iVar5 == 0) goto code_r0x0001802dd92b;
    }
    *arg1 = *(int64_t *)0x1806a0d20;
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd878;
        iVar6 = func_0x000180315860();
        arg1[1] = iVar6;
        if (iVar6 != 0) goto code_r0x0001802dd884;
code_r0x0001802dd8a0:
        *(undefined4 *)(arg1 + 2) = 1;
        *(undefined4 *)((int64_t)arg1 + 0x34) = 4;
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8bf;
        iVar2 = func_0x000180224430(8, arg1, arg1 + 8);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8c8;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8e0;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3)
                         );
        } else {
            pcVar1 = *(code **)(*arg1 + 0x10);
            if (pcVar1 == (code *)0x0) {
                return arg1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd8f8;
            iVar2 = (*pcVar1)(arg1);
            if (iVar2 != 0) {
                return arg1;
            }
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd901;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd919;
            fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                          , *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), 
                          *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), *(int64_t *)(&stack0x00000070 + iVar4 + iVar3)
                         );
        }
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd842;
        iVar2 = func_0x00018026b010(iVar6);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd84b;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
        } else {
            arg1[1] = iVar6;
code_r0x0001802dd884:
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + 0x20 + -0x20) = 0x1802dd88c;
            iVar6 = func_0x000180192480(iVar6);
            *arg1 = iVar6;
            if (iVar6 != 0) goto code_r0x0001802dd8a0;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3 + 0x20 + -0x20) = 0x1802dd899;
            fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3)
                         );
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd863;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar4 + iVar3), *(int64_t *)(&stack0x00000048 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000050 + iVar4 + iVar3), *(int64_t *)(&stack0x00000058 + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd92b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar4 + iVar3));
code_r0x0001802dd92b:
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x1802dd933;
    fcn.180268f80((int64_t)arg1);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_180269220
// Address: 0x180269220
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.180269220(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    uint8_t *in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026923a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RCX != 0) && (*(int64_t *)(in_RCX + 0x18) != 0)) {
        iVar4 = *(int64_t *)(in_RCX + 0x20);
        if (iVar4 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269265;
            iVar4 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(int64_t *)(in_RCX + 0x20) = iVar4;
            if (iVar4 == 0) {
                return 0;
            }
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&var_18h + iVar3) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269285;
        iVar2 = func_0x0001802d5ee0(uVar1, iVar4, in_RDX, in_R8);
        if (iVar2 != 0) {
            *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + 1;
            if ((***(uint8_t ***)(in_RCX + 0x18) & 2) == 0) {
                *(uint32_t *)(in_RCX + 0x34) = *in_RDX & 0xfffffffe;
            }
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1802692c0
// Address: 0x1802692c0
// Size: 120 bytes
// ============================================================
undefined8 fcn.1802692c0(int64_t param_1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802692cc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*(int64_t **)(param_1 + 0x18) != (int64_t *)0x0) && (iVar1 = **(int64_t **)(param_1 + 0x18), iVar1 != 0)) {
        pcVar2 = *(code **)(iVar1 + 0x138);
        if (pcVar2 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269329;
            uVar4 = (*pcVar2)();
            if ((int32_t)uVar4 != 1) {
                return uVar4;
            }
            *(int64_t *)(param_1 + 0x60) = *(int64_t *)(param_1 + 0x60) + 1;
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802692f4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026930c;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026931e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_180269340
// Address: 0x180269340
// Size: 228 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180269340(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026935b;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int64_t **)(in_RCX + 0x18) != (int64_t *)0x0) && (iVar3 = **(int64_t **)(in_RCX + 0x18), iVar3 != 0)) {
        pcVar1 = *(code **)(iVar3 + 0x130);
        if (pcVar1 == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180269386;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026939e;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar2), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                          *(int64_t *)(&stack0x00000048 + iVar2));
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802693b0;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802693d0;
            iVar3 = (*pcVar1)();
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802693ed;
                iVar4 = fcn.1802248d0(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar2));
                if (iVar4 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180269403;
                    iVar3 = fcn.180269430(in_RCX, iVar4, iVar3);
                    if (iVar3 != 0) {
                        *in_RDX = iVar4;
                        return iVar3;
                    }
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026941d;
                    fcn.180224990(iVar4, 0x1804e7210, 0x437);
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180269430
// Address: 0x180269430
// Size: 103 bytes
// ============================================================
undefined8 fcn.180269430(int64_t param_1)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026943a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((*(int64_t **)(param_1 + 0x18) != (int64_t *)0x0) && (iVar1 = **(int64_t **)(param_1 + 0x18), iVar1 != 0)) {
        UNRECOVERED_JUMPTABLE = *(code **)(iVar1 + 0x130);
        if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180269494. Too many branches
    // WARNING: Treating indirect jump as call
            uVar3 = (*UNRECOVERED_JUMPTABLE)();
            return uVar3;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026945f;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180269477;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180269489;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_1802694a0
// Address: 0x1802694a0
// Size: 39 bytes
// ============================================================
void fcn.1802694a0(int64_t param_1, undefined4 param_2)
{
    fcn.18045a350();
    *(undefined4 *)(param_1 + 0x34) = param_2;
    if (*(int64_t *)(param_1 + 0x18) != 0) {
        *(undefined4 *)(*(int64_t *)(param_1 + 0x18) + 0x2c) = param_2;
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1802694f0
// Address: 0x1802694f0
// Size: 128 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.1802694f0(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180269500;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(*in_RCX + 0x28);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269518;
        uVar4 = (*pcVar1)();
        if ((int32_t)uVar4 == 0) {
            return uVar4;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269530;
    fcn.1802668c0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269538;
    iVar5 = fcn.180266850(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    in_RCX[3] = iVar5;
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269549;
        iVar2 = fcn.180266ad0(iVar5);
        if (iVar2 == 0x494) {
            *(uint32_t *)((int64_t)in_RCX + 0x3c) = *(uint32_t *)((int64_t)in_RCX + 0x3c) | 4;
            in_RCX[0xc] = in_RCX[0xc] + 1;
        }
    }
    in_RCX[0xc] = in_RCX[0xc] + 1;
    return (uint64_t)(in_RCX[3] != 0);
}

// ============================================================
// Function: FUN_180269570
// Address: 0x180269570
// Size: 279 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180269570(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269585;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((int64_t *)in_RCX[3] != (int64_t *)0x0) && (*(int64_t *)in_RCX[3] != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802695a2;
        iVar4 = func_0x0001801dd6c0();
        if (iVar4 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802695b2;
            iVar2 = func_0x0001802553f0(iVar4);
            if (iVar2 == 0) {
                pcVar1 = *(code **)(*(int64_t *)in_RCX[3] + 0x140);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802695d1;
                    iVar2 = (*pcVar1)(in_RCX, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                }
                pcVar1 = *(code **)(*in_RCX + 0x30);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802695ea;
                    iVar2 = (*pcVar1)(in_RCX, in_RDX);
                    if (iVar2 == 0) {
                        return 0;
                    }
                }
                if (in_RDX == 0) {
                    iVar4 = in_RCX[5];
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802695fc;
                    fcn.180254e90(iVar4);
                    in_RCX[5] = 0;
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026961a;
                    iVar5 = func_0x0001802551a0(in_RDX);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026962f;
                        func_0x000180255830(iVar5, 4);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269637;
                        iVar2 = func_0x00018020efa0(iVar4);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269642;
                        iVar4 = func_0x000180256300(iVar5, iVar2 + 2);
                        if (iVar4 != 0) {
                            iVar4 = in_RCX[5];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026966a;
                            fcn.180254e90(iVar4);
                            in_RCX[0xc] = in_RCX[0xc] + 1;
                            in_RCX[5] = iVar5;
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026964f;
                        fcn.180254e90(iVar5);
                        return 0;
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180269690
// Address: 0x180269690
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180269690(int64_t arg_28h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t *in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802696a0;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(*in_RCX + 0x38);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802696b8;
        uVar4 = (*pcVar1)();
        if ((int32_t)uVar4 == 0) {
            return uVar4;
        }
    }
    iVar2 = in_RCX[4];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802696d0;
    fcn.180268030(iVar2);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802696dc;
    iVar3 = fcn.180267fb0(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
    in_RCX[0xc] = in_RCX[0xc] + 1;
    in_RCX[4] = iVar3;
    return (uint64_t)(iVar3 != 0);
}

// ============================================================
// Function: FUN_180269720
// Address: 0x180269720
// Size: 971 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_238h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_248h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180269720(int64_t arg_28h, int64_t arg_38h)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    undefined4 in_EDX;
    uint32_t uVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180269742;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000238 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3);
    uVar13 = *(undefined8 *)(in_RCX + 0x18);
    uVar8 = *(undefined8 *)(in_RCX + 0x50);
    iVar5 = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar3) = uVar13;
    iVar7 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar3) = in_EDX;
    iVar9 = 0;
    iVar12 = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269777;
    iVar4 = func_0x0001802d4850(uVar8);
    uVar11 = *(uint32_t *)(in_RCX + 0x3c);
    if (iVar4 != 0) {
        iVar5 = *(int64_t *)(in_RCX + 0x28);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269799;
            iVar5 = func_0x0001802556d0();
            if (iVar5 == 0) goto code_r0x000180269a70;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802697ad;
        iVar6 = func_0x0001801dd6c0(uVar13);
        if (iVar6 != 0) {
            iVar9 = iVar12;
            if ((uVar11 & 4) == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802697f3;
                iVar7 = func_0x0001802551a0(iVar6);
                if (iVar7 != 0) {
code_r0x000180269800:
                    do {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269811;
                        iVar1 = func_0x0001802dc870(iVar5, iVar7, 0, iVar4);
                        if (iVar1 == 0) goto code_r0x000180269a70;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269821;
                        iVar1 = func_0x0001802553f0(iVar5);
                    } while (iVar1 != 0);
                    iVar9 = *(int64_t *)(in_RCX + 0x20);
                    if (iVar9 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269836;
                        iVar9 = fcn.1802685b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
                        if (iVar9 == 0) goto code_r0x000180269a70;
                    }
                    *(int64_t *)(&stack0x00000000 + iVar3) = iVar4;
                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269861;
                    iVar1 = func_0x000180268410(uVar13, iVar9, iVar5, 0);
                    if (iVar1 != 0) {
                        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + 1;
                        *(int64_t *)(in_RCX + 0x28) = iVar5;
                        iVar5 = 0;
                        *(int64_t *)(in_RCX + 0x20) = iVar9;
                        iVar9 = 0;
                        iVar12 = 0;
                        iVar6 = 0;
                        if (*(int32_t *)((int64_t)&var_8h + iVar3) == 0) goto code_r0x000180269a98;
                        uVar8 = *(undefined8 *)(in_RCX + 0x50);
                        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
                        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802698a8;
                        func_0x0001802c17b0(uVar8, (int64_t)&var_18h + iVar3, (int64_t)&var_10h + iVar3);
                        *(undefined (*) [16])((int64_t)&arg_28h + iVar3) = ZEXT816(0);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802698bf;
                        iVar12 = func_0x0001802c1810(*(undefined8 *)((int64_t)&var_18h + iVar3), 
                                                     *(undefined8 *)((int64_t)&var_10h + iVar3));
                        if (iVar12 == 0) goto code_r0x000180269a70;
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802698e1;
                        func_0x0001802c18a0(iVar12, 0x1804e7250, 0x1804ad21c);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802698f3;
                        iVar6 = func_0x0001802dd3f0((int64_t)&arg_28h + iVar3, 0x10, in_RCX);
                        if (iVar6 == 0) {
code_r0x000180269a51:
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a5b;
                            func_0x0001802c1960(iVar12, 0);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a63;
                            func_0x0001802c1780(iVar12);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a6b;
                            func_0x0001802b0330(iVar6);
                        } else {
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18026990c;
                            func_0x0001802c18f0(iVar12, (int64_t)&arg_28h + iVar3);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269921;
                            iVar1 = func_0x0001802dd5a0((int64_t)&arg_28h + iVar3, 0x10, iVar6, in_RCX);
                            if (iVar1 != 1) goto code_r0x000180269a51;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269933;
                            func_0x0001802c1960(iVar12, 1);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18026993b;
                            func_0x0001802c1780(iVar12);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269943;
                            func_0x0001802b0330(iVar6);
                            *(undefined4 *)((int64_t)&var_8h + iVar3) = 0;
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269959;
                            fcn.1804986e0((int64_t)&arg_38h + iVar3, 0, 0x200);
                            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269968;
                            iVar12 = func_0x0001802c1810(*(undefined8 *)((int64_t)&var_18h + iVar3), 
                                                         *(undefined8 *)((int64_t)&var_10h + iVar3));
                            if (iVar12 != 0) {
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18026998a;
                                func_0x0001802c18a0(iVar12, 0x1804e7240, 0x1804ad21c);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269993;
                                iVar6 = fcn.1802685b0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar3));
                                if (iVar6 == 0) {
code_r0x000180269a2d:
                                    uVar11 = *(uint32_t *)((int64_t)&var_8h + iVar3);
                                } else {
                                    uVar13 = *(undefined8 *)(in_RCX + 0x28);
                                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                                    *(int64_t *)(&stack0x00000000 + iVar3) = iVar4;
                                    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802699bc;
                                    iVar1 = func_0x000180268410(uVar8, iVar6, uVar13, 0);
                                    if (iVar1 == 0) goto code_r0x000180269a2d;
                                    uVar13 = *(undefined8 *)(iVar6 + 0x10);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802699c9;
                                    iVar1 = func_0x000180255500(uVar13);
                                    if (0x1007 < iVar1 + 7) goto code_r0x000180269a2d;
                                    uVar13 = *(undefined8 *)(iVar6 + 0x10);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802699e1;
                                    uVar2 = func_0x000180254c60(uVar13, (int64_t)&arg_38h + iVar3);
                                    *(undefined4 *)((int64_t)&var_8h + iVar3 + 4) = uVar2;
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802699f2;
                                    iVar1 = func_0x0001802c18f0(iVar12, (int64_t)&arg_38h + iVar3);
                                    if (iVar1 != 0) {
                                        uVar13 = *(undefined8 *)(iVar6 + 0x10);
                                        uVar2 = *(undefined4 *)((int64_t)&var_8h + iVar3 + 4);
                                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a08;
                                        iVar10 = func_0x000180254c30((int64_t)&arg_38h + iVar3, uVar2, uVar13);
                                        if (iVar10 == 0) goto code_r0x000180269a2d;
                                    }
                                    uVar13 = *(undefined8 *)(in_RCX + 0x20);
                                    uVar8 = *(undefined8 *)(in_RCX + 0x18);
                                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a20;
                                    iVar1 = func_0x000180267d70(uVar8, uVar13, iVar6, iVar4);
                                    uVar11 = (uint32_t)(iVar1 == 0);
                                    *(uint32_t *)((int64_t)&var_8h + iVar3) = (uint32_t)(iVar1 == 0);
                                }
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a39;
                                func_0x0001802c1960(iVar12, uVar11);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a41;
                                func_0x0001802c1780(iVar12);
                                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a49;
                                fcn.180268030(iVar6);
                                iVar12 = iVar5;
                                iVar6 = iVar9;
                                if (*(int32_t *)((int64_t)&var_8h + iVar3) != 0) goto code_r0x000180269a98;
                            }
                        }
                        uVar13 = *(undefined8 *)((int64_t)&var_20h + iVar3);
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802697c3;
                iVar7 = fcn.1802554c0();
                if (iVar7 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802697d4;
                    uVar8 = func_0x000180255ab0();
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802697e2;
                    iVar1 = func_0x0001802d4a70(iVar7, iVar6, uVar8);
                    if (iVar1 != 0) goto code_r0x000180269800;
                }
            }
        }
    }
code_r0x000180269a70:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a7c;
    func_0x0001800086f0(0x1804e7250);
    uVar8 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a85;
    func_0x000180254de0(uVar8);
    iVar12 = iVar5;
    iVar6 = iVar9;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269a98;
        func_0x000180268920(uVar13);
    }
code_r0x000180269a98:
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269aa0;
    fcn.180268030(iVar6);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269aa8;
    fcn.180254e90(iVar12);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269ab0;
    func_0x0001802d44d0(iVar4);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269ab8;
    fcn.180255290(iVar7);
    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180269aca;
    func_0x000180459870(*(uint64_t *)(&stack0x00000238 + iVar3) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_180269af0
// Address: 0x180269af0
// Size: 276 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180269af0(int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269b05;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar6 = *(int64_t *)(in_RCX + 0x28);
    if (iVar6 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269b1f;
        iVar6 = func_0x0001802556d0();
        *(int64_t *)(in_RCX + 0x28) = iVar6;
        if (iVar6 == 0) goto code_r0x000180269bcf;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269b3d;
    iVar4 = func_0x0001802dead0(in_RCX, iVar6, in_RDX, in_R8);
    if (0 < iVar4) {
        if (*(int64_t *)(in_RCX + 0x20) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269b55;
            iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar5));
            *(int64_t *)(in_RCX + 0x20) = iVar6;
            if (iVar6 == 0) goto code_r0x000180269bcf;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269b67;
        iVar6 = func_0x0001802d4790(uVar1);
        if (iVar6 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar2 = *(undefined8 *)(in_RCX + 0x20);
            uVar3 = *(undefined8 *)(in_RCX + 0x18);
            *(int64_t *)((int64_t)&var_20h + iVar5) = iVar6;
            *(undefined8 *)((int64_t)&var_18h + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269b91;
            iVar4 = func_0x000180268410(uVar3, uVar2, uVar1, 0);
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269b9b;
            func_0x0001802d44d0(iVar6);
            if (iVar4 == 1) {
                *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + 1;
                return 1;
            }
            if (iVar4 != 0) {
                return 1;
            }
        }
    }
code_r0x000180269bcf:
    uVar1 = *(undefined8 *)(in_RCX + 0x28);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269bd8;
    fcn.180254e90(uVar1);
    *(undefined8 *)(in_RCX + 0x28) = 0;
    if (*(int64_t *)(in_RCX + 0x20) != 0) {
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x180269bf2;
        func_0x000180268920(uVar1);
    }
    return 0;
}

// ============================================================
// Function: FUN_180269c10
// Address: 0x180269c10
// Size: 49 bytes
// ============================================================
void fcn.180269c10(int64_t param_1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269c1c;
    iVar3 = fcn.18045a350();
    pcVar1 = *(code **)(**(int64_t **)(param_1 + 0x18) + 0x148);
    *(undefined8 *)((int64_t)&uStack_10 - iVar3) = 0x180269c32;
    iVar2 = (*pcVar1)();
    if (iVar2 == 1) {
        *(int64_t *)(param_1 + 0x60) = *(int64_t *)(param_1 + 0x60) + 1;
    }
    return;
}

// ============================================================
// Function: FUN_180269c50
// Address: 0x180269c50
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180269c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180269c65;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    if ((((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
       (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dc5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dd7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ca4;
    iVar4 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ccd;
        iVar2 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cd6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cee;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d00;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d08;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0x20);
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d32;
        iVar2 = fcn.180267d70(uVar1, iVar4, uVar5, in_RDX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d3b;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d53;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d65;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d6d;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d91;
    fcn.180268030(iVar4);
    return uVar5;
}

// ============================================================
// Function: FUN_180269c9a
// Address: 0x180269c9a
// Size: 133 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180269c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180269c65;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    if ((((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
       (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dc5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dd7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ca4;
    iVar4 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ccd;
        iVar2 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cd6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cee;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d00;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d08;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0x20);
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d32;
        iVar2 = fcn.180267d70(uVar1, iVar4, uVar5, in_RDX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d3b;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d53;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d65;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d6d;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d91;
    fcn.180268030(iVar4);
    return uVar5;
}

// ============================================================
// Function: FUN_180269d1f
// Address: 0x180269d1f
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180269c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180269c65;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    if ((((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
       (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dc5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dd7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ca4;
    iVar4 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ccd;
        iVar2 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cd6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cee;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d00;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d08;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0x20);
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d32;
        iVar2 = fcn.180267d70(uVar1, iVar4, uVar5, in_RDX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d3b;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d53;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d65;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d6d;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d91;
    fcn.180268030(iVar4);
    return uVar5;
}

// ============================================================
// Function: FUN_180269d84
// Address: 0x180269d84
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180269c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180269c65;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    if ((((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
       (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dc5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dd7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ca4;
    iVar4 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ccd;
        iVar2 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cd6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cee;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d00;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d08;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0x20);
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d32;
        iVar2 = fcn.180267d70(uVar1, iVar4, uVar5, in_RDX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d3b;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d53;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d65;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d6d;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d91;
    fcn.180268030(iVar4);
    return uVar5;
}

// ============================================================
// Function: FUN_180269da8
// Address: 0x180269da8
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180269c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar5;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    
    uStack_10 = 0x180269c65;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar5 = 0;
    if ((((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
       (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dad;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dc5;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269dd7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ca4;
    iVar4 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar3));
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&var_20h + iVar3) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269ccd;
        iVar2 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                              *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                              *(int64_t *)(&stack0x00000060 + iVar3));
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cd6;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269cee;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d00;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d08;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = *(undefined8 *)(in_RCX + 0x20);
        uVar1 = *(undefined8 *)(in_RCX + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d32;
        iVar2 = fcn.180267d70(uVar1, iVar4, uVar5, in_RDX);
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d3b;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d53;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                          *(int64_t *)(&stack0x00000028 + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)((int64_t)&arg_48h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d65;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d6d;
            fcn.180268030(iVar4);
            return 0;
        }
        uVar5 = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269d91;
    fcn.180268030(iVar4);
    return uVar5;
}

// ============================================================
// Function: FUN_180269df0
// Address: 0x180269df0
// Size: 37 bytes
// ============================================================
undefined8 fcn.180269df0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180269dfc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e80;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e98;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e23;
        uVar4 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e2e;
        iVar2 = fcn.180254f10(uVar1, uVar4);
        if (-1 < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e48;
            iVar2 = fcn.180254f10(uVar1, uVar4);
            if (iVar2 < 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e5c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e74;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269eaa;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180269e15
// Address: 0x180269e15
// Size: 34 bytes
// ============================================================
undefined8 fcn.180269df0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180269dfc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e80;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e98;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e23;
        uVar4 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e2e;
        iVar2 = fcn.180254f10(uVar1, uVar4);
        if (-1 < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e48;
            iVar2 = fcn.180254f10(uVar1, uVar4);
            if (iVar2 < 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e5c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e74;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269eaa;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180269e37
// Address: 0x180269e37
// Size: 123 bytes
// ============================================================
undefined8 fcn.180269df0(int64_t arg_28h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180269dfc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x28) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e80;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e98;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RBX;
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e23;
        uVar4 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e2e;
        iVar2 = fcn.180254f10(uVar1, uVar4);
        if (-1 < iVar2) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar4 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e48;
            iVar2 = fcn.180254f10(uVar1, uVar4);
            if (iVar2 < 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e5c;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269e74;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180269eaa;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_180269ec0
// Address: 0x180269ec0
// Size: 121 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180269ec0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269eef;
    iVar5 = func_0x00018021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269efd;
    iVar3 = func_0x00018026a070(in_RCX, in_RDX);
    if (iVar3 != 0) {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f12;
            iVar3 = func_0x0001802553a0(iVar5);
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f29;
        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar5 != 0) {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
            uVar1 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f4a;
            iVar3 = func_0x0001802553f0(uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f53;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f6b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f7d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f85;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fae;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fb7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fcf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe9;
                fcn.180268030(iVar5);
                return 0;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269ffe;
            iVar3 = func_0x0001802682b0(uVar1, iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a007;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a01f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a031;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a039;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a04f;
            fcn.180268030(iVar5);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180269f39
// Address: 0x180269f39
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180269ec0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269eef;
    iVar5 = func_0x00018021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269efd;
    iVar3 = func_0x00018026a070(in_RCX, in_RDX);
    if (iVar3 != 0) {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f12;
            iVar3 = func_0x0001802553a0(iVar5);
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f29;
        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar5 != 0) {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
            uVar1 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f4a;
            iVar3 = func_0x0001802553f0(uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f53;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f6b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f7d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f85;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fae;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fb7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fcf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe9;
                fcn.180268030(iVar5);
                return 0;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269ffe;
            iVar3 = func_0x0001802682b0(uVar1, iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a007;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a01f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a031;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a039;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a04f;
            fcn.180268030(iVar5);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180269f91
// Address: 0x180269f91
// Size: 97 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180269ec0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269eef;
    iVar5 = func_0x00018021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269efd;
    iVar3 = func_0x00018026a070(in_RCX, in_RDX);
    if (iVar3 != 0) {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f12;
            iVar3 = func_0x0001802553a0(iVar5);
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f29;
        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar5 != 0) {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
            uVar1 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f4a;
            iVar3 = func_0x0001802553f0(uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f53;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f6b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f7d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f85;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fae;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fb7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fcf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe9;
                fcn.180268030(iVar5);
                return 0;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269ffe;
            iVar3 = func_0x0001802682b0(uVar1, iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a007;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a01f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a031;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a039;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a04f;
            fcn.180268030(iVar5);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180269ff2
// Address: 0x180269ff2
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180269ec0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269eef;
    iVar5 = func_0x00018021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269efd;
    iVar3 = func_0x00018026a070(in_RCX, in_RDX);
    if (iVar3 != 0) {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f12;
            iVar3 = func_0x0001802553a0(iVar5);
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f29;
        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar5 != 0) {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
            uVar1 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f4a;
            iVar3 = func_0x0001802553f0(uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f53;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f6b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f7d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f85;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fae;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fb7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fcf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe9;
                fcn.180268030(iVar5);
                return 0;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269ffe;
            iVar3 = func_0x0001802682b0(uVar1, iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a007;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a01f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a031;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a039;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a04f;
            fcn.180268030(iVar5);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026a042
// Address: 0x18026a042
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180269ec0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269eef;
    iVar5 = func_0x00018021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269efd;
    iVar3 = func_0x00018026a070(in_RCX, in_RDX);
    if (iVar3 != 0) {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f12;
            iVar3 = func_0x0001802553a0(iVar5);
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f29;
        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar5 != 0) {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
            uVar1 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f4a;
            iVar3 = func_0x0001802553f0(uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f53;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f6b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f7d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f85;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fae;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fb7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fcf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe9;
                fcn.180268030(iVar5);
                return 0;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269ffe;
            iVar3 = func_0x0001802682b0(uVar1, iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a007;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a01f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a031;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a039;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a04f;
            fcn.180268030(iVar5);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026a058
// Address: 0x18026a058
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180269ec0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180269edb;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269eef;
    iVar5 = func_0x00018021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269efd;
    iVar3 = func_0x00018026a070(in_RCX, in_RDX);
    if (iVar3 != 0) {
        if (iVar5 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f12;
            iVar3 = func_0x0001802553a0(iVar5);
            if (iVar3 != 0) {
                return 1;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f29;
        iVar5 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar5 != 0) {
            iVar2 = *(int64_t *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
            uVar1 = *(undefined8 *)(iVar2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f4a;
            iVar3 = func_0x0001802553f0(uVar1);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f53;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f6b;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f7d;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269f85;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&var_20h + iVar4) = in_RDX;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fae;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fb7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fcf;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe1;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269fe9;
                fcn.180268030(iVar5);
                return 0;
            }
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180269ffe;
            iVar3 = func_0x0001802682b0(uVar1, iVar5);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a007;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a01f;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a031;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a039;
                fcn.180268030(iVar5);
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a04f;
            fcn.180268030(iVar5);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026a070
// Address: 0x18026a070
// Size: 129 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18026a070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a080;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a261;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a279;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a28b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0b1;
    iVar2 = fcn.1802682b0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0ba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0d2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0e4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a108;
    fcn.1802d48b0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a110;
    uVar5 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a11b;
    iVar6 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a13b;
        iVar2 = fcn.180268070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a148;
            iVar2 = fcn.180266b40(uVar1);
            if (iVar2 == 0x196) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a15b;
                iVar2 = fcn.180255370(uVar5);
                if (iVar2 == 0) {
                    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a16f;
                    iVar2 = fcn.180254f10(uVar5, uVar1);
                    if (iVar2 < 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a17b;
                        iVar2 = fcn.180255370(iVar6);
                        if (iVar2 == 0) {
                            uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a18f;
                            iVar2 = fcn.180254f10(iVar6, uVar5);
                            if (iVar2 < 0) goto code_r0x00018026a20c;
                        }
                    }
                }
            } else {
                uVar5 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ef;
                iVar2 = fcn.180266ae0(uVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1fa;
                iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                      *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
                if (iVar3 <= iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a207;
                    iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                         );
                    if (iVar3 <= iVar2) {
code_r0x00018026a20c:
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a214;
                        fcn.1802d4450(in_RDX);
                        uVar5 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a224;
                        iVar2 = fcn.180268360(uVar1, uVar5, in_RDX);
                        if (0 < iVar2) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a22d;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a245;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        goto code_r0x00018026a1c0;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a19b;
    fcn.1802d4450(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1a0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x00018026a1c0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026a0f1
// Address: 0x18026a0f1
// Size: 245 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18026a070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a080;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a261;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a279;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a28b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0b1;
    iVar2 = fcn.1802682b0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0ba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0d2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0e4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a108;
    fcn.1802d48b0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a110;
    uVar5 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a11b;
    iVar6 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a13b;
        iVar2 = fcn.180268070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a148;
            iVar2 = fcn.180266b40(uVar1);
            if (iVar2 == 0x196) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a15b;
                iVar2 = fcn.180255370(uVar5);
                if (iVar2 == 0) {
                    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a16f;
                    iVar2 = fcn.180254f10(uVar5, uVar1);
                    if (iVar2 < 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a17b;
                        iVar2 = fcn.180255370(iVar6);
                        if (iVar2 == 0) {
                            uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a18f;
                            iVar2 = fcn.180254f10(iVar6, uVar5);
                            if (iVar2 < 0) goto code_r0x00018026a20c;
                        }
                    }
                }
            } else {
                uVar5 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ef;
                iVar2 = fcn.180266ae0(uVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1fa;
                iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                      *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
                if (iVar3 <= iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a207;
                    iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                         );
                    if (iVar3 <= iVar2) {
code_r0x00018026a20c:
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a214;
                        fcn.1802d4450(in_RDX);
                        uVar5 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a224;
                        iVar2 = fcn.180268360(uVar1, uVar5, in_RDX);
                        if (0 < iVar2) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a22d;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a245;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        goto code_r0x00018026a1c0;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a19b;
    fcn.1802d4450(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1a0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x00018026a1c0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026a1e6
// Address: 0x18026a1e6
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18026a070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a080;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a261;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a279;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a28b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0b1;
    iVar2 = fcn.1802682b0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0ba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0d2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0e4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a108;
    fcn.1802d48b0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a110;
    uVar5 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a11b;
    iVar6 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a13b;
        iVar2 = fcn.180268070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a148;
            iVar2 = fcn.180266b40(uVar1);
            if (iVar2 == 0x196) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a15b;
                iVar2 = fcn.180255370(uVar5);
                if (iVar2 == 0) {
                    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a16f;
                    iVar2 = fcn.180254f10(uVar5, uVar1);
                    if (iVar2 < 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a17b;
                        iVar2 = fcn.180255370(iVar6);
                        if (iVar2 == 0) {
                            uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a18f;
                            iVar2 = fcn.180254f10(iVar6, uVar5);
                            if (iVar2 < 0) goto code_r0x00018026a20c;
                        }
                    }
                }
            } else {
                uVar5 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ef;
                iVar2 = fcn.180266ae0(uVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1fa;
                iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                      *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
                if (iVar3 <= iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a207;
                    iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                         );
                    if (iVar3 <= iVar2) {
code_r0x00018026a20c:
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a214;
                        fcn.1802d4450(in_RDX);
                        uVar5 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a224;
                        iVar2 = fcn.180268360(uVar1, uVar5, in_RDX);
                        if (0 < iVar2) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a22d;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a245;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        goto code_r0x00018026a1c0;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a19b;
    fcn.1802d4450(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1a0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x00018026a1c0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026a25c
// Address: 0x18026a25c
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18026a070(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a080;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (((in_RCX == 0) || (*(int64_t *)(in_RCX + 0x18) == 0)) || (*(int64_t *)(in_RCX + 0x20) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a261;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a279;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a28b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0b1;
    iVar2 = fcn.1802682b0();
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0ba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0d2;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a0e4;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a108;
    fcn.1802d48b0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a110;
    uVar5 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a11b;
    iVar6 = fcn.1802d4590(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4));
    if (iVar6 != 0) {
        *(undefined8 *)((int64_t)&var_18h + iVar4) = in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a13b;
        iVar2 = fcn.180268070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_48h + iVar4));
        if (iVar2 != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a148;
            iVar2 = fcn.180266b40(uVar1);
            if (iVar2 == 0x196) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a15b;
                iVar2 = fcn.180255370(uVar5);
                if (iVar2 == 0) {
                    uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a16f;
                    iVar2 = fcn.180254f10(uVar5, uVar1);
                    if (iVar2 < 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a17b;
                        iVar2 = fcn.180255370(iVar6);
                        if (iVar2 == 0) {
                            uVar5 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x40);
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a18f;
                            iVar2 = fcn.180254f10(iVar6, uVar5);
                            if (iVar2 < 0) goto code_r0x00018026a20c;
                        }
                    }
                }
            } else {
                uVar5 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ef;
                iVar2 = fcn.180266ae0(uVar5);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1fa;
                iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                      *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4));
                if (iVar3 <= iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a207;
                    iVar3 = fcn.180255500(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)(&stack0x00000068 + iVar4), *(int64_t *)(&stack0x00000070 + iVar4)
                                         );
                    if (iVar3 <= iVar2) {
code_r0x00018026a20c:
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a214;
                        fcn.1802d4450(in_RDX);
                        uVar5 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a224;
                        iVar2 = fcn.180268360(uVar1, uVar5, in_RDX);
                        if (0 < iVar2) {
                            return 1;
                        }
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a22d;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a245;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        goto code_r0x00018026a1c0;
                    }
                }
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a19b;
    fcn.1802d4450(in_RDX);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1a0;
    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1b8;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
code_r0x00018026a1c0:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a1ca;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_18026a2b0
// Address: 0x18026a2b0
// Size: 96 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026a2b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h)
{
    undefined8 uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    undefined8 uVar9;
    
    uStack_10 = 0x18026a2c1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a31a;
    iVar5 = fcn.1802d4790(uVar1);
    if (iVar5 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a341;
    iVar6 = fcn.18021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a34f;
    iVar3 = fcn.18026a070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    if (iVar3 == 0) goto code_r0x00018026a58b;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    if (iVar6 == 0) {
code_r0x00018026a371:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a37a;
        iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar6 == 0) goto code_r0x00018026a58b;
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a396;
        iVar3 = fcn.1802553f0(uVar1);
        if (iVar3 == 0) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3db;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3e4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3fc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a40f;
                iVar3 = fcn.1802682b0(uVar1, iVar6);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a457;
                    fcn.180268030(iVar6);
                    goto code_r0x00018026a457;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a430;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a39f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3b7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a442;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a44a;
        fcn.180268030(iVar6);
        goto code_r0x00018026a58b;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a369;
    iVar3 = fcn.1802553a0(iVar6);
    if (iVar3 == 0) goto code_r0x00018026a371;
code_r0x00018026a457:
    if (*(int64_t *)(in_RCX + 0x28) == 0) {
code_r0x00018026a580:
        uVar9 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a616;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a62e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a640;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar9 = uVar8;
            goto code_r0x00018026a58b;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a474;
        uVar7 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a47f;
        iVar3 = fcn.180254f10(uVar1, uVar7);
        if (-1 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a498;
            iVar3 = fcn.180254f10(uVar1, uVar7);
            if (iVar3 < 0) {
                if (((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
                   (*(int64_t *)(in_RCX + 0x28) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar9 = uVar8;
                    goto code_r0x00018026a58b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4c9;
                iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                bVar2 = false;
                if (iVar6 != 0) {
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4f2;
                    iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4)
                                         );
                    bVar2 = false;
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4fb;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a513;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a525;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    } else {
                        uVar8 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a53a;
                        iVar3 = fcn.180267d70(uVar1, iVar6, uVar8, iVar5);
                        if (iVar3 == 0) {
                            bVar2 = true;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a543;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a55b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a56d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a57c;
                fcn.180268030(iVar6);
                if (!bVar2) goto code_r0x00018026a58b;
                goto code_r0x00018026a580;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a60c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = uVar8;
    }
code_r0x00018026a58b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a593;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar9;
}

// ============================================================
// Function: FUN_18026a310
// Address: 0x18026a310
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026a2b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h)
{
    undefined8 uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    undefined8 uVar9;
    
    uStack_10 = 0x18026a2c1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a31a;
    iVar5 = fcn.1802d4790(uVar1);
    if (iVar5 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a341;
    iVar6 = fcn.18021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a34f;
    iVar3 = fcn.18026a070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    if (iVar3 == 0) goto code_r0x00018026a58b;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    if (iVar6 == 0) {
code_r0x00018026a371:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a37a;
        iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar6 == 0) goto code_r0x00018026a58b;
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a396;
        iVar3 = fcn.1802553f0(uVar1);
        if (iVar3 == 0) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3db;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3e4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3fc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a40f;
                iVar3 = fcn.1802682b0(uVar1, iVar6);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a457;
                    fcn.180268030(iVar6);
                    goto code_r0x00018026a457;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a430;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a39f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3b7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a442;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a44a;
        fcn.180268030(iVar6);
        goto code_r0x00018026a58b;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a369;
    iVar3 = fcn.1802553a0(iVar6);
    if (iVar3 == 0) goto code_r0x00018026a371;
code_r0x00018026a457:
    if (*(int64_t *)(in_RCX + 0x28) == 0) {
code_r0x00018026a580:
        uVar9 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a616;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a62e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a640;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar9 = uVar8;
            goto code_r0x00018026a58b;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a474;
        uVar7 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a47f;
        iVar3 = fcn.180254f10(uVar1, uVar7);
        if (-1 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a498;
            iVar3 = fcn.180254f10(uVar1, uVar7);
            if (iVar3 < 0) {
                if (((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
                   (*(int64_t *)(in_RCX + 0x28) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar9 = uVar8;
                    goto code_r0x00018026a58b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4c9;
                iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                bVar2 = false;
                if (iVar6 != 0) {
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4f2;
                    iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4)
                                         );
                    bVar2 = false;
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4fb;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a513;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a525;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    } else {
                        uVar8 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a53a;
                        iVar3 = fcn.180267d70(uVar1, iVar6, uVar8, iVar5);
                        if (iVar3 == 0) {
                            bVar2 = true;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a543;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a55b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a56d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a57c;
                fcn.180268030(iVar6);
                if (!bVar2) goto code_r0x00018026a58b;
                goto code_r0x00018026a580;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a60c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = uVar8;
    }
code_r0x00018026a58b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a593;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar9;
}

// ============================================================
// Function: FUN_18026a333
// Address: 0x18026a333
// Size: 36 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026a2b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h)
{
    undefined8 uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    undefined8 uVar9;
    
    uStack_10 = 0x18026a2c1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a31a;
    iVar5 = fcn.1802d4790(uVar1);
    if (iVar5 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a341;
    iVar6 = fcn.18021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a34f;
    iVar3 = fcn.18026a070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    if (iVar3 == 0) goto code_r0x00018026a58b;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    if (iVar6 == 0) {
code_r0x00018026a371:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a37a;
        iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar6 == 0) goto code_r0x00018026a58b;
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a396;
        iVar3 = fcn.1802553f0(uVar1);
        if (iVar3 == 0) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3db;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3e4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3fc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a40f;
                iVar3 = fcn.1802682b0(uVar1, iVar6);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a457;
                    fcn.180268030(iVar6);
                    goto code_r0x00018026a457;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a430;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a39f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3b7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a442;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a44a;
        fcn.180268030(iVar6);
        goto code_r0x00018026a58b;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a369;
    iVar3 = fcn.1802553a0(iVar6);
    if (iVar3 == 0) goto code_r0x00018026a371;
code_r0x00018026a457:
    if (*(int64_t *)(in_RCX + 0x28) == 0) {
code_r0x00018026a580:
        uVar9 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a616;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a62e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a640;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar9 = uVar8;
            goto code_r0x00018026a58b;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a474;
        uVar7 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a47f;
        iVar3 = fcn.180254f10(uVar1, uVar7);
        if (-1 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a498;
            iVar3 = fcn.180254f10(uVar1, uVar7);
            if (iVar3 < 0) {
                if (((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
                   (*(int64_t *)(in_RCX + 0x28) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar9 = uVar8;
                    goto code_r0x00018026a58b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4c9;
                iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                bVar2 = false;
                if (iVar6 != 0) {
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4f2;
                    iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4)
                                         );
                    bVar2 = false;
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4fb;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a513;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a525;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    } else {
                        uVar8 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a53a;
                        iVar3 = fcn.180267d70(uVar1, iVar6, uVar8, iVar5);
                        if (iVar3 == 0) {
                            bVar2 = true;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a543;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a55b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a56d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a57c;
                fcn.180268030(iVar6);
                if (!bVar2) goto code_r0x00018026a58b;
                goto code_r0x00018026a580;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a60c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = uVar8;
    }
code_r0x00018026a58b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a593;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar9;
}

// ============================================================
// Function: FUN_18026a357
// Address: 0x18026a357
// Size: 564 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026a2b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h)
{
    undefined8 uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    undefined8 uVar9;
    
    uStack_10 = 0x18026a2c1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a31a;
    iVar5 = fcn.1802d4790(uVar1);
    if (iVar5 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a341;
    iVar6 = fcn.18021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a34f;
    iVar3 = fcn.18026a070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    if (iVar3 == 0) goto code_r0x00018026a58b;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    if (iVar6 == 0) {
code_r0x00018026a371:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a37a;
        iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar6 == 0) goto code_r0x00018026a58b;
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a396;
        iVar3 = fcn.1802553f0(uVar1);
        if (iVar3 == 0) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3db;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3e4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3fc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a40f;
                iVar3 = fcn.1802682b0(uVar1, iVar6);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a457;
                    fcn.180268030(iVar6);
                    goto code_r0x00018026a457;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a430;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a39f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3b7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a442;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a44a;
        fcn.180268030(iVar6);
        goto code_r0x00018026a58b;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a369;
    iVar3 = fcn.1802553a0(iVar6);
    if (iVar3 == 0) goto code_r0x00018026a371;
code_r0x00018026a457:
    if (*(int64_t *)(in_RCX + 0x28) == 0) {
code_r0x00018026a580:
        uVar9 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a616;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a62e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a640;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar9 = uVar8;
            goto code_r0x00018026a58b;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a474;
        uVar7 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a47f;
        iVar3 = fcn.180254f10(uVar1, uVar7);
        if (-1 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a498;
            iVar3 = fcn.180254f10(uVar1, uVar7);
            if (iVar3 < 0) {
                if (((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
                   (*(int64_t *)(in_RCX + 0x28) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar9 = uVar8;
                    goto code_r0x00018026a58b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4c9;
                iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                bVar2 = false;
                if (iVar6 != 0) {
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4f2;
                    iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4)
                                         );
                    bVar2 = false;
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4fb;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a513;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a525;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    } else {
                        uVar8 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a53a;
                        iVar3 = fcn.180267d70(uVar1, iVar6, uVar8, iVar5);
                        if (iVar3 == 0) {
                            bVar2 = true;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a543;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a55b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a56d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a57c;
                fcn.180268030(iVar6);
                if (!bVar2) goto code_r0x00018026a58b;
                goto code_r0x00018026a580;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a60c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = uVar8;
    }
code_r0x00018026a58b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a593;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar9;
}

// ============================================================
// Function: FUN_18026a58b
// Address: 0x18026a58b
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026a2b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h)
{
    undefined8 uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    undefined8 uVar9;
    
    uStack_10 = 0x18026a2c1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a31a;
    iVar5 = fcn.1802d4790(uVar1);
    if (iVar5 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a341;
    iVar6 = fcn.18021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a34f;
    iVar3 = fcn.18026a070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    if (iVar3 == 0) goto code_r0x00018026a58b;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    if (iVar6 == 0) {
code_r0x00018026a371:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a37a;
        iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar6 == 0) goto code_r0x00018026a58b;
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a396;
        iVar3 = fcn.1802553f0(uVar1);
        if (iVar3 == 0) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3db;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3e4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3fc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a40f;
                iVar3 = fcn.1802682b0(uVar1, iVar6);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a457;
                    fcn.180268030(iVar6);
                    goto code_r0x00018026a457;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a430;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a39f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3b7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a442;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a44a;
        fcn.180268030(iVar6);
        goto code_r0x00018026a58b;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a369;
    iVar3 = fcn.1802553a0(iVar6);
    if (iVar3 == 0) goto code_r0x00018026a371;
code_r0x00018026a457:
    if (*(int64_t *)(in_RCX + 0x28) == 0) {
code_r0x00018026a580:
        uVar9 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a616;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a62e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a640;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar9 = uVar8;
            goto code_r0x00018026a58b;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a474;
        uVar7 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a47f;
        iVar3 = fcn.180254f10(uVar1, uVar7);
        if (-1 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a498;
            iVar3 = fcn.180254f10(uVar1, uVar7);
            if (iVar3 < 0) {
                if (((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
                   (*(int64_t *)(in_RCX + 0x28) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar9 = uVar8;
                    goto code_r0x00018026a58b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4c9;
                iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                bVar2 = false;
                if (iVar6 != 0) {
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4f2;
                    iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4)
                                         );
                    bVar2 = false;
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4fb;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a513;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a525;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    } else {
                        uVar8 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a53a;
                        iVar3 = fcn.180267d70(uVar1, iVar6, uVar8, iVar5);
                        if (iVar3 == 0) {
                            bVar2 = true;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a543;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a55b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a56d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a57c;
                fcn.180268030(iVar6);
                if (!bVar2) goto code_r0x00018026a58b;
                goto code_r0x00018026a580;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a60c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = uVar8;
    }
code_r0x00018026a58b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a593;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar9;
}

// ============================================================
// Function: FUN_18026a5ac
// Address: 0x18026a5ac
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026a2b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_80h)
{
    undefined8 uVar1;
    bool bVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    int64_t var_8h;
    undefined8 uVar9;
    
    uStack_10 = 0x18026a2c1;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar9 = 0;
    uVar8 = 0;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2d4;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2ec;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a2fe;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a31a;
    iVar5 = fcn.1802d4790(uVar1);
    if (iVar5 == 0) {
        return 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a341;
    iVar6 = fcn.18021eaf0(uVar1);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a34f;
    iVar3 = fcn.18026a070(*(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4));
    if (iVar3 == 0) goto code_r0x00018026a58b;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    if (iVar6 == 0) {
code_r0x00018026a371:
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a37a;
        iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar6 == 0) goto code_r0x00018026a58b;
        uVar1 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a396;
        iVar3 = fcn.1802553f0(uVar1);
        if (iVar3 == 0) {
            *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
            *(undefined8 *)((int64_t)&var_18h + iVar4) = uVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3db;
            iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4), *(int64_t *)(&stack0x00000058 + iVar4), 
                                  *(int64_t *)(&stack0x00000060 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3e4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3fc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            } else {
                uVar1 = *(undefined8 *)(in_RCX + 0x18);
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a40f;
                iVar3 = fcn.1802682b0(uVar1, iVar6);
                if (iVar3 != 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a457;
                    fcn.180268030(iVar6);
                    goto code_r0x00018026a457;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a418;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a430;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                              *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                              *(int64_t *)((int64_t)&arg_48h + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a39f;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a3b7;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a442;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a44a;
        fcn.180268030(iVar6);
        goto code_r0x00018026a58b;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a369;
    iVar3 = fcn.1802553a0(iVar6);
    if (iVar3 == 0) goto code_r0x00018026a371;
code_r0x00018026a457:
    if (*(int64_t *)(in_RCX + 0x28) == 0) {
code_r0x00018026a580:
        uVar9 = 1;
    } else {
        if (*(int64_t *)(in_RCX + 0x18) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a616;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a62e;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                          *(int64_t *)((int64_t)&arg_48h + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a640;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
            uVar9 = uVar8;
            goto code_r0x00018026a58b;
        }
        uVar1 = *(undefined8 *)(in_RCX + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a474;
        uVar7 = fcn.180255ab0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a47f;
        iVar3 = fcn.180254f10(uVar1, uVar7);
        if (-1 < iVar3) {
            uVar1 = *(undefined8 *)(in_RCX + 0x28);
            uVar7 = *(undefined8 *)(*(int64_t *)(in_RCX + 0x18) + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a498;
            iVar3 = fcn.180254f10(uVar1, uVar7);
            if (iVar3 < 0) {
                if (((*(int64_t *)(in_RCX + 0x18) == 0) || (*(int64_t *)(in_RCX + 0x20) == 0)) ||
                   (*(int64_t *)(in_RCX + 0x28) == 0)) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5b1;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5c9;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5db;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    uVar9 = uVar8;
                    goto code_r0x00018026a58b;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4c9;
                iVar6 = fcn.1802685b0(*(int64_t *)((int64_t)&var_18h + iVar4));
                bVar2 = false;
                if (iVar6 != 0) {
                    *(int64_t *)((int64_t)&var_20h + iVar4) = iVar5;
                    *(undefined8 *)((int64_t)&var_18h + iVar4) = 0;
                    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4f2;
                    iVar3 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_40h + iVar4), 
                                          *(int64_t *)((int64_t)&arg_50h + iVar4), 
                                          *(int64_t *)(&stack0x00000058 + iVar4), *(int64_t *)(&stack0x00000060 + iVar4)
                                         );
                    bVar2 = false;
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a4fb;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a513;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar4));
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a525;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                    } else {
                        uVar8 = *(undefined8 *)(in_RCX + 0x20);
                        uVar1 = *(undefined8 *)(in_RCX + 0x18);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a53a;
                        iVar3 = fcn.180267d70(uVar1, iVar6, uVar8, iVar5);
                        if (iVar3 == 0) {
                            bVar2 = true;
                        } else {
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a543;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a55b;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)((int64_t)&var_20h + iVar4), 
                                          *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4)
                                          , *(int64_t *)((int64_t)&arg_48h + iVar4));
                            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a56d;
                            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
                        }
                    }
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a57c;
                fcn.180268030(iVar6);
                if (!bVar2) goto code_r0x00018026a58b;
                goto code_r0x00018026a580;
            }
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5e2;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a5fa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a60c;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar4));
        uVar9 = uVar8;
    }
code_r0x00018026a58b:
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a593;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)((int64_t)&arg_50h + iVar4));
    return uVar9;
}

// ============================================================
// Function: FUN_18026a650
// Address: 0x18026a650
// Size: 24 bytes
// ============================================================
void fcn.18026a650(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint32_t uVar12;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t iVar13;
    undefined8 unaff_R12;
    undefined8 uVar14;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t iStack_8;
    
    iStack_8 = 0x18026a65a;
    iVar11 = fcn.18045a350();
    iVar11 = -iVar11;
    uVar2 = 0;
    *(undefined8 *)(&stack0x00000038 + iVar11) = unaff_RBX;
    *(undefined8 *)(&stack0x00000040 + iVar11) = unaff_RBP;
    *(undefined8 *)(&stack0x00000048 + iVar11) = unaff_RSI;
    *(undefined8 *)(&stack0x00000020 + iVar11) = unaff_RDI;
    *(undefined8 *)(&stack0x00000018 + iVar11) = unaff_R12;
    *(undefined8 *)(&stack0x00000010 + iVar11) = unaff_R13;
    *(undefined8 *)(&stack0x00000008 + iVar11) = unaff_R14;
    *(undefined8 *)(&stack0x00000020 + iVar11 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&iStack_8 + iVar11) = 0x180269742;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000260 + iVar3 + iVar11) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000020 + iVar3 + iVar11 + -0x20);
    uVar14 = *(undefined8 *)(param_1 + 0x18);
    uVar8 = *(undefined8 *)(param_1 + 0x50);
    iVar5 = 0;
    *(undefined8 *)(&stack0x00000048 + iVar3 + iVar11) = uVar14;
    iVar7 = 0;
    *(undefined4 *)(&stack0x00000030 + iVar3 + iVar11) = uVar2;
    iVar9 = 0;
    iVar13 = 0;
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269777;
    iVar4 = func_0x0001802d4850(uVar8);
    uVar12 = *(uint32_t *)(param_1 + 0x3c);
    if (iVar4 != 0) {
        iVar5 = *(int64_t *)(param_1 + 0x28);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269799;
            iVar5 = func_0x0001802556d0();
            if (iVar5 == 0) goto code_r0x000180269a70;
        }
        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802697ad;
        iVar6 = func_0x0001801dd6c0(uVar14);
        if (iVar6 != 0) {
            iVar9 = iVar13;
            if ((uVar12 & 4) == 0) {
                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802697f3;
                iVar7 = func_0x0001802551a0(iVar6);
                if (iVar7 != 0) {
code_r0x000180269800:
                    do {
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269811;
                        iVar1 = func_0x0001802dc870(iVar5, iVar7, 0, iVar4);
                        if (iVar1 == 0) goto code_r0x000180269a70;
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269821;
                        iVar1 = fcn.1802553f0(iVar5);
                    } while (iVar1 != 0);
                    iVar9 = *(int64_t *)(param_1 + 0x20);
                    if (iVar9 == 0) {
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269836;
                        iVar9 = fcn.1802685b0(*(int64_t *)(&stack0x00000020 + iVar3 + iVar11));
                        if (iVar9 == 0) goto code_r0x000180269a70;
                    }
                    *(int64_t *)(&stack0x00000028 + iVar3 + iVar11) = iVar4;
                    *(undefined8 *)(&stack0x00000020 + iVar3 + iVar11) = 0;
                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269861;
                    iVar1 = fcn.180268410(*(int64_t *)(&stack0x00000040 + iVar3 + iVar11), 
                                          *(int64_t *)(&stack0x00000048 + iVar3 + iVar11), 
                                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar11), 
                                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar11), 
                                          *(int64_t *)(&stack0x00000068 + iVar3 + iVar11));
                    if (iVar1 != 0) {
                        *(int64_t *)(param_1 + 0x60) = *(int64_t *)(param_1 + 0x60) + 1;
                        *(int64_t *)(param_1 + 0x28) = iVar5;
                        iVar5 = 0;
                        *(int64_t *)(param_1 + 0x20) = iVar9;
                        iVar9 = 0;
                        iVar13 = 0;
                        iVar6 = 0;
                        if (*(int32_t *)(&stack0x00000030 + iVar3 + iVar11) == 0) goto code_r0x000180269a98;
                        uVar8 = *(undefined8 *)(param_1 + 0x50);
                        *(undefined8 *)(&stack0x00000040 + iVar3 + iVar11) = 0;
                        *(undefined8 *)(&stack0x00000038 + iVar3 + iVar11) = 0;
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802698a8;
                        func_0x0001802c17b0(uVar8, &stack0x00000040 + iVar3 + iVar11, &stack0x00000038 + iVar3 + iVar11)
                        ;
                        *(undefined (*) [16])(&stack0x00000050 + iVar3 + iVar11) = ZEXT816(0);
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802698bf;
                        iVar13 = func_0x0001802c1810(*(undefined8 *)(&stack0x00000040 + iVar3 + iVar11), 
                                                     *(undefined8 *)(&stack0x00000038 + iVar3 + iVar11));
                        if (iVar13 == 0) goto code_r0x000180269a70;
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802698e1;
                        func_0x0001802c18a0(iVar13, 0x1804e7250, 0x1804ad21c);
                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802698f3;
                        iVar6 = func_0x0001802dd3f0(&stack0x00000050 + iVar3 + iVar11, 0x10, param_1);
                        if (iVar6 == 0) {
code_r0x000180269a51:
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a5b;
                            func_0x0001802c1960(iVar13, 0);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a63;
                            func_0x0001802c1780(iVar13);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a6b;
                            func_0x0001802b0330(iVar6);
                        } else {
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x18026990c;
                            func_0x0001802c18f0(iVar13, &stack0x00000050 + iVar3 + iVar11);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269921;
                            iVar1 = func_0x0001802dd5a0(&stack0x00000050 + iVar3 + iVar11, 0x10, iVar6, param_1);
                            if (iVar1 != 1) goto code_r0x000180269a51;
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269933;
                            func_0x0001802c1960(iVar13, 1);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x18026993b;
                            func_0x0001802c1780(iVar13);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269943;
                            func_0x0001802b0330(iVar6);
                            *(undefined4 *)(&stack0x00000030 + iVar3 + iVar11) = 0;
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269959;
                            fcn.1804986e0(&stack0x00000060 + iVar3 + iVar11, 0, 0x200);
                            *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269968;
                            iVar13 = func_0x0001802c1810(*(undefined8 *)(&stack0x00000040 + iVar3 + iVar11), 
                                                         *(undefined8 *)(&stack0x00000038 + iVar3 + iVar11));
                            if (iVar13 != 0) {
                                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x18026998a;
                                func_0x0001802c18a0(iVar13, 0x1804e7240, 0x1804ad21c);
                                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269993;
                                iVar6 = fcn.1802685b0(*(int64_t *)(&stack0x00000020 + iVar3 + iVar11));
                                if (iVar6 == 0) {
code_r0x000180269a2d:
                                    uVar12 = *(uint32_t *)(&stack0x00000030 + iVar3 + iVar11);
                                } else {
                                    *(int64_t *)(&stack0x00000028 + iVar3 + iVar11) = iVar4;
                                    *(undefined8 *)(&stack0x00000020 + iVar3 + iVar11) = 0;
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802699bc;
                                    iVar1 = fcn.180268410(*(int64_t *)(&stack0x00000040 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000048 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000058 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000068 + iVar3 + iVar11));
                                    if (iVar1 == 0) goto code_r0x000180269a2d;
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802699c9;
                                    iVar1 = fcn.180255500(*(int64_t *)(&stack0x00000030 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000038 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000040 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000048 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000070 + iVar3 + iVar11), 
                                                          *(int64_t *)(&stack0x00000078 + iVar3 + iVar11));
                                    if (0x1007 < iVar1 + 7) goto code_r0x000180269a2d;
                                    uVar14 = *(undefined8 *)(iVar6 + 0x10);
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802699e1;
                                    uVar2 = func_0x000180254c60(uVar14, &stack0x00000060 + iVar3 + iVar11);
                                    *(undefined4 *)(&stack0x00000034 + iVar3 + iVar11) = uVar2;
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802699f2;
                                    iVar1 = func_0x0001802c18f0(iVar13, &stack0x00000060 + iVar3 + iVar11);
                                    if (iVar1 != 0) {
                                        uVar14 = *(undefined8 *)(iVar6 + 0x10);
                                        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a08;
                                        iVar10 = func_0x000180254c30(&stack0x00000060 + iVar3 + iVar11, 
                                                                     *(undefined4 *)(&stack0x00000034 + iVar3 + iVar11)
                                                                     , uVar14);
                                        if (iVar10 == 0) goto code_r0x000180269a2d;
                                    }
                                    uVar14 = *(undefined8 *)(param_1 + 0x20);
                                    uVar8 = *(undefined8 *)(param_1 + 0x18);
                                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a20;
                                    iVar1 = fcn.180267d70(uVar8, uVar14, iVar6, iVar4);
                                    uVar12 = (uint32_t)(iVar1 == 0);
                                    *(uint32_t *)(&stack0x00000030 + iVar3 + iVar11) = (uint32_t)(iVar1 == 0);
                                }
                                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a39;
                                func_0x0001802c1960(iVar13, uVar12);
                                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a41;
                                func_0x0001802c1780(iVar13);
                                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a49;
                                fcn.180268030(iVar6);
                                iVar13 = iVar5;
                                iVar6 = iVar9;
                                if (*(int32_t *)(&stack0x00000030 + iVar3 + iVar11) != 0) goto code_r0x000180269a98;
                            }
                        }
                        uVar14 = *(undefined8 *)(&stack0x00000048 + iVar3 + iVar11);
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802697c3;
                iVar7 = fcn.1802554c0();
                if (iVar7 != 0) {
                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802697d4;
                    uVar8 = fcn.180255ab0();
                    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x1802697e2;
                    iVar1 = func_0x0001802d4a70(iVar7, iVar6, uVar8);
                    if (iVar1 != 0) goto code_r0x000180269800;
                }
            }
        }
    }
code_r0x000180269a70:
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a7c;
    func_0x0001800086f0(0x1804e7250);
    uVar8 = *(undefined8 *)(param_1 + 0x28);
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a85;
    func_0x000180254de0(uVar8);
    iVar13 = iVar5;
    iVar6 = iVar9;
    if (*(int64_t *)(param_1 + 0x20) != 0) {
        *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269a98;
        func_0x000180268920(uVar14);
    }
code_r0x000180269a98:
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269aa0;
    fcn.180268030(iVar6);
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269aa8;
    fcn.180254e90(iVar13);
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269ab0;
    fcn.1802d44d0(*(int64_t *)(&stack0x00000020 + iVar3 + iVar11), *(int64_t *)(&stack0x00000028 + iVar3 + iVar11), 
                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar11));
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269ab8;
    fcn.180255290(iVar7);
    *(undefined8 *)((int64_t)&iStack_8 + iVar3 + iVar11) = 0x180269aca;
    func_0x000180459870(*(uint64_t *)(&stack0x00000260 + iVar3 + iVar11) ^
                        (uint64_t)(&stack0x00000020 + iVar3 + iVar11 + -0x20));
    return;
}

// ============================================================
// Function: FUN_18026a670
// Address: 0x18026a670
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.18026a670(int64_t arg_38h, int64_t arg_40h, int64_t arg_80h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a680;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    uVar1 = *(undefined8 *)(in_RCX + 0x50);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a68f;
    iVar4 = fcn.1802d4790(uVar1);
    if (iVar4 == 0) {
        return 0;
    }
    *(int64_t *)((int64_t)&var_20h + iVar3) = iVar4;
    *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a6c9;
    iVar2 = fcn.180268410(*(int64_t *)((int64_t)&arg_38h + iVar3), *(int64_t *)((int64_t)&arg_40h + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3), *(int64_t *)(&stack0x00000058 + iVar3), 
                          *(int64_t *)(&stack0x00000060 + iVar3));
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a6d3;
    fcn.1802d44d0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    if (iVar2 == 1) {
        *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + 1;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18026a6f0
// Address: 0x18026a6f0
// Size: 303 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18026a6f0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a705;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (0x7fffffff < in_R8) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a71f;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a737;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a749;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    iVar2 = *(int64_t *)(in_RCX + 0x28);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a769;
        iVar2 = fcn.1802556d0();
        *(int64_t *)(in_RCX + 0x28) = iVar2;
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a777;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a78f;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                          *(int64_t *)(&stack0x00000048 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a7a1;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
            return 0;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a7c0;
    iVar2 = fcn.180254c30(in_RDX, in_R8 & 0xffffffff, iVar2);
    if (iVar2 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a7ca;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a7e2;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                      *(int64_t *)(&stack0x00000048 + iVar1));
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026a7f4;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
        return 0;
    }
    *(int64_t *)(in_RCX + 0x60) = *(int64_t *)(in_RCX + 0x60) + 1;
    return 1;
}

// ============================================================
// Function: FUN_18026a820
// Address: 0x18026a820
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.18026a820(int64_t arg_28h, int64_t arg_30h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar5;
    uint64_t in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a835;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar1 = *(undefined8 *)(in_RCX + 0x18);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a84a;
    iVar3 = fcn.180267710(uVar1);
    iVar2 = *(int64_t *)(in_RCX + 0x28);
    iVar3 = (int32_t)(iVar3 + 7 + (iVar3 + 7 >> 0x1f & 7U)) >> 3;
    if (iVar2 != 0) {
        uVar5 = (uint64_t)iVar3;
        if (in_RDX == 0) {
            return uVar5;
        }
        if (uVar5 <= in_R8) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a877;
            iVar3 = fcn.180254d60(iVar2, in_RDX, iVar3);
            if (iVar3 != -1) {
                return uVar5;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a881;
            fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a899;
            fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar4), *(int64_t *)((int64_t)&arg_30h + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar4));
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026a8ab;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026a8d0
// Address: 0x18026a8d0
// Size: 301 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18026a8d0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026a8ea;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a903;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a91b;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a931;
        iVar2 = func_0x000180222950(*(undefined8 *)0x180782b60);
        if (iVar2 == 0) {
            return 0;
        }
        if (*(int32_t *)(in_RCX + 0xa0) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a94e;
            func_0x000180222910(*(undefined8 *)0x180782b60);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a953;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a96b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar3), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                          *(int64_t *)(&stack0x00000048 + iVar3));
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a977;
            func_0x000180222910(*(undefined8 *)0x180782b60);
            pcVar1 = *(code **)(in_RCX + 0x78);
            if (pcVar1 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a985;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a99d;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            } else {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a9b2;
                iVar4 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
                if (iVar4 != 0) {
                    return iVar4;
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a9bc;
                fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a9d4;
                fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)((int64_t)&arg_28h + iVar3), 
                              *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000048 + iVar3));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026a9e6;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18026aa00
// Address: 0x18026aa00
// Size: 341 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8
fcn.18026aa00(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_68h,
             int64_t arg_70h, int64_t arg_78h, int64_t arg_80h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026aa1a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aa33;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aa4b;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)((int64_t)&arg_48h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aa5d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aa70;
        iVar2 = func_0x000180222950(*(undefined8 *)0x180782b60);
        if (iVar2 != 0) {
            if (*(int32_t *)(in_RCX + 0xa0) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aa89;
                func_0x000180222910(*(undefined8 *)0x180782b60);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aa8e;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aaa6;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aab8;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aac4;
            func_0x000180222910(*(undefined8 *)0x180782b60);
            pcVar1 = *(code **)(in_RCX + 0x88);
            if (pcVar1 == (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aad5;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aaed;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar3), *(int64_t *)((int64_t)&var_20h + iVar3), 
                              *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)((int64_t)&arg_48h + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026aaff;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0;
            }
            *(undefined8 *)((int64_t)&arg_30h + iVar3) = *(undefined8 *)((int64_t)&arg_80h + iVar3);
            *(undefined8 *)((int64_t)&arg_28h + iVar3) = *(undefined8 *)((int64_t)&arg_78h + iVar3);
            *(undefined8 *)((int64_t)&var_20h + iVar3) = *(undefined8 *)((int64_t)&arg_70h + iVar3);
            *(undefined8 *)((int64_t)&var_18h + iVar3) = *(undefined8 *)((int64_t)&arg_68h + iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026ab40;
            uVar4 = (*pcVar1)(in_RCX, in_RDX, in_R8, in_R9);
            return uVar4;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026ab80
// Address: 0x18026ab80
// Size: 103 bytes
// ============================================================
undefined8 fcn.18026ab80(int64_t arg_30h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026ab8a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar1 = *(code **)(in_RCX + 0x38);
    if (pcVar1 != (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026aba3;
        iVar2 = (*pcVar1)();
        if (iVar2 != 0) {
            return *(undefined8 *)((int64_t)&arg_30h + iVar3);
        }
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026abb6;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026abce;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar3), *(int64_t *)(&stack0x00000028 + iVar3), 
                  *(int64_t *)((int64_t)&arg_30h + iVar3), *(int64_t *)(&stack0x00000038 + iVar3), 
                  *(int64_t *)(&stack0x00000050 + iVar3));
    *(undefined8 *)((int64_t)&uStack_8 + iVar3) = 0x18026abe0;
    fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar3));
    return 0;
}

// ============================================================
// Function: FUN_18026abf0
// Address: 0x18026abf0
// Size: 44 bytes
// ============================================================
int64_t fcn.18026abf0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_70h, int64_t arg_78h,
                     int64_t arg_90h)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t in_RCX;
    int64_t *piVar9;
    undefined4 uVar10;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    uVar10 = (undefined4)in_RCX;
    piVar9 = (int64_t *)0x18077e760;
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5) = 0x1802dff85;
    uVar6 = fcn.18045a350(0x18077e760, in_RCX & 0xffffffff, 0x1804e73d0, 0x45);
    iVar3 = -uVar6;
    iVar8 = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dff98;
    func_0x000180243560(uVar6 & 0xffffffff, 0);
    if (*piVar9 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffad;
    iVar4 = func_0x000180222950(*(undefined8 *)0x180782b60);
    if (iVar4 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffba;
    func_0x000180229b10();
    iVar7 = *piVar9;
    if (iVar7 == 0) goto code_r0x0001802e0077;
    *(undefined4 *)((int64_t)&arg_40h + iVar3 + iVar5) = uVar10;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffd4;
    iVar7 = func_0x000180229240(iVar7, (int64_t)&arg_40h + iVar3 + iVar5);
    if (iVar7 == 0) goto code_r0x0001802e0077;
    if (*(int64_t *)(iVar7 + 0x10) == 0) {
code_r0x0001802dfff8:
        if (*(int32_t *)(iVar7 + 0x18) != 0) goto code_r0x0001802dfff2;
        uVar1 = *(undefined8 *)(iVar7 + 8);
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0008;
        iVar8 = func_0x000180222340(uVar1, 0);
        while (iVar8 != 0) {
            if ((0 < *(int32_t *)(iVar8 + 0xa0)) || ((*(uint8_t *)0x18077ef40 & 1) == 0)) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e002f;
                iVar4 = func_0x00018026b1e0(iVar8);
                if (iVar4 != 0) {
                    if (*(int64_t *)(iVar7 + 0x10) != iVar8) {
                        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0058;
                        iVar4 = func_0x00018026b1e0(iVar8);
                        if (iVar4 != 0) {
                            iVar2 = *(int64_t *)(iVar7 + 0x10);
                            if (iVar2 != 0) {
                                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e006c;
                                func_0x00018026b120(iVar2, 0);
                            }
                            *(int64_t *)(iVar7 + 0x10) = iVar8;
                        }
                    }
                    break;
                }
            }
            uVar1 = *(undefined8 *)(iVar7 + 8);
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e003e;
            iVar8 = func_0x000180222340(uVar1);
        }
    } else {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802dffee;
        iVar4 = func_0x00018026b1e0();
        if (iVar4 == 0) goto code_r0x0001802dfff8;
code_r0x0001802dfff2:
        iVar8 = *(int64_t *)(iVar7 + 0x10);
    }
    *(undefined4 *)(iVar7 + 0x18) = 1;
code_r0x0001802e0077:
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0083;
    func_0x000180222910(*(undefined8 *)0x180782b60);
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar5) = 0x1802e0088;
    func_0x0001802299d0();
    return iVar8;
}

