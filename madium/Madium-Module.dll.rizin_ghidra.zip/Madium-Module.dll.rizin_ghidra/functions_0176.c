// Chunk 176 - 50 functions

// ============================================================
// Function: FUN_1802332b0
// Address: 0x1802332b0
// Size: 283 bytes
// ============================================================
int32_t fcn.1802332b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 in_RCX;
    int32_t in_EDX;
    int64_t in_R8;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802332c6;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_EDX != 3) {
        if (in_EDX != 4) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802332ed;
        uVar4 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023331f;
        iVar5 = func_0x000180251ef0(in_R8, *(undefined8 *)((int64_t)&arg_70h + iVar3), 
                                    *(undefined8 *)((int64_t)&arg_78h + iVar3), 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233333;
        iVar6 = func_0x000180251c80(iVar5);
        iVar2 = 0;
        if (iVar6 != 0) {
            while( true ) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233348;
                iVar1 = func_0x000180203a00(iVar6);
                iVar2 = 0;
                if (iVar1 == 1) break;
                if (iVar1 == 5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233378;
                    uVar7 = func_0x000180251470(iVar6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233383;
                    iVar2 = func_0x00018021f070(uVar4, uVar7);
                } else {
                    iVar2 = 0;
                    if (iVar1 == 6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233363;
                        uVar7 = func_0x000180251480(iVar6);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023336e;
                        iVar2 = func_0x00018021f0d0(uVar4, uVar7);
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023338d;
                func_0x0001802513b0(iVar6);
                if (iVar2 == 0) goto code_r0x0001802333ba;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233399;
                iVar6 = func_0x000180251c80(iVar5);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333a9;
                    func_0x000180251880(iVar5);
                    return iVar2;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333ba;
            func_0x0001802513b0(iVar6);
        }
code_r0x0001802333ba:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333c2;
        func_0x000180251880(iVar5);
        return iVar2;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R15;
    if (in_R8 == 0) {
code_r0x000180233520:
        iVar2 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333de;
        iVar5 = func_0x0001801dd6c0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333f8;
        piVar8 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2080, 0x87);
        if (piVar8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023341e;
            iVar9 = func_0x0001802231e0(in_R8, 0x1804e2080, 0x8e);
            iVar6 = *(int64_t *)((int64_t)&arg_78h + iVar3);
            iVar10 = *(int64_t *)((int64_t)&arg_70h + iVar3);
            *piVar8 = iVar9;
            piVar8[1] = iVar10;
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023344f;
                iVar9 = func_0x0001802231e0(iVar6, 0x1804e2080, 0x91);
                piVar8[2] = iVar9;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023347a;
            iVar10 = func_0x000180251ef0(in_R8, iVar10, iVar6, 0);
            if ((iVar10 != 0) && (((iVar6 == 0 || (piVar8[2] != 0)) && (*piVar8 != 0)))) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023349c;
                func_0x000180251880(iVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334a6;
                    iVar5 = func_0x000180221f20();
                    if (iVar5 == 0) goto code_r0x0001802334c8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334b9;
                    func_0x00018021eb00(in_RCX, iVar5);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334c4;
                iVar2 = func_0x000180222110(iVar5, piVar8);
                if (iVar2 < 1) {
code_r0x0001802334c8:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334d0;
                    func_0x000180233830(piVar8);
                    return 0;
                }
                goto code_r0x000180233520;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334dc;
            func_0x000180251880(iVar10);
            iVar5 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334f1;
            func_0x000180224990(iVar5, 0x1804e2080, 0x73);
            iVar5 = piVar8[2];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233507;
            func_0x000180224990(iVar5, 0x1804e2080, 0x74);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023351c;
            func_0x000180224990(piVar8, 0x1804e2080, 0x75);
        }
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_1802333cb
// Address: 0x1802333cb
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1802332b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 in_RCX;
    int32_t in_EDX;
    int64_t in_R8;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802332c6;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_EDX != 3) {
        if (in_EDX != 4) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802332ed;
        uVar4 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023331f;
        iVar5 = func_0x000180251ef0(in_R8, *(undefined8 *)((int64_t)&arg_70h + iVar3), 
                                    *(undefined8 *)((int64_t)&arg_78h + iVar3), 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233333;
        iVar6 = func_0x000180251c80(iVar5);
        iVar2 = 0;
        if (iVar6 != 0) {
            while( true ) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233348;
                iVar1 = func_0x000180203a00(iVar6);
                iVar2 = 0;
                if (iVar1 == 1) break;
                if (iVar1 == 5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233378;
                    uVar7 = func_0x000180251470(iVar6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233383;
                    iVar2 = func_0x00018021f070(uVar4, uVar7);
                } else {
                    iVar2 = 0;
                    if (iVar1 == 6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233363;
                        uVar7 = func_0x000180251480(iVar6);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023336e;
                        iVar2 = func_0x00018021f0d0(uVar4, uVar7);
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023338d;
                func_0x0001802513b0(iVar6);
                if (iVar2 == 0) goto code_r0x0001802333ba;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233399;
                iVar6 = func_0x000180251c80(iVar5);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333a9;
                    func_0x000180251880(iVar5);
                    return iVar2;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333ba;
            func_0x0001802513b0(iVar6);
        }
code_r0x0001802333ba:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333c2;
        func_0x000180251880(iVar5);
        return iVar2;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R15;
    if (in_R8 == 0) {
code_r0x000180233520:
        iVar2 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333de;
        iVar5 = func_0x0001801dd6c0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333f8;
        piVar8 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2080, 0x87);
        if (piVar8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023341e;
            iVar9 = func_0x0001802231e0(in_R8, 0x1804e2080, 0x8e);
            iVar6 = *(int64_t *)((int64_t)&arg_78h + iVar3);
            iVar10 = *(int64_t *)((int64_t)&arg_70h + iVar3);
            *piVar8 = iVar9;
            piVar8[1] = iVar10;
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023344f;
                iVar9 = func_0x0001802231e0(iVar6, 0x1804e2080, 0x91);
                piVar8[2] = iVar9;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023347a;
            iVar10 = func_0x000180251ef0(in_R8, iVar10, iVar6, 0);
            if ((iVar10 != 0) && (((iVar6 == 0 || (piVar8[2] != 0)) && (*piVar8 != 0)))) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023349c;
                func_0x000180251880(iVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334a6;
                    iVar5 = func_0x000180221f20();
                    if (iVar5 == 0) goto code_r0x0001802334c8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334b9;
                    func_0x00018021eb00(in_RCX, iVar5);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334c4;
                iVar2 = func_0x000180222110(iVar5, piVar8);
                if (iVar2 < 1) {
code_r0x0001802334c8:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334d0;
                    func_0x000180233830(piVar8);
                    return 0;
                }
                goto code_r0x000180233520;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334dc;
            func_0x000180251880(iVar10);
            iVar5 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334f1;
            func_0x000180224990(iVar5, 0x1804e2080, 0x73);
            iVar5 = piVar8[2];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233507;
            func_0x000180224990(iVar5, 0x1804e2080, 0x74);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023351c;
            func_0x000180224990(piVar8, 0x1804e2080, 0x75);
        }
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18023340a
// Address: 0x18023340a
// Size: 122 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1802332b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 in_RCX;
    int32_t in_EDX;
    int64_t in_R8;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802332c6;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_EDX != 3) {
        if (in_EDX != 4) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802332ed;
        uVar4 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023331f;
        iVar5 = func_0x000180251ef0(in_R8, *(undefined8 *)((int64_t)&arg_70h + iVar3), 
                                    *(undefined8 *)((int64_t)&arg_78h + iVar3), 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233333;
        iVar6 = func_0x000180251c80(iVar5);
        iVar2 = 0;
        if (iVar6 != 0) {
            while( true ) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233348;
                iVar1 = func_0x000180203a00(iVar6);
                iVar2 = 0;
                if (iVar1 == 1) break;
                if (iVar1 == 5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233378;
                    uVar7 = func_0x000180251470(iVar6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233383;
                    iVar2 = func_0x00018021f070(uVar4, uVar7);
                } else {
                    iVar2 = 0;
                    if (iVar1 == 6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233363;
                        uVar7 = func_0x000180251480(iVar6);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023336e;
                        iVar2 = func_0x00018021f0d0(uVar4, uVar7);
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023338d;
                func_0x0001802513b0(iVar6);
                if (iVar2 == 0) goto code_r0x0001802333ba;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233399;
                iVar6 = func_0x000180251c80(iVar5);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333a9;
                    func_0x000180251880(iVar5);
                    return iVar2;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333ba;
            func_0x0001802513b0(iVar6);
        }
code_r0x0001802333ba:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333c2;
        func_0x000180251880(iVar5);
        return iVar2;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R15;
    if (in_R8 == 0) {
code_r0x000180233520:
        iVar2 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333de;
        iVar5 = func_0x0001801dd6c0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333f8;
        piVar8 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2080, 0x87);
        if (piVar8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023341e;
            iVar9 = func_0x0001802231e0(in_R8, 0x1804e2080, 0x8e);
            iVar6 = *(int64_t *)((int64_t)&arg_78h + iVar3);
            iVar10 = *(int64_t *)((int64_t)&arg_70h + iVar3);
            *piVar8 = iVar9;
            piVar8[1] = iVar10;
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023344f;
                iVar9 = func_0x0001802231e0(iVar6, 0x1804e2080, 0x91);
                piVar8[2] = iVar9;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023347a;
            iVar10 = func_0x000180251ef0(in_R8, iVar10, iVar6, 0);
            if ((iVar10 != 0) && (((iVar6 == 0 || (piVar8[2] != 0)) && (*piVar8 != 0)))) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023349c;
                func_0x000180251880(iVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334a6;
                    iVar5 = func_0x000180221f20();
                    if (iVar5 == 0) goto code_r0x0001802334c8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334b9;
                    func_0x00018021eb00(in_RCX, iVar5);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334c4;
                iVar2 = func_0x000180222110(iVar5, piVar8);
                if (iVar2 < 1) {
code_r0x0001802334c8:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334d0;
                    func_0x000180233830(piVar8);
                    return 0;
                }
                goto code_r0x000180233520;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334dc;
            func_0x000180251880(iVar10);
            iVar5 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334f1;
            func_0x000180224990(iVar5, 0x1804e2080, 0x73);
            iVar5 = piVar8[2];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233507;
            func_0x000180224990(iVar5, 0x1804e2080, 0x74);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023351c;
            func_0x000180224990(piVar8, 0x1804e2080, 0x75);
        }
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180233484
// Address: 0x180233484
// Size: 166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1802332b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 in_RCX;
    int32_t in_EDX;
    int64_t in_R8;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802332c6;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_EDX != 3) {
        if (in_EDX != 4) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802332ed;
        uVar4 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023331f;
        iVar5 = func_0x000180251ef0(in_R8, *(undefined8 *)((int64_t)&arg_70h + iVar3), 
                                    *(undefined8 *)((int64_t)&arg_78h + iVar3), 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233333;
        iVar6 = func_0x000180251c80(iVar5);
        iVar2 = 0;
        if (iVar6 != 0) {
            while( true ) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233348;
                iVar1 = func_0x000180203a00(iVar6);
                iVar2 = 0;
                if (iVar1 == 1) break;
                if (iVar1 == 5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233378;
                    uVar7 = func_0x000180251470(iVar6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233383;
                    iVar2 = func_0x00018021f070(uVar4, uVar7);
                } else {
                    iVar2 = 0;
                    if (iVar1 == 6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233363;
                        uVar7 = func_0x000180251480(iVar6);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023336e;
                        iVar2 = func_0x00018021f0d0(uVar4, uVar7);
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023338d;
                func_0x0001802513b0(iVar6);
                if (iVar2 == 0) goto code_r0x0001802333ba;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233399;
                iVar6 = func_0x000180251c80(iVar5);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333a9;
                    func_0x000180251880(iVar5);
                    return iVar2;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333ba;
            func_0x0001802513b0(iVar6);
        }
code_r0x0001802333ba:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333c2;
        func_0x000180251880(iVar5);
        return iVar2;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R15;
    if (in_R8 == 0) {
code_r0x000180233520:
        iVar2 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333de;
        iVar5 = func_0x0001801dd6c0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333f8;
        piVar8 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2080, 0x87);
        if (piVar8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023341e;
            iVar9 = func_0x0001802231e0(in_R8, 0x1804e2080, 0x8e);
            iVar6 = *(int64_t *)((int64_t)&arg_78h + iVar3);
            iVar10 = *(int64_t *)((int64_t)&arg_70h + iVar3);
            *piVar8 = iVar9;
            piVar8[1] = iVar10;
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023344f;
                iVar9 = func_0x0001802231e0(iVar6, 0x1804e2080, 0x91);
                piVar8[2] = iVar9;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023347a;
            iVar10 = func_0x000180251ef0(in_R8, iVar10, iVar6, 0);
            if ((iVar10 != 0) && (((iVar6 == 0 || (piVar8[2] != 0)) && (*piVar8 != 0)))) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023349c;
                func_0x000180251880(iVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334a6;
                    iVar5 = func_0x000180221f20();
                    if (iVar5 == 0) goto code_r0x0001802334c8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334b9;
                    func_0x00018021eb00(in_RCX, iVar5);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334c4;
                iVar2 = func_0x000180222110(iVar5, piVar8);
                if (iVar2 < 1) {
code_r0x0001802334c8:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334d0;
                    func_0x000180233830(piVar8);
                    return 0;
                }
                goto code_r0x000180233520;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334dc;
            func_0x000180251880(iVar10);
            iVar5 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334f1;
            func_0x000180224990(iVar5, 0x1804e2080, 0x73);
            iVar5 = piVar8[2];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233507;
            func_0x000180224990(iVar5, 0x1804e2080, 0x74);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023351c;
            func_0x000180224990(piVar8, 0x1804e2080, 0x75);
        }
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_18023352a
// Address: 0x18023352a
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int32_t fcn.1802332b0(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 in_RCX;
    int32_t in_EDX;
    int64_t in_R8;
    undefined8 unaff_R13;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802332c6;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_EDX != 3) {
        if (in_EDX != 4) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802332ed;
        uVar4 = func_0x00018021eaf0();
        *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
        *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
        *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023331f;
        iVar5 = func_0x000180251ef0(in_R8, *(undefined8 *)((int64_t)&arg_70h + iVar3), 
                                    *(undefined8 *)((int64_t)&arg_78h + iVar3), 0);
        if (iVar5 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233333;
        iVar6 = func_0x000180251c80(iVar5);
        iVar2 = 0;
        if (iVar6 != 0) {
            while( true ) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233348;
                iVar1 = func_0x000180203a00(iVar6);
                iVar2 = 0;
                if (iVar1 == 1) break;
                if (iVar1 == 5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233378;
                    uVar7 = func_0x000180251470(iVar6);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233383;
                    iVar2 = func_0x00018021f070(uVar4, uVar7);
                } else {
                    iVar2 = 0;
                    if (iVar1 == 6) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233363;
                        uVar7 = func_0x000180251480(iVar6);
                        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023336e;
                        iVar2 = func_0x00018021f0d0(uVar4, uVar7);
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023338d;
                func_0x0001802513b0(iVar6);
                if (iVar2 == 0) goto code_r0x0001802333ba;
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233399;
                iVar6 = func_0x000180251c80(iVar5);
                if (iVar6 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333a9;
                    func_0x000180251880(iVar5);
                    return iVar2;
                }
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333ba;
            func_0x0001802513b0(iVar6);
        }
code_r0x0001802333ba:
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333c2;
        func_0x000180251880(iVar5);
        return iVar2;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar3) = unaff_R15;
    if (in_R8 == 0) {
code_r0x000180233520:
        iVar2 = 1;
    } else {
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333de;
        iVar5 = func_0x0001801dd6c0();
        *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802333f8;
        piVar8 = (int64_t *)func_0x000180224d60(0x18, 0x1804e2080, 0x87);
        if (piVar8 != (int64_t *)0x0) {
            *(undefined8 *)((int64_t)&arg_48h + iVar3) = unaff_R13;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023341e;
            iVar9 = func_0x0001802231e0(in_R8, 0x1804e2080, 0x8e);
            iVar6 = *(int64_t *)((int64_t)&arg_78h + iVar3);
            iVar10 = *(int64_t *)((int64_t)&arg_70h + iVar3);
            *piVar8 = iVar9;
            piVar8[1] = iVar10;
            if (iVar6 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023344f;
                iVar9 = func_0x0001802231e0(iVar6, 0x1804e2080, 0x91);
                piVar8[2] = iVar9;
            }
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0;
            *(undefined8 *)((int64_t)&var_8h + iVar3) = 0;
            *(undefined8 *)(&stack0x00000000 + iVar3) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023347a;
            iVar10 = func_0x000180251ef0(in_R8, iVar10, iVar6, 0);
            if ((iVar10 != 0) && (((iVar6 == 0 || (piVar8[2] != 0)) && (*piVar8 != 0)))) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023349c;
                func_0x000180251880(iVar10);
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334a6;
                    iVar5 = func_0x000180221f20();
                    if (iVar5 == 0) goto code_r0x0001802334c8;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334b9;
                    func_0x00018021eb00(in_RCX, iVar5);
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334c4;
                iVar2 = func_0x000180222110(iVar5, piVar8);
                if (iVar2 < 1) {
code_r0x0001802334c8:
                    *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334d0;
                    func_0x000180233830(piVar8);
                    return 0;
                }
                goto code_r0x000180233520;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334dc;
            func_0x000180251880(iVar10);
            iVar5 = *piVar8;
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x1802334f1;
            func_0x000180224990(iVar5, 0x1804e2080, 0x73);
            iVar5 = piVar8[2];
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x180233507;
            func_0x000180224990(iVar5, 0x1804e2080, 0x74);
            *(undefined8 *)((int64_t)&uStack_30 + iVar3) = 0x18023351c;
            func_0x000180224990(piVar8, 0x1804e2080, 0x75);
        }
        iVar2 = 0;
    }
    return iVar2;
}

// ============================================================
// Function: FUN_180233540
// Address: 0x180233540
// Size: 45 bytes
// ============================================================
void fcn.180233540(int64_t arg_28h, int64_t arg_30h, int64_t arg_70h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023354a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = *(undefined8 *)((int64_t)&arg_70h + iVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180233568;
    fcn.1802332b0(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1), 
                  *(int64_t *)((int64_t)&arg_70h + iVar1));
    return;
}

// ============================================================
// Function: FUN_180233570
// Address: 0x180233570
// Size: 318 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

uint64_t fcn.180233570(undefined8 placeholder_0, uint64_t placeholder_1, int64_t arg3, int64_t arg4, int64_t arg_28h,
                      undefined8 placeholder_5, int64_t arg_38h, int64_t arg_40h)
{
    int32_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_40;
    
    uStack_40 = 0x180233594;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802335a4;
    uVar4 = func_0x000180251800(arg3);
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802335af;
    uVar5 = func_0x0001801dd6c0(placeholder_0);
    uVar8 = 0;
    iVar2 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802335c1;
    iVar1 = func_0x000180222010(uVar5);
    uVar7 = uVar8;
    if (0 < iVar1) {
        do {
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802335cf;
            uVar6 = func_0x000180222340(uVar5, uVar7);
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802335e3;
            iVar2 = func_0x0001802336c0(placeholder_0, uVar6, uVar4, 1);
            if (iVar2 != 0) break;
            uVar9 = (int32_t)uVar7 + 1;
            uVar7 = (uint64_t)uVar9;
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x1802335f4;
            iVar1 = func_0x000180222010(uVar5);
        } while ((int32_t)uVar9 < iVar1);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233600;
    uVar5 = func_0x00018021eaf0(placeholder_0);
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233608;
    uVar5 = func_0x0001801bc820(uVar5);
    *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233616;
    func_0x000180251850(uVar4);
    uVar7 = uVar8;
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233623;
        uVar4 = func_0x00018021eaf0(placeholder_0);
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18023362e;
        uVar7 = func_0x00018021f7d0(uVar4);
        if ((int32_t)uVar7 == 0) {
            return uVar7;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233641;
        uVar7 = func_0x00018021ebb0(uVar5, placeholder_1 & 0xffffffff, *(undefined8 *)((int64_t)&arg_38h + iVar3));
        *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x18023364c;
        func_0x00018021f590(uVar4);
    }
    if (uVar7 != 0) {
        if ((int32_t)placeholder_1 == 1) {
            uVar4 = *(undefined8 *)(uVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233688;
            uVar9 = func_0x00018021ebf0(*(undefined8 *)((int64_t)&arg_40h + iVar3), uVar4);
            uVar8 = (uint64_t)uVar9;
            if (uVar9 != 0) {
                uVar4 = *(undefined8 *)(uVar7 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233697;
                func_0x00018021fe80(uVar4);
            }
        } else if ((int32_t)placeholder_1 == 2) {
            uVar4 = *(undefined8 *)(uVar7 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233669;
            uVar9 = func_0x00018021ec80(*(undefined8 *)((int64_t)&arg_40h + iVar3), uVar4);
            uVar8 = (uint64_t)uVar9;
            if (uVar9 != 0) {
                uVar4 = *(undefined8 *)(uVar7 + 8);
                *(undefined8 *)((int64_t)&uStack_40 + iVar3) = 0x180233678;
                func_0x00018028eb90(uVar4);
            }
        }
    }
    return uVar8;
}

// ============================================================
// Function: FUN_1802336c0
// Address: 0x1802336c0
// Size: 356 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

uint64_t fcn.1802336c0(int64_t arg_28h, int64_t arg_38h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    undefined8 *in_RDX;
    int64_t in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1802336e2;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802336fa;
    uVar6 = func_0x00018021eaf0();
    uVar9 = in_RDX[2];
    uVar1 = in_RDX[1];
    uVar2 = *in_RDX;
    *(undefined8 *)((int64_t)&var_10h + iVar5) = 0;
    *(undefined8 *)((int64_t)&var_8h + iVar5) = 0;
    *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
    *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180233724;
    uVar7 = func_0x000180251ef0(uVar2, uVar1, uVar9, 0);
    uVar10 = uVar7;
    if (uVar7 != 0) {
        if (in_R8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023373a;
            func_0x000180229b10();
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180233745;
            func_0x000180251980(uVar7, in_R8);
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023374a;
            func_0x0001802299d0();
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180233752;
        iVar8 = func_0x000180251c80(uVar7);
        uVar10 = 0;
        while (iVar8 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180233768;
            iVar3 = func_0x000180203a00(iVar8);
            uVar10 = 0;
            if (iVar3 == 1) {
                if (0 < in_R9D) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18023377b;
                    uVar9 = func_0x000180251490(iVar8);
                    *(undefined8 *)((int64_t)&var_18h + iVar5) = uVar9;
                    *(undefined8 *)((int64_t)&var_20h + iVar5) = in_RDX[1];
                    *(undefined8 *)((int64_t)&arg_28h + iVar5) = in_RDX[2];
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337a6;
                    uVar4 = fcn.1802336c0(*(int64_t *)(&stack0xfffffffffffffff8 + iVar5), 
                                          *(int64_t *)((int64_t)&var_8h + iVar5));
                    goto code_r0x0001802337da;
                }
            } else {
                if (iVar3 == 5) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337cf;
                    uVar9 = func_0x000180251470(iVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337da;
                    uVar4 = func_0x00018021f070(uVar6, uVar9);
                } else {
                    if (iVar3 != 6) goto code_r0x0001802337dc;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337ba;
                    uVar9 = func_0x000180251480(iVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337c5;
                    uVar4 = func_0x00018021f0d0(uVar6, uVar9);
                }
code_r0x0001802337da:
                uVar10 = (uint64_t)uVar4;
            }
code_r0x0001802337dc:
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337e4;
            func_0x0001802513b0(iVar8);
            if ((int32_t)uVar10 == 0) break;
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802337f0;
            iVar8 = func_0x000180251c80(uVar7);
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180233804;
        func_0x000180251880(uVar7);
    }
    return uVar10;
}

// ============================================================
// Function: FUN_180233830
// Address: 0x180233830
// Size: 92 bytes
// ============================================================
void fcn.180233830(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180233840;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        uVar1 = *(undefined8 *)arg1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023385b;
        fcn.180224990(uVar1, 0x1804e2080, 0x73);
        uVar1 = *(undefined8 *)(arg1 + 0x10);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233871;
        fcn.180224990(uVar1, 0x1804e2080, 0x74);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233886;
        fcn.180224990(arg1, 0x1804e2080, 0x75);
    }
    return;
}

// ============================================================
// Function: FUN_180233890
// Address: 0x180233890
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180233890(int64_t arg_28h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802338a0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802338b3;
        fcn.180232b70();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802338be;
        iVar3 = fcn.18021f130(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = 0;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802338f2;
            iVar1 = fcn.18021eaa0(iVar3, 1, in_RDX);
            if (0 < iVar1) {
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180233920
// Address: 0x180233920
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180233920(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18023393a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233953;
        fcn.180232b70();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023395e;
        iVar3 = fcn.18021f130(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_R9;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = in_R8;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233988;
            iVar1 = fcn.18021eaa0(iVar3, 1, in_RDX);
            return 0 < iVar1;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_1802339b0
// Address: 0x1802339b0
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

bool fcn.1802339b0(int64_t arg_38h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802339c0;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802339d3;
        fcn.180232660();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802339de;
        iVar3 = fcn.18021f130(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&iStackX_20 + iVar2 + -8) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233a00;
            iVar1 = fcn.18021ea30(*(int64_t *)((int64_t)&iStackX_20 + iVar2 + -8), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000060 + iVar2));
            return 0 < iVar1;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180233a20
// Address: 0x180233a20
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180233a20(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180233a3a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233a53;
        func_0x0001802336b0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233a5e;
        iVar3 = fcn.18021f130(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                              *(int64_t *)((int64_t)&arg_28h + iVar2));
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_R9;
            *(undefined8 *)((int64_t)&var_20h + iVar2) = in_R8;
            *(undefined8 *)((int64_t)&var_18h + iVar2) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233a87;
            iVar1 = fcn.18021eaa0(iVar3, 3, in_RDX, 0);
            return iVar1 != 0;
        }
    }
    return false;
}

// ============================================================
// Function: FUN_180233ab0
// Address: 0x180233ab0
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180233ab0(int64_t arg_28h, int64_t arg_48h, int64_t arg_50h, int64_t arg_78h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180233ac5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233ad6;
    fcn.180232b70();
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233ae1;
    iVar2 = fcn.18021f130(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)((int64_t)&arg_28h + iVar1));
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R8;
        *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RDX;
        *(undefined8 *)((int64_t)&var_18h + iVar1) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b13;
        fcn.18021eaa0(iVar2, 1, 0, 3);
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b18;
        fcn.180232660();
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b23;
        iVar2 = fcn.18021f130(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1));
        if (iVar2 != 0) {
            *(undefined8 *)((int64_t)&var_18h + iVar1) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b47;
            fcn.18021ea30(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                          *(int64_t *)(&stack0x00000060 + iVar1));
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b4c;
            fcn.1802336b0();
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b57;
            iVar2 = fcn.18021f130(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar1));
            if (iVar2 != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R8;
                *(undefined8 *)((int64_t)&var_20h + iVar1) = in_RDX;
                *(undefined8 *)((int64_t)&var_18h + iVar1) = 0;
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b82;
                fcn.18021eaa0(iVar2, 3, 0, 0);
                *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180233b87;
                fcn.1802203d0(*(int64_t *)((int64_t)&var_18h + iVar1), *(int64_t *)((int64_t)&var_20h + iVar1), 
                              *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)(&stack0x00000030 + iVar1), 
                              *(int64_t *)((int64_t)&arg_48h + iVar1));
                return 1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180233bc0
// Address: 0x180233bc0
// Size: 151 bytes
// ============================================================
void fcn.180233bc0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180233bd4;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233bea;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233bfa;
        fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        uVar1 = *(undefined8 *)(arg1 + 0x40);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233c10;
        fcn.180224990(uVar1, 0x1804e2338, 0x66);
        uVar1 = *(undefined8 *)(arg1 + 0x48);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233c26;
        fcn.180224990(uVar1, 0x1804e2338, 0x67);
        uVar1 = *(undefined8 *)(arg1 + 0x58);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233c3c;
        fcn.180224990(uVar1, 0x1804e2338, 0x68);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180233c51;
        fcn.180224990(arg1, 0x1804e2338, 0x69);
    }
    return;
}

// ============================================================
// Function: FUN_180233c60
// Address: 0x180233c60
// Size: 762 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

bool fcn.180233c60(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    undefined8 uVar1;
    uint32_t uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t in_RCX;
    uint32_t *puVar10;
    uint32_t uVar11;
    int64_t in_RDX;
    uint32_t uVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180233c82;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RDX == 0) {
        return true;
    }
    uVar13 = 0;
    uVar11 = *(uint32_t *)(in_RDX + 0x10) | *(uint32_t *)(in_RCX + 0x10);
    if ((uVar11 & 0x10) != 0) {
        *(undefined4 *)(in_RCX + 0x10) = 0;
    }
    if ((uVar11 & 8) != 0) {
        return true;
    }
    uVar12 = uVar11 & 1;
    uVar14 = uVar11 & 2;
    if ((((((((((uVar14 != 0) ||
               ((*(int32_t *)(in_RDX + 0x18) != 0 && ((uVar12 != 0 || (*(int32_t *)(in_RCX + 0x18) == 0)))))) &&
              (*(undefined4 *)(in_RCX + 0x18) = *(undefined4 *)(in_RDX + 0x18), uVar14 != 0)) ||
             ((*(int32_t *)(in_RDX + 0x1c) != 0 && ((uVar12 != 0 || (*(int32_t *)(in_RCX + 0x1c) == 0)))))) &&
            (*(undefined4 *)(in_RCX + 0x1c) = *(undefined4 *)(in_RDX + 0x1c), uVar14 != 0)) ||
           ((*(int32_t *)(in_RDX + 0x20) != -1 && ((uVar12 != 0 || (*(int32_t *)(in_RCX + 0x20) == -1)))))) &&
          (*(undefined4 *)(in_RCX + 0x20) = *(undefined4 *)(in_RDX + 0x20), uVar14 != 0)) ||
         ((*(int32_t *)(in_RDX + 0x24) != -1 && ((uVar12 != 0 || (*(int32_t *)(in_RCX + 0x24) == -1)))))) &&
        (*(undefined4 *)(in_RCX + 0x24) = *(undefined4 *)(in_RDX + 0x24), uVar14 != 0)) ||
       (uVar2 = *(uint32_t *)(in_RCX + 0x14), (uVar2 & 2) == 0)) {
        puVar10 = (uint32_t *)(in_RCX + 0x14);
        uVar6 = *(undefined8 *)(in_RDX + 8);
        *puVar10 = *puVar10 & 0xfffffffd;
        *(undefined8 *)(in_RCX + 8) = uVar6;
        uVar2 = *puVar10;
    }
    if ((uVar11 & 4) != 0) {
        *(uint32_t *)(in_RCX + 0x14) = 0;
        uVar2 = 0;
    }
    *(uint32_t *)(in_RCX + 0x14) = uVar2 | *(uint32_t *)(in_RDX + 0x14);
    if ((uVar14 == 0) && ((*(int64_t *)(in_RDX + 0x28) == 0 || ((uVar12 == 0 && (*(int64_t *)(in_RCX + 0x28) != 0))))))
    {
code_r0x000180233e00:
        if ((*(int32_t *)(in_RDX + 0x38) != 0) && ((uVar12 != 0 || (*(int32_t *)(in_RCX + 0x38) == 0))))
        goto code_r0x000180233e10;
code_r0x000180233e1b:
        if ((*(int64_t *)(in_RDX + 0x30) != 0) && ((uVar12 != 0 || (*(int64_t *)(in_RCX + 0x30) == 0))))
        goto code_r0x000180233e2b;
code_r0x000180233e69:
        if ((*(int64_t *)(in_RDX + 0x48) != 0) && ((uVar12 != 0 || (*(int64_t *)(in_RCX + 0x48) == 0))))
        goto code_r0x000180233e81;
    } else {
        iVar7 = *(int64_t *)(in_RDX + 0x28);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233d88;
        fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        if (iVar7 == 0) {
            *(undefined8 *)(in_RCX + 0x28) = 0;
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233d98;
            iVar5 = func_0x000180221f20();
            *(int64_t *)(in_RCX + 0x28) = iVar5;
            if (iVar5 == 0) {
                return false;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233db0;
            iVar3 = func_0x000180222010(iVar7);
            uVar8 = uVar13;
            if (0 < iVar3) {
                do {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233dbe;
                    uVar6 = func_0x000180222340(iVar7, uVar8);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233dc6;
                    iVar5 = func_0x0001802983b0(uVar6);
                    if (iVar5 == 0) {
                        return false;
                    }
                    uVar6 = *(undefined8 *)(in_RCX + 0x28);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233dde;
                    iVar3 = func_0x000180222110(uVar6, iVar5);
                    if (iVar3 == 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233ed8;
                        func_0x00018027c100(iVar5);
                        return false;
                    }
                    uVar11 = (int32_t)uVar8 + 1;
                    uVar8 = (uint64_t)uVar11;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233df0;
                    iVar3 = func_0x000180222010(iVar7);
                } while ((int32_t)uVar11 < iVar3);
            }
            *(uint32_t *)(in_RCX + 0x14) = *(uint32_t *)(in_RCX + 0x14) | 0x80;
        }
        if (uVar14 == 0) goto code_r0x000180233e00;
code_r0x000180233e10:
        *(undefined4 *)(in_RCX + 0x38) = *(undefined4 *)(in_RDX + 0x38);
        if (uVar14 == 0) goto code_r0x000180233e1b;
code_r0x000180233e2b:
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233e3b;
        fcn.180222050(*(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                      *(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4));
        *(undefined8 *)(in_RCX + 0x30) = 0;
        iVar7 = *(int64_t *)(in_RDX + 0x30);
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233e5b;
            iVar7 = func_0x000180221730(iVar7, 0x180234290, 0x1802342c0);
            *(int64_t *)(in_RCX + 0x30) = iVar7;
            if (iVar7 == 0) {
                return false;
            }
        }
        if (uVar14 == 0) goto code_r0x000180233e69;
code_r0x000180233e81:
        iVar7 = *(int64_t *)(in_RDX + 0x48);
        uVar8 = *(uint64_t *)(in_RDX + 0x50);
        uVar9 = uVar13;
        if (iVar7 != 0) {
            if (uVar8 == 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233e9b;
                uVar8 = func_0x000180498cd0(iVar7);
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233eb4;
            uVar9 = func_0x0001802248d0(uVar8 + 1, 0x1804e2338, 0xf5);
            if (uVar9 == 0) {
                return false;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233eca;
            func_0x000180498030(uVar9, iVar7, uVar8);
            *(undefined *)(uVar9 + uVar8) = 0;
            uVar13 = uVar8;
        }
        uVar6 = *(undefined8 *)(in_RCX + 0x48);
        *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233ef8;
        fcn.180224990(uVar6, 0x1804e2338, 0xfe);
        *(uint64_t *)(in_RCX + 0x48) = uVar9;
        if ((uint64_t *)(in_RCX + 0x50) != (uint64_t *)0x0) {
            *(uint64_t *)(in_RCX + 0x50) = uVar13;
        }
        if (uVar14 != 0) goto code_r0x000180233f1d;
    }
    if ((*(int64_t *)(in_RDX + 0x58) == 0) || ((uVar12 == 0 && (*(int64_t *)(in_RCX + 0x58) != 0)))) {
        return true;
    }
code_r0x000180233f1d:
    uVar6 = *(undefined8 *)(in_RDX + 0x60);
    uVar1 = *(undefined8 *)(in_RDX + 0x58);
    *(undefined8 *)((int64_t)&uStack_30 + iVar4) = 0x180233f2d;
    iVar3 = func_0x000180234120(in_RCX, uVar1, uVar6);
    return iVar3 != 0;
}

// ============================================================
// Function: FUN_180233f60
// Address: 0x180233f60
// Size: 127 bytes
// ============================================================
void fcn.180233f60(int64_t arg_30h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180233f6a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = in_RCX;
    if (*(int64_t *)0x18077e4b8 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180233f83;
        fcn.1802222d0();
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180233f94;
        iVar1 = fcn.180221a50(*(int64_t *)((int64_t)&arg_30h + iVar2), *(int64_t *)(&stack0x00000038 + iVar2));
        if (-1 < iVar1) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180233fa6;
            fcn.180222340(*(int64_t *)0x18077e4b8, iVar1);
            return;
        }
    }
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x1802342f0;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180233fd7;
    fcn.18022c840(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2));
    return;
}

// ============================================================
// Function: FUN_180233fe0
// Address: 0x180233fe0
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180233fe0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180233ff5;
    iVar2 = fcn.18045a350();
    if (in_RDX == 0) {
        iVar3 = 0;
    } else {
        iVar3 = *(int64_t *)(in_RDX + 0x40);
    }
    iVar1 = *(int64_t *)(in_RCX + 0x40);
    if (iVar1 != iVar3) {
        *(undefined8 *)((int64_t)&uStack_10 - iVar2) = 0x180234026;
        fcn.180224990(iVar1, 0x1804e2338, 0x1ad);
        *(int64_t *)(in_RCX + 0x40) = iVar3;
    }
    if (in_RDX != 0) {
        *(undefined8 *)(in_RDX + 0x40) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180234050
// Address: 0x180234050
// Size: 66 bytes
// ============================================================
void fcn.180234050(void)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023405a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 + -iVar1) = 0x180234074;
    iVar1 = fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + -iVar1));
    if (iVar1 == 0) {
        return;
    }
    *(undefined4 *)(iVar1 + 0x1c) = 0;
    *(undefined8 *)(iVar1 + 0x20) = 0xffffffffffffffff;
    return;
}

// ============================================================
// Function: FUN_1802340a0
// Address: 0x1802340a0
// Size: 113 bytes
// ============================================================
undefined8 fcn.1802340a0(int64_t arg_28h)
{
    uint32_t uVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802340ac;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (in_RCX == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802340bc;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802340d4;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802340e6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
    uVar1 = *(uint32_t *)(in_RCX + 0x10);
    *(uint32_t *)(in_RCX + 0x10) = uVar1 | 1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234103;
    uVar3 = fcn.180233c60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar2));
    *(uint32_t *)(in_RCX + 0x10) = uVar1;
    return uVar3;
}

// ============================================================
// Function: FUN_180234120
// Address: 0x180234120
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180234120(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234135;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_R8 & 0xffffffffffffffeb) != 0) || (in_R8 == 0x14)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234217;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023422f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234241;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (in_RDX == 0) {
        in_R8 = 0;
        uVar3 = in_R8;
    } else {
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234178;
            in_R8 = func_0x000180498cd0(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234191;
        uVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        if (uVar3 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341c5;
        func_0x000180498030(uVar3, in_RDX, in_R8);
        *(undefined *)(uVar3 + in_R8) = 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341e5;
    fcn.180224990(uVar1, 0x1804e2338, 0xfe);
    *(uint64_t *)(in_RCX + 0x58) = uVar3;
    if ((uint64_t *)(in_RCX + 0x60) != (uint64_t *)0x0) {
        *(uint64_t *)(in_RCX + 0x60) = in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_180234158
// Address: 0x180234158
// Size: 95 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180234120(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234135;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_R8 & 0xffffffffffffffeb) != 0) || (in_R8 == 0x14)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234217;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023422f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234241;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (in_RDX == 0) {
        in_R8 = 0;
        uVar3 = in_R8;
    } else {
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234178;
            in_R8 = func_0x000180498cd0(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234191;
        uVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        if (uVar3 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341c5;
        func_0x000180498030(uVar3, in_RDX, in_R8);
        *(undefined *)(uVar3 + in_R8) = 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341e5;
    fcn.180224990(uVar1, 0x1804e2338, 0xfe);
    *(uint64_t *)(in_RCX + 0x58) = uVar3;
    if ((uint64_t *)(in_RCX + 0x60) != (uint64_t *)0x0) {
        *(uint64_t *)(in_RCX + 0x60) = in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_1802341b7
// Address: 0x1802341b7
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180234120(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234135;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_R8 & 0xffffffffffffffeb) != 0) || (in_R8 == 0x14)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234217;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023422f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234241;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (in_RDX == 0) {
        in_R8 = 0;
        uVar3 = in_R8;
    } else {
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234178;
            in_R8 = func_0x000180498cd0(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234191;
        uVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        if (uVar3 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341c5;
        func_0x000180498030(uVar3, in_RDX, in_R8);
        *(undefined *)(uVar3 + in_R8) = 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341e5;
    fcn.180224990(uVar1, 0x1804e2338, 0xfe);
    *(uint64_t *)(in_RCX + 0x58) = uVar3;
    if ((uint64_t *)(in_RCX + 0x60) != (uint64_t *)0x0) {
        *(uint64_t *)(in_RCX + 0x60) = in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_180234212
// Address: 0x180234212
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.180234120(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    undefined8 uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234135;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_R8 & 0xffffffffffffffeb) != 0) || (in_R8 == 0x14)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234217;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18023422f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2), 
                      *(int64_t *)((int64_t)&arg_28h + iVar2), *(int64_t *)((int64_t)&arg_30h + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234241;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
    if (in_RDX == 0) {
        in_R8 = 0;
        uVar3 = in_R8;
    } else {
        if (in_R8 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234178;
            in_R8 = func_0x000180498cd0(in_RDX);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180234191;
        uVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar2), *(int64_t *)((int64_t)&var_20h + iVar2));
        if (uVar3 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341c5;
        func_0x000180498030(uVar3, in_RDX, in_R8);
        *(undefined *)(uVar3 + in_R8) = 0;
    }
    uVar1 = *(undefined8 *)(in_RCX + 0x58);
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802341e5;
    fcn.180224990(uVar1, 0x1804e2338, 0xfe);
    *(uint64_t *)(in_RCX + 0x58) = uVar3;
    if ((uint64_t *)(in_RCX + 0x60) != (uint64_t *)0x0) {
        *(uint64_t *)(in_RCX + 0x60) = in_R8;
    }
    return 1;
}

// ============================================================
// Function: FUN_180234290
// Address: 0x180234290
// Size: 35 bytes
// ============================================================
int64_t fcn.180234290(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = 0x1802231f5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_50h + iVar1 + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar4) = 0x180223222;
    iVar2 = fcn.180498cd0();
    *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar4) = 0x180223234;
    iVar3 = fcn.1802248d0(*(int64_t *)((int64_t)&arg_40h + iVar1 + iVar4), 
                          *(int64_t *)(&stack0x00000048 + iVar1 + iVar4));
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar1 + iVar4) = 0x18022324a;
        fcn.180498030(iVar3, in_RCX, iVar2 + 1);
    }
    return iVar3;
}

// ============================================================
// Function: FUN_1802342c0
// Address: 0x1802342c0
// Size: 35 bytes
// ============================================================
void fcn.1802342c0(int64_t param_1)
{
    int32_t iVar1;
    undefined4 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18022499a;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (*(code **)0x1806a0030 == fcn.180224990) {
        if (param_1 != 0) {
            *(undefined8 *)(&stack0x00000048 + iVar3 + iVar4) = unaff_RBX;
            *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca3c;
            iVar1 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, param_1);
            if (iVar1 == 0) {
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca46;
                uVar2 = (*(code *)0x699ff6)();
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca4d;
                uVar2 = fcn.18046b63c(uVar2);
                *(undefined8 *)((int64_t)&uStackX_20 + iVar3 + iVar4) = 0x18047ca54;
                puVar5 = (undefined4 *)fcn.18046b77c();
                *puVar5 = uVar2;
            }
        }
        return;
    }
    // WARNING: Could not recover jumptable at 0x0001802249b4. Too many branches
    // WARNING: Treating indirect jump as call
    (**(code **)0x1806a0030)();
    return;
}

// ============================================================
// Function: FUN_1802342f0
// Address: 0x1802342f0
// Size: 28 bytes
// ============================================================
uint64_t fcn.1802342f0(uint64_t **param_1, int64_t *param_2)
{
    uint8_t uVar1;
    uint64_t uVar2;
    uint64_t *puVar3;
    int64_t iVar4;
    
    fcn.18045a350();
    puVar3 = *param_1;
    iVar4 = *param_2 - (int64_t)puVar3;
    while( true ) {
        if (((uint64_t)puVar3 & 7) == 0) {
            while ((((int32_t)iVar4 + (int32_t)puVar3 & 0xfffU) < 0xff9 &&
                   (uVar2 = *puVar3, uVar2 == *(uint64_t *)(iVar4 + (int64_t)puVar3)))) {
                puVar3 = puVar3 + 1;
                if ((~uVar2 & uVar2 + 0xfefefefefefefeff & 0x8080808080808080) != 0) {
                    return 0;
                }
            }
        }
        uVar1 = *(uint8_t *)puVar3;
        if (uVar1 != *(uint8_t *)(iVar4 + (int64_t)puVar3)) break;
        puVar3 = (uint64_t *)((int64_t)puVar3 + 1);
        if (uVar1 == 0) {
            return 0;
        }
    }
    return -(uint64_t)(uVar1 < *(uint8_t *)(iVar4 + (int64_t)puVar3)) | 1;
}

// ============================================================
// Function: FUN_180234320
// Address: 0x180234320
// Size: 135 bytes
// ============================================================
uint64_t fcn.180234320(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar9;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar10;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180234330;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_90h + iVar4);
    *(undefined *)((int64_t)&var_18h + iVar4) = *(undefined *)((int64_t)&arg_88h + iVar4);
    iVar2 = 0x100000;
    if (in_R8D < 0x100001) {
        iVar2 = in_R8D;
    }
    *(undefined4 *)((int64_t)&var_10h + iVar4) = *(undefined4 *)((int64_t)&arg_80h + iVar4);
    *(undefined4 *)((int64_t)&var_8h + iVar4) = *(undefined4 *)((int64_t)&arg_78h + iVar4);
    *(int64_t *)((int64_t)&arg_28h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023439f;
    uVar5 = func_0x000180261940((int64_t)&arg_60h + iVar4, (int64_t)&arg_28h + iVar4, iVar2, 0x1804e2470);
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBX;
    piVar6 = *in_RCX;
    if (piVar6 != (int64_t *)0x0) {
        iVar7 = piVar6[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343bd;
        func_0x000180226310(iVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343cc;
        fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        iVar7 = piVar6[3];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343e2;
        fcn.180224990(iVar7, 0x1804e2570, 0x7e);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343f7;
        fcn.180224990(piVar6, 0x1804e2570, 0x7f);
        *in_RCX = (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234425;
    piVar6 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (piVar6 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234436;
        iVar7 = func_0x000180221f20();
        *piVar6 = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023444f;
            iVar7 = func_0x000180226610();
            piVar6[2] = iVar7;
            if (iVar7 != 0) {
                *(undefined4 *)(piVar6 + 1) = 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344c4;
                iVar7 = func_0x000180226380(iVar7, *(int64_t *)((int64_t)&arg_28h + iVar4) - iVar1);
                if (iVar7 != 0) {
                    uVar8 = *(undefined8 *)(piVar6[2] + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344e5;
                    fcn.180498030(uVar8, iVar1, *(int64_t *)((int64_t)&arg_28h + iVar4) - iVar1);
                    iVar9 = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344f1;
                    iVar2 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_60h + iVar4));
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023450c;
                            uVar8 = fcn.180222340(*(undefined8 *)((int64_t)&arg_60h + iVar4), iVar9);
                            iVar10 = 0;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234519;
                            iVar2 = func_0x000180222010(uVar8);
                            if (0 < iVar2) {
                                do {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023452a;
                                    iVar7 = fcn.180222340(uVar8, iVar10);
                                    *(int32_t *)(iVar7 + 0x10) = iVar9;
                                    iVar1 = *piVar6;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234538;
                                    iVar2 = func_0x000180222110(iVar1, iVar7);
                                    if (iVar2 == 0) goto code_r0x0001802345ab;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234549;
                                    func_0x0001802221b0(uVar8, iVar10, 0);
                                    iVar10 = iVar10 + 1;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234553;
                                    iVar2 = func_0x000180222010(uVar8);
                                } while (iVar10 < iVar2);
                            }
                            iVar9 = iVar9 + 1;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234563;
                            iVar2 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_60h + iVar4));
                        } while (iVar9 < iVar2);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023456f;
                    uVar3 = func_0x000180234c40(piVar6);
                    if (uVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234586;
                        func_0x000180222290(*(undefined8 *)((int64_t)&arg_60h + iVar4), 0x180196ec0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234595;
                        fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000040 + iVar4));
                        *(undefined4 *)(piVar6 + 1) = 0;
                        iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar4);
                        *in_RCX = piVar6;
                        *in_RDX = iVar1;
                        return (uint64_t)uVar3;
                    }
                }
code_r0x0001802345ab:
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345ba;
                func_0x0001802612b0(piVar6, 0x1804e24e8);
                goto code_r0x0001802345ba;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234467;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023447c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023448b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar1 = *piVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234493;
        func_0x000180221d50(iVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344a8;
        fcn.180224990(piVar6, 0x1804e2570, 0x6f);
    }
code_r0x0001802345ba:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345cb;
    func_0x000180222290(*(undefined8 *)((int64_t)&arg_60h + iVar4), 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345da;
    fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345df;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345f7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000038 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234609;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_1802343a7
// Address: 0x1802343a7
// Size: 633 bytes
// ============================================================
uint64_t fcn.180234320(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar9;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar10;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180234330;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_90h + iVar4);
    *(undefined *)((int64_t)&var_18h + iVar4) = *(undefined *)((int64_t)&arg_88h + iVar4);
    iVar2 = 0x100000;
    if (in_R8D < 0x100001) {
        iVar2 = in_R8D;
    }
    *(undefined4 *)((int64_t)&var_10h + iVar4) = *(undefined4 *)((int64_t)&arg_80h + iVar4);
    *(undefined4 *)((int64_t)&var_8h + iVar4) = *(undefined4 *)((int64_t)&arg_78h + iVar4);
    *(int64_t *)((int64_t)&arg_28h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023439f;
    uVar5 = func_0x000180261940((int64_t)&arg_60h + iVar4, (int64_t)&arg_28h + iVar4, iVar2, 0x1804e2470);
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBX;
    piVar6 = *in_RCX;
    if (piVar6 != (int64_t *)0x0) {
        iVar7 = piVar6[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343bd;
        func_0x000180226310(iVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343cc;
        fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        iVar7 = piVar6[3];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343e2;
        fcn.180224990(iVar7, 0x1804e2570, 0x7e);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343f7;
        fcn.180224990(piVar6, 0x1804e2570, 0x7f);
        *in_RCX = (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234425;
    piVar6 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (piVar6 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234436;
        iVar7 = func_0x000180221f20();
        *piVar6 = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023444f;
            iVar7 = func_0x000180226610();
            piVar6[2] = iVar7;
            if (iVar7 != 0) {
                *(undefined4 *)(piVar6 + 1) = 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344c4;
                iVar7 = func_0x000180226380(iVar7, *(int64_t *)((int64_t)&arg_28h + iVar4) - iVar1);
                if (iVar7 != 0) {
                    uVar8 = *(undefined8 *)(piVar6[2] + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344e5;
                    fcn.180498030(uVar8, iVar1, *(int64_t *)((int64_t)&arg_28h + iVar4) - iVar1);
                    iVar9 = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344f1;
                    iVar2 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_60h + iVar4));
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023450c;
                            uVar8 = fcn.180222340(*(undefined8 *)((int64_t)&arg_60h + iVar4), iVar9);
                            iVar10 = 0;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234519;
                            iVar2 = func_0x000180222010(uVar8);
                            if (0 < iVar2) {
                                do {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023452a;
                                    iVar7 = fcn.180222340(uVar8, iVar10);
                                    *(int32_t *)(iVar7 + 0x10) = iVar9;
                                    iVar1 = *piVar6;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234538;
                                    iVar2 = func_0x000180222110(iVar1, iVar7);
                                    if (iVar2 == 0) goto code_r0x0001802345ab;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234549;
                                    func_0x0001802221b0(uVar8, iVar10, 0);
                                    iVar10 = iVar10 + 1;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234553;
                                    iVar2 = func_0x000180222010(uVar8);
                                } while (iVar10 < iVar2);
                            }
                            iVar9 = iVar9 + 1;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234563;
                            iVar2 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_60h + iVar4));
                        } while (iVar9 < iVar2);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023456f;
                    uVar3 = func_0x000180234c40(piVar6);
                    if (uVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234586;
                        func_0x000180222290(*(undefined8 *)((int64_t)&arg_60h + iVar4), 0x180196ec0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234595;
                        fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000040 + iVar4));
                        *(undefined4 *)(piVar6 + 1) = 0;
                        iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar4);
                        *in_RCX = piVar6;
                        *in_RDX = iVar1;
                        return (uint64_t)uVar3;
                    }
                }
code_r0x0001802345ab:
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345ba;
                func_0x0001802612b0(piVar6, 0x1804e24e8);
                goto code_r0x0001802345ba;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234467;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023447c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023448b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar1 = *piVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234493;
        func_0x000180221d50(iVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344a8;
        fcn.180224990(piVar6, 0x1804e2570, 0x6f);
    }
code_r0x0001802345ba:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345cb;
    func_0x000180222290(*(undefined8 *)((int64_t)&arg_60h + iVar4), 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345da;
    fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345df;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345f7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000038 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234609;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180234620
// Address: 0x180234620
// Size: 10 bytes
// ============================================================
uint64_t fcn.180234320(int64_t arg_28h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h,
                      int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_c8h)
{
    int64_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    undefined8 uVar8;
    int64_t **in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RBX;
    int32_t iVar9;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    int32_t iVar10;
    int32_t in_R8D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x180234330;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar1 = *in_RDX;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_90h + iVar4);
    *(undefined *)((int64_t)&var_18h + iVar4) = *(undefined *)((int64_t)&arg_88h + iVar4);
    iVar2 = 0x100000;
    if (in_R8D < 0x100001) {
        iVar2 = in_R8D;
    }
    *(undefined4 *)((int64_t)&var_10h + iVar4) = *(undefined4 *)((int64_t)&arg_80h + iVar4);
    *(undefined4 *)((int64_t)&var_8h + iVar4) = *(undefined4 *)((int64_t)&arg_78h + iVar4);
    *(int64_t *)((int64_t)&arg_28h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023439f;
    uVar5 = func_0x000180261940((int64_t)&arg_60h + iVar4, (int64_t)&arg_28h + iVar4, iVar2, 0x1804e2470);
    if ((int32_t)uVar5 < 1) {
        return uVar5;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar4) = unaff_RBX;
    piVar6 = *in_RCX;
    if (piVar6 != (int64_t *)0x0) {
        iVar7 = piVar6[2];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343bd;
        func_0x000180226310(iVar7);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343cc;
        fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar4));
        iVar7 = piVar6[3];
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343e2;
        fcn.180224990(iVar7, 0x1804e2570, 0x7e);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802343f7;
        fcn.180224990(piVar6, 0x1804e2570, 0x7f);
        *in_RCX = (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_70h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234425;
    piVar6 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&var_8h + iVar4));
    if (piVar6 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234436;
        iVar7 = func_0x000180221f20();
        *piVar6 = iVar7;
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023444f;
            iVar7 = func_0x000180226610();
            piVar6[2] = iVar7;
            if (iVar7 != 0) {
                *(undefined4 *)(piVar6 + 1) = 1;
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344c4;
                iVar7 = func_0x000180226380(iVar7, *(int64_t *)((int64_t)&arg_28h + iVar4) - iVar1);
                if (iVar7 != 0) {
                    uVar8 = *(undefined8 *)(piVar6[2] + 8);
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344e5;
                    fcn.180498030(uVar8, iVar1, *(int64_t *)((int64_t)&arg_28h + iVar4) - iVar1);
                    iVar9 = 0;
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344f1;
                    iVar2 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_60h + iVar4));
                    if (0 < iVar2) {
                        do {
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023450c;
                            uVar8 = fcn.180222340(*(undefined8 *)((int64_t)&arg_60h + iVar4), iVar9);
                            iVar10 = 0;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234519;
                            iVar2 = func_0x000180222010(uVar8);
                            if (0 < iVar2) {
                                do {
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023452a;
                                    iVar7 = fcn.180222340(uVar8, iVar10);
                                    *(int32_t *)(iVar7 + 0x10) = iVar9;
                                    iVar1 = *piVar6;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234538;
                                    iVar2 = func_0x000180222110(iVar1, iVar7);
                                    if (iVar2 == 0) goto code_r0x0001802345ab;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234549;
                                    func_0x0001802221b0(uVar8, iVar10, 0);
                                    iVar10 = iVar10 + 1;
                                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234553;
                                    iVar2 = func_0x000180222010(uVar8);
                                } while (iVar10 < iVar2);
                            }
                            iVar9 = iVar9 + 1;
                            *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234563;
                            iVar2 = func_0x000180222010(*(undefined8 *)((int64_t)&arg_60h + iVar4));
                        } while (iVar9 < iVar2);
                    }
                    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023456f;
                    uVar3 = func_0x000180234c40(piVar6);
                    if (uVar3 != 0) {
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234586;
                        func_0x000180222290(*(undefined8 *)((int64_t)&arg_60h + iVar4), 0x180196ec0);
                        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234595;
                        fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                                      *(int64_t *)(&stack0x00000040 + iVar4));
                        *(undefined4 *)(piVar6 + 1) = 0;
                        iVar1 = *(int64_t *)((int64_t)&arg_28h + iVar4);
                        *in_RCX = piVar6;
                        *in_RDX = iVar1;
                        return (uint64_t)uVar3;
                    }
                }
code_r0x0001802345ab:
                *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345ba;
                func_0x0001802612b0(piVar6, 0x1804e24e8);
                goto code_r0x0001802345ba;
            }
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234467;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023447c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                      *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                      *(int64_t *)(&stack0x00000038 + iVar4));
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x18023448b;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
        iVar1 = *piVar6;
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234493;
        func_0x000180221d50(iVar1);
        *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802344a8;
        fcn.180224990(piVar6, 0x1804e2570, 0x6f);
    }
code_r0x0001802345ba:
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345cb;
    func_0x000180222290(*(undefined8 *)((int64_t)&arg_60h + iVar4), 0x180196ec0);
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345da;
    fcn.180222050(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345df;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x1802345f7;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar4), *(int64_t *)((int64_t)&var_10h + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)((int64_t)&var_20h + iVar4), 
                  *(int64_t *)(&stack0x00000038 + iVar4));
    *(undefined8 *)((int64_t)&uStack_20 + iVar4) = 0x180234609;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar4));
    return 0;
}

// ============================================================
// Function: FUN_180234630
// Address: 0x180234630
// Size: 75 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180234630(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180234640;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *in_RCX;
    if (*(int32_t *)(iVar2 + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234657;
        uVar7 = fcn.180235070(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        if ((int32_t)uVar7 < 0) {
            return uVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234663;
        iVar5 = fcn.180234c40(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6), 
                              *(int64_t *)(&stack0x00000060 + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
        if (iVar5 == 0) {
            return 0xffffffff;
        }
    }
    puVar3 = *(uint32_t **)(iVar2 + 0x10);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    uVar1 = *puVar3;
    if (in_RDX != (int64_t *)0x0) {
        uVar4 = *(undefined8 *)(puVar3 + 2);
        iVar2 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234697;
        fcn.180498030(iVar2, uVar4, (int64_t)(int32_t)uVar1);
        *in_RDX = *in_RDX + (int64_t)(int32_t)uVar1;
    }
    return (uint64_t)uVar1;
}

// ============================================================
// Function: FUN_18023467b
// Address: 0x18023467b
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180234630(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180234640;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *in_RCX;
    if (*(int32_t *)(iVar2 + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234657;
        uVar7 = fcn.180235070(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        if ((int32_t)uVar7 < 0) {
            return uVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234663;
        iVar5 = fcn.180234c40(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6), 
                              *(int64_t *)(&stack0x00000060 + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
        if (iVar5 == 0) {
            return 0xffffffff;
        }
    }
    puVar3 = *(uint32_t **)(iVar2 + 0x10);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    uVar1 = *puVar3;
    if (in_RDX != (int64_t *)0x0) {
        uVar4 = *(undefined8 *)(puVar3 + 2);
        iVar2 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234697;
        fcn.180498030(iVar2, uVar4, (int64_t)(int32_t)uVar1);
        *in_RDX = *in_RDX + (int64_t)(int32_t)uVar1;
    }
    return (uint64_t)uVar1;
}

// ============================================================
// Function: FUN_1802346a1
// Address: 0x1802346a1
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

uint64_t fcn.180234630(int64_t arg_28h, int64_t arg_30h)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint32_t *puVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t *in_RCX;
    int64_t *in_RDX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180234640;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar2 = *in_RCX;
    if (*(int32_t *)(iVar2 + 8) != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234657;
        uVar7 = fcn.180235070(*(int64_t *)((int64_t)&arg_28h + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar6), 
                              *(int64_t *)(&stack0x00000038 + iVar6), *(int64_t *)(&stack0x00000040 + iVar6));
        if ((int32_t)uVar7 < 0) {
            return uVar7;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234663;
        iVar5 = fcn.180234c40(*(int64_t *)((int64_t)aiStackX_18 + iVar6), *(int64_t *)((int64_t)aiStackX_18 + iVar6 + 8)
                              , *(int64_t *)(&stack0x00000050 + iVar6), *(int64_t *)(&stack0x00000058 + iVar6), 
                              *(int64_t *)(&stack0x00000060 + iVar6), *(int64_t *)(&stack0x00000068 + iVar6));
        if (iVar5 == 0) {
            return 0xffffffff;
        }
    }
    puVar3 = *(uint32_t **)(iVar2 + 0x10);
    *(undefined8 *)((int64_t)&arg_28h + iVar6) = unaff_RSI;
    uVar1 = *puVar3;
    if (in_RDX != (int64_t *)0x0) {
        uVar4 = *(undefined8 *)(puVar3 + 2);
        iVar2 = *in_RDX;
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x180234697;
        fcn.180498030(iVar2, uVar4, (int64_t)(int32_t)uVar1);
        *in_RDX = *in_RDX + (int64_t)(int32_t)uVar1;
    }
    return (uint64_t)uVar1;
}

// ============================================================
// Function: FUN_1802346b0
// Address: 0x1802346b0
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802346b0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802346c0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802346dd;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (piVar2 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802346fa;
    iVar3 = fcn.180221f20();
    *piVar2 = iVar3;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234713;
        iVar3 = fcn.180226610();
        piVar2[2] = iVar3;
        if (iVar3 != 0) {
            *(undefined4 *)(piVar2 + 1) = 1;
            *in_RCX = piVar2;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023472b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234740;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023474f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    iVar3 = *piVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234757;
    fcn.180221d50(iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023476c;
    fcn.180224990(piVar2, 0x1804e2570, 0x6f);
    return 0;
}

// ============================================================
// Function: FUN_1802346f0
// Address: 0x1802346f0
// Size: 142 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802346b0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802346c0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802346dd;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (piVar2 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802346fa;
    iVar3 = fcn.180221f20();
    *piVar2 = iVar3;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234713;
        iVar3 = fcn.180226610();
        piVar2[2] = iVar3;
        if (iVar3 != 0) {
            *(undefined4 *)(piVar2 + 1) = 1;
            *in_RCX = piVar2;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023472b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234740;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023474f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    iVar3 = *piVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234757;
    fcn.180221d50(iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023476c;
    fcn.180224990(piVar2, 0x1804e2570, 0x6f);
    return 0;
}

// ============================================================
// Function: FUN_18023477e
// Address: 0x18023477e
// Size: 31 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.1802346b0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    undefined8 unaff_RSI;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1802346c0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802346dd;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (piVar2 == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RSI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1802346fa;
    iVar3 = fcn.180221f20();
    *piVar2 = iVar3;
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234713;
        iVar3 = fcn.180226610();
        piVar2[2] = iVar3;
        if (iVar3 != 0) {
            *(undefined4 *)(piVar2 + 1) = 1;
            *in_RCX = piVar2;
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023472b;
    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234740;
    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8), 
                  *(int64_t *)((int64_t)&arg_28h + iVar1), *(int64_t *)((int64_t)&arg_30h + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar1));
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023474f;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar1));
    iVar3 = *piVar2;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234757;
    fcn.180221d50(iVar3);
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18023476c;
    fcn.180224990(piVar2, 0x1804e2570, 0x6f);
    return 0;
}

// ============================================================
// Function: FUN_1802347a0
// Address: 0x1802347a0
// Size: 19 bytes
// ============================================================
void fcn.1802347a0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802347b0;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        iVar1 = *(int64_t *)arg1;
        if (iVar1 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347cc;
            fcn.180226310(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347db;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar2 = *(undefined8 *)(iVar1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347f1;
            fcn.180224990(uVar2, 0x1804e2570, 0x7e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180234806;
            fcn.180224990(iVar1, 0x1804e2570, 0x7f);
            *(int64_t *)arg1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1802347b3
// Address: 0x1802347b3
// Size: 100 bytes
// ============================================================
void fcn.1802347a0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802347b0;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        iVar1 = *(int64_t *)arg1;
        if (iVar1 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347cc;
            fcn.180226310(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347db;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar2 = *(undefined8 *)(iVar1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347f1;
            fcn.180224990(uVar2, 0x1804e2570, 0x7e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180234806;
            fcn.180224990(iVar1, 0x1804e2570, 0x7f);
            *(int64_t *)arg1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180234817
// Address: 0x180234817
// Size: 1 bytes
// ============================================================
void fcn.1802347a0(int64_t arg1, int64_t arg_28h)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802347b0;
        iVar3 = fcn.18045a350();
        iVar3 = -iVar3;
        *(undefined8 *)((int64_t)&arg_28h + iVar3) = unaff_RDI;
        iVar1 = *(int64_t *)arg1;
        if (iVar1 != 0) {
            uVar2 = *(undefined8 *)(iVar1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347cc;
            fcn.180226310(uVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347db;
            fcn.180222050(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                          *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)(&stack0x00000030 + iVar3), 
                          *(int64_t *)(&stack0x00000050 + iVar3));
            uVar2 = *(undefined8 *)(iVar1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802347f1;
            fcn.180224990(uVar2, 0x1804e2570, 0x7e);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180234806;
            fcn.180224990(iVar1, 0x1804e2570, 0x7f);
            *(int64_t *)arg1 = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180234820
// Address: 0x180234820
// Size: 49 bytes
// ============================================================
undefined4 fcn.180234820(int64_t arg_50h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined4 uVar3;
    undefined8 uStack_8;
    
    uStack_8 = 0x18023482a;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18023483e;
    iVar1 = fcn.1802a7ff0(*(int64_t *)((int64_t)&arg_50h + iVar2), *(int64_t *)(&stack0x00000058 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar2), *(int64_t *)(&stack0x00000068 + iVar2), 
                          *(int64_t *)(&stack0x00000070 + iVar2), *(int64_t *)(&stack0x000000a0 + iVar2));
    uVar3 = 2;
    if (iVar1 < 1) {
        uVar3 = 0;
    }
    return uVar3;
}

// ============================================================
// Function: FUN_180234870
// Address: 0x180234870
// Size: 32 bytes
// ============================================================
undefined8
fcn.180234870(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h, int64_t arg_80h, int64_t arg_88h, int64_t arg_90h, int64_t arg_98h, int64_t arg_e8h,
             int64_t arg_f0h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    char *pcVar6;
    undefined8 unaff_RBX;
    code *pcVar7;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = "\x01";
    *(undefined8 *)((int64_t)&arg_30h + iVar3) = unaff_RBX;
    *(int64_t *)((int64_t)&arg_38h + iVar3) = in_RCX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3) = 0x18028ef45;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    pcVar7 = (code *)0x0;
    *(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3) = 0;
    *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3) = 0;
    if (in_RCX != 0) {
        if ((((*pcVar6 == '\x01') || ((*pcVar6 - 2U & 0xfb) == 0)) && (*(int64_t *)(pcVar6 + 0x18) != 0)) &&
           (pcVar7 = *(code **)(*(int64_t *)(pcVar6 + 0x18) + 0x18), pcVar7 != (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028ef9c;
            iVar2 = (*pcVar7)(0xe, (int64_t)&arg_88h + iVar4 + iVar3, pcVar6, 0);
            if (iVar2 == 0) goto code_r0x00018028f06b;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028efb8;
            iVar2 = (*pcVar7)(0x10, (int64_t)&arg_88h + iVar4 + iVar3, pcVar6, (int64_t)&arg_50h + iVar4 + iVar3);
            if (iVar2 == 0) goto code_r0x00018028f06b;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028efd4;
            iVar2 = (*pcVar7)(0x11, (int64_t)&arg_88h + iVar4 + iVar3, pcVar6, (int64_t)&arg_98h + iVar4 + iVar3);
            if (iVar2 == 0) goto code_r0x00018028f06b;
            in_RCX = *(int64_t *)((int64_t)&arg_88h + iVar4 + iVar3);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028eff1;
        iVar2 = func_0x0001802642c0(in_RCX, (int64_t)&arg_90h + iVar4 + iVar3, pcVar6);
        if ((-1 < iVar2) && (iVar1 = *(int64_t *)((int64_t)&arg_90h + iVar4 + iVar3), iVar1 != 0)) {
            *(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3) = iVar1;
            *(undefined8 *)((int64_t)&arg_48h + iVar4 + iVar3) = *(undefined8 *)((int64_t)&arg_98h + iVar4 + iVar3);
            *(undefined8 *)((int64_t)&arg_40h + iVar4 + iVar3) = *(undefined8 *)((int64_t)&arg_50h + iVar4 + iVar3);
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f032;
            uVar5 = func_0x000180261850(0, (int64_t)&arg_60h + iVar4 + iVar3, iVar2, pcVar6);
            *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3) = uVar5;
            *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f04e;
            fcn.180224990(*(undefined8 *)((int64_t)&arg_90h + iVar4 + iVar3), 0x1804ebd30, 0x54);
            if (pcVar7 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f067;
                iVar2 = (*pcVar7)(0xf, (int64_t)&arg_58h + iVar4 + iVar3, pcVar6, 
                                  *(undefined8 *)((int64_t)&arg_88h + iVar4 + iVar3));
                if (iVar2 == 0) {
code_r0x00018028f06b:
                    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f070;
                    fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f088;
                    fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), 
                                  *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                                  *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0a2;
                    fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
                    return 0;
                }
            }
            return *(undefined8 *)((int64_t)&arg_58h + iVar4 + iVar3);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0c4;
        fcn.180229480(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0dc;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_40h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_48h + iVar4 + iVar3), 
                      *(int64_t *)((int64_t)&arg_50h + iVar4 + iVar3), *(int64_t *)((int64_t)&arg_58h + iVar4 + iVar3), 
                      *(int64_t *)(&stack0x00000070 + iVar4 + iVar3));
        *(undefined8 *)((int64_t)auStackX_18 + iVar4 + iVar3) = 0x18028f0ee;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_60h + iVar4 + iVar3));
    }
    return 0;
}

// ============================================================
// Function: FUN_180234890
// Address: 0x180234890
// Size: 29 bytes
// ============================================================
void fcn.180234890(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802348b0
// Address: 0x1802348b0
// Size: 29 bytes
// ============================================================
undefined8 fcn.1802348b0(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uVar4;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180260b4c;
    iVar3 = fcn.18045a350(0x1804e23d0);
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    if (0 < iVar1) {
        uVar4 = *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_1802348d0
// Address: 0x1802348d0
// Size: 32 bytes
// ============================================================
undefined8 fcn.1802348d0(int64_t param_1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    char *pcVar5;
    undefined8 unaff_RBX;
    code *pcVar6;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    pcVar5 = "\x04";
    *(undefined8 *)(&stack0x00000030 + iVar2) = unaff_RBX;
    *(int64_t *)(&stack0x00000038 + iVar2) = param_1;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x18028ef45;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar6 = (code *)0x0;
    *(undefined8 *)(&stack0x00000090 + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000050 + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000098 + iVar3 + iVar2) = 0;
    if (param_1 != 0) {
        if ((((*pcVar5 == '\x01') || ((*pcVar5 - 2U & 0xfb) == 0)) && (*(int64_t *)(pcVar5 + 0x18) != 0)) &&
           (pcVar6 = *(code **)(*(int64_t *)(pcVar5 + 0x18) + 0x18), pcVar6 != (code *)0x0)) {
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028ef9c;
            iVar1 = (*pcVar6)(0xe, &stack0x00000088 + iVar3 + iVar2, pcVar5, 0);
            if (iVar1 == 0) goto code_r0x00018028f06b;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028efb8;
            iVar1 = (*pcVar6)(0x10, &stack0x00000088 + iVar3 + iVar2, pcVar5, &stack0x00000050 + iVar3 + iVar2);
            if (iVar1 == 0) goto code_r0x00018028f06b;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028efd4;
            iVar1 = (*pcVar6)(0x11, &stack0x00000088 + iVar3 + iVar2, pcVar5, &stack0x00000098 + iVar3 + iVar2);
            if (iVar1 == 0) goto code_r0x00018028f06b;
            param_1 = *(int64_t *)(&stack0x00000088 + iVar3 + iVar2);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028eff1;
        iVar1 = func_0x0001802642c0(param_1, &stack0x00000090 + iVar3 + iVar2, pcVar5);
        if ((-1 < iVar1) && (*(int64_t *)(&stack0x00000090 + iVar3 + iVar2) != 0)) {
            *(int64_t *)(&stack0x00000060 + iVar3 + iVar2) = *(int64_t *)(&stack0x00000090 + iVar3 + iVar2);
            *(undefined8 *)(&stack0x00000048 + iVar3 + iVar2) = *(undefined8 *)(&stack0x00000098 + iVar3 + iVar2);
            *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = *(undefined8 *)(&stack0x00000050 + iVar3 + iVar2);
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f032;
            uVar4 = func_0x000180261850(0, &stack0x00000060 + iVar3 + iVar2, iVar1, pcVar5);
            *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2) = uVar4;
            *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f04e;
            fcn.180224990(*(undefined8 *)(&stack0x00000090 + iVar3 + iVar2), 0x1804ebd30, 0x54);
            if (pcVar6 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f067;
                iVar1 = (*pcVar6)(0xf, &stack0x00000058 + iVar3 + iVar2, pcVar5, 
                                  *(undefined8 *)(&stack0x00000088 + iVar3 + iVar2));
                if (iVar1 == 0) {
code_r0x00018028f06b:
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f070;
                    fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f088;
                    fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                                  *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
                    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f0a2;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
                    return 0;
                }
            }
            return *(undefined8 *)(&stack0x00000058 + iVar3 + iVar2);
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f0c4;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f0dc;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18028f0ee;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    }
    return 0;
}

// ============================================================
// Function: FUN_1802348f0
// Address: 0x1802348f0
// Size: 29 bytes
// ============================================================
void fcn.1802348f0(undefined8 param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)(&stack0x00000030 + iVar1) = param_1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802612bf;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802612cf;
    fcn.1802612e0(*(int64_t *)(&stack0x00000048 + iVar2 + iVar1), *(int64_t *)(&stack0x00000050 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000058 + iVar2 + iVar1), *(int64_t *)(&stack0x00000060 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180234920
// Address: 0x180234920
// Size: 29 bytes
// ============================================================
undefined8 fcn.180234920(void)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 unaff_RBX;
    undefined8 uVar4;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x180260b4c;
    iVar3 = fcn.18045a350(0x1804e24e8);
    iVar3 = -iVar3;
    uVar4 = 0;
    *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2) = 0;
    *(undefined8 *)(&stack0x00000040 + iVar3 + iVar2) = 0;
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x180260b6e;
    iVar1 = fcn.180260bc0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                          , *(int64_t *)(&stack0x00000050 + iVar3 + iVar2), 
                          *(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
    if (0 < iVar1) {
        uVar4 = *(undefined8 *)(&stack0x00000068 + iVar3 + iVar2);
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180234940
// Address: 0x180234940
// Size: 368 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

undefined8
fcn.1802a7ff0(int64_t arg_58h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h, int64_t arg_a8h)
{
    char cVar1;
    int32_t iVar2;
    int64_t iVar3;
    char *pcVar4;
    undefined8 uVar5;
    int64_t iVar6;
    char *pcVar7;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    char *pcVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t in_R9D;
    undefined8 unaff_R14;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802a7ffa;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_R9D != 0) {
        *(int32_t *)((int64_t)&var_20h + iVar6) = in_R9D;
        *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x1802a8025;
        uVar5 = fcn.1802a85c0(*(int64_t *)((int64_t)&var_20h + iVar6), *(int64_t *)(&stack0x00000028 + iVar6), 
                              *(int64_t *)(&stack0x00000030 + iVar6), *(int64_t *)(&stack0x00000080 + iVar6), 
                              *(int64_t *)(&stack0x000000e8 + iVar6), *(int64_t *)(&stack0x000000f0 + iVar6), 
                              *(int64_t *)(&stack0x00000200 + iVar6));
        return uVar5;
    }
    *(undefined8 *)((int64_t)&arg_58h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000030 + iVar6) = unaff_R14;
    *(undefined8 *)(&stack0x00000028 + iVar6) = 0x180234951;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234967;
    pcVar4 = (char *)fcn.1802a8cb0(*(int64_t *)(&stack0x00000090 + iVar3 + iVar6), 
                                   *(int64_t *)(&stack0x000000f8 + iVar3 + iVar6));
    if (pcVar4 == (char *)0x0) {
        return 0;
    }
    if (*pcVar4 == '\0') {
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234995;
        fcn.180224990(pcVar4, 0x1804e2570, 0x200);
        return 1;
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar3 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_68h + iVar3 + iVar6) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_70h + iVar3 + iVar6) = unaff_RDI;
    pcVar7 = pcVar4 + 1;
    pcVar8 = pcVar7;
    for (; *pcVar7 != '/'; pcVar7 = pcVar7 + 1) {
code_r0x0001802349eb:
        if (*pcVar7 == '\0') goto code_r0x0001802349f0;
code_r0x000180234a2e:
    }
    cVar1 = pcVar7[1];
    *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x1802349ce;
    iVar2 = fcn.1802754b0((int32_t)cVar1);
    if (iVar2 == 0) goto code_r0x0001802349eb;
    cVar1 = pcVar7[2];
    if (cVar1 != '=') {
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x1802349e1;
        iVar2 = fcn.1802754b0((int32_t)cVar1);
        if ((iVar2 == 0) || (pcVar7[3] != '=')) goto code_r0x0001802349eb;
    }
code_r0x0001802349f0:
    *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a02;
    iVar2 = fcn.18021b2c0(*(int64_t *)((int64_t)&arg_70h + iVar3 + iVar6));
    if (iVar2 == (int32_t)pcVar7 - (int32_t)pcVar8) {
        pcVar8 = pcVar7 + 1;
        if (*pcVar7 != '\0') {
            *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a24;
            iVar2 = fcn.18021b2c0(*(int64_t *)((int64_t)&arg_70h + iVar3 + iVar6));
            if (iVar2 != 2) goto code_r0x000180234a4f;
            if (*pcVar7 != '\0') goto code_r0x000180234a2e;
        }
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a48;
        fcn.180224990(pcVar4, 0x1804e2570, 0x21a);
        uVar5 = 1;
    } else {
code_r0x000180234a4f:
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a54;
        fcn.180229480(*(int64_t *)(&stack0x00000050 + iVar3 + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar6));
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a6c;
        fcn.1802295a0(*(int64_t *)(&stack0x00000050 + iVar3 + iVar6), *(int64_t *)((int64_t)&arg_58h + iVar3 + iVar6), 
                      *(int64_t *)((int64_t)&arg_60h + iVar3 + iVar6), *(int64_t *)((int64_t)&arg_68h + iVar3 + iVar6), 
                      *(int64_t *)(&stack0x00000080 + iVar3 + iVar6));
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a7e;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_70h + iVar3 + iVar6));
        *(undefined8 *)(&stack0x00000028 + iVar3 + iVar6) = 0x180234a93;
        fcn.180224990(pcVar4, 0x1804e2570, 0x21e);
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180234ab0
// Address: 0x180234ab0
// Size: 47 bytes
// ============================================================
bool fcn.180234ab0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234abc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*in_RCX == in_RDX) {
        return *in_RCX != 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234ae9;
    iVar2 = fcn.18028ef30(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                          *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                          *(int64_t *)(&stack0x00000088 + iVar1), *(int64_t *)(&stack0x000000d8 + iVar1), 
                          *(int64_t *)(&stack0x000000e0 + iVar1));
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234b0b;
    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
    *in_RCX = iVar2;
    return true;
}

// ============================================================
// Function: FUN_180234adf
// Address: 0x180234adf
// Size: 29 bytes
// ============================================================
bool fcn.180234ab0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234abc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*in_RCX == in_RDX) {
        return *in_RCX != 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234ae9;
    iVar2 = fcn.18028ef30(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                          *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                          *(int64_t *)(&stack0x00000088 + iVar1), *(int64_t *)(&stack0x000000d8 + iVar1), 
                          *(int64_t *)(&stack0x000000e0 + iVar1));
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234b0b;
    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
    *in_RCX = iVar2;
    return true;
}

// ============================================================
// Function: FUN_180234afc
// Address: 0x180234afc
// Size: 34 bytes
// ============================================================
bool fcn.180234ab0(int64_t arg_28h, int64_t arg_58h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RDI;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x180234abc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (*in_RCX == in_RDX) {
        return *in_RCX != 0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234ae9;
    iVar2 = fcn.18028ef30(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000070 + iVar1), 
                          *(int64_t *)(&stack0x00000078 + iVar1), *(int64_t *)(&stack0x00000080 + iVar1), 
                          *(int64_t *)(&stack0x00000088 + iVar1), *(int64_t *)(&stack0x000000d8 + iVar1), 
                          *(int64_t *)(&stack0x000000e0 + iVar1));
    if (iVar2 == 0) {
        return false;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x180234b0b;
    fcn.1802612b0(*(int64_t *)((int64_t)&iStackX_20 + iVar1));
    *in_RCX = iVar2;
    return true;
}

