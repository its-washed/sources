// Chunk 185 - 50 functions

// ============================================================
// Function: FUN_180245ff0
// Address: 0x180245ff0
// Size: 232 bytes
// ============================================================
void fcn.180245ff0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
                  int64_t arg_68h)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined8 in_R8;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180245ffc;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000868 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = in_R8;
    *(undefined8 *)((int64_t)&var_20h + iVar2) = in_RDX;
    *(int64_t *)((int64_t)&arg_58h + iVar2) = (int64_t)&arg_68h + iVar2;
    *(undefined8 *)((int64_t)&arg_50h + iVar2) = 0x800;
    *(int64_t *)((int64_t)&var_18h + iVar2) = (int64_t)&arg_48h + iVar2;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18024605d;
    iVar1 = func_0x000180246150((int64_t)&arg_58h + iVar2, (int64_t)&arg_38h + iVar2, (int64_t)&arg_50h + iVar2, 
                                (int64_t)&arg_40h + iVar2);
    if (iVar1 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180246078;
        func_0x000180224990(*(undefined8 *)((int64_t)&arg_38h + iVar2), 0x1804e4250, 0x435);
    } else if (*(int64_t *)((int64_t)&arg_38h + iVar2) == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802460bb;
        func_0x00018021b2c0(in_RCX, (int64_t)&arg_68h + iVar2, *(undefined4 *)((int64_t)&arg_40h + iVar2));
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180246096;
        func_0x00018021b2c0(in_RCX, *(int64_t *)((int64_t)&arg_38h + iVar2), *(undefined4 *)((int64_t)&arg_40h + iVar2))
        ;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802460af;
        func_0x000180224990(*(undefined8 *)((int64_t)&arg_38h + iVar2), 0x1804e4250, 0x43a);
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1802460cf;
    func_0x000180459870(*(uint64_t *)(&stack0x00000868 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_1802460e0
// Address: 0x1802460e0
// Size: 111 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

uint64_t fcn.1802460e0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h,
                      int64_t arg_30h, undefined8 placeholder_6, int64_t arg_40h, int64_t arg_48h,
                      undefined8 placeholder_9, undefined8 placeholder_10, int64_t arg_60h, int64_t arg_68h,
                      int64_t arg_a0h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802460f4;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = placeholder_3;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = placeholder_2;
    *(int64_t *)((int64_t)&var_20h + iVar2) = (int64_t)&arg_40h + iVar2;
    *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x180246121;
    iVar1 = fcn.180246150(*(int64_t *)((int64_t)&var_20h + iVar2), *(int64_t *)((int64_t)&arg_28h + iVar2), 
                          *(int64_t *)((int64_t)&arg_30h + iVar2));
    if ((iVar1 != 0) && (*(int32_t *)((int64_t)&arg_40h + iVar2) == 0)) {
        uVar3 = 0xffffffff;
        if (*(uint64_t *)((int64_t)&arg_48h + iVar2) < 0x80000000) {
            uVar3 = *(uint64_t *)((int64_t)&arg_48h + iVar2) & 0xffffffff;
        }
        return uVar3;
    }
    return 0xffffffff;
}

// ============================================================
// Function: FUN_180246150
// Address: 0x180246150
// Size: 1956 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_88h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch

undefined4
fcn.180246150(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h, int64_t arg_38h)
{
    char *pcVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t *piVar7;
    char cVar8;
    char cVar9;
    int64_t *piVar10;
    uint64_t uVar11;
    undefined8 uVar12;
    int32_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 uVar16;
    uint32_t uVar17;
    bool bVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    uint32_t var_88h;
    int64_t var_84h;
    int32_t var_7ch;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined8 uStack_48;
    
    uStack_48 = 0x18024617d;
    piVar7 = (int64_t *)arg1;
    iVar6 = arg2;
    piVar10 = (int64_t *)arg3;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    var_78h = *piVar7;
    uVar17 = 0;
    iVar4 = -1;
    var_60h = *piVar10;
    var_68h = 0;
    var_58h = 0;
    var_84h._0_4_ = 0;
    var_84h._4_4_ = 0;
    var_88h = 0;
    var_7ch = -1;
    var_70h = iVar6;
    uVar3 = uVar17;
    uVar14 = uVar17;
    do {
        cVar8 = *(char *)arg_30h;
        arg_30h = arg_30h + 1;
        iVar13 = var_7ch;
code_r0x0001802461e0:
        var_7ch = iVar13;
        uVar15 = 0;
        if (cVar8 == '\0') goto code_r0x000180246244;
        pcVar1 = (char *)arg_30h;
        iVar13 = var_7ch;
    // switch table (7 cases) at 0x1802467a8
        switch(uVar17) {
        case 0:
            if (cVar8 == '%') {
                uVar17 = 1;
            } else {
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246221;
                iVar2 = func_0x000180246900(&var_78h, (int32_t)cVar8);
                iVar4 = var_7ch;
                uVar3 = var_88h;
                if (iVar2 == 0) goto code_r0x000180246533;
            }
            pcVar1 = (char *)(arg_30h + 1);
            cVar8 = *(char *)arg_30h;
        default:
code_r0x00018024623e:
            arg_30h = (int64_t)pcVar1;
            if (uVar17 == 7) {
code_r0x000180246244:
                var_84h._0_4_ = 1;
                goto code_r0x000180246533;
            }
            goto code_r0x0001802461e0;
        case 1:
            if (cVar8 == ' ') {
                uVar14 = uVar14 | 4;
                break;
            }
            if (cVar8 == '#') {
                uVar14 = uVar14 | 8;
                break;
            }
            if (cVar8 == '+') {
                uVar14 = uVar14 | 2;
                break;
            }
            if (cVar8 == '-') {
                uVar14 = uVar14 | 1;
                break;
            }
            if (cVar8 != '0') {
                uVar17 = 2;
                goto code_r0x0001802461e0;
            }
            uVar14 = uVar14 | 0x10;
            break;
        case 2:
            iVar2 = (int32_t)cVar8;
            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1802462b0;
            iVar4 = func_0x000180275480(iVar2);
            if (iVar4 == 0) {
                uVar17 = 3;
                iVar4 = var_7ch;
                uVar3 = var_88h;
                if (cVar8 != '*') goto code_r0x0001802461e0;
                iVar4 = *(int32_t *)arg_38h;
                cVar8 = *(char *)arg_30h;
                arg_38h = arg_38h + 8;
                uVar3 = uVar14 | 1;
                if (-1 < iVar4) {
                    uVar3 = uVar14;
                }
                var_84h._4_4_ = -iVar4;
                uVar14 = uVar3;
                if (0 < iVar4) {
                    var_84h._4_4_ = iVar4;
                }
            } else {
                if (0xccccccb < var_84h._4_4_) goto code_r0x00018024679b;
                cVar8 = *(char *)arg_30h;
                var_84h._4_4_ = var_84h._4_4_ * 10 + -0x30 + iVar2;
            }
            arg_30h = arg_30h + 1;
            iVar4 = var_7ch;
            uVar3 = var_88h;
            goto code_r0x0001802461e0;
        case 3:
            cVar9 = cVar8;
            if (cVar8 == '.') {
                cVar9 = *(char *)arg_30h;
            }
            uVar17 = (cVar8 != '.') + 4;
            bVar18 = cVar8 != '.';
            pcVar1 = (char *)(arg_30h + 1);
            cVar8 = cVar9;
            if (bVar18) {
                pcVar1 = (char *)arg_30h;
            }
            goto code_r0x00018024623e;
        case 4:
            iVar4 = (int32_t)cVar8;
            *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246360;
            iVar13 = func_0x000180275480(iVar4);
            if (iVar13 == 0) {
                uVar17 = 5;
                if (cVar8 == '*') {
                    cVar8 = *(char *)arg_30h;
                    iVar4 = *(int32_t *)arg_38h;
                    arg_30h = arg_30h + 1;
                    arg_38h = arg_38h + 8;
                    iVar13 = iVar4;
                    uVar3 = var_88h;
                } else {
                    iVar4 = 0;
                    iVar13 = 0;
                    uVar3 = var_88h;
                    if (-1 < var_7ch) {
                        iVar4 = var_7ch;
                        iVar13 = var_7ch;
                    }
                }
            } else {
                iVar13 = 0;
                if (-1 < var_7ch) {
                    iVar13 = var_7ch;
                }
                if (0xccccccb < iVar13) {
code_r0x00018024679b:
                    var_84h._0_4_ = 0;
                    goto code_r0x000180246533;
                }
                cVar8 = *(char *)arg_30h;
                iVar4 = iVar13 * 10 + -0x30 + iVar4;
                arg_30h = arg_30h + 1;
                iVar13 = iVar4;
                uVar3 = var_88h;
            }
            goto code_r0x0001802461e0;
        case 5:
    // switch table (7 cases) at 0x1802467c4
            switch(cVar8) {
            case 'L':
                var_88h = 4;
                break;
            default:
                goto code_r0x00018024649f;
            case 'h':
                cVar8 = *(char *)arg_30h;
                if (cVar8 != 'h') {
                    arg_30h = arg_30h + 1;
                    var_88h = 2;
                    uVar17 = 6;
                    uVar3 = 2;
                    goto code_r0x0001802461e0;
                }
                var_88h = 1;
                arg_30h = arg_30h + 1;
                break;
            case 'j':
            case 'q':
                var_88h = 5;
                break;
            case 'l':
                cVar8 = *(char *)arg_30h;
                if (cVar8 != 'l') {
                    arg_30h = arg_30h + 1;
                    var_88h = 3;
                    uVar17 = 6;
                    uVar3 = 3;
                    goto code_r0x0001802461e0;
                }
                var_88h = 5;
                arg_30h = arg_30h + 1;
                break;
            case 't':
                var_88h = 7;
                break;
            case 'z':
                var_88h = 6;
            }
            cVar8 = *(char *)arg_30h;
            arg_30h = arg_30h + 1;
            uVar3 = var_88h;
code_r0x00018024649f:
            uVar17 = 6;
            goto code_r0x0001802461e0;
        case 6:
            iVar13 = (int32_t)cVar8;
    // switch table (84 cases) at 0x180246810
            switch(iVar13) {
            case 0x25:
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246766;
                iVar4 = func_0x000180246900(&var_78h, iVar13);
                goto code_r0x000180246528;
            case 0x45:
                uVar14 = uVar14 | 0x20;
            case 0x65:
                piVar7 = *(int64_t **)arg_38h;
                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar5) = 1;
                *(uint32_t *)(&stack0xffffffffffffffe0 + iVar5) = uVar14;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246657;
                iVar4 = func_0x000180246a50(&var_78h, piVar7, var_84h._4_4_, iVar4);
                if (iVar4 == 0) goto code_r0x000180246533;
                arg_38h = arg_38h + 8;
                break;
            case 0x47:
                uVar14 = uVar14 | 0x20;
            case 0x67:
                piVar7 = *(int64_t **)arg_38h;
                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar5) = 2;
                *(uint32_t *)(&stack0xffffffffffffffe0 + iVar5) = uVar14;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x18024668d;
                iVar4 = func_0x000180246a50(&var_78h, piVar7, var_84h._4_4_, iVar4);
                if (iVar4 == 0) goto code_r0x000180246533;
                arg_38h = arg_38h + 8;
                break;
            case 0x58:
                uVar14 = uVar14 | 0x20;
            case 0x6f:
            case 0x75:
            case 0x78:
                uVar14 = uVar14 | 0x40;
    // switch table (7 cases) at 0x1802468bc
                switch(uVar3) {
                case 1:
                    piVar7 = (int64_t *)(uint64_t)*(uint8_t *)arg_38h;
                    break;
                case 2:
                    piVar7 = (int64_t *)(uint64_t)*(uint16_t *)arg_38h;
                    break;
                default:
                    piVar7 = (int64_t *)(uint64_t)*(uint32_t *)arg_38h;
                    break;
                case 5:
                case 6:
                case 7:
                    piVar7 = *(int64_t **)arg_38h;
                }
                if (cVar8 == 'o') {
                    uVar12 = 8;
                } else {
                    uVar12 = 0x10;
                    if (iVar13 == 0x75) {
                        uVar12 = 10;
                    }
                }
                goto code_r0x000180246511;
            case 99:
                uVar16 = *(undefined4 *)arg_38h;
                arg_38h = arg_38h + 8;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1802466ae;
                iVar4 = func_0x000180246900(&var_78h, uVar16);
                goto code_r0x000180246528;
            case 100:
            case 0x69:
    // switch table (7 cases) at 0x1802468a0
                switch(uVar3) {
                case 1:
                    piVar7 = (int64_t *)(int64_t)*(char *)arg_38h;
                    break;
                case 2:
                    piVar7 = (int64_t *)(int64_t)*(int16_t *)arg_38h;
                    break;
                default:
                    piVar7 = (int64_t *)(int64_t)*(int32_t *)arg_38h;
                    break;
                case 5:
                case 6:
                case 7:
                    piVar7 = *(int64_t **)arg_38h;
                }
                uVar12 = 10;
                goto code_r0x000180246511;
            case 0x66:
                piVar7 = *(int64_t **)arg_38h;
                *(undefined4 *)(&stack0xffffffffffffffe8 + iVar5) = 0;
                *(uint32_t *)(&stack0xffffffffffffffe0 + iVar5) = uVar14;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246621;
                iVar4 = func_0x000180246a50(&var_78h, piVar7, var_84h._4_4_, iVar4);
                if (iVar4 == 0) goto code_r0x000180246533;
                arg_38h = arg_38h + 8;
                break;
            case 0x6e:
    // switch table (7 cases) at 0x1802468d8
                switch(uVar3) {
                case 1:
                    *(undefined *)*(int64_t **)arg_38h = (undefined)var_58h;
                    arg_38h = arg_38h + 8;
                    break;
                case 2:
                    *(undefined2 *)*(int64_t **)arg_38h = (undefined2)var_58h;
                    arg_38h = arg_38h + 8;
                    break;
                default:
                    *(undefined4 *)*(int64_t **)arg_38h = (undefined4)var_58h;
                    arg_38h = arg_38h + 8;
                    break;
                case 5:
                case 6:
                case 7:
                    **(int64_t **)arg_38h = var_58h;
                    arg_38h = arg_38h + 8;
                }
                break;
            case 0x70:
                piVar7 = *(int64_t **)arg_38h;
                uVar14 = uVar14 | 8;
                uVar12 = 0x10;
code_r0x000180246511:
                arg_38h = arg_38h + 8;
                *(uint32_t *)(&stack0xffffffffffffffe8 + iVar5) = uVar14;
                *(int32_t *)(&stack0xffffffffffffffe0 + iVar5) = iVar4;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246528;
                iVar4 = func_0x000180247160(&var_78h, piVar7, uVar12, var_84h._4_4_);
                goto code_r0x000180246528;
            case 0x73:
                piVar7 = *(int64_t **)arg_38h;
                arg_38h = arg_38h + 8;
                if (iVar4 < 0) {
                    iVar4 = 0x7fffffff;
                }
                *(int32_t *)(&stack0xffffffffffffffe0 + iVar5) = iVar4;
                *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x1802466db;
                iVar4 = func_0x0001802474e0(&var_78h, piVar7, uVar14, var_84h._4_4_);
code_r0x000180246528:
                if (iVar4 == 0) {
code_r0x000180246533:
                    if (arg2 == 0) {
                        uVar11 = var_60h - 1;
                        bVar18 = uVar11 < (uint64_t)var_68h;
                        if (uVar11 < (uint64_t)var_68h) {
                            var_68h = uVar11;
                        }
                        *(uint32_t *)arg_28h = (uint32_t)bVar18;
                    }
                    *(undefined8 *)((int64_t)&uStack_48 + iVar5) = 0x180246567;
                    iVar4 = func_0x000180246900(&var_78h, 0);
                    uVar16 = 0;
                    if (iVar4 != 0) {
                        uVar16 = (undefined4)var_84h;
                    }
                    *(int64_t *)arg4 = var_68h + -1;
                    *(int64_t *)arg1 = var_78h;
                    *(int64_t *)arg3 = var_60h;
                    return uVar16;
                }
                break;
            case 0x77:
                arg_30h = arg_30h + 1;
            }
            cVar8 = *(char *)arg_30h;
            var_84h._4_4_ = 0;
            var_7ch = -1;
            arg_30h = arg_30h + 1;
            var_88h = 0;
            iVar4 = -1;
            iVar13 = var_7ch;
            uVar14 = uVar15;
            uVar3 = uVar15;
            uVar17 = uVar15;
            goto code_r0x0001802461e0;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180246900
// Address: 0x180246900
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180246900(int64_t arg_28h, int64_t arg_30h)
{
    uint64_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RCX;
    undefined in_DL;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x180246915;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((*in_RCX != 0) || (in_RCX[1] != 0)) {
        uVar1 = in_RCX[3];
        if ((uint64_t)in_RCX[2] <= uVar1) {
            if (((int64_t *)in_RCX[1] == (int64_t *)0x0) || (in_RCX[2] != uVar1)) goto code_r0x0001802469e3;
            if (uVar1 < 0x7ffffc00) {
                iVar4 = uVar1 + 0x400;
                in_RCX[3] = iVar4;
                iVar5 = *(int64_t *)in_RCX[1];
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180246988;
                    iVar5 = func_0x0001802248d0(iVar4, 0x1804e4250, 0x3d4);
                    *(int64_t *)in_RCX[1] = iVar5;
                    if (iVar5 != 0) {
                        if (in_RCX[2] != 0) {
                            if (*in_RCX == 0) {
                                return 0;
                            }
                            uVar2 = *(undefined8 *)in_RCX[1];
                            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802469b9;
                            func_0x000180498030(uVar2);
                        }
                        *in_RCX = 0;
code_r0x0001802469e3:
                        uVar1 = in_RCX[2];
                        if (uVar1 < (uint64_t)in_RCX[3]) {
                            if (*in_RCX == 0) {
                                *(undefined *)(uVar1 + *(int64_t *)in_RCX[1]) = in_DL;
                            } else {
                                *(undefined *)(uVar1 + *in_RCX) = in_DL;
                            }
                            in_RCX[2] = in_RCX[2] + 1;
                        }
                        if (in_RCX[4] < 0x7fffffffffffffff) {
                            in_RCX[4] = in_RCX[4] + 1;
                        }
                        return 1;
                    }
                } else {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802469d7;
                    iVar3 = func_0x0001802249c0(iVar5, iVar4, 0x1804e4250, 0x3df);
                    if (iVar3 != 0) {
                        *(int64_t *)in_RCX[1] = iVar3;
                        goto code_r0x0001802469e3;
                    }
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180246a50
// Address: 0x180246a50
// Size: 249 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_37h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

void fcn.180246a50(int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h)
{
    code *pcVar1;
    undefined auVar2 [16];
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int32_t in_R8D;
    uint64_t uVar13;
    int32_t in_R9D;
    uint64_t uVar14;
    int32_t iVar15;
    undefined8 unaff_R12;
    int32_t iVar16;
    int32_t iVar17;
    int32_t iVar18;
    undefined8 unaff_R14;
    double in_XMM1_Qa;
    double dVar19;
    double dVar20;
    double dVar21;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_7h;
    int64_t var_1fh;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180246a62;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    auVar2._4_4_ = unaff_XMM6_Db;
    auVar2._0_4_ = unaff_XMM6_Da;
    auVar2._8_4_ = unaff_XMM6_Dc;
    auVar2._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_58h + iVar6) = auVar2;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    iVar5 = 0;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    iVar16 = 0;
    iVar17 = 6;
    if (-1 < in_R9D) {
        iVar17 = in_R9D;
    }
    if (0.0 <= in_XMM1_Qa) {
        if ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 2) == 0) {
            uVar9 = 0;
            if ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 4) != 0) {
                uVar9 = 0x20;
            }
            *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar9;
        } else {
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x2b;
        }
    } else {
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x2d;
    }
    dVar19 = in_XMM1_Qa;
    if (in_XMM1_Qa < 0.0) {
        dVar19 = (double)((uint64_t)in_XMM1_Qa ^ 0x8000000000000000);
    }
    if ((dVar19 <= 0.0) || (dVar19 * 0.5 != dVar19)) {
        if (NAN(dVar19)) {
            dVar19 = 0.0;
        }
        if (dVar19 == 0.0) goto code_r0x000180246b1d;
    } else {
        dVar19 = 0.0;
code_r0x000180246b1d:
        if (in_XMM1_Qa != 0.0) {
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x3f;
        }
    }
    iVar15 = *(int32_t *)((int64_t)&arg_c0h + iVar6);
    dVar21 = 1.0;
    *(undefined8 *)((int64_t)&arg_a0h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_a8h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_b0h + iVar6) = unaff_R14;
    if (iVar15 == 2) {
        if (dVar19 == 0.0) goto code_r0x000180246b6e;
        if (dVar19 < 0.0001) {
            *(undefined4 *)((int64_t)&var_8h + iVar6 + 4) = 1;
            iVar18 = 1;
            goto code_r0x000180246bc7;
        }
        if ((iVar17 != 0) || (dVar19 < 10.0)) {
            if (0 < iVar17) {
                dVar20 = 1.0;
                iVar18 = iVar17;
                do {
                    dVar20 = dVar20 * 10.0;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                if (dVar20 <= dVar19) goto code_r0x000180246bae;
            }
code_r0x000180246b6e:
            *(undefined4 *)((int64_t)&var_8h + iVar6 + 4) = 0;
            iVar18 = 0;
        } else {
code_r0x000180246bae:
            *(undefined4 *)((int64_t)&var_8h + iVar6 + 4) = 1;
            iVar18 = 1;
        }
code_r0x000180246bc7:
        dVar20 = dVar19;
        if (dVar19 != 0.0) {
            for (; dVar20 < 1.0; dVar20 = dVar20 * 10.0) {
                iVar16 = iVar16 + -1;
            }
            for (; 10.0 < dVar20; dVar20 = dVar20 / 10.0) {
                iVar16 = iVar16 + 1;
            }
        }
        if (iVar15 != 2) {
code_r0x000180246c6a:
            if (iVar18 == 1) {
                dVar19 = dVar20;
            }
            goto code_r0x000180246c71;
        }
        if (iVar17 == 0) {
            iVar17 = 1;
        }
        if (iVar18 != 0) {
            iVar17 = iVar17 + -1;
            goto code_r0x000180246c6a;
        }
        iVar17 = iVar17 + (-1 - iVar16);
        if (-1 < iVar17) goto code_r0x000180246c71;
    } else {
        *(int32_t *)((int64_t)&var_8h + iVar6 + 4) = iVar15;
        iVar18 = iVar15;
        if (iVar15 != 0) goto code_r0x000180246bc7;
code_r0x000180246c71:
        if (dVar19 < 4294967296.0) {
            dVar20 = 1.0;
            uVar12 = (uint64_t)dVar19;
            if (iVar17 < 10) {
                iVar18 = iVar17;
                iVar7 = iVar17;
                if (iVar17 != 0) goto code_r0x000180246ca2;
                uVar11 = 1;
            } else {
                iVar17 = 9;
                iVar18 = 9;
                iVar7 = 9;
code_r0x000180246ca2:
                do {
                    dVar20 = dVar20 * 10.0;
                    iVar17 = iVar17 + -1;
                } while (iVar17 != 0);
                uVar3 = (uint32_t)dVar20;
                uVar11 = uVar3 + 1;
                if (dVar20 - (double)uVar3 < 0.5) {
                    uVar11 = uVar3;
                }
                do {
                    dVar21 = dVar21 * 10.0;
                    iVar7 = iVar7 + -1;
                } while (iVar7 != 0);
            }
            dVar21 = (dVar19 - (double)(uVar12 & 0xffffffff)) * dVar21;
            uVar4 = (uint32_t)dVar21;
            uVar3 = uVar4 + 1;
            if (dVar21 - (double)uVar4 < 0.5) {
                uVar3 = uVar4;
            }
            uVar4 = uVar3;
            if (uVar11 <= uVar3) {
                uVar4 = uVar3 - uVar11;
            }
            uVar10 = (uint64_t)uVar4;
            iVar8 = 0;
            uVar14 = (uint64_t)((int32_t)uVar12 + 1);
            iVar17 = 0;
            if (uVar3 < uVar11) {
                uVar14 = uVar12 & 0xffffffff;
            }
            do {
                iVar7 = iVar17;
                iVar17 = (int32_t)(uVar14 / 10);
                *(undefined *)((int64_t)&var_7h + iVar8 + iVar6 + 1) =
                     *(undefined *)((uint64_t)(uint32_t)((int32_t)uVar14 + iVar17 * -10) + 0x180643ac0);
                iVar8 = iVar8 + 1;
                if (iVar17 == 0) break;
                uVar14 = uVar14 / 10;
                iVar17 = iVar7 + 1;
            } while (iVar8 < 0x14);
            if (iVar7 != 0x13) {
                iVar7 = iVar7 + 1;
            }
            uVar12 = (uint64_t)iVar7;
            if (0x13 < uVar12) {
code_r0x000180247157:
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024715c;
                func_0x000180459e6c();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined *)((int64_t)&var_7h + uVar12 + iVar6 + 1) = 0;
            if (0 < iVar18) {
                iVar8 = 0;
                do {
                    if (((iVar15 == 2) && (iVar8 == 0)) && ((int32_t)uVar10 == (int32_t)(uVar10 / 10) * 10)) {
                        iVar18 = iVar18 + -1;
                    } else {
                        iVar5 = iVar5 + 1;
                        *(undefined *)((int64_t)&var_1fh + iVar8 + iVar6 + 1) =
                             *(undefined *)
                              ((uint64_t)(uint32_t)((int32_t)uVar10 + (int32_t)(uVar10 / 10) * -10) + 0x180643ac0);
                        iVar8 = iVar8 + 1;
                    }
                    uVar10 = uVar10 / 10;
                } while (iVar5 < iVar18);
            }
            uVar14 = (uint64_t)iVar5;
            if (0x13 < uVar14) goto code_r0x000180247157;
            iVar17 = *(int32_t *)((int64_t)&var_8h + iVar6 + 4);
            *(undefined *)((int64_t)&var_1fh + uVar14 + iVar6 + 1) = 0;
            if (iVar17 == 1) {
                uVar13 = 0;
                uVar10 = uVar13;
                iVar15 = -iVar16;
                if (0 < iVar16) {
                    uVar10 = 0;
                    iVar15 = iVar16;
                }
                do {
                    uVar11 = (int32_t)uVar10 + 1;
                    uVar10 = (uint64_t)uVar11;
                    *(uint32_t *)(&stack0x00000000 + iVar6) = uVar11;
                    (&stack0x00000038)[uVar13 + iVar6] = *(undefined *)((int64_t)(iVar15 % 10) + 0x180643ac0);
                    uVar13 = uVar13 + 1;
                    if (iVar15 / 10 < 1) {
                        if (uVar11 != 1) goto code_r0x000180246ea6;
                        iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
                        (&stack0x00000039)[iVar6] = 0x30;
                        uVar11 = 2;
                        *(undefined4 *)(&stack0x00000000 + iVar6) = 2;
                        iVar15 = (((in_R8D - (uint32_t)(0 < iVar18)) - (uint32_t)(iVar16 != 0)) - iVar7) - iVar18;
                        goto code_r0x000180246ecb;
                    }
                    iVar15 = iVar15 / 10;
                } while ((int64_t)uVar13 < 0x14);
                goto code_r0x000180246c1f;
            }
            uVar11 = *(uint32_t *)(&stack0x00000000 + iVar6);
code_r0x000180246ea6:
            iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
            iVar15 = (((in_R8D - (uint32_t)(iVar16 != 0)) - (uint32_t)(0 < iVar18)) - iVar7) - iVar18;
            if (iVar17 == 1) {
code_r0x000180246ecb:
                iVar15 = iVar15 + (-2 - uVar11);
            }
            iVar17 = 0;
            if (-1 < iVar18 - iVar5) {
                iVar17 = iVar18 - iVar5;
            }
            iVar5 = 0;
            if (-1 < iVar15) {
                iVar5 = iVar15;
            }
            iVar15 = -iVar5;
            if ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 1) == 0) {
                iVar15 = iVar5;
            }
            if (((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 0x10) == 0) || (iVar15 < 1)) {
                for (; 0 < iVar15; iVar15 = iVar15 + -1) {
                    if ((*(int64_t *)(in_RCX + 8) == 0) &&
                       (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                        if (0 < iVar15) {
                            iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
                            goto code_r0x000180246f75;
                        }
                        break;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246fc4;
                    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar16 == 0) goto code_r0x000180246c2b;
                }
                iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
code_r0x000180246fd6:
                if (iVar16 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246fe4;
                    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar16 == 0) goto code_r0x000180246c2b;
                }
            } else {
                if (iVar16 == 0) {
                    iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
code_r0x000180246f40:
                    do {
                        if ((*(int64_t *)(in_RCX + 8) == 0) &&
                           (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                            if (0 < iVar15) {
code_r0x000180246f75:
                                if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar15) {
                                    *(int64_t *)(in_RCX + 0x20) = *(int64_t *)(in_RCX + 0x20) + (int64_t)iVar15;
                                } else {
                                    *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                                }
                            }
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246f5e;
                        iVar5 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)(&stack0x00000000 + iVar6));
                        if (iVar5 == 0) goto code_r0x000180246c2b;
                        iVar15 = iVar15 + -1;
                    } while (0 < iVar15);
                    goto code_r0x000180246fd6;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246f21;
                iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                if (iVar16 == 0) goto code_r0x000180246c2b;
                iVar15 = iVar15 + -1;
                iVar16 = 0;
                if (0 < iVar15) goto code_r0x000180246f40;
            }
            do {
                if ((int64_t)uVar12 < 1) {
                    if ((iVar18 < 1) && ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 8) == 0))
                    goto joined_r0x000180247060;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024702e;
                    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar16 != 0) goto joined_r0x000180247039;
                    break;
                }
                uVar12 = uVar12 - 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247002;
                iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            } while (iVar16 != 0);
            goto code_r0x000180246c2b;
        }
    }
code_r0x000180246c1f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246c29;
    fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    goto code_r0x000180246c2b;
    while( true ) {
        uVar14 = uVar14 - 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247050;
        iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        if (iVar16 == 0) break;
joined_r0x000180247039:
        if ((int64_t)uVar14 < 1) goto joined_r0x000180247060;
    }
    goto code_r0x000180246c2b;
joined_r0x000180247060:
    if (iVar17 < 1) goto code_r0x0001802470d5;
    if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
        if (0 < iVar17) {
            if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar17) {
                *(int64_t *)(in_RCX + 0x20) = *(int64_t *)(in_RCX + 0x20) + (int64_t)iVar17;
            } else {
                *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
            }
        }
        goto code_r0x0001802470d5;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247080;
    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    if (iVar16 == 0) goto code_r0x000180246c2b;
    iVar17 = iVar17 + -1;
    goto joined_r0x000180247060;
code_r0x0001802470d5:
    if (*(int32_t *)((int64_t)&var_8h + iVar6 + 4) == 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1802470ee;
        iVar17 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        if (iVar17 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024710d;
            iVar17 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            if ((iVar17 != 0) &&
               (iVar8 = (int64_t)*(int32_t *)(&stack0x00000000 + iVar6), 0 < *(int32_t *)(&stack0x00000000 + iVar6))) {
                do {
                    iVar8 = iVar8 + -1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247140;
                    iVar17 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar17 == 0) break;
                } while (0 < iVar8);
            }
        }
    }
code_r0x000180246c2b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246c50;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180246b49
// Address: 0x180246b49
// Size: 1556 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Removing arg arg_37h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel

void fcn.180246a50(int64_t arg_50h, int64_t arg_58h, int64_t arg_a0h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h,
                  int64_t arg_c0h)
{
    code *pcVar1;
    undefined auVar2 [16];
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int32_t iVar7;
    int64_t in_RCX;
    int64_t iVar8;
    undefined4 uVar9;
    uint64_t uVar10;
    uint32_t uVar11;
    undefined8 unaff_RDI;
    uint64_t uVar12;
    int32_t in_R8D;
    uint64_t uVar13;
    int32_t in_R9D;
    uint64_t uVar14;
    int32_t iVar15;
    undefined8 unaff_R12;
    int32_t iVar16;
    int32_t iVar17;
    int32_t iVar18;
    undefined8 unaff_R14;
    double in_XMM1_Qa;
    double dVar19;
    double dVar20;
    double dVar21;
    undefined4 unaff_XMM6_Da;
    undefined4 unaff_XMM6_Db;
    undefined4 unaff_XMM6_Dc;
    undefined4 unaff_XMM6_Dd;
    int64_t var_7h;
    int64_t var_1fh;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x180246a62;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    auVar2._4_4_ = unaff_XMM6_Db;
    auVar2._0_4_ = unaff_XMM6_Da;
    auVar2._8_4_ = unaff_XMM6_Dc;
    auVar2._12_4_ = unaff_XMM6_Dd;
    *(undefined (*) [16])((int64_t)&arg_58h + iVar6) = auVar2;
    *(uint64_t *)((int64_t)&arg_50h + iVar6) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6);
    iVar5 = 0;
    *(undefined4 *)(&stack0x00000000 + iVar6) = 0;
    iVar16 = 0;
    iVar17 = 6;
    if (-1 < in_R9D) {
        iVar17 = in_R9D;
    }
    if (0.0 <= in_XMM1_Qa) {
        if ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 2) == 0) {
            uVar9 = 0;
            if ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 4) != 0) {
                uVar9 = 0x20;
            }
            *(undefined4 *)((int64_t)&var_8h + iVar6) = uVar9;
        } else {
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x2b;
        }
    } else {
        *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x2d;
    }
    dVar19 = in_XMM1_Qa;
    if (in_XMM1_Qa < 0.0) {
        dVar19 = (double)((uint64_t)in_XMM1_Qa ^ 0x8000000000000000);
    }
    if ((dVar19 <= 0.0) || (dVar19 * 0.5 != dVar19)) {
        if (NAN(dVar19)) {
            dVar19 = 0.0;
        }
        if (dVar19 == 0.0) goto code_r0x000180246b1d;
    } else {
        dVar19 = 0.0;
code_r0x000180246b1d:
        if (in_XMM1_Qa != 0.0) {
            *(undefined4 *)((int64_t)&var_8h + iVar6) = 0x3f;
        }
    }
    iVar15 = *(int32_t *)((int64_t)&arg_c0h + iVar6);
    dVar21 = 1.0;
    *(undefined8 *)((int64_t)&arg_a0h + iVar6) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_a8h + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_b0h + iVar6) = unaff_R14;
    if (iVar15 == 2) {
        if (dVar19 == 0.0) goto code_r0x000180246b6e;
        if (dVar19 < 0.0001) {
            *(undefined4 *)((int64_t)&var_8h + iVar6 + 4) = 1;
            iVar18 = 1;
            goto code_r0x000180246bc7;
        }
        if ((iVar17 != 0) || (dVar19 < 10.0)) {
            if (0 < iVar17) {
                dVar20 = 1.0;
                iVar18 = iVar17;
                do {
                    dVar20 = dVar20 * 10.0;
                    iVar18 = iVar18 + -1;
                } while (iVar18 != 0);
                if (dVar20 <= dVar19) goto code_r0x000180246bae;
            }
code_r0x000180246b6e:
            *(undefined4 *)((int64_t)&var_8h + iVar6 + 4) = 0;
            iVar18 = 0;
        } else {
code_r0x000180246bae:
            *(undefined4 *)((int64_t)&var_8h + iVar6 + 4) = 1;
            iVar18 = 1;
        }
code_r0x000180246bc7:
        dVar20 = dVar19;
        if (dVar19 != 0.0) {
            for (; dVar20 < 1.0; dVar20 = dVar20 * 10.0) {
                iVar16 = iVar16 + -1;
            }
            for (; 10.0 < dVar20; dVar20 = dVar20 / 10.0) {
                iVar16 = iVar16 + 1;
            }
        }
        if (iVar15 != 2) {
code_r0x000180246c6a:
            if (iVar18 == 1) {
                dVar19 = dVar20;
            }
            goto code_r0x000180246c71;
        }
        if (iVar17 == 0) {
            iVar17 = 1;
        }
        if (iVar18 != 0) {
            iVar17 = iVar17 + -1;
            goto code_r0x000180246c6a;
        }
        iVar17 = iVar17 + (-1 - iVar16);
        if (-1 < iVar17) goto code_r0x000180246c71;
    } else {
        *(int32_t *)((int64_t)&var_8h + iVar6 + 4) = iVar15;
        iVar18 = iVar15;
        if (iVar15 != 0) goto code_r0x000180246bc7;
code_r0x000180246c71:
        if (dVar19 < 4294967296.0) {
            dVar20 = 1.0;
            uVar12 = (uint64_t)dVar19;
            if (iVar17 < 10) {
                iVar18 = iVar17;
                iVar7 = iVar17;
                if (iVar17 != 0) goto code_r0x000180246ca2;
                uVar11 = 1;
            } else {
                iVar17 = 9;
                iVar18 = 9;
                iVar7 = 9;
code_r0x000180246ca2:
                do {
                    dVar20 = dVar20 * 10.0;
                    iVar17 = iVar17 + -1;
                } while (iVar17 != 0);
                uVar3 = (uint32_t)dVar20;
                uVar11 = uVar3 + 1;
                if (dVar20 - (double)uVar3 < 0.5) {
                    uVar11 = uVar3;
                }
                do {
                    dVar21 = dVar21 * 10.0;
                    iVar7 = iVar7 + -1;
                } while (iVar7 != 0);
            }
            dVar21 = (dVar19 - (double)(uVar12 & 0xffffffff)) * dVar21;
            uVar4 = (uint32_t)dVar21;
            uVar3 = uVar4 + 1;
            if (dVar21 - (double)uVar4 < 0.5) {
                uVar3 = uVar4;
            }
            uVar4 = uVar3;
            if (uVar11 <= uVar3) {
                uVar4 = uVar3 - uVar11;
            }
            uVar10 = (uint64_t)uVar4;
            iVar8 = 0;
            uVar14 = (uint64_t)((int32_t)uVar12 + 1);
            iVar17 = 0;
            if (uVar3 < uVar11) {
                uVar14 = uVar12 & 0xffffffff;
            }
            do {
                iVar7 = iVar17;
                iVar17 = (int32_t)(uVar14 / 10);
                *(undefined *)((int64_t)&var_7h + iVar8 + iVar6 + 1) =
                     *(undefined *)((uint64_t)(uint32_t)((int32_t)uVar14 + iVar17 * -10) + 0x180643ac0);
                iVar8 = iVar8 + 1;
                if (iVar17 == 0) break;
                uVar14 = uVar14 / 10;
                iVar17 = iVar7 + 1;
            } while (iVar8 < 0x14);
            if (iVar7 != 0x13) {
                iVar7 = iVar7 + 1;
            }
            uVar12 = (uint64_t)iVar7;
            if (0x13 < uVar12) {
code_r0x000180247157:
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024715c;
                func_0x000180459e6c();
                pcVar1 = (code *)swi(3);
                (*pcVar1)();
                return;
            }
            *(undefined *)((int64_t)&var_7h + uVar12 + iVar6 + 1) = 0;
            if (0 < iVar18) {
                iVar8 = 0;
                do {
                    if (((iVar15 == 2) && (iVar8 == 0)) && ((int32_t)uVar10 == (int32_t)(uVar10 / 10) * 10)) {
                        iVar18 = iVar18 + -1;
                    } else {
                        iVar5 = iVar5 + 1;
                        *(undefined *)((int64_t)&var_1fh + iVar8 + iVar6 + 1) =
                             *(undefined *)
                              ((uint64_t)(uint32_t)((int32_t)uVar10 + (int32_t)(uVar10 / 10) * -10) + 0x180643ac0);
                        iVar8 = iVar8 + 1;
                    }
                    uVar10 = uVar10 / 10;
                } while (iVar5 < iVar18);
            }
            uVar14 = (uint64_t)iVar5;
            if (0x13 < uVar14) goto code_r0x000180247157;
            iVar17 = *(int32_t *)((int64_t)&var_8h + iVar6 + 4);
            *(undefined *)((int64_t)&var_1fh + uVar14 + iVar6 + 1) = 0;
            if (iVar17 == 1) {
                uVar13 = 0;
                uVar10 = uVar13;
                iVar15 = -iVar16;
                if (0 < iVar16) {
                    uVar10 = 0;
                    iVar15 = iVar16;
                }
                do {
                    uVar11 = (int32_t)uVar10 + 1;
                    uVar10 = (uint64_t)uVar11;
                    *(uint32_t *)(&stack0x00000000 + iVar6) = uVar11;
                    (&stack0x00000038)[uVar13 + iVar6] = *(undefined *)((int64_t)(iVar15 % 10) + 0x180643ac0);
                    uVar13 = uVar13 + 1;
                    if (iVar15 / 10 < 1) {
                        if (uVar11 != 1) goto code_r0x000180246ea6;
                        iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
                        (&stack0x00000039)[iVar6] = 0x30;
                        uVar11 = 2;
                        *(undefined4 *)(&stack0x00000000 + iVar6) = 2;
                        iVar15 = (((in_R8D - (uint32_t)(0 < iVar18)) - (uint32_t)(iVar16 != 0)) - iVar7) - iVar18;
                        goto code_r0x000180246ecb;
                    }
                    iVar15 = iVar15 / 10;
                } while ((int64_t)uVar13 < 0x14);
                goto code_r0x000180246c1f;
            }
            uVar11 = *(uint32_t *)(&stack0x00000000 + iVar6);
code_r0x000180246ea6:
            iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
            iVar15 = (((in_R8D - (uint32_t)(iVar16 != 0)) - (uint32_t)(0 < iVar18)) - iVar7) - iVar18;
            if (iVar17 == 1) {
code_r0x000180246ecb:
                iVar15 = iVar15 + (-2 - uVar11);
            }
            iVar17 = 0;
            if (-1 < iVar18 - iVar5) {
                iVar17 = iVar18 - iVar5;
            }
            iVar5 = 0;
            if (-1 < iVar15) {
                iVar5 = iVar15;
            }
            iVar15 = -iVar5;
            if ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 1) == 0) {
                iVar15 = iVar5;
            }
            if (((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 0x10) == 0) || (iVar15 < 1)) {
                for (; 0 < iVar15; iVar15 = iVar15 + -1) {
                    if ((*(int64_t *)(in_RCX + 8) == 0) &&
                       (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                        if (0 < iVar15) {
                            iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
                            goto code_r0x000180246f75;
                        }
                        break;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246fc4;
                    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar16 == 0) goto code_r0x000180246c2b;
                }
                iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
code_r0x000180246fd6:
                if (iVar16 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246fe4;
                    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar16 == 0) goto code_r0x000180246c2b;
                }
            } else {
                if (iVar16 == 0) {
                    iVar16 = *(int32_t *)((int64_t)&var_8h + iVar6);
code_r0x000180246f40:
                    do {
                        if ((*(int64_t *)(in_RCX + 8) == 0) &&
                           (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                            if (0 < iVar15) {
code_r0x000180246f75:
                                if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar15) {
                                    *(int64_t *)(in_RCX + 0x20) = *(int64_t *)(in_RCX + 0x20) + (int64_t)iVar15;
                                } else {
                                    *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                                }
                            }
                            break;
                        }
                        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246f5e;
                        iVar5 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                              *(int64_t *)(&stack0x00000000 + iVar6));
                        if (iVar5 == 0) goto code_r0x000180246c2b;
                        iVar15 = iVar15 + -1;
                    } while (0 < iVar15);
                    goto code_r0x000180246fd6;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246f21;
                iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
                if (iVar16 == 0) goto code_r0x000180246c2b;
                iVar15 = iVar15 + -1;
                iVar16 = 0;
                if (0 < iVar15) goto code_r0x000180246f40;
            }
            do {
                if ((int64_t)uVar12 < 1) {
                    if ((iVar18 < 1) && ((*(uint32_t *)((int64_t)&arg_b8h + iVar6) & 8) == 0))
                    goto joined_r0x000180247060;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024702e;
                    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar16 != 0) goto joined_r0x000180247039;
                    break;
                }
                uVar12 = uVar12 - 1;
                *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247002;
                iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            } while (iVar16 != 0);
            goto code_r0x000180246c2b;
        }
    }
code_r0x000180246c1f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246c29;
    fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    goto code_r0x000180246c2b;
    while( true ) {
        uVar14 = uVar14 - 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247050;
        iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        if (iVar16 == 0) break;
joined_r0x000180247039:
        if ((int64_t)uVar14 < 1) goto joined_r0x000180247060;
    }
    goto code_r0x000180246c2b;
joined_r0x000180247060:
    if (iVar17 < 1) goto code_r0x0001802470d5;
    if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
        if (0 < iVar17) {
            if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar17) {
                *(int64_t *)(in_RCX + 0x20) = *(int64_t *)(in_RCX + 0x20) + (int64_t)iVar17;
            } else {
                *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
            }
        }
        goto code_r0x0001802470d5;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247080;
    iVar16 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
    if (iVar16 == 0) goto code_r0x000180246c2b;
    iVar17 = iVar17 + -1;
    goto joined_r0x000180247060;
code_r0x0001802470d5:
    if (*(int32_t *)((int64_t)&var_8h + iVar6 + 4) == 1) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x1802470ee;
        iVar17 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
        if (iVar17 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x18024710d;
            iVar17 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)(&stack0x00000000 + iVar6));
            if ((iVar17 != 0) &&
               (iVar8 = (int64_t)*(int32_t *)(&stack0x00000000 + iVar6), 0 < *(int32_t *)(&stack0x00000000 + iVar6))) {
                do {
                    iVar8 = iVar8 + -1;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180247140;
                    iVar17 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar6), 
                                           *(int64_t *)(&stack0x00000000 + iVar6));
                    if (iVar17 == 0) break;
                } while (0 < iVar8);
            }
        }
    }
code_r0x000180246c2b:
    *(undefined8 *)((int64_t)&uStack_30 + iVar6) = 0x180246c50;
    func_0x000180459870(*(uint64_t *)((int64_t)&arg_50h + iVar6) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_180247160
// Address: 0x180247160
// Size: 883 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.180247160(int64_t arg_28h, int64_t arg_60h, int64_t arg_78h, int64_t arg_80h)
{
    char *pcVar1;
    char cVar2;
    uint32_t uVar3;
    code *pcVar4;
    int64_t iVar5;
    uint64_t uVar6;
    int64_t iVar7;
    int64_t in_RCX;
    uint64_t in_RDX;
    uint64_t uVar8;
    int32_t iVar9;
    undefined8 unaff_RSI;
    int32_t iVar10;
    uint64_t in_R8;
    int64_t iVar11;
    undefined4 in_R9D;
    int32_t iVar12;
    int32_t iVar13;
    char *pcVar14;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    int64_t var_8h;
    
    uStack_30 = 0x18024717d;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&var_20h + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5);
    uVar3 = *(uint32_t *)((int64_t)&arg_80h + iVar5);
    pcVar14 = "";
    iVar13 = 0;
    iVar12 = 0;
    *(undefined4 *)((int64_t)&var_8h + iVar5 + 4) = in_R9D;
    iVar10 = *(int32_t *)((int64_t)&arg_78h + iVar5);
    iVar9 = 1;
    if (-1 < iVar10) {
        iVar9 = iVar10;
    }
    *(int32_t *)((int64_t)&var_8h + iVar5) = iVar9;
    if (-1 < iVar10) {
        uVar3 = uVar3 & 0xffffffef;
    }
    uVar8 = in_RDX;
    if ((uVar3 & 0x40) == 0) {
        if ((int64_t)in_RDX < 0) {
            iVar13 = 0x2d;
            uVar8 = -in_RDX;
        } else if ((uVar3 & 2) == 0) {
            iVar13 = 0;
            if ((uVar3 & 4) != 0) {
                iVar13 = 0x20;
            }
        } else {
            iVar13 = 0x2b;
        }
    }
    if ((uVar3 & 8) != 0) {
        pcVar14 = "0";
        if ((int32_t)in_R8 != 8) {
            pcVar14 = "";
        }
        if (((in_RDX != 0) && ((int32_t)in_R8 == 0x10)) && (pcVar14 = "0x", (uVar3 & 0x20) != 0)) {
            pcVar14 = "0X";
        }
    }
    *(undefined8 *)((int64_t)&arg_60h + iVar5) = unaff_RSI;
    if (uVar8 != 0) {
        iVar11 = 0;
        do {
            if (0x19 < iVar11) break;
            uVar6 = uVar8 / (in_R8 & 0xffffffff);
            iVar7 = 0x180624310;
            if ((uVar3 & 0x20) != 0) {
                iVar7 = 0x1804a6a38;
            }
            iVar12 = iVar12 + 1;
            (&stack0x00000000)[iVar11 + iVar5] = *(undefined *)(iVar7 + uVar8 % (in_R8 & 0xffffffff));
            iVar11 = iVar11 + 1;
            uVar8 = uVar6;
        } while (uVar6 != 0);
        iVar9 = *(int32_t *)((int64_t)&var_8h + iVar5);
    }
    iVar10 = 0x19;
    if (iVar12 != 0x1a) {
        iVar10 = iVar12;
    }
    uVar8 = (uint64_t)iVar10;
    if (0x19 < uVar8) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802474d2;
        func_0x000180459e6c();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    (&stack0x00000000)[uVar8 + iVar5] = 0;
    iVar12 = (iVar9 - (uint32_t)(pcVar14 == "0")) - iVar10;
    iVar9 = 0;
    if (-1 < iVar12) {
        iVar9 = iVar12;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802472e8;
    iVar12 = func_0x000180498cd0(pcVar14);
    iVar12 = (uint32_t)(iVar13 != 0) + iVar9 + iVar10 + iVar12;
    if (iVar12 <= *(int32_t *)((int64_t)&var_8h + iVar5)) {
        iVar12 = *(int32_t *)((int64_t)&var_8h + iVar5);
    }
    iVar12 = *(int32_t *)((int64_t)&var_8h + iVar5 + 4) - iVar12;
    iVar10 = 0;
    if (-1 < iVar12) {
        iVar10 = iVar12;
    }
    if ((uVar3 & 1) == 0) {
        if ((uVar3 & 0x10) == 0) goto joined_r0x00018024731b;
        iVar9 = iVar9 + iVar10;
        iVar10 = 0;
    } else {
        iVar10 = -iVar10;
joined_r0x00018024731b:
        for (; 0 < iVar10; iVar10 = iVar10 + -1) {
            if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                if (0 < iVar10) {
                    if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar10) {
                        *(int64_t *)(in_RCX + 0x20) = (int64_t)iVar10 + *(int64_t *)(in_RCX + 0x20);
                    } else {
                        *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                    }
                }
                break;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024733e;
            iVar12 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
            if (iVar12 == 0) goto code_r0x000180247474;
        }
    }
    if (iVar13 != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x18024738e;
        iVar12 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        if (iVar12 == 0) goto code_r0x000180247474;
    }
    cVar2 = *pcVar14;
    while (cVar2 != '\0') {
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802473ab;
        iVar12 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        if (iVar12 == 0) goto code_r0x000180247474;
        pcVar1 = pcVar14 + 1;
        pcVar14 = pcVar14 + 1;
        cVar2 = *pcVar1;
    }
    for (; 0 < iVar9; iVar9 = iVar9 + -1) {
        if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
            if (0 < iVar9) {
                if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar9) {
                    *(int64_t *)(in_RCX + 0x20) = (int64_t)iVar9 + *(int64_t *)(in_RCX + 0x20);
                } else {
                    *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                }
            }
            break;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x1802473e1;
        iVar12 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
        if (iVar12 == 0) goto code_r0x000180247474;
    }
    do {
        if ((int64_t)uVar8 < 1) {
            if ((iVar10 < 0) && (iVar9 = -iVar10, iVar10 < 0)) goto code_r0x000180247447;
            break;
        }
        uVar8 = uVar8 - 1;
        *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180247430;
        iVar9 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
    } while (iVar9 != 0);
code_r0x000180247474:
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180247489;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_20h + iVar5) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar5));
    return;
code_r0x000180247447:
    if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
        if (0 < iVar9) {
            if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar9) {
                *(int64_t *)(in_RCX + 0x20) = (int64_t)iVar9 + *(int64_t *)(in_RCX + 0x20);
            } else {
                *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
            }
        }
        goto code_r0x000180247474;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar5) = 0x180247465;
    iVar10 = fcn.180246900(*(int64_t *)((int64_t)&var_8h + iVar5), *(int64_t *)(&stack0x00000000 + iVar5));
    if ((iVar10 == 0) || (iVar9 = iVar9 + -1, iVar9 < 1)) goto code_r0x000180247474;
    goto code_r0x000180247447;
}

// ============================================================
// Function: FUN_1802474e0
// Address: 0x1802474e0
// Size: 532 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1802474e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_48h)
{
    int32_t iVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t in_RCX;
    int64_t in_RDX;
    int64_t iVar4;
    int32_t iVar5;
    uint32_t in_R8D;
    int32_t in_R9D;
    int32_t iVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_30;
    
    uStack_30 = 0x180247502;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    iVar5 = *(int32_t *)((int64_t)&arg_48h + iVar2);
    iVar6 = 0;
    iVar8 = 0x1804bf754;
    if (in_RDX != 0) {
        iVar8 = in_RDX;
    }
    iVar4 = -1;
    if (-1 < iVar5) {
        iVar4 = (int64_t)iVar5;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18024753c;
    uVar3 = func_0x000180223860(iVar8, iVar4);
    iVar7 = 0;
    if (((-1 < in_R9D) && (iVar7 = 0, uVar3 < 0x7fffffff)) && (iVar7 = in_R9D - (int32_t)uVar3, iVar7 < 0)) {
        iVar7 = 0;
    }
    if (-1 < iVar5) {
        if (iVar5 < 0x7fffffff - iVar7) {
            iVar5 = iVar5 + iVar7;
        } else {
            iVar5 = 0x7fffffff;
        }
    }
    if (((in_R8D & 1) == 0) && (0 < iVar7)) {
        if (iVar5 < 0) {
code_r0x000180247592:
            do {
                if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                    if (0 < iVar7) {
                        if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar7) {
                            *(int64_t *)(in_RCX + 0x20) = (int64_t)iVar7 + *(int64_t *)(in_RCX + 0x20);
                        } else {
                            *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                        }
                    }
                    break;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x1802475b0;
                iVar1 = fcn.180246900(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                      *(int64_t *)(&stack0x00000000 + iVar2));
                if (iVar1 == 0) {
                    return 0;
                }
                iVar7 = iVar7 + -1;
            } while (0 < iVar7);
            goto code_r0x0001802475e4;
        }
        if (iVar5 < iVar7) {
            iVar7 = iVar5;
        }
        iVar6 = iVar7;
        if (iVar7 != 0) goto code_r0x000180247592;
    } else {
code_r0x0001802475e4:
        if (iVar5 < 0) goto joined_r0x000180247608;
    }
    if ((0x7fffffff < uVar3) || (iVar5 - iVar6 < (int32_t)uVar3)) {
        uVar3 = (uint64_t)(iVar5 - iVar6);
    }
    iVar6 = iVar6 + (int32_t)uVar3;
joined_r0x000180247608:
    do {
        if (uVar3 == 0) {
code_r0x000180247662:
            if (((in_R8D & 1) != 0) && (0 < iVar7)) {
                if (iVar5 < 0) goto code_r0x000180247680;
                iVar1 = iVar5 - iVar6;
                if (iVar7 <= iVar5 - iVar6) goto code_r0x000180247680;
                while (iVar7 = iVar1, 0 < iVar7) {
code_r0x000180247680:
                    if ((*(int64_t *)(in_RCX + 8) == 0) &&
                       (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
                        if (iVar7 < 1) {
                            return 1;
                        }
                        if (*(int64_t *)(in_RCX + 0x20) < 0x7fffffffffffffff - (int64_t)iVar7) {
                            *(int64_t *)(in_RCX + 0x20) = (int64_t)iVar7 + *(int64_t *)(in_RCX + 0x20);
                            return 1;
                        }
                        *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                        return 1;
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18024769e;
                    iVar5 = fcn.180246900(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), 
                                          *(int64_t *)(&stack0x00000000 + iVar2));
                    if (iVar5 == 0) {
                        return 0;
                    }
                    iVar1 = iVar7 + -1;
                }
            }
            return 1;
        }
        if ((*(int64_t *)(in_RCX + 8) == 0) && (*(uint64_t *)(in_RCX + 0x18) <= *(uint64_t *)(in_RCX + 0x10))) {
            if (0 < (int64_t)uVar3) {
                if (*(int64_t *)(in_RCX + 0x20) < (int64_t)(0x7fffffffffffffff - uVar3)) {
                    *(uint64_t *)(in_RCX + 0x20) = *(int64_t *)(in_RCX + 0x20) + uVar3;
                } else {
                    *(undefined8 *)(in_RCX + 0x20) = 0x7fffffffffffffff;
                }
            }
            goto code_r0x000180247662;
        }
        *(undefined8 *)((int64_t)&uStack_30 + iVar2) = 0x18024762d;
        iVar1 = fcn.180246900(*(int64_t *)(&stack0xfffffffffffffff8 + iVar2), *(int64_t *)(&stack0x00000000 + iVar2));
        if (iVar1 == 0) {
            return 0;
        }
        uVar3 = uVar3 - 1;
    } while( true );
}

// ============================================================
// Function: FUN_180247700
// Address: 0x180247700
// Size: 63 bytes
// ============================================================
void fcn.180247700(int64_t arg1)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180247710;
        iVar2 = fcn.18045a350();
        pcVar1 = *(code **)(*(int64_t *)arg1 + 0x18);
        if (pcVar1 != (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180247724;
            (*pcVar1)();
        }
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x180247739;
        fcn.180224990(arg1, 0x1804e4270, 0x3d);
    }
    return;
}

// ============================================================
// Function: FUN_180247740
// Address: 0x180247740
// Size: 126 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t * fcn.180247740(int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180247750;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024776f;
        piVar4 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar3));
        if (piVar4 != (int64_t *)0x0) {
            *piVar4 = in_RCX;
            pcVar1 = *(code **)(in_RCX + 0x10);
            if (pcVar1 != (code *)0x0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180247788;
                iVar2 = (*pcVar1)(piVar4);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802477a1;
                    fcn.180224990(piVar4, 0x1804e4270, 0x1d);
                    piVar4 = (int64_t *)0x0;
                }
            }
            return piVar4;
        }
    }
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_1802477c0
// Address: 0x1802477c0
// Size: 83 bytes
// ============================================================
undefined8 fcn.1802477c0(int64_t arg_38h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1802477cc;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar2 = *(code **)(*in_RCX + 0x20);
    if (pcVar2 == (code *)0x0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    iVar1 = *(int32_t *)((int64_t)&arg_58h + iVar3);
    *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802477fe;
    uVar4 = (*pcVar2)();
    if (0 < (int32_t)uVar4) {
        *(int32_t *)(in_RCX + 1) = *(int32_t *)(in_RCX + 1) + iVar1;
        *(int32_t *)((int64_t)in_RCX + 0xc) = *(int32_t *)((int64_t)in_RCX + 0xc) + (int32_t)uVar4;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180247820
// Address: 0x180247820
// Size: 83 bytes
// ============================================================
undefined8 fcn.180247820(int64_t arg_38h, int64_t arg_58h)
{
    int32_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t *in_RCX;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18024782c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    pcVar2 = *(code **)(*in_RCX + 0x28);
    if (pcVar2 == (code *)0x0) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar3) = unaff_RDI;
    iVar1 = *(int32_t *)((int64_t)&arg_58h + iVar3);
    *(int64_t *)((int64_t)&var_18h + iVar3) = (int64_t)iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024785e;
    uVar4 = (*pcVar2)();
    if (0 < (int32_t)uVar4) {
        *(int32_t *)(in_RCX + 2) = *(int32_t *)(in_RCX + 2) + iVar1;
        *(int32_t *)((int64_t)in_RCX + 0x14) = *(int32_t *)((int64_t)in_RCX + 0x14) + (int32_t)uVar4;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_180247890
// Address: 0x180247890
// Size: 16 bytes
// ============================================================
int64_t fcn.180247890(int64_t arg_160h, int64_t arg_180h, int64_t arg_188h, int64_t arg_1a8h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18024789d;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_160h + iVar3) = unaff_RBP;
    in_RDX = in_RDX & 0xffffffff;
    *(undefined8 *)((int64_t)&arg_188h + iVar3) = unaff_RBX;
    do {
        *(int64_t *)((int64_t)&arg_180h + iVar3) = (int64_t)&var_20h + iVar3;
        *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)in_RDX;
        if (*(int64_t *)0x18077e6d0 == 0) {
code_r0x000180247903:
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180247c40;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180247928;
            piVar5 = (int64_t *)func_0x00018022c840((int64_t)&arg_180h + iVar3, 0x1806a0350, 0xf, 8);
            if ((piVar5 == (int64_t *)0x0) || (iVar4 = *piVar5, iVar4 == 0)) {
                iVar4 = 0;
code_r0x000180247942:
                if (in_RCX != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180247956;
                    iVar6 = func_0x0001802c88c0(in_RDX);
                    if (iVar6 != 0) {
                        *in_RCX = iVar6;
                        *(undefined8 *)(&stack0x00000170 + iVar3) = 0x1802c885a;
                        iVar4 = fcn.18045a350(iVar6, in_RDX);
                        iVar4 = -iVar4;
                        pcVar1 = *(code **)(iVar6 + 0x50);
                        if (pcVar1 != (code *)0x0) {
                            *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c8873;
                            iVar2 = (*pcVar1)();
                            if (iVar2 != 0) {
                                return *(int64_t *)((int64_t)&arg_1a8h + iVar4 + iVar3);
                            }
                        }
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c8886;
                        fcn.180229480(*(int64_t *)(&stack0x00000198 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001a0 + iVar4 + iVar3));
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c889e;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000198 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001a0 + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_1a8h + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001b0 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001c8 + iVar4 + iVar3));
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c88b0;
                        fcn.1802296d0(*(int64_t *)(&stack0x000001b8 + iVar4 + iVar3));
                        return 0;
                    }
                    *in_RCX = 0;
                }
                return iVar4;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802478e7;
            iVar2 = func_0x000180221a50(*(int64_t *)0x18077e6d0, (int64_t)&var_20h + iVar3);
            if (iVar2 < 0) goto code_r0x000180247903;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802478f9;
            iVar4 = func_0x000180222340(*(int64_t *)0x18077e6d0, iVar2);
            if (iVar4 == 0) goto code_r0x000180247942;
        }
        if ((*(uint8_t *)(iVar4 + 8) & 1) == 0) goto code_r0x000180247942;
        in_RDX = (uint64_t)*(uint32_t *)(iVar4 + 4);
    } while( true );
}

// ============================================================
// Function: FUN_1802478a0
// Address: 0x1802478a0
// Size: 175 bytes
// ============================================================
int64_t fcn.180247890(int64_t arg_160h, int64_t arg_180h, int64_t arg_188h, int64_t arg_1a8h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18024789d;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_160h + iVar3) = unaff_RBP;
    in_RDX = in_RDX & 0xffffffff;
    *(undefined8 *)((int64_t)&arg_188h + iVar3) = unaff_RBX;
    do {
        *(int64_t *)((int64_t)&arg_180h + iVar3) = (int64_t)&var_20h + iVar3;
        *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)in_RDX;
        if (*(int64_t *)0x18077e6d0 == 0) {
code_r0x000180247903:
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180247c40;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180247928;
            piVar5 = (int64_t *)func_0x00018022c840((int64_t)&arg_180h + iVar3, 0x1806a0350, 0xf, 8);
            if ((piVar5 == (int64_t *)0x0) || (iVar4 = *piVar5, iVar4 == 0)) {
                iVar4 = 0;
code_r0x000180247942:
                if (in_RCX != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180247956;
                    iVar6 = func_0x0001802c88c0(in_RDX);
                    if (iVar6 != 0) {
                        *in_RCX = iVar6;
                        *(undefined8 *)(&stack0x00000170 + iVar3) = 0x1802c885a;
                        iVar4 = fcn.18045a350(iVar6, in_RDX);
                        iVar4 = -iVar4;
                        pcVar1 = *(code **)(iVar6 + 0x50);
                        if (pcVar1 != (code *)0x0) {
                            *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c8873;
                            iVar2 = (*pcVar1)();
                            if (iVar2 != 0) {
                                return *(int64_t *)((int64_t)&arg_1a8h + iVar4 + iVar3);
                            }
                        }
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c8886;
                        fcn.180229480(*(int64_t *)(&stack0x00000198 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001a0 + iVar4 + iVar3));
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c889e;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000198 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001a0 + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_1a8h + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001b0 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001c8 + iVar4 + iVar3));
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c88b0;
                        fcn.1802296d0(*(int64_t *)(&stack0x000001b8 + iVar4 + iVar3));
                        return 0;
                    }
                    *in_RCX = 0;
                }
                return iVar4;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802478e7;
            iVar2 = func_0x000180221a50(*(int64_t *)0x18077e6d0, (int64_t)&var_20h + iVar3);
            if (iVar2 < 0) goto code_r0x000180247903;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802478f9;
            iVar4 = func_0x000180222340(*(int64_t *)0x18077e6d0, iVar2);
            if (iVar4 == 0) goto code_r0x000180247942;
        }
        if ((*(uint8_t *)(iVar4 + 8) & 1) == 0) goto code_r0x000180247942;
        in_RDX = (uint64_t)*(uint32_t *)(iVar4 + 4);
    } while( true );
}

// ============================================================
// Function: FUN_18024794f
// Address: 0x18024794f
// Size: 70 bytes
// ============================================================
int64_t fcn.180247890(int64_t arg_160h, int64_t arg_180h, int64_t arg_188h, int64_t arg_1a8h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_18;
    
    uStack_18 = 0x18024789d;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(undefined8 *)((int64_t)&arg_160h + iVar3) = unaff_RBP;
    in_RDX = in_RDX & 0xffffffff;
    *(undefined8 *)((int64_t)&arg_188h + iVar3) = unaff_RBX;
    do {
        *(int64_t *)((int64_t)&arg_180h + iVar3) = (int64_t)&var_20h + iVar3;
        *(int32_t *)((int64_t)&var_20h + iVar3) = (int32_t)in_RDX;
        if (*(int64_t *)0x18077e6d0 == 0) {
code_r0x000180247903:
            *(undefined8 *)((int64_t)&var_10h + iVar3) = 0x180247c40;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180247928;
            piVar5 = (int64_t *)func_0x00018022c840((int64_t)&arg_180h + iVar3, 0x1806a0350, 0xf, 8);
            if ((piVar5 == (int64_t *)0x0) || (iVar4 = *piVar5, iVar4 == 0)) {
                iVar4 = 0;
code_r0x000180247942:
                if (in_RCX != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x180247956;
                    iVar6 = func_0x0001802c88c0(in_RDX);
                    if (iVar6 != 0) {
                        *in_RCX = iVar6;
                        *(undefined8 *)(&stack0x00000170 + iVar3) = 0x1802c885a;
                        iVar4 = fcn.18045a350(iVar6, in_RDX);
                        iVar4 = -iVar4;
                        pcVar1 = *(code **)(iVar6 + 0x50);
                        if (pcVar1 != (code *)0x0) {
                            *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c8873;
                            iVar2 = (*pcVar1)();
                            if (iVar2 != 0) {
                                return *(int64_t *)((int64_t)&arg_1a8h + iVar4 + iVar3);
                            }
                        }
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c8886;
                        fcn.180229480(*(int64_t *)(&stack0x00000198 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001a0 + iVar4 + iVar3));
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c889e;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000198 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001a0 + iVar4 + iVar3), 
                                      *(int64_t *)((int64_t)&arg_1a8h + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001b0 + iVar4 + iVar3), 
                                      *(int64_t *)(&stack0x000001c8 + iVar4 + iVar3));
                        *(undefined8 *)(&stack0x00000170 + iVar4 + iVar3) = 0x1802c88b0;
                        fcn.1802296d0(*(int64_t *)(&stack0x000001b8 + iVar4 + iVar3));
                        return 0;
                    }
                    *in_RCX = 0;
                }
                return iVar4;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802478e7;
            iVar2 = func_0x000180221a50(*(int64_t *)0x18077e6d0, (int64_t)&var_20h + iVar3);
            if (iVar2 < 0) goto code_r0x000180247903;
            *(undefined8 *)((int64_t)&uStack_18 + iVar3) = 0x1802478f9;
            iVar4 = func_0x000180222340(*(int64_t *)0x18077e6d0, iVar2);
            if (iVar4 == 0) goto code_r0x000180247942;
        }
        if ((*(uint8_t *)(iVar4 + 8) & 1) == 0) goto code_r0x000180247942;
        in_RDX = (uint64_t)*(uint32_t *)(iVar4 + 4);
    } while( true );
}

// ============================================================
// Function: FUN_1802479a0
// Address: 0x1802479a0
// Size: 153 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802479a0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R13;
    int64_t iVar8;
    undefined8 uStack_28;
    int64_t var_20h;
    
    uStack_28 = 0x1802479b2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = in_R8 & 0xffffffff;
    if ((int32_t)in_R8 == -1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479cc;
        uVar5 = func_0x000180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    if (in_RCX != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479ec;
        iVar6 = func_0x0001802c88f0((int64_t)&arg_30h + iVar4, in_RDX, uVar5 & 0xffffffff);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479fe;
            iVar2 = func_0x00018026b010(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            iVar8 = 0;
            if (iVar2 != 0) {
                iVar8 = iVar6;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a0e;
            func_0x00018029b080(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            *in_RCX = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            return iVar8;
        }
        *in_RCX = 0;
    }
    uVar7 = 0xf;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000000 + iVar4) = unaff_R13;
    if (*(int64_t *)0x18077e6d0 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a52;
        iVar2 = func_0x000180222010();
        uVar7 = (uint64_t)(iVar2 + 0xfU);
        if ((int32_t)(iVar2 + 0xfU) < 1) {
            return 0;
        }
    }
    iVar2 = (int32_t)uVar7 + -0xf;
    do {
        iVar2 = iVar2 + -1;
        uVar7 = uVar7 - 1;
        iVar6 = 0;
        if (-1 < (int64_t)uVar7) {
            if ((int64_t)uVar7 < 0xf) {
                iVar6 = *(int64_t *)(uVar7 * 8 + 0x1806a0350);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a8d;
                iVar6 = func_0x000180222340(*(int64_t *)0x18077e6d0, iVar2);
            }
        }
        if ((*(uint8_t *)(iVar6 + 8) & 1) == 0) {
            uVar1 = *(undefined8 *)(iVar6 + 0x10);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247aa2;
            iVar3 = func_0x000180498cd0(uVar1);
            if (iVar3 == (int32_t)uVar5) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247ab5;
                iVar3 = func_0x0001802237e0(uVar1, in_RDX, (int64_t)(int32_t)uVar5);
                if (iVar3 == 0) {
                    return iVar6;
                }
            }
        }
    } while (0 < (int64_t)uVar7);
    return 0;
}

// ============================================================
// Function: FUN_180247a39
// Address: 0x180247a39
// Size: 167 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802479a0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R13;
    int64_t iVar8;
    undefined8 uStack_28;
    int64_t var_20h;
    
    uStack_28 = 0x1802479b2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = in_R8 & 0xffffffff;
    if ((int32_t)in_R8 == -1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479cc;
        uVar5 = func_0x000180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    if (in_RCX != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479ec;
        iVar6 = func_0x0001802c88f0((int64_t)&arg_30h + iVar4, in_RDX, uVar5 & 0xffffffff);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479fe;
            iVar2 = func_0x00018026b010(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            iVar8 = 0;
            if (iVar2 != 0) {
                iVar8 = iVar6;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a0e;
            func_0x00018029b080(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            *in_RCX = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            return iVar8;
        }
        *in_RCX = 0;
    }
    uVar7 = 0xf;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000000 + iVar4) = unaff_R13;
    if (*(int64_t *)0x18077e6d0 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a52;
        iVar2 = func_0x000180222010();
        uVar7 = (uint64_t)(iVar2 + 0xfU);
        if ((int32_t)(iVar2 + 0xfU) < 1) {
            return 0;
        }
    }
    iVar2 = (int32_t)uVar7 + -0xf;
    do {
        iVar2 = iVar2 + -1;
        uVar7 = uVar7 - 1;
        iVar6 = 0;
        if (-1 < (int64_t)uVar7) {
            if ((int64_t)uVar7 < 0xf) {
                iVar6 = *(int64_t *)(uVar7 * 8 + 0x1806a0350);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a8d;
                iVar6 = func_0x000180222340(*(int64_t *)0x18077e6d0, iVar2);
            }
        }
        if ((*(uint8_t *)(iVar6 + 8) & 1) == 0) {
            uVar1 = *(undefined8 *)(iVar6 + 0x10);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247aa2;
            iVar3 = func_0x000180498cd0(uVar1);
            if (iVar3 == (int32_t)uVar5) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247ab5;
                iVar3 = func_0x0001802237e0(uVar1, in_RDX, (int64_t)(int32_t)uVar5);
                if (iVar3 == 0) {
                    return iVar6;
                }
            }
        }
    } while (0 < (int64_t)uVar7);
    return 0;
}

// ============================================================
// Function: FUN_180247ae0
// Address: 0x180247ae0
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.1802479a0(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t in_R8;
    undefined8 unaff_R13;
    int64_t iVar8;
    undefined8 uStack_28;
    int64_t var_20h;
    
    uStack_28 = 0x1802479b2;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar5 = in_R8 & 0xffffffff;
    if ((int32_t)in_R8 == -1) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479cc;
        uVar5 = func_0x000180498cd0(in_RDX);
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RDI;
    if (in_RCX != (undefined8 *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479ec;
        iVar6 = func_0x0001802c88f0((int64_t)&arg_30h + iVar4, in_RDX, uVar5 & 0xffffffff);
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x1802479fe;
            iVar2 = func_0x00018026b010(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            iVar8 = 0;
            if (iVar2 != 0) {
                iVar8 = iVar6;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a0e;
            func_0x00018029b080(*(undefined8 *)((int64_t)&arg_30h + iVar4));
            *in_RCX = *(undefined8 *)((int64_t)&arg_30h + iVar4);
            return iVar8;
        }
        *in_RCX = 0;
    }
    uVar7 = 0xf;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_RBP;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000000 + iVar4) = unaff_R13;
    if (*(int64_t *)0x18077e6d0 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a52;
        iVar2 = func_0x000180222010();
        uVar7 = (uint64_t)(iVar2 + 0xfU);
        if ((int32_t)(iVar2 + 0xfU) < 1) {
            return 0;
        }
    }
    iVar2 = (int32_t)uVar7 + -0xf;
    do {
        iVar2 = iVar2 + -1;
        uVar7 = uVar7 - 1;
        iVar6 = 0;
        if (-1 < (int64_t)uVar7) {
            if ((int64_t)uVar7 < 0xf) {
                iVar6 = *(int64_t *)(uVar7 * 8 + 0x1806a0350);
            } else {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247a8d;
                iVar6 = func_0x000180222340(*(int64_t *)0x18077e6d0, iVar2);
            }
        }
        if ((*(uint8_t *)(iVar6 + 8) & 1) == 0) {
            uVar1 = *(undefined8 *)(iVar6 + 0x10);
            *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247aa2;
            iVar3 = func_0x000180498cd0(uVar1);
            if (iVar3 == (int32_t)uVar5) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar4) = 0x180247ab5;
                iVar3 = func_0x0001802237e0(uVar1, in_RDX, (int64_t)(int32_t)uVar5);
                if (iVar3 == 0) {
                    return iVar6;
                }
            }
        }
    } while (0 < (int64_t)uVar7);
    return 0;
}

// ============================================================
// Function: FUN_180247af0
// Address: 0x180247af0
// Size: 99 bytes
// ============================================================
void fcn.180247af0(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180247b00;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if ((*(uint8_t *)(arg1 + 8) & 2) != 0) {
            uVar1 = *(undefined8 *)(arg1 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180247b22;
            fcn.180224990(uVar1, 0x1804e4288, 0x113);
            uVar1 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180247b38;
            fcn.180224990(uVar1, 0x1804e4288, 0x114);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x180247b4d;
            fcn.180224990(arg1, 0x1804e4288, 0x115);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180247b60
// Address: 0x180247b60
// Size: 67 bytes
// ============================================================
undefined8 fcn.180247b60(int32_t param_1)
{
    fcn.18045a350();
    if (param_1 < 0) {
        return 0;
    }
    if (param_1 < 0xf) {
        return *(undefined8 *)((int64_t)param_1 * 8 + 0x1806a0350);
    }
    param_1 = param_1 + -0xf;
    if (((*(int32_t **)0x18077e6d0 != (int32_t *)0x0) && (-1 < param_1)) && (param_1 < **(int32_t **)0x18077e6d0)) {
        return *(undefined8 *)(*(int64_t *)(*(int32_t **)0x18077e6d0 + 2) + (int64_t)param_1 * 8);
    }
    return 0;
}

// ============================================================
// Function: FUN_180247c10
// Address: 0x180247c10
// Size: 48 bytes
// ============================================================
int32_t fcn.180247c10(void)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x180247c1a;
    iVar2 = fcn.18045a350();
    if (*(int64_t *)0x18077e6d0 != 0) {
        *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x180247c2e;
        iVar1 = fcn.180222010();
        return iVar1 + 0xf;
    }
    return 0xf;
}

// ============================================================
// Function: FUN_180247c50
// Address: 0x180247c50
// Size: 510 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180247c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    uint64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180247c63;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247c7c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247c94;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ca6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0xffffffff;
    }
    if ((*in_RCX != 0x10) && (*in_RCX != 0x4000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ccc;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ce4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247cf6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
        iVar8 = *(int64_t *)(in_RCX + 10);
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R14;
        iVar2 = *(int64_t *)(iVar8 + 0x10);
        pcVar3 = *(code **)(iVar8 + 0x38);
        iVar8 = 0x1805aadb1;
        if (iVar2 != 0) {
            iVar8 = iVar2;
        }
        if (pcVar3 == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e7c;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e94;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247eb3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
            uVar7 = 0xfffffffe;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)((int64_t)&arg_58h + iVar6);
            *(undefined8 *)((int64_t)&var_8h + iVar6) = in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ed9;
            uVar5 = (*pcVar3)();
            uVar7 = (uint64_t)uVar5;
            if ((int32_t)uVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ee4;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247efc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247f1b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
            }
        }
        return uVar7;
    }
    iVar8 = *(int64_t *)(in_RCX + 0x1e);
    if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0x48) != 0)) {
        if ((*(uint8_t *)(iVar8 + 4) & 2) != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d43;
            iVar4 = fcn.18022fbd0(uVar1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d4f;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d67;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d79;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
                return 0;
            }
            if (in_RDX == 0) {
                *in_R8 = (int64_t)iVar4;
                return 1;
            }
            if (*in_R8 < (uint64_t)(int64_t)iVar4) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247dae;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247dc6;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247dd8;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
                return 0;
            }
        }
    // WARNING: Could not recover jumptable at 0x000180247e09. Too many branches
    // WARNING: Treating indirect jump as call
        uVar7 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x48))(in_RCX, in_RDX, in_R8, in_R9);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e11;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e29;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e3b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180247e4e
// Address: 0x180247e4e
// Size: 231 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

uint64_t fcn.180247c50(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_58h)
{
    undefined8 uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int32_t *in_RCX;
    int64_t in_RDX;
    undefined8 unaff_RBP;
    uint64_t *in_R8;
    undefined8 in_R9;
    undefined8 unaff_R14;
    int64_t iVar8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_20;
    
    uStack_20 = 0x180247c63;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247c7c;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247c94;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ca6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0xffffffff;
    }
    if ((*in_RCX != 0x10) && (*in_RCX != 0x4000)) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ccc;
        fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ce4;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar6));
        *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247cf6;
        fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) != 0) {
        *(undefined8 *)((int64_t)&arg_38h + iVar6) = unaff_RBP;
        iVar8 = *(int64_t *)(in_RCX + 10);
        *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_R14;
        iVar2 = *(int64_t *)(iVar8 + 0x10);
        pcVar3 = *(code **)(iVar8 + 0x38);
        iVar8 = 0x1805aadb1;
        if (iVar2 != 0) {
            iVar8 = iVar2;
        }
        if (pcVar3 == (code *)0x0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e7c;
            fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e94;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar6));
            *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247eb3;
            fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
            uVar7 = 0xfffffffe;
        } else {
            *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)((int64_t)&arg_58h + iVar6);
            *(undefined8 *)((int64_t)&var_8h + iVar6) = in_R9;
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ed9;
            uVar5 = (*pcVar3)();
            uVar7 = (uint64_t)uVar5;
            if ((int32_t)uVar5 < 1) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247ee4;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247efc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(int64_t *)((int64_t)&var_8h + iVar6) = iVar8;
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247f1b;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
            }
        }
        return uVar7;
    }
    iVar8 = *(int64_t *)(in_RCX + 0x1e);
    if ((iVar8 != 0) && (*(int64_t *)(iVar8 + 0x48) != 0)) {
        if ((*(uint8_t *)(iVar8 + 4) & 2) != 0) {
            uVar1 = *(undefined8 *)(in_RCX + 0x22);
            *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d43;
            iVar4 = fcn.18022fbd0(uVar1);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d4f;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d67;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247d79;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
                return 0;
            }
            if (in_RDX == 0) {
                *in_R8 = (int64_t)iVar4;
                return 1;
            }
            if (*in_R8 < (uint64_t)(int64_t)iVar4) {
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247dae;
                fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247dc6;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar6), *(int64_t *)((int64_t)&arg_38h + iVar6));
                *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247dd8;
                fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
                return 0;
            }
        }
    // WARNING: Could not recover jumptable at 0x000180247e09. Too many branches
    // WARNING: Treating indirect jump as call
        uVar7 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x48))(in_RCX, in_RDX, in_R8, in_R9);
        return uVar7;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e11;
    fcn.180229480(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e29;
    fcn.1802295a0(*(int64_t *)((int64_t)&var_8h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6), 
                  *(int64_t *)((int64_t)&iStackX_20 + iVar6 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar6), 
                  *(int64_t *)((int64_t)&arg_38h + iVar6));
    *(undefined8 *)((int64_t)&uStack_20 + iVar6) = 0x180247e3b;
    fcn.1802296d0(*(int64_t *)(&stack0x00000028 + iVar6));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180247f40
// Address: 0x180247f40
// Size: 33 bytes
// ============================================================
int32_t fcn.180247f40(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h,
                     int64_t arg_a0h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int32_t *in_RCX;
    code *pcVar15;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x180247f4a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    iVar16 = 0x10;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x180248258;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar6 = 0;
    iVar10 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7) = 0;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024827d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248295;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482a7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar8 + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482cc;
    fcn.180259930();
    *in_RCX = iVar16;
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248435;
        fcn.180229b10();
        iVar9 = *(int64_t *)(in_RCX + 8);
        if (iVar9 == 0) {
code_r0x0001802485a2:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802485a7;
            fcn.1802299d0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802485b4;
            fcn.180257a00(*(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7));
            iVar12 = *(int64_t *)(in_RCX + 0x1e);
            *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7) = 0;
            if (iVar12 == 0) {
code_r0x000180248935:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024893a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248952;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
code_r0x000180248957:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248964;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                return -2;
            }
            if (iVar16 == 0x10) {
                if (*(int64_t *)(iVar12 + 0x48) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x40);
            } else if (iVar16 == 0x20) {
                if (*(int64_t *)(iVar12 + 0x58) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x50);
            } else {
                if (iVar16 != 0x40) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488eb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x0001802488f0;
                }
                if (*(int64_t *)(iVar12 + 0x68) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x60);
            }
            if (pcVar15 == (code *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488b8;
            iVar6 = (*pcVar15)(in_RCX);
            if (iVar6 < 1) goto code_r0x000180248915;
code_r0x0001802488be:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488c6;
            iVar6 = fcn.18025a1d0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000060 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000070 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000078 + iVar8 + iVar7));
code_r0x0001802488c8:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488d5;
            fcn.180257a00(*(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7));
            return iVar6;
        }
        if (*(int64_t *)(in_RCX + 0x22) == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248453;
            fcn.180229900();
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248458;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            goto code_r0x0001802482eb;
        }
        iVar14 = *(int64_t *)(*(int64_t *)(in_RCX + 0x22) + 0x60);
        if ((iVar14 != 0) && (iVar14 != iVar9)) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248475;
            fcn.180229900();
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024847a;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248492;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            goto code_r0x000180248908;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802484a6;
        iVar9 = fcn.18029f2b0(iVar9, 0xc);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar9;
        if (iVar9 != 0) {
            iVar5 = 1;
            do {
                if (iVar10 != 0) goto code_r0x0001802486a8;
                if (iVar12 != 0) {
                    LOCK();
                    piVar2 = (int32_t *)(iVar12 + 0x20);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 < 2) {
                        uVar4 = *(undefined8 *)(iVar12 + 8);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248506;
                        fcn.180224990(uVar4, 0x1804e42a0, 0x1d4);
                        uVar4 = *(undefined8 *)(iVar12 + 0x18);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024850f;
                        fcn.18027edb0(uVar4);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248524;
                        fcn.180224990(iVar12, 0x1804e42a0, 0x1d7);
                    }
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248531;
                fcn.180257a00(*(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7));
                if (iVar5 == 1) {
                    *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar7) = 0x1802489e0;
                    *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                    *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = 0x180248a40;
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248621;
                    iVar12 = fcn.180280c20(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                           *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7));
                    if (iVar12 != 0) goto code_r0x00018024862d;
                } else {
                    if (iVar5 == 2) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248559;
                        fcn.1801dd170(uVar4);
                        *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar7) = 0x1802489e0;
                        *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                        *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = 0x180248a40;
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248596;
                        iVar12 = fcn.180280ca0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000078 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7));
                        if (iVar12 == 0) goto code_r0x0001802485a2;
                    } else if (iVar12 == 0) goto code_r0x000180248689;
code_r0x00018024862d:
                    uVar4 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024863a;
                    fcn.1801dd6c0(uVar4);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248648;
                    iVar9 = fcn.180257b60(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) = iVar9;
                    if (iVar9 != 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248674;
                        iVar10 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_a0h + iVar8 + iVar7));
                    }
                    if (*(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248689;
                        fcn.180257a00(iVar9);
                    }
                }
code_r0x000180248689:
                iVar5 = iVar5 + 1;
            } while (iVar5 < 3);
            if (iVar10 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486a3;
                fcn.1802481d0(iVar12);
                goto code_r0x0001802485a2;
            }
code_r0x0001802486a8:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486ad;
            fcn.1802299d0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            goto code_r0x0001802486ad;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802484b5;
        fcn.180229900();
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802484ba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x0001802488f0:
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248903;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
    } else {
        if (*(int64_t *)(in_RCX + 0x22) != 0) {
            uVar4 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248319;
            fcn.1801dd6c0(uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248327;
            iVar9 = fcn.180257b60(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) = iVar9;
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248353;
                iVar10 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                       *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                       *(int64_t *)((int64_t)&arg_a0h + iVar8 + iVar7));
            }
            if (*(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248368;
                fcn.180257a00(iVar9);
            }
            if (iVar10 == 0) goto code_r0x0001802488c8;
            pcVar15 = *(code **)(iVar12 + 0x120);
            if (pcVar15 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024837f;
                piVar11 = (int64_t *)(*pcVar15)();
                iVar9 = *piVar11;
                while (iVar9 != 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024839b;
                    iVar5 = fcn.1802590b0(in_RCX, iVar9);
                    if (iVar5 != 0) {
                        if (*piVar11 != 0) goto code_r0x000180248427;
                        break;
                    }
                    piVar1 = piVar11 + 1;
                    piVar11 = piVar11 + 1;
                    iVar9 = *piVar1;
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483b8;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x0001802483bd:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483d0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                goto code_r0x000180248957;
            }
            uVar4 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483e3;
            fcn.1801dd6c0(uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483f4;
            iVar5 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000030 + iVar8 + iVar7));
            if (iVar5 == 0) {
                uVar4 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248406;
                fcn.18029f2b0(uVar4, 0xc);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248417;
                iVar5 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248420;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x0001802483bd;
                }
            }
code_r0x000180248427:
            LOCK();
            *(int32_t *)(iVar12 + 0x20) = *(int32_t *)(iVar12 + 0x20) + 1;
            UNLOCK();
code_r0x0001802486ad:
            uVar4 = *(undefined8 *)(in_RCX + 4);
            *(int64_t *)(in_RCX + 10) = iVar12;
            uVar13 = *(undefined8 *)(iVar12 + 0x18);
            pcVar15 = *(code **)(iVar12 + 0x28);
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar12 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar12 + 0x10);
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486d4;
            uVar13 = fcn.18027e810(uVar13);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486dc;
            iVar14 = (*pcVar15)(uVar13, uVar4);
            *(int64_t *)(in_RCX + 0xc) = iVar14;
            if (iVar14 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486ea;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x0001802488f0;
            }
            if (iVar16 == 0x10) {
                pcVar15 = *(code **)(iVar12 + 0x30);
                if (pcVar15 != (code *)0x0) {
code_r0x000180248853:
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248864;
                    iVar6 = (*pcVar15)(iVar14, iVar10, *(undefined8 *)((int64_t)&arg_a0h + iVar8 + iVar7));
                    if (iVar6 < 1) {
                        pcVar15 = *(code **)(iVar12 + 0xd0);
                        uVar4 = *(undefined8 *)(in_RCX + 0xc);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248877;
                        (*pcVar15)(uVar4);
                        *(undefined8 *)(in_RCX + 0xc) = 0;
                        goto code_r0x000180248915;
                    }
                    goto code_r0x0001802488be;
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248812;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024882a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else if (iVar16 == 0x20) {
                pcVar15 = *(code **)(iVar12 + 0x58);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487e3;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487fb;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else if (iVar16 == 0x40) {
                pcVar15 = *(code **)(iVar12 + 0x80);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487b4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487cc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else if (iVar16 == 0x4000) {
                pcVar15 = *(code **)(iVar12 + 0x40);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024877b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248793;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else {
                if (iVar16 != 0x8000) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248729;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x0001802488f0;
                }
                pcVar15 = *(code **)(iVar12 + 0x68);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248745;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024875d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            }
            *(int64_t *)((int64_t)&var_18h + iVar8 + iVar7) = iVar9;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248849;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            iVar6 = -2;
            goto code_r0x000180248915;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x0001802482eb:
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
    }
code_r0x000180248908:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248915;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
code_r0x000180248915:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024891d;
    fcn.180259930(in_RCX);
    uVar4 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248931;
    fcn.180257a00(uVar4);
    return iVar6;
}

// ============================================================
// Function: FUN_180247f70
// Address: 0x180247f70
// Size: 237 bytes
// ============================================================
uint64_t fcn.180247f70(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180247f7a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247f87;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247f9f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fb1;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    if ((*in_RCX != 0x20) && (*in_RCX != 0x8000)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fce;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fe6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247ff8;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 0xc);
    if (iVar1 == 0) {
        if ((*(int64_t *)(in_RCX + 0x1e) != 0) &&
           (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x58), UNRECOVERED_JUMPTABLE != (code *)0x0
           )) {
    // WARNING: Could not recover jumptable at 0x000180248021. Too many branches
    // WARNING: Treating indirect jump as call
            uVar5 = (*UNRECOVERED_JUMPTABLE)();
            return uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248029;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248041;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248053;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    iVar2 = *(int64_t *)(*(int64_t *)(in_RCX + 10) + 0x10);
    UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 10) + 0x60);
    iVar6 = 0x1805aadb1;
    if (iVar2 != 0) {
        iVar6 = iVar2;
    }
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024808b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480a3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480c2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_60h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480eb;
    uVar3 = (*UNRECOVERED_JUMPTABLE)(iVar1);
    if ((int32_t)uVar3 < 1) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480f6;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024810e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024812d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_18024805d
// Address: 0x18024805d
// Size: 121 bytes
// ============================================================
uint64_t fcn.180247f70(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180247f7a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247f87;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247f9f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fb1;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    if ((*in_RCX != 0x20) && (*in_RCX != 0x8000)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fce;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fe6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247ff8;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 0xc);
    if (iVar1 == 0) {
        if ((*(int64_t *)(in_RCX + 0x1e) != 0) &&
           (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x58), UNRECOVERED_JUMPTABLE != (code *)0x0
           )) {
    // WARNING: Could not recover jumptable at 0x000180248021. Too many branches
    // WARNING: Treating indirect jump as call
            uVar5 = (*UNRECOVERED_JUMPTABLE)();
            return uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248029;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248041;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248053;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    iVar2 = *(int64_t *)(*(int64_t *)(in_RCX + 10) + 0x10);
    UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 10) + 0x60);
    iVar6 = 0x1805aadb1;
    if (iVar2 != 0) {
        iVar6 = iVar2;
    }
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024808b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480a3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480c2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_60h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480eb;
    uVar3 = (*UNRECOVERED_JUMPTABLE)(iVar1);
    if ((int32_t)uVar3 < 1) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480f6;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024810e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024812d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_1802480d6
// Address: 0x1802480d6
// Size: 109 bytes
// ============================================================
uint64_t fcn.180247f70(int64_t arg_30h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h)
{
    int64_t iVar1;
    code *UNRECOVERED_JUMPTABLE;
    int64_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int32_t *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t iVar6;
    undefined8 unaff_RDI;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x180247f7a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247f87;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247f9f;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fb1;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    if ((*in_RCX != 0x20) && (*in_RCX != 0x8000)) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fce;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247fe6;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180247ff8;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xffffffff;
    }
    iVar1 = *(int64_t *)(in_RCX + 0xc);
    if (iVar1 == 0) {
        if ((*(int64_t *)(in_RCX + 0x1e) != 0) &&
           (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0x58), UNRECOVERED_JUMPTABLE != (code *)0x0
           )) {
    // WARNING: Could not recover jumptable at 0x000180248021. Too many branches
    // WARNING: Treating indirect jump as call
            uVar5 = (*UNRECOVERED_JUMPTABLE)();
            return uVar5;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248029;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248041;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x180248053;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_48h + iVar4) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RDI;
    iVar2 = *(int64_t *)(*(int64_t *)(in_RCX + 10) + 0x10);
    UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 10) + 0x60);
    iVar6 = 0x1805aadb1;
    if (iVar2 != 0) {
        iVar6 = iVar2;
    }
    if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024808b;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480a3;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480c2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&var_20h + iVar4) = *(undefined8 *)((int64_t)&arg_60h + iVar4);
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480eb;
    uVar3 = (*UNRECOVERED_JUMPTABLE)(iVar1);
    if ((int32_t)uVar3 < 1) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x1802480f6;
        fcn.180229480(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024810e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)(&stack0x00000028 + iVar4), 
                      *(int64_t *)((int64_t)&arg_30h + iVar4), *(int64_t *)(&stack0x00000038 + iVar4), 
                      *(int64_t *)(&stack0x00000050 + iVar4));
        *(int64_t *)((int64_t)&var_20h + iVar4) = iVar6;
        *(undefined8 *)((int64_t)&uStack_8 + iVar4) = 0x18024812d;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_40h + iVar4));
    }
    return (uint64_t)uVar3;
}

// ============================================================
// Function: FUN_180248150
// Address: 0x180248150
// Size: 33 bytes
// ============================================================
int32_t fcn.180248150(int32_t *param_1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    code *pcVar15;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t aiStack_10 [2];
    
    aiStack_10[1] = 0x18024815a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    iVar16 = 0x20;
    *(undefined8 *)(&stack0x00000048 + iVar7) = 0;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R13;
    *(undefined8 *)((int64_t)aiStack_10 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)aiStack_10 + iVar7) = 0x180248258;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar6 = 0;
    iVar10 = 0;
    *(undefined8 *)(&stack0x00000088 + iVar8 + iVar7) = 0;
    if (param_1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024827d;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248295;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802482a7;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        return -1;
    }
    *(undefined8 *)(&stack0x00000098 + iVar8 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000048 + iVar8 + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802482cc;
    fcn.180259930();
    *param_1 = iVar16;
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248435;
        fcn.180229b10();
        iVar9 = *(int64_t *)(param_1 + 8);
        if (iVar9 == 0) {
code_r0x0001802485a2:
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802485a7;
            fcn.1802299d0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802485b4;
            fcn.180257a00(*(undefined8 *)(&stack0x00000088 + iVar8 + iVar7));
            iVar12 = *(int64_t *)(param_1 + 0x1e);
            *(undefined8 *)(&stack0x00000088 + iVar8 + iVar7) = 0;
            if (iVar12 == 0) {
code_r0x000180248935:
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024893a;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248952;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
code_r0x000180248957:
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248964;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                return -2;
            }
            if (iVar16 == 0x10) {
                if (*(int64_t *)(iVar12 + 0x48) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x40);
            } else if (iVar16 == 0x20) {
                if (*(int64_t *)(iVar12 + 0x58) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x50);
            } else {
                if (iVar16 != 0x40) {
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802488eb;
                    fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                    goto code_r0x0001802488f0;
                }
                if (*(int64_t *)(iVar12 + 0x68) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x60);
            }
            if (pcVar15 == (code *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802488b8;
            iVar6 = (*pcVar15)(param_1);
            if (iVar6 < 1) goto code_r0x000180248915;
code_r0x0001802488be:
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802488c6;
            iVar6 = fcn.18025a1d0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000060 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000070 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000078 + iVar8 + iVar7));
code_r0x0001802488c8:
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802488d5;
            fcn.180257a00(*(undefined8 *)(&stack0x00000088 + iVar8 + iVar7));
            return iVar6;
        }
        if (*(int64_t *)(param_1 + 0x22) == 0) {
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248453;
            fcn.180229900();
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248458;
            fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                         );
            goto code_r0x0001802482eb;
        }
        iVar14 = *(int64_t *)(*(int64_t *)(param_1 + 0x22) + 0x60);
        if ((iVar14 != 0) && (iVar14 != iVar9)) {
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248475;
            fcn.180229900();
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024847a;
            fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248492;
            fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7)
                         );
            goto code_r0x000180248908;
        }
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802484a6;
        iVar9 = fcn.18029f2b0(iVar9, 0xc);
        *(int64_t *)(&stack0x00000038 + iVar8 + iVar7) = iVar9;
        if (iVar9 != 0) {
            iVar5 = 1;
            do {
                if (iVar10 != 0) goto code_r0x0001802486a8;
                if (iVar12 != 0) {
                    LOCK();
                    piVar2 = (int32_t *)(iVar12 + 0x20);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 < 2) {
                        uVar4 = *(undefined8 *)(iVar12 + 8);
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248506;
                        fcn.180224990(uVar4, 0x1804e42a0, 0x1d4);
                        uVar4 = *(undefined8 *)(iVar12 + 0x18);
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024850f;
                        fcn.18027edb0(uVar4);
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248524;
                        fcn.180224990(iVar12, 0x1804e42a0, 0x1d7);
                    }
                }
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248531;
                fcn.180257a00(*(undefined8 *)(&stack0x00000088 + iVar8 + iVar7));
                if (iVar5 == 1) {
                    *(undefined8 *)(&stack0x00000028 + iVar8 + iVar7) = 0x1802489e0;
                    *(undefined8 *)(&stack0x00000020 + iVar8 + iVar7) = 0x180248230;
                    *(undefined8 *)(&stack0x00000018 + iVar8 + iVar7) = 0x180248a40;
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248621;
                    iVar12 = fcn.180280c20(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7));
                    if (iVar12 != 0) goto code_r0x00018024862d;
                } else {
                    if (iVar5 == 2) {
                        uVar4 = *(undefined8 *)(param_1 + 8);
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248559;
                        fcn.1801dd170(uVar4);
                        *(undefined8 *)(&stack0x00000028 + iVar8 + iVar7) = 0x1802489e0;
                        *(undefined8 *)(&stack0x00000020 + iVar8 + iVar7) = 0x180248230;
                        *(undefined8 *)(&stack0x00000018 + iVar8 + iVar7) = 0x180248a40;
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248596;
                        iVar12 = fcn.180280ca0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000048 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000078 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7));
                        if (iVar12 == 0) goto code_r0x0001802485a2;
                    } else if (iVar12 == 0) goto code_r0x000180248689;
code_r0x00018024862d:
                    uVar4 = *(undefined8 *)(param_1 + 8);
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024863a;
                    fcn.1801dd6c0(uVar4);
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248648;
                    iVar9 = fcn.180257b60(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                          *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                    *(int64_t *)(&stack0x00000088 + iVar8 + iVar7) = iVar9;
                    if (iVar9 != 0) {
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248674;
                        iVar10 = fcn.180230ea0(*(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000a0 + iVar8 + iVar7));
                    }
                    if (*(int64_t *)(&stack0x00000088 + iVar8 + iVar7) == 0) {
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248689;
                        fcn.180257a00(iVar9);
                    }
                }
code_r0x000180248689:
                iVar5 = iVar5 + 1;
            } while (iVar5 < 3);
            if (iVar10 == 0) {
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802486a3;
                fcn.1802481d0(iVar12);
                goto code_r0x0001802485a2;
            }
code_r0x0001802486a8:
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802486ad;
            fcn.1802299d0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                         );
            goto code_r0x0001802486ad;
        }
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802484b5;
        fcn.180229900();
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802484ba;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
code_r0x0001802488f0:
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248903;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
    } else {
        if (*(int64_t *)(param_1 + 0x22) != 0) {
            uVar4 = *(undefined8 *)(param_1 + 8);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248319;
            fcn.1801dd6c0(uVar4);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248327;
            iVar9 = fcn.180257b60(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
            *(int64_t *)(&stack0x00000088 + iVar8 + iVar7) = iVar9;
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248353;
                iVar10 = fcn.180230ea0(*(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x000000a0 + iVar8 + iVar7));
            }
            if (*(int64_t *)(&stack0x00000088 + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248368;
                fcn.180257a00(iVar9);
            }
            if (iVar10 == 0) goto code_r0x0001802488c8;
            pcVar15 = *(code **)(iVar12 + 0x120);
            if (pcVar15 != (code *)0x0) {
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024837f;
                piVar11 = (int64_t *)(*pcVar15)();
                iVar9 = *piVar11;
                while (iVar9 != 0) {
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024839b;
                    iVar5 = fcn.1802590b0(param_1, iVar9);
                    if (iVar5 != 0) {
                        if (*piVar11 != 0) goto code_r0x000180248427;
                        break;
                    }
                    piVar1 = piVar11 + 1;
                    piVar11 = piVar11 + 1;
                    iVar9 = *piVar1;
                }
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802483b8;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
code_r0x0001802483bd:
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802483d0;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
                goto code_r0x000180248957;
            }
            uVar4 = *(undefined8 *)(param_1 + 8);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802483e3;
            fcn.1801dd6c0(uVar4);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802483f4;
            iVar5 = fcn.180280ea0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000030 + iVar8 + iVar7));
            if (iVar5 == 0) {
                uVar4 = *(undefined8 *)(param_1 + 8);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248406;
                fcn.18029f2b0(uVar4, 0xc);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248417;
                iVar5 = fcn.180280ea0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248420;
                    fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                    goto code_r0x0001802483bd;
                }
            }
code_r0x000180248427:
            LOCK();
            *(int32_t *)(iVar12 + 0x20) = *(int32_t *)(iVar12 + 0x20) + 1;
            UNLOCK();
code_r0x0001802486ad:
            uVar4 = *(undefined8 *)(param_1 + 4);
            *(int64_t *)(param_1 + 10) = iVar12;
            uVar13 = *(undefined8 *)(iVar12 + 0x18);
            pcVar15 = *(code **)(iVar12 + 0x28);
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar12 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar12 + 0x10);
            }
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802486d4;
            uVar13 = fcn.18027e810(uVar13);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802486dc;
            iVar14 = (*pcVar15)(uVar13, uVar4);
            *(int64_t *)(param_1 + 0xc) = iVar14;
            if (iVar14 == 0) {
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802486ea;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                goto code_r0x0001802488f0;
            }
            if (iVar16 == 0x10) {
                pcVar15 = *(code **)(iVar12 + 0x30);
                if (pcVar15 != (code *)0x0) {
code_r0x000180248853:
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248864;
                    iVar6 = (*pcVar15)(iVar14, iVar10, *(undefined8 *)(&stack0x000000a0 + iVar8 + iVar7));
                    if (iVar6 < 1) {
                        pcVar15 = *(code **)(iVar12 + 0xd0);
                        uVar4 = *(undefined8 *)(param_1 + 0xc);
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248877;
                        (*pcVar15)(uVar4);
                        *(undefined8 *)(param_1 + 0xc) = 0;
                        goto code_r0x000180248915;
                    }
                    goto code_r0x0001802488be;
                }
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248812;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024882a;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
            } else if (iVar16 == 0x20) {
                pcVar15 = *(code **)(iVar12 + 0x58);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802487e3;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802487fb;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
            } else if (iVar16 == 0x40) {
                pcVar15 = *(code **)(iVar12 + 0x80);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802487b4;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802487cc;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
            } else if (iVar16 == 0x4000) {
                pcVar15 = *(code **)(iVar12 + 0x40);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024877b;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248793;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
            } else {
                if (iVar16 != 0x8000) {
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248729;
                    fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                    goto code_r0x0001802488f0;
                }
                pcVar15 = *(code **)(iVar12 + 0x68);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248745;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024875d;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
            }
            *(int64_t *)(&stack0x00000018 + iVar8 + iVar7) = iVar9;
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248849;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            iVar6 = -2;
            goto code_r0x000180248915;
        }
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802482e6;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
code_r0x0001802482eb:
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x1802482fe;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
    }
code_r0x000180248908:
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248915;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
code_r0x000180248915:
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18024891d;
    fcn.180259930(param_1);
    uVar4 = *(undefined8 *)(&stack0x00000088 + iVar8 + iVar7);
    *param_1 = 0;
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x180248931;
    fcn.180257a00(uVar4);
    return iVar6;
}

// ============================================================
// Function: FUN_180248180
// Address: 0x180248180
// Size: 70 bytes
// ============================================================
void fcn.180248180(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024818a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x1802489e0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180248230;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180248a40;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802481c1;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802481d0
// Address: 0x1802481d0
// Size: 95 bytes
// ============================================================
void fcn.1802481d0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802481e0;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024820b;
            fcn.180224990(uVar3, 0x1804e42a0, 0x1d4);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180248214;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180248229;
            fcn.180224990(arg1, 0x1804e42a0, 0x1d7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180248240
// Address: 0x180248240
// Size: 1860 bytes
// ============================================================
int32_t fcn.180247f40(int64_t arg_28h, int64_t arg_38h, int64_t arg_48h, int64_t arg_88h, int64_t arg_98h,
                     int64_t arg_a0h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int32_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t iVar12;
    undefined8 uVar13;
    int64_t iVar14;
    int32_t *in_RCX;
    code *pcVar15;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t iVar16;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x180247f4a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar12 = 0;
    iVar16 = 0x10;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBP;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x180248258;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar6 = 0;
    iVar10 = 0;
    *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7) = 0;
    if (in_RCX == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024827d;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248295;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482a7;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return -1;
    }
    *(undefined8 *)((int64_t)&arg_98h + iVar8 + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar8 + iVar7) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482cc;
    fcn.180259930();
    *in_RCX = iVar16;
    if (iVar12 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248435;
        fcn.180229b10();
        iVar9 = *(int64_t *)(in_RCX + 8);
        if (iVar9 == 0) {
code_r0x0001802485a2:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802485a7;
            fcn.1802299d0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802485b4;
            fcn.180257a00(*(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7));
            iVar12 = *(int64_t *)(in_RCX + 0x1e);
            *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7) = 0;
            if (iVar12 == 0) {
code_r0x000180248935:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024893a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248952;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
code_r0x000180248957:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248964;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                return -2;
            }
            if (iVar16 == 0x10) {
                if (*(int64_t *)(iVar12 + 0x48) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x40);
            } else if (iVar16 == 0x20) {
                if (*(int64_t *)(iVar12 + 0x58) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x50);
            } else {
                if (iVar16 != 0x40) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488eb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x0001802488f0;
                }
                if (*(int64_t *)(iVar12 + 0x68) == 0) goto code_r0x000180248935;
                pcVar15 = *(code **)(iVar12 + 0x60);
            }
            if (pcVar15 == (code *)0x0) {
                return 1;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488b8;
            iVar6 = (*pcVar15)(in_RCX);
            if (iVar6 < 1) goto code_r0x000180248915;
code_r0x0001802488be:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488c6;
            iVar6 = fcn.18025a1d0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000060 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000068 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000070 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000078 + iVar8 + iVar7));
code_r0x0001802488c8:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802488d5;
            fcn.180257a00(*(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7));
            return iVar6;
        }
        if (*(int64_t *)(in_RCX + 0x22) == 0) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248453;
            fcn.180229900();
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248458;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            goto code_r0x0001802482eb;
        }
        iVar14 = *(int64_t *)(*(int64_t *)(in_RCX + 0x22) + 0x60);
        if ((iVar14 != 0) && (iVar14 != iVar9)) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248475;
            fcn.180229900();
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024847a;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248492;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            goto code_r0x000180248908;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802484a6;
        iVar9 = fcn.18029f2b0(iVar9, 0xc);
        *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar9;
        if (iVar9 != 0) {
            iVar5 = 1;
            do {
                if (iVar10 != 0) goto code_r0x0001802486a8;
                if (iVar12 != 0) {
                    LOCK();
                    piVar2 = (int32_t *)(iVar12 + 0x20);
                    iVar3 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar3 < 2) {
                        uVar4 = *(undefined8 *)(iVar12 + 8);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248506;
                        fcn.180224990(uVar4, 0x1804e42a0, 0x1d4);
                        uVar4 = *(undefined8 *)(iVar12 + 0x18);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024850f;
                        fcn.18027edb0(uVar4);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248524;
                        fcn.180224990(iVar12, 0x1804e42a0, 0x1d7);
                    }
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248531;
                fcn.180257a00(*(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7));
                if (iVar5 == 1) {
                    *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar7) = 0x1802489e0;
                    *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                    *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = 0x180248a40;
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248621;
                    iVar12 = fcn.180280c20(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                           *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                           *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                           *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7), 
                                           *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7));
                    if (iVar12 != 0) goto code_r0x00018024862d;
                } else {
                    if (iVar5 == 2) {
                        uVar4 = *(undefined8 *)(in_RCX + 8);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248559;
                        fcn.1801dd170(uVar4);
                        *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar7) = 0x1802489e0;
                        *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                        *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = 0x180248a40;
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248596;
                        iVar12 = fcn.180280ca0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000078 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000b0 + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x000000b8 + iVar8 + iVar7));
                        if (iVar12 == 0) goto code_r0x0001802485a2;
                    } else if (iVar12 == 0) goto code_r0x000180248689;
code_r0x00018024862d:
                    uVar4 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024863a;
                    fcn.1801dd6c0(uVar4);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248648;
                    iVar9 = fcn.180257b60(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) = iVar9;
                    if (iVar9 != 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248674;
                        iVar10 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                                               *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                               *(int64_t *)((int64_t)&arg_a0h + iVar8 + iVar7));
                    }
                    if (*(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248689;
                        fcn.180257a00(iVar9);
                    }
                }
code_r0x000180248689:
                iVar5 = iVar5 + 1;
            } while (iVar5 < 3);
            if (iVar10 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486a3;
                fcn.1802481d0(iVar12);
                goto code_r0x0001802485a2;
            }
code_r0x0001802486a8:
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486ad;
            fcn.1802299d0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            goto code_r0x0001802486ad;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802484b5;
        fcn.180229900();
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802484ba;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x0001802488f0:
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248903;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
    } else {
        if (*(int64_t *)(in_RCX + 0x22) != 0) {
            uVar4 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248319;
            fcn.1801dd6c0(uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248327;
            iVar9 = fcn.180257b60(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) = iVar9;
            if (iVar9 != 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248353;
                iVar10 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                       *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7), 
                                       *(int64_t *)(&stack0x00000040 + iVar8 + iVar7), 
                                       *(int64_t *)((int64_t)&arg_a0h + iVar8 + iVar7));
            }
            if (*(int64_t *)((int64_t)&arg_88h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248368;
                fcn.180257a00(iVar9);
            }
            if (iVar10 == 0) goto code_r0x0001802488c8;
            pcVar15 = *(code **)(iVar12 + 0x120);
            if (pcVar15 != (code *)0x0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024837f;
                piVar11 = (int64_t *)(*pcVar15)();
                iVar9 = *piVar11;
                while (iVar9 != 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024839b;
                    iVar5 = fcn.1802590b0(in_RCX, iVar9);
                    if (iVar5 != 0) {
                        if (*piVar11 != 0) goto code_r0x000180248427;
                        break;
                    }
                    piVar1 = piVar11 + 1;
                    piVar11 = piVar11 + 1;
                    iVar9 = *piVar1;
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483b8;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x0001802483bd:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483d0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                goto code_r0x000180248957;
            }
            uVar4 = *(undefined8 *)(in_RCX + 8);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483e3;
            fcn.1801dd6c0(uVar4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802483f4;
            iVar5 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000030 + iVar8 + iVar7));
            if (iVar5 == 0) {
                uVar4 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248406;
                fcn.18029f2b0(uVar4, 0xc);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248417;
                iVar5 = fcn.180280ea0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7));
                if (iVar5 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248420;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x0001802483bd;
                }
            }
code_r0x000180248427:
            LOCK();
            *(int32_t *)(iVar12 + 0x20) = *(int32_t *)(iVar12 + 0x20) + 1;
            UNLOCK();
code_r0x0001802486ad:
            uVar4 = *(undefined8 *)(in_RCX + 4);
            *(int64_t *)(in_RCX + 10) = iVar12;
            uVar13 = *(undefined8 *)(iVar12 + 0x18);
            pcVar15 = *(code **)(iVar12 + 0x28);
            iVar9 = 0x1805aadb1;
            if (*(int64_t *)(iVar12 + 0x10) != 0) {
                iVar9 = *(int64_t *)(iVar12 + 0x10);
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486d4;
            uVar13 = fcn.18027e810(uVar13);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486dc;
            iVar14 = (*pcVar15)(uVar13, uVar4);
            *(int64_t *)(in_RCX + 0xc) = iVar14;
            if (iVar14 == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802486ea;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x0001802488f0;
            }
            if (iVar16 == 0x10) {
                pcVar15 = *(code **)(iVar12 + 0x30);
                if (pcVar15 != (code *)0x0) {
code_r0x000180248853:
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248864;
                    iVar6 = (*pcVar15)(iVar14, iVar10, *(undefined8 *)((int64_t)&arg_a0h + iVar8 + iVar7));
                    if (iVar6 < 1) {
                        pcVar15 = *(code **)(iVar12 + 0xd0);
                        uVar4 = *(undefined8 *)(in_RCX + 0xc);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248877;
                        (*pcVar15)(uVar4);
                        *(undefined8 *)(in_RCX + 0xc) = 0;
                        goto code_r0x000180248915;
                    }
                    goto code_r0x0001802488be;
                }
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248812;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024882a;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else if (iVar16 == 0x20) {
                pcVar15 = *(code **)(iVar12 + 0x58);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487e3;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487fb;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else if (iVar16 == 0x40) {
                pcVar15 = *(code **)(iVar12 + 0x80);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487b4;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802487cc;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else if (iVar16 == 0x4000) {
                pcVar15 = *(code **)(iVar12 + 0x40);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024877b;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248793;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            } else {
                if (iVar16 != 0x8000) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248729;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x0001802488f0;
                }
                pcVar15 = *(code **)(iVar12 + 0x68);
                if (pcVar15 != (code *)0x0) goto code_r0x000180248853;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248745;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024875d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            }
            *(int64_t *)((int64_t)&var_18h + iVar8 + iVar7) = iVar9;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248849;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            iVar6 = -2;
            goto code_r0x000180248915;
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482e6;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x0001802482eb:
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x1802482fe;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
    }
code_r0x000180248908:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248915;
    fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
code_r0x000180248915:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18024891d;
    fcn.180259930(in_RCX);
    uVar4 = *(undefined8 *)((int64_t)&arg_88h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x180248931;
    fcn.180257a00(uVar4);
    return iVar6;
}

// ============================================================
// Function: FUN_180248990
// Address: 0x180248990
// Size: 70 bytes
// ============================================================
void fcn.180248990(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024899a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x1802489e0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180248230;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x180248a40;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1802489d1;
    fcn.180280ca0(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x00000080 + iVar1), *(int64_t *)(&stack0x000000b0 + iVar1), 
                  *(int64_t *)(&stack0x000000b8 + iVar1), *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1802489e0
// Address: 0x1802489e0
// Size: 95 bytes
// ============================================================
void fcn.1802489e0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1802489f0;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180248a1b;
            fcn.180224990(uVar3, 0x1804e42a0, 0x1d4);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180248a24;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180248a39;
            fcn.180224990(arg1, 0x1804e42a0, 0x1d7);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180248a40
// Address: 0x180248a40
// Size: 2944 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.

undefined4 * fcn.180248a40(int64_t arg_58h, int64_t arg_60h, int64_t arg_70h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 in_ECX;
    int64_t in_RDX;
    undefined8 *puVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    undefined8 in_R8;
    int32_t iVar12;
    int32_t iVar13;
    int32_t iVar14;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_40;
    int64_t var_18h;
    
    uStack_40 = 0x180248a5a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar8 = 0;
    *(undefined4 *)((int64_t)&arg_60h + iVar4) = 0;
    iVar13 = 0;
    iVar14 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180248a90;
    puVar5 = (undefined4 *)fcn.180224d60(*(int64_t *)((int64_t)&var_18h + iVar4));
    if (puVar5 == (undefined4 *)0x0) {
code_r0x0001802494f6:
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802494fb;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249513;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18)
                      , *(int64_t *)((int64_t)aiStackX_18 + iVar4));
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249525;
        fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
        return (undefined4 *)0x0;
    }
    puVar5[8] = 1;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180248aab;
    iVar3 = func_0x00018027fb30(in_R8);
    if (iVar3 == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802494f6;
        fcn.180224990(puVar5, 0x1804e42a0, 0x2b);
        goto code_r0x0001802494f6;
    }
    *(undefined8 *)(puVar5 + 6) = in_R8;
    *puVar5 = in_ECX;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180248ac4;
    iVar6 = func_0x000180282210(in_RDX);
    *(int64_t *)(puVar5 + 2) = iVar6;
    if (iVar6 == 0) goto code_r0x00018024949c;
    iVar6 = *(int64_t *)(in_RDX + 0x18);
    *(int64_t *)(puVar5 + 4) = iVar6;
    iVar10 = 0x1805aadb1;
    if (iVar6 != 0) {
        iVar10 = iVar6;
    }
    iVar3 = *piVar1;
    *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18) = iVar10;
    if (iVar3 == 0) {
code_r0x00018024945f:
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249464;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024947c;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18)
                      , *(int64_t *)((int64_t)aiStackX_18 + iVar4));
    } else {
        puVar7 = (undefined8 *)(piVar1 + 2);
        iVar9 = 0;
        iVar12 = 0;
        do {
    // switch table (32 cases) at 0x180249540
            switch(iVar3) {
            case 1:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 10) == 0) {
                    iVar13 = iVar13 + 1;
                    *(undefined8 *)(puVar5 + 10) = *puVar7;
                }
                break;
            case 2:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0xc) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0xc) = *puVar7;
                }
                break;
            case 3:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0xe) == 0) {
                    *(undefined8 *)(puVar5 + 0xe) = *puVar7;
                }
                break;
            case 4:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x16) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0x16) = *puVar7;
                }
                break;
            case 5:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x18) == 0) {
                    *(undefined8 *)(puVar5 + 0x18) = *puVar7;
                }
                break;
            case 6:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x20) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0x20) = *puVar7;
                }
                break;
            case 7:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x22) == 0) {
                    *(undefined8 *)(puVar5 + 0x22) = *puVar7;
                }
                break;
            case 8:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x24) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0x24) = *puVar7;
                }
                break;
            case 9:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x26) == 0) {
                    *(undefined8 *)(puVar5 + 0x26) = *puVar7;
                }
                break;
            case 10:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x28) == 0) {
                    *(undefined8 *)(puVar5 + 0x28) = *puVar7;
                }
                break;
            case 0xb:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x2a) == 0) {
                    *(undefined8 *)(puVar5 + 0x2a) = *puVar7;
                }
                break;
            case 0xc:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x2c) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0x2c) = *puVar7;
                }
                break;
            case 0xd:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x2e) == 0) {
                    *(undefined8 *)(puVar5 + 0x2e) = *puVar7;
                }
                break;
            case 0xe:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x30) == 0) {
                    *(undefined8 *)(puVar5 + 0x30) = *puVar7;
                }
                break;
            case 0xf:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x32) == 0) {
                    *(undefined8 *)(puVar5 + 0x32) = *puVar7;
                }
                break;
            case 0x10:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x34) == 0) {
                    iVar13 = iVar13 + 1;
                    *(undefined8 *)(puVar5 + 0x34) = *puVar7;
                }
                break;
            case 0x11:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x36) == 0) {
                    *(undefined8 *)(puVar5 + 0x36) = *puVar7;
                }
                break;
            case 0x12:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x38) == 0) {
                    iVar8 = iVar8 + 1;
                    *(undefined8 *)(puVar5 + 0x38) = *puVar7;
                }
                break;
            case 0x13:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x3a) == 0) {
                    iVar8 = iVar8 + 1;
                    *(undefined8 *)(puVar5 + 0x3a) = *puVar7;
                }
                break;
            case 0x14:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x3c) == 0) {
                    iVar9 = iVar9 + 1;
                    *(undefined8 *)(puVar5 + 0x3c) = *puVar7;
                }
                break;
            case 0x15:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x3e) == 0) {
                    iVar9 = iVar9 + 1;
                    *(undefined8 *)(puVar5 + 0x3e) = *puVar7;
                }
                break;
            case 0x16:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x40) == 0) {
                    iVar12 = iVar12 + 1;
                    *(undefined8 *)(puVar5 + 0x40) = *puVar7;
                }
                break;
            case 0x17:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x42) == 0) {
                    iVar12 = iVar12 + 1;
                    *(undefined8 *)(puVar5 + 0x42) = *puVar7;
                }
                break;
            case 0x18:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x44) == 0) {
                    uVar11 = uVar11 + 1;
                    *(undefined8 *)(puVar5 + 0x44) = *puVar7;
                    *(uint32_t *)((int64_t)&arg_60h + iVar4) = uVar11;
                }
                break;
            case 0x19:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x46) == 0) {
                    uVar11 = uVar11 + 1;
                    *(undefined8 *)(puVar5 + 0x46) = *puVar7;
                    *(uint32_t *)((int64_t)&arg_60h + iVar4) = uVar11;
                }
                break;
            case 0x1a:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x48) == 0) {
                    *(undefined8 *)(puVar5 + 0x48) = *puVar7;
                }
                break;
            case 0x1b:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x10) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0x10) = *puVar7;
                }
                break;
            case 0x1c:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x12) == 0) {
                    *(undefined8 *)(puVar5 + 0x12) = *puVar7;
                }
                break;
            case 0x1d:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x14) == 0) {
                    *(undefined8 *)(puVar5 + 0x14) = *puVar7;
                }
                break;
            case 0x1e:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x1a) == 0) {
                    iVar14 = iVar14 + 1;
                    *(undefined8 *)(puVar5 + 0x1a) = *puVar7;
                }
                break;
            case 0x1f:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x1c) == 0) {
                    *(undefined8 *)(puVar5 + 0x1c) = *puVar7;
                }
                break;
            case 0x20:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
                if (*(int64_t *)(puVar5 + 0x1e) == 0) {
                    *(undefined8 *)(puVar5 + 0x1e) = *puVar7;
                }
                break;
            default:
                uVar11 = *(uint32_t *)((int64_t)&arg_60h + iVar4);
            }
            iVar3 = *(int32_t *)(puVar7 + 1);
            puVar7 = puVar7 + 2;
        } while (iVar3 != 0);
        *(int32_t *)(&stack0xfffffffffffffffc + iVar4) = iVar12;
        *(int32_t *)(&stack0xfffffffffffffff8 + iVar4) = iVar9;
        iVar10 = *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18);
        *(int32_t *)((int64_t)&arg_70h + iVar4) = iVar8;
        if (iVar13 != 2) goto code_r0x00018024945f;
        if (((((*(uint32_t *)((int64_t)&arg_70h + iVar4) & 0xfffffffd) == 0) &&
             ((*(uint32_t *)(&stack0xfffffffffffffff8 + iVar4) & 0xfffffffd) == 0)) &&
            ((*(uint32_t *)(&stack0xfffffffffffffffc + iVar4) & 0xfffffffd) == 0)) && ((uVar11 & 0xfffffffd) == 0)) {
            if (iVar14 == 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024902e;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249046;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            } else if ((*(int64_t *)(puVar5 + 0xc) == 0) || (*(int64_t *)(puVar5 + 0xe) != 0)) {
                if (*(int64_t *)(puVar5 + 0x10) == 0) {
code_r0x0001802490ad:
                    if ((*(int64_t *)(puVar5 + 0xe) != 0) ||
                       ((*(int64_t *)(puVar5 + 0x12) != 0 || (*(int64_t *)(puVar5 + 0x14) != 0))))
                    goto code_r0x0001802490bf;
                } else {
                    if (*(int64_t *)(puVar5 + 0xe) == 0) {
                        if ((*(int64_t *)(puVar5 + 0x12) == 0) || (*(int64_t *)(puVar5 + 0x14) == 0))
                        goto code_r0x000180249080;
                        goto code_r0x0001802490ad;
                    }
code_r0x0001802490bf:
                    if ((*(int64_t *)(puVar5 + 0xc) == 0) && (*(int64_t *)(puVar5 + 0x10) == 0)) {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802490ce;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802490e6;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                        goto code_r0x000180249488;
                    }
                }
                if ((*(int64_t *)(puVar5 + 0x16) == 0) || (*(int64_t *)(puVar5 + 0x18) != 0)) {
                    if (*(int64_t *)(puVar5 + 0x1a) == 0) {
code_r0x00018024914d:
                        if ((*(int64_t *)(puVar5 + 0x18) != 0) ||
                           ((*(int64_t *)(puVar5 + 0x1c) != 0 || (*(int64_t *)(puVar5 + 0x1e) != 0))))
                        goto code_r0x00018024915f;
                    } else {
                        if (*(int64_t *)(puVar5 + 0x18) == 0) {
                            if ((*(int64_t *)(puVar5 + 0x1c) == 0) || (*(int64_t *)(puVar5 + 0x1e) == 0))
                            goto code_r0x000180249120;
                            goto code_r0x00018024914d;
                        }
code_r0x00018024915f:
                        if ((*(int64_t *)(puVar5 + 0x16) == 0) && (*(int64_t *)(puVar5 + 0x1a) == 0)) {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024916e;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249186;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                            goto code_r0x000180249488;
                        }
                    }
                    if ((*(int64_t *)(puVar5 + 0x20) == 0) || (*(int64_t *)(puVar5 + 0x22) != 0)) {
                        if (((*(int64_t *)(puVar5 + 0x24) == 0) || (*(int64_t *)(puVar5 + 0x2a) != 0)) ||
                           ((*(int64_t *)(puVar5 + 0x26) != 0 && (*(int64_t *)(puVar5 + 0x28) != 0)))) {
                            if ((*(int64_t *)(puVar5 + 0x2c) == 0) ||
                               ((*(int64_t *)(puVar5 + 0x32) != 0 ||
                                ((*(int64_t *)(puVar5 + 0x2e) != 0 && (*(int64_t *)(puVar5 + 0x30) != 0)))))) {
                                if (((*(int64_t *)(puVar5 + 0x2a) == 0) &&
                                    ((*(int64_t *)(puVar5 + 0x26) == 0 && (*(int64_t *)(puVar5 + 0x28) == 0)))) ||
                                   (*(int64_t *)(puVar5 + 0x24) != 0)) {
                                    if ((((*(int64_t *)(puVar5 + 0x32) == 0) && (*(int64_t *)(puVar5 + 0x2e) == 0)) &&
                                        (*(int64_t *)(puVar5 + 0x30) == 0)) || (*(int64_t *)(puVar5 + 0x2c) != 0)) {
                                        if ((*(int64_t *)(puVar5 + 0x12) == 0) == (*(int64_t *)(puVar5 + 0x14) == 0)) {
                                            if ((*(int64_t *)(puVar5 + 0x1c) == 0) == (*(int64_t *)(puVar5 + 0x1e) == 0)
                                               ) {
                                                if ((*(int64_t *)(puVar5 + 0x26) == 0) ==
                                                    (*(int64_t *)(puVar5 + 0x28) == 0)) {
                                                    if ((*(int64_t *)(puVar5 + 0x2e) == 0) ==
                                                        (*(int64_t *)(puVar5 + 0x30) == 0)) {
                                                        return puVar5;
                                                    }
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249408;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249420;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                                                } else {
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802493c0;
                                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802493d8;
                                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                                                }
                                            } else {
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249377;
                                                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024938f;
                                                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                                            }
                                        } else {
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249334;
                                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024934c;
                                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                                        }
                                    } else {
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802492f1;
                                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249309;
                                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                                    }
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802492a0;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802492b8;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024924f;
                                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249267;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802491fe;
                            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249216;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                          *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802491ad;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802491c5;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                      *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                    }
                } else {
code_r0x000180249120:
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249125;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024913d;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar4));
                }
            } else {
code_r0x000180249080:
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249085;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024909d;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), 
                              *(int64_t *)((int64_t)aiStackX_18 + iVar4));
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024943a;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x180249452;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), 
                          *(int64_t *)((int64_t)aiStackX_18 + iVar4 + -0x18), *(int64_t *)((int64_t)aiStackX_18 + iVar4)
                         );
        }
    }
code_r0x000180249488:
    *(int64_t *)((int64_t)&var_18h + iVar4) = iVar10;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024949c;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
code_r0x00018024949c:
    LOCK();
    piVar1 = puVar5 + 8;
    iVar8 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (1 < iVar8) {
        return (undefined4 *)0x0;
    }
    uVar2 = *(undefined8 *)(puVar5 + 2);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802494c1;
    fcn.180224990(uVar2, 0x1804e42a0, 0x1d4);
    uVar2 = *(undefined8 *)(puVar5 + 6);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802494ca;
    fcn.18027edb0(uVar2);
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x1802494df;
    fcn.180224990(puVar5, 0x1804e42a0, 0x1d7);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1802495c0
// Address: 0x1802495c0
// Size: 70 bytes
// ============================================================
void fcn.1802495c0(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1802495ca;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = 0x18024a0f0;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0x180248230;
    *(undefined8 *)((int64_t)&var_20h + iVar1) = 0x18024a150;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x180249601;
    fcn.180280c20(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                  *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                  *(int64_t *)(&stack0x000000b0 + iVar1), *(int64_t *)(&stack0x000000b8 + iVar1), 
                  *(int64_t *)(&stack0x000000c0 + iVar1));
    return;
}

// ============================================================
// Function: FUN_180249610
// Address: 0x180249610
// Size: 95 bytes
// ============================================================
void fcn.180249610(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x180249620;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024964b;
            fcn.180224990(uVar3, 0x1804e4690, 0xaa);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180249654;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x180249669;
            fcn.180224990(arg1, 0x1804e4690, 0xad);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180249670
// Address: 0x180249670
// Size: 567 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180249670(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint32_t *in_RCX;
    int64_t in_RDX;
    uint64_t *in_R8;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x180249685;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    if ((in_RCX == (uint32_t *)0x0) || (in_R8 == (uint64_t *)0x0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180249868;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180249880;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    } else {
        if ((*in_RCX & 0x800) != 0) {
            if (*(int64_t *)(in_RCX + 0xc) != 0) {
                if (in_RDX != 0) {
    // WARNING: Could not recover jumptable at 0x000180249843. Too many branches
    // WARNING: Treating indirect jump as call
                    uVar4 = (**(code **)(*(int64_t *)(in_RCX + 10) + 0x40))();
                    return uVar4;
                }
    // WARNING: Could not recover jumptable at 0x000180249860. Too many branches
    // WARNING: Treating indirect jump as call
                uVar4 = (**(code **)(*(int64_t *)(in_RCX + 10) + 0x40))();
                return uVar4;
            }
            iVar1 = *(int64_t *)(in_RCX + 0x1e);
            if ((iVar1 == 0) || (*(int64_t *)(iVar1 + 0xb8) == 0)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802497e5;
                fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                             );
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802497fd;
                fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8)
                              , *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                              *(int64_t *)(&stack0x00000048 + iVar3));
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024980f;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                return 0xfffffffe;
            }
            if ((*(uint8_t *)(iVar1 + 4) & 2) != 0) {
                uVar4 = *(undefined8 *)(in_RCX + 0x22);
                *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024970f;
                iVar2 = fcn.18022fbd0(uVar4);
                if (iVar2 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024971b;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180249733;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)(&stack0x00000048 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180249745;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                    return 0;
                }
                if (in_RDX == 0) {
                    *in_R8 = (int64_t)iVar2;
                    return 1;
                }
                if (*in_R8 < (uint64_t)(int64_t)iVar2) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18024977e;
                    fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180249796;
                    fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                  *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                                  *(int64_t *)(&stack0x00000048 + iVar3));
                    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802497a8;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
                    return 0;
                }
            }
    // WARNING: Could not recover jumptable at 0x0001802497dd. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (**(code **)(*(int64_t *)(in_RCX + 0x1e) + 0xb8))
                              (in_RCX, in_RDX, in_R8, *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0xb8));
            return uVar4;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802496b0;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1802496c8;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar3), *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                      *(int64_t *)((int64_t)&arg_28h + iVar3), *(int64_t *)((int64_t)&arg_30h + iVar3), 
                      *(int64_t *)(&stack0x00000048 + iVar3));
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x180249892;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar3));
    return 0xffffffff;
}

// ============================================================
// Function: FUN_1802498b0
// Address: 0x1802498b0
// Size: 24 bytes
// ============================================================
uint32_t fcn.1802498b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_68h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    undefined4 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + -8) = 0x1802498e4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6) = 0;
    if (in_RCX == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249905;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024991d;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024992f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249957;
    fcn.180259930();
    *in_RCX = 0x800;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249962;
    fcn.180229b10();
    if (*(int64_t *)(in_RCX + 8) == 0) {
code_r0x000180249af4:
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249af9;
        fcn.1802299d0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
        iVar10 = *(int64_t *)(in_RCX + 0x1e);
        if ((iVar10 == 0) || (*(int64_t *)(iVar10 + 0xb8) == 0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249d00;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249d18;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249d2a;
            fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
            uVar5 = 0xfffffffe;
        } else {
            pcVar3 = *(code **)(iVar10 + 0xb0);
            if (pcVar3 == (code *)0x0) {
                uVar5 = 1;
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249ce1;
                uVar5 = (*pcVar3)(in_RCX);
                if ((int32_t)uVar5 < 1) {
                    *in_RCX = 0;
                }
                uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249cf7;
                fcn.180257a00(uVar11);
            }
        }
    } else {
        iVar8 = *(int64_t *)(in_RCX + 0x22);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024997d;
            iVar8 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249991;
                iVar4 = fcn.1802305c0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000078 + iVar7 + iVar6));
                if (iVar4 != 0) {
                    uVar11 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024999e;
                    iVar9 = fcn.180257fb0(uVar11);
                    *(int64_t *)(iVar8 + 0x68) = iVar9;
                    if (iVar9 != 0) {
                        *(int64_t *)(in_RCX + 0x22) = iVar8;
                        goto code_r0x0001802499ae;
                    }
                }
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499d6;
            fcn.180229900();
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499de;
            fcn.18022ecc0(iVar8);
        } else {
code_r0x0001802499ae:
            if ((*(int64_t *)(iVar8 + 0x60) == 0) || (*(int64_t *)(iVar8 + 0x60) == *(int64_t *)(in_RCX + 8))) {
                uVar11 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499f6;
                iVar8 = fcn.18029f2b0(uVar11, 0xb);
                *(int64_t *)((int64_t)&arg_a8h + iVar7 + iVar6) = iVar8;
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a08;
                    fcn.180229900();
                } else {
                    iVar4 = 1;
                    iVar8 = iVar10;
                    do {
                        if (iVar8 != 0) goto code_r0x000180249c37;
                        if (iVar10 != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(iVar10 + 0x20);
                            iVar2 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar2 < 2) {
                                uVar11 = *(undefined8 *)(iVar10 + 8);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a55;
                                fcn.180224990(uVar11, 0x1804e4690, 0xaa);
                                uVar11 = *(undefined8 *)(iVar10 + 0x18);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a5e;
                                fcn.18027edb0(uVar11);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a73;
                                fcn.180224990(iVar10, 0x1804e4690, 0xad);
                            }
                        }
                        uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a80;
                        fcn.180257a00(uVar11);
                        if (iVar4 == 1) {
                            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0x18024a0f0;
                            *(undefined8 *)((int64_t)&arg_30h + iVar7 + iVar6) = 0x180248230;
                            *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0x18024a150;
                            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249b6b;
                            iVar10 = fcn.180280c20(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                                   *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6), 
                                                   *(int64_t *)(&stack0x000000c0 + iVar7 + iVar6), 
                                                   *(int64_t *)(&stack0x000000c8 + iVar7 + iVar6));
                            if (iVar10 != 0) goto code_r0x000180249b77;
                        } else {
                            if (iVar4 == 2) {
                                uVar11 = *(undefined8 *)(in_RCX + 8);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249aa8;
                                fcn.1801dd170(uVar11);
                                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0x18024a0f0;
                                *(undefined8 *)((int64_t)&arg_30h + iVar7 + iVar6) = 0x180248230;
                                *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0x18024a150;
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249ae8;
                                iVar10 = fcn.180280ca0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x00000088 + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x000000c0 + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x000000c8 + iVar7 + iVar6));
                                if (iVar10 == 0) goto code_r0x000180249af4;
                            } else if (iVar10 == 0) goto code_r0x000180249bd3;
code_r0x000180249b77:
                            uVar11 = *(undefined8 *)(in_RCX + 8);
                            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249b84;
                            fcn.1801dd6c0(uVar11);
                            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249b92;
                            iVar9 = fcn.180257b60(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                            *(int64_t *)((int64_t)&arg_98h + iVar7 + iVar6) = iVar9;
                            if (iVar9 != 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249bbe;
                                iVar8 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                      *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                                                      *(int64_t *)(&stack0x000000b0 + iVar7 + iVar6));
                            }
                            if (*(int64_t *)((int64_t)&arg_98h + iVar7 + iVar6) == 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249bd3;
                                fcn.180257a00(iVar9);
                            }
                        }
code_r0x000180249bd3:
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 3);
                    if (iVar8 == 0) {
                        if (iVar10 != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(iVar10 + 0x20);
                            iVar4 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar4 < 2) {
                                uVar11 = *(undefined8 *)(iVar10 + 8);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c14;
                                fcn.180224990(uVar11, 0x1804e4690, 0xaa);
                                uVar11 = *(undefined8 *)(iVar10 + 0x18);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c1d;
                                fcn.18027edb0(uVar11);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c32;
                                fcn.180224990(iVar10, 0x1804e4690, 0xad);
                            }
                        }
                        goto code_r0x000180249af4;
                    }
code_r0x000180249c37:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c3c;
                    fcn.1802299d0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                    *(int64_t *)(in_RCX + 10) = iVar10;
                    uVar11 = *(undefined8 *)(iVar10 + 0x18);
                    pcVar3 = *(code **)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c4d;
                    uVar11 = fcn.18027e810(uVar11);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c52;
                    iVar9 = (*pcVar3)(uVar11);
                    *(int64_t *)(in_RCX + 0xc) = iVar9;
                    if (iVar9 != 0) {
                        pcVar3 = *(code **)(iVar10 + 0x30);
                        uVar11 = *(undefined8 *)((int64_t)&arg_a0h + iVar7 + iVar6);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249cc2;
                        iVar4 = (*pcVar3)(iVar9, iVar8, uVar11);
                        uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249cd1;
                        fcn.180257a00(uVar11);
                        return (uint32_t)(iVar4 != 0);
                    }
                }
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499c2;
                fcn.180229900();
            }
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c6a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c7f;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c8e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c96;
        fcn.180259930(in_RCX);
        uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
        *in_RCX = 0;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249ca6;
        fcn.180257a00(uVar11);
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_1802498d0
// Address: 0x1802498d0
// Size: 1149 bytes
// ============================================================
uint32_t fcn.1802498b0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_50h, int64_t arg_58h,
                      int64_t arg_60h, int64_t arg_68h, int64_t arg_98h, int64_t arg_a0h, int64_t arg_a8h)
{
    int32_t *piVar1;
    int32_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    undefined8 uVar11;
    undefined4 *in_RCX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = 0;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_8 + iVar6 + -8) = 0x1802498e4;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar10 = 0;
    *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6) = 0;
    if (in_RCX == (undefined4 *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249905;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024991d;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024992f;
        fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        return 0xfffffffe;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar7 + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_60h + iVar7 + iVar6) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_50h + iVar7 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249957;
    fcn.180259930();
    *in_RCX = 0x800;
    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249962;
    fcn.180229b10();
    if (*(int64_t *)(in_RCX + 8) == 0) {
code_r0x000180249af4:
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249af9;
        fcn.1802299d0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
        iVar10 = *(int64_t *)(in_RCX + 0x1e);
        if ((iVar10 == 0) || (*(int64_t *)(iVar10 + 0xb8) == 0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249d00;
            fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249d18;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                          *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                          *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249d2a;
            fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
            uVar5 = 0xfffffffe;
        } else {
            pcVar3 = *(code **)(iVar10 + 0xb0);
            if (pcVar3 == (code *)0x0) {
                uVar5 = 1;
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249ce1;
                uVar5 = (*pcVar3)(in_RCX);
                if ((int32_t)uVar5 < 1) {
                    *in_RCX = 0;
                }
                uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249cf7;
                fcn.180257a00(uVar11);
            }
        }
    } else {
        iVar8 = *(int64_t *)(in_RCX + 0x22);
        if (iVar8 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024997d;
            iVar8 = fcn.18022fd80(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                  *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6));
            if (iVar8 != 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249991;
                iVar4 = fcn.1802305c0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                      *(int64_t *)((int64_t)&arg_60h + iVar7 + iVar6), 
                                      *(int64_t *)(&stack0x00000078 + iVar7 + iVar6));
                if (iVar4 != 0) {
                    uVar11 = *(undefined8 *)(in_RCX + 8);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x18024999e;
                    iVar9 = fcn.180257fb0(uVar11);
                    *(int64_t *)(iVar8 + 0x68) = iVar9;
                    if (iVar9 != 0) {
                        *(int64_t *)(in_RCX + 0x22) = iVar8;
                        goto code_r0x0001802499ae;
                    }
                }
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499d6;
            fcn.180229900();
            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499de;
            fcn.18022ecc0(iVar8);
        } else {
code_r0x0001802499ae:
            if ((*(int64_t *)(iVar8 + 0x60) == 0) || (*(int64_t *)(iVar8 + 0x60) == *(int64_t *)(in_RCX + 8))) {
                uVar11 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499f6;
                iVar8 = fcn.18029f2b0(uVar11, 0xb);
                *(int64_t *)((int64_t)&arg_a8h + iVar7 + iVar6) = iVar8;
                if (iVar8 == 0) {
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a08;
                    fcn.180229900();
                } else {
                    iVar4 = 1;
                    iVar8 = iVar10;
                    do {
                        if (iVar8 != 0) goto code_r0x000180249c37;
                        if (iVar10 != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(iVar10 + 0x20);
                            iVar2 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar2 < 2) {
                                uVar11 = *(undefined8 *)(iVar10 + 8);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a55;
                                fcn.180224990(uVar11, 0x1804e4690, 0xaa);
                                uVar11 = *(undefined8 *)(iVar10 + 0x18);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a5e;
                                fcn.18027edb0(uVar11);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a73;
                                fcn.180224990(iVar10, 0x1804e4690, 0xad);
                            }
                        }
                        uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249a80;
                        fcn.180257a00(uVar11);
                        if (iVar4 == 1) {
                            *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0x18024a0f0;
                            *(undefined8 *)((int64_t)&arg_30h + iVar7 + iVar6) = 0x180248230;
                            *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0x18024a150;
                            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249b6b;
                            iVar10 = fcn.180280c20(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                   *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                                   *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6), 
                                                   *(int64_t *)(&stack0x000000c0 + iVar7 + iVar6), 
                                                   *(int64_t *)(&stack0x000000c8 + iVar7 + iVar6));
                            if (iVar10 != 0) goto code_r0x000180249b77;
                        } else {
                            if (iVar4 == 2) {
                                uVar11 = *(undefined8 *)(in_RCX + 8);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249aa8;
                                fcn.1801dd170(uVar11);
                                *(undefined8 *)((int64_t)&arg_38h + iVar7 + iVar6) = 0x18024a0f0;
                                *(undefined8 *)((int64_t)&arg_30h + iVar7 + iVar6) = 0x180248230;
                                *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar6) = 0x18024a150;
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249ae8;
                                iVar10 = fcn.180280ca0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                       *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x00000088 + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x000000b8 + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x000000c0 + iVar7 + iVar6), 
                                                       *(int64_t *)(&stack0x000000c8 + iVar7 + iVar6));
                                if (iVar10 == 0) goto code_r0x000180249af4;
                            } else if (iVar10 == 0) goto code_r0x000180249bd3;
code_r0x000180249b77:
                            uVar11 = *(undefined8 *)(in_RCX + 8);
                            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249b84;
                            fcn.1801dd6c0(uVar11);
                            *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249b92;
                            iVar9 = fcn.180257b60(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                                  *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                            *(int64_t *)((int64_t)&arg_98h + iVar7 + iVar6) = iVar9;
                            if (iVar9 != 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249bbe;
                                iVar8 = fcn.180230ea0(*(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), 
                                                      *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                                                      *(int64_t *)(&stack0x00000048 + iVar7 + iVar6), 
                                                      *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6), 
                                                      *(int64_t *)(&stack0x000000b0 + iVar7 + iVar6));
                            }
                            if (*(int64_t *)((int64_t)&arg_98h + iVar7 + iVar6) == 0) {
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249bd3;
                                fcn.180257a00(iVar9);
                            }
                        }
code_r0x000180249bd3:
                        iVar4 = iVar4 + 1;
                    } while (iVar4 < 3);
                    if (iVar8 == 0) {
                        if (iVar10 != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(iVar10 + 0x20);
                            iVar4 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar4 < 2) {
                                uVar11 = *(undefined8 *)(iVar10 + 8);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c14;
                                fcn.180224990(uVar11, 0x1804e4690, 0xaa);
                                uVar11 = *(undefined8 *)(iVar10 + 0x18);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c1d;
                                fcn.18027edb0(uVar11);
                                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c32;
                                fcn.180224990(iVar10, 0x1804e4690, 0xad);
                            }
                        }
                        goto code_r0x000180249af4;
                    }
code_r0x000180249c37:
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c3c;
                    fcn.1802299d0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), 
                                  *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
                    *(int64_t *)(in_RCX + 10) = iVar10;
                    uVar11 = *(undefined8 *)(iVar10 + 0x18);
                    pcVar3 = *(code **)(iVar10 + 0x28);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c4d;
                    uVar11 = fcn.18027e810(uVar11);
                    *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c52;
                    iVar9 = (*pcVar3)(uVar11);
                    *(int64_t *)(in_RCX + 0xc) = iVar9;
                    if (iVar9 != 0) {
                        pcVar3 = *(code **)(iVar10 + 0x30);
                        uVar11 = *(undefined8 *)((int64_t)&arg_a0h + iVar7 + iVar6);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249cc2;
                        iVar4 = (*pcVar3)(iVar9, iVar8, uVar11);
                        uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
                        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249cd1;
                        fcn.180257a00(uVar11);
                        return (uint32_t)(iVar4 != 0);
                    }
                }
            } else {
                *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x1802499c2;
                fcn.180229900();
            }
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c6a;
        fcn.180229480(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c7f;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_28h + iVar7 + iVar6), *(int64_t *)((int64_t)&arg_30h + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_38h + iVar7 + iVar6), *(int64_t *)(&stack0x00000040 + iVar7 + iVar6), 
                      *(int64_t *)((int64_t)&arg_58h + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c8e;
        fcn.1802296d0(*(int64_t *)(&stack0x00000048 + iVar7 + iVar6));
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249c96;
        fcn.180259930(in_RCX);
        uVar11 = *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar6);
        *in_RCX = 0;
        *(undefined8 *)((int64_t)auStackX_8 + iVar7 + iVar6 + -8) = 0x180249ca6;
        fcn.180257a00(uVar11);
        uVar5 = 0;
    }
    return uVar5;
}

// ============================================================
// Function: FUN_180249d50
// Address: 0x180249d50
// Size: 28 bytes
// ============================================================
undefined8 fcn.180249d50(int64_t arg_30h, int64_t arg_38h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = 1;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4) = 0x180249d7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar4) = 0;
    if (in_RCX == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249d99;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249db1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249dc3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
        return 0xffffffff;
    }
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_68h + iVar5 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_70h + iVar5 + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar5 + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar4) = unaff_R15;
    if (((uVar1 & 0x800) != 0) && (*(int64_t *)(in_RCX + 0xc) != 0)) {
        if (*(int64_t *)(*(int64_t *)(in_RCX + 10) + 0x38) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e0a;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            goto code_r0x00018024a0a6;
        }
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e26;
            iVar6 = fcn.180259210(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4));
            if (iVar6 == 0) {
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e3a;
            iVar3 = fcn.18026ebf0(*(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e44;
            fcn.180258be0(iVar6);
            if (iVar3 < 1) {
                return 0xffffffff;
            }
        }
        uVar8 = *(undefined8 *)(in_RCX + 8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e6b;
        fcn.1801dd6c0(uVar8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e79;
        iVar6 = fcn.180257b60(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
        *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4) = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e9b;
            iVar7 = fcn.180230ea0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000b8 + iVar5 + iVar4));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249ea6;
        fcn.180257a00(iVar6);
        if (iVar7 != 0) {
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x38);
            uVar8 = *(undefined8 *)(in_RCX + 0xc);
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249ebd;
            uVar8 = (*pcVar2)(uVar8, iVar7);
            iVar3 = (int32_t)uVar8;
            goto joined_r0x00018024a074;
        }
    }
    iVar7 = *(int64_t *)(in_RCX + 0x1e);
    if (((iVar7 != 0) &&
        (((*(int64_t *)(iVar7 + 0xb8) != 0 || (*(int64_t *)(iVar7 + 0x98) != 0)) || (*(int64_t *)(iVar7 + 0xa8) != 0))))
       && (pcVar2 = *(code **)(iVar7 + 0xc0), pcVar2 != (code *)0x0)) {
        if ((*in_RCX != 0x800) && ((*in_RCX - 0x200 & 0xfffffdff) != 0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f23;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f3b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f4d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f68;
        uVar8 = (*pcVar2)(in_RCX, 2, 0, in_RDX);
        if ((int32_t)uVar8 < 1) {
            return uVar8;
        }
        if ((int32_t)uVar8 == 2) {
            return 1;
        }
        if (*(int32_t **)(in_RCX + 0x22) == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f8a;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fa2;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fb4;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
            return 0xffffffff;
        }
        if (**(int32_t **)(in_RCX + 0x22) != *in_RDX) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fca;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fe2;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249ff4;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a006;
        iVar3 = fcn.18022fd20(in_RDX);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a019;
            iVar3 = fcn.18022fee0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000c8 + iVar5 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a022;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a03a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a04c;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                return 0xffffffff;
            }
        }
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0xc0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a072;
        uVar8 = (*pcVar2)(in_RCX, 2, 1, in_RDX);
        iVar3 = (int32_t)uVar8;
joined_r0x00018024a074:
        if (iVar3 < 1) {
            return uVar8;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a07e;
        iVar3 = fcn.1802308d0(in_RDX);
        if (iVar3 != 0) {
            uVar8 = *(undefined8 *)(in_RCX + 0x24);
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a08e;
            fcn.18022ecc0(uVar8);
            *(int32_t **)(in_RCX + 0x24) = in_RDX;
            return 1;
        }
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a0a1;
    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
code_r0x00018024a0a6:
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a0b9;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a0cb;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_180249d70
// Address: 0x180249d70
// Size: 893 bytes
// ============================================================
undefined8 fcn.180249d50(int64_t arg_30h, int64_t arg_38h, int64_t arg_60h, int64_t arg_68h, int64_t arg_70h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    undefined8 uVar8;
    uint32_t *in_RCX;
    int32_t *in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R12;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 auStackX_8 [4];
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    iVar3 = 1;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x18) = unaff_RBP;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 0x10) = unaff_RSI;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4 + 8) = unaff_R14;
    *(undefined8 *)((int64_t)auStackX_8 + iVar4) = 0x180249d7f;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    iVar7 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar5 + iVar4) = 0;
    if (in_RCX == (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249d99;
        fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249db1;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                      *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                      *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249dc3;
        fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
        return 0xffffffff;
    }
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&arg_68h + iVar5 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_70h + iVar5 + iVar4) = unaff_RDI;
    *(undefined8 *)((int64_t)&arg_38h + iVar5 + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar4) = unaff_R15;
    if (((uVar1 & 0x800) != 0) && (*(int64_t *)(in_RCX + 0xc) != 0)) {
        if (*(int64_t *)(*(int64_t *)(in_RCX + 10) + 0x38) == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e0a;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            goto code_r0x00018024a0a6;
        }
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e26;
            iVar6 = fcn.180259210(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4));
            if (iVar6 == 0) {
                return 0xffffffff;
            }
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e3a;
            iVar3 = fcn.18026ebf0(*(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e44;
            fcn.180258be0(iVar6);
            if (iVar3 < 1) {
                return 0xffffffff;
            }
        }
        uVar8 = *(undefined8 *)(in_RCX + 8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e6b;
        fcn.1801dd6c0(uVar8);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e79;
        iVar6 = fcn.180257b60(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
        *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4) = iVar6;
        if (iVar6 != 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249e9b;
            iVar7 = fcn.180230ea0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000050 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000b8 + iVar5 + iVar4));
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249ea6;
        fcn.180257a00(iVar6);
        if (iVar7 != 0) {
            pcVar2 = *(code **)(*(int64_t *)(in_RCX + 10) + 0x38);
            uVar8 = *(undefined8 *)(in_RCX + 0xc);
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249ebd;
            uVar8 = (*pcVar2)(uVar8, iVar7);
            iVar3 = (int32_t)uVar8;
            goto joined_r0x00018024a074;
        }
    }
    iVar7 = *(int64_t *)(in_RCX + 0x1e);
    if (((iVar7 != 0) &&
        (((*(int64_t *)(iVar7 + 0xb8) != 0 || (*(int64_t *)(iVar7 + 0x98) != 0)) || (*(int64_t *)(iVar7 + 0xa8) != 0))))
       && (pcVar2 = *(code **)(iVar7 + 0xc0), pcVar2 != (code *)0x0)) {
        if ((*in_RCX != 0x800) && ((*in_RCX - 0x200 & 0xfffffdff) != 0)) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f23;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f3b;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f4d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f68;
        uVar8 = (*pcVar2)(in_RCX, 2, 0, in_RDX);
        if ((int32_t)uVar8 < 1) {
            return uVar8;
        }
        if ((int32_t)uVar8 == 2) {
            return 1;
        }
        if (*(int32_t **)(in_RCX + 0x22) == (int32_t *)0x0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249f8a;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fa2;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fb4;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
            return 0xffffffff;
        }
        if (**(int32_t **)(in_RCX + 0x22) != *in_RDX) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fca;
            fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249fe2;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                          *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                          *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4)
                          , *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x180249ff4;
            fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
            return 0xffffffff;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a006;
        iVar3 = fcn.18022fd20(in_RDX);
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a019;
            iVar3 = fcn.18022fee0(*(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x00000058 + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_68h + iVar5 + iVar4), 
                                  *(int64_t *)((int64_t)&arg_70h + iVar5 + iVar4), 
                                  *(int64_t *)(&stack0x000000c8 + iVar5 + iVar4));
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a022;
                fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a03a;
                fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), 
                              *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                              *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
                *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a04c;
                fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
                return 0xffffffff;
            }
        }
        pcVar2 = *(code **)(*(int64_t *)(in_RCX + 0x1e) + 0xc0);
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a072;
        uVar8 = (*pcVar2)(in_RCX, 2, 1, in_RDX);
        iVar3 = (int32_t)uVar8;
joined_r0x00018024a074:
        if (iVar3 < 1) {
            return uVar8;
        }
        *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a07e;
        iVar3 = fcn.1802308d0(in_RDX);
        if (iVar3 != 0) {
            uVar8 = *(undefined8 *)(in_RCX + 0x24);
            *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a08e;
            fcn.18022ecc0(uVar8);
            *(int32_t **)(in_RCX + 0x24) = in_RDX;
            return 1;
        }
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a0a1;
    fcn.180229480(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4));
code_r0x00018024a0a6:
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a0b9;
    fcn.1802295a0(*(int64_t *)((int64_t)&arg_30h + iVar5 + iVar4), *(int64_t *)((int64_t)&arg_38h + iVar5 + iVar4), 
                  *(int64_t *)(&stack0x00000040 + iVar5 + iVar4), *(int64_t *)(&stack0x00000048 + iVar5 + iVar4), 
                  *(int64_t *)((int64_t)&arg_60h + iVar5 + iVar4));
    *(undefined8 *)((int64_t)auStackX_8 + iVar5 + iVar4) = 0x18024a0cb;
    fcn.1802296d0(*(int64_t *)(&stack0x00000050 + iVar5 + iVar4));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18024a0f0
// Address: 0x18024a0f0
// Size: 95 bytes
// ============================================================
void fcn.18024a0f0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18024a100;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024a12b;
            fcn.180224990(uVar3, 0x1804e4690, 0xaa);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024a134;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18024a149;
            fcn.180224990(arg1, 0x1804e4690, 0xad);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18024a150
// Address: 0x18024a150
// Size: 728 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.18024a150(int64_t arg_28h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 in_ECX;
    int64_t in_RDX;
    undefined8 *puVar7;
    int32_t iVar8;
    int32_t iVar9;
    undefined8 in_R8;
    uint32_t uVar10;
    uint32_t uVar11;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18024a16a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar9 = 0;
    iVar8 = 0;
    uVar10 = 0;
    uVar11 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a199;
    puVar5 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4));
    if (puVar5 != (undefined4 *)0x0) {
        puVar5[8] = 1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a1b4;
        iVar3 = func_0x00018027fb30(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)(puVar5 + 6) = in_R8;
            *puVar5 = in_ECX;
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a1cb;
            iVar6 = func_0x000180282210(in_RDX);
            *(int64_t *)(puVar5 + 2) = iVar6;
            if (iVar6 != 0) {
                *(undefined8 *)(puVar5 + 4) = *(undefined8 *)(in_RDX + 0x18);
                iVar3 = *piVar1;
                if (iVar3 != 0) {
                    puVar7 = (undefined8 *)(piVar1 + 2);
                    do {
    // switch table (11 cases) at 0x18024a3fc
                        switch(iVar3) {
                        case 1:
                            if (*(int64_t *)(puVar5 + 10) == 0) {
                                iVar9 = iVar9 + 1;
                                *(undefined8 *)(puVar5 + 10) = *puVar7;
                            }
                            break;
                        case 2:
                            if (*(int64_t *)(puVar5 + 0xc) == 0) {
                                iVar9 = iVar9 + 1;
                                *(undefined8 *)(puVar5 + 0xc) = *puVar7;
                            }
                            break;
                        case 3:
                            if (*(int64_t *)(puVar5 + 0x10) == 0) {
                                *(undefined8 *)(puVar5 + 0x10) = *puVar7;
code_r0x00018024a2f3:
                                iVar8 = 1;
                            }
                            break;
                        case 4:
                            if (*(int64_t *)(puVar5 + 0xe) == 0) {
                                *(undefined8 *)(puVar5 + 0xe) = *puVar7;
                            }
                            break;
                        case 5:
                            if (*(int64_t *)(puVar5 + 0x12) == 0) {
                                iVar9 = iVar9 + 1;
                                *(undefined8 *)(puVar5 + 0x12) = *puVar7;
                            }
                            break;
                        case 6:
                            if (*(int64_t *)(puVar5 + 0x14) == 0) {
                                *(undefined8 *)(puVar5 + 0x14) = *puVar7;
                            }
                            break;
                        case 7:
                            if (*(int64_t *)(puVar5 + 0x16) == 0) {
                                uVar10 = uVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x16) = *puVar7;
                            }
                            break;
                        case 8:
                            if (*(int64_t *)(puVar5 + 0x18) == 0) {
                                uVar10 = uVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x18) = *puVar7;
                            }
                            break;
                        case 9:
                            if (*(int64_t *)(puVar5 + 0x1a) == 0) {
                                uVar11 = uVar11 + 1;
                                *(undefined8 *)(puVar5 + 0x1a) = *puVar7;
                            }
                            break;
                        case 10:
                            if (*(int64_t *)(puVar5 + 0x1c) == 0) {
                                uVar11 = uVar11 + 1;
                                *(undefined8 *)(puVar5 + 0x1c) = *puVar7;
                            }
                            break;
                        case 0xb:
                            if (*(int64_t *)(puVar5 + 0x1e) == 0) {
                                *(undefined8 *)(puVar5 + 0x1e) = *puVar7;
                                goto code_r0x00018024a2f3;
                            }
                        }
                        iVar3 = *(int32_t *)(puVar7 + 1);
                        puVar7 = puVar7 + 2;
                    } while (iVar3 != 0);
                    if (((iVar9 + iVar8 == 4) && ((uVar11 & 0xfffffffd) == 0)) && ((uVar10 & 0xfffffffd) == 0)) {
                        return puVar5;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a331;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a349;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a35b;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
            }
            LOCK();
            piVar1 = puVar5 + 8;
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (1 < iVar8) {
                return (undefined4 *)0x0;
            }
            uVar2 = *(undefined8 *)(puVar5 + 2);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a380;
            fcn.180224990(uVar2, 0x1804e4690, 0xaa);
            uVar2 = *(undefined8 *)(puVar5 + 6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a389;
            fcn.18027edb0(uVar2);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a39e;
            fcn.180224990(puVar5, 0x1804e4690, 0xad);
            return (undefined4 *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a3b5;
        fcn.180224990(puVar5, 0x1804e4690, 0x2a);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a3ba;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a3d2;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4));
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18024a3e4;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_18024a430
// Address: 0x18024a430
// Size: 44 bytes
// ============================================================
bool fcn.18024a430(void)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x18024a43a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18024a44d;
    iVar1 = fcn.18024ab80(*(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000040 + iVar1));
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_18024a460
// Address: 0x18024a460
// Size: 441 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int32_t fcn.18024a460(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t in_RCX;
    int64_t in_RDX;
    uint64_t uVar8;
    int32_t iVar9;
    uint64_t in_R8;
    int64_t iStackX_8;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_20;
    
    uStack_20 = 0x18024a47e;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == 0) {
        return 1;
    }
    iVar9 = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a49e;
    fcn.180229b10();
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a4b4;
    iVar3 = func_0x00018028c920(in_RCX, 0, 0x1804e4758, (int64_t)&arg_28h + iVar5);
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a4bb;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
    uVar1 = *(undefined8 *)(in_RCX + 0x28);
    if (iVar3 < 1) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a4e1;
        uVar4 = func_0x0001802451e0(uVar1);
    } else {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a4d1;
        func_0x000180245570(uVar1, 0 < *(int32_t *)((int64_t)&arg_28h + iVar5));
        uVar4 = (uint32_t)(0 < *(int32_t *)((int64_t)&arg_28h + iVar5));
    }
    uVar8 = (uint64_t)((uint32_t)in_R8 & 0xffffffe8);
    if (uVar4 == 0) {
        uVar8 = in_R8 & 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a4f2;
    fcn.180229b10();
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a504;
        iVar6 = func_0x00018028cb70(in_RCX, 0, in_RDX);
        if (iVar6 != 0) goto code_r0x00018024a54e;
        if ((uVar8 & 0x20) == 0) goto code_r0x00018024a52b;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a523;
    iVar6 = func_0x00018028cb70(in_RCX, 0, 0x1804e4770);
    if (iVar6 == 0) {
code_r0x00018024a52b:
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a530;
        fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        return 1;
    }
code_r0x00018024a54e:
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a559;
    iVar6 = func_0x00018028cae0(in_RCX, iVar6);
    if (iVar6 == 0) {
        if ((uVar8 & 4) != 0) {
            *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5ab;
            fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a56c;
        fcn.180229900();
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a571;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a589;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5), 
                      *(int64_t *)((int64_t)&var_18h + iVar5), *(int64_t *)((int64_t)&var_20h + iVar5), 
                      *(int64_t *)((int64_t)&arg_38h + iVar5));
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5a2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_28h + iVar5));
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5b4;
    fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5bc;
    iVar3 = fcn.180222010(iVar6);
    if (iVar3 < 1) {
        return 1;
    }
    while( true ) {
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5ce;
        iVar7 = func_0x000180222340(iVar6, iVar9);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5d6;
        fcn.180229b10();
        uVar1 = *(undefined8 *)(iVar7 + 0x10);
        uVar2 = *(undefined8 *)(iVar7 + 8);
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5e9;
        iVar3 = func_0x00018024afc0(in_RCX, uVar2, uVar1, uVar8);
        if ((iVar3 < 1) && ((uVar8 & 1) == 0)) break;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a5fa;
        fcn.1802299d0(*(int64_t *)((int64_t)&iStackX_8 + iVar5), *(int64_t *)((int64_t)&var_10h + iVar5));
        iVar9 = iVar9 + 1;
        *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a604;
        iVar3 = fcn.180222010(iVar6);
        if (iVar3 <= iVar9) {
            return 1;
        }
    }
    *(undefined8 *)((int64_t)&uStack_20 + iVar5) = 0x18024a612;
    fcn.180229900();
    return iVar3;
}

// ============================================================
// Function: FUN_18024a620
// Address: 0x18024a620
// Size: 20 bytes
// ============================================================
int32_t fcn.18024a620(undefined8 placeholder_0, char *placeholder_1, int64_t arg3, uint64_t placeholder_3,
                     int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
                     int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    char *pcVar6;
    int64_t iVar7;
    undefined8 unaff_RSI;
    char *pcVar8;
    undefined8 unaff_RDI;
    char *pcVar10;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    char *pcVar9;
    
    uStack_18 = 0x18024a631;
    var_18h = arg3;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RSI;
    pcVar9 = (char *)0x0;
    pcVar8 = (char *)0x0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    iVar2 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a667;
    iVar1 = func_0x0001802451e0();
    *(int32_t *)((int64_t)&arg_78h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a675;
    fcn.180229b10();
    pcVar6 = placeholder_1;
    if (placeholder_1 == (char *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a68a;
        iVar5 = func_0x000180275160(0x1804e4848);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a69c;
            iVar5 = func_0x0001802a72f0();
            if (iVar5 == 0) {
                iVar5 = 0x1805aadb1;
                uVar11 = 0x2c4;
                goto code_r0x00018024a6b1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6d6;
            iVar7 = func_0x000180498cd0(iVar5);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6ef;
            pcVar6 = (char *)fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar4), 
                                           *(int64_t *)((int64_t)&var_18h + iVar4));
            pcVar10 = pcVar9;
            if (pcVar6 != (char *)0x0) {
                *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1804e4858;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x1806238f0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a72c;
                func_0x000180245f70(pcVar6, iVar7 + 0xd, 0x1804e4864, iVar5);
                goto code_r0x00018024a737;
            }
        } else {
            uVar11 = 0x2b7;
code_r0x00018024a6b1:
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6c0;
            pcVar6 = (char *)func_0x0001802231e0(iVar5, 0x1804e4740, uVar11);
            pcVar8 = pcVar9;
            pcVar10 = pcVar6;
            iVar2 = 0;
            if (pcVar6 != (char *)0x0) {
code_r0x00018024a737:
                if (*pcVar6 != '\0') {
                    iVar1 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    goto code_r0x00018024a751;
                }
                iVar2 = 1;
                pcVar8 = pcVar9;
                pcVar10 = pcVar6;
            }
        }
    } else {
code_r0x00018024a751:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a75b;
        pcVar8 = (char *)func_0x00018028cc80(placeholder_0, 0);
        iVar2 = 0;
        if (pcVar8 != (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a771;
            iVar2 = func_0x00018028cc20(pcVar8, pcVar6, 0);
            if (iVar2 < 1) {
                iVar2 = 0;
                if ((placeholder_3 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a780;
                    uVar3 = func_0x000180220a00();
                    if ((((int32_t)uVar3 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar3) == 0x72) {
                        iVar2 = 1;
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7ad;
                iVar2 = fcn.18024a460(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7b7;
                iVar1 = func_0x0001802451e0(placeholder_0);
                *(int32_t *)((int64_t)&arg_78h + iVar4) = iVar1;
            }
        }
        pcVar10 = pcVar6;
        if (placeholder_1 != (char *)0x0) goto code_r0x00018024a7e1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7da;
    fcn.180224990(pcVar10, 0x1804e4740, 0xe7);
    iVar1 = *(int32_t *)((int64_t)&arg_78h + iVar4);
code_r0x00018024a7e1:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7e9;
    func_0x00018028c900(pcVar8);
    if (((placeholder_3 & 2) != 0) && (iVar1 == 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a81b;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
        return 1;
    }
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a83b;
        fcn.180229900();
        return iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a82d;
    fcn.1802299d0(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    return iVar2;
}

// ============================================================
// Function: FUN_18024a634
// Address: 0x18024a634
// Size: 473 bytes
// ============================================================
int32_t fcn.18024a620(undefined8 placeholder_0, char *placeholder_1, int64_t arg3, uint64_t placeholder_3,
                     int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
                     int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    char *pcVar6;
    int64_t iVar7;
    undefined8 unaff_RSI;
    char *pcVar8;
    undefined8 unaff_RDI;
    char *pcVar10;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    char *pcVar9;
    
    uStack_18 = 0x18024a631;
    var_18h = arg3;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RSI;
    pcVar9 = (char *)0x0;
    pcVar8 = (char *)0x0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    iVar2 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a667;
    iVar1 = func_0x0001802451e0();
    *(int32_t *)((int64_t)&arg_78h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a675;
    fcn.180229b10();
    pcVar6 = placeholder_1;
    if (placeholder_1 == (char *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a68a;
        iVar5 = func_0x000180275160(0x1804e4848);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a69c;
            iVar5 = func_0x0001802a72f0();
            if (iVar5 == 0) {
                iVar5 = 0x1805aadb1;
                uVar11 = 0x2c4;
                goto code_r0x00018024a6b1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6d6;
            iVar7 = func_0x000180498cd0(iVar5);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6ef;
            pcVar6 = (char *)fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar4), 
                                           *(int64_t *)((int64_t)&var_18h + iVar4));
            pcVar10 = pcVar9;
            if (pcVar6 != (char *)0x0) {
                *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1804e4858;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x1806238f0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a72c;
                func_0x000180245f70(pcVar6, iVar7 + 0xd, 0x1804e4864, iVar5);
                goto code_r0x00018024a737;
            }
        } else {
            uVar11 = 0x2b7;
code_r0x00018024a6b1:
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6c0;
            pcVar6 = (char *)func_0x0001802231e0(iVar5, 0x1804e4740, uVar11);
            pcVar8 = pcVar9;
            pcVar10 = pcVar6;
            iVar2 = 0;
            if (pcVar6 != (char *)0x0) {
code_r0x00018024a737:
                if (*pcVar6 != '\0') {
                    iVar1 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    goto code_r0x00018024a751;
                }
                iVar2 = 1;
                pcVar8 = pcVar9;
                pcVar10 = pcVar6;
            }
        }
    } else {
code_r0x00018024a751:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a75b;
        pcVar8 = (char *)func_0x00018028cc80(placeholder_0, 0);
        iVar2 = 0;
        if (pcVar8 != (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a771;
            iVar2 = func_0x00018028cc20(pcVar8, pcVar6, 0);
            if (iVar2 < 1) {
                iVar2 = 0;
                if ((placeholder_3 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a780;
                    uVar3 = func_0x000180220a00();
                    if ((((int32_t)uVar3 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar3) == 0x72) {
                        iVar2 = 1;
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7ad;
                iVar2 = fcn.18024a460(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7b7;
                iVar1 = func_0x0001802451e0(placeholder_0);
                *(int32_t *)((int64_t)&arg_78h + iVar4) = iVar1;
            }
        }
        pcVar10 = pcVar6;
        if (placeholder_1 != (char *)0x0) goto code_r0x00018024a7e1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7da;
    fcn.180224990(pcVar10, 0x1804e4740, 0xe7);
    iVar1 = *(int32_t *)((int64_t)&arg_78h + iVar4);
code_r0x00018024a7e1:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7e9;
    func_0x00018028c900(pcVar8);
    if (((placeholder_3 & 2) != 0) && (iVar1 == 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a81b;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
        return 1;
    }
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a83b;
        fcn.180229900();
        return iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a82d;
    fcn.1802299d0(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    return iVar2;
}

// ============================================================
// Function: FUN_18024a80d
// Address: 0x18024a80d
// Size: 55 bytes
// ============================================================
int32_t fcn.18024a620(undefined8 placeholder_0, char *placeholder_1, int64_t arg3, uint64_t placeholder_3,
                     int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_60h,
                     int64_t arg_70h, int64_t arg_78h)
{
    int32_t iVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    char *pcVar6;
    int64_t iVar7;
    undefined8 unaff_RSI;
    char *pcVar8;
    undefined8 unaff_RDI;
    char *pcVar10;
    undefined8 uVar11;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_18;
    char *pcVar9;
    
    uStack_18 = 0x18024a631;
    var_18h = arg3;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined8 *)((int64_t)&arg_60h + iVar4) = unaff_RSI;
    pcVar9 = (char *)0x0;
    pcVar8 = (char *)0x0;
    *(undefined8 *)((int64_t)&arg_40h + iVar4) = unaff_RDI;
    iVar2 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar4) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_R13;
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_R14;
    *(undefined8 *)((int64_t)&var_20h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a667;
    iVar1 = func_0x0001802451e0();
    *(int32_t *)((int64_t)&arg_78h + iVar4) = iVar1;
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a675;
    fcn.180229b10();
    pcVar6 = placeholder_1;
    if (placeholder_1 == (char *)0x0) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a68a;
        iVar5 = func_0x000180275160(0x1804e4848);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a69c;
            iVar5 = func_0x0001802a72f0();
            if (iVar5 == 0) {
                iVar5 = 0x1805aadb1;
                uVar11 = 0x2c4;
                goto code_r0x00018024a6b1;
            }
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6d6;
            iVar7 = func_0x000180498cd0(iVar5);
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6ef;
            pcVar6 = (char *)fcn.1802248d0(*(int64_t *)((int64_t)&var_10h + iVar4), 
                                           *(int64_t *)((int64_t)&var_18h + iVar4));
            pcVar10 = pcVar9;
            if (pcVar6 != (char *)0x0) {
                *(undefined8 *)((int64_t)&var_18h + iVar4) = 0x1804e4858;
                *(undefined8 *)((int64_t)&var_10h + iVar4) = 0x1806238f0;
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a72c;
                func_0x000180245f70(pcVar6, iVar7 + 0xd, 0x1804e4864, iVar5);
                goto code_r0x00018024a737;
            }
        } else {
            uVar11 = 0x2b7;
code_r0x00018024a6b1:
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a6c0;
            pcVar6 = (char *)func_0x0001802231e0(iVar5, 0x1804e4740, uVar11);
            pcVar8 = pcVar9;
            pcVar10 = pcVar6;
            iVar2 = 0;
            if (pcVar6 != (char *)0x0) {
code_r0x00018024a737:
                if (*pcVar6 != '\0') {
                    iVar1 = *(int32_t *)((int64_t)&arg_78h + iVar4);
                    goto code_r0x00018024a751;
                }
                iVar2 = 1;
                pcVar8 = pcVar9;
                pcVar10 = pcVar6;
            }
        }
    } else {
code_r0x00018024a751:
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a75b;
        pcVar8 = (char *)func_0x00018028cc80(placeholder_0, 0);
        iVar2 = 0;
        if (pcVar8 != (char *)0x0) {
            *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a771;
            iVar2 = func_0x00018028cc20(pcVar8, pcVar6, 0);
            if (iVar2 < 1) {
                iVar2 = 0;
                if ((placeholder_3 & 0x10) != 0) {
                    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a780;
                    uVar3 = func_0x000180220a00();
                    if ((((int32_t)uVar3 >> 0x1f & 0x7f800000U) + 0x7fffff & uVar3) == 0x72) {
                        iVar2 = 1;
                    }
                }
            } else {
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7ad;
                iVar2 = fcn.18024a460(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4), 
                                      *(int64_t *)((int64_t)&var_20h + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
                *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7b7;
                iVar1 = func_0x0001802451e0(placeholder_0);
                *(int32_t *)((int64_t)&arg_78h + iVar4) = iVar1;
            }
        }
        pcVar10 = pcVar6;
        if (placeholder_1 != (char *)0x0) goto code_r0x00018024a7e1;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7da;
    fcn.180224990(pcVar10, 0x1804e4740, 0xe7);
    iVar1 = *(int32_t *)((int64_t)&arg_78h + iVar4);
code_r0x00018024a7e1:
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a7e9;
    func_0x00018028c900(pcVar8);
    if (((placeholder_3 & 2) != 0) && (iVar1 == 0)) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a81b;
        fcn.1802299d0(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
        return 1;
    }
    if (iVar2 < 1) {
        *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a83b;
        fcn.180229900();
        return iVar2;
    }
    *(undefined8 *)((int64_t)&uStack_18 + iVar4) = 0x18024a82d;
    fcn.1802299d0(*(int64_t *)((int64_t)&var_10h + iVar4), *(int64_t *)((int64_t)&var_18h + iVar4));
    return iVar2;
}

// ============================================================
// Function: FUN_18024a850
// Address: 0x18024a850
// Size: 331 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.18024a850(int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    char cVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    char *pcVar6;
    int64_t iVar7;
    char *pcVar8;
    undefined8 uVar9;
    char *in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    char *pcVar10;
    int32_t in_R8D;
    code *in_R9;
    undefined8 unaff_R15;
    int64_t aiStackX_8 [4];
    undefined8 uStack_28;
    int64_t var_20h;
    
    uStack_28 = 0x18024a862;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    if (in_RCX == (char *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a87b;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar5));
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a893;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + -8), *(int64_t *)((int64_t)aiStackX_8 + iVar5), 
                      *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 8), *(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x10), 
                      *(int64_t *)((int64_t)&arg_30h + iVar5));
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a8a5;
        fcn.1802296d0(*(int64_t *)((int64_t)aiStackX_8 + iVar5 + 0x18));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar5) = unaff_RSI;
    *(undefined8 *)((int64_t)&arg_40h + iVar5) = unaff_RDI;
    *(undefined8 *)((int64_t)aiStackX_8 + iVar5 + -8) = unaff_R15;
    uVar2 = *(undefined8 *)((int64_t)&arg_50h + iVar5);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RBP;
    do {
        if (in_R8D != 0) {
            cVar1 = *in_RCX;
            while (cVar1 != '\0') {
                cVar1 = *in_RCX;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a8e8;
                iVar3 = fcn.18046ce40(cVar1);
                if (iVar3 == 0) break;
                in_RCX = in_RCX + 1;
                cVar1 = *in_RCX;
            }
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a8ff;
        pcVar6 = (char *)fcn.18045b928(in_RCX, in_RDX & 0xffffffff);
        if ((pcVar6 == in_RCX) || (*in_RCX == '\0')) {
            iVar3 = 0;
            in_RCX = (char *)0x0;
        } else {
            pcVar8 = pcVar6;
            if (pcVar6 == (char *)0x0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a919;
                iVar7 = fcn.180498cd0(in_RCX);
                pcVar8 = in_RCX + iVar7;
            }
            pcVar10 = pcVar8 + -1;
            iVar3 = (int32_t)pcVar10;
            if (in_R8D != 0) {
                cVar1 = pcVar8[-1];
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a932;
                iVar4 = fcn.18046ce40(cVar1);
                while (iVar3 = (int32_t)pcVar10, iVar4 != 0) {
                    cVar1 = pcVar10[-1];
                    pcVar10 = pcVar10 + -1;
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a94c;
                    iVar4 = fcn.18046ce40(cVar1);
                }
            }
            iVar3 = (iVar3 - (int32_t)in_RCX) + 1;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x18024a964;
        uVar9 = (*in_R9)(in_RCX, iVar3, uVar2);
        if ((int32_t)uVar9 < 1) {
            return uVar9;
        }
        if (pcVar6 == (char *)0x0) {
            return 1;
        }
        in_RCX = pcVar6 + 1;
    } while( true );
}

// ============================================================
// Function: FUN_18024a9a0
// Address: 0x18024a9a0
// Size: 74 bytes
// ============================================================
undefined8 fcn.18024a9a0(int64_t arg_28h, int64_t arg_30h)
{
    code *pcVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    undefined8 unaff_RDI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18024a9ac;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024a9c9;
    iVar3 = fcn.180222870(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    iVar4 = 0;
    if (iVar3 != 0) {
        iVar4 = *(int32_t *)0x18077e6f8;
    }
    if ((iVar4 != 0) && (*(int64_t *)0x18077e6e0 != 0)) {
        *(undefined8 *)((int64_t)&arg_30h + iVar5) = unaff_RDI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024a9f4;
        func_0x000180222fa0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa00;
        uVar6 = func_0x00018001ed90(0x18077e6f0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa14;
        func_0x000180222a00(0x18077e6f0, (int64_t)&arg_28h + iVar5);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa20;
        func_0x000180222fc0(*(int64_t *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa2c;
        func_0x000180222fe0(*(int64_t *)0x18077e6e0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa34;
        iVar4 = fcn.180222010(uVar6);
        while (0 < iVar4) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa40;
            piVar7 = (int64_t *)func_0x000180222020(uVar6);
            if (piVar7 != (int64_t *)0x0) {
                pcVar1 = *(code **)(*piVar7 + 0x18);
                if (pcVar1 != (code *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa59;
                    (*pcVar1)(piVar7);
                }
                *(int32_t *)(*piVar7 + 0x20) = *(int32_t *)(*piVar7 + 0x20) + -1;
                iVar2 = piVar7[1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa75;
                fcn.180224990(iVar2, 0x1804e4740, 0x26a);
                iVar2 = piVar7[2];
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aa8b;
                fcn.180224990(iVar2, 0x1804e4740, 0x26b);
                *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aaa0;
                fcn.180224990(piVar7, 0x1804e4740, 0x26c);
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aaa8;
            iVar4 = fcn.180222010(uVar6);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18024aab4;
        func_0x000180221d50(uVar6);
        return 1;
    }
    return 0;
}

