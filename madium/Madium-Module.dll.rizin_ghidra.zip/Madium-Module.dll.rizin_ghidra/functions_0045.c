// Chunk 45 - 50 functions

// ============================================================
// Function: FUN_180093a30
// Address: 0x180093a30
// Size: 180 bytes
// ============================================================
void fcn.180093a30(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint32_t *puVar2;
    char cVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int32_t iVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    uint64_t uVar14;
    int64_t unaff_RBX;
    undefined8 unaff_RSI;
    int64_t unaff_RDI;
    int32_t iVar15;
    undefined4 *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStack_30 [5];
    
    if (*(char *)(arg1 + 3) == '\0') {
        if (arg2 == *(int64_t *)(arg1 + 0x28)) {
            auStack_30[0] = 0x180093ae3;
            func_0x000180093000(arg1, 0x18063e0d0);
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        auStack_30[0] = 0x180093a5f;
        iVar11 = func_0x0001800a5fa0(arg1, arg2 + -0x10, 0xffffffff);
        if (*(char *)(arg1 + 3) == '\x7f') {
            arg2 = *(int64_t *)(arg1 + 0x28);
        } else {
            if (iVar11 != 0) {
                return;
            }
            puVar2 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
            *puVar2 = *puVar2 | 1;
        }
    }
    if (*(char *)(arg1 + 3) != '\0') {
        *(undefined *)(arg1 + 3) = 0;
        iVar6 = **(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8);
        if ((*(char *)(iVar6 + 3) != '\0') && (iVar6 + 0x28 + *(int64_t *)(iVar6 + 0x28) == 0)) {
            auStack_30[0] = 0x180093aaa;
            func_0x0001800a6160(arg1, arg2);
            arg2 = unaff_RDI;
            goto code_r0x000180093890;
        }
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(*(int64_t *)(arg1 + 0x18) + 0x10);
    }
    *(undefined8 **)0x20 = (BADSPACEBASE *)auStack_30;
    auStack_30[0] = 0x180093acc;
    unaff_RBX = arg1;
code_r0x000180093890:
    *(int64_t *)((int64_t)*(undefined **)0x20 + 0x10) = unaff_RBX;
    *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RSI;
    *(int64_t *)((int64_t)*(undefined **)0x20 + 8) = arg2;
    do {
        do {
            while( true ) {
                if (((*(char *)(arg1 + 3) != '\0') && (*(char *)(arg1 + 3) != '\x7f')) ||
                   (uVar14 = *(uint64_t *)(arg1 + 0x18), uVar14 <= *(uint64_t *)(arg1 + 0x78))) {
                    return;
                }
                *(undefined *)(arg1 + 3) = 0;
                iVar6 = **(int64_t **)(uVar14 + 8);
                if (*(char *)(iVar6 + 3) != '\0') break;
                if ((*(char *)0x180777dd8 != '\0') && ((*(uint32_t *)(uVar14 + 0x24) & 8) != 0)) {
                    *(uint32_t *)(uVar14 + 0x24) = *(uint32_t *)(uVar14 + 0x24) & 0xfffffff7;
                    iVar6 = *(int64_t *)(uVar14 + 0x18);
                    iVar11 = *(int32_t *)(iVar6 + -4);
                    uVar14 = (uint64_t)(uint8_t)((uint32_t)iVar11 >> 8);
                    iVar4 = *(int64_t *)(arg1 + 0x28);
                    puVar13 = (undefined4 *)(iVar4 + 0x30 + uVar14 * 0x10);
                    uVar8 = puVar13[1];
                    uVar9 = puVar13[2];
                    uVar10 = puVar13[3];
                    puVar5 = (undefined4 *)(iVar4 + 0x20 + uVar14 * 0x10);
                    *puVar5 = *puVar13;
                    puVar5[1] = uVar8;
                    puVar5[2] = uVar9;
                    puVar5[3] = uVar10;
                    if (*(int32_t *)(iVar4 + 0x3c + uVar14 * 0x10) == 0) {
                        iVar11 = 1;
                    } else {
                        iVar11 = iVar11 >> 0x10;
                    }
                    *(int64_t *)(*(int64_t *)(arg1 + 0x18) + 0x18) = iVar6 + (int64_t)iVar11 * 4;
                }
                *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x180093a0d;
                (**(code **)0x1807825a0)(arg1);
            }
            if (*(char *)0x180777030 != '\0') {
                *(uint32_t *)(uVar14 + 0x24) = *(uint32_t *)(uVar14 + 0x24) & 0xfffffffd;
            }
            iVar4 = *(int64_t *)(iVar6 + 0x28);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x1800938f7;
            iVar11 = (*(code *)(iVar4 + 0x28 + iVar6))(arg1, 0);
            cVar3 = *(char *)(arg1 + 3);
            if (cVar3 == '\x06') {
                return;
            }
            if (cVar3 == '\x01') {
                return;
            }
        } while ((*(char *)0x180777030 != '\0') && (cVar3 == '\x7f'));
        iVar6 = *(int64_t *)(arg1 + 0x40);
        iVar4 = *(int64_t *)(arg1 + 0x18);
        if (*(char *)0x180777df8 != '\0') {
            piVar1 = (int64_t *)(**(int64_t **)(iVar4 + 8) + 8);
            *piVar1 = *piVar1 + -1;
        }
        iVar15 = *(int32_t *)(iVar4 + 0x20);
        puVar13 = *(undefined4 **)(iVar4 + 8);
        puVar5 = *(undefined4 **)(arg1 + 0x40);
        puVar12 = puVar13;
        puVar16 = (undefined4 *)(iVar6 + (int64_t)iVar11 * -0x10);
        if (iVar15 != 0) {
            do {
                puVar13 = puVar12;
                if (puVar5 <= puVar16) break;
                puVar13 = puVar12 + 4;
                uVar8 = puVar16[1];
                uVar9 = puVar16[2];
                uVar10 = puVar16[3];
                *puVar12 = *puVar16;
                puVar12[1] = uVar8;
                puVar12[2] = uVar9;
                puVar12[3] = uVar10;
                iVar15 = iVar15 + -1;
                puVar12 = puVar13;
                puVar16 = puVar16 + 4;
            } while (iVar15 != 0);
            for (; 0 < iVar15; iVar15 = iVar15 + -1) {
                puVar13[3] = 0;
                puVar13 = puVar13 + 4;
            }
        }
        *(undefined8 **)(arg1 + 0x18) = (undefined8 *)(iVar4 + -0x28);
        *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(iVar4 + -0x18);
        if (*(int32_t *)(iVar4 + 0x20) != -1) {
            puVar13 = *(undefined4 **)(undefined8 *)(iVar4 + -0x28);
        }
        *(undefined4 **)(arg1 + 0x40) = puVar13;
    } while( true );
}

// ============================================================
// Function: FUN_180093af0
// Address: 0x180093af0
// Size: 103 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180093af0(int64_t arg1, int64_t arg2)
{
    uint32_t *puVar1;
    char cVar2;
    uint16_t uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    code *pcVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    int32_t iVar10;
    int32_t iVar11;
    int64_t iVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    puVar5 = *(undefined4 **)(arg1 + 0x40);
    *puVar5 = puVar5[-4];
    puVar5[1] = puVar5[-3];
    puVar5[2] = puVar5[-2];
    puVar5[3] = puVar5[-1];
    iVar12 = *(int64_t *)(arg1 + 0x40);
    uVar7 = *(undefined4 *)(arg2 + 4);
    uVar8 = *(undefined4 *)(arg2 + 8);
    uVar9 = *(undefined4 *)(arg2 + 0xc);
    *(undefined4 *)(iVar12 + -0x10) = *(undefined4 *)arg2;
    *(undefined4 *)(iVar12 + -0xc) = uVar7;
    *(undefined4 *)(iVar12 + -8) = uVar8;
    *(undefined4 *)(iVar12 + -4) = uVar9;
    if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
        iVar11 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
        iVar10 = iVar11 * 2;
        if (iVar11 < 1) {
            iVar10 = iVar11 + 1;
        }
        func_0x000180093240(arg1, iVar10, 0);
    }
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    iVar12 = *(int64_t *)(arg1 + 0x40) + -0x20;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + 1;
    uVar3 = *(uint16_t *)(arg1 + 0x68);
    if (199 < uVar3) {
        if (uVar3 == 200) {
            func_0x000180093000(arg1, 0x18063e0f0);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if (0xe0 < uVar3) {
            func_0x0001800931b0(arg1, 5);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
    }
    iVar4 = *(int64_t *)(arg1 + 0x38);
    iVar10 = func_0x0001800a5fa0(arg1, iVar12, 1);
    if (iVar10 == 0) {
        puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x18) + 0x24);
        *puVar1 = *puVar1 | 1;
        cVar2 = *(char *)(arg1 + 6);
        *(undefined *)(arg1 + 6) = 1;
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        (**(code **)0x1807825a0)(arg1);
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
    }
    *(int64_t *)(arg1 + 0x40) = (*(int64_t *)(arg1 + 0x38) - iVar4) + 0x10 + iVar12;
    *(int16_t *)(arg1 + 0x68) = *(int16_t *)(arg1 + 0x68) + -1;
    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
        (**(code **)0x180782658)(arg1, 1);
    }
    return;
}

// ============================================================
// Function: FUN_180093b60
// Address: 0x180093b60
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180093b60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar3 = **(int64_t **)(arg2 + 8);
    if (*(char *)0x180777850 == '\0') {
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
    }
    *(uint32_t *)(arg2 + 0x24) = *(uint32_t *)(arg2 + 0x24) & 0xfffffffd;
    cVar4 = *(char *)(arg1 + 3);
    *(undefined *)(arg1 + 3) = 0;
    if (cVar4 != '\x02') {
        func_0x000180093800(arg1, cVar4, *(undefined8 *)(arg1 + 0x40));
    }
    if ((*(char *)0x180777030 != '\0') && (*(int32_t *)(arg2 + 0x18) != 0)) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = func_0x000180093190(arg1, fcn.180093af0, 
                                    (int64_t)(*(int32_t *)(arg2 + 0x18) + -1) * 0x10 + *(int64_t *)(arg2 + 0x10));
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
        if (iVar2 == 0) {
            cVar4 = '\x02';
        } else if ((cVar4 != '\x04') || (iVar2 != 4)) {
            cVar4 = '\x05';
        }
        func_0x000180093800(arg1, cVar4, *(int64_t *)(arg1 + 0x40) + -0x10);
        arg2 = *(int64_t *)(arg1 + 0x78) + (arg2 - iVar1);
        *(undefined4 *)(arg2 + 0x18) = 0;
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        arg2 = arg2 + (*(int64_t *)(arg1 + 0x78) - iVar1);
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(undefined8 *)(arg2 + 0x10));
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    } else {
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(int64_t *)(arg2 + 0x10));
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        if (*(char *)(arg1 + 3) != '\0') {
            return;
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    }
    func_0x0001800a6160(arg1, iVar3);
    func_0x000180093890(arg1);
    return;
}

// ============================================================
// Function: FUN_180093b7b
// Address: 0x180093b7b
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180093b60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar3 = **(int64_t **)(arg2 + 8);
    if (*(char *)0x180777850 == '\0') {
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
    }
    *(uint32_t *)(arg2 + 0x24) = *(uint32_t *)(arg2 + 0x24) & 0xfffffffd;
    cVar4 = *(char *)(arg1 + 3);
    *(undefined *)(arg1 + 3) = 0;
    if (cVar4 != '\x02') {
        func_0x000180093800(arg1, cVar4, *(undefined8 *)(arg1 + 0x40));
    }
    if ((*(char *)0x180777030 != '\0') && (*(int32_t *)(arg2 + 0x18) != 0)) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = func_0x000180093190(arg1, fcn.180093af0, 
                                    (int64_t)(*(int32_t *)(arg2 + 0x18) + -1) * 0x10 + *(int64_t *)(arg2 + 0x10));
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
        if (iVar2 == 0) {
            cVar4 = '\x02';
        } else if ((cVar4 != '\x04') || (iVar2 != 4)) {
            cVar4 = '\x05';
        }
        func_0x000180093800(arg1, cVar4, *(int64_t *)(arg1 + 0x40) + -0x10);
        arg2 = *(int64_t *)(arg1 + 0x78) + (arg2 - iVar1);
        *(undefined4 *)(arg2 + 0x18) = 0;
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        arg2 = arg2 + (*(int64_t *)(arg1 + 0x78) - iVar1);
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(undefined8 *)(arg2 + 0x10));
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    } else {
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(int64_t *)(arg2 + 0x10));
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        if (*(char *)(arg1 + 3) != '\0') {
            return;
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    }
    func_0x0001800a6160(arg1, iVar3);
    func_0x000180093890(arg1);
    return;
}

// ============================================================
// Function: FUN_180093bcf
// Address: 0x180093bcf
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180093b60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar3 = **(int64_t **)(arg2 + 8);
    if (*(char *)0x180777850 == '\0') {
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
    }
    *(uint32_t *)(arg2 + 0x24) = *(uint32_t *)(arg2 + 0x24) & 0xfffffffd;
    cVar4 = *(char *)(arg1 + 3);
    *(undefined *)(arg1 + 3) = 0;
    if (cVar4 != '\x02') {
        func_0x000180093800(arg1, cVar4, *(undefined8 *)(arg1 + 0x40));
    }
    if ((*(char *)0x180777030 != '\0') && (*(int32_t *)(arg2 + 0x18) != 0)) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = func_0x000180093190(arg1, fcn.180093af0, 
                                    (int64_t)(*(int32_t *)(arg2 + 0x18) + -1) * 0x10 + *(int64_t *)(arg2 + 0x10));
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
        if (iVar2 == 0) {
            cVar4 = '\x02';
        } else if ((cVar4 != '\x04') || (iVar2 != 4)) {
            cVar4 = '\x05';
        }
        func_0x000180093800(arg1, cVar4, *(int64_t *)(arg1 + 0x40) + -0x10);
        arg2 = *(int64_t *)(arg1 + 0x78) + (arg2 - iVar1);
        *(undefined4 *)(arg2 + 0x18) = 0;
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        arg2 = arg2 + (*(int64_t *)(arg1 + 0x78) - iVar1);
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(undefined8 *)(arg2 + 0x10));
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    } else {
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(int64_t *)(arg2 + 0x10));
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        if (*(char *)(arg1 + 3) != '\0') {
            return;
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    }
    func_0x0001800a6160(arg1, iVar3);
    func_0x000180093890(arg1);
    return;
}

// ============================================================
// Function: FUN_180093c46
// Address: 0x180093c46
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180093b60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar3 = **(int64_t **)(arg2 + 8);
    if (*(char *)0x180777850 == '\0') {
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
    }
    *(uint32_t *)(arg2 + 0x24) = *(uint32_t *)(arg2 + 0x24) & 0xfffffffd;
    cVar4 = *(char *)(arg1 + 3);
    *(undefined *)(arg1 + 3) = 0;
    if (cVar4 != '\x02') {
        func_0x000180093800(arg1, cVar4, *(undefined8 *)(arg1 + 0x40));
    }
    if ((*(char *)0x180777030 != '\0') && (*(int32_t *)(arg2 + 0x18) != 0)) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = func_0x000180093190(arg1, fcn.180093af0, 
                                    (int64_t)(*(int32_t *)(arg2 + 0x18) + -1) * 0x10 + *(int64_t *)(arg2 + 0x10));
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
        if (iVar2 == 0) {
            cVar4 = '\x02';
        } else if ((cVar4 != '\x04') || (iVar2 != 4)) {
            cVar4 = '\x05';
        }
        func_0x000180093800(arg1, cVar4, *(int64_t *)(arg1 + 0x40) + -0x10);
        arg2 = *(int64_t *)(arg1 + 0x78) + (arg2 - iVar1);
        *(undefined4 *)(arg2 + 0x18) = 0;
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        arg2 = arg2 + (*(int64_t *)(arg1 + 0x78) - iVar1);
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(undefined8 *)(arg2 + 0x10));
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    } else {
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(int64_t *)(arg2 + 0x10));
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        if (*(char *)(arg1 + 3) != '\0') {
            return;
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    }
    func_0x0001800a6160(arg1, iVar3);
    func_0x000180093890(arg1);
    return;
}

// ============================================================
// Function: FUN_180093c5b
// Address: 0x180093c5b
// Size: 289 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180093b60(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int32_t iVar2;
    int64_t iVar3;
    char cVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    iVar3 = **(int64_t **)(arg2 + 8);
    if (*(char *)0x180777850 == '\0') {
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
    }
    *(uint32_t *)(arg2 + 0x24) = *(uint32_t *)(arg2 + 0x24) & 0xfffffffd;
    cVar4 = *(char *)(arg1 + 3);
    *(undefined *)(arg1 + 3) = 0;
    if (cVar4 != '\x02') {
        func_0x000180093800(arg1, cVar4, *(undefined8 *)(arg1 + 0x40));
    }
    if ((*(char *)0x180777030 != '\0') && (*(int32_t *)(arg2 + 0x18) != 0)) {
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = func_0x000180093190(arg1, fcn.180093af0, 
                                    (int64_t)(*(int32_t *)(arg2 + 0x18) + -1) * 0x10 + *(int64_t *)(arg2 + 0x10));
        *(undefined2 *)(arg1 + 0x68) = *(undefined2 *)(arg1 + 0x6a);
        if (iVar2 == 0) {
            cVar4 = '\x02';
        } else if ((cVar4 != '\x04') || (iVar2 != 4)) {
            cVar4 = '\x05';
        }
        func_0x000180093800(arg1, cVar4, *(int64_t *)(arg1 + 0x40) + -0x10);
        arg2 = *(int64_t *)(arg1 + 0x78) + (arg2 - iVar1);
        *(undefined4 *)(arg2 + 0x18) = 0;
    }
    piVar5 = (int64_t *)(arg1 + 0x40);
    if (*(char *)0x180777030 == '\0') {
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        iVar1 = *(int64_t *)(arg1 + 0x78);
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        arg2 = arg2 + (*(int64_t *)(arg1 + 0x78) - iVar1);
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(undefined8 *)(arg2 + 0x10));
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    } else {
        *(int64_t *)(arg1 + 0x18) = arg2;
        func_0x000180094340(arg1, *(int64_t *)(arg2 + 0x10));
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg2 + 0x10);
        *(int64_t *)arg2 = *piVar5;
        if ((20000 < *(int32_t *)(arg1 + 100)) &&
           ((int32_t)(*(int64_t *)(arg1 + 0x18) - *(int64_t *)(arg1 + 0x78) >> 3) * -0x33333333 + 1 < 20000)) {
            func_0x0001800933e0(arg1, 20000);
        }
        iVar2 = (*(code *)(*(int64_t *)(iVar3 + 0x28) + 0x28 + iVar3))(arg1, cVar4);
        if (*(char *)(arg1 + 3) != '\0') {
            return;
        }
        iVar3 = *piVar5 + (int64_t)iVar2 * -0x10;
    }
    func_0x0001800a6160(arg1, iVar3);
    func_0x000180093890(arg1);
    return;
}

// ============================================================
// Function: FUN_180093d80
// Address: 0x180093d80
// Size: 283 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180093d80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    int32_t iVar2;
    uint16_t uVar3;
    int32_t iVar4;
    undefined8 uVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    int64_t var_8h;
    
    cVar1 = *(char *)(arg1 + 3);
    if (((cVar1 != '\x01') && (cVar1 != '\x06')) &&
       ((cVar1 != '\0' || (*(int64_t *)(arg1 + 0x18) != *(int64_t *)(arg1 + 0x78))))) {
        uVar5 = 0x18063e0a8;
        uVar7 = 0x25;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)arg3 * -0x10;
        puVar6 = *(undefined8 **)(arg1 + 0x40);
code_r0x000180093dca:
        uVar5 = func_0x00018009a8e0(arg1, uVar5, uVar7);
        *puVar6 = uVar5;
        *(undefined4 *)((int64_t)puVar6 + 0xc) = 6;
        if (*(int64_t *)(arg1 + 0x30) - *(int64_t *)(arg1 + 0x40) < 0x11) {
            iVar4 = *(int32_t *)(arg1 + 0x60) - ((int32_t)arg1 + 0x60);
            iVar2 = iVar4 * 2;
            if (iVar4 < 1) {
                iVar2 = iVar4 + 1;
            }
            func_0x000180093240(arg1, iVar2, 0);
        }
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return 2;
    }
    if (arg2 == 0) {
        uVar3 = 0;
        *(undefined2 *)(arg1 + 0x68) = 0;
    } else {
        uVar3 = *(uint16_t *)(arg2 + 0x68);
        *(uint16_t *)(arg1 + 0x68) = uVar3;
        if (199 < uVar3) {
            uVar5 = 0x18063e0f0;
            uVar7 = 0x10;
            *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)arg3 * -0x10;
            puVar6 = *(undefined8 **)(arg1 + 0x40);
            goto code_r0x000180093dca;
        }
    }
    *(uint16_t *)(arg1 + 0x68) = uVar3 + 1;
    *(uint16_t *)(arg1 + 0x6a) = uVar3 + 1;
    *(undefined *)(arg1 + 6) = 1;
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    return 0;
}

// ============================================================
// Function: FUN_180093ea0
// Address: 0x180093ea0
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined fcn.180093ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int16_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = (int16_t)arg3;
    iVar3 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar3 != 0) {
        do {
            iVar3 = (int32_t)uVar6;
            uVar4 = *(uint64_t *)(arg1 + 0x18);
            while( true ) {
                if (uVar4 <= *(uint64_t *)(arg1 + 0x78)) goto code_r0x000180093f5c;
                if ((*(uint8_t *)(uVar4 + 0x24) & 2) != 0) break;
                uVar4 = uVar4 - 0x28;
            }
            if (((*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) &&
                (pcVar1 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x518), pcVar1 != (code *)0x0)) &&
               ((*pcVar1)(arg1), *(char *)(arg1 + 3) == '\x06')) {
                iVar3 = 0;
                goto code_r0x000180093f5c;
            }
            if (*(char *)0x180777850 != '\0') {
                *(int16_t *)(arg1 + 0x68) = iVar5;
                *(int16_t *)(arg1 + 0x6a) = iVar5;
            }
            *(char *)(arg1 + 3) = (char)uVar6;
            uVar2 = func_0x000180093190(arg1, fcn.180093b60, uVar4);
            uVar6 = (uint64_t)uVar2;
        } while (uVar2 != 0);
        iVar3 = 0;
    }
code_r0x000180093f5c:
    if (*(char *)0x180777850 == '\0') {
        iVar5 = *(int16_t *)(arg1 + 0x6a);
    }
    *(int16_t *)(arg1 + 0x68) = iVar5 + -1;
    *(int16_t *)(arg1 + 0x6a) = iVar5 + -1;
    *(undefined *)(arg1 + 6) = 0;
    if (iVar3 != 0) {
        *(char *)(arg1 + 3) = (char)iVar3;
        func_0x000180093800(arg1, iVar3, *(undefined8 *)(arg1 + 0x40));
        **(undefined8 **)(arg1 + 0x18) = *(undefined8 *)(arg1 + 0x40);
        return *(undefined *)(arg1 + 3);
    }
    if (*(char *)(arg1 + 3) == '\0') {
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
    }
    return *(undefined *)(arg1 + 3);
}

// ============================================================
// Function: FUN_180093ea8
// Address: 0x180093ea8
// Size: 22 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined fcn.180093ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int16_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = (int16_t)arg3;
    iVar3 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar3 != 0) {
        do {
            iVar3 = (int32_t)uVar6;
            uVar4 = *(uint64_t *)(arg1 + 0x18);
            while( true ) {
                if (uVar4 <= *(uint64_t *)(arg1 + 0x78)) goto code_r0x000180093f5c;
                if ((*(uint8_t *)(uVar4 + 0x24) & 2) != 0) break;
                uVar4 = uVar4 - 0x28;
            }
            if (((*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) &&
                (pcVar1 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x518), pcVar1 != (code *)0x0)) &&
               ((*pcVar1)(arg1), *(char *)(arg1 + 3) == '\x06')) {
                iVar3 = 0;
                goto code_r0x000180093f5c;
            }
            if (*(char *)0x180777850 != '\0') {
                *(int16_t *)(arg1 + 0x68) = iVar5;
                *(int16_t *)(arg1 + 0x6a) = iVar5;
            }
            *(char *)(arg1 + 3) = (char)uVar6;
            uVar2 = func_0x000180093190(arg1, fcn.180093b60, uVar4);
            uVar6 = (uint64_t)uVar2;
        } while (uVar2 != 0);
        iVar3 = 0;
    }
code_r0x000180093f5c:
    if (*(char *)0x180777850 == '\0') {
        iVar5 = *(int16_t *)(arg1 + 0x6a);
    }
    *(int16_t *)(arg1 + 0x68) = iVar5 + -1;
    *(int16_t *)(arg1 + 0x6a) = iVar5 + -1;
    *(undefined *)(arg1 + 6) = 0;
    if (iVar3 != 0) {
        *(char *)(arg1 + 3) = (char)iVar3;
        func_0x000180093800(arg1, iVar3, *(undefined8 *)(arg1 + 0x40));
        **(undefined8 **)(arg1 + 0x18) = *(undefined8 *)(arg1 + 0x40);
        return *(undefined *)(arg1 + 3);
    }
    if (*(char *)(arg1 + 3) == '\0') {
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
    }
    return *(undefined *)(arg1 + 3);
}

// ============================================================
// Function: FUN_180093ebe
// Address: 0x180093ebe
// Size: 158 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined fcn.180093ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int16_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = (int16_t)arg3;
    iVar3 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar3 != 0) {
        do {
            iVar3 = (int32_t)uVar6;
            uVar4 = *(uint64_t *)(arg1 + 0x18);
            while( true ) {
                if (uVar4 <= *(uint64_t *)(arg1 + 0x78)) goto code_r0x000180093f5c;
                if ((*(uint8_t *)(uVar4 + 0x24) & 2) != 0) break;
                uVar4 = uVar4 - 0x28;
            }
            if (((*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) &&
                (pcVar1 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x518), pcVar1 != (code *)0x0)) &&
               ((*pcVar1)(arg1), *(char *)(arg1 + 3) == '\x06')) {
                iVar3 = 0;
                goto code_r0x000180093f5c;
            }
            if (*(char *)0x180777850 != '\0') {
                *(int16_t *)(arg1 + 0x68) = iVar5;
                *(int16_t *)(arg1 + 0x6a) = iVar5;
            }
            *(char *)(arg1 + 3) = (char)uVar6;
            uVar2 = func_0x000180093190(arg1, fcn.180093b60, uVar4);
            uVar6 = (uint64_t)uVar2;
        } while (uVar2 != 0);
        iVar3 = 0;
    }
code_r0x000180093f5c:
    if (*(char *)0x180777850 == '\0') {
        iVar5 = *(int16_t *)(arg1 + 0x6a);
    }
    *(int16_t *)(arg1 + 0x68) = iVar5 + -1;
    *(int16_t *)(arg1 + 0x6a) = iVar5 + -1;
    *(undefined *)(arg1 + 6) = 0;
    if (iVar3 != 0) {
        *(char *)(arg1 + 3) = (char)iVar3;
        func_0x000180093800(arg1, iVar3, *(undefined8 *)(arg1 + 0x40));
        **(undefined8 **)(arg1 + 0x18) = *(undefined8 *)(arg1 + 0x40);
        return *(undefined *)(arg1 + 3);
    }
    if (*(char *)(arg1 + 3) == '\0') {
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
    }
    return *(undefined *)(arg1 + 3);
}

// ============================================================
// Function: FUN_180093f5c
// Address: 0x180093f5c
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined fcn.180093ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int16_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = (int16_t)arg3;
    iVar3 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar3 != 0) {
        do {
            iVar3 = (int32_t)uVar6;
            uVar4 = *(uint64_t *)(arg1 + 0x18);
            while( true ) {
                if (uVar4 <= *(uint64_t *)(arg1 + 0x78)) goto code_r0x000180093f5c;
                if ((*(uint8_t *)(uVar4 + 0x24) & 2) != 0) break;
                uVar4 = uVar4 - 0x28;
            }
            if (((*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) &&
                (pcVar1 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x518), pcVar1 != (code *)0x0)) &&
               ((*pcVar1)(arg1), *(char *)(arg1 + 3) == '\x06')) {
                iVar3 = 0;
                goto code_r0x000180093f5c;
            }
            if (*(char *)0x180777850 != '\0') {
                *(int16_t *)(arg1 + 0x68) = iVar5;
                *(int16_t *)(arg1 + 0x6a) = iVar5;
            }
            *(char *)(arg1 + 3) = (char)uVar6;
            uVar2 = func_0x000180093190(arg1, fcn.180093b60, uVar4);
            uVar6 = (uint64_t)uVar2;
        } while (uVar2 != 0);
        iVar3 = 0;
    }
code_r0x000180093f5c:
    if (*(char *)0x180777850 == '\0') {
        iVar5 = *(int16_t *)(arg1 + 0x6a);
    }
    *(int16_t *)(arg1 + 0x68) = iVar5 + -1;
    *(int16_t *)(arg1 + 0x6a) = iVar5 + -1;
    *(undefined *)(arg1 + 6) = 0;
    if (iVar3 != 0) {
        *(char *)(arg1 + 3) = (char)iVar3;
        func_0x000180093800(arg1, iVar3, *(undefined8 *)(arg1 + 0x40));
        **(undefined8 **)(arg1 + 0x18) = *(undefined8 *)(arg1 + 0x40);
        return *(undefined *)(arg1 + 3);
    }
    if (*(char *)(arg1 + 3) == '\0') {
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
    }
    return *(undefined *)(arg1 + 3);
}

// ============================================================
// Function: FUN_180093f86
// Address: 0x180093f86
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined fcn.180093ea0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint32_t uVar2;
    int32_t iVar3;
    uint64_t uVar4;
    int16_t iVar5;
    uint64_t uVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar5 = (int16_t)arg3;
    iVar3 = (int32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    if (iVar3 != 0) {
        do {
            iVar3 = (int32_t)uVar6;
            uVar4 = *(uint64_t *)(arg1 + 0x18);
            while( true ) {
                if (uVar4 <= *(uint64_t *)(arg1 + 0x78)) goto code_r0x000180093f5c;
                if ((*(uint8_t *)(uVar4 + 0x24) & 2) != 0) break;
                uVar4 = uVar4 - 0x28;
            }
            if (((*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) &&
                (pcVar1 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x518), pcVar1 != (code *)0x0)) &&
               ((*pcVar1)(arg1), *(char *)(arg1 + 3) == '\x06')) {
                iVar3 = 0;
                goto code_r0x000180093f5c;
            }
            if (*(char *)0x180777850 != '\0') {
                *(int16_t *)(arg1 + 0x68) = iVar5;
                *(int16_t *)(arg1 + 0x6a) = iVar5;
            }
            *(char *)(arg1 + 3) = (char)uVar6;
            uVar2 = func_0x000180093190(arg1, fcn.180093b60, uVar4);
            uVar6 = (uint64_t)uVar2;
        } while (uVar2 != 0);
        iVar3 = 0;
    }
code_r0x000180093f5c:
    if (*(char *)0x180777850 == '\0') {
        iVar5 = *(int16_t *)(arg1 + 0x6a);
    }
    *(int16_t *)(arg1 + 0x68) = iVar5 + -1;
    *(int16_t *)(arg1 + 0x6a) = iVar5 + -1;
    *(undefined *)(arg1 + 6) = 0;
    if (iVar3 != 0) {
        *(char *)(arg1 + 3) = (char)iVar3;
        func_0x000180093800(arg1, iVar3, *(undefined8 *)(arg1 + 0x40));
        **(undefined8 **)(arg1 + 0x18) = *(undefined8 *)(arg1 + 0x40);
        return *(undefined *)(arg1 + 3);
    }
    if (*(char *)(arg1 + 3) == '\0') {
        if (**(uint64_t **)(arg1 + 0x18) < *(uint64_t *)(arg1 + 0x40)) {
            **(uint64_t **)(arg1 + 0x18) = *(uint64_t *)(arg1 + 0x40);
        }
    }
    return *(undefined *)(arg1 + 3);
}

// ============================================================
// Function: FUN_180093fe0
// Address: 0x180093fe0
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180093fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint16_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = fcn.180093d80(arg1, arg2, arg3 & 0xffffffff);
    if (iVar2 == 0) {
        uVar1 = *(uint16_t *)(arg1 + 0x68);
        uVar3 = fcn.180093190(arg1, fcn.180093a30, *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)arg3 * -0x10);
        fcn.180093ea0(arg1, (uint64_t)uVar3, (uint64_t)uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_18009400a
// Address: 0x18009400a
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180093fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint16_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = fcn.180093d80(arg1, arg2, arg3 & 0xffffffff);
    if (iVar2 == 0) {
        uVar1 = *(uint16_t *)(arg1 + 0x68);
        uVar3 = fcn.180093190(arg1, fcn.180093a30, *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)arg3 * -0x10);
        fcn.180093ea0(arg1, (uint64_t)uVar3, (uint64_t)uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_180094034
// Address: 0x180094034
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180093fe0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint16_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = fcn.180093d80(arg1, arg2, arg3 & 0xffffffff);
    if (iVar2 == 0) {
        uVar1 = *(uint16_t *)(arg1 + 0x68);
        uVar3 = fcn.180093190(arg1, fcn.180093a30, *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)arg3 * -0x10);
        fcn.180093ea0(arg1, (uint64_t)uVar3, (uint64_t)uVar1);
    }
    return;
}

// ============================================================
// Function: FUN_180094040
// Address: 0x180094040
// Size: 63 bytes
// ============================================================
undefined8 fcn.180094040(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined8 uVar2;
    
    if (*(uint16_t *)(arg1 + 0x68) <= *(uint16_t *)(arg1 + 0x6a)) {
        *(undefined *)(arg1 + 3) = 1;
        *(int64_t *)(arg1 + 0x28) = *(int64_t *)(arg1 + 0x40) + (int64_t)(int32_t)arg2 * -0x10;
        return 0xffffffff;
    }
    fcn.180093000(arg1, 0x18063e070);
    pcVar1 = (code *)swi(3);
    uVar2 = (*pcVar1)();
    return uVar2;
}

// ============================================================
// Function: FUN_180094080
// Address: 0x180094080
// Size: 392 bytes
// ============================================================
int32_t fcn.180094080(int64_t arg1, undefined8 placeholder_1, undefined8 placeholder_2, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    char cVar2;
    undefined2 uVar3;
    undefined2 uVar4;
    uint16_t uVar5;
    uint16_t uVar6;
    code *pcVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t iVar12;
    int64_t var_20h;
    
    uVar3 = *(undefined2 *)(arg1 + 0x68);
    uVar4 = *(undefined2 *)(arg1 + 0x6a);
    iVar12 = *(int64_t *)(arg1 + 0x18);
    iVar10 = *(int64_t *)(arg1 + 0x78);
    cVar2 = *(char *)(arg1 + 6);
    iVar8 = fcn.180093190();
    if (iVar8 != 0) {
        iVar12 = iVar12 - iVar10;
        if (*(char *)0x180777df8 != '\0') {
            iVar10 = *(int64_t *)(arg1 + 0x78);
            for (iVar11 = *(int64_t *)(arg1 + 0x18); iVar11 != iVar10 + iVar12; iVar11 = iVar11 + -0x28) {
                piVar1 = (int64_t *)(**(int64_t **)(iVar11 + 8) + 8);
                *piVar1 = *piVar1 + -1;
            }
        }
        iVar9 = iVar8;
        if (arg_28h != 0) {
            if (iVar8 != 2) {
                func_0x000180093800(arg1, iVar8, *(undefined8 *)(arg1 + 0x40));
            }
            iVar9 = fcn.180093190(arg1, fcn.180093af0, *(int64_t *)(arg1 + 0x38) + arg_28h);
            if (iVar9 == 0) {
                iVar9 = 2;
            } else if ((iVar8 == 4) && (iVar9 == 4)) {
                iVar9 = 4;
            } else {
                iVar8 = 5;
                iVar9 = 5;
            }
        }
        if (cVar2 == '\0') {
            *(undefined *)(arg1 + 6) = 0;
        }
        uVar5 = *(uint16_t *)(arg1 + 0x68);
        uVar6 = *(uint16_t *)(arg1 + 0x6a);
        *(undefined2 *)(arg1 + 0x68) = uVar3;
        *(undefined2 *)(arg1 + 0x6a) = uVar4;
        if (((uVar6 < uVar5) || (pcVar7 = *(code **)(*(int64_t *)(arg1 + 0x20) + 0x518), pcVar7 == (code *)0x0)) ||
           ((*pcVar7)(arg1), *(char *)(arg1 + 3) != '\x06')) {
            arg4 = *(int64_t *)(arg1 + 0x38) + arg4;
            func_0x000180094340(arg1, arg4);
            func_0x000180093800(arg1, iVar9, arg4);
            iVar10 = *(int64_t *)(arg1 + 0x78) + iVar12;
            *(int64_t *)(arg1 + 0x18) = iVar10;
            *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(iVar10 + 0x10);
            if ((20000 < *(int32_t *)(arg1 + 100)) && ((int32_t)(iVar12 >> 3) * -0x33333333 + 1 < 20000)) {
                func_0x0001800933e0(arg1, 20000);
            }
        } else {
            iVar8 = 0;
        }
    }
    return iVar8;
}

// ============================================================
// Function: FUN_180094210
// Address: 0x180094210
// Size: 156 bytes
// ============================================================
undefined * fcn.180094210(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint8_t uVar1;
    undefined *puVar2;
    uint64_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    
    iVar5 = (int32_t)arg2;
    puVar2 = (undefined *)func_0x000180098710(arg1, (int64_t)iVar5 * 0x10 + 0x28, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    puVar2[2] = 8;
    puVar2[1] = uVar1 & 3;
    *puVar2 = *(undefined *)(arg1 + 4);
    puVar2[3] = 0;
    *(int64_t *)(puVar2 + 0x10) = arg3;
    puVar2[4] = (char)arg2;
    puVar2[5] = *(undefined *)(arg4 + 3);
    uVar3 = 0;
    *(undefined8 *)(puVar2 + 8) = 0;
    puVar2[6] = 0;
    *(int64_t *)(puVar2 + 0x20) = arg4;
    *(undefined8 *)(arg4 + 0x78) = 1;
    if (0 < iVar5) {
        do {
            uVar4 = (int32_t)uVar3 + 1;
            *(undefined4 *)(puVar2 + uVar3 * 0x10 + 0x34) = 0;
            uVar3 = (uint64_t)uVar4;
        } while ((int32_t)uVar4 < iVar5);
    }
    return puVar2;
}

// ============================================================
// Function: FUN_1800942b0
// Address: 0x1800942b0
// Size: 140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined * fcn.1800942b0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    undefined uVar2;
    undefined *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar3 = (undefined *)fcn.180098710(arg1, (int64_t)(int32_t)arg2 * 0x10 + 0x38, *(undefined *)(arg1 + 4));
    uVar1 = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58);
    puVar3[2] = 8;
    puVar3[1] = uVar1 & 3;
    uVar2 = *(undefined *)(arg1 + 4);
    puVar3[4] = (char)arg2;
    *puVar3 = uVar2;
    puVar3[3] = 2;
    *(int64_t *)(puVar3 + 0x10) = arg3;
    *(undefined2 *)(puVar3 + 5) = 0x14;
    *(undefined8 *)(puVar3 + 8) = 0;
    *(undefined8 *)(puVar3 + 0x20) = 0;
    *(int64_t *)(puVar3 + 0x28) = -(int64_t)(puVar3 + 0x28);
    *(undefined **)(puVar3 + 0x30) = puVar3 + 0x30;
    return puVar3;
}

// ============================================================
// Function: FUN_180094340
// Address: 0x180094340
// Size: 220 bytes
// ============================================================
void fcn.180094340(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    uint8_t uVar2;
    int64_t iVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    
    iVar3 = *(int64_t *)(arg1 + 0x10);
    while ((iVar3 != 0 && ((uint64_t)arg2 <= *(uint64_t *)(iVar3 + 8)))) {
        piVar1 = (int64_t *)(iVar3 + 0x10);
        *(undefined8 *)(arg1 + 0x10) = *(undefined8 *)(iVar3 + 0x20);
        *(int64_t *)(*(int64_t *)(iVar3 + 0x18) + 0x10) = *piVar1;
        *(undefined8 *)(*piVar1 + 0x18) = *(undefined8 *)(iVar3 + 0x18);
        puVar4 = *(undefined4 **)(iVar3 + 8);
        uVar6 = puVar4[1];
        uVar7 = puVar4[2];
        uVar8 = puVar4[3];
        *(undefined4 *)piVar1 = *puVar4;
        *(undefined4 *)(iVar3 + 0x14) = uVar6;
        *(undefined4 *)(iVar3 + 0x18) = uVar7;
        *(undefined4 *)(iVar3 + 0x1c) = uVar8;
        uVar2 = *(uint8_t *)(iVar3 + 1);
        *(int64_t **)(iVar3 + 8) = piVar1;
        if ((uVar2 & 7) == 0) {
            if ((uint8_t)(*(char *)(*(int64_t *)(arg1 + 0x20) + 0x59) - 1U) < 3) {
                *(uint8_t *)(iVar3 + 1) = uVar2 | 4;
                if ((5 < *(int32_t *)(iVar3 + 0x1c)) && ((*(uint8_t *)(*piVar1 + 1) & 3) != 0)) {
                    iVar5 = *(int64_t *)(arg1 + 0x20);
                    if ((uint8_t)(*(char *)(iVar5 + 0x59) - 1U) < 3) {
                        func_0x000180094420(iVar5, *piVar1);
                    } else {
                        *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(iVar5 + 0x58) & 3 | uVar2 & 0xf8;
                    }
                }
            } else {
                *(uint8_t *)(iVar3 + 1) = *(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0x58) & 3 | uVar2 & 0xf8;
            }
        }
        iVar3 = *(int64_t *)(arg1 + 0x10);
    }
    return;
}

// ============================================================
// Function: FUN_180094420
// Address: 0x180094420
// Size: 264 bytes
// ============================================================
void fcn.180094420(int64_t arg1, int64_t arg2)
{
    int64_t arg2_00;
    uint32_t uVar1;
    
    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfc;
    uVar1 = *(uint8_t *)(arg2 + 2) - 6;
    if (10 < uVar1) {
        return;
    }
code_r0x000180094450:
    // switch table (11 cases) at 0x1800944fc
    switch(uVar1) {
    default:
        return;
    case 1:
    case 2:
        *(undefined8 *)(arg2 + 0x18) = *(undefined8 *)(arg1 + 0x20);
        *(int64_t *)(arg1 + 0x20) = arg2;
        return;
    case 3:
        break;
    case 4:
    case 9:
        *(undefined8 *)(arg2 + 0x48) = *(undefined8 *)(arg1 + 0x20);
        *(int64_t *)(arg1 + 0x20) = arg2;
        return;
    case 6:
    case 7:
        *(undefined8 *)(arg2 + 8) = *(undefined8 *)(arg1 + 0x20);
        *(int64_t *)(arg1 + 0x20) = arg2;
        return;
    case 10:
        if ((5 < *(int32_t *)((int64_t)*(int64_t **)(arg2 + 8) + 0xc)) &&
           (arg2_00 = **(int64_t **)(arg2 + 8), (*(uint8_t *)(arg2_00 + 1) & 3) != 0)) {
            fcn.180094420(arg1, arg2_00);
        }
        if (*(int64_t *)(arg2 + 8) != arg2 + 0x10) {
            return;
        }
    case 5:
        *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) | 4;
        return;
    }
    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) | 4;
    arg2 = *(int64_t *)(arg2 + 8) + 8 + arg2;
    if (arg2 == 0) {
        return;
    }
    if ((*(uint8_t *)(arg2 + 1) & 3) == 0) {
        return;
    }
    *(uint8_t *)(arg2 + 1) = *(uint8_t *)(arg2 + 1) & 0xfc;
    uVar1 = *(uint8_t *)(arg2 + 2) - 6;
    if (10 < uVar1) {
        return;
    }
    goto code_r0x000180094450;
}

// ============================================================
// Function: FUN_180094530
// Address: 0x180094530
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180094530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    var_18h = arg3;
    var_20h = arg4;
    fcn.1800102c0();
    fcn.180467430((int64_t)&var_18h);
    return;
}

// ============================================================
// Function: FUN_180094580
// Address: 0x180094580
// Size: 137 bytes
// ============================================================
undefined8 fcn.180094580(int64_t arg1)
{
    code *pcVar1;
    undefined8 uVar2;
    double dVar3;
    int64_t var_10h;
    
    dVar3 = (double)fcn.180085ea0(arg1, 1, &var_10h);
    if ((int32_t)var_10h == 0) {
        fcn.180088470(arg1, 1, 3);
        pcVar1 = (code *)swi(3);
        uVar2 = (*pcVar1)();
        return uVar2;
    }
    if (((-9.223372036854776e+18 <= dVar3) && (dVar3 < 9.223372036854776e+18)) && ((double)(int64_t)dVar3 == dVar3)) {
        fcn.180086660(arg1);
        return 1;
    }
    fcn.180086510(arg1);
    return 1;
}

// ============================================================
// Function: FUN_180094610
// Address: 0x180094610
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180094610(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar7 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar5;
    if (piVar7 <= piVar5) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800947c7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        piVar7 = *(int64_t **)(arg1 + 0x40);
        piVar3 = piVar5;
        if (piVar7 <= piVar5) {
            piVar3 = *(int64_t **)0x180782430;
        }
    }
    iVar6 = *piVar3 + 0x18;
    if (iVar6 == 0) {
code_r0x0001800947c7:
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    piVar3 = piVar5 + 2;
    if (piVar7 <= piVar5 + 2) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) < 1)) {
code_r0x00018009472d:
        var_8h = 0;
        uVar4 = func_0x00018046c5e0(iVar6, &var_8h, 10);
        if (var_8h == iVar6) goto code_r0x000180094707;
        if ((*(char *)var_8h == 'x') || (*(char *)var_8h == 'X')) {
            uVar4 = func_0x00018046c748(iVar6, &var_8h, 0x10);
        }
    } else {
        iVar2 = func_0x000180088860(arg1, 2);
        if (0x22 < iVar2 - 2U) {
            func_0x000180088380(arg1, 2, 0x18063dac0);
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
        var_8h = 0;
        if (iVar2 == 10) goto code_r0x00018009472d;
        uVar4 = func_0x00018046c748(iVar6, &var_8h, iVar2);
        if (var_8h == iVar6) goto code_r0x000180094707;
    }
    if (*(char *)var_8h != '\0') {
        iVar2 = func_0x00018046ce40();
        while (iVar2 != 0) {
            var_8h = var_8h + 1;
            iVar2 = func_0x00018046ce40(*(char *)var_8h);
        }
        if (*(char *)var_8h != '\0') {
code_r0x000180094707:
            fcn.180086510(arg1);
            return 1;
        }
    }
    fcn.180086660(arg1, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1800946ac
// Address: 0x1800946ac
// Size: 120 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180094610(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar7 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar5;
    if (piVar7 <= piVar5) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800947c7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        piVar7 = *(int64_t **)(arg1 + 0x40);
        piVar3 = piVar5;
        if (piVar7 <= piVar5) {
            piVar3 = *(int64_t **)0x180782430;
        }
    }
    iVar6 = *piVar3 + 0x18;
    if (iVar6 == 0) {
code_r0x0001800947c7:
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    piVar3 = piVar5 + 2;
    if (piVar7 <= piVar5 + 2) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) < 1)) {
code_r0x00018009472d:
        var_8h = 0;
        uVar4 = func_0x00018046c5e0(iVar6, &var_8h, 10);
        if (var_8h == iVar6) goto code_r0x000180094707;
        if ((*(char *)var_8h == 'x') || (*(char *)var_8h == 'X')) {
            uVar4 = func_0x00018046c748(iVar6, &var_8h, 0x10);
        }
    } else {
        iVar2 = func_0x000180088860(arg1, 2);
        if (0x22 < iVar2 - 2U) {
            func_0x000180088380(arg1, 2, 0x18063dac0);
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
        var_8h = 0;
        if (iVar2 == 10) goto code_r0x00018009472d;
        uVar4 = func_0x00018046c748(iVar6, &var_8h, iVar2);
        if (var_8h == iVar6) goto code_r0x000180094707;
    }
    if (*(char *)var_8h != '\0') {
        iVar2 = func_0x00018046ce40();
        while (iVar2 != 0) {
            var_8h = var_8h + 1;
            iVar2 = func_0x00018046ce40(*(char *)var_8h);
        }
        if (*(char *)var_8h != '\0') {
code_r0x000180094707:
            fcn.180086510(arg1);
            return 1;
        }
    }
    fcn.180086660(arg1, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_180094724
// Address: 0x180094724
// Size: 163 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180094610(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar7 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar5;
    if (piVar7 <= piVar5) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800947c7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        piVar7 = *(int64_t **)(arg1 + 0x40);
        piVar3 = piVar5;
        if (piVar7 <= piVar5) {
            piVar3 = *(int64_t **)0x180782430;
        }
    }
    iVar6 = *piVar3 + 0x18;
    if (iVar6 == 0) {
code_r0x0001800947c7:
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    piVar3 = piVar5 + 2;
    if (piVar7 <= piVar5 + 2) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) < 1)) {
code_r0x00018009472d:
        var_8h = 0;
        uVar4 = func_0x00018046c5e0(iVar6, &var_8h, 10);
        if (var_8h == iVar6) goto code_r0x000180094707;
        if ((*(char *)var_8h == 'x') || (*(char *)var_8h == 'X')) {
            uVar4 = func_0x00018046c748(iVar6, &var_8h, 0x10);
        }
    } else {
        iVar2 = func_0x000180088860(arg1, 2);
        if (0x22 < iVar2 - 2U) {
            func_0x000180088380(arg1, 2, 0x18063dac0);
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
        var_8h = 0;
        if (iVar2 == 10) goto code_r0x00018009472d;
        uVar4 = func_0x00018046c748(iVar6, &var_8h, iVar2);
        if (var_8h == iVar6) goto code_r0x000180094707;
    }
    if (*(char *)var_8h != '\0') {
        iVar2 = func_0x00018046ce40();
        while (iVar2 != 0) {
            var_8h = var_8h + 1;
            iVar2 = func_0x00018046ce40(*(char *)var_8h);
        }
        if (*(char *)var_8h != '\0') {
code_r0x000180094707:
            fcn.180086510(arg1);
            return 1;
        }
    }
    fcn.180086660(arg1, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1800947c7
// Address: 0x1800947c7
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180094610(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar7 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar5;
    if (piVar7 <= piVar5) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800947c7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        piVar7 = *(int64_t **)(arg1 + 0x40);
        piVar3 = piVar5;
        if (piVar7 <= piVar5) {
            piVar3 = *(int64_t **)0x180782430;
        }
    }
    iVar6 = *piVar3 + 0x18;
    if (iVar6 == 0) {
code_r0x0001800947c7:
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    piVar3 = piVar5 + 2;
    if (piVar7 <= piVar5 + 2) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) < 1)) {
code_r0x00018009472d:
        var_8h = 0;
        uVar4 = func_0x00018046c5e0(iVar6, &var_8h, 10);
        if (var_8h == iVar6) goto code_r0x000180094707;
        if ((*(char *)var_8h == 'x') || (*(char *)var_8h == 'X')) {
            uVar4 = func_0x00018046c748(iVar6, &var_8h, 0x10);
        }
    } else {
        iVar2 = func_0x000180088860(arg1, 2);
        if (0x22 < iVar2 - 2U) {
            func_0x000180088380(arg1, 2, 0x18063dac0);
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
        var_8h = 0;
        if (iVar2 == 10) goto code_r0x00018009472d;
        uVar4 = func_0x00018046c748(iVar6, &var_8h, iVar2);
        if (var_8h == iVar6) goto code_r0x000180094707;
    }
    if (*(char *)var_8h != '\0') {
        iVar2 = func_0x00018046ce40();
        while (iVar2 != 0) {
            var_8h = var_8h + 1;
            iVar2 = func_0x00018046ce40(*(char *)var_8h);
        }
        if (*(char *)var_8h != '\0') {
code_r0x000180094707:
            fcn.180086510(arg1);
            return 1;
        }
    }
    fcn.180086660(arg1, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1800947db
// Address: 0x1800947db
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.180094610(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t *piVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t *piVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar7 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar5;
    if (piVar7 <= piVar5) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar2 = func_0x0001800a8360(arg1);
        if (iVar2 == 0) goto code_r0x0001800947c7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        piVar7 = *(int64_t **)(arg1 + 0x40);
        piVar3 = piVar5;
        if (piVar7 <= piVar5) {
            piVar3 = *(int64_t **)0x180782430;
        }
    }
    iVar6 = *piVar3 + 0x18;
    if (iVar6 == 0) {
code_r0x0001800947c7:
        fcn.180088470(arg1, 1, 6);
        pcVar1 = (code *)swi(3);
        uVar4 = (*pcVar1)();
        return uVar4;
    }
    piVar3 = piVar5 + 2;
    if (piVar7 <= piVar5 + 2) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) < 1)) {
code_r0x00018009472d:
        var_8h = 0;
        uVar4 = func_0x00018046c5e0(iVar6, &var_8h, 10);
        if (var_8h == iVar6) goto code_r0x000180094707;
        if ((*(char *)var_8h == 'x') || (*(char *)var_8h == 'X')) {
            uVar4 = func_0x00018046c748(iVar6, &var_8h, 0x10);
        }
    } else {
        iVar2 = func_0x000180088860(arg1, 2);
        if (0x22 < iVar2 - 2U) {
            func_0x000180088380(arg1, 2, 0x18063dac0);
            pcVar1 = (code *)swi(3);
            uVar4 = (*pcVar1)();
            return uVar4;
        }
        var_8h = 0;
        if (iVar2 == 10) goto code_r0x00018009472d;
        uVar4 = func_0x00018046c748(iVar6, &var_8h, iVar2);
        if (var_8h == iVar6) goto code_r0x000180094707;
    }
    if (*(char *)var_8h != '\0') {
        iVar2 = func_0x00018046ce40();
        while (iVar2 != 0) {
            var_8h = var_8h + 1;
            iVar2 = func_0x00018046ce40(*(char *)var_8h);
        }
        if (*(char *)var_8h != '\0') {
code_r0x000180094707:
            fcn.180086510(arg1);
            return 1;
        }
    }
    fcn.180086660(arg1, uVar4);
    return 1;
}

// ============================================================
// Function: FUN_1800947f0
// Address: 0x1800947f0
// Size: 109 bytes
// ============================================================
undefined8 fcn.1800947f0(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    int64_t iVar5;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 4)) {
        if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
            piVar2 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar2 + 0xc) == 4) {
            iVar5 = *piVar2;
        } else {
            iVar5 = 0;
        }
        func_0x000180086570(arg1, (double)iVar5);
        return 1;
    }
    fcn.180088470(arg1, 1, 4);
    pcVar1 = (code *)swi(3);
    uVar3 = (*pcVar1)();
    return uVar3;
}

// ============================================================
// Function: FUN_180094860
// Address: 0x180094860
// Size: 111 bytes
// ============================================================
undefined8 fcn.180094860(int64_t arg1)
{
    code *pcVar1;
    int64_t *piVar2;
    undefined8 uVar3;
    int64_t *piVar4;
    
    piVar2 = *(int64_t **)(arg1 + 0x28);
    piVar4 = piVar2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar1 = (code *)swi(3);
        uVar3 = (*pcVar1)();
        return uVar3;
    }
    if (*(int64_t **)(arg1 + 0x40) <= piVar2) {
        piVar2 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar2 + 0xc) == 4) {
        fcn.180086660(arg1, -*piVar2);
        return 1;
    }
    fcn.180086660(arg1, 0);
    return 1;
}

// ============================================================
// Function: FUN_1800948d0
// Address: 0x1800948d0
// Size: 178 bytes
// ============================================================
undefined8 fcn.1800948d0(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar6 = *piVar3;
    } else {
        iVar6 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            fcn.180086660(arg1, *piVar4 + iVar6);
            return 1;
        }
        fcn.180086660(arg1, iVar6);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180094990
// Address: 0x180094990
// Size: 166 bytes
// ============================================================
undefined8 fcn.180094990(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar7 = *piVar3;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            iVar6 = *piVar4;
        } else {
            iVar6 = 0;
        }
        fcn.180086660(arg1, iVar7 - iVar6);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180094a40
// Address: 0x180094a40
// Size: 180 bytes
// ============================================================
undefined8 fcn.180094a40(int64_t arg1)
{
    int64_t *piVar1;
    code *pcVar2;
    int64_t *piVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t iVar6;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar3 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar5 = (*pcVar2)();
        return uVar5;
    }
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar3 + 0xc) == 4) {
        iVar6 = *piVar3;
    } else {
        iVar6 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar3 = piVar4;
    if (piVar1 <= piVar4) {
        piVar3 = *(int64_t **)0x180782430;
    }
    if ((piVar3 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar3 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
            fcn.180086660(arg1, *piVar4 * iVar6);
            return 1;
        }
        fcn.180086660(arg1, 0);
        return 1;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar5 = (*pcVar2)();
    return uVar5;
}

// ============================================================
// Function: FUN_180094b00
// Address: 0x180094b00
// Size: 218 bytes
// ============================================================
undefined8 fcn.180094b00(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    int64_t iVar7;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar4 = piVar5;
    if (piVar1 <= piVar5) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar4 = piVar5;
    if (piVar1 <= piVar5) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
        iVar7 = *piVar4;
    } else {
        iVar7 = 0;
    }
    piVar5 = piVar5 + 2;
    piVar4 = piVar5;
    if (piVar1 <= piVar5) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 4)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar5 + 0xc) == 4) && (iVar2 = *piVar5, iVar2 != 0)) {
            if ((iVar7 == -0x8000000000000000) && (iVar2 == -1)) {
                fcn.180088560(arg1, 0x18063e1b0);
                pcVar3 = (code *)swi(3);
                uVar6 = (*pcVar3)();
                return uVar6;
            }
            fcn.180086660(arg1, iVar7 / iVar2);
            return 1;
        }
        fcn.180088560(arg1, 0x18063e1c8);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar3 = (code *)swi(3);
    uVar6 = (*pcVar3)();
    return uVar6;
}

// ============================================================
// Function: FUN_180094be0
// Address: 0x180094be0
// Size: 243 bytes
// ============================================================
undefined8 fcn.180094be0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t iVar6;
    undefined8 uVar7;
    int64_t iVar8;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar4 = piVar5;
    if (piVar1 <= piVar5) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar4 = piVar5;
    if (piVar1 <= piVar5) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar4 + 0xc) == 4) {
        iVar8 = *piVar4;
    } else {
        iVar8 = 0;
    }
    piVar5 = piVar5 + 2;
    piVar4 = piVar5;
    if (piVar1 <= piVar5) {
        piVar4 = *(int64_t **)0x180782430;
    }
    if ((piVar4 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar4 + 0xc) == 4)) {
        if (piVar1 <= piVar5) {
            piVar5 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar5 + 0xc) == 4) && (iVar2 = *piVar5, iVar2 != 0)) {
            if ((iVar8 == -0x8000000000000000) && (iVar2 == -1)) {
                fcn.180088560(arg1, 0x18063e1b0);
                pcVar3 = (code *)swi(3);
                uVar7 = (*pcVar3)();
                return uVar7;
            }
            iVar6 = iVar8 / iVar2;
            if ((iVar6 < 0) && (iVar8 % iVar2 != 0)) {
                iVar6 = iVar6 + -1;
            }
            fcn.180086660(arg1, iVar6);
            return 1;
        }
        fcn.180088560(arg1, 0x18063e1c8);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_180094ce0
// Address: 0x180094ce0
// Size: 229 bytes
// ============================================================
undefined8 fcn.180094ce0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t *piVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t iVar7;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar6 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) == 4) {
        iVar7 = *piVar6;
    } else {
        iVar7 = 0;
    }
    piVar4 = piVar4 + 2;
    piVar6 = piVar4;
    if (piVar1 <= piVar4) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if ((piVar6 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar6 + 0xc) == 4)) {
        if (piVar1 <= piVar4) {
            piVar4 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar4 + 0xc) == 4) && (iVar2 = *piVar4, iVar2 != 0)) {
            if ((iVar7 == -0x8000000000000000) && (iVar2 == -1)) {
                fcn.180086660(arg1, 0);
                return 1;
            }
            fcn.180086660(arg1, iVar7 % iVar2);
            return 1;
        }
        fcn.180088560(arg1, 0x18063e1c8);
        pcVar3 = (code *)swi(3);
        uVar5 = (*pcVar3)();
        return uVar5;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar3 = (code *)swi(3);
    uVar5 = (*pcVar3)();
    return uVar5;
}

// ============================================================
// Function: FUN_180094dd0
// Address: 0x180094dd0
// Size: 259 bytes
// ============================================================
undefined8 fcn.180094dd0(int64_t arg1)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    int64_t iVar7;
    int64_t iVar8;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar1 = *(int64_t **)(arg1 + 0x40);
    piVar5 = piVar6;
    if (piVar1 <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar5 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    piVar5 = piVar6;
    if (piVar1 <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) == 4) {
        iVar8 = *piVar5;
    } else {
        iVar8 = 0;
    }
    piVar6 = piVar6 + 2;
    piVar5 = piVar6;
    if (piVar1 <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if ((piVar5 != *(int64_t **)0x180782430) && (*(int32_t *)((int64_t)piVar5 + 0xc) == 4)) {
        if (piVar1 <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)piVar6 + 0xc) == 4) && (iVar2 = *piVar6, iVar2 != 0)) {
            if ((((iVar8 != -0x8000000000000000) || (iVar7 = 0, iVar2 != -1)) && (iVar7 = iVar8 % iVar2, iVar7 != 0)) &&
               ((char)-(char)(iVar8 >> 0x3f) != (char)-(char)(iVar2 >> 0x3f))) {
                iVar7 = iVar7 + iVar2;
            }
            fcn.180086660(arg1, iVar7);
            return 1;
        }
        fcn.180088560(arg1, 0x18063e1c8);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar3 = (code *)swi(3);
    uVar4 = (*pcVar3)();
    return uVar4;
}

// ============================================================
// Function: FUN_180094ee0
// Address: 0x180094ee0
// Size: 198 bytes
// ============================================================
undefined8 fcn.180094ee0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar6 = *puVar4;
    } else {
        uVar6 = 0;
    }
    puVar5 = puVar5 + 2;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar4 + 0xc) == 4)) {
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)puVar5 + 0xc) == 4) && (*puVar5 != 0)) {
            fcn.180086660(arg1, uVar6 / *puVar5);
            return 1;
        }
        fcn.180088560(arg1, 0x18063e1c8);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180094fb0
// Address: 0x180094fb0
// Size: 195 bytes
// ============================================================
undefined8 fcn.180094fb0(int64_t arg1)
{
    uint64_t *puVar1;
    code *pcVar2;
    undefined8 uVar3;
    uint64_t *puVar4;
    uint64_t *puVar5;
    uint64_t uVar6;
    
    puVar5 = *(uint64_t **)(arg1 + 0x28);
    puVar1 = *(uint64_t **)(arg1 + 0x40);
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 == *(uint64_t **)0x180782430) || (*(int32_t *)((int64_t)puVar4 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)puVar4 + 0xc) == 4) {
        uVar6 = *puVar4;
    } else {
        uVar6 = 0;
    }
    puVar5 = puVar5 + 2;
    puVar4 = puVar5;
    if (puVar1 <= puVar5) {
        puVar4 = *(uint64_t **)0x180782430;
    }
    if ((puVar4 != *(uint64_t **)0x180782430) && (*(int32_t *)((int64_t)puVar4 + 0xc) == 4)) {
        if (puVar1 <= puVar5) {
            puVar5 = *(uint64_t **)0x180782430;
        }
        if ((*(int32_t *)((int64_t)puVar5 + 0xc) == 4) && (*puVar5 != 0)) {
            fcn.180086660(arg1, uVar6 % *puVar5);
            return 1;
        }
        fcn.180088560(arg1, 0x18063e1c8);
        pcVar2 = (code *)swi(3);
        uVar3 = (*pcVar2)();
        return uVar3;
    }
    fcn.180088470(arg1, 2, 4);
    pcVar2 = (code *)swi(3);
    uVar3 = (*pcVar2)();
    return uVar3;
}

// ============================================================
// Function: FUN_180095080
// Address: 0x180095080
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095080(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar5 < iVar9) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800950bc
// Address: 0x1800950bc
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095080(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar5 < iVar9) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095115
// Address: 0x180095115
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095080(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar5 < iVar9) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18009515f
// Address: 0x18009515f
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095080(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar5 < iVar9) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095173
// Address: 0x180095173
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095080(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar5 < iVar9) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095190
// Address: 0x180095190
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar9 < iVar5) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_1800951cc
// Address: 0x1800951cc
// Size: 89 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar9 < iVar5) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095225
// Address: 0x180095225
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar9 < iVar5) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_18009526f
// Address: 0x18009526f
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar9 < iVar5) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

// ============================================================
// Function: FUN_180095283
// Address: 0x180095283
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180095190(int64_t arg1)
{
    int64_t *piVar1;
    int64_t *piVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    int64_t unaff_RDI;
    int64_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar2 = *(int64_t **)(arg1 + 0x40);
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if ((piVar7 == *(int64_t **)0x180782430) || (*(int32_t *)((int64_t)piVar7 + 0xc) != 4)) {
        fcn.180088470(arg1, 1, 4);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar7 = piVar1;
    if (piVar2 <= piVar1) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) == 4) {
        iVar9 = *piVar7;
    } else {
        iVar9 = 0;
    }
    iVar8 = 2;
    iVar4 = (int32_t)((int64_t)piVar2 - (int64_t)piVar1 >> 4);
    if (1 < iVar4) {
        do {
            iVar5 = func_0x000180088910(arg1, iVar8);
            if (iVar9 < iVar5) {
                iVar9 = iVar5;
            }
            iVar8 = iVar8 + 1;
        } while (iVar8 <= iVar4);
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar4 = fcn.180085510(unaff_RDI), iVar4 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar3 = (code *)swi(3);
        uVar6 = (*pcVar3)();
        return uVar6;
    }
    piVar1 = *(int64_t **)(arg1 + 0x40);
    *piVar1 = iVar9;
    *(undefined4 *)((int64_t)piVar1 + 0xc) = 4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    return 1;
}

