// Chunk 103 - 50 functions

// ============================================================
// Function: FUN_180166d10
// Address: 0x180166d10
// Size: 97 bytes
// ============================================================
void fcn.180166d10(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t var_8h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 8);
    if (ppiVar1 != (int64_t **)0x0) {
        (**(code **)(*ppiVar1[1] + 0x10))();
        (**(code **)(**ppiVar1 + 0x10))();
        func_0x000180460d90(ppiVar1);
        *(undefined8 *)(arg1 + 0x10) = 0;
        *(undefined8 *)(arg1 + 8) = 0;
    }
    *(undefined4 *)(arg1 + 4) = 1;
    if ((*(char *)(arg1 + 0x57) == '\0') && (*(int64_t *)(arg1 + 0x28) != 0)) {
        *(undefined4 *)(arg1 + 4) = 2;
    }
    return;
}

// ============================================================
// Function: FUN_180166d80
// Address: 0x180166d80
// Size: 1094 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1cch
// WARNING: [rz-ghidra] Detected overlap for variable var_1c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_178h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1bch
// WARNING: [rz-ghidra] Detected overlap for variable var_1a4h

void fcn.180166d80(void)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t **ppiVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_238 [32];
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1d8h;
    int64_t var_1d0h;
    undefined var_1c8h [8];
    int64_t var_1c0h;
    undefined4 var_1b8h;
    undefined4 var_1b4h;
    int64_t var_1b0h;
    undefined4 uStack_1a8;
    undefined4 var_1a4h;
    int64_t var_1a0h;
    undefined4 var_198h;
    int64_t var_194h;
    undefined4 var_18ch;
    undefined8 var_188h;
    undefined8 uStack_180;
    undefined4 var_178h;
    undefined var_174h;
    int64_t var_173h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_74h;
    undefined4 var_6ch;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_54h;
    undefined4 var_4ch;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_34h;
    undefined4 var_2ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_238;
    ppiVar7 = (int64_t **)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        ppiVar7 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    if (*ppiVar7 != (int64_t *)0x0) {
        func_0x0001801671d0();
        var_1e8h = 0;
        var_1f0h = (int64_t)&var_1d8h;
        var_1f8h._0_4_ = 0;
        var_200h._0_4_ = 0;
        var_208h = 0x180646464;
        var_210h = 0x18064646c;
        var_218h = 0;
        iVar3 = (*(code *)0x69a866)(0x180645ff0, 0x2dd, 0, 0);
        if (-1 < iVar3) {
            piVar1 = *ppiVar7;
            pcVar2 = *(code **)(*piVar1 + 0x60);
            uVar4 = (**(code **)(*(int64_t *)var_1d8h + 0x20))();
            uVar5 = (**(code **)(*(int64_t *)var_1d8h + 0x18))();
            var_218h = (int64_t)(ppiVar7 + 5);
            iVar3 = (*pcVar2)(piVar1, uVar5, uVar4, 0);
            if (iVar3 == 0) {
                piVar1 = *ppiVar7;
                var_88h = 0x180646488;
                var_68h = 0x180646498;
                var_48h = 0x1806464a4;
                var_80h._0_4_ = 0;
                stack0xffffffffffffff84 = 0x10;
                var_74h = 0;
                var_6ch = 0;
                var_60h._0_4_ = 0;
                stack0xffffffffffffffa4 = 0x10;
                var_54h = 8;
                var_4ch = 0;
                var_40h._0_4_ = 0;
                stack0xffffffffffffffc4 = 0x1c;
                var_34h = 0x10;
                var_2ch = 0;
                pcVar2 = *(code **)(*piVar1 + 0x58);
                iVar6 = (**(code **)(*(int64_t *)var_1d8h + 0x20))();
                uVar4 = (**(code **)(*(int64_t *)var_1d8h + 0x18))();
                var_210h = (int64_t)(ppiVar7 + 6);
                var_218h = iVar6;
                iVar3 = (*pcVar2)(piVar1, &var_88h, 3, uVar4);
                iVar6 = *(int64_t *)var_1d8h;
                if (iVar3 == 0) {
                    (**(code **)(iVar6 + 0x10))();
                    var_1d0h = 0x200000040;
                    _var_1c8h = ZEXT816(0x1000000000004);
                    (**(code **)(**ppiVar7 + 0x18))(*ppiVar7, &var_1d0h, 0, ppiVar7 + 7);
                    var_1e8h = 0;
                    var_1f0h = (int64_t)&var_1d8h;
                    var_1f8h._0_4_ = 0;
                    var_200h._0_4_ = 0;
                    var_208h = 0x1806464ac;
                    var_210h = 0x18064646c;
                    var_218h = 0;
                    iVar3 = (*(code *)0x69a866)(0x1806462d0, 0x191, 0, 0);
                    if (iVar3 < 0) goto code_r0x000180166e8c;
                    piVar1 = *ppiVar7;
                    pcVar2 = *(code **)(*piVar1 + 0x78);
                    uVar4 = (**(code **)(*(int64_t *)var_1d8h + 0x20))();
                    uVar5 = (**(code **)(*(int64_t *)var_1d8h + 0x18))();
                    var_218h = (int64_t)(ppiVar7 + 8);
                    iVar3 = (*pcVar2)(piVar1, uVar5, uVar4, 0);
                    iVar6 = *(int64_t *)var_1d8h;
                    if (iVar3 == 0) {
                        (**(code **)(iVar6 + 0x10))();
                        var_194h._0_4_ = 0;
                        func_0x0001804986e0(&var_173h, 0, 0xe3);
                        var_198h = 0;
                        var_194h._4_4_ = 1;
                        var_18ch = 5;
                        var_188h = 0x100000006;
                        uStack_180 = 0x600000002;
                        var_178h = 1;
                        var_174h = 0xf;
                        (**(code **)(**ppiVar7 + 0xa0))(*ppiVar7, &var_198h, ppiVar7 + 0xc);
                        _var_1c8h = ZEXT816(0);
                        var_1b0h = 0;
                        var_1d0h = 0x100000003;
                        var_1b4h = 1;
                        var_1b8h = 1;
                        (**(code **)(**ppiVar7 + 0xb0))(*ppiVar7, &var_1d0h, ppiVar7 + 0xb);
                        var_1d0h = 0x100000000;
                        _var_1c8h = ZEXT812(8);
                        var_1b0h = 0x100000008;
                        uStack_1a8 = 1;
                        var_1a4h = 1;
                        var_1b4h = 1;
                        var_1b8h = 1;
                        var_1c0h._4_4_ = 1;
                        var_1a0h._0_4_ = 8;
                        (**(code **)(**ppiVar7 + 0xa8))(*ppiVar7, &var_1d0h, ppiVar7 + 0xd);
                        var_1b4h = 0;
                        var_1b0h = SUB168(ZEXT816(0), 4);
                        uStack_1a8 = 0;
                        var_1b8h = 8;
                        var_1d0h = 0x300000015;
                        _var_1c8h = ZEXT816(0x300000003);
                        var_1a4h = 0;
                        var_1a0h._0_4_ = 0;
                        (**(code **)(**ppiVar7 + 0xb8))(*ppiVar7, &var_1d0h, ppiVar7 + 9);
                        var_1d0h = var_1d0h & 0xffffffff00000000;
                        (**(code **)(**ppiVar7 + 0xb8))(*ppiVar7, &var_1d0h, ppiVar7 + 10);
                        goto code_r0x000180166e8c;
                    }
                }
            } else {
                iVar6 = *(int64_t *)var_1d8h;
            }
            (**(code **)(iVar6 + 0x10))();
        }
    }
code_r0x000180166e8c:
    func_0x000180459870(var_28h ^ (uint64_t)auStack_238);
    return;
}

// ============================================================
// Function: FUN_1801671d0
// Address: 0x1801671d0
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801671d0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = (int64_t *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        piVar5 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd8);
    }
    if (*piVar5 != 0) {
        piVar4 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd78);
        piVar1 = piVar4 + *(int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            iVar2 = *piVar4;
            if (*(int16_t *)(iVar2 + 0x54) == 1) {
                ppiVar3 = *(int64_t ***)(iVar2 + 8);
                if (ppiVar3 != (int64_t **)0x0) {
                    (**(code **)(*ppiVar3[1] + 0x10))();
                    (**(code **)(**ppiVar3 + 0x10))();
                    func_0x000180460d90(ppiVar3);
                    *(undefined8 *)(iVar2 + 0x10) = 0;
                    *(undefined8 *)(iVar2 + 8) = 0;
                }
                *(undefined4 *)(iVar2 + 4) = 1;
                if ((*(char *)(iVar2 + 0x57) == '\0') && (*(int64_t *)(iVar2 + 0x28) != 0)) {
                    *(undefined4 *)(iVar2 + 4) = 2;
                }
            }
        }
        if ((int64_t *)piVar5[9] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[9] + 0x10))();
            piVar5[9] = 0;
        }
        if ((int64_t *)piVar5[10] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[10] + 0x10))();
            piVar5[10] = 0;
        }
        if ((int64_t *)piVar5[4] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[4] + 0x10))();
            piVar5[4] = 0;
        }
        if ((int64_t *)piVar5[3] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[3] + 0x10))();
            piVar5[3] = 0;
        }
        if ((int64_t *)piVar5[0xc] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xc] + 0x10))();
            piVar5[0xc] = 0;
        }
        if ((int64_t *)piVar5[0xd] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xd] + 0x10))();
            piVar5[0xd] = 0;
        }
        if ((int64_t *)piVar5[0xb] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xb] + 0x10))();
            piVar5[0xb] = 0;
        }
        if ((int64_t *)piVar5[8] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[8] + 0x10))();
            piVar5[8] = 0;
        }
        if ((int64_t *)piVar5[7] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[7] + 0x10))();
            piVar5[7] = 0;
        }
        if ((int64_t *)piVar5[6] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[6] + 0x10))();
            piVar5[6] = 0;
        }
        if ((int64_t *)piVar5[5] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[5] + 0x10))();
            piVar5[5] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801671fc
// Address: 0x1801671fc
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801671d0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = (int64_t *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        piVar5 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd8);
    }
    if (*piVar5 != 0) {
        piVar4 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd78);
        piVar1 = piVar4 + *(int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            iVar2 = *piVar4;
            if (*(int16_t *)(iVar2 + 0x54) == 1) {
                ppiVar3 = *(int64_t ***)(iVar2 + 8);
                if (ppiVar3 != (int64_t **)0x0) {
                    (**(code **)(*ppiVar3[1] + 0x10))();
                    (**(code **)(**ppiVar3 + 0x10))();
                    func_0x000180460d90(ppiVar3);
                    *(undefined8 *)(iVar2 + 0x10) = 0;
                    *(undefined8 *)(iVar2 + 8) = 0;
                }
                *(undefined4 *)(iVar2 + 4) = 1;
                if ((*(char *)(iVar2 + 0x57) == '\0') && (*(int64_t *)(iVar2 + 0x28) != 0)) {
                    *(undefined4 *)(iVar2 + 4) = 2;
                }
            }
        }
        if ((int64_t *)piVar5[9] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[9] + 0x10))();
            piVar5[9] = 0;
        }
        if ((int64_t *)piVar5[10] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[10] + 0x10))();
            piVar5[10] = 0;
        }
        if ((int64_t *)piVar5[4] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[4] + 0x10))();
            piVar5[4] = 0;
        }
        if ((int64_t *)piVar5[3] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[3] + 0x10))();
            piVar5[3] = 0;
        }
        if ((int64_t *)piVar5[0xc] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xc] + 0x10))();
            piVar5[0xc] = 0;
        }
        if ((int64_t *)piVar5[0xd] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xd] + 0x10))();
            piVar5[0xd] = 0;
        }
        if ((int64_t *)piVar5[0xb] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xb] + 0x10))();
            piVar5[0xb] = 0;
        }
        if ((int64_t *)piVar5[8] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[8] + 0x10))();
            piVar5[8] = 0;
        }
        if ((int64_t *)piVar5[7] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[7] + 0x10))();
            piVar5[7] = 0;
        }
        if ((int64_t *)piVar5[6] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[6] + 0x10))();
            piVar5[6] = 0;
        }
        if ((int64_t *)piVar5[5] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[5] + 0x10))();
            piVar5[5] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18016721d
// Address: 0x18016721d
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801671d0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = (int64_t *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        piVar5 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd8);
    }
    if (*piVar5 != 0) {
        piVar4 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd78);
        piVar1 = piVar4 + *(int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            iVar2 = *piVar4;
            if (*(int16_t *)(iVar2 + 0x54) == 1) {
                ppiVar3 = *(int64_t ***)(iVar2 + 8);
                if (ppiVar3 != (int64_t **)0x0) {
                    (**(code **)(*ppiVar3[1] + 0x10))();
                    (**(code **)(**ppiVar3 + 0x10))();
                    func_0x000180460d90(ppiVar3);
                    *(undefined8 *)(iVar2 + 0x10) = 0;
                    *(undefined8 *)(iVar2 + 8) = 0;
                }
                *(undefined4 *)(iVar2 + 4) = 1;
                if ((*(char *)(iVar2 + 0x57) == '\0') && (*(int64_t *)(iVar2 + 0x28) != 0)) {
                    *(undefined4 *)(iVar2 + 4) = 2;
                }
            }
        }
        if ((int64_t *)piVar5[9] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[9] + 0x10))();
            piVar5[9] = 0;
        }
        if ((int64_t *)piVar5[10] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[10] + 0x10))();
            piVar5[10] = 0;
        }
        if ((int64_t *)piVar5[4] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[4] + 0x10))();
            piVar5[4] = 0;
        }
        if ((int64_t *)piVar5[3] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[3] + 0x10))();
            piVar5[3] = 0;
        }
        if ((int64_t *)piVar5[0xc] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xc] + 0x10))();
            piVar5[0xc] = 0;
        }
        if ((int64_t *)piVar5[0xd] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xd] + 0x10))();
            piVar5[0xd] = 0;
        }
        if ((int64_t *)piVar5[0xb] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xb] + 0x10))();
            piVar5[0xb] = 0;
        }
        if ((int64_t *)piVar5[8] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[8] + 0x10))();
            piVar5[8] = 0;
        }
        if ((int64_t *)piVar5[7] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[7] + 0x10))();
            piVar5[7] = 0;
        }
        if ((int64_t *)piVar5[6] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[6] + 0x10))();
            piVar5[6] = 0;
        }
        if ((int64_t *)piVar5[5] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[5] + 0x10))();
            piVar5[5] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180167293
// Address: 0x180167293
// Size: 19 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801671d0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = (int64_t *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        piVar5 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd8);
    }
    if (*piVar5 != 0) {
        piVar4 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd78);
        piVar1 = piVar4 + *(int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            iVar2 = *piVar4;
            if (*(int16_t *)(iVar2 + 0x54) == 1) {
                ppiVar3 = *(int64_t ***)(iVar2 + 8);
                if (ppiVar3 != (int64_t **)0x0) {
                    (**(code **)(*ppiVar3[1] + 0x10))();
                    (**(code **)(**ppiVar3 + 0x10))();
                    func_0x000180460d90(ppiVar3);
                    *(undefined8 *)(iVar2 + 0x10) = 0;
                    *(undefined8 *)(iVar2 + 8) = 0;
                }
                *(undefined4 *)(iVar2 + 4) = 1;
                if ((*(char *)(iVar2 + 0x57) == '\0') && (*(int64_t *)(iVar2 + 0x28) != 0)) {
                    *(undefined4 *)(iVar2 + 4) = 2;
                }
            }
        }
        if ((int64_t *)piVar5[9] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[9] + 0x10))();
            piVar5[9] = 0;
        }
        if ((int64_t *)piVar5[10] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[10] + 0x10))();
            piVar5[10] = 0;
        }
        if ((int64_t *)piVar5[4] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[4] + 0x10))();
            piVar5[4] = 0;
        }
        if ((int64_t *)piVar5[3] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[3] + 0x10))();
            piVar5[3] = 0;
        }
        if ((int64_t *)piVar5[0xc] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xc] + 0x10))();
            piVar5[0xc] = 0;
        }
        if ((int64_t *)piVar5[0xd] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xd] + 0x10))();
            piVar5[0xd] = 0;
        }
        if ((int64_t *)piVar5[0xb] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xb] + 0x10))();
            piVar5[0xb] = 0;
        }
        if ((int64_t *)piVar5[8] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[8] + 0x10))();
            piVar5[8] = 0;
        }
        if ((int64_t *)piVar5[7] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[7] + 0x10))();
            piVar5[7] = 0;
        }
        if ((int64_t *)piVar5[6] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[6] + 0x10))();
            piVar5[6] = 0;
        }
        if ((int64_t *)piVar5[5] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[5] + 0x10))();
            piVar5[5] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801672a6
// Address: 0x1801672a6
// Size: 208 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1801671d0(int64_t arg_50h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t **ppiVar3;
    int64_t *piVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    piVar5 = (int64_t *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        piVar5 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd8);
    }
    if (*piVar5 != 0) {
        piVar4 = *(int64_t **)(*(int64_t *)0x180781f28 + 0xd78);
        piVar1 = piVar4 + *(int32_t *)(*(int64_t *)0x180781f28 + 0xd70);
        for (; piVar4 != piVar1; piVar4 = piVar4 + 1) {
            iVar2 = *piVar4;
            if (*(int16_t *)(iVar2 + 0x54) == 1) {
                ppiVar3 = *(int64_t ***)(iVar2 + 8);
                if (ppiVar3 != (int64_t **)0x0) {
                    (**(code **)(*ppiVar3[1] + 0x10))();
                    (**(code **)(**ppiVar3 + 0x10))();
                    func_0x000180460d90(ppiVar3);
                    *(undefined8 *)(iVar2 + 0x10) = 0;
                    *(undefined8 *)(iVar2 + 8) = 0;
                }
                *(undefined4 *)(iVar2 + 4) = 1;
                if ((*(char *)(iVar2 + 0x57) == '\0') && (*(int64_t *)(iVar2 + 0x28) != 0)) {
                    *(undefined4 *)(iVar2 + 4) = 2;
                }
            }
        }
        if ((int64_t *)piVar5[9] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[9] + 0x10))();
            piVar5[9] = 0;
        }
        if ((int64_t *)piVar5[10] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[10] + 0x10))();
            piVar5[10] = 0;
        }
        if ((int64_t *)piVar5[4] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[4] + 0x10))();
            piVar5[4] = 0;
        }
        if ((int64_t *)piVar5[3] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[3] + 0x10))();
            piVar5[3] = 0;
        }
        if ((int64_t *)piVar5[0xc] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xc] + 0x10))();
            piVar5[0xc] = 0;
        }
        if ((int64_t *)piVar5[0xd] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xd] + 0x10))();
            piVar5[0xd] = 0;
        }
        if ((int64_t *)piVar5[0xb] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[0xb] + 0x10))();
            piVar5[0xb] = 0;
        }
        if ((int64_t *)piVar5[8] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[8] + 0x10))();
            piVar5[8] = 0;
        }
        if ((int64_t *)piVar5[7] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[7] + 0x10))();
            piVar5[7] = 0;
        }
        if ((int64_t *)piVar5[6] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[6] + 0x10))();
            piVar5[6] = 0;
        }
        if ((int64_t *)piVar5[5] != (int64_t *)0x0) {
            (**(code **)(*(int64_t *)piVar5[5] + 0x10))();
            piVar5[5] = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180167380
// Address: 0x180167380
// Size: 691 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_58h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h

undefined8 fcn.180167380(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    undefined (*pauVar6) [16];
    undefined8 uVar7;
    int32_t iVar8;
    undefined (*pauVar9) [16];
    undefined (*pauVar10) [16];
    int32_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_64h;
    int64_t var_5ch;
    int64_t var_54h;
    int64_t var_4ch;
    int64_t var_44h;
    int64_t var_38h;
    
    puVar4 = *(undefined8 **)0x1807821d0;
    uVar7 = *(undefined8 *)0x1807821c0;
    iVar2 = *(int64_t *)0x180781f28;
    var_8h = arg1;
    var_10h = arg2;
    pauVar6 = (undefined (*) [16])func_0x00018046d050(0x88);
    pauVar10 = (undefined (*) [16])0x0;
    pauVar9 = pauVar10;
    if (pauVar6 != (undefined (*) [16])0x0) {
        *pauVar6 = ZEXT816(0);
        pauVar6[1] = ZEXT816(0);
        pauVar6[2] = ZEXT816(0);
        pauVar6[3] = ZEXT816(0);
        pauVar6[4] = ZEXT816(0);
        pauVar6[5] = ZEXT816(0);
        pauVar6[6] = ZEXT816(0);
        pauVar6[7] = ZEXT816(0);
        *(undefined8 *)pauVar6[8] = 0;
        *(undefined4 *)pauVar6[7] = 5000;
        *(undefined4 *)(pauVar6[7] + 4) = 10000;
        pauVar9 = pauVar6;
    }
    *(uint32_t *)(iVar2 + 0x34) = *(uint32_t *)(iVar2 + 0x34) | 0x418;
    *(undefined8 *)(iVar2 + 200) = 0x180646478;
    iVar3 = *(int64_t *)0x180781f28;
    *(undefined (**) [16])(iVar2 + 0xd8) = pauVar9;
    *(undefined4 *)(iVar3 + 0xc88) = 0x4000;
    *(undefined4 *)(iVar3 + 0xc84) = 0x4000;
    var_10h = 0;
    var_8h = 0;
    var_18h = 0;
    iVar5 = (**(code **)*puVar4)(puVar4, 0x180645fc8, &var_10h);
    if (((iVar5 == 0) && (iVar5 = (**(code **)(*(int64_t *)var_10h + 0x30))(var_10h, 0x180645fb8, &var_8h), iVar5 == 0))
       && (iVar5 = (**(code **)(*(int64_t *)var_8h + 0x30))(var_8h, 0x180645fd8, &var_18h), iVar5 == 0)) {
        *(undefined8 **)*pauVar9 = puVar4;
        *(undefined8 *)(*pauVar9 + 8) = uVar7;
        *(int64_t *)pauVar9[1] = var_18h;
    }
    if (var_10h != 0) {
        (**(code **)(*(int64_t *)var_10h + 0x10))();
    }
    if (var_8h != 0) {
        (**(code **)(*(int64_t *)var_8h + 0x10))();
    }
    (**(code **)(**(int64_t **)*pauVar9 + 8))();
    (**(code **)(**(int64_t **)(*pauVar9 + 8) + 8))();
    iVar2 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xd38) = 0x180167670;
    *(undefined8 *)(iVar2 + 0xd40) = 0x1801677e0;
    *(undefined8 *)(iVar2 + 0xd48) = 0x180167850;
    *(undefined8 *)(iVar2 + 0xd50) = 0x180167920;
    *(undefined8 *)(iVar2 + 0xd58) = 0x1801679b0;
    if (iVar2 != 0) {
        pauVar10 = *(undefined (**) [16])(iVar2 + 0xd8);
    }
    iVar5 = *(int32_t *)(pauVar10[7] + 0xc);
    if (iVar5 < 1) {
        if (iVar5 == 0) {
            iVar11 = 8;
        } else {
            iVar8 = iVar5 / 2 + iVar5;
            iVar11 = 1;
            if (1 < iVar8) {
                iVar11 = iVar8;
            }
            if (iVar11 <= iVar5) goto code_r0x0001801675e6;
        }
        uVar7 = func_0x00018046d050((int64_t)iVar11 * 0x48);
        if (*(int64_t *)pauVar10[8] != 0) {
            func_0x000180498030(uVar7, *(int64_t *)pauVar10[8], (int64_t)*(int32_t *)(pauVar10[7] + 8) * 0x48);
            func_0x000180460d90(*(undefined8 *)pauVar10[8]);
        }
        *(undefined8 *)pauVar10[8] = uVar7;
        *(int32_t *)(pauVar10[7] + 0xc) = iVar11;
    }
code_r0x0001801675e6:
    *(undefined4 *)(pauVar10[7] + 8) = 1;
    puVar1 = *(undefined4 **)pauVar10[8];
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0x1c;
    puVar1[5] = 0;
    puVar1[6] = 0;
    puVar1[7] = 1;
    puVar1[8] = 0;
    puVar1[9] = 0x20;
    puVar1[10] = 1;
    puVar1[0xb] = 0;
    puVar1[0xc] = 0;
    puVar1[0xd] = 0;
    puVar1[0xe] = 1;
    puVar1[0xf] = 0;
    *(undefined8 *)(puVar1 + 0x10) = 0;
    return CONCAT71((unkint7)((uint64_t)puVar1 >> 8), 1);
}

// ============================================================
// Function: FUN_180167670
// Address: 0x180167670
// Size: 360 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_94h

void fcn.180167670(int64_t arg1, int64_t arg_48h, int64_t arg_60h, int64_t arg_68h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int64_t **ppiVar3;
    int64_t **ppiVar4;
    int64_t *piVar5;
    int64_t **ppiVar6;
    int64_t iVar7;
    undefined auStack_c8 [40];
    int64_t var_a0h;
    int64_t var_98h;
    undefined4 uStack_90;
    undefined4 uStack_8c;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    int64_t var_68h;
    undefined4 uStack_60;
    undefined4 uStack_5c;
    int64_t var_58h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    ppiVar4 = (int64_t **)0x0;
    ppiVar6 = ppiVar4;
    if (*(int64_t *)0x180781f28 != 0) {
        ppiVar6 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    ppiVar3 = (int64_t **)func_0x00018046d050(0x10);
    if (ppiVar3 != (int64_t **)0x0) {
        *ppiVar3 = (int64_t *)0x0;
        ppiVar3[1] = (int64_t *)0x0;
        ppiVar4 = ppiVar3;
    }
    iVar7 = *(int64_t *)(arg1 + 0x68);
    *(int64_t ***)(arg1 + 0x48) = ppiVar4;
    if (iVar7 == 0) {
        iVar7 = *(int64_t *)(arg1 + 0x60);
    }
    piVar5 = ppiVar6[0x10];
    piVar1 = piVar5 + (int64_t)*(int32_t *)(ppiVar6 + 0xf) * 9;
    for (; piVar5 != piVar1; piVar5 = piVar5 + 9) {
        uStack_90 = *(undefined4 *)(piVar5 + 1);
        uStack_8c = *(undefined4 *)((int64_t)piVar5 + 0xc);
        var_88h._0_4_ = *(undefined4 *)(piVar5 + 2);
        var_88h._4_4_ = *(undefined4 *)((int64_t)piVar5 + 0x14);
        uStack_80 = *(undefined4 *)(piVar5 + 3);
        uStack_7c = *(undefined4 *)((int64_t)piVar5 + 0x1c);
        var_78h._0_4_ = *(undefined4 *)(piVar5 + 4);
        var_78h._4_4_ = *(undefined4 *)((int64_t)piVar5 + 0x24);
        uStack_70 = *(undefined4 *)(piVar5 + 5);
        uStack_6c = *(undefined4 *)((int64_t)piVar5 + 0x2c);
        var_98h._0_4_ = (undefined4)(int64_t)*(float *)(arg1 + 0x10);
        uStack_60 = *(undefined4 *)(piVar5 + 7);
        uStack_5c = *(undefined4 *)((int64_t)piVar5 + 0x3c);
        var_98h._4_4_ = (undefined4)(int64_t)*(float *)(arg1 + 0x14);
        var_58h = piVar5[8];
        var_68h = iVar7;
        iVar2 = (**(code **)(*ppiVar6[2] + 0x50))(ppiVar6[2], *ppiVar6, &var_98h, ppiVar4);
        if (-1 < iVar2) break;
    }
    (**(code **)(*ppiVar6[2] + 0x40))(ppiVar6[2], iVar7, 3);
    piVar1 = *ppiVar4;
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x48))(piVar1, 0, 0x18063d260, &var_a0h);
        (**(code **)(**ppiVar6 + 0x48))(*ppiVar6, var_a0h, 0, ppiVar4 + 1);
        (**(code **)(*(int64_t *)var_a0h + 0x10))();
    }
    func_0x000180459870(var_48h ^ (uint64_t)auStack_c8);
    return;
}

// ============================================================
// Function: FUN_1801677e0
// Address: 0x1801677e0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801677e0(int64_t arg1)
{
    int64_t **ppiVar1;
    int64_t var_8h;
    
    ppiVar1 = *(int64_t ***)(arg1 + 0x48);
    if (ppiVar1 != (int64_t **)0x0) {
        if (*ppiVar1 != (int64_t *)0x0) {
            (**(code **)(**ppiVar1 + 0x10))();
        }
        *ppiVar1 = (int64_t *)0x0;
        if (ppiVar1[1] != (int64_t *)0x0) {
            (**(code **)(*ppiVar1[1] + 0x10))();
        }
        ppiVar1[1] = (int64_t *)0x0;
        func_0x000180460d90(ppiVar1);
        *(undefined8 *)(arg1 + 0x48) = 0;
        return;
    }
    *(undefined8 *)(arg1 + 0x48) = 0;
    return;
}

// ============================================================
// Function: FUN_180167850
// Address: 0x180167850
// Size: 199 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180167850(int64_t arg1, int64_t arg2)
{
    int64_t **ppiVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    
    ppiVar3 = (int64_t **)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        ppiVar3 = *(int64_t ***)(*(int64_t *)0x180781f28 + 0xd8);
    }
    ppiVar1 = *(int64_t ***)(arg1 + 0x48);
    if (ppiVar1[1] != (int64_t *)0x0) {
        (**(code **)(*ppiVar1[1] + 0x10))();
        ppiVar1[1] = (int64_t *)0x0;
    }
    piVar2 = *ppiVar1;
    if (piVar2 != (int64_t *)0x0) {
        var_38h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
        var_8h = 0;
        (**(code **)(*piVar2 + 0x68))(piVar2, 0, (int64_t)(float)arg2, (int64_t)var_38h._4_4_, 0, 0);
        (**(code **)(**ppiVar1 + 0x48))(*ppiVar1, 0, 0x18063d260, &var_8h);
        if (var_8h != 0) {
            (**(code **)(**ppiVar3 + 0x48))(*ppiVar3, var_8h, 0, ppiVar1 + 1);
            (**(code **)(*(int64_t *)var_8h + 0x10))();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180167920
// Address: 0x180167920
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180167920(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_10;
    
    iVar2 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd8);
    }
    iVar1 = *(int64_t *)(arg1 + 0x48);
    var_18h = 0;
    uStack_10 = 0x3f80000000000000;
    (**(code **)(**(int64_t **)(iVar2 + 8) + 0x108))(*(int64_t **)(iVar2 + 8), 1, iVar1 + 8, 0);
    if ((*(uint32_t *)(arg1 + 4) & 0x100) == 0) {
        (**(code **)(**(int64_t **)(iVar2 + 8) + 400))(*(int64_t **)(iVar2 + 8), *(undefined8 *)(iVar1 + 8), &var_18h);
    }
    func_0x0001801660f0(*(undefined8 *)(arg1 + 0x40));
    return;
}

// ============================================================
// Function: FUN_1801679d0
// Address: 0x1801679d0
// Size: 62 bytes
// ============================================================
void fcn.1801679d0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint64_t uVar3;
    
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    uVar3 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar3 >> 0x10 & 0xffff, 0x20001004, iVar1 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar1 + 0x2c) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180167a10
// Address: 0x180167a10
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167a63
// Address: 0x180167a63
// Size: 13 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167a70
// Address: 0x180167a70
// Size: 850 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167dc2
// Address: 0x180167dc2
// Size: 40 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167dea
// Address: 0x180167dea
// Size: 56 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167e22
// Address: 0x180167e22
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167e45
// Address: 0x180167e45
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.180167a10(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    undefined (*pauVar3) [16];
    uint64_t uVar4;
    undefined (*pauVar5) [16];
    int64_t iVar6;
    undefined8 uVar7;
    code *pcVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined (*pauVar11) [16];
    uint32_t uVar12;
    int64_t unaff_GS_OFFSET;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_a8 [48];
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_38h;
    undefined8 uStack_30;
    int64_t var_28h;
    undefined8 uStack_20;
    uint64_t uStack_18;
    int64_t var_8h;
    undefined (*pauVar13) [16];
    
    iVar6 = *(int64_t *)0x180781f28;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar2 = (*(code *)0x699e5a)(&var_78h);
    if ((iVar2 == 0) || (iVar2 = (*(code *)0x699e76)(&var_70h), iVar2 == 0)) goto code_r0x000180167e24;
    pauVar3 = (undefined (*) [16])func_0x00018046d050(0x68);
    pauVar13 = (undefined (*) [16])0x0;
    pauVar11 = pauVar13;
    if (pauVar3 != (undefined (*) [16])0x0) {
        *pauVar3 = ZEXT816(0);
        pauVar3[1] = ZEXT816(0);
        pauVar3[2] = ZEXT816(0);
        pauVar3[3] = ZEXT816(0);
        pauVar3[4] = ZEXT816(0);
        pauVar3[5] = ZEXT816(0);
        *(undefined8 *)pauVar3[6] = 0;
        pauVar11 = pauVar3;
    }
    *(uint32_t *)(iVar6 + 0x34) = *(uint32_t *)(iVar6 + 0x34) | 0x3806;
    *(undefined8 *)(iVar6 + 0xc0) = 0x1806464c8;
    *(undefined (**) [16])(iVar6 + 0xd0) = pauVar11;
    *(int64_t *)*pauVar11 = arg1;
    *(int64_t *)pauVar11[2] = var_78h;
    *(int64_t *)(pauVar11[1] + 8) = var_70h;
    *(undefined4 *)(pauVar11[2] + 8) = 0xb;
    iVar6 = *(int64_t *)(iVar6 + 0xd0);
    uVar4 = (*(code *)0x69a5dc)(0);
    iVar2 = (*(code *)0x699eca)(uVar4 >> 0x10 & 0xffff, 0x20001004, iVar6 + 0x2c, 4);
    if (iVar2 == 0) {
        *(undefined4 *)(iVar6 + 0x2c) = 0;
    }
    func_0x000180168bb0();
    iVar6 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    uVar7 = *(undefined8 *)*pauVar11;
    *(undefined8 *)(iVar6 + 0x68) = uVar7;
    *(undefined8 *)(iVar6 + 0x60) = uVar7;
    (*(code *)0x69a6e4)(*(undefined8 *)*pauVar11, 0x1806464b8);
    var_60h = 0x18016af40;
    var_68h = 0x300000050;
    var_58h = 0;
    var_50h = (*(code *)0x699d1e)(0);
    _var_48h = ZEXT816(0);
    var_28h = 0x180646630;
    var_38h = 2;
    uStack_30 = 0;
    uStack_20 = 0;
    (*(code *)0x69a64c)(&var_68h);
    func_0x000180168bb0();
    iVar1 = *(int64_t *)0x180781f28;
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0xc98) = 0x18016a4e0;
    *(undefined8 *)(iVar1 + 0xca0) = 0x18016a6f0;
    *(undefined8 *)(iVar1 + 0xca8) = 0x18016a790;
    *(undefined8 *)(iVar1 + 0xcb0) = 0x18016aa80;
    *(undefined8 *)(iVar1 + 0xcb8) = 0x18016aa30;
    *(undefined8 *)(iVar1 + 0xcc0) = 0x18016ac20;
    *(undefined8 *)(iVar1 + 0xcc8) = 0x18016abb0;
    *(undefined8 *)(iVar1 + 0xcd8) = 0x18016ad50;
    *(undefined8 *)(iVar1 + 0xce0) = 0x18016ad80;
    *(undefined8 *)(iVar1 + 0xce8) = 0x18016ada0;
    *(undefined8 *)(iVar1 + 0xcf0) = 0x18016adc0;
    *(undefined8 *)(iVar1 + 0xcf8) = 0x18016ae70;
    *(undefined8 *)(iVar1 + 0xd00) = 0x18016a810;
    *(undefined8 *)(iVar1 + 0xd18) = 0x18016af10;
    *(undefined8 *)(iVar1 + 0xd20) = 0x1800086f0;
    iVar6 = **(int64_t **)(iVar1 + 0x2158);
    pauVar3 = pauVar13;
    if (iVar1 != 0) {
        pauVar3 = *(undefined (**) [16])(iVar1 + 0xd0);
    }
    pauVar5 = (undefined (*) [16])func_0x00018046d050(0x20);
    pauVar10 = pauVar13;
    if (pauVar5 != (undefined (*) [16])0x0) {
        *(undefined8 *)(*pauVar5 + 8) = 0;
        *(undefined8 *)*pauVar5 = 0;
        pauVar5[1][0] = 0;
        *(undefined8 *)(pauVar5[1] + 4) = 0;
        pauVar10 = pauVar5;
    }
    *(undefined8 *)*pauVar10 = *(undefined8 *)*pauVar3;
    pauVar10[1][0] = 0;
    *(undefined (**) [16])(iVar6 + 0x50) = pauVar10;
    iVar6 = (*(code *)0x699d1e)(0x180646500);
    if (iVar6 != 0) {
        uVar7 = (*(code *)0x699eee)(iVar6, 0x1806464e0);
        *(undefined8 *)(pauVar11[3] + 8) = uVar7;
    }
    iVar2 = func_0x00018016a2c0(10, 0);
    if (iVar2 == 0) {
code_r0x000180167d77:
        bVar14 = false;
    } else {
        if ((*(int32_t *)
              (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
             *(int32_t *)0x180782b40) && (func_0x000180459d18(0x180782b40), *(int32_t *)0x180782b40 == -1)) {
            *(undefined8 *)0x180782b50 = (*(code *)0x699d1e)(0x180646500);
            func_0x000180459cac(0x180782b40);
        }
        pcVar8 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x1806465b8);
        pcVar9 = (code *)(*(code *)0x699eee)(*(undefined8 *)0x180782b50, 0x180646598);
        if ((pcVar8 == (code *)0x0) || (pcVar9 == (code *)0x0)) goto code_r0x000180167d77;
        uVar7 = (*pcVar8)();
        iVar2 = (*pcVar9)(uVar7, 0xfffffffffffffffc);
        bVar14 = iVar2 != 0;
    }
    pauVar11[3][1] = bVar14;
    var_68h = 0x180646568;
    var_60h = 0x180646558;
    var_58h = 0x180646588;
    var_50h = 0x180646578;
    var_48h = 0x180646528;
    pauVar11[4][1] = 1;
    do {
        iVar6 = (*(code *)0x699e24)((&var_68h)[(int64_t)pauVar13]);
        if (iVar6 != 0) {
            *(int64_t *)(pauVar11[4] + 8) = iVar6;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646510);
            *(undefined8 *)pauVar11[5] = uVar7;
            uVar7 = (*(code *)0x699eee)(iVar6, 0x180646548);
            *(undefined8 *)(pauVar11[5] + 8) = uVar7;
            break;
        }
        uVar12 = (int32_t)pauVar13 + 1;
        pauVar13 = (undefined (*) [16])(uint64_t)uVar12;
    } while ((int32_t)uVar12 < 5);
code_r0x000180167e24:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180167e90
// Address: 0x180167e90
// Size: 424 bytes
// ============================================================
undefined8 fcn.180167e90(int64_t arg1, int64_t arg2)
{
    undefined8 uVar1;
    
    if ((*(uint8_t *)arg1 & 0x20) != 0) {
        return 0;
    }
    if (((int32_t)arg2 != -1) && (*(char *)(arg1 + 0x5c) == '\0')) {
        uVar1 = 0x7f00;
    // switch table (11 cases) at 0x18016800c
        switch((int32_t)arg2) {
        case 1:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f01);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 2:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f86);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 3:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f85);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 4:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f84);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 5:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f83);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 6:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f82);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 7:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f89);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 8:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f02);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 9:
            uVar1 = (*(code *)0x69a6d6)(0, 0x7f8a);
            (*(code *)0x69a566)(uVar1);
            return 1;
        case 10:
            uVar1 = 0x7f88;
        }
        uVar1 = (*(code *)0x69a6d6)(0, uVar1);
        (*(code *)0x69a566)(uVar1);
        return 1;
    }
    (*(code *)0x69a566)(0);
    return 1;
}

// ============================================================
// Function: FUN_180168040
// Address: 0x180168040
// Size: 616 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180168040(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t **ppiVar3;
    undefined4 *puVar4;
    int32_t *piVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int32_t iVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    int32_t **ppiVar15;
    uint64_t uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_34h;
    int64_t var_28h;
    
    piVar6 = *(int64_t **)(arg1 + 0xa0);
    iVar7 = (*(code *)0x69a4e2)(&var_18h);
    iVar10 = (*(code *)0x69a404)();
    if (iVar10 == 0) {
code_r0x0001801680c2:
        iVar8 = 0;
        if (iVar7 == 0) goto code_r0x0001801681c7;
    } else {
        if ((iVar10 != *piVar6) && (iVar8 = (*(code *)0x69a602)(iVar10), iVar8 == 0)) {
            piVar13 = *(int64_t **)(arg2 + 0x140);
            piVar2 = piVar13 + *(int32_t *)(arg2 + 0x138);
            for (; piVar13 != piVar2; piVar13 = piVar13 + 1) {
                if (*(int64_t *)(*piVar13 + 0x60) == iVar10) goto code_r0x00018016811b;
            }
            goto code_r0x0001801680c2;
        }
code_r0x00018016811b:
        if (*(char *)(arg1 + 0xbb) != '\0') {
            uVar14 = (uint64_t)(uint32_t)(int32_t)*(float *)(arg1 + 0xe8);
            uVar16 = (uint64_t)(uint32_t)(int32_t)*(float *)(arg1 + 0xec);
            var_8h = CONCAT44((int32_t)*(float *)(arg1 + 0xec), (int32_t)*(float *)(arg1 + 0xe8));
            if ((*(uint32_t *)arg1 & 0x400) == 0) {
                (*(code *)0x69a42c)(iVar10, &var_8h);
                uVar16 = (uint64_t)var_8h >> 0x20;
                uVar14 = var_8h & 0xffffffff;
            }
            (*(code *)0x69a4fe)(uVar14, uVar16);
            if (*(char *)(arg1 + 0xbb) != '\0') goto code_r0x0001801680c2;
        }
        if ((*(int32_t *)(piVar6 + 2) != 0) || (iVar7 == 0)) goto code_r0x0001801680c2;
        var_8h = var_18h;
        if ((*(uint32_t *)arg1 & 0x400) == 0) {
            (*(code *)0x69a660)(*piVar6, &var_8h);
        }
        func_0x0001800f5530(arg1);
    }
    iVar8 = 0;
    iVar10 = (*(code *)0x69a63a)(var_18h);
    if (iVar10 != 0) {
        ppiVar15 = *(int32_t ***)(arg2 + 0x140);
        ppiVar3 = ppiVar15 + *(int32_t *)(arg2 + 0x138);
        for (; iVar8 = 0, ppiVar15 != ppiVar3; ppiVar15 = ppiVar15 + 1) {
            if (*(int64_t *)(*ppiVar15 + 0x18) == iVar10) {
                iVar8 = **ppiVar15;
                break;
            }
        }
    }
code_r0x0001801681c7:
    if (*(char *)(arg1 + 0xbe5) != '\0') {
        iVar10 = *(int64_t *)(arg1 + 0xe0);
        piVar1 = (int32_t *)(iVar10 + 0x1558);
        iVar7 = *piVar1;
        uVar11 = iVar7 - 1;
        if (-1 < (int32_t)uVar11) {
            do {
                if (*(int32_t *)((uint64_t)uVar11 * 0x1c + *(int64_t *)(iVar10 + 0x1560)) == 4) {
                    iVar9 = *(int32_t *)((uint64_t)uVar11 * 0x1c + 0xc + *(int64_t *)(iVar10 + 0x1560));
                    goto code_r0x000180168219;
                }
                uVar11 = uVar11 - 1;
            } while (-1 < (int32_t)uVar11);
        }
        iVar9 = *(int32_t *)(iVar10 + 0x134);
code_r0x000180168219:
        if (iVar9 != iVar8) {
            iVar9 = *(int32_t *)(iVar10 + 0x155c);
            if (iVar7 == iVar9) {
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                iVar12 = iVar7 + 1;
                if (iVar7 + 1 < iVar9) {
                    iVar12 = iVar9;
                }
                func_0x00018011f9d0(piVar1, iVar12);
            }
            iVar7 = *piVar1;
            iVar10 = *(int64_t *)(iVar10 + 0x1560);
            puVar4 = (undefined4 *)((int64_t)iVar7 * 0x1c + iVar10);
            *puVar4 = 4;
            puVar4[1] = 1;
            puVar4[2] = 0;
            puVar4[3] = iVar8;
            piVar5 = (int32_t *)((int64_t)iVar7 * 0x1c + 0xc + iVar10);
            *piVar5 = iVar8;
            piVar5[1] = 0;
            piVar5[2] = 0;
            piVar5[3] = 0;
            *piVar1 = *piVar1 + 1;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801682b0
// Address: 0x1801682b0
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180168354
// Address: 0x180168354
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_18016837f
// Address: 0x18016837f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180168385
// Address: 0x180168385
// Size: 1201 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180168836
// Address: 0x180168836
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_180168877
// Address: 0x180168877
// Size: 53 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_1801688ac
// Address: 0x1801688ac
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.1801682b0(int64_t arg1)
{
    int64_t iVar1;
    int32_t iVar2;
    uint8_t uVar3;
    bool bVar4;
    float fVar5;
    float fVar6;
    undefined4 uVar7;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int16_t var_80h;
    int16_t var_7eh;
    int16_t var_7ch;
    int16_t var_7ah;
    undefined var_78h [16];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_8h;
    
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    iVar1 = *(int64_t *)(arg1 + 0xa0);
    if (*(char *)(iVar1 + 0x41) != '\0') {
        bVar4 = false;
        var_68h._0_4_ = 0;
        var_78h = ZEXT816(0);
        if (*(code **)(iVar1 + 0x50) != (code *)0x0) {
            iVar2 = (**(code **)(iVar1 + 0x50))(0, 1, var_78h);
            bVar4 = iVar2 == 0;
        }
        *(bool *)(iVar1 + 0x40) = bVar4;
        *(undefined *)(iVar1 + 0x41) = 0;
    }
    *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) & 0xfffffffe;
    if (((*(char *)(iVar1 + 0x40) != '\0') && (*(code **)(iVar1 + 0x58) != (code *)0x0)) &&
       (iVar2 = (**(code **)(iVar1 + 0x58))(0, &var_88h), iVar2 == 0)) {
        *(uint32_t *)(arg1 + 4) = *(uint32_t *)(arg1 + 4) | 1;
        if ((*(int32_t *)(iVar1 + 0x60) == 0) || (*(int32_t *)(iVar1 + 0x60) != (int32_t)var_88h)) {
            *(int32_t *)(iVar1 + 0x60) = (int32_t)var_88h;
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 4 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x278, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    uVar3 = var_88h._4_1_ >> 5 & 1;
                    if (uVar3 == 0) {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x279, uVar3, uVar7);
                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                        uVar3 = (uint8_t)(var_88h._4_2_ >> 0xe);
                        if ((uVar3 & 1) == 0) {
                            uVar7 = 0;
                        } else {
                            uVar7 = 0x3f800000;
                        }
                        func_0x0001800f5370(arg1, 0x27a, uVar3 & 1, uVar7);
                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                            uVar3 = (uint8_t)(var_88h._4_2_ >> 0xd);
                            if ((uVar3 & 1) == 0) {
                                uVar7 = 0;
                            } else {
                                uVar7 = 0x3f800000;
                            }
                            func_0x0001800f5370(arg1, 0x27b, uVar3 & 1, uVar7);
                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                if ((int16_t)var_88h._4_2_ < 0) {
                                    uVar7 = 0x3f800000;
                                } else {
                                    uVar7 = 0;
                                }
                                func_0x0001800f5370(arg1, 0x27c, var_88h._4_2_ >> 0xf, uVar7);
                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                    uVar3 = (uint8_t)(var_88h._4_2_ >> 0xc);
                                    if ((uVar3 & 1) == 0) {
                                        uVar7 = 0;
                                    } else {
                                        uVar7 = 0x3f800000;
                                    }
                                    func_0x0001800f5370(arg1, 0x27d, uVar3 & 1, uVar7);
                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                        uVar3 = var_88h._4_1_ >> 2 & 1;
                                        if (uVar3 == 0) {
                                            uVar7 = 0;
                                        } else {
                                            uVar7 = 0x3f800000;
                                        }
                                        func_0x0001800f5370(arg1, 0x27e, uVar3, uVar7);
                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                            uVar3 = var_88h._4_1_ >> 3 & 1;
                                            if (uVar3 == 0) {
                                                uVar7 = 0;
                                            } else {
                                                uVar7 = 0x3f800000;
                                            }
                                            func_0x0001800f5370(arg1, 0x27f, uVar3, uVar7);
                                            if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                if ((var_88h._4_2_ & 1) == 0) {
                                                    uVar7 = 0;
                                                } else {
                                                    uVar7 = 0x3f800000;
                                                }
                                                func_0x0001800f5370(arg1, 0x280, var_88h._4_1_ & 1, uVar7);
                                                if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                    uVar3 = var_88h._4_1_ >> 1 & 1;
                                                    if (uVar3 == 0) {
                                                        uVar7 = 0;
                                                    } else {
                                                        uVar7 = 0x3f800000;
                                                    }
                                                    func_0x0001800f5370(arg1, 0x281, uVar3, uVar7);
                                                    if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                        if ((var_88h._4_2_ & 0x100) == 0) {
                                                            uVar7 = 0;
                                                        } else {
                                                            uVar7 = 0x3f800000;
                                                        }
                                                        func_0x0001800f5370(arg1, 0x282, 
                                                                            (uint8_t)(var_88h._4_2_ >> 8) & 1, uVar7);
                                                        if (*(char *)(arg1 + 0xbe5) != '\0') {
                                                            uVar3 = (uint8_t)(var_88h._4_2_ >> 9);
                                                            if ((uVar3 & 1) == 0) {
                                                                uVar7 = 0;
                                                            } else {
                                                                uVar7 = 0x3f800000;
                                                            }
                                                            func_0x0001800f5370(arg1, 0x283, uVar3 & 1, uVar7);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            fVar5 = (float)(var_88h._6_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x284, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_88h._7_1_ - 0x1e) / 225.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x285, 0.1 < fVar5, fVar6);
            if (*(char *)(arg1 + 0xbe5) != '\0') {
                uVar3 = var_88h._4_1_ >> 6 & 1;
                if (uVar3 == 0) {
                    uVar7 = 0;
                } else {
                    uVar7 = 0x3f800000;
                }
                func_0x0001800f5370(arg1, 0x286, uVar3, uVar7);
                if (*(char *)(arg1 + 0xbe5) != '\0') {
                    if ((char)-((char)var_88h._4_1_ >> 7) == '\0') {
                        uVar7 = 0;
                    } else {
                        uVar7 = 0x3f800000;
                    }
                    func_0x0001800f5370(arg1, 0x287, -((char)var_88h._4_1_ >> 7), uVar7);
                }
            }
            fVar5 = (float)(var_80h + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x288, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_80h + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x289, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28a, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7eh + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28b, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + 0x1ea9) / -24919.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28c, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ch + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28d, 0.1 < fVar5, fVar6);
            fVar5 = (float)(var_7ah + -0x1ea9) / 24918.0;
            if (0.0 <= fVar5) {
                fVar6 = 1.0;
                if (fVar5 <= 1.0) {
                    fVar6 = fVar5;
                }
            } else {
                fVar6 = 0.0;
            }
            func_0x0001800f5370(arg1, 0x28e, 0.1 < fVar5, fVar6);
            fVar6 = (float)(var_7ah + 0x1ea9) / -24919.0;
            fVar5 = 0.0;
            if ((0.0 <= fVar6) && (fVar5 = 1.0, fVar6 <= 1.0)) {
                fVar5 = fVar6;
            }
            func_0x0001800f5370(arg1, 0x28f, 0.1 < fVar6, fVar5);
        }
    }
    func_0x000180459870(var_60h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_1801688d0
// Address: 0x1801688d0
// Size: 88 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.1801688d0(int64_t arg1, int64_t arg_110h)
{
    int32_t iVar1;
    float *pfVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t *piVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    int64_t var_10h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int32_t var_c0h;
    int32_t var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_a8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    stack0xffffffffffffff2c = SUB1612(ZEXT816(0), 4);
    var_d8h._0_4_ = 0x28;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    iVar4 = (*(code *)0x69a5ca)(0, &var_d8h);
    if (iVar4 == 0) goto code_r0x000180168b8e;
    iVar4 = var_d0h._4_4_ - var_d8h._4_4_;
    iVar5 = (int32_t)var_c8h - (int32_t)var_d0h;
    fVar13 = (float)var_d8h._4_4_;
    iVar6 = var_bch - var_c8h._4_4_;
    fVar14 = (float)(int32_t)var_d0h;
    iVar7 = (int32_t)var_b8h - var_c0h;
    fVar15 = (float)var_c8h._4_4_;
    fVar16 = (float)var_c0h;
    fVar12 = (float)func_0x00018016a3b0(arg1);
    iVar3 = *(int64_t *)0x180781f28;
    if (fVar12 <= 0.0) goto code_r0x000180168b8e;
    piVar11 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    iVar1 = *piVar11;
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd64);
    if ((var_b8h & 0x100000000U) == 0) {
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
code_r0x000180168adc:
            func_0x00018016b050(piVar11, iVar10);
        }
code_r0x000180168ae4:
        iVar9 = (int64_t)*piVar11;
        iVar3 = *(int64_t *)(iVar3 + 0xd68);
        *(float *)(iVar3 + iVar9 * 0x30) = fVar13;
        *(float *)(iVar3 + 4 + iVar9 * 0x30) = fVar14;
        *(float *)(iVar3 + 8 + iVar9 * 0x30) = (float)iVar4;
        *(float *)(iVar3 + 0xc + iVar9 * 0x30) = (float)iVar5;
        *(float *)(iVar3 + 0x10 + iVar9 * 0x30) = fVar15;
        *(float *)(iVar3 + 0x14 + iVar9 * 0x30) = fVar16;
        *(float *)(iVar3 + 0x18 + iVar9 * 0x30) = (float)iVar6;
        *(float *)(iVar3 + 0x1c + iVar9 * 0x30) = (float)iVar7;
        *(float *)(iVar3 + 0x20 + iVar9 * 0x30) = fVar12;
        *(float *)(iVar3 + 0x24 + iVar9 * 0x30) = var_b8h._4_4_;
        *(int64_t *)(iVar3 + 0x28 + iVar9 * 0x30) = arg1;
    } else {
        if (iVar1 == 0) {
            if (iVar8 == 0) {
                iVar10 = 8;
                goto code_r0x000180168adc;
            }
            goto code_r0x000180168ae4;
        }
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
            func_0x00018016b050(piVar11, iVar10);
        }
        if (0 < (int64_t)*piVar11) {
            func_0x000180498030(*(int64_t *)(iVar3 + 0xd68) + 0x30, *(int64_t *)(iVar3 + 0xd68), 
                                (int64_t)*piVar11 * 0x30);
        }
        pfVar2 = *(float **)(iVar3 + 0xd68);
        *pfVar2 = fVar13;
        pfVar2[1] = fVar14;
        pfVar2[2] = (float)iVar4;
        pfVar2[3] = (float)iVar5;
        pfVar2[4] = fVar15;
        pfVar2[5] = fVar16;
        pfVar2[6] = (float)iVar6;
        pfVar2[7] = (float)iVar7;
        pfVar2[8] = fVar12;
        pfVar2[9] = var_b8h._4_4_;
        *(int64_t *)(pfVar2 + 10) = arg1;
    }
    *piVar11 = *piVar11 + 1;
code_r0x000180168b8e:
    func_0x000180459870(var_a8h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180168928
// Address: 0x180168928
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.1801688d0(int64_t arg1, int64_t arg_110h)
{
    int32_t iVar1;
    float *pfVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t *piVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    int64_t var_10h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int32_t var_c0h;
    int32_t var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_a8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    stack0xffffffffffffff2c = SUB1612(ZEXT816(0), 4);
    var_d8h._0_4_ = 0x28;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    iVar4 = (*(code *)0x69a5ca)(0, &var_d8h);
    if (iVar4 == 0) goto code_r0x000180168b8e;
    iVar4 = var_d0h._4_4_ - var_d8h._4_4_;
    iVar5 = (int32_t)var_c8h - (int32_t)var_d0h;
    fVar13 = (float)var_d8h._4_4_;
    iVar6 = var_bch - var_c8h._4_4_;
    fVar14 = (float)(int32_t)var_d0h;
    iVar7 = (int32_t)var_b8h - var_c0h;
    fVar15 = (float)var_c8h._4_4_;
    fVar16 = (float)var_c0h;
    fVar12 = (float)func_0x00018016a3b0(arg1);
    iVar3 = *(int64_t *)0x180781f28;
    if (fVar12 <= 0.0) goto code_r0x000180168b8e;
    piVar11 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    iVar1 = *piVar11;
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd64);
    if ((var_b8h & 0x100000000U) == 0) {
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
code_r0x000180168adc:
            func_0x00018016b050(piVar11, iVar10);
        }
code_r0x000180168ae4:
        iVar9 = (int64_t)*piVar11;
        iVar3 = *(int64_t *)(iVar3 + 0xd68);
        *(float *)(iVar3 + iVar9 * 0x30) = fVar13;
        *(float *)(iVar3 + 4 + iVar9 * 0x30) = fVar14;
        *(float *)(iVar3 + 8 + iVar9 * 0x30) = (float)iVar4;
        *(float *)(iVar3 + 0xc + iVar9 * 0x30) = (float)iVar5;
        *(float *)(iVar3 + 0x10 + iVar9 * 0x30) = fVar15;
        *(float *)(iVar3 + 0x14 + iVar9 * 0x30) = fVar16;
        *(float *)(iVar3 + 0x18 + iVar9 * 0x30) = (float)iVar6;
        *(float *)(iVar3 + 0x1c + iVar9 * 0x30) = (float)iVar7;
        *(float *)(iVar3 + 0x20 + iVar9 * 0x30) = fVar12;
        *(float *)(iVar3 + 0x24 + iVar9 * 0x30) = var_b8h._4_4_;
        *(int64_t *)(iVar3 + 0x28 + iVar9 * 0x30) = arg1;
    } else {
        if (iVar1 == 0) {
            if (iVar8 == 0) {
                iVar10 = 8;
                goto code_r0x000180168adc;
            }
            goto code_r0x000180168ae4;
        }
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
            func_0x00018016b050(piVar11, iVar10);
        }
        if (0 < (int64_t)*piVar11) {
            func_0x000180498030(*(int64_t *)(iVar3 + 0xd68) + 0x30, *(int64_t *)(iVar3 + 0xd68), 
                                (int64_t)*piVar11 * 0x30);
        }
        pfVar2 = *(float **)(iVar3 + 0xd68);
        *pfVar2 = fVar13;
        pfVar2[1] = fVar14;
        pfVar2[2] = (float)iVar4;
        pfVar2[3] = (float)iVar5;
        pfVar2[4] = fVar15;
        pfVar2[5] = fVar16;
        pfVar2[6] = (float)iVar6;
        pfVar2[7] = (float)iVar7;
        pfVar2[8] = fVar12;
        pfVar2[9] = var_b8h._4_4_;
        *(int64_t *)(pfVar2 + 10) = arg1;
    }
    *piVar11 = *piVar11 + 1;
code_r0x000180168b8e:
    func_0x000180459870(var_a8h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_1801689e8
// Address: 0x1801689e8
// Size: 349 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.1801688d0(int64_t arg1, int64_t arg_110h)
{
    int32_t iVar1;
    float *pfVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t *piVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    int64_t var_10h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int32_t var_c0h;
    int32_t var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_a8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    stack0xffffffffffffff2c = SUB1612(ZEXT816(0), 4);
    var_d8h._0_4_ = 0x28;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    iVar4 = (*(code *)0x69a5ca)(0, &var_d8h);
    if (iVar4 == 0) goto code_r0x000180168b8e;
    iVar4 = var_d0h._4_4_ - var_d8h._4_4_;
    iVar5 = (int32_t)var_c8h - (int32_t)var_d0h;
    fVar13 = (float)var_d8h._4_4_;
    iVar6 = var_bch - var_c8h._4_4_;
    fVar14 = (float)(int32_t)var_d0h;
    iVar7 = (int32_t)var_b8h - var_c0h;
    fVar15 = (float)var_c8h._4_4_;
    fVar16 = (float)var_c0h;
    fVar12 = (float)func_0x00018016a3b0(arg1);
    iVar3 = *(int64_t *)0x180781f28;
    if (fVar12 <= 0.0) goto code_r0x000180168b8e;
    piVar11 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    iVar1 = *piVar11;
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd64);
    if ((var_b8h & 0x100000000U) == 0) {
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
code_r0x000180168adc:
            func_0x00018016b050(piVar11, iVar10);
        }
code_r0x000180168ae4:
        iVar9 = (int64_t)*piVar11;
        iVar3 = *(int64_t *)(iVar3 + 0xd68);
        *(float *)(iVar3 + iVar9 * 0x30) = fVar13;
        *(float *)(iVar3 + 4 + iVar9 * 0x30) = fVar14;
        *(float *)(iVar3 + 8 + iVar9 * 0x30) = (float)iVar4;
        *(float *)(iVar3 + 0xc + iVar9 * 0x30) = (float)iVar5;
        *(float *)(iVar3 + 0x10 + iVar9 * 0x30) = fVar15;
        *(float *)(iVar3 + 0x14 + iVar9 * 0x30) = fVar16;
        *(float *)(iVar3 + 0x18 + iVar9 * 0x30) = (float)iVar6;
        *(float *)(iVar3 + 0x1c + iVar9 * 0x30) = (float)iVar7;
        *(float *)(iVar3 + 0x20 + iVar9 * 0x30) = fVar12;
        *(float *)(iVar3 + 0x24 + iVar9 * 0x30) = var_b8h._4_4_;
        *(int64_t *)(iVar3 + 0x28 + iVar9 * 0x30) = arg1;
    } else {
        if (iVar1 == 0) {
            if (iVar8 == 0) {
                iVar10 = 8;
                goto code_r0x000180168adc;
            }
            goto code_r0x000180168ae4;
        }
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
            func_0x00018016b050(piVar11, iVar10);
        }
        if (0 < (int64_t)*piVar11) {
            func_0x000180498030(*(int64_t *)(iVar3 + 0xd68) + 0x30, *(int64_t *)(iVar3 + 0xd68), 
                                (int64_t)*piVar11 * 0x30);
        }
        pfVar2 = *(float **)(iVar3 + 0xd68);
        *pfVar2 = fVar13;
        pfVar2[1] = fVar14;
        pfVar2[2] = (float)iVar4;
        pfVar2[3] = (float)iVar5;
        pfVar2[4] = fVar15;
        pfVar2[5] = fVar16;
        pfVar2[6] = (float)iVar6;
        pfVar2[7] = (float)iVar7;
        pfVar2[8] = fVar12;
        pfVar2[9] = var_b8h._4_4_;
        *(int64_t *)(pfVar2 + 10) = arg1;
    }
    *piVar11 = *piVar11 + 1;
code_r0x000180168b8e:
    func_0x000180459870(var_a8h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180168b45
// Address: 0x180168b45
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.1801688d0(int64_t arg1, int64_t arg_110h)
{
    int32_t iVar1;
    float *pfVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t *piVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    int64_t var_10h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int32_t var_c0h;
    int32_t var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_a8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    stack0xffffffffffffff2c = SUB1612(ZEXT816(0), 4);
    var_d8h._0_4_ = 0x28;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    iVar4 = (*(code *)0x69a5ca)(0, &var_d8h);
    if (iVar4 == 0) goto code_r0x000180168b8e;
    iVar4 = var_d0h._4_4_ - var_d8h._4_4_;
    iVar5 = (int32_t)var_c8h - (int32_t)var_d0h;
    fVar13 = (float)var_d8h._4_4_;
    iVar6 = var_bch - var_c8h._4_4_;
    fVar14 = (float)(int32_t)var_d0h;
    iVar7 = (int32_t)var_b8h - var_c0h;
    fVar15 = (float)var_c8h._4_4_;
    fVar16 = (float)var_c0h;
    fVar12 = (float)func_0x00018016a3b0(arg1);
    iVar3 = *(int64_t *)0x180781f28;
    if (fVar12 <= 0.0) goto code_r0x000180168b8e;
    piVar11 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    iVar1 = *piVar11;
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd64);
    if ((var_b8h & 0x100000000U) == 0) {
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
code_r0x000180168adc:
            func_0x00018016b050(piVar11, iVar10);
        }
code_r0x000180168ae4:
        iVar9 = (int64_t)*piVar11;
        iVar3 = *(int64_t *)(iVar3 + 0xd68);
        *(float *)(iVar3 + iVar9 * 0x30) = fVar13;
        *(float *)(iVar3 + 4 + iVar9 * 0x30) = fVar14;
        *(float *)(iVar3 + 8 + iVar9 * 0x30) = (float)iVar4;
        *(float *)(iVar3 + 0xc + iVar9 * 0x30) = (float)iVar5;
        *(float *)(iVar3 + 0x10 + iVar9 * 0x30) = fVar15;
        *(float *)(iVar3 + 0x14 + iVar9 * 0x30) = fVar16;
        *(float *)(iVar3 + 0x18 + iVar9 * 0x30) = (float)iVar6;
        *(float *)(iVar3 + 0x1c + iVar9 * 0x30) = (float)iVar7;
        *(float *)(iVar3 + 0x20 + iVar9 * 0x30) = fVar12;
        *(float *)(iVar3 + 0x24 + iVar9 * 0x30) = var_b8h._4_4_;
        *(int64_t *)(iVar3 + 0x28 + iVar9 * 0x30) = arg1;
    } else {
        if (iVar1 == 0) {
            if (iVar8 == 0) {
                iVar10 = 8;
                goto code_r0x000180168adc;
            }
            goto code_r0x000180168ae4;
        }
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
            func_0x00018016b050(piVar11, iVar10);
        }
        if (0 < (int64_t)*piVar11) {
            func_0x000180498030(*(int64_t *)(iVar3 + 0xd68) + 0x30, *(int64_t *)(iVar3 + 0xd68), 
                                (int64_t)*piVar11 * 0x30);
        }
        pfVar2 = *(float **)(iVar3 + 0xd68);
        *pfVar2 = fVar13;
        pfVar2[1] = fVar14;
        pfVar2[2] = (float)iVar4;
        pfVar2[3] = (float)iVar5;
        pfVar2[4] = fVar15;
        pfVar2[5] = fVar16;
        pfVar2[6] = (float)iVar6;
        pfVar2[7] = (float)iVar7;
        pfVar2[8] = fVar12;
        pfVar2[9] = var_b8h._4_4_;
        *(int64_t *)(pfVar2 + 10) = arg1;
    }
    *piVar11 = *piVar11 + 1;
code_r0x000180168b8e:
    func_0x000180459870(var_a8h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180168b8e
// Address: 0x180168b8e
// Size: 27 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.1801688d0(int64_t arg1, int64_t arg_110h)
{
    int32_t iVar1;
    float *pfVar2;
    int64_t iVar3;
    int32_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t *piVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    int64_t var_10h;
    undefined auStack_f8 [32];
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int32_t var_c0h;
    int32_t var_bch;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    var_a8h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_f8;
    stack0xffffffffffffff2c = SUB1612(ZEXT816(0), 4);
    var_d8h._0_4_ = 0x28;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    iVar4 = (*(code *)0x69a5ca)(0, &var_d8h);
    if (iVar4 == 0) goto code_r0x000180168b8e;
    iVar4 = var_d0h._4_4_ - var_d8h._4_4_;
    iVar5 = (int32_t)var_c8h - (int32_t)var_d0h;
    fVar13 = (float)var_d8h._4_4_;
    iVar6 = var_bch - var_c8h._4_4_;
    fVar14 = (float)(int32_t)var_d0h;
    iVar7 = (int32_t)var_b8h - var_c0h;
    fVar15 = (float)var_c8h._4_4_;
    fVar16 = (float)var_c0h;
    fVar12 = (float)func_0x00018016a3b0(arg1);
    iVar3 = *(int64_t *)0x180781f28;
    if (fVar12 <= 0.0) goto code_r0x000180168b8e;
    piVar11 = (int32_t *)(*(int64_t *)0x180781f28 + 0xd60);
    iVar1 = *piVar11;
    iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd64);
    if ((var_b8h & 0x100000000U) == 0) {
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
code_r0x000180168adc:
            func_0x00018016b050(piVar11, iVar10);
        }
code_r0x000180168ae4:
        iVar9 = (int64_t)*piVar11;
        iVar3 = *(int64_t *)(iVar3 + 0xd68);
        *(float *)(iVar3 + iVar9 * 0x30) = fVar13;
        *(float *)(iVar3 + 4 + iVar9 * 0x30) = fVar14;
        *(float *)(iVar3 + 8 + iVar9 * 0x30) = (float)iVar4;
        *(float *)(iVar3 + 0xc + iVar9 * 0x30) = (float)iVar5;
        *(float *)(iVar3 + 0x10 + iVar9 * 0x30) = fVar15;
        *(float *)(iVar3 + 0x14 + iVar9 * 0x30) = fVar16;
        *(float *)(iVar3 + 0x18 + iVar9 * 0x30) = (float)iVar6;
        *(float *)(iVar3 + 0x1c + iVar9 * 0x30) = (float)iVar7;
        *(float *)(iVar3 + 0x20 + iVar9 * 0x30) = fVar12;
        *(float *)(iVar3 + 0x24 + iVar9 * 0x30) = var_b8h._4_4_;
        *(int64_t *)(iVar3 + 0x28 + iVar9 * 0x30) = arg1;
    } else {
        if (iVar1 == 0) {
            if (iVar8 == 0) {
                iVar10 = 8;
                goto code_r0x000180168adc;
            }
            goto code_r0x000180168ae4;
        }
        if (iVar1 == iVar8) {
            if (iVar8 == 0) {
                iVar8 = 8;
            } else {
                iVar8 = iVar8 / 2 + iVar8;
            }
            iVar10 = iVar1 + 1;
            if (iVar1 + 1 < iVar8) {
                iVar10 = iVar8;
            }
            func_0x00018016b050(piVar11, iVar10);
        }
        if (0 < (int64_t)*piVar11) {
            func_0x000180498030(*(int64_t *)(iVar3 + 0xd68) + 0x30, *(int64_t *)(iVar3 + 0xd68), 
                                (int64_t)*piVar11 * 0x30);
        }
        pfVar2 = *(float **)(iVar3 + 0xd68);
        *pfVar2 = fVar13;
        pfVar2[1] = fVar14;
        pfVar2[2] = (float)iVar4;
        pfVar2[3] = (float)iVar5;
        pfVar2[4] = fVar15;
        pfVar2[5] = fVar16;
        pfVar2[6] = (float)iVar6;
        pfVar2[7] = (float)iVar7;
        pfVar2[8] = fVar12;
        pfVar2[9] = var_b8h._4_4_;
        *(int64_t *)(pfVar2 + 10) = arg1;
    }
    *piVar11 = *piVar11 + 1;
code_r0x000180168b8e:
    func_0x000180459870(var_a8h ^ (uint64_t)auStack_f8);
    return;
}

// ============================================================
// Function: FUN_180168bb0
// Address: 0x180168bb0
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_cch
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.180168bb0(undefined8 placeholder_0, int64_t arg2)
{
    undefined4 *puVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t var_8h;
    
    if (*(int64_t *)0x180781f28 == 0) {
        iVar4 = 0;
    } else {
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd0);
    }
    puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd60);
    iVar3 = *(int32_t *)(*(int64_t *)0x180781f28 + 0xd64);
    if (iVar3 < 0) {
        iVar3 = iVar3 + iVar3 / 2;
        iVar2 = 0;
        if (0 < iVar3) {
            iVar2 = iVar3;
        }
        func_0x00018016b050(puVar1, iVar2);
    }
    *puVar1 = 0;
    (*(code *)0x69a684)(0, 0, fcn.1801688d0, 0);
    *(undefined *)(iVar4 + 0x30) = 0;
    return;
}

// ============================================================
// Function: FUN_180168c20
// Address: 0x180168c20
// Size: 574 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_82h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7eh
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ah
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h

void fcn.180168c20(void)
{
    int64_t arg1;
    int64_t arg2;
    int64_t iVar1;
    int16_t iVar2;
    undefined8 placeholder_0;
    int64_t *arg2_00;
    uint64_t arg2_01;
    undefined8 *puVar3;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_48 [32];
    int64_t var_28h;
    int64_t var_20h;
    int64_t var_18h;
    uint64_t uStack_10;
    
    iVar1 = *(int64_t *)0x180781f28;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_48;
    if (*(int64_t *)0x180781f28 == 0) {
        puVar3 = (undefined8 *)0x0;
    } else {
        puVar3 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0xd0);
    }
    _var_20h = ZEXT816(0);
    arg2_00 = &var_20h;
    placeholder_0 = *puVar3;
    arg1 = *(int64_t *)0x180781f28 + 0x30;
    arg2 = *(int64_t *)0x180781f28 + 0xc48;
    (*(code *)0x69a3e6)();
    *(float *)(iVar1 + 0x38) = (float)((int32_t)var_18h - (int32_t)var_20h);
    *(float *)(iVar1 + 0x3c) = (float)(var_18h._4_4_ - var_20h._4_4_);
    if (*(char *)(puVar3 + 6) != '\0') {
        fcn.180168bb0(placeholder_0, (int64_t)arg2_00);
    }
    var_28h = 0;
    (*(code *)0x699e76)(&var_28h);
    *(float *)(iVar1 + 0x48) = (float)(var_28h - puVar3[3]) / (float)puVar3[4];
    puVar3[3] = var_28h;
    fcn.180168040(arg1, arg2);
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x240) != '\0') && (*(char *)(*(int64_t *)0x180781f28 + 0x1794) == '\0')) {
        iVar2 = (*(code *)0x69a706)(0xa0);
        if ((-1 < iVar2) && (*(char *)(iVar1 + 0xc15) != '\0')) {
            func_0x0001800f5370(arg1, 0x210, 0, 0);
        }
    }
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x280) != '\0') && (*(char *)(*(int64_t *)0x180781f28 + 0x17c4) == '\0')) {
        iVar2 = (*(code *)0x69a706)(0xa1);
        if ((-1 < iVar2) && (*(char *)(iVar1 + 0xc15) != '\0')) {
            func_0x0001800f5370(arg1, 0x214, 0, 0);
        }
    }
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x260) != '\0') && (*(char *)(*(int64_t *)0x180781f28 + 0x17ac) == '\0')) {
        iVar2 = (*(code *)0x69a706)(0x5b);
        if ((-1 < iVar2) && (*(char *)(iVar1 + 0xc15) != '\0')) {
            func_0x0001800f5370(arg1, 0x212, 0, 0);
        }
    }
    if ((*(char *)(*(int64_t *)0x180781f28 + 0x2a0) != '\0') && (*(char *)(*(int64_t *)0x180781f28 + 0x17dc) == '\0')) {
        iVar2 = (*(code *)0x69a706)(0x5c);
        if ((-1 < iVar2) && (*(char *)(iVar1 + 0xc15) != '\0')) {
            func_0x0001800f5370(arg1, 0x216, 0, 0);
        }
    }
    if (*(char *)(iVar1 + 0x8c) == '\0') {
        arg2_01 = (uint64_t)*(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650);
    } else {
        arg2_01 = 0xffffffff;
    }
    if (*(int32_t *)(puVar3 + 5) != (int32_t)arg2_01) {
        *(int32_t *)(puVar3 + 5) = (int32_t)arg2_01;
        fcn.180167e90(arg1, arg2_01);
    }
    fcn.1801682b0(arg1);
    func_0x000180459870(uStack_10 ^ (uint64_t)auStack_48);
    return;
}

// ============================================================
// Function: FUN_180168e60
// Address: 0x180168e60
// Size: 59 bytes
// ============================================================
undefined fcn.180168e60(void)
{
    uint64_t uVar1;
    
    uVar1 = (*(code *)0x69a6f0)();
    if ((uVar1 & 0xffffff80) == 0xff515700) {
        return 2;
    }
    return (uVar1 & 0xffffff80) == 0xff515780;
}

// ============================================================
// Function: FUN_180168ea0
// Address: 0x180168ea0
// Size: 5140 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: Variable defined which should be unmapped: var_b0h
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_9h
// WARNING: Variable defined which should be unmapped: var_15h
// WARNING: Variable defined which should be unmapped: var_21h
// WARNING: Variable defined which should be unmapped: var_39h
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_41h
// WARNING: [rz-ghidra] Detected overlap for variable var_35h
// WARNING: [rz-ghidra] Detected overlap for variable var_31h
// WARNING: [rz-ghidra] Detected overlap for variable var_2dh
// WARNING: [rz-ghidra] Detected overlap for variable var_29h
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Detected overlap for variable var_11h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_dh

undefined8 fcn.180168ea0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int32_t *piVar1;
    undefined4 *puVar2;
    uint32_t *puVar3;
    int16_t iVar4;
    char extraout_AH;
    char extraout_AH_00;
    char extraout_AH_01;
    char extraout_AH_02;
    char extraout_AH_03;
    char extraout_AH_04;
    int32_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint32_t uVar12;
    int32_t iVar13;
    undefined8 uVar14;
    bool bVar15;
    char cVar16;
    undefined auVar17 [16];
    undefined auVar18 [16];
    undefined4 uVar19;
    int64_t var_10h;
    uint64_t uStackX_18;
    int64_t iStackX_20;
    uint16_t in_stack_00000028;
    undefined2 in_stack_0000002a;
    undefined4 in_stack_0000002c;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int32_t iStack_90;
    int32_t iStack_8c;
    undefined4 uStack_88;
    undefined4 uStack_84;
    int64_t iStack_80;
    undefined4 uStack_78;
    undefined4 uStack_70;
    undefined4 uStack_6c;
    undefined8 uStack_68;
    uint32_t uStack_60;
    uint32_t uStack_5c;
    uint32_t uStack_58;
    int64_t var_48h;
    int64_t var_39h;
    int64_t var_21h;
    int64_t var_15h;
    int64_t var_9h;
    
    puVar3 = (uint32_t *)CONCAT44(in_stack_0000002c, CONCAT22(in_stack_0000002a, in_stack_00000028));
    uVar8 = (uint32_t)arg2;
    iVar11 = *(int64_t *)(puVar3 + 0x28);
    if (iVar11 == 0) {
        return 0;
    }
    uVar14 = 0x200;
    uStackX_18 = arg3;
    iStackX_20 = arg4;
    if (0x200 < uVar8) {
        iVar4 = (int16_t)((uint64_t)arg3 >> 0x10);
    // switch table (224 cases) at 0x18016a1b0
        switch(uVar8) {
        case 0x201:
        case 0x203:
        case 0x204:
        case 0x206:
        case 0x207:
        case 0x209:
        case 0x20b:
        case 0x20d:
            uVar7 = fcn.180168e60();
            in_stack_00000028 = (uint16_t)uVar7;
            in_stack_0000002a = (undefined2)((uint32_t)uVar7 >> 0x10);
            if ((uVar8 == 0x204) || (iVar6 = 0, uVar8 == 0x206)) {
                iVar6 = 1;
            }
            if ((uVar8 - 0x207 & 0xfffffffd) == 0) {
                iVar6 = 2;
            }
            if ((uVar8 - 0x20b & 0xfffffffd) == 0) {
                iVar6 = ((int16_t)(uStackX_18 >> 0x10) != 1) + 3;
            }
            iVar10 = (*(code *)0x69a61e)();
            if (*(int32_t *)(iVar11 + 0x14) != 0) {
                if (iVar10 == arg1) goto code_r0x000180169ba3;
                *(undefined4 *)(iVar11 + 0x14) = 0;
            }
            if (iVar10 == 0) {
                (*(code *)0x69a572)();
            }
code_r0x000180169ba3:
            *(uint32_t *)(iVar11 + 0x14) = *(uint32_t *)(iVar11 + 0x14) | 1 << iVar6;
            *(uint32_t *)(*(int64_t *)(puVar3 + 0x38) + 0x1578) = CONCAT22(in_stack_0000002a, in_stack_00000028);
            func_0x0001800f56b0(puVar3, iVar6, 1);
            return 0;
        case 0x202:
        case 0x205:
        case 0x208:
        case 0x20c:
            uVar7 = fcn.180168e60();
            in_stack_00000028 = (uint16_t)uVar7;
            in_stack_0000002a = (undefined2)((uint32_t)uVar7 >> 0x10);
            uVar12 = (uint32_t)(uVar8 == 0x205);
            if (uVar8 == 0x208) {
                uVar12 = 2;
            } else if (uVar8 == 0x20c) {
                uVar12 = ((int16_t)(uStackX_18 >> 0x10) != 1) + 3;
            }
            uVar8 = *(uint32_t *)(iVar11 + 0x14) & ~(1 << uVar12);
            *(uint32_t *)(iVar11 + 0x14) = uVar8;
            if ((uVar8 == 0) && (iVar11 = (*(code *)0x69a61e)(), iVar11 == arg1)) {
                (*(code *)0x69a530)();
            }
            *(uint32_t *)(*(int64_t *)(puVar3 + 0x38) + 0x1578) = CONCAT22(in_stack_0000002a, in_stack_00000028);
            func_0x0001800f56b0(puVar3, uVar12, 0);
            return 0;
        case 0x20a:
            func_0x0001800f5890(puVar3, 0x180000000, (float)(int32_t)iVar4 / 120.0);
            return 0;
        case 0x20e:
            auVar17._0_4_ = (float)((uint32_t)(float)(int32_t)iVar4 ^ 0x80000000);
            auVar17._4_4_ = 0x80000000;
            auVar17._8_4_ = 0x80000000;
            auVar17._12_4_ = 0x80000000;
            auVar18._4_12_ = auVar17._4_12_;
            auVar18._0_4_ = auVar17._0_4_ / 120.0;
            func_0x0001800f5890(puVar3, auVar18._0_8_);
            return 0;
        default:
            return 0;
        case 0x219:
            if ((int32_t)arg3 != 7) {
                return 0;
            }
            *(undefined *)(iVar11 + 0x41) = 1;
            return 0;
        case 0x286:
            iVar6 = (*(code *)0x69a542)(arg1);
            if (iVar6 != 0) {
                return 0;
            }
            iVar6 = (*(code *)0x699edc)(uStackX_18 >> 8);
            if (iVar6 != 0) {
                uStackX_18 = (uint64_t)(uint16_t)((int16_t)uStackX_18 << 8) | uStackX_18 >> 8 & 0xff;
            }
            in_stack_00000028 = 0;
            (*(code *)0x699e90)(*(undefined4 *)(iVar11 + 0x2c), 1, &uStackX_18, 2, &stack0x00000028, 1);
            func_0x0001800f5210(puVar3, in_stack_00000028);
            return 1;
        case 0x2a2:
        case 0x2a3:
            goto code_r0x000180169ae3;
        case 0x2e0:
            if (*(char *)((int64_t)puVar3 + 0x5b) == '\0') {
                return 0;
            }
            var_b8h = (int64_t)(uint32_t)(*(int32_t *)(arg4 + 8) - *(int32_t *)arg4);
            (*(code *)0x69a6ae)(arg1, 0, *(int32_t *)arg4, *(int32_t *)(arg4 + 4), var_b8h, 
                                *(int32_t *)(arg4 + 0xc) - *(int32_t *)(arg4 + 4), 0x14);
            return 0;
        }
    }
    if (uVar8 == 0x200) {
code_r0x0001801699c1:
        uVar7 = fcn.180168e60();
        *(int64_t *)(iVar11 + 8) = arg1;
        _in_stack_00000028 = (uVar8 != 0x200) + 1;
        if (*(int32_t *)(iVar11 + 0x10) != _in_stack_00000028) {
            uStack_88 = 0x18;
            uStack_84 = 0x80000000;
            uStack_6c = 2;
            if (uVar8 != 0x200) {
                uStack_6c = 0x12;
            }
            uStack_78 = 0;
            uStack_70 = 0x18;
            uStack_60 = 0;
            iStack_80 = arg1;
            uStack_68 = arg1;
            if (*(int32_t *)(iVar11 + 0x10) != 0) {
                (*(code *)0x69a5f0)(&uStack_88);
            }
            (*(code *)0x69a5f0)(&uStack_70);
            *(int32_t *)(iVar11 + 0x10) = _in_stack_00000028;
            arg4 = iStackX_20;
        }
        iStack_90 = (int32_t)(int16_t)arg4;
        iStack_8c = (int32_t)(int16_t)((uint64_t)arg4 >> 0x10);
        if (uVar8 == 0x200) {
            if ((*puVar3 & 0x400) != 0) {
                (*(code *)0x69a42c)(arg1, &iStack_90);
            }
        } else if ((uVar8 == 0xa0) && ((*puVar3 & 0x400) == 0)) {
            (*(code *)0x69a660)(arg1, &iStack_90);
        }
        *(undefined4 *)(*(int64_t *)(puVar3 + 0x38) + 0x1578) = uVar7;
        func_0x0001800f5530(puVar3);
        return 0;
    }
    if (uVar8 < 8) {
        if (uVar8 == 7) goto code_r0x000180169762;
        if (uVar8 != 2) {
            return 0;
        }
        if (*(int64_t *)(iVar11 + 8) != arg1) {
            return 0;
        }
        if (*(int32_t *)(iVar11 + 0x10) == 0) {
            return 0;
        }
        uStack_78 = 0;
        uStack_88 = 0x18;
        uStack_84 = 0x80000000;
        iStack_80 = arg1;
        (*(code *)0x69a5f0)(&uStack_88);
        goto code_r0x000180169b02;
    }
    if (0x10f < uVar8) {
        return 0;
    }
    if (uVar8 == 0x10f) {
        uVar14 = (*(code *)0x69a72a)(arg1, 0x10f);
        if (((uint64_t)arg4 >> 0xb & 1) != 0) {
            return 1;
        }
        return uVar14;
    }
    // switch table (254 cases) at 0x180169da0
    switch(uVar8) {
    case 8:
code_r0x000180169762:
        iVar10 = *(int64_t *)(puVar3 + 0x38);
        piVar1 = (int32_t *)(iVar10 + 0x1558);
        iVar6 = *piVar1;
        uVar12 = iVar6 - 1;
        if (-1 < (int32_t)uVar12) {
            do {
                if (*(int32_t *)((uint64_t)uVar12 * 0x1c + *(int64_t *)(iVar10 + 0x1560)) == 7) {
                    cVar16 = *(char *)((uint64_t)uVar12 * 0x1c + 0xc + *(int64_t *)(iVar10 + 0x1560));
                    goto code_r0x0001801697ad;
                }
                uVar12 = uVar12 - 1;
            } while (-1 < (int32_t)uVar12);
        }
        cVar16 = *(char *)(iVar10 + 0xc14) == '\0';
code_r0x0001801697ad:
        if (((bool)cVar16 != (uVar8 == 7)) && ((*(char *)((int64_t)puVar3 + 0x89) == '\0' || (uVar8 == 7)))) {
            uStack_68._0_4_ = *(int32_t *)(iVar10 + 0x157c);
            uStack_6c = 0;
            *(int32_t *)(iVar10 + 0x157c) = (int32_t)uStack_68 + 1;
            iVar5 = *(int32_t *)(iVar10 + 0x155c);
            uStack_70 = 7;
            uStack_60 = 0;
            uStack_5c = 0;
            uStack_58 = 0;
            uStack_68._4_4_ = (uint32_t)(uVar8 == 7);
            if (iVar6 == iVar5) {
                if (iVar5 == 0) {
                    iVar5 = 8;
                } else {
                    iVar5 = iVar5 / 2 + iVar5;
                }
                iVar13 = iVar6 + 1;
                if (iVar6 + 1 < iVar5) {
                    iVar13 = iVar5;
                }
                func_0x00018011f9d0(piVar1, iVar13);
            }
            iVar6 = *piVar1;
            iVar10 = *(int64_t *)(iVar10 + 0x1560);
            puVar2 = (undefined4 *)((int64_t)iVar6 * 0x1c + iVar10);
            *puVar2 = uStack_70;
            puVar2[1] = uStack_6c;
            puVar2[2] = (int32_t)uStack_68;
            puVar2[3] = uStack_68._4_4_;
            puVar3 = (uint32_t *)((int64_t)iVar6 * 0x1c + 0xc + iVar10);
            *puVar3 = uStack_68._4_4_;
            puVar3[1] = uStack_60;
            puVar3[2] = uStack_5c;
            puVar3[3] = uStack_58;
            *piVar1 = *piVar1 + 1;
        }
        *(undefined4 *)(iVar11 + 0x60) = 0;
        return 0;
    case 0x1a:
        if (arg3 != 0x2f) {
            return 0;
        }
    case 0x7e:
        *(undefined *)(iVar11 + 0x30) = 1;
        break;
    case 0x20:
        if (((int16_t)arg4 == 1) &&
           (cVar16 = fcn.180167e90((int64_t)puVar3, (uint64_t)*(uint32_t *)(iVar11 + 0x28)), cVar16 != '\0')) {
            return 1;
        }
        break;
    case 0x51:
        fcn.1801679d0((int64_t)puVar3);
        break;
    case 0xa0:
        goto code_r0x0001801699c1;
    case 0x100:
    case 0x101:
    case 0x104:
    case 0x105:
        bVar15 = (uVar8 - 0x100 & 0xfffffffb) == 0;
        if (0xff < (uint64_t)arg3) {
            return 0;
        }
        iVar4 = (*(code *)0x69a706)(0x11);
        uVar7 = 0x3f800000;
        if (*(char *)((int64_t)puVar3 + 0xbe5) != '\0') {
            if (iVar4 < 0) {
                uVar19 = 0x3f800000;
            } else {
                uVar19 = 0;
            }
            func_0x0001800f5370(puVar3, 0x1000, (uint8_t)((uint16_t)iVar4 >> 0xf), uVar19);
        }
        iVar4 = (*(code *)0x69a706)(0x10);
        if (*(char *)((int64_t)puVar3 + 0xbe5) != '\0') {
            if (iVar4 < 0) {
                uVar19 = 0x3f800000;
            } else {
                uVar19 = 0;
            }
            func_0x0001800f5370(puVar3, 0x2000, (uint8_t)((uint16_t)iVar4 >> 0xf), uVar19);
        }
        iVar4 = (*(code *)0x69a706)(0x12);
        if (*(char *)((int64_t)puVar3 + 0xbe5) != '\0') {
            if (iVar4 < 0) {
                uVar19 = 0x3f800000;
            } else {
                uVar19 = 0;
            }
            func_0x0001800f5370(puVar3, 0x4000, (uint8_t)((uint16_t)iVar4 >> 0xf), uVar19);
        }
        uVar9 = (*(code *)0x69a706)(0x5b);
        if (((uVar9 & 0x8000) == 0) && (uVar9 = (*(code *)0x69a706)(0x5c), (uVar9 & 0x8000) == 0)) {
            cVar16 = '\0';
        } else {
            cVar16 = '\x01';
        }
        if (*(char *)((int64_t)puVar3 + 0xbe5) != '\0') {
            if (cVar16 == '\0') {
                uVar19 = 0;
            } else {
                uVar19 = 0x3f800000;
            }
            func_0x0001800f5370(puVar3, 0x8000, cVar16, uVar19);
        }
        uVar9 = uStackX_18;
        if ((uStackX_18 == 0xd) && ((arg4 & 0x1000000U) != 0)) {
            uVar14 = 0x273;
            goto code_r0x000180169595;
        }
    // switch table (109 cases) at 0x180169ec4
        switch(uStackX_18) {
        case 8:
            uVar14 = 0x20b;
            break;
        case 9:
            break;
        default:
    // switch table (13 cases) at 0x18016a130
            switch((uint32_t)((uint64_t)arg4 >> 0x10) & 0xff) {
            case 0xc:
                uVar14 = 0x256;
                break;
            case 0xd:
                uVar14 = 0x25a;
                break;
            default:
                goto code_r0x0001801695ba;
            case 0x1a:
                uVar14 = 0x25b;
                break;
            case 0x1b:
                uVar14 = 0x25d;
                break;
            case 0x27:
                uVar14 = 0x259;
                break;
            case 0x28:
                uVar14 = 0x254;
                break;
            case 0x29:
                uVar14 = 0x25e;
                break;
            case 0x2b:
                uVar14 = 0x25c;
                break;
            case 0x33:
                goto code_r0x000180169173;
            case 0x34:
                goto code_r0x00018016917d;
            case 0x35:
                uVar14 = 600;
                break;
            case 0x56:
                uVar14 = 0x277;
            }
            break;
        case 0xd:
            uVar14 = 0x20d;
            break;
        case 0x13:
            uVar14 = 0x263;
            break;
        case 0x14:
            uVar14 = 0x25f;
            break;
        case 0x1b:
            uVar14 = 0x20e;
            break;
        case 0x20:
            uVar14 = 0x20c;
            break;
        case 0x21:
            uVar14 = 0x205;
            break;
        case 0x22:
            uVar14 = 0x206;
            break;
        case 0x23:
            uVar14 = 0x208;
            break;
        case 0x24:
            uVar14 = 0x207;
            break;
        case 0x25:
            uVar14 = 0x201;
            break;
        case 0x26:
            uVar14 = 0x203;
            break;
        case 0x27:
            uVar14 = 0x202;
            break;
        case 0x28:
            uVar14 = 0x204;
            break;
        case 0x2c:
            uVar14 = 0x262;
            if (!bVar15) {
                if ((bool)*(char *)((int64_t)puVar3 + 0xbe5) == bVar15) goto code_r0x0001801695ba;
                func_0x0001800f5370(puVar3, 0x262, 1, 0x3f800000);
            }
            break;
        case 0x2d:
            uVar14 = 0x209;
            break;
        case 0x2e:
            uVar14 = 0x20a;
            break;
        case 0x30:
            uVar14 = 0x218;
            break;
        case 0x31:
            uVar14 = 0x219;
            break;
        case 0x32:
            uVar14 = 0x21a;
            break;
        case 0x33:
            uVar14 = 0x21b;
            break;
        case 0x34:
            uVar14 = 0x21c;
            break;
        case 0x35:
            uVar14 = 0x21d;
            break;
        case 0x36:
            uVar14 = 0x21e;
            break;
        case 0x37:
            uVar14 = 0x21f;
            break;
        case 0x38:
            uVar14 = 0x220;
            break;
        case 0x39:
            uVar14 = 0x221;
            break;
        case 0x41:
            uVar14 = 0x222;
            break;
        case 0x42:
            uVar14 = 0x223;
            break;
        case 0x43:
            uVar14 = 0x224;
            break;
        case 0x44:
            uVar14 = 0x225;
            break;
        case 0x45:
            uVar14 = 0x226;
            break;
        case 0x46:
            uVar14 = 0x227;
            break;
        case 0x47:
            uVar14 = 0x228;
            break;
        case 0x48:
            uVar14 = 0x229;
            break;
        case 0x49:
            uVar14 = 0x22a;
            break;
        case 0x4a:
            uVar14 = 0x22b;
            break;
        case 0x4b:
            uVar14 = 0x22c;
            break;
        case 0x4c:
            uVar14 = 0x22d;
            break;
        case 0x4d:
            uVar14 = 0x22e;
            break;
        case 0x4e:
            uVar14 = 0x22f;
            break;
        case 0x4f:
            uVar14 = 0x230;
            break;
        case 0x50:
            uVar14 = 0x231;
            break;
        case 0x51:
            uVar14 = 0x232;
            break;
        case 0x52:
            uVar14 = 0x233;
            break;
        case 0x53:
            uVar14 = 0x234;
            break;
        case 0x54:
            uVar14 = 0x235;
            break;
        case 0x55:
            uVar14 = 0x236;
            break;
        case 0x56:
            uVar14 = 0x237;
            break;
        case 0x57:
            uVar14 = 0x238;
            break;
        case 0x58:
            uVar14 = 0x239;
            break;
        case 0x59:
            uVar14 = 0x23a;
            break;
        case 0x5a:
            uVar14 = 0x23b;
            break;
        case 0x5b:
            uVar14 = 0x212;
            break;
        case 0x5c:
            uVar14 = 0x216;
            break;
        case 0x5d:
            uVar14 = 0x217;
            break;
        case 0x60:
            uVar14 = 0x264;
            break;
        case 0x61:
            uVar14 = 0x265;
            break;
        case 0x62:
            uVar14 = 0x266;
            break;
        case 99:
            uVar14 = 0x267;
            break;
        case 100:
            uVar14 = 0x268;
            break;
        case 0x65:
            uVar14 = 0x269;
            break;
        case 0x66:
            uVar14 = 0x26a;
            break;
        case 0x67:
            uVar14 = 0x26b;
            break;
        case 0x68:
            uVar14 = 0x26c;
            break;
        case 0x69:
            uVar14 = 0x26d;
            break;
        case 0x6a:
            uVar14 = 0x270;
            break;
        case 0x6b:
            uVar14 = 0x272;
            break;
        case 0x6d:
            uVar14 = 0x271;
            break;
        case 0x6e:
            uVar14 = 0x26e;
            break;
        case 0x6f:
            uVar14 = 0x26f;
            break;
        case 0x70:
            uVar14 = 0x23c;
            break;
        case 0x71:
            uVar14 = 0x23d;
            break;
        case 0x72:
            uVar14 = 0x23e;
            break;
        case 0x73:
            uVar14 = 0x23f;
            break;
        case 0x74:
            uVar14 = 0x240;
            break;
        case 0x75:
            uVar14 = 0x241;
            break;
        case 0x76:
            uVar14 = 0x242;
            break;
        case 0x77:
            uVar14 = 0x243;
            break;
        case 0x78:
            uVar14 = 0x244;
            break;
        case 0x79:
            uVar14 = 0x245;
            break;
        case 0x7a:
            uVar14 = 0x246;
            break;
        case 0x7b:
            uVar14 = 0x247;
            break;
        case 0x7c:
            uVar14 = 0x248;
            break;
        case 0x7d:
            uVar14 = 0x249;
            break;
        case 0x7e:
            uVar14 = 0x24a;
            break;
        case 0x7f:
            uVar14 = 0x24b;
            break;
        case 0x80:
            uVar14 = 0x24c;
            break;
        case 0x81:
            uVar14 = 0x24d;
            break;
        case 0x82:
            uVar14 = 0x24e;
            break;
        case 0x83:
            uVar14 = 0x24f;
            break;
        case 0x84:
            uVar14 = 0x250;
            break;
        case 0x85:
            uVar14 = 0x251;
            break;
        case 0x86:
            uVar14 = 0x252;
            break;
        case 0x87:
            uVar14 = 0x253;
            break;
        case 0x90:
            uVar14 = 0x261;
            break;
        case 0x91:
            uVar14 = 0x260;
            break;
        case 0xa0:
            uVar14 = 0x210;
            break;
        case 0xa1:
            uVar14 = 0x214;
            break;
        case 0xa2:
            uVar14 = 0x20f;
            break;
        case 0xa3:
            uVar14 = 0x213;
            break;
        case 0xa4:
            uVar14 = 0x211;
            break;
        case 0xa5:
            uVar14 = 0x215;
            break;
        case 0xa6:
            uVar14 = 0x275;
            break;
        case 0xa7:
            uVar14 = 0x276;
            break;
        case 0xbc:
code_r0x000180169173:
            uVar14 = 0x255;
            break;
        case 0xbe:
code_r0x00018016917d:
            uVar14 = 599;
        }
code_r0x000180169595:
        if (*(char *)((int64_t)puVar3 + 0xbe5) != '\0') {
            if (bVar15) {
                uVar19 = 0x3f800000;
            } else {
                uVar19 = 0;
            }
            func_0x0001800f5370(puVar3, uVar14, bVar15, uVar19);
        }
code_r0x0001801695ba:
        iVar6 = (int32_t)uVar9;
        if (iVar6 == 0x10) {
            (*(code *)0x69a706)(0xa0);
            if (((bool)-(extraout_AH >> 7) == bVar15) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                if (bVar15) {
                    uVar19 = 0x3f800000;
                } else {
                    uVar19 = 0;
                }
                func_0x0001800f5370(puVar3, 0x210, bVar15, uVar19);
            }
            (*(code *)0x69a706)(0xa1);
            if (((bool)-(extraout_AH_00 >> 7) == bVar15) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                if (!bVar15) {
                    uVar7 = 0;
                }
                func_0x0001800f5370(puVar3, 0x214, bVar15, uVar7);
            }
        } else if (iVar6 == 0x11) {
            (*(code *)0x69a706)(0xa2);
            if (((bool)-(extraout_AH_01 >> 7) == bVar15) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                if (bVar15) {
                    uVar19 = 0x3f800000;
                } else {
                    uVar19 = 0;
                }
                func_0x0001800f5370(puVar3, 0x20f, bVar15, uVar19);
            }
            (*(code *)0x69a706)(0xa3);
            if (((bool)-(extraout_AH_02 >> 7) == bVar15) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                if (!bVar15) {
                    uVar7 = 0;
                }
                func_0x0001800f5370(puVar3, 0x213, bVar15, uVar7);
            }
        } else if (iVar6 == 0x12) {
            (*(code *)0x69a706)(0xa4);
            if (((bool)-(extraout_AH_03 >> 7) == bVar15) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                if (bVar15) {
                    uVar19 = 0x3f800000;
                } else {
                    uVar19 = 0;
                }
                func_0x0001800f5370(puVar3, 0x211, bVar15, uVar19);
            }
            (*(code *)0x69a706)(0xa5);
            if (((bool)-(extraout_AH_04 >> 7) == bVar15) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                if (!bVar15) {
                    uVar7 = 0;
                }
                func_0x0001800f5370(puVar3, 0x215, bVar15, uVar7);
            }
        }
        break;
    case 0x102:
        iVar6 = (*(code *)0x69a542)(arg1);
        if (iVar6 == 0) {
            in_stack_00000028 = 0;
            (*(code *)0x699e90)(*(undefined4 *)(iVar11 + 0x2c), 1, &uStackX_18, 2, &stack0x00000028, 1);
            if ((in_stack_00000028 != 0) && (*(char *)((int64_t)puVar3 + 0xbe5) != '\0')) {
                iVar11 = *(int64_t *)(puVar3 + 0x38);
                uStack_60 = 0;
                uStack_5c = 0;
                uStack_58 = 0;
                uStack_70 = 6;
                uStack_68._0_4_ = *(int32_t *)(iVar11 + 0x157c);
                piVar1 = (int32_t *)(iVar11 + 0x1558);
                *(int32_t *)(iVar11 + 0x157c) = (int32_t)uStack_68 + 1;
                iVar6 = *(int32_t *)(iVar11 + 0x155c);
                uStack_6c = 2;
                uStack_68._4_4_ = (uint32_t)in_stack_00000028;
                if (*piVar1 == iVar6) {
                    iVar5 = *piVar1 + 1;
                    if (iVar6 == 0) {
                        iVar6 = 8;
                    } else {
                        iVar6 = iVar6 / 2 + iVar6;
                    }
                    if (iVar5 < iVar6) {
                        iVar5 = iVar6;
                    }
                    func_0x00018011f9d0(piVar1, iVar5);
                }
                iVar6 = *piVar1;
                iVar11 = *(int64_t *)(iVar11 + 0x1560);
                puVar2 = (undefined4 *)((int64_t)iVar6 * 0x1c + iVar11);
                *puVar2 = uStack_70;
                puVar2[1] = uStack_6c;
                puVar2[2] = (int32_t)uStack_68;
                puVar2[3] = uStack_68._4_4_;
                puVar3 = (uint32_t *)((int64_t)iVar6 * 0x1c + 0xc + iVar11);
                *puVar3 = uStack_68._4_4_;
                puVar3[1] = uStack_60;
                puVar3[2] = uStack_5c;
                puVar3[3] = uStack_58;
                *piVar1 = *piVar1 + 1;
            }
        } else if (uStackX_18 - 1 < 0xffff) {
            func_0x0001800f5210(puVar3);
        }
    }
    return 0;
code_r0x000180169ae3:
    if (*(int32_t *)(iVar11 + 0x10) != (uVar8 != 0x2a3) + 1) {
        return 0;
    }
    if (*(int64_t *)(iVar11 + 8) != arg1) goto code_r0x000180169b06;
code_r0x000180169b02:
    *(undefined8 *)(iVar11 + 8) = 0;
code_r0x000180169b06:
    *(undefined4 *)(iVar11 + 0x10) = 0;
    func_0x0001800f5530(puVar3);
    return 0;
}

// ============================================================
// Function: FUN_18016a2c0
// Address: 0x18016a2c0
// Size: 234 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h

void fcn.18016a2c0(uint16_t param_1, uint32_t param_2)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t var_18h;
    undefined auStack_158 [32];
    int64_t var_138h;
    uint32_t var_130h;
    int64_t var_12ch;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_158;
    if (*(code **)0x180782510 == (code *)0x0) {
        iVar1 = (*(code *)0x699d1e)(0x180646538);
        if (iVar1 != 0) {
            *(code **)0x180782510 = (code *)(*(code *)0x699eee)(iVar1, 0x180646608);
        }
        if (*(code **)0x180782510 == (code *)0x0) goto code_r0x00018016a389;
    }
    func_0x0001804986e0(&var_12ch, 0, 0x110);
    var_138h._0_4_ = 0x11c;
    var_138h._4_4_ = (uint32_t)param_1;
    var_130h = param_2 & 0xffff;
    uVar2 = (*(code *)0x699b28)(0, 2, 3);
    uVar2 = (*(code *)0x699b28)(uVar2, 1, 3);
    (**(code **)0x180782510)(&var_138h, 3, uVar2);
code_r0x00018016a389:
    func_0x000180459870(uStack_18 ^ (uint64_t)auStack_158);
    return;
}

// ============================================================
// Function: FUN_18016a3b0
// Address: 0x18016a3b0
// Size: 297 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_130h

float fcn.18016a3b0(int64_t arg1)
{
    int32_t iVar1;
    undefined8 uVar2;
    int64_t unaff_GS_OFFSET;
    int64_t var_10h;
    int64_t var_18h;
    
    var_10h._0_4_ = 0x60;
    var_18h._0_4_ = 0x60;
    iVar1 = fcn.18016a2c0(6, 3);
    if (iVar1 != 0) {
        if (*(int32_t *)
             (*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
            *(int32_t *)0x180782b58) {
            func_0x000180459d18(0x180782b58);
            if (*(int32_t *)0x180782b58 == -1) {
                *(int64_t *)0x180782b48 = (*(code *)0x699e24)(0x180646620);
                func_0x000180459cac(0x180782b58);
            }
        }
        if (*(code **)0x180782518 != (code *)0x0) {
code_r0x00018016a434:
            (**(code **)0x180782518)(arg1, 0, &var_10h, &var_18h);
            goto code_r0x00018016a481;
        }
        if (*(int64_t *)0x180782b48 != 0) {
            *(code **)0x180782518 = (code *)(*(code *)0x699eee)(*(int64_t *)0x180782b48, 0x1806465f0);
            if (*(code **)0x180782518 != (code *)0x0) goto code_r0x00018016a434;
        }
    }
    uVar2 = (*(code *)0x69a6be)(0);
    var_10h._0_4_ = (*(code *)0x69a79e)(uVar2, 0x58);
    var_18h._0_4_ = (*(code *)0x69a79e)(uVar2, 0x5a);
    (*(code *)0x69a4f2)(0, uVar2);
code_r0x00018016a481:
    return (float)(uint64_t)(uint32_t)var_10h / 96.0;
}

// ============================================================
// Function: FUN_18016a4e0
// Address: 0x18016a4e0
// Size: 519 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.18016a4e0(int64_t arg1)
{
    uint32_t uVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined4 uVar4;
    uint32_t uVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    undefined8 *puVar8;
    undefined8 uVar9;
    undefined8 *puVar10;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_a8 [32];
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_38h;
    int32_t var_30h;
    int32_t var_2ch;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_a8;
    puVar7 = (undefined8 *)func_0x00018046d050(0x20);
    puVar8 = (undefined8 *)0x0;
    puVar10 = puVar8;
    if (puVar7 != (undefined8 *)0x0) {
        puVar7[1] = 0;
        *puVar7 = 0;
        *(undefined *)(puVar7 + 2) = 0;
        *(undefined8 *)((int64_t)puVar7 + 0x14) = 0;
        puVar10 = puVar7;
    }
    uVar1 = *(uint32_t *)(arg1 + 4);
    *(undefined8 **)(arg1 + 0x50) = puVar10;
    uVar4 = 0x80000000;
    if ((uVar1 & 8) == 0) {
        uVar4 = 0xcf0000;
    }
    *(undefined4 *)((int64_t)puVar10 + 0x14) = uVar4;
    uVar5 = 0x80;
    if ((uVar1 & 0x10) == 0) {
        uVar5 = 0x40000;
    }
    *(uint32_t *)(puVar10 + 3) = uVar5;
    if ((uVar1 >> 10 & 1) != 0) {
        *(uint32_t *)(puVar10 + 3) = uVar5 | 8;
    }
    puVar7 = puVar8;
    if (*(int64_t *)(arg1 + 0x38) != 0) {
        puVar7 = *(undefined8 **)(*(int64_t *)(arg1 + 0x38) + 0x60);
    }
    puVar10[1] = puVar7;
    var_38h._0_4_ = (int32_t)*(float *)(arg1 + 8);
    var_38h._4_4_ = (int32_t)*(float *)(arg1 + 0xc);
    var_30h = (int32_t)(*(float *)(arg1 + 8) + *(float *)(arg1 + 0x10));
    var_2ch = (int32_t)(*(float *)(arg1 + 0xc) + *(float *)(arg1 + 0x14));
    uVar4 = *(undefined4 *)(puVar10 + 3);
    uVar2 = *(undefined4 *)((int64_t)puVar10 + 0x14);
    if (*(int64_t *)0x180781f28 != 0) {
        puVar8 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0xd0);
    }
    if (((((code *)puVar8[7] == (code *)0x0) || (*(char *)((int64_t)puVar8 + 0x31) == '\0')) ||
        (iVar6 = (int32_t)(int64_t)(*(float *)(arg1 + 0x30) * 96.0 + 0.5), iVar6 == 0)) ||
       (var_88h._0_4_ = iVar6, iVar6 = (*(code *)puVar8[7])(&var_38h, uVar2, 0, uVar4), iVar6 == 0)) {
        (*(code *)0x69a714)(&var_38h, uVar2, 0, uVar4);
    }
    var_58h = (*(code *)0x699d1e)(0);
    var_70h._0_4_ = var_2ch - var_38h._4_4_;
    var_50h = 0;
    var_78h._0_4_ = var_30h - (int32_t)var_38h;
    var_68h = puVar10[1];
    var_60h = 0;
    var_80h._0_4_ = var_38h._4_4_;
    var_88h._0_4_ = (int32_t)var_38h;
    uVar9 = (*(code *)0x69a672)(*(undefined4 *)(puVar10 + 3), 0x180646630, 0x1806465d8, 
                                *(undefined4 *)((int64_t)puVar10 + 0x14));
    iVar3 = *(int64_t *)0x180781f28;
    *puVar10 = uVar9;
    *(undefined *)(puVar10 + 2) = 1;
    *(undefined *)(arg1 + 0x72) = 0;
    uVar9 = *puVar10;
    *(undefined8 *)(arg1 + 0x68) = uVar9;
    *(undefined8 *)(arg1 + 0x60) = uVar9;
    (*(code *)0x69a6e4)(*puVar10, 0x1806464b8, iVar3);
    func_0x000180459870(var_28h ^ (uint64_t)auStack_a8);
    return;
}

// ============================================================
// Function: FUN_18016a6f0
// Address: 0x18016a6f0
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016a6f0(int64_t arg1, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    puVar4 = (undefined8 *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        puVar4 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0xd0);
    }
    piVar1 = *(int64_t **)(arg1 + 0x50);
    if (piVar1 == (int64_t *)0x0) {
        *(undefined8 *)(arg1 + 0x60) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        return;
    }
    iVar2 = *piVar1;
    iVar3 = (*(code *)0x69a61e)();
    if (iVar3 == iVar2) {
        (*(code *)0x69a530)();
        (*(code *)0x69a572)(*puVar4);
    }
    if ((*piVar1 != 0) && (*(char *)(piVar1 + 2) != '\0')) {
        (*(code *)0x69a6c6)();
    }
    *piVar1 = 0;
    func_0x000180460d90(piVar1);
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_18016a720
// Address: 0x18016a720
// Size: 24 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016a6f0(int64_t arg1, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    puVar4 = (undefined8 *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        puVar4 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0xd0);
    }
    piVar1 = *(int64_t **)(arg1 + 0x50);
    if (piVar1 == (int64_t *)0x0) {
        *(undefined8 *)(arg1 + 0x60) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        return;
    }
    iVar2 = *piVar1;
    iVar3 = (*(code *)0x69a61e)();
    if (iVar3 == iVar2) {
        (*(code *)0x69a530)();
        (*(code *)0x69a572)(*puVar4);
    }
    if ((*piVar1 != 0) && (*(char *)(piVar1 + 2) != '\0')) {
        (*(code *)0x69a6c6)();
    }
    *piVar1 = 0;
    func_0x000180460d90(piVar1);
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_18016a738
// Address: 0x18016a738
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18016a6f0(int64_t arg1, int64_t arg_58h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 *puVar4;
    int64_t var_8h;
    
    puVar4 = (undefined8 *)0x0;
    if (*(int64_t *)0x180781f28 != 0) {
        puVar4 = *(undefined8 **)(*(int64_t *)0x180781f28 + 0xd0);
    }
    piVar1 = *(int64_t **)(arg1 + 0x50);
    if (piVar1 == (int64_t *)0x0) {
        *(undefined8 *)(arg1 + 0x60) = 0;
        *(undefined8 *)(arg1 + 0x50) = 0;
        return;
    }
    iVar2 = *piVar1;
    iVar3 = (*(code *)0x69a61e)();
    if (iVar3 == iVar2) {
        (*(code *)0x69a530)();
        (*(code *)0x69a572)(*puVar4);
    }
    if ((*piVar1 != 0) && (*(char *)(piVar1 + 2) != '\0')) {
        (*(code *)0x69a6c6)();
    }
    *piVar1 = 0;
    func_0x000180460d90(piVar1);
    *(undefined8 *)(arg1 + 0x60) = 0;
    *(undefined8 *)(arg1 + 0x50) = 0;
    return;
}

// ============================================================
// Function: FUN_18016a790
// Address: 0x18016a790
// Size: 123 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18016a790(int64_t arg1)
{
    undefined8 *puVar1;
    bool bVar2;
    undefined8 uVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar1 = *(undefined8 **)(arg1 + 0x50);
    if ((puVar1[1] == 0) || ((*(uint8_t *)(arg1 + 4) & 0x30) == 0)) {
        bVar2 = false;
    } else {
        bVar2 = true;
        (*(code *)0x69a4a8)(*puVar1, 0xfffffff8, 0);
    }
    uVar3 = 8;
    if ((*(uint8_t *)(arg1 + 4) & 0x20) == 0) {
        uVar3 = 5;
    }
    (*(code *)0x69a62c)(*puVar1, uVar3);
    if (bVar2) {
        (*(code *)0x69a4a8)(*puVar1, 0xfffffff8, puVar1[1]);
    }
    return;
}

// ============================================================
// Function: FUN_18016a810
// Address: 0x18016a810
// Size: 132 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.18016a810(int64_t arg1)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int32_t var_40h;
    int32_t var_3ch;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar9 = *(int64_t *)(arg1 + 0x38);
    puVar4 = *(undefined8 **)(arg1 + 0x50);
    if (iVar9 != 0) {
        iVar9 = *(int64_t *)(iVar9 + 0x60);
    }
    if (iVar9 != puVar4[1]) {
        puVar4[1] = iVar9;
        (*(code *)0x69a4a8)(*puVar4, 0xfffffff8);
    }
    uVar1 = *(uint32_t *)(arg1 + 4);
    iVar7 = -0x80000000;
    if ((uVar1 & 8) == 0) {
        iVar7 = 0xcf0000;
    }
    uVar6 = 0x80;
    if ((uVar1 & 0x10) == 0) {
        uVar6 = 0x40000;
    }
    uVar5 = uVar6 | 8;
    if ((uVar1 & 0x400) == 0) {
        uVar5 = uVar6;
    }
    if ((*(int32_t *)((int64_t)puVar4 + 0x14) == iVar7) && (*(uint32_t *)(puVar4 + 3) == uVar5))
    goto code_r0x00018016aa19;
    uVar6 = *(uint32_t *)(puVar4 + 3);
    iVar9 = 0;
    if ((uVar6 & 8) != (uVar5 & 8)) {
        iVar9 = (uint64_t)((uVar1 & 0x400) != 0) - 2;
    }
    *(uint32_t *)(puVar4 + 3) = uVar5;
    *(int32_t *)((int64_t)puVar4 + 0x14) = iVar7;
    (*(code *)0x69a60c)(*puVar4, 0xfffffff0);
    (*(code *)0x69a60c)(*puVar4, 0xffffffec, *(undefined4 *)(puVar4 + 3));
    uVar2 = *(undefined4 *)(puVar4 + 3);
    uVar3 = *(undefined4 *)((int64_t)puVar4 + 0x14);
    var_48h._0_4_ = (int32_t)*(float *)(arg1 + 8);
    var_48h._4_4_ = (int32_t)*(float *)(arg1 + 0xc);
    var_40h = (int32_t)(*(float *)(arg1 + 8) + *(float *)(arg1 + 0x10));
    var_3ch = (int32_t)(*(float *)(arg1 + 0xc) + *(float *)(arg1 + 0x14));
    iVar8 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd0);
    }
    if ((*(code **)(iVar8 + 0x38) == (code *)0x0) || (*(char *)(iVar8 + 0x31) == '\0')) {
code_r0x00018016a98d:
        (*(code *)0x69a714)(&var_48h, uVar3, 0, uVar2);
    } else {
        iVar7 = (int32_t)(int64_t)(*(float *)(arg1 + 0x30) * 96.0 + 0.5);
        if (iVar7 == 0) goto code_r0x00018016a98d;
        var_68h._0_4_ = iVar7;
        iVar7 = (**(code **)(iVar8 + 0x38))(&var_48h, uVar3, 0, uVar2);
        if (iVar7 == 0) goto code_r0x00018016a98d;
    }
    var_58h._0_4_ = 0x34;
    if ((uVar6 & 8) != (uVar5 & 8)) {
        var_58h._0_4_ = 0x30;
    }
    var_60h._0_4_ = var_3ch - var_48h._4_4_;
    var_68h._0_4_ = var_40h - (int32_t)var_48h;
    (*(code *)0x69a6ae)(*puVar4, iVar9);
    (*(code *)0x69a62c)(*puVar4, 8);
    *(undefined2 *)(arg1 + 0x71) = 0x101;
code_r0x00018016aa19:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18016a894
// Address: 0x18016a894
// Size: 389 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.18016a810(int64_t arg1)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int32_t var_40h;
    int32_t var_3ch;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar9 = *(int64_t *)(arg1 + 0x38);
    puVar4 = *(undefined8 **)(arg1 + 0x50);
    if (iVar9 != 0) {
        iVar9 = *(int64_t *)(iVar9 + 0x60);
    }
    if (iVar9 != puVar4[1]) {
        puVar4[1] = iVar9;
        (*(code *)0x69a4a8)(*puVar4, 0xfffffff8);
    }
    uVar1 = *(uint32_t *)(arg1 + 4);
    iVar7 = -0x80000000;
    if ((uVar1 & 8) == 0) {
        iVar7 = 0xcf0000;
    }
    uVar6 = 0x80;
    if ((uVar1 & 0x10) == 0) {
        uVar6 = 0x40000;
    }
    uVar5 = uVar6 | 8;
    if ((uVar1 & 0x400) == 0) {
        uVar5 = uVar6;
    }
    if ((*(int32_t *)((int64_t)puVar4 + 0x14) == iVar7) && (*(uint32_t *)(puVar4 + 3) == uVar5))
    goto code_r0x00018016aa19;
    uVar6 = *(uint32_t *)(puVar4 + 3);
    iVar9 = 0;
    if ((uVar6 & 8) != (uVar5 & 8)) {
        iVar9 = (uint64_t)((uVar1 & 0x400) != 0) - 2;
    }
    *(uint32_t *)(puVar4 + 3) = uVar5;
    *(int32_t *)((int64_t)puVar4 + 0x14) = iVar7;
    (*(code *)0x69a60c)(*puVar4, 0xfffffff0);
    (*(code *)0x69a60c)(*puVar4, 0xffffffec, *(undefined4 *)(puVar4 + 3));
    uVar2 = *(undefined4 *)(puVar4 + 3);
    uVar3 = *(undefined4 *)((int64_t)puVar4 + 0x14);
    var_48h._0_4_ = (int32_t)*(float *)(arg1 + 8);
    var_48h._4_4_ = (int32_t)*(float *)(arg1 + 0xc);
    var_40h = (int32_t)(*(float *)(arg1 + 8) + *(float *)(arg1 + 0x10));
    var_3ch = (int32_t)(*(float *)(arg1 + 0xc) + *(float *)(arg1 + 0x14));
    iVar8 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd0);
    }
    if ((*(code **)(iVar8 + 0x38) == (code *)0x0) || (*(char *)(iVar8 + 0x31) == '\0')) {
code_r0x00018016a98d:
        (*(code *)0x69a714)(&var_48h, uVar3, 0, uVar2);
    } else {
        iVar7 = (int32_t)(int64_t)(*(float *)(arg1 + 0x30) * 96.0 + 0.5);
        if (iVar7 == 0) goto code_r0x00018016a98d;
        var_68h._0_4_ = iVar7;
        iVar7 = (**(code **)(iVar8 + 0x38))(&var_48h, uVar3, 0, uVar2);
        if (iVar7 == 0) goto code_r0x00018016a98d;
    }
    var_58h._0_4_ = 0x34;
    if ((uVar6 & 8) != (uVar5 & 8)) {
        var_58h._0_4_ = 0x30;
    }
    var_60h._0_4_ = var_3ch - var_48h._4_4_;
    var_68h._0_4_ = var_40h - (int32_t)var_48h;
    (*(code *)0x69a6ae)(*puVar4, iVar9);
    (*(code *)0x69a62c)(*puVar4, 8);
    *(undefined2 *)(arg1 + 0x71) = 0x101;
code_r0x00018016aa19:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18016aa19
// Address: 0x18016aa19
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.18016a810(int64_t arg1)
{
    uint32_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined8 *puVar4;
    uint32_t uVar5;
    uint32_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_88 [32];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int32_t var_40h;
    int32_t var_3ch;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    iVar9 = *(int64_t *)(arg1 + 0x38);
    puVar4 = *(undefined8 **)(arg1 + 0x50);
    if (iVar9 != 0) {
        iVar9 = *(int64_t *)(iVar9 + 0x60);
    }
    if (iVar9 != puVar4[1]) {
        puVar4[1] = iVar9;
        (*(code *)0x69a4a8)(*puVar4, 0xfffffff8);
    }
    uVar1 = *(uint32_t *)(arg1 + 4);
    iVar7 = -0x80000000;
    if ((uVar1 & 8) == 0) {
        iVar7 = 0xcf0000;
    }
    uVar6 = 0x80;
    if ((uVar1 & 0x10) == 0) {
        uVar6 = 0x40000;
    }
    uVar5 = uVar6 | 8;
    if ((uVar1 & 0x400) == 0) {
        uVar5 = uVar6;
    }
    if ((*(int32_t *)((int64_t)puVar4 + 0x14) == iVar7) && (*(uint32_t *)(puVar4 + 3) == uVar5))
    goto code_r0x00018016aa19;
    uVar6 = *(uint32_t *)(puVar4 + 3);
    iVar9 = 0;
    if ((uVar6 & 8) != (uVar5 & 8)) {
        iVar9 = (uint64_t)((uVar1 & 0x400) != 0) - 2;
    }
    *(uint32_t *)(puVar4 + 3) = uVar5;
    *(int32_t *)((int64_t)puVar4 + 0x14) = iVar7;
    (*(code *)0x69a60c)(*puVar4, 0xfffffff0);
    (*(code *)0x69a60c)(*puVar4, 0xffffffec, *(undefined4 *)(puVar4 + 3));
    uVar2 = *(undefined4 *)(puVar4 + 3);
    uVar3 = *(undefined4 *)((int64_t)puVar4 + 0x14);
    var_48h._0_4_ = (int32_t)*(float *)(arg1 + 8);
    var_48h._4_4_ = (int32_t)*(float *)(arg1 + 0xc);
    var_40h = (int32_t)(*(float *)(arg1 + 8) + *(float *)(arg1 + 0x10));
    var_3ch = (int32_t)(*(float *)(arg1 + 0xc) + *(float *)(arg1 + 0x14));
    iVar8 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar8 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd0);
    }
    if ((*(code **)(iVar8 + 0x38) == (code *)0x0) || (*(char *)(iVar8 + 0x31) == '\0')) {
code_r0x00018016a98d:
        (*(code *)0x69a714)(&var_48h, uVar3, 0, uVar2);
    } else {
        iVar7 = (int32_t)(int64_t)(*(float *)(arg1 + 0x30) * 96.0 + 0.5);
        if (iVar7 == 0) goto code_r0x00018016a98d;
        var_68h._0_4_ = iVar7;
        iVar7 = (**(code **)(iVar8 + 0x38))(&var_48h, uVar3, 0, uVar2);
        if (iVar7 == 0) goto code_r0x00018016a98d;
    }
    var_58h._0_4_ = 0x34;
    if ((uVar6 & 8) != (uVar5 & 8)) {
        var_58h._0_4_ = 0x30;
    }
    var_60h._0_4_ = var_3ch - var_48h._4_4_;
    var_68h._0_4_ = var_40h - (int32_t)var_48h;
    (*(code *)0x69a6ae)(*puVar4, iVar9);
    (*(code *)0x69a62c)(*puVar4, 8);
    *(undefined2 *)(arg1 + 0x71) = 0x101;
code_r0x00018016aa19:
    func_0x000180459870(var_38h ^ (uint64_t)auStack_88);
    return;
}

// ============================================================
// Function: FUN_18016aa30
// Address: 0x18016aa30
// Size: 70 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

int64_t fcn.18016aa30(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    var_8h = 0;
    (*(code *)0x69a42c)(**(undefined8 **)(arg2 + 0x50), &var_8h);
    *(float *)arg1 = (float)(int32_t)var_8h;
    *(float *)(arg1 + 4) = (float)var_8h._4_4_;
    return arg1;
}

// ============================================================
// Function: FUN_18016aa80
// Address: 0x18016aa80
// Size: 298 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.18016aa80(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    undefined4 uVar1;
    undefined8 *puVar2;
    undefined4 uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t var_18h;
    undefined auStack_78 [32];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    var_20h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    puVar2 = *(undefined8 **)(arg1 + 0x50);
    var_30h._0_4_ = (int32_t)(float)arg2;
    var_38h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
    var_30h._4_4_ = (int32_t)var_38h._4_4_;
    var_38h = arg2;
    var_28h._0_4_ = (int32_t)var_30h;
    var_28h._4_4_ = var_30h._4_4_;
    if ((*(uint8_t *)(arg1 + 4) & 4) != 0) {
        uVar3 = (*(code *)0x69a73c)(*puVar2, 0xfffffff0);
        *(undefined4 *)((int64_t)puVar2 + 0x14) = uVar3;
        uVar3 = (*(code *)0x69a73c)(*puVar2, 0xffffffec);
        *(undefined4 *)(puVar2 + 3) = uVar3;
    }
    uVar3 = *(undefined4 *)(puVar2 + 3);
    uVar1 = *(undefined4 *)((int64_t)puVar2 + 0x14);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(int64_t *)0x180781f28 != 0) {
        iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0xd0);
    }
    if ((*(code **)(iVar5 + 0x38) != (code *)0x0) && (*(char *)(iVar5 + 0x31) != '\0')) {
        iVar4 = (int32_t)(int64_t)(*(float *)(arg1 + 0x30) * 96.0 + 0.5);
        if (iVar4 != 0) {
            var_58h._0_4_ = iVar4;
            iVar4 = (**(code **)(iVar5 + 0x38))(&var_30h, uVar1, 0, uVar3);
            if (iVar4 != 0) goto code_r0x00018016ab60;
        }
    }
    (*(code *)0x69a714)(&var_30h, uVar1, 0, uVar3);
code_r0x00018016ab60:
    var_48h._0_4_ = 0x15;
    var_50h._0_4_ = 0;
    var_58h._0_4_ = 0;
    (*(code *)0x69a6ae)(*puVar2, 0, (int32_t)var_30h, var_30h._4_4_);
    func_0x000180459870(var_20h ^ (uint64_t)auStack_78);
    return;
}

