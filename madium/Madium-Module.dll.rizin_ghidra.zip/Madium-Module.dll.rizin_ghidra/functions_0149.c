// Chunk 149 - 50 functions

// ============================================================
// Function: FUN_1801f8ad0
// Address: 0x1801f8ad0
// Size: 427 bytes
// ============================================================
undefined8
fcn.1801f8ad0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    undefined8 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 uVar5;
    undefined8 in_R8;
    int32_t in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f8af0;
    iVar3 = func_0x00018045a350();
    iVar3 = -iVar3;
    if (in_R9D == 1) {
        uVar5 = 0x1804b88d0;
    } else if (in_R9D == 2) {
        uVar5 = 0x1804b88e0;
    } else {
        if (in_R9D != 3) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b16;
            func_0x000180229480();
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b2e;
            func_0x0001802295a0(0x1804b8920, 0x22, 0x1804b8900);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b40;
            func_0x0001802296d0(0x14, 0x8010c, 0);
            return 0;
        }
        uVar5 = 0x1804b88f0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b63;
    iVar4 = func_0x000180211490();
    in_RCX[2] = iVar4;
    if (iVar4 == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b71;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b89;
        func_0x0001802295a0(0x1804b8920, 0x28, 0x1804b8900);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8b9b;
        func_0x0001802296d0(0x14, 0x80006, 0);
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8bae;
    iVar4 = func_0x0001802119f0(in_RDX, uVar5, in_R8);
    in_RCX[3] = iVar4;
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8bbf;
        iVar2 = func_0x00018020efa0(iVar4);
        if (*(int64_t *)((int64_t)&arg_60h + iVar3) == (int64_t)iVar2) {
            uVar5 = in_RCX[3];
            uVar1 = in_RCX[2];
            *(undefined4 *)((int64_t)&var_20h + iVar3) = 1;
            *(undefined8 *)((int64_t)&var_18h + iVar3) = 0;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8bef;
            iVar2 = func_0x000180211b70(uVar1, uVar5, 0, *(undefined8 *)((int64_t)&arg_58h + iVar3));
            if (iVar2 != 0) {
                *in_RCX = in_RDX;
                in_RCX[1] = in_R8;
                *(int32_t *)(in_RCX + 4) = in_R9D;
                return 1;
            }
            uVar5 = 0x35;
            goto code_r0x0001801f8c10;
        }
    }
    uVar5 = 0x2f;
code_r0x0001801f8c10:
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8c15;
    func_0x000180229480();
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8c2a;
    func_0x0001802295a0(0x1804b8920, uVar5, 0x1804b8900);
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8c3c;
    func_0x0001802296d0(0x14, 0x80006, 0);
    uVar5 = in_RCX[2];
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8c45;
    func_0x000180211410(uVar5);
    uVar5 = in_RCX[3];
    in_RCX[2] = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801f8c56;
    func_0x000180211a40(uVar5);
    in_RCX[3] = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801f8c80
// Address: 0x1801f8c80
// Size: 144 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h

void fcn.1801f8c80(int64_t arg_28h, int64_t arg_38h)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_R8;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f8c8c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(uint64_t *)((int64_t)&arg_38h + iVar4) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4);
    if ((in_R8 != 0) && (0xf < *(uint64_t *)(in_R8 + 0x48))) {
        *(int64_t *)((int64_t)&var_18h + iVar4) = (int64_t)&arg_28h + iVar4;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f8cbc;
        iVar3 = fcn.1801f84b0(*(int64_t *)((int64_t)&var_18h + iVar4));
        if (iVar3 != 0) {
            iVar1 = *(int64_t *)(in_R8 + 0x50);
            iVar2 = *(int64_t *)(in_R8 + 0x48);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f8cdf;
            fcn.1802262e0((int64_t)&arg_28h + iVar4, iVar2 + iVar1 + -0x10, 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f8cf5;
            fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4));
            return;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801f8d0a;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_38h + iVar4) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar4));
    return;
}

// ============================================================
// Function: FUN_1801f8d60
// Address: 0x1801f8d60
// Size: 1364 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

undefined8
fcn.1801f8d60(uint8_t **placeholder_0, uint64_t placeholder_1, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
             int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h,
             int64_t arg_60h)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint64_t *puVar3;
    uint8_t **ppuVar4;
    uint32_t *puVar5;
    uint8_t uVar6;
    int32_t iVar7;
    int64_t iVar8;
    uint8_t *puVar9;
    uint8_t *puVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    uint8_t *puVar13;
    uint32_t uVar14;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint8_t *puVar15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_38;
    int64_t var_10h;
    
    uVar12 = (uint32_t)arg3;
    uStack_38 = 0x1801f8d7e;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    puVar3 = *(uint64_t **)((int64_t)&arg_60h + iVar8);
    puVar15 = (uint8_t *)0x0;
    puVar9 = placeholder_0[1];
    *(uint8_t **)((int64_t)&arg_30h + iVar8) = puVar9;
    if (puVar3 != (uint64_t *)0x0) {
        *puVar3 = 1;
    }
    ppuVar4 = *(uint8_t ***)((int64_t)&arg_58h + iVar8);
    if (ppuVar4 != (uint8_t **)0x0) {
        *ppuVar4 = *placeholder_0;
        ppuVar4[1] = (uint8_t *)0x0;
        ppuVar4[2] = (uint8_t *)0x0;
        ppuVar4[3] = (uint8_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_38h + iVar8) = unaff_RSI;
    *(undefined8 *)((int64_t)&var_10h + iVar8) = unaff_RDI;
    if (puVar9 < (uint8_t *)0x7) {
        return 0;
    }
    if (placeholder_0[1] == (uint8_t *)0x0) {
        return 0;
    }
    puVar5 = *(uint32_t **)((int64_t)&arg_50h + iVar8);
    uVar1 = **placeholder_0;
    *placeholder_0 = *placeholder_0 + 1;
    placeholder_0[1] = placeholder_0[1] + -1;
    *puVar5 = ((uVar12 & 1) << 0xe ^ *puVar5 & 0xffffbfff) & 0xffc0ffff;
    uVar14 = (uint32_t)uVar1;
    if ((char)uVar1 < '\0') {
        puVar9 = placeholder_0[1];
        if (puVar9 < (uint8_t *)0x4) {
            return 0;
        }
        puVar13 = *placeholder_0;
        uVar12 = CONCAT31(CONCAT21(CONCAT11(*puVar13, puVar13[1]), puVar13[2]), puVar13[3]);
        placeholder_0[1] = puVar9 + -4;
        *placeholder_0 = puVar13 + 4;
        if ((uVar12 != 0) && ((uVar1 & 0x40) == 0)) {
            return 0;
        }
        if (puVar9 + -4 == (uint8_t *)0x0) {
            return 0;
        }
        uVar6 = puVar13[4];
        *placeholder_0 = puVar13 + 5;
        placeholder_0[1] = puVar9 + -5;
        *(uint8_t *)((int64_t)&arg_60h + iVar8) = uVar6;
        if (0x14 < uVar6) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f8fc4;
        iVar7 = func_0x0001801b4900(placeholder_0, (undefined *)((int64_t)puVar5 + 9), uVar6);
        if (iVar7 == 0) {
            return 0;
        }
        if (placeholder_0[1] == (uint8_t *)0x0) {
            return 0;
        }
        uVar6 = **placeholder_0;
        *placeholder_0 = *placeholder_0 + 1;
        placeholder_0[1] = placeholder_0[1] + -1;
        if (0x14 < uVar6) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f9003;
        iVar7 = func_0x0001801b4900(placeholder_0, (undefined *)((int64_t)puVar5 + 0x1e), uVar6);
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined *)(puVar5 + 2) = *(undefined *)((int64_t)&arg_60h + iVar8);
        puVar5[1] = uVar12;
        *(uint8_t *)((int64_t)puVar5 + 0x1d) = uVar6;
        if (uVar12 == 0) {
            *(undefined *)puVar5 = 6;
            uVar12 = ((uint32_t)uVar1 << 9 ^ *puVar5) & 0x8000 ^ *puVar5;
            *puVar5 = uVar12;
            *(uint8_t **)(puVar5 + 0x14) = *placeholder_0;
            puVar9 = placeholder_0[1];
            *(uint8_t **)(puVar5 + 0x12) = puVar9;
            if (((uint64_t)puVar9 & 3) != 0) {
                return 0;
            }
            *puVar5 = uVar12 & 0xffff80ff;
            *(undefined8 *)(puVar5 + 0xe) = 0;
            *(undefined8 *)(puVar5 + 0x10) = 0;
            *(undefined4 *)((int64_t)puVar5 + 0x32) = 0;
            puVar9 = *(uint8_t **)(puVar5 + 0x12);
            puVar15 = (uint8_t *)0x0;
            goto code_r0x0001801f8f29;
        }
        if (uVar12 != 1) {
            if (puVar3 == (uint64_t *)0x0) {
                return 0;
            }
            *puVar3 = *puVar3 | 2;
            return 0;
        }
        if (*(uint64_t *)((int64_t)&arg_30h + iVar8) < 0x15) {
            return 0;
        }
        uVar6 = uVar1 >> 4 & 3;
        if ((uVar1 >> 4 & 3) == 0) {
            *(undefined *)puVar5 = 1;
        } else if (uVar6 == 1) {
            *(undefined *)puVar5 = 2;
        } else if (uVar6 == 2) {
            *(undefined *)puVar5 = 3;
        } else if (uVar6 == 3) {
            *(undefined *)puVar5 = 4;
        }
        uVar12 = *puVar5;
        *puVar5 = uVar12 & 0xffffc0ff | 0x8000;
        if ((char)(uVar12 & 0xffffc0ff) == '\x01') {
            if (placeholder_0[1] == (uint8_t *)0x0) {
                return 0;
            }
            puVar9 = *placeholder_0;
            puVar13 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar9 >> 6));
            if (placeholder_0[1] < puVar13) {
                return 0;
            }
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f90f5;
            puVar10 = (uint8_t *)func_0x000180274e70(puVar9);
            puVar9 = placeholder_0[1];
            *placeholder_0 = *placeholder_0 + (int64_t)puVar13;
            placeholder_0[1] = puVar9 + -(int64_t)puVar13;
            if (puVar9 + -(int64_t)puVar13 < puVar10) {
                return 0;
            }
            *(uint8_t **)(puVar5 + 0xe) = *placeholder_0;
            *placeholder_0 = *placeholder_0 + (int64_t)puVar10;
            placeholder_0[1] = placeholder_0[1] + -(int64_t)puVar10;
            *(uint8_t **)(puVar5 + 0x10) = puVar10;
            if (puVar10 == (uint8_t *)0x0) goto code_r0x0001801f9129;
        } else {
            *(undefined8 *)(puVar5 + 0x10) = 0;
code_r0x0001801f9129:
            *(undefined8 *)(puVar5 + 0xe) = 0;
        }
        uVar12 = *puVar5;
        if ((char)uVar12 == '\x04') {
            *(uint8_t **)(puVar5 + 0x14) = *placeholder_0;
            *(uint8_t **)(puVar5 + 0x12) = placeholder_0[1];
            *puVar5 = ((uint32_t)uVar1 << 0x10 ^ uVar12 & 0xffffbfff) & 0xf0000 ^ uVar12 & 0xffffbfff;
            *(undefined4 *)((int64_t)puVar5 + 0x32) = 0;
            puVar9 = *(uint8_t **)(puVar5 + 0x12);
            goto code_r0x0001801f8f29;
        }
        iVar7 = *(int32_t *)((int64_t)&arg_40h + iVar8);
        uVar12 = uVar12 & 0xffffc3ff;
        if (iVar7 == 0) {
            uVar12 = uVar12 | ((uVar14 & 3) + 1) * 0x400;
            uVar14 = (uint32_t)(uVar1 >> 2);
        } else {
            uVar14 = 0;
        }
        *puVar5 = (uVar14 << 0x14 ^ uVar12) & 0x300000 ^ uVar12;
        if (placeholder_0[1] == (uint8_t *)0x0) {
            return 0;
        }
        puVar9 = *placeholder_0;
        puVar13 = (uint8_t *)(uint64_t)(uint32_t)(1 << (*puVar9 >> 6));
        if (placeholder_0[1] < puVar13) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f91c5;
        puVar10 = (uint8_t *)func_0x000180274e70(puVar9);
        *placeholder_0 = *placeholder_0 + (int64_t)puVar13;
        puVar9 = placeholder_0[1];
        puVar15 = *placeholder_0;
        placeholder_0[1] = puVar9 + -(int64_t)puVar13;
        if (puVar10 < (uint8_t *)0x4) {
            return 0;
        }
        iVar2 = *(int32_t *)((int64_t)&arg_48h + iVar8);
        if ((iVar2 == 0) && (puVar9 + -(int64_t)puVar13 < puVar10)) {
            return 0;
        }
        *(undefined4 *)((int64_t)puVar5 + 0x32) = 0;
        if (iVar7 == 0) {
            uVar12 = *puVar5;
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f9234;
            iVar7 = func_0x0001801b4900(placeholder_0, (undefined4 *)((int64_t)puVar5 + 0x32), uVar12 >> 10 & 0xf);
            if (iVar7 == 0) {
                return 0;
            }
            puVar10 = puVar10 + -(uint64_t)(*puVar5 >> 10 & 0xf);
        } else {
            if (placeholder_0[1] < (uint8_t *)0x4) {
                return 0;
            }
            *placeholder_0 = *placeholder_0 + 4;
            placeholder_0[1] = placeholder_0[1] + -4;
            puVar10 = puVar10 + -4;
        }
        *(uint8_t **)(puVar5 + 0x12) = puVar10;
        if (iVar2 != 0) {
            *(undefined8 *)(puVar5 + 0x14) = 0;
            goto code_r0x0001801f9276;
        }
        *(uint8_t **)(puVar5 + 0x14) = *placeholder_0;
        if (placeholder_0[1] < puVar10) {
            return 0;
        }
        *placeholder_0 = *placeholder_0 + (int64_t)puVar10;
        puVar9 = placeholder_0[1] + -(int64_t)puVar10;
    } else {
        if (0x14 < placeholder_1) {
            return 0;
        }
        if ((uVar1 & 0x40) == 0) {
            return 0;
        }
        if (puVar9 < (uint8_t *)0x15) {
            return 0;
        }
        *(undefined *)puVar5 = 5;
        uVar11 = ((uint32_t)uVar1 * 8 ^ (*puVar5 | 0x8000)) & 0x100 ^ (*puVar5 | 0x8000);
        if (uVar12 == 0) {
            uVar11 = ((uVar14 & 4) << 7 ^ uVar11 & 0xfffffdff) & 0xffffc3ff | ((uVar14 & 3) + 1) * 0x400;
            uVar11 = (uVar14 << 0x11 ^ uVar11) & 0x300000 ^ uVar11;
        } else {
            uVar11 = uVar11 & 0xffcfc1ff;
        }
        *puVar5 = uVar11;
        *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f8eb3;
        iVar7 = func_0x0001801b4900(placeholder_0, (undefined *)((int64_t)puVar5 + 9), placeholder_1);
        if (iVar7 == 0) {
            return 0;
        }
        *(char *)(puVar5 + 2) = (char)placeholder_1;
        *(undefined4 *)((int64_t)puVar5 + 0x32) = 0;
        puVar15 = *placeholder_0;
        if (uVar12 == 0) {
            uVar12 = *puVar5;
            *(undefined8 *)((int64_t)&uStack_38 + iVar8) = 0x1801f8f02;
            iVar7 = func_0x0001801b4900(placeholder_0, (undefined *)((int64_t)puVar5 + 0x32), uVar12 >> 10 & 0xf);
            if (iVar7 == 0) {
                return 0;
            }
        } else {
            if (placeholder_0[1] < (uint8_t *)0x4) {
                return 0;
            }
            *placeholder_0 = puVar15 + 4;
            placeholder_0[1] = placeholder_0[1] + -4;
        }
        puVar5[1] = 0;
        *(undefined *)((int64_t)puVar5 + 0x1d) = 0;
        *(undefined8 *)(puVar5 + 0xe) = 0;
        *(undefined8 *)(puVar5 + 0x10) = 0;
        puVar9 = placeholder_0[1];
        *(uint8_t **)(puVar5 + 0x12) = puVar9;
        *(uint8_t **)(puVar5 + 0x14) = *placeholder_0;
code_r0x0001801f8f29:
        if (placeholder_0[1] < puVar9) {
            return 0;
        }
        *placeholder_0 = *placeholder_0 + (int64_t)puVar9;
        puVar9 = placeholder_0[1] + -(int64_t)puVar9;
    }
    placeholder_0[1] = puVar9;
code_r0x0001801f9276:
    if ((ppuVar4 != (uint8_t **)0x0) && (ppuVar4[3] = puVar15, puVar15 != (uint8_t *)0x0)) {
        ppuVar4[1] = puVar15 + 4;
        ppuVar4[2] = *placeholder_0 + (int64_t)(placeholder_0[1] + (-4 - (int64_t)puVar15));
    }
    if (puVar3 != (uint64_t *)0x0) {
        *puVar3 = *puVar3 & 0xfffffffffffffffe;
    }
    return 1;
}

// ============================================================
// Function: FUN_1801f93b0
// Address: 0x1801f93b0
// Size: 950 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined8 fcn.1801f93b0(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h)
{
    undefined uVar1;
    uint32_t uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    uint8_t uVar6;
    int32_t iVar7;
    uint32_t uVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    int64_t in_RCX;
    int64_t iVar12;
    uint8_t uVar13;
    uint64_t in_RDX;
    uint32_t *in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f93d0;
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f93e4;
    iVar10 = func_0x000180244270();
    *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f93f4;
    iVar7 = func_0x0001802442e0(in_RCX, (int64_t)&var_20h + iVar9);
    if (iVar7 == 0) {
        return 0;
    }
    if (in_R9 != (int64_t *)0x0) {
        if (*(int64_t *)(in_RCX + 8) == 0) {
            return 0;
        }
        *in_R9 = 0;
        in_R9[1] = 0;
        in_R9[2] = 0;
        in_R9[3] = 0;
    }
    uVar2 = *in_R8;
    if ((uVar2 >> 0xe & 1) != 0) {
        return 0;
    }
    if ((uVar2 & 0xff) == 5) {
        if (*(uint8_t *)(in_R8 + 2) != in_RDX) {
            return 0;
        }
        if (0x14 < in_RDX) {
            return 0;
        }
        if (3 < (uVar2 >> 10 & 0xf) - 1) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f94c0;
        iVar7 = func_0x0001802446f0(in_RCX, ((((uint64_t)(uVar2 & 0x100) | 0x200) >> 6 | (uint64_t)(uVar2 >> 0x14 & 3))
                                             * 2 | (uint64_t)(uVar2 >> 9 & 1)) << 2 |
                                            (uint64_t)((uVar2 >> 10 & 0xf) - 1 & 0xbf), 1);
        if (iVar7 == 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f94d7;
        iVar7 = func_0x0001802445f0(in_RCX, (int64_t)in_R8 + 9, in_RDX);
code_r0x0001801f96b2:
        if (iVar7 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f96c7;
            iVar7 = func_0x0001802442e0(in_RCX, (int64_t)&var_18h + iVar9);
            if (iVar7 != 0) {
                uVar2 = *in_R8;
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f96e2;
                iVar7 = func_0x0001802445f0(in_RCX, (int64_t)in_R8 + 0x32, uVar2 >> 10 & 0xf);
                if (iVar7 != 0) {
                    iVar5 = *(int64_t *)(in_R8 + 0x12);
                    if (iVar5 != 0) {
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f96fa;
                        iVar7 = func_0x000180244860(in_RCX, iVar5, 0);
                        if (iVar7 == 0) {
                            return 0;
                        }
                    }
                    if (in_R9 != (int64_t *)0x0) {
                        iVar5 = *(int64_t *)((int64_t)&var_18h + iVar9);
                        iVar11 = *(int64_t *)((int64_t)&var_20h + iVar9);
                        *in_R9 = iVar10;
                        iVar12 = (iVar5 - iVar11) + 4 + iVar10;
                        in_R9[1] = iVar12;
                        iVar5 = *(int64_t *)(in_R8 + 0x12);
                        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f972a;
                        iVar11 = func_0x000180244270(in_RCX);
                        in_R9[2] = iVar11 + (iVar5 - iVar12);
                        in_R9[3] = (*(int64_t *)((int64_t)&var_18h + iVar9) - *(int64_t *)((int64_t)&var_20h + iVar9)) +
                                   iVar10;
                    }
                    return 1;
                }
            }
        }
    } else {
        if (0x14 < *(uint8_t *)(in_R8 + 2)) {
            return 0;
        }
        if (0x14 < *(uint8_t *)((int64_t)in_R8 + 0x1d)) {
            return 0;
        }
        if ((((uVar2 & 0xff) - 4 & 0xfffffffd) != 0) && (0xc00 < (uVar2 & 0x3c00) - 0x400)) {
            return 0;
        }
        uVar2 = *in_R8;
        uVar8 = uVar2 & 0xff;
        if (uVar8 == 1) {
            uVar13 = 0x80;
code_r0x0001801f955a:
            uVar13 = uVar13 | 0x40;
        } else {
            if (uVar8 == 2) {
                uVar13 = 0x90;
                goto code_r0x0001801f955a;
            }
            if (uVar8 == 3) {
                uVar13 = 0xa0;
                goto code_r0x0001801f955a;
            }
            if (uVar8 == 4) {
                uVar13 = 0xb0;
                goto code_r0x0001801f955a;
            }
            if (uVar8 != 6) {
                return 0;
            }
            if (in_R8[1] != 0) {
                return 0;
            }
            uVar13 = 0x80;
            if ((uVar2 >> 0xf & 1) != 0) goto code_r0x0001801f955a;
        }
        if (((uVar2 & 0xff) == 4) || ((uVar2 & 0xff) == 6)) {
            if ((char)uVar2 == '\x04') {
                uVar6 = (uint8_t)(uVar2 >> 0x10) & 0xf;
                goto code_r0x0001801f958c;
            }
        } else {
            uVar6 = ((uint8_t)(uVar2 >> 0x14) & 3) << 2 | ((uint8_t)(uVar2 >> 10) & 0xf) - 1;
code_r0x0001801f958c:
            uVar13 = uVar13 | uVar6;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f959f;
        iVar7 = func_0x0001802446f0(in_RCX, uVar13, 1);
        if (iVar7 == 0) {
            return 0;
        }
        uVar2 = in_R8[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f95b8;
        iVar7 = func_0x0001802446f0(in_RCX, uVar2, 4);
        if (iVar7 == 0) {
            return 0;
        }
        uVar1 = *(undefined *)(in_R8 + 2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f95d2;
        iVar7 = func_0x0001802446f0(in_RCX, uVar1, 1);
        if (iVar7 == 0) {
            return 0;
        }
        uVar1 = *(undefined *)(in_R8 + 2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f95eb;
        iVar7 = func_0x0001802445f0(in_RCX, (int64_t)in_R8 + 9, uVar1);
        if (iVar7 == 0) {
            return 0;
        }
        uVar1 = *(undefined *)((int64_t)in_R8 + 0x1d);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f9605;
        iVar7 = func_0x0001802446f0(in_RCX, uVar1, 1);
        if (iVar7 == 0) {
            return 0;
        }
        uVar1 = *(undefined *)((int64_t)in_R8 + 0x1d);
        *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f961e;
        iVar7 = func_0x0001802445f0(in_RCX, (int64_t)in_R8 + 0x1e, uVar1);
        if (iVar7 == 0) {
            return 0;
        }
        if ((*in_R8 & 0xff) == 6) {
            iVar10 = *(int64_t *)(in_R8 + 0x12);
            if (iVar10 == 0) {
                return 1;
            }
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f9644;
            iVar7 = func_0x000180244860(in_RCX, iVar10, 0);
        } else {
            if ((*in_R8 & 0xff) == 1) {
                uVar3 = *(undefined8 *)(in_R8 + 0x10);
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f9657;
                iVar7 = func_0x0001802447a0(in_RCX, uVar3);
                if (iVar7 == 0) {
                    return 0;
                }
                uVar3 = *(undefined8 *)(in_R8 + 0x10);
                uVar4 = *(undefined8 *)(in_R8 + 0xe);
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f966f;
                iVar7 = func_0x0001802445f0(in_RCX, uVar4, uVar3);
                if (iVar7 == 0) {
                    return 0;
                }
            }
            uVar2 = *in_R8;
            if ((char)uVar2 != '\x04') {
                iVar5 = *(int64_t *)(in_R8 + 0x12);
                *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f96b2;
                iVar7 = func_0x0001802447a0(in_RCX, (uint64_t)(uVar2 >> 10 & 0xf) + iVar5);
                goto code_r0x0001801f96b2;
            }
            uVar3 = *(undefined8 *)(in_R8 + 0x10);
            uVar4 = *(undefined8 *)(in_R8 + 0xe);
            *(undefined8 *)((int64_t)&uStack_10 + iVar9) = 0x1801f9690;
            iVar7 = func_0x0001802445f0(in_RCX, uVar4, uVar3);
        }
        if (iVar7 != 0) {
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f97e0
// Address: 0x1801f97e0
// Size: 280 bytes
// ============================================================
int64_t fcn.1801f97e0(uint64_t param_1, uint32_t *param_2)
{
    uint8_t uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f97ec;
    iVar3 = fcn.18045a350();
    uVar2 = *param_2;
    if ((uVar2 >> 0xe & 1) == 0) {
        uVar1 = *(uint8_t *)(param_2 + 2);
        if ((uVar2 & 0xff) == 5) {
            if (uVar1 != param_1) {
                return 0;
            }
            if (0x14 < param_1) {
                return 0;
            }
            if (0xc00 < (uVar2 & 0x3c00) - 0x400) {
                return 0;
            }
            return param_1 + 1 + (uint64_t)(uVar2 >> 10 & 0xf);
        }
        if (0x14 < uVar1) {
            return 0;
        }
        if (0x14 < *(uint8_t *)((int64_t)param_2 + 0x1d)) {
            return 0;
        }
        iVar6 = (uint64_t)uVar1 + 7 + (uint64_t)*(uint8_t *)((int64_t)param_2 + 0x1d);
        if (((uVar2 & 0xff) - 4 & 0xfffffffd) != 0) {
            if (0xc00 < (uVar2 & 0x3c00) - 0x400) {
                return 0;
            }
            iVar6 = iVar6 + (uint64_t)(uVar2 >> 10 & 0xf);
        }
        uVar2 = *param_2;
        if ((char)uVar2 == '\x01') {
            iVar5 = *(int64_t *)(param_2 + 0x10);
            *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801f98ae;
            iVar4 = fcn.1801f8d10(iVar5);
            if (iVar4 == 0) {
                return 0;
            }
            iVar6 = iVar5 + iVar4 + iVar6;
        } else {
            if ((uVar2 & 0xff) == 4) {
                return iVar6;
            }
            if ((uVar2 & 0xff) == 6) {
                return iVar6;
            }
        }
        iVar5 = *(int64_t *)(param_2 + 0x12);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801f98df;
        iVar3 = fcn.1801f8d10((uint64_t)(uVar2 >> 10 & 0xf) + iVar5);
        if (iVar3 != 0) {
            return iVar6 + iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f9900
// Address: 0x1801f9900
// Size: 156 bytes
// ============================================================
undefined8 fcn.1801f9900(uint8_t *param_1, uint64_t param_2, uint64_t param_3, uint8_t *param_4)
{
    uint8_t uVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801f990a;
    iVar2 = fcn.18045a350();
    if ((6 < param_2) && (param_3 < 0x15)) {
        uVar1 = *param_1;
        if ((char)uVar1 < '\0') {
            if (((((param_1[1] == 0) && (param_1[2] == 0)) && (param_1[3] == 0)) && (param_1[4] == 0)) ||
               ((uVar1 & 0x40) != 0)) {
                uVar1 = param_1[5];
                if ((uVar1 < 0x15) && ((uint64_t)uVar1 + 7 <= param_2)) {
                    *param_4 = uVar1;
                    *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x1801f9964;
                    func_0x000180498030(param_4 + 1, param_1 + 6, uVar1);
                    return 1;
                }
            }
        } else if (((uVar1 & 0x40) != 0) && (param_3 + 0x15 <= param_2)) {
            *param_4 = (uint8_t)param_3;
            *(undefined8 *)((int64_t)&uStack_8 + -iVar2) = 0x1801f998b;
            func_0x000180498030(param_4 + 1, param_1 + 1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f99a0
// Address: 0x1801f99a0
// Size: 116 bytes
// ============================================================
undefined8 fcn.1801f99a0(undefined8 param_1, uint64_t param_2, undefined *param_3)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801f99ac;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (param_2 < 0x15) {
        *param_3 = (char)param_2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f99ca;
        iVar1 = fcn.18021b9c0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                              *(int64_t *)(&stack0x00000040 + iVar2), *(int64_t *)(&stack0x00000048 + iVar2), 
                              *(int64_t *)(&stack0x00000050 + iVar2));
        if (iVar1 == 1) {
            return 1;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f99d4;
        fcn.180229480(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f99ec;
        fcn.1802295a0(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000028 + iVar2), *(int64_t *)(&stack0x00000030 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801f99fe;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar2));
        *param_3 = 0;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801f9c30
// Address: 0x1801f9c30
// Size: 1081 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_44h because it doesn't fit into ProtoModel

void fcn.1801f9c30(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    undefined uVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined4 uVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined4 *puVar10;
    undefined8 in_RCX;
    undefined8 in_RDX;
    undefined *in_R8;
    int32_t in_R9D;
    int64_t iVar11;
    undefined8 uVar12;
    int64_t *piVar13;
    int64_t *piVar14;
    undefined4 extraout_XMM0_Da;
    int64_t var_8h;
    undefined8 uStackX_10;
    undefined4 auStackX_18 [2];
    int64_t var_20h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_1e8h;
    undefined4 uStack_1e0;
    undefined4 uStack_1dc;
    int64_t var_1d8h;
    undefined4 uStack_1d0;
    undefined4 uStack_1cc;
    int64_t var_1c8h;
    int64_t var_1c0h;
    undefined4 uStack_1b8;
    undefined4 uStack_1b4;
    int64_t var_1b0h;
    undefined4 uStack_1a8;
    undefined4 uStack_1a4;
    int64_t var_1a0h;
    int64_t var_198h;
    undefined4 uStack_190;
    undefined4 uStack_18c;
    int64_t var_188h;
    undefined4 uStack_180;
    undefined4 uStack_17c;
    int64_t var_178h;
    int64_t var_170h;
    undefined4 uStack_168;
    undefined4 uStack_164;
    int64_t var_160h;
    undefined4 uStack_158;
    undefined4 uStack_154;
    int64_t var_150h;
    int64_t var_148h;
    undefined4 uStack_140;
    undefined4 uStack_13c;
    int64_t var_138h;
    undefined4 uStack_130;
    undefined4 uStack_12c;
    int64_t var_128h;
    int64_t var_120h;
    undefined4 uStack_118;
    undefined4 uStack_114;
    int64_t var_110h;
    undefined4 uStack_108;
    undefined4 uStack_104;
    int64_t var_100h;
    int64_t var_a8h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_48h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x1801f9c52;
    iVar6 = fcn.18045a350();
    iVar3 = arg_30h;
    iVar2 = arg_28h;
    iVar6 = -iVar6;
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6);
    *(undefined8 *)((int64_t)&arg_38h + iVar6) = in_RDX;
    if ((arg_28h == 0) && (arg_30h == 0)) goto code_r0x0001801f9f3b;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9ca0;
    iVar7 = func_0x000180215540(extraout_XMM0_Da, 0x1804ad37c, in_RDX);
    if (iVar7 == 0) goto code_r0x0001801f9f3b;
    *(undefined4 *)((int64_t)&arg_40h + iVar6 + 4) = 1;
    piVar14 = &var_a8h;
    if (in_R9D != 0) {
        piVar14 = &var_88h;
    }
    piVar13 = &var_88h;
    if (in_R9D != 0) {
        piVar13 = &var_a8h;
    }
    uVar1 = *in_R8;
    iVar9 = 0;
    *(undefined4 *)((int64_t)&arg_28h + iVar6) = 0;
    iVar11 = 0;
    *(undefined8 *)((int64_t)&arg_30h + iVar6) = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar6) = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9d00;
    iVar8 = func_0x00018020f750(iVar7);
    if (iVar8 != 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9d21;
        iVar11 = func_0x00018025f200(in_RCX, 0x1804b8aac, *(undefined8 *)((int64_t)&arg_38h + iVar6));
        if (iVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9d35;
            iVar9 = func_0x00018025f910(iVar11);
            *(int64_t *)((int64_t)&arg_30h + iVar6) = iVar9;
            if (iVar9 == 0) goto code_r0x0001801f9e90;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9d58;
            puVar10 = (undefined4 *)func_0x000180229bc0(&var_210h, 0x1804b8ab8, (int64_t)&arg_40h + iVar6);
            var_1e8h._0_4_ = *puVar10;
            var_1e8h._4_4_ = puVar10[1];
            uStack_1e0 = puVar10[2];
            uStack_1dc = puVar10[3];
            var_1d8h._0_4_ = puVar10[4];
            var_1d8h._4_4_ = puVar10[5];
            uStack_1d0 = puVar10[6];
            uStack_1cc = puVar10[7];
            var_1c8h = *(int64_t *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9d86;
            puVar10 = (undefined4 *)func_0x000180229bc0(&var_210h, 0x1804a95d0, (int64_t)&arg_40h + iVar6 + 4);
            var_1c0h._0_4_ = *puVar10;
            var_1c0h._4_4_ = puVar10[1];
            uStack_1b8 = puVar10[2];
            uStack_1b4 = puVar10[3];
            var_1b0h._0_4_ = puVar10[4];
            var_1b0h._4_4_ = puVar10[5];
            uStack_1a8 = puVar10[6];
            uStack_1a4 = puVar10[7];
            var_1a0h = *(int64_t *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9db6;
            puVar10 = (undefined4 *)func_0x000180229e30(&var_210h, 0x1804af254, iVar8, 0);
            var_198h._0_4_ = *puVar10;
            var_198h._4_4_ = puVar10[1];
            uStack_190 = puVar10[2];
            uStack_18c = puVar10[3];
            var_188h._0_4_ = puVar10[4];
            var_188h._4_4_ = puVar10[5];
            uStack_180 = puVar10[6];
            uStack_17c = puVar10[7];
            var_178h = *(int64_t *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9dec;
            puVar10 = (undefined4 *)func_0x000180229c70(&var_210h, 0x1804afa00, 0x1804b89d8, 0x14);
            var_170h._0_4_ = *puVar10;
            var_170h._4_4_ = puVar10[1];
            uStack_168 = puVar10[2];
            uStack_164 = puVar10[3];
            var_160h._0_4_ = puVar10[4];
            var_160h._4_4_ = puVar10[5];
            uStack_158 = puVar10[6];
            uStack_154 = puVar10[7];
            var_150h = *(int64_t *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9e20;
            puVar10 = (undefined4 *)func_0x000180229c70(&var_210h, 0x1804af9b0, in_R8 + 1, uVar1);
            var_148h._0_4_ = *puVar10;
            var_148h._4_4_ = puVar10[1];
            uStack_140 = puVar10[2];
            uStack_13c = puVar10[3];
            var_138h._0_4_ = puVar10[4];
            var_138h._4_4_ = puVar10[5];
            uStack_130 = puVar10[6];
            uStack_12c = puVar10[7];
            var_128h = *(int64_t *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9e45;
            puVar10 = (undefined4 *)func_0x000180229ba0(&var_210h);
            var_120h._0_4_ = *puVar10;
            var_120h._4_4_ = puVar10[1];
            uStack_118 = puVar10[2];
            uStack_114 = puVar10[3];
            var_110h._0_4_ = puVar10[4];
            var_110h._4_4_ = puVar10[5];
            uStack_108 = puVar10[6];
            uStack_104 = puVar10[7];
            var_100h = *(int64_t *)(puVar10 + 8);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9e82;
            uVar4 = func_0x00018025fa30(*(undefined8 *)((int64_t)&arg_30h + iVar6), &var_68h, 0x20, &var_1e8h);
            *(undefined4 *)((int64_t)&arg_28h + iVar6) = uVar4;
        }
        iVar9 = *(int64_t *)((int64_t)&arg_30h + iVar6);
    }
code_r0x0001801f9e90:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9e98;
    func_0x00018025f7a0(iVar9);
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9ea0;
    func_0x00018025f250(iVar11);
    if (*(int32_t *)((int64_t)&arg_28h + iVar6) != 0) {
        if (((iVar3 == 0) || (piVar14 != &var_a8h)) && ((iVar2 == 0 || (piVar13 != &var_a8h)))) {
            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar6);
        } else {
            uVar12 = *(undefined8 *)((int64_t)&arg_38h + iVar6);
            *(undefined4 *)((int64_t)auStackX_18 + iVar6) = 1;
            *(undefined8 *)((int64_t)&uStackX_10 + iVar6) = 0x20;
            *(int64_t **)((int64_t)&uStackX_10 + iVar6 + -8) = &var_a8h;
            *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 9;
            *(undefined8 *)((int64_t)&var_18h + iVar6) = 0x1804b89b8;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9f2d;
            iVar5 = func_0x0001801b4180(in_RCX, uVar12, iVar7, &var_68h);
            if (iVar5 == 0) goto code_r0x0001801f9f31;
        }
        if ((iVar3 == 0) || (piVar14 != &var_88h)) {
            if (iVar2 != 0) {
                if (piVar13 == &var_88h) goto code_r0x0001801f9f90;
                goto code_r0x0001801f9ff0;
            }
code_r0x0001801fa031:
            if (iVar3 == 0) goto code_r0x0001801f9f3b;
code_r0x0001801fa036:
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 0x20;
            *(int64_t **)((int64_t)&var_18h + iVar6) = piVar14;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fa057;
            iVar5 = func_0x0001801fb890(iVar3, 0, 1, iVar7);
            if (iVar5 != 0) goto code_r0x0001801f9f3b;
        } else {
code_r0x0001801f9f90:
            *(undefined4 *)((int64_t)auStackX_18 + iVar6) = 1;
            *(undefined8 *)((int64_t)&uStackX_10 + iVar6) = 0x20;
            *(int64_t **)((int64_t)&uStackX_10 + iVar6 + -8) = &var_88h;
            *(undefined8 *)(&stack0x00000000 + iVar6) = 0;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = 0;
            *(undefined8 *)((int64_t)&var_10h + iVar6) = 9;
            *(undefined8 *)((int64_t)&var_18h + iVar6) = 0x1804b89c8;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9fe3;
            iVar5 = func_0x0001801b4180(in_RCX, uVar12, iVar7, &var_68h);
            if (iVar5 != 0) {
                if (iVar2 == 0) goto code_r0x0001801fa031;
code_r0x0001801f9ff0:
                *(undefined8 *)((int64_t)&var_10h + iVar6) = 0x20;
                *(int64_t **)((int64_t)&var_18h + iVar6) = piVar13;
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fa011;
                iVar5 = func_0x000180205530(iVar2, 0, 1, iVar7);
                if (iVar5 != 0) {
                    if (iVar3 == 0) goto code_r0x0001801f9f3b;
                    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fa026;
                    iVar5 = func_0x000180215670(iVar7);
                    if (iVar5 != 0) goto code_r0x0001801fa036;
                    iVar7 = 0;
                }
            }
        }
    }
code_r0x0001801f9f31:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9f39;
    func_0x000180215590(iVar7);
code_r0x0001801f9f3b:
    *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801f9f4a;
    fcn.180459870(var_48h ^ (uint64_t)(&stack0xffffffffffffffc8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801fa070
// Address: 0x1801fa070
// Size: 22 bytes
// ============================================================
void fcn.1801fa070(int64_t arg_48h, int64_t arg_50h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStackX_20;
    
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar1) = 0x1802450ca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(uint64_t *)((int64_t)&arg_60h + iVar2 + iVar1) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802450e7;
    (*(code *)0x69a176)((int64_t)&arg_50h + iVar2 + iVar1);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x1802450f7;
    (*(code *)0x69a186)((int64_t)&arg_50h + iVar2 + iVar1, (int64_t)&arg_48h + iVar2 + iVar1);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar2 + iVar1) = 0x180245117;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_60h + iVar2 + iVar1) ^ (uint64_t)(&stack0x00000028 + iVar2 + iVar1));
    return;
}

// ============================================================
// Function: FUN_1801fa090
// Address: 0x1801fa090
// Size: 48 bytes
// ============================================================
void fcn.1801fa090(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa09c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    param_1 = param_1 + 0x98;
    if (param_2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801fa0b3;
        func_0x00018020c990(param_1);
    }
    *(undefined8 *)((int64_t)auStackX_10 + iVar1 + 8) = *(undefined8 *)((int64_t)auStackX_10 + iVar1 + 8);
    *(undefined8 *)((int64_t)auStackX_10 + iVar1) = 0x18020c78c;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)auStackX_10 + (iVar1 - iVar2)) = 0x18020c79f;
    func_0x00018020bbc0();
    *(undefined *)(param_1 + 6) = 1;
    return;
}

// ============================================================
// Function: FUN_1801fa0c0
// Address: 0x1801fa0c0
// Size: 29 bytes
// ============================================================
void fcn.1801fa0c0(int64_t arg_58h, int64_t arg_78h)
{
    uint8_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint8_t uVar8;
    int64_t in_RCX;
    uint8_t *puVar9;
    uint32_t uVar10;
    int64_t iVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint8_t uVar12;
    uint64_t uVar13;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar9 = (uint8_t *)(in_RCX + 0x98);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18020c7ba;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar13 = 0x5d;
    uVar10 = 1;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000040 + iVar7 + iVar5) = 0x18020bcd0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = puVar9[0x10];
    if (puVar9[4] != 0) {
        return;
    }
    uVar12 = puVar9[5];
    iVar2 = *(int64_t *)(puVar9 + 0x48);
    puVar9[0x10] = 0;
    if (uVar12 == 0) {
        if (iVar2 != 0) {
            uVar8 = 7;
            iVar11 = iVar2 + -1;
            goto code_r0x00018020bd1e;
        }
        uVar3 = 0xffffffff;
    } else {
        uVar8 = uVar12 - 1;
        iVar11 = iVar2;
code_r0x00018020bd1e:
        uVar3 = (uint32_t)(((uint8_t)(1 << (uVar8 & 0x1f)) & *(uint8_t *)(iVar11 + *(int64_t *)(puVar9 + 8))) != 0);
    }
    if (((uVar3 == uVar10) && ((uVar10 != 0 || (puVar9[6] != 1)))) && ((iVar2 != 0 || (uVar12 != 0)))) {
        if (uVar12 == 0) {
            uVar12 = 7;
            *(int64_t *)(puVar9 + 0x48) = iVar2 + -1;
        } else {
            uVar12 = uVar12 - 1;
        }
        puVar9[5] = uVar12;
        if (uVar1 == 0) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bd83;
            func_0x00018020be10(puVar9);
        }
        *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bd8f;
        func_0x00018020c1a0(puVar9, uVar13 & 0xff);
        if ((puVar9[5] != 0) || (*(int64_t *)(puVar9 + 0x48) != 0)) {
            puVar9[6] = 2;
            return;
        }
        puVar9[6] = 2;
        if ((*puVar9 & 1) == 0) {
            return;
        }
        if (puVar9[4] != 0) {
            return;
        }
        if (puVar9[0x10] != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bdb9;
            func_0x00018020be10(puVar9);
        }
        if (*(int64_t *)(puVar9 + 0x38) == *(int64_t *)(puVar9 + 0x40)) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bdce;
            iVar4 = func_0x00018020cd80(puVar9 + 0x28, 0);
            if (iVar4 == 0) goto code_r0x00018020bdfc;
        }
        *(undefined *)(*(int64_t *)(puVar9 + 0x30) + *(int64_t *)(puVar9 + 0x40)) = 10;
        *(int64_t *)(puVar9 + 0x40) = *(int64_t *)(puVar9 + 0x40) + 1;
        return;
    }
code_r0x00018020bdfc:
    puVar9[4] = 1;
    return;
}

// ============================================================
// Function: FUN_1801fa0e0
// Address: 0x1801fa0e0
// Size: 79 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018020cb63: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018020cb68)
// WARNING: Removing unreachable block (ram,0x00018020cb71)
// WARNING: Removing unreachable block (ram,0x00018020cb90)
// WARNING: Removing unreachable block (ram,0x00018020cba1)
// WARNING: Removing unreachable block (ram,0x00018020cba5)
// WARNING: Removing unreachable block (ram,0x00018020cbae)
// WARNING: Removing unreachable block (ram,0x00018020cbb4)
// WARNING: Removing unreachable block (ram,0x00018020cbbc)
// WARNING: Removing unreachable block (ram,0x00018020cbc6)
// WARNING: Removing unreachable block (ram,0x00018020cbdb)
// WARNING: Removing unreachable block (ram,0x00018020cbd5)
// WARNING: Removing unreachable block (ram,0x00018020cbeb)
// WARNING: Removing unreachable block (ram,0x00018020cbf6)
// WARNING: Removing unreachable block (ram,0x00018020cbfa)
// WARNING: Removing unreachable block (ram,0x00018020cc02)
// WARNING: Removing unreachable block (ram,0x00018020cc08)
// WARNING: Removing unreachable block (ram,0x00018020cc10)
// WARNING: Removing unreachable block (ram,0x00018020cc1a)
// WARNING: Removing unreachable block (ram,0x00018020cc2f)
// WARNING: Removing unreachable block (ram,0x00018020cc29)
// WARNING: Removing unreachable block (ram,0x00018020cc3f)
// WARNING: Removing unreachable block (ram,0x00018020cc4b)
// WARNING: Removing unreachable block (ram,0x00018020cc5a)
// WARNING: Removing unreachable block (ram,0x00018020cc60)
// WARNING: Removing unreachable block (ram,0x00018020cc66)
// WARNING: Removing unreachable block (ram,0x00018020cc6e)
// WARNING: Removing unreachable block (ram,0x00018020cc78)
// WARNING: Removing unreachable block (ram,0x00018020cc8d)
// WARNING: Removing unreachable block (ram,0x00018020cc87)
// WARNING: Removing unreachable block (ram,0x00018020cc9d)
// WARNING: Removing unreachable block (ram,0x00018020cca8)
// WARNING: Removing unreachable block (ram,0x00018020ccca)
// WARNING: Removing unreachable block (ram,0x00018020ccaf)
// WARNING: Removing unreachable block (ram,0x00018020ccb8)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801fa0e0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_70h)
{
    char cVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    int64_t iVar6;
    undefined uVar7;
    int64_t in_RDX;
    undefined8 uVar8;
    undefined8 in_R8;
    undefined8 in_R9;
    undefined8 unaff_R15;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 auStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa0f5;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    in_RCX = in_RCX + 0x98;
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fa112;
        func_0x00018020c990(in_RCX);
    }
    uVar8 = *(undefined8 *)((int64_t)auStackX_18 + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + -8) = *(undefined8 *)((int64_t)&arg_30h + iVar4);
    iVar2 = iVar4 + 8;
    *(undefined8 *)((int64_t)&var_8h + iVar4) = unaff_R15;
    *(undefined8 *)((int64_t)auStackX_18 + iVar4 + -0x18) = 0x18020cb3f;
    iVar5 = fcn.18045a350(in_RCX, in_R8, in_R9);
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + -0x18) = 0x18020cb51;
    iVar3 = func_0x00018020bfa0();
    if (iVar3 != 0) {
        uVar7 = 0x22;
        *(undefined8 *)((int64_t)&arg_50h + iVar5 + iVar4) = uVar8;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + -0x18) = 0x18020cb68;
        *(undefined8 *)((int64_t)auStackX_18 + iVar5 + iVar4 + -8) = in_R8;
        *(undefined8 *)(&stack0xfffffffffffffff8 + iVar5 + iVar4) = uVar8;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5 + iVar4) = 0x18020c1b0;
        iVar6 = in_RCX;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        if (*(char *)(iVar6 + 4) == '\0') {
            cVar1 = *(char *)(iVar6 + 0x10);
            *(int64_t *)((int64_t)&arg_28h + iVar4 + iVar5 + iVar2 + -8) = in_RCX;
            if (cVar1 != '\0') {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4 + iVar5 + iVar2 + -8) = 0x18020c1cf;
                func_0x00018020be10();
            }
            if (*(int64_t *)(iVar6 + 0x38) == *(int64_t *)(iVar6 + 0x40)) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar4 + iVar5 + iVar2 + -8) = 0x18020c1e4;
                iVar3 = func_0x00018020cd80(iVar6 + 0x28, 0);
                if (iVar3 == 0) {
                    *(undefined *)(iVar6 + 4) = 1;
                    return;
                }
            }
            *(undefined *)(*(int64_t *)(iVar6 + 0x30) + *(int64_t *)(iVar6 + 0x40)) = uVar7;
            *(int64_t *)(iVar6 + 0x40) = *(int64_t *)(iVar6 + 0x40) + 1;
        }
        return;
    }
    return;
}

// ============================================================
// Function: FUN_1801fa130
// Address: 0x1801fa130
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801fa130(int64_t arg_28h, int64_t arg_48h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    undefined uVar7;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    char in_R8B;
    int64_t var_8h;
    undefined8 auStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa140;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar6 = (uint8_t *)(in_RCX + 0x98);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fa15b;
        func_0x00018020c990(puVar6);
    }
    uVar8 = *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    iVar2 = iVar4 + 0x18;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4 + 8) = uVar8;
    *(undefined8 *)((int64_t)auStackX_10 + iVar4) = 0x18020c7e0;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x18020c7ee;
    iVar3 = func_0x00018020bfa0();
    if (iVar3 != 0) {
        uVar8 = 0x1805ab28c;
        if (in_R8B != '\0') {
            uVar8 = 0x1805ab294;
        }
        *(undefined8 *)((int64_t)auStackX_10 + iVar5 + iVar4) = 0x18020c80f;
        func_0x00018020c680(puVar6, uVar8);
        if ((puVar6[5] == 0) && (*(int64_t *)(puVar6 + 0x48) == 0)) {
            puVar6[6] = 2;
            if ((*puVar6 & 1) != 0) {
                uVar7 = 10;
                uVar8 = *(undefined8 *)((int64_t)&arg_48h + iVar5 + iVar4);
                *(undefined8 *)(&stack0x00000050 + iVar5 + iVar4) = unaff_RSI;
                *(undefined8 *)(&stack0x00000038 + iVar5 + iVar4) = *(undefined8 *)(&stack0x00000038 + iVar5 + iVar4);
                *(undefined8 *)(&stack0x00000030 + iVar5 + iVar4) = 0x18020c1b0;
                iVar4 = fcn.18045a350();
                iVar4 = -iVar4;
                if (puVar6[4] == 0) {
                    uVar1 = puVar6[0x10];
                    *(undefined8 *)(&stack0x00000068 + iVar4 + iVar5 + iVar2 + -0x18) = uVar8;
                    if (uVar1 != 0) {
                        *(undefined8 *)(&stack0x00000030 + iVar4 + iVar5 + iVar2 + -0x18) = 0x18020c1cf;
                        func_0x00018020be10();
                    }
                    if (*(int64_t *)(puVar6 + 0x38) == *(int64_t *)(puVar6 + 0x40)) {
                        *(undefined8 *)(&stack0x00000030 + iVar4 + iVar5 + iVar2 + -0x18) = 0x18020c1e4;
                        iVar3 = func_0x00018020cd80(puVar6 + 0x28, 0);
                        if (iVar3 == 0) {
                            puVar6[4] = 1;
                            return;
                        }
                    }
                    *(undefined *)(*(int64_t *)(puVar6 + 0x30) + *(int64_t *)(puVar6 + 0x40)) = uVar7;
                    *(int64_t *)(puVar6 + 0x40) = *(int64_t *)(puVar6 + 0x40) + 1;
                }
                return;
            }
        } else {
            puVar6[6] = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801fa180
// Address: 0x1801fa180
// Size: 43 bytes
// ============================================================
void fcn.1801fa180(int64_t arg1, int64_t arg_28h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 unaff_RDI;
    uint64_t uVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fa194;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (*(int32_t *)(arg1 + 0x68) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1b5;
            func_0x00018020ca90(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1c8;
            func_0x00018020c990(arg1 + 0x98, 0x18062621c);
            uVar1 = *(uint64_t *)(arg1 + 0x88);
            if (*(int32_t *)(arg1 + 0xf4) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1f5;
                func_0x00018020cd60(arg1 + 0x98, uVar1 / 1000000);
                *(undefined4 *)(arg1 + 0xf4) = 1;
            } else {
                uVar3 = 0;
                if (*(uint64_t *)(arg1 + 0x90) <= uVar1) {
                    uVar3 = uVar1 - *(uint64_t *)(arg1 + 0x90);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa235;
                func_0x00018020cd60(arg1 + 0x98, uVar3 / 1000000);
            }
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(arg1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa24f;
            func_0x00018020ca90(arg1 + 0x98);
            *(undefined4 *)(arg1 + 0x68) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801fa1ab
// Address: 0x1801fa1ab
// Size: 176 bytes
// ============================================================
void fcn.1801fa180(int64_t arg1, int64_t arg_28h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 unaff_RDI;
    uint64_t uVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fa194;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (*(int32_t *)(arg1 + 0x68) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1b5;
            func_0x00018020ca90(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1c8;
            func_0x00018020c990(arg1 + 0x98, 0x18062621c);
            uVar1 = *(uint64_t *)(arg1 + 0x88);
            if (*(int32_t *)(arg1 + 0xf4) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1f5;
                func_0x00018020cd60(arg1 + 0x98, uVar1 / 1000000);
                *(undefined4 *)(arg1 + 0xf4) = 1;
            } else {
                uVar3 = 0;
                if (*(uint64_t *)(arg1 + 0x90) <= uVar1) {
                    uVar3 = uVar1 - *(uint64_t *)(arg1 + 0x90);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa235;
                func_0x00018020cd60(arg1 + 0x98, uVar3 / 1000000);
            }
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(arg1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa24f;
            func_0x00018020ca90(arg1 + 0x98);
            *(undefined4 *)(arg1 + 0x68) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801fa25b
// Address: 0x1801fa25b
// Size: 6 bytes
// ============================================================
void fcn.1801fa180(int64_t arg1, int64_t arg_28h)
{
    uint64_t uVar1;
    int64_t iVar2;
    undefined8 unaff_RDI;
    uint64_t uVar3;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fa194;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        if (*(int32_t *)(arg1 + 0x68) != 0) {
            *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RDI;
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1b5;
            func_0x00018020ca90(arg1 + 0x98);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1c8;
            func_0x00018020c990(arg1 + 0x98, 0x18062621c);
            uVar1 = *(uint64_t *)(arg1 + 0x88);
            if (*(int32_t *)(arg1 + 0xf4) == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa1f5;
                func_0x00018020cd60(arg1 + 0x98, uVar1 / 1000000);
                *(undefined4 *)(arg1 + 0xf4) = 1;
            } else {
                uVar3 = 0;
                if (*(uint64_t *)(arg1 + 0x90) <= uVar1) {
                    uVar3 = uVar1 - *(uint64_t *)(arg1 + 0x90);
                }
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa235;
                func_0x00018020cd60(arg1 + 0x98, uVar3 / 1000000);
            }
            *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(arg1 + 0x88);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa24f;
            func_0x00018020ca90(arg1 + 0x98);
            *(undefined4 *)(arg1 + 0x68) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801fa270
// Address: 0x1801fa270
// Size: 86 bytes
// ============================================================
undefined8 fcn.1801fa270(int64_t arg_28h, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa27c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RCX != 0) && (*(int32_t *)(in_RCX + 0x68) == 0)) &&
       ((*(uint32_t *)(in_RCX + 0x60 + ((in_RDX & 0xffffffff) >> 6) * 8) & (uint32_t)(1LL << ((uint8_t)in_RDX & 0x3f)))
        != 0)) {
        uVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(in_RCX + 0x80) = *(undefined8 *)((int64_t)&arg_48h + iVar2);
        pcVar1 = *(code **)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(int32_t *)(in_RCX + 0x68) = (int32_t)in_RDX;
        *(undefined8 *)(in_RCX + 0x70) = in_R8;
        *(undefined8 *)(in_RCX + 0x78) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2d8;
        uVar3 = (*pcVar1)(uVar3);
        *(undefined8 *)(in_RCX + 0x88) = uVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2e7;
        fcn.1801faf60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000098 + iVar2), 
                      *(int64_t *)(&stack0x000000c0 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2), 
                      *(int64_t *)(&stack0x000000d0 + iVar2), *(int64_t *)(&stack0x00000190 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2f3;
        fcn.18020ca60(in_RCX + 0x98);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa306;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa319;
        fcn.18020cac0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa32c;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa338;
        fcn.18020ca60(in_RCX + 0x98);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fa2c6
// Address: 0x1801fa2c6
// Size: 130 bytes
// ============================================================
undefined8 fcn.1801fa270(int64_t arg_28h, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa27c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RCX != 0) && (*(int32_t *)(in_RCX + 0x68) == 0)) &&
       ((*(uint32_t *)(in_RCX + 0x60 + ((in_RDX & 0xffffffff) >> 6) * 8) & (uint32_t)(1LL << ((uint8_t)in_RDX & 0x3f)))
        != 0)) {
        uVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(in_RCX + 0x80) = *(undefined8 *)((int64_t)&arg_48h + iVar2);
        pcVar1 = *(code **)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(int32_t *)(in_RCX + 0x68) = (int32_t)in_RDX;
        *(undefined8 *)(in_RCX + 0x70) = in_R8;
        *(undefined8 *)(in_RCX + 0x78) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2d8;
        uVar3 = (*pcVar1)(uVar3);
        *(undefined8 *)(in_RCX + 0x88) = uVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2e7;
        fcn.1801faf60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000098 + iVar2), 
                      *(int64_t *)(&stack0x000000c0 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2), 
                      *(int64_t *)(&stack0x000000d0 + iVar2), *(int64_t *)(&stack0x00000190 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2f3;
        fcn.18020ca60(in_RCX + 0x98);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa306;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa319;
        fcn.18020cac0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa32c;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa338;
        fcn.18020ca60(in_RCX + 0x98);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fa348
// Address: 0x1801fa348
// Size: 8 bytes
// ============================================================
undefined8 fcn.1801fa270(int64_t arg_28h, int64_t arg_48h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int64_t in_RCX;
    uint64_t in_RDX;
    undefined8 unaff_RBX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa27c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if (((in_RCX != 0) && (*(int32_t *)(in_RCX + 0x68) == 0)) &&
       ((*(uint32_t *)(in_RCX + 0x60 + ((in_RDX & 0xffffffff) >> 6) * 8) & (uint32_t)(1LL << ((uint8_t)in_RDX & 0x3f)))
        != 0)) {
        uVar3 = *(undefined8 *)(in_RCX + 0x40);
        *(undefined8 *)(in_RCX + 0x80) = *(undefined8 *)((int64_t)&arg_48h + iVar2);
        pcVar1 = *(code **)(in_RCX + 0x38);
        *(undefined8 *)((int64_t)&arg_28h + iVar2) = unaff_RBX;
        *(int32_t *)(in_RCX + 0x68) = (int32_t)in_RDX;
        *(undefined8 *)(in_RCX + 0x70) = in_R8;
        *(undefined8 *)(in_RCX + 0x78) = in_R9;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2d8;
        uVar3 = (*pcVar1)(uVar3);
        *(undefined8 *)(in_RCX + 0x88) = uVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2e7;
        fcn.1801faf60(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)(&stack0x00000098 + iVar2), 
                      *(int64_t *)(&stack0x000000c0 + iVar2), *(int64_t *)(&stack0x000000c8 + iVar2), 
                      *(int64_t *)(&stack0x000000d0 + iVar2), *(int64_t *)(&stack0x00000190 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa2f3;
        fcn.18020ca60(in_RCX + 0x98);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa306;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa319;
        fcn.18020cac0(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa32c;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar2));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa338;
        fcn.18020ca60(in_RCX + 0x98);
        return 1;
    }
    return 0;
}

// ============================================================
// Function: FUN_1801fa350
// Address: 0x1801fa350
// Size: 44 bytes
// ============================================================
undefined8
fcn.1801fa350(int64_t arg_60h, int64_t arg_68h, int64_t arg_78h, int64_t arg_80h, int64_t arg_88h, int64_t arg_a8h)
{
    uint64_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    int32_t iVar7;
    undefined8 unaff_RBX;
    uint64_t uVar8;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 uStackX_20;
    
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if (in_RCX == 0) {
        return 1;
    }
    in_RCX = in_RCX + 0x98;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar4) = 0x18020c85a;
    iVar5 = fcn.18045a350();
    iVar6 = -iVar5;
    iVar2 = iVar6 + iVar4 + 0x20;
    in_RCX = in_RCX + iVar5;
    iVar7 = 1;
    *(undefined8 *)((int64_t)&arg_60h + iVar6 + iVar4) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_68h + iVar6 + iVar4) = unaff_RSI;
    *(undefined8 *)(&stack0x00000048 + iVar6 + iVar4 + 0x20 + -0x20) = unaff_RDI;
    *(undefined8 *)(&stack0x00000040 + iVar6 + iVar4) = 0x18020cd95;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    iVar4 = *(int64_t *)(in_RCX + 0x18);
    uVar8 = 0;
    *(undefined8 *)((int64_t)&arg_78h + iVar6 + iVar2 + -0x20) = 0;
    if (iVar4 != 0) {
        do {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar2 + -0x20) = 0x18020cdc8;
            iVar3 = fcn.18021b300(*(int64_t *)((int64_t)&arg_68h + iVar6 + iVar2 + -0x20));
            uVar1 = *(uint64_t *)(in_RCX + 0x18);
            if (iVar3 == 0) {
                iVar4 = *(int64_t *)(in_RCX + 8);
                *(undefined8 *)(&stack0x00000040 + iVar6 + iVar2 + -0x20) = 0x18020ce1e;
                fcn.180498030(iVar4, iVar4 + uVar8, uVar1 - uVar8);
                *(undefined8 *)(in_RCX + 0x18) = 0;
                return 0;
            }
            uVar8 = uVar8 + *(int64_t *)((int64_t)&arg_78h + iVar6 + iVar2 + -0x20);
        } while (uVar8 < uVar1);
    }
    *(undefined8 *)(in_RCX + 0x18) = 0;
    if (iVar7 != 0) {
        *(undefined8 *)(&stack0x00000040 + iVar6 + iVar2 + -0x20) = 0x18020cdf9;
        fcn.180219d10(*(int64_t *)((int64_t)&arg_88h + iVar6 + iVar2 + -0x20), 
                      *(int64_t *)(&stack0x00000090 + iVar6 + iVar2 + -0x20), 
                      *(int64_t *)(&stack0x00000098 + iVar6 + iVar2 + -0x20));
    }
    return 1;
}

// ============================================================
// Function: FUN_1801fa380
// Address: 0x1801fa380
// Size: 162 bytes
// ============================================================
void fcn.1801fa380(int64_t arg1)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fa394;
        iVar2 = fcn.18045a350();
        iVar2 = -iVar2;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa3a6;
        fcn.18020c870(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8));
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa3af;
        fcn.18021a070(*(int64_t *)((int64_t)aiStackX_18 + iVar2), *(int64_t *)((int64_t)aiStackX_18 + iVar2 + 8), 
                      *(int64_t *)(&stack0x00000038 + iVar2), *(int64_t *)(&stack0x00000040 + iVar2), 
                      *(int64_t *)(&stack0x00000048 + iVar2));
        uVar1 = *(undefined8 *)(arg1 + 0x18);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa3c5;
        fcn.180224990(uVar1, 0x1804b8ac8, 0xa8);
        uVar1 = *(undefined8 *)(arg1 + 0x20);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa3db;
        fcn.180224990(uVar1, 0x1804b8ac8, 0xa9);
        uVar1 = *(undefined8 *)(arg1 + 0x28);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa3f1;
        fcn.180224990(uVar1, 0x1804b8ac8, 0xaa);
        uVar1 = *(undefined8 *)(arg1 + 0x50);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa407;
        fcn.180224990(uVar1, 0x1804b8ac8, 0xab);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x1801fa41c;
        fcn.180224990(arg1, 0x1804b8ac8, 0xac);
    }
    return;
}

// ============================================================
// Function: FUN_1801fa430
// Address: 0x1801fa430
// Size: 48 bytes
// ============================================================
void fcn.1801fa430(int64_t param_1, int64_t param_2)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fa43c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    param_1 = param_1 + 0x98;
    if (param_2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x1801fa453;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_10 + iVar1 + 8));
    }
    *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + 8) = *(undefined8 *)((int64_t)aiStackX_10 + iVar1 + 8);
    *(undefined8 *)((int64_t)aiStackX_10 + iVar1) = 0x18020ca6c;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar2 + iVar1) = 0x18020ca7c;
    fcn.18020bbc0(*(int64_t *)(&stack0x00000038 + iVar2 + iVar1), *(int64_t *)(&stack0x00000040 + iVar2 + iVar1), 
                  *(int64_t *)(&stack0x00000048 + iVar2 + iVar1));
    *(undefined *)(param_1 + 6) = 0;
    return;
}

// ============================================================
// Function: FUN_1801fa460
// Address: 0x1801fa460
// Size: 29 bytes
// ============================================================
void fcn.1801fa460(int64_t param_1)
{
    uint8_t uVar1;
    int64_t iVar2;
    uint32_t uVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint8_t uVar8;
    uint8_t *puVar9;
    uint32_t uVar10;
    int64_t iVar11;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    uint8_t uVar12;
    uint64_t uVar13;
    undefined8 uStackX_20;
    
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar9 = (uint8_t *)(param_1 + 0x98);
    *(undefined8 *)((int64_t)&uStackX_20 + iVar5) = 0x18020ca9a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    uVar13 = 0x7d;
    uVar10 = 0;
    *(undefined8 *)(&stack0x00000058 + iVar7 + iVar5) = unaff_RBX;
    *(undefined8 *)(&stack0x00000048 + iVar7 + iVar5) = unaff_RDI;
    *(undefined8 *)(&stack0x00000040 + iVar7 + iVar5) = 0x18020bcd0;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = puVar9[0x10];
    if (puVar9[4] != 0) {
        return;
    }
    uVar12 = puVar9[5];
    iVar2 = *(int64_t *)(puVar9 + 0x48);
    puVar9[0x10] = 0;
    if (uVar12 == 0) {
        if (iVar2 != 0) {
            uVar8 = 7;
            iVar11 = iVar2 + -1;
            goto code_r0x00018020bd1e;
        }
        uVar3 = 0xffffffff;
    } else {
        uVar8 = uVar12 - 1;
        iVar11 = iVar2;
code_r0x00018020bd1e:
        uVar3 = (uint32_t)(((uint8_t)(1 << (uVar8 & 0x1f)) & *(uint8_t *)(iVar11 + *(int64_t *)(puVar9 + 8))) != 0);
    }
    if (((uVar3 == uVar10) && ((uVar10 != 0 || (puVar9[6] != 1)))) && ((iVar2 != 0 || (uVar12 != 0)))) {
        if (uVar12 == 0) {
            uVar12 = 7;
            *(int64_t *)(puVar9 + 0x48) = iVar2 + -1;
        } else {
            uVar12 = uVar12 - 1;
        }
        puVar9[5] = uVar12;
        if (uVar1 == 0) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bd83;
            func_0x00018020be10(puVar9);
        }
        *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bd8f;
        func_0x00018020c1a0(puVar9, uVar13 & 0xff);
        if ((puVar9[5] != 0) || (*(int64_t *)(puVar9 + 0x48) != 0)) {
            puVar9[6] = 2;
            return;
        }
        puVar9[6] = 2;
        if ((*puVar9 & 1) == 0) {
            return;
        }
        if (puVar9[4] != 0) {
            return;
        }
        if (puVar9[0x10] != 0) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bdb9;
            func_0x00018020be10(puVar9);
        }
        if (*(int64_t *)(puVar9 + 0x38) == *(int64_t *)(puVar9 + 0x40)) {
            *(undefined8 *)(&stack0x00000040 + iVar6 + iVar7 + iVar5) = 0x18020bdce;
            iVar4 = fcn.18020cd80(*(int64_t *)(&stack0x000000a0 + iVar6 + iVar7 + iVar5), 
                                  *(int64_t *)(&stack0x000000a8 + iVar6 + iVar7 + iVar5), 
                                  *(int64_t *)(&stack0x000000b8 + iVar6 + iVar7 + iVar5), 
                                  *(int64_t *)(&stack0x000000c0 + iVar6 + iVar7 + iVar5), 
                                  *(int64_t *)(&stack0x000000c8 + iVar6 + iVar7 + iVar5), 
                                  *(int64_t *)(&stack0x000000e8 + iVar6 + iVar7 + iVar5));
            if (iVar4 == 0) goto code_r0x00018020bdfc;
        }
        *(undefined *)(*(int64_t *)(puVar9 + 0x30) + *(int64_t *)(puVar9 + 0x40)) = 10;
        *(int64_t *)(puVar9 + 0x40) = *(int64_t *)(puVar9 + 0x40) + 1;
        return;
    }
code_r0x00018020bdfc:
    puVar9[4] = 1;
    return;
}

// ============================================================
// Function: FUN_1801fa480
// Address: 0x1801fa480
// Size: 968 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

undefined4 * fcn.1801fa480(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    uint8_t uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    char cVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    undefined8 uVar9;
    int64_t iVar10;
    int64_t iVar11;
    undefined4 *puVar12;
    undefined4 *puVar13;
    undefined4 *in_RCX;
    char *pcVar14;
    uint64_t uVar15;
    bool bVar16;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x1801fa4a2;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa4b4;
    pcVar8 = (char *)func_0x000180275160(0x1804b8ad8);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa4c3;
    uVar9 = func_0x000180275160(0x1804b8ae0);
    *(undefined8 *)((int64_t)&arg_28h + iVar7) = uVar9;
    if (in_RCX == (undefined4 *)0x0) {
        return (undefined4 *)0x0;
    }
    if (pcVar8 == (char *)0x0) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa4e2;
    iVar10 = func_0x000180498cd0(pcVar8);
    if (iVar10 == 0) {
        return (undefined4 *)0x0;
    }
    cVar5 = *pcVar8;
    pcVar14 = pcVar8;
    if (cVar5 != '\0') {
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa4fe;
        iVar11 = func_0x000180498cd0();
        pcVar14 = pcVar8 + iVar11 + -1;
        cVar5 = *pcVar14;
    }
    uVar15 = 0;
    if (cVar5 == '\\') {
        bVar16 = true;
    } else {
        bVar16 = *pcVar14 == '/';
    }
    iVar11 = (uint64_t)*(uint8_t *)in_RCX * 2 + 0xf + iVar10;
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa547;
    puVar12 = (undefined4 *)func_0x0001802248d0(iVar11, 0x1804b8ac8, 0x7d);
    if (puVar12 == (undefined4 *)0x0) {
        return (undefined4 *)0x0;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa561;
    fcn.180498030(puVar12, pcVar8, iVar10);
    if (!bVar16) {
        *(undefined *)(iVar10 + (int64_t)puVar12) = 0x5c;
        iVar10 = iVar10 + 1;
    }
    if (*(uint8_t *)in_RCX != 0) {
        do {
            uVar1 = *(uint8_t *)((int64_t)in_RCX + uVar15 + 1);
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa58e;
            iVar6 = func_0x000180245f70(iVar10 + (int64_t)puVar12, iVar11 - iVar10, 0x1804b8af0, uVar1);
            uVar15 = uVar15 + 1;
            iVar10 = iVar10 + iVar6;
        } while (uVar15 < *(uint8_t *)in_RCX);
    }
    uVar9 = 0x1804b8b00;
    if (in_RCX[0xc] != 0) {
        uVar9 = 0x1804b8af8;
    }
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa5cb;
    func_0x000180245f70(iVar10 + (int64_t)puVar12, iVar11 - iVar10, 0x1804b8b08, uVar9);
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa5de;
    puVar13 = (undefined4 *)func_0x000180224d60(0xf8, 0x1804b8ac8, 0x3a);
    if (puVar13 != (undefined4 *)0x0) {
        uVar2 = in_RCX[1];
        uVar3 = in_RCX[2];
        uVar4 = in_RCX[3];
        *puVar13 = *in_RCX;
        puVar13[1] = uVar2;
        puVar13[2] = uVar3;
        puVar13[3] = uVar4;
        puVar13[4] = in_RCX[4];
        *(uint8_t *)(puVar13 + 5) = *(uint8_t *)(in_RCX + 5);
        puVar13[0xc] = in_RCX[0xc];
        *(undefined8 *)(puVar13 + 0xe) = *(undefined8 *)(in_RCX + 0xe);
        *(undefined8 *)(puVar13 + 0x10) = *(undefined8 *)(in_RCX + 0x10);
        *(undefined8 *)(puVar13 + 0x12) = *(undefined8 *)(in_RCX + 0x12);
        iVar10 = *(int64_t *)(in_RCX + 6);
        if (iVar10 == 0) {
code_r0x0001801fa63b:
            iVar10 = *(int64_t *)(in_RCX + 8);
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa652;
                iVar10 = func_0x0001802231e0(iVar10, 0x1804b8ac8, 0x4a);
                *(int64_t *)(puVar13 + 8) = iVar10;
                if (iVar10 == 0) goto code_r0x0001801fa6b3;
            }
            iVar10 = *(int64_t *)(in_RCX + 10);
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa672;
                iVar10 = func_0x0001802231e0(iVar10, 0x1804b8ac8, 0x4e);
                *(int64_t *)(puVar13 + 10) = iVar10;
                if (iVar10 == 0) goto code_r0x0001801fa6b3;
            }
            iVar10 = *(int64_t *)(in_RCX + 0x14);
            if (iVar10 != 0) {
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa692;
                iVar10 = func_0x0001802231e0(iVar10, 0x1804b8ac8, 0x53);
                *(int64_t *)(puVar13 + 0x14) = iVar10;
                if (iVar10 == 0) goto code_r0x0001801fa6b3;
            }
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa6af;
            iVar6 = func_0x00018020c8f0(puVar13 + 0x26, 0, 5);
            if (iVar6 != 0) {
                if (*(int64_t *)(puVar13 + 0xe) == 0) {
                    *(code **)(puVar13 + 0xe) = fcn.1801fa070;
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa738;
                iVar10 = func_0x00018023f8e0(puVar12, 0x1804b8b14);
                if (iVar10 != 0) {
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa74c;
                    func_0x00018020c850(puVar13 + 0x26);
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa755;
                    fcn.18021a070(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7)
                                  , *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                                  *(int64_t *)((int64_t)&arg_28h + iVar7));
                    *(int64_t *)(puVar13 + 0x16) = iVar10;
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa768;
                    func_0x00018020cab0(puVar13 + 0x26, iVar10);
                    pcVar8 = *(char **)((int64_t)&arg_28h + iVar7);
                    if ((pcVar8 == (char *)0x0) || (*pcVar8 == '\0')) {
                        pcVar8 = "*";
                    }
                    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa789;
                    iVar6 = func_0x0001801fa850(puVar13, pcVar8);
                    if (iVar6 != 0) {
                        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa843;
                        fcn.180224990(puVar12, 0x1804b8ac8, 0x98);
                        return puVar13;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7a2;
                fcn.180224990(puVar12, 0x1804b8ac8, 0x9c);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7ae;
                fcn.18020c870(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7));
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7b7;
                fcn.18021a070(*(int64_t *)(&stack0xfffffffffffffff8 + iVar7), *(int64_t *)(&stack0x00000000 + iVar7), 
                              *(int64_t *)((int64_t)&var_18h + iVar7), *(int64_t *)((int64_t)&var_20h + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar7));
                uVar9 = *(undefined8 *)(puVar13 + 6);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7c9;
                fcn.180224990(uVar9, 0x1804b8ac8, 0xa8);
                uVar9 = *(undefined8 *)(puVar13 + 8);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7db;
                fcn.180224990(uVar9, 0x1804b8ac8, 0xa9);
                uVar9 = *(undefined8 *)(puVar13 + 10);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7ed;
                fcn.180224990(uVar9, 0x1804b8ac8, 0xaa);
                uVar9 = *(undefined8 *)(puVar13 + 0x14);
                *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa7ff;
                fcn.180224990(uVar9, 0x1804b8ac8, 0xab);
                uVar9 = 0xac;
                goto code_r0x0001801fa808;
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa632;
            iVar10 = func_0x0001802231e0(iVar10, 0x1804b8ac8, 0x46);
            *(int64_t *)(puVar13 + 6) = iVar10;
            if (iVar10 != 0) goto code_r0x0001801fa63b;
        }
code_r0x0001801fa6b3:
        uVar9 = *(undefined8 *)(puVar13 + 6);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa6c5;
        fcn.180224990(uVar9, 0x1804b8ac8, 0x61);
        uVar9 = *(undefined8 *)(puVar13 + 8);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa6d7;
        fcn.180224990(uVar9, 0x1804b8ac8, 0x62);
        uVar9 = *(undefined8 *)(puVar13 + 10);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa6e9;
        fcn.180224990(uVar9, 0x1804b8ac8, 99);
        uVar9 = *(undefined8 *)(puVar13 + 0x14);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa6fb;
        fcn.180224990(uVar9, 0x1804b8ac8, 100);
        *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa70c;
        fcn.180224990(puVar13, 0x1804b8ac8, 0x65);
    }
    uVar9 = 0x9c;
    puVar13 = puVar12;
code_r0x0001801fa808:
    *(undefined8 *)((int64_t)&uStack_30 + iVar7) = 0x1801fa813;
    fcn.180224990(puVar13, 0x1804b8ac8, uVar9);
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_1801fa850
// Address: 0x1801fa850
// Size: 1598 bytes
// ============================================================
undefined8 fcn.1801fa850(int64_t arg1, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h)
{
    uint8_t uVar1;
    int32_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *in_RDX;
    int64_t *piVar6;
    uint64_t uVar7;
    char cVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    uint64_t uVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    bool bVar14;
    int64_t var_8h;
    undefined8 uStack_48;
    
    uStack_48 = 0x1801fa86b;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    uVar7 = *(uint64_t *)(arg1 + 0x60);
    if (in_RDX == (int64_t *)0x0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801fa886;
    iVar5 = func_0x000180498cd0(in_RDX);
    piVar6 = (int64_t *)(iVar5 + (int64_t)in_RDX);
    *(int64_t **)((int64_t)&arg_40h + iVar4) = piVar6;
code_r0x0001801fa8b0:
    do {
        for (; ((uVar1 = *(uint8_t *)in_RDX, uVar1 == 0x20 || (((uVar1 - 9 & 0xfa) == 0 && (uVar1 != 0xe)))) &&
               (in_RDX < piVar6)); in_RDX = (int64_t *)((int64_t)in_RDX + 1)) {
        }
        piVar9 = in_RDX;
        if (in_RDX == piVar6) {
            *(uint64_t *)(*(int64_t *)((int64_t)&arg_30h + iVar4) + 0x60) = uVar7;
            return 1;
        }
        for (; ((0x20 < uVar1 || ((0x100002600U >> ((int64_t)(char)uVar1 & 0x3fU) & 1) == 0)) && (piVar9 < piVar6));
            piVar9 = (int64_t *)((int64_t)piVar9 + 1)) {
            uVar1 = *(uint8_t *)((int64_t)piVar9 + 1);
        }
        if (in_RDX == piVar9) {
            cVar8 = -1;
code_r0x0001801fa91c:
            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801fa92c;
            iVar2 = func_0x000180275490((int32_t)cVar8, 3);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801fa937;
                iVar2 = func_0x000180275480((int32_t)cVar8);
                if (((iVar2 == 0) && (cVar8 != '_')) && (cVar8 != '*')) {
                    return 0;
                }
            }
            bVar14 = true;
            *(undefined4 *)((int64_t)&arg_38h + iVar4) = 1;
            piVar13 = in_RDX;
        } else {
            cVar8 = *(char *)in_RDX;
            if ((cVar8 != '+') && (cVar8 != '-')) goto code_r0x0001801fa91c;
            piVar13 = (int64_t *)((int64_t)in_RDX + 1);
            bVar14 = cVar8 == '+';
            cVar8 = -1;
            *(uint32_t *)((int64_t)&arg_38h + iVar4) = (uint32_t)bVar14;
            if (piVar13 != piVar9) {
                cVar8 = *(char *)piVar13;
            }
            *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801fa98a;
            iVar2 = func_0x000180275490((int32_t)cVar8, 3);
            if (iVar2 == 0) {
                *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801fa995;
                iVar2 = func_0x000180275480((int32_t)cVar8);
                if (iVar2 == 0) {
                    if (0x35 < (uint8_t)(cVar8 - 0x2aU)) {
                        return 0;
                    }
                    if ((0x20000000000009U >> ((int64_t)(char)(cVar8 - 0x2aU) & 0x3fU) & 1) == 0) {
                        return 0;
                    }
                }
            }
        }
        piVar6 = piVar13;
        in_RDX = piVar9;
        if (((int64_t)piVar9 - (int64_t)piVar13 == 1) && (*(char *)piVar13 == '*')) {
            piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4);
            if (bVar14) {
                uVar7 = uVar7 | 0xfe;
            } else {
                uVar7 = uVar7 & 0xffffffffffffff01;
            }
            goto code_r0x0001801fa8b0;
        }
        for (; piVar6 < piVar9; piVar6 = (int64_t *)((int64_t)piVar6 + 1)) {
            if (*(char *)piVar6 == ':') goto code_r0x0001801faa16;
        }
        if (piVar6 == piVar9) {
            return 0;
        }
code_r0x0001801faa16:
        piVar12 = (int64_t *)((int64_t)piVar6 + 1);
        iVar5 = (int64_t)piVar6 - (int64_t)piVar13;
        uVar11 = (int64_t)piVar9 - (int64_t)piVar12;
        *(int64_t *)((int64_t)&arg_48h + iVar4) = iVar5;
        if (iVar5 == 1) {
            if (*(char *)piVar13 != '*') goto code_r0x0001801faa50;
            piVar13 = (int64_t *)0x0;
            *(undefined8 *)((int64_t)&arg_48h + iVar4) = 0;
        } else {
            if (iVar5 == 0) {
                return 0;
            }
code_r0x0001801faa50:
            uVar10 = 0;
            if (iVar5 != 0) {
                do {
                    cVar8 = *(char *)((int64_t)piVar13 + uVar10);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801faa71;
                    iVar2 = func_0x000180275490((int32_t)cVar8, 3);
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801faa7c;
                        iVar2 = func_0x000180275480((int32_t)cVar8);
                        if (((iVar2 == 0) && (cVar8 != '_')) && (cVar8 != '-')) {
                            return 0;
                        }
                    }
                    uVar10 = uVar10 + 1;
                } while (uVar10 < *(uint64_t *)((int64_t)&arg_48h + iVar4));
            }
        }
        if (uVar11 == 1) {
            if (*(char *)piVar12 != '*') goto code_r0x0001801faaba;
            piVar12 = (int64_t *)0x0;
            uVar11 = 0;
        } else {
            if (uVar11 == 0) {
                return 0;
            }
code_r0x0001801faaba:
            uVar10 = 0;
            if (uVar11 != 0) {
                do {
                    cVar8 = *(char *)((int64_t)piVar12 + uVar10);
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801faad2;
                    iVar2 = func_0x000180275490((int32_t)cVar8, 3);
                    if (iVar2 == 0) {
                        *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801faadd;
                        iVar2 = func_0x000180275480((int32_t)cVar8);
                        if (((iVar2 == 0) && (cVar8 != '_')) && (cVar8 != '-')) {
                            return 0;
                        }
                    }
                    uVar10 = uVar10 + 1;
                } while (uVar10 < uVar11);
            }
        }
        iVar5 = *(int64_t *)((int64_t)&arg_48h + iVar4);
        if ((piVar13 == (int64_t *)0x0) || (iVar5 == 0xc)) {
            if ((piVar12 == (int64_t *)0x0) || (uVar11 == 0x12)) {
                if ((piVar13 != (int64_t *)0x0) &&
                   ((*piVar13 != 0x697463656e6e6f63 || (*(int32_t *)(piVar13 + 1) != 0x79746976))))
                goto code_r0x0001801fab77;
                if ((piVar12 != (int64_t *)0x0) &&
                   (((*piVar12 != 0x697463656e6e6f63 || (piVar12[1] != 0x74726174735f6e6f)) ||
                    (*(int16_t *)(piVar12 + 2) != 0x6465)))) goto code_r0x0001801fab6c;
                iVar2 = *(int32_t *)((int64_t)&arg_38h + iVar4);
                if (iVar2 == 0) {
                    uVar7 = uVar7 & 0xfffffffffffffffd;
                } else {
                    uVar7 = uVar7 | 2;
                }
            } else {
code_r0x0001801fab6c:
                iVar2 = *(int32_t *)((int64_t)&arg_38h + iVar4);
            }
            if (piVar13 != (int64_t *)0x0) goto code_r0x0001801fab7b;
code_r0x0001801fab85:
            if ((piVar12 == (int64_t *)0x0) || (uVar11 == 0x18)) {
                if ((piVar13 == (int64_t *)0x0) ||
                   ((*piVar13 == 0x697463656e6e6f63 && (*(int32_t *)(piVar13 + 1) == 0x79746976)))) {
                    if ((piVar12 == (int64_t *)0x0) ||
                       (((*piVar12 == 0x697463656e6e6f63 && (piVar12[1] == 0x65746174735f6e6f)) &&
                        (piVar12[2] == 0x646574616470755f)))) {
                        if (iVar2 == 0) {
                            uVar7 = uVar7 & 0xfffffffffffffffb;
                        } else {
                            uVar7 = uVar7 | 4;
                        }
                    }
                    goto code_r0x0001801fabe6;
                }
code_r0x0001801fabeb:
                if (iVar5 != 0xc) goto code_r0x0001801fac4e;
            } else {
code_r0x0001801fabe6:
                if (piVar13 != (int64_t *)0x0) goto code_r0x0001801fabeb;
            }
            if ((piVar12 == (int64_t *)0x0) || (uVar11 == 0x11)) {
                if ((piVar13 != (int64_t *)0x0) &&
                   ((*piVar13 != 0x697463656e6e6f63 || (*(int32_t *)(piVar13 + 1) != 0x79746976))))
                goto code_r0x0001801fac4e;
                if ((piVar12 == (int64_t *)0x0) ||
                   (((*piVar12 == 0x697463656e6e6f63 && (piVar12[1] == 0x65736f6c635f6e6f)) &&
                    (*(char *)(piVar12 + 2) == 'd')))) {
                    if (iVar2 == 0) {
                        uVar7 = uVar7 & 0xfffffffffffffff7;
                    } else {
                        uVar7 = uVar7 | 8;
                    }
                }
            }
            if (piVar13 != (int64_t *)0x0) goto code_r0x0001801fac4e;
code_r0x0001801fac58:
            if ((piVar12 == (int64_t *)0x0) || (uVar11 == 0xe)) {
                if ((piVar13 == (int64_t *)0x0) || ((*piVar13 == 0x726f70736e617274 && (*(char *)(piVar13 + 1) == 't')))
                   ) {
                    if ((piVar12 == (int64_t *)0x0) ||
                       (((*piVar12 == 0x6574656d61726170 && (*(int32_t *)(piVar12 + 1) == 0x735f7372)) &&
                        (*(int16_t *)((int64_t)piVar12 + 0xc) == 0x7465)))) {
                        if (iVar2 == 0) {
                            uVar7 = uVar7 & 0xffffffffffffffef;
                        } else {
                            uVar7 = uVar7 | 0x10;
                        }
                    }
                    goto code_r0x0001801facb3;
                }
code_r0x0001801facb8:
                if (iVar5 != 9) goto code_r0x0001801fad7c;
            } else {
code_r0x0001801facb3:
                if (piVar13 != (int64_t *)0x0) goto code_r0x0001801facb8;
            }
            if ((piVar12 == (int64_t *)0x0) || (uVar11 == 0xb)) {
                if ((piVar13 == (int64_t *)0x0) || ((*piVar13 == 0x726f70736e617274 && (*(char *)(piVar13 + 1) == 't')))
                   ) {
                    if ((piVar12 == (int64_t *)0x0) ||
                       (((*piVar12 == 0x735f74656b636170 && (*(int16_t *)(piVar12 + 1) == 0x6e65)) &&
                        (*(char *)((int64_t)piVar12 + 10) == 't')))) {
                        if (iVar2 == 0) {
                            uVar7 = uVar7 & 0xffffffffffffffdf;
                        } else {
                            uVar7 = uVar7 | 0x20;
                        }
                    }
                    goto code_r0x0001801fad1a;
                }
code_r0x0001801fad1f:
                if (iVar5 != 9) goto code_r0x0001801fad7c;
            } else {
code_r0x0001801fad1a:
                if (piVar13 != (int64_t *)0x0) goto code_r0x0001801fad1f;
            }
            if ((piVar12 == (int64_t *)0x0) || (uVar11 == 0xf)) {
                if ((piVar13 != (int64_t *)0x0) && ((*piVar13 != 0x726f70736e617274 || (*(char *)(piVar13 + 1) != 't')))
                   ) goto code_r0x0001801fad7c;
                if (piVar12 != (int64_t *)0x0) {
                    *(undefined8 *)((int64_t)&uStack_48 + iVar4) = 0x1801fad65;
                    iVar3 = func_0x000180497f30(piVar12, 0x1804b8c00, 0xf);
                    if (iVar3 != 0) goto code_r0x0001801fad77;
                }
                if (iVar2 == 0) {
                    uVar7 = uVar7 & 0xffffffffffffffbf;
                } else {
                    uVar7 = uVar7 | 0x40;
                }
            }
code_r0x0001801fad77:
            if (piVar13 != (int64_t *)0x0) goto code_r0x0001801fad7c;
            goto code_r0x0001801fad98;
        }
code_r0x0001801fab77:
        iVar2 = *(int32_t *)((int64_t)&arg_38h + iVar4);
code_r0x0001801fab7b:
        if (iVar5 == 0xc) goto code_r0x0001801fab85;
code_r0x0001801fac4e:
        if (iVar5 == 9) goto code_r0x0001801fac58;
code_r0x0001801fad7c:
        piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4);
        if (iVar5 == 8) {
code_r0x0001801fad98:
            if ((((piVar12 == (int64_t *)0x0) || (piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4), uVar11 == 0xb)) &&
                ((piVar13 == (int64_t *)0x0 ||
                 (piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4), *piVar13 == 0x797265766f636572)))) &&
               ((piVar12 == (int64_t *)0x0 ||
                (((piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4), *piVar12 == 0x6c5f74656b636170 &&
                  (*(int16_t *)(piVar12 + 1) == 0x736f)) && (*(char *)((int64_t)piVar12 + 10) == 't')))))) {
                if (iVar2 == 0) {
                    piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4);
                    uVar7 = uVar7 & 0xffffffffffffff7f;
                } else {
                    piVar6 = *(int64_t **)((int64_t)&arg_40h + iVar4);
                    uVar7 = uVar7 | 0x80;
                }
            }
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801fae90
// Address: 0x1801fae90
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1801fae90(int64_t arg_28h)
{
    uint8_t uVar1;
    int64_t iVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t in_RCX;
    uint8_t *puVar6;
    undefined uVar7;
    int64_t in_RDX;
    undefined8 unaff_RSI;
    undefined8 uVar8;
    undefined8 in_R8;
    int64_t var_8h;
    int64_t aiStackX_10 [3];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801faea0;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    puVar6 = (uint8_t *)(in_RCX + 0x98);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801faeba;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_10 + iVar4 + 8));
    }
    uVar8 = *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8);
    *(undefined8 *)((int64_t)&arg_28h + iVar4) = *(undefined8 *)((int64_t)&arg_28h + iVar4);
    iVar2 = iVar4 + 0x18;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4 + 8) = uVar8;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar4) = 0x18020cad0;
    iVar5 = fcn.18045a350(puVar6, in_R8);
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + iVar4) = 0x18020cade;
    iVar3 = func_0x00018020bfa0();
    if (iVar3 != 0) {
        *(undefined8 *)((int64_t)aiStackX_10 + iVar5 + iVar4) = 0x18020caf6;
        func_0x00018020c220(puVar6, in_R8, 0, 1);
        if ((puVar6[5] == 0) && (*(int64_t *)(puVar6 + 0x48) == 0)) {
            puVar6[6] = 2;
            if ((*puVar6 & 1) != 0) {
                uVar7 = 10;
                uVar8 = *(undefined8 *)(&stack0x00000048 + iVar5 + iVar4);
                *(undefined8 *)(&stack0x00000050 + iVar5 + iVar4) = unaff_RSI;
                *(undefined8 *)(&stack0x00000038 + iVar5 + iVar4) = *(undefined8 *)(&stack0x00000038 + iVar5 + iVar4);
                *(undefined8 *)(&stack0x00000030 + iVar5 + iVar4) = 0x18020c1b0;
                iVar4 = fcn.18045a350();
                iVar4 = -iVar4;
                if (puVar6[4] == 0) {
                    uVar1 = puVar6[0x10];
                    *(undefined8 *)(&stack0x00000068 + iVar4 + iVar5 + iVar2 + -0x18) = uVar8;
                    if (uVar1 != 0) {
                        *(undefined8 *)(&stack0x00000030 + iVar4 + iVar5 + iVar2 + -0x18) = 0x18020c1cf;
                        func_0x00018020be10();
                    }
                    if (*(int64_t *)(puVar6 + 0x38) == *(int64_t *)(puVar6 + 0x40)) {
                        *(undefined8 *)(&stack0x00000030 + iVar4 + iVar5 + iVar2 + -0x18) = 0x18020c1e4;
                        iVar3 = fcn.18020cd80(*(int64_t *)(&stack0x00000090 + iVar4 + iVar5 + iVar2 + -0x18), 
                                              *(int64_t *)(&stack0x00000098 + iVar4 + iVar5 + iVar2 + -0x18), 
                                              *(int64_t *)(&stack0x000000a8 + iVar4 + iVar5 + iVar2 + -0x18), 
                                              *(int64_t *)(&stack0x000000b0 + iVar4 + iVar5 + iVar2 + -0x18), 
                                              *(int64_t *)(&stack0x000000b8 + iVar4 + iVar5 + iVar2 + -0x18), 
                                              *(int64_t *)(&stack0x000000d8 + iVar4 + iVar5 + iVar2 + -0x18));
                        if (iVar3 == 0) {
                            puVar6[4] = 1;
                            return;
                        }
                    }
                    *(undefined *)(*(int64_t *)(puVar6 + 0x30) + *(int64_t *)(puVar6 + 0x40)) = uVar7;
                    *(int64_t *)(puVar6 + 0x40) = *(int64_t *)(puVar6 + 0x40) + 1;
                }
                return;
            }
        } else {
            puVar6[6] = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801faed0
// Address: 0x1801faed0
// Size: 79 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801faed0(int64_t arg_28h, int64_t arg_30h, int64_t arg_48h, int64_t arg_50h)
{
    uint8_t uVar1;
    undefined8 uVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    int64_t in_RCX;
    uint8_t *puVar7;
    undefined uVar8;
    int64_t in_RDX;
    undefined8 in_R8;
    undefined8 in_R9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801faee5;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    puVar7 = (uint8_t *)(in_RCX + 0x98);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x1801faf02;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar5));
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar5) = *(undefined8 *)((int64_t)&arg_28h + iVar5);
    *(undefined8 *)((int64_t)&arg_30h + iVar5) = *(undefined8 *)((int64_t)&arg_30h + iVar5);
    iVar3 = iVar5 + 0x18;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5) = *(undefined8 *)((int64_t)aiStackX_18 + iVar5);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar5 + -8) = 0x18020ccf5;
    iVar6 = fcn.18045a350(puVar7, in_R8, in_R9);
    iVar6 = -iVar6;
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5 + -8) = 0x18020cd06;
    iVar4 = func_0x00018020bfa0();
    if (iVar4 != 0) {
        *(undefined8 *)((int64_t)aiStackX_18 + iVar6 + iVar5 + -8) = 0x18020cd1b;
        func_0x00018020c220(puVar7, in_R8, in_R9, 0);
        if ((puVar7[5] == 0) && (*(int64_t *)(puVar7 + 0x48) == 0)) {
            puVar7[6] = 2;
            if ((*puVar7 & 1) != 0) {
                uVar8 = 10;
                uVar2 = *(undefined8 *)((int64_t)&arg_48h + iVar6 + iVar5);
                *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5) = *(undefined8 *)((int64_t)&arg_50h + iVar6 + iVar5);
                *(undefined8 *)(&stack0x00000038 + iVar6 + iVar5) = *(undefined8 *)(&stack0x00000038 + iVar6 + iVar5);
                *(undefined8 *)((int64_t)&arg_30h + iVar6 + iVar5) = 0x18020c1b0;
                iVar5 = fcn.18045a350();
                iVar5 = -iVar5;
                if (puVar7[4] == 0) {
                    uVar1 = puVar7[0x10];
                    *(undefined8 *)(&stack0x00000068 + iVar5 + iVar6 + iVar3 + -0x18) = uVar2;
                    if (uVar1 != 0) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar6 + iVar3 + -0x18) = 0x18020c1cf;
                        func_0x00018020be10();
                    }
                    if (*(int64_t *)(puVar7 + 0x38) == *(int64_t *)(puVar7 + 0x40)) {
                        *(undefined8 *)((int64_t)&arg_30h + iVar5 + iVar6 + iVar3 + -0x18) = 0x18020c1e4;
                        iVar4 = fcn.18020cd80(*(int64_t *)(&stack0x00000090 + iVar5 + iVar6 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x00000098 + iVar5 + iVar6 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x000000a8 + iVar5 + iVar6 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x000000b0 + iVar5 + iVar6 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x000000b8 + iVar5 + iVar6 + iVar3 + -0x18), 
                                              *(int64_t *)(&stack0x000000d8 + iVar5 + iVar6 + iVar3 + -0x18));
                        if (iVar4 == 0) {
                            puVar7[4] = 1;
                            return;
                        }
                    }
                    *(undefined *)(*(int64_t *)(puVar7 + 0x30) + *(int64_t *)(puVar7 + 0x40)) = uVar8;
                    *(int64_t *)(puVar7 + 0x40) = *(int64_t *)(puVar7 + 0x40) + 1;
                }
                return;
            }
        } else {
            puVar7[6] = 2;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801faf20
// Address: 0x1801faf20
// Size: 63 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable arg_65h

void fcn.1801faf20(int64_t arg_28h, int64_t arg_60h, int64_t arg_68h, int64_t arg_98h, int64_t arg_a0h)
{
    uint8_t uVar1;
    char cVar2;
    undefined8 uVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t in_RCX;
    uint8_t *puVar9;
    int64_t in_RDX;
    uint64_t uVar10;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    char *pcVar11;
    undefined8 uVar12;
    uint64_t in_R8;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801faf30;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    puVar9 = (uint8_t *)(in_RCX + 0x98);
    if (in_RDX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar6) = 0x1801faf4a;
        fcn.18020c990(*(int64_t *)((int64_t)aiStackX_18 + iVar6));
    }
    uVar3 = *(undefined8 *)((int64_t)&arg_28h + iVar6);
    uVar12 = *(undefined8 *)((int64_t)aiStackX_18 + iVar6);
    *(undefined8 *)((int64_t)aiStackX_18 + iVar6) = 0x18020cd6a;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    iVar5 = 0;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar6) = uVar3;
    *(undefined8 *)(&stack0x00000040 + iVar8 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000038 + iVar8 + iVar6) = uVar12;
    *(undefined8 *)(&stack0x00000030 + iVar8 + iVar6) = unaff_R14;
    *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar6) = 0x18020c043;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    *(uint64_t *)((int64_t)&arg_68h + iVar7 + iVar8 + iVar6) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0x00000030 + iVar7 + iVar8 + iVar6);
    pcVar11 = (char *)((int64_t)&arg_60h + iVar7 + iVar8 + iVar6 + 5);
    if (((iVar5 == 0) && ((*puVar9 & 4) != 0)) && (0x1fffffffffffff < in_R8)) {
        bVar4 = true;
    } else {
        bVar4 = false;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c089;
    iVar5 = func_0x00018020bfa0();
    if (iVar5 != 0) {
        if (bVar4) {
            *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c0a0;
            func_0x00018020c1a0(puVar9, 0x22);
        }
        if (in_R8 == 0) {
            pcVar11 = "0";
        } else {
            *(undefined *)((int64_t)&arg_60h + iVar7 + iVar8 + iVar6 + 5) = 0;
            do {
                pcVar11 = pcVar11 + -1;
                uVar10 = in_R8 / 10;
                *pcVar11 = (char)in_R8 + (char)uVar10 * -10 + '0';
                in_R8 = uVar10;
            } while (uVar10 != 0);
        }
        if (puVar9[4] == 0) {
            uVar1 = puVar9[0x10];
            *(undefined8 *)((int64_t)&arg_98h + iVar7 + iVar8 + iVar6) = unaff_RBP;
            if (uVar1 != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c100;
                func_0x00018020be10(puVar9);
            }
            cVar2 = *pcVar11;
            while (cVar2 != '\0') {
                pcVar11 = pcVar11 + 1;
                if (*(int64_t *)(puVar9 + 0x38) == *(int64_t *)(puVar9 + 0x40)) {
                    *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c129;
                    iVar5 = fcn.18020cd80(*(int64_t *)(&stack0x00000088 + iVar7 + iVar8 + iVar6), 
                                          *(int64_t *)(&stack0x00000090 + iVar7 + iVar8 + iVar6), 
                                          *(int64_t *)((int64_t)&arg_a0h + iVar7 + iVar8 + iVar6), 
                                          *(int64_t *)(&stack0x000000a8 + iVar7 + iVar8 + iVar6), 
                                          *(int64_t *)(&stack0x000000b0 + iVar7 + iVar8 + iVar6), 
                                          *(int64_t *)(&stack0x000000d0 + iVar7 + iVar8 + iVar6));
                    if (iVar5 == 0) {
                        puVar9[4] = 1;
                        break;
                    }
                }
                *(char *)(*(int64_t *)(puVar9 + 0x30) + *(int64_t *)(puVar9 + 0x40)) = cVar2;
                *(int64_t *)(puVar9 + 0x40) = *(int64_t *)(puVar9 + 0x40) + 1;
                cVar2 = *pcVar11;
            }
        }
        if (bVar4) {
            *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c15f;
            func_0x00018020c1a0(puVar9, 0x22);
        }
        if ((puVar9[5] == 0) && (*(int64_t *)(puVar9 + 0x48) == 0)) {
            puVar9[6] = 2;
            if ((*puVar9 & 1) != 0) {
                *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c17f;
                func_0x00018020c1a0(puVar9, 10);
            }
        } else {
            puVar9[6] = 2;
        }
    }
    uVar10 = *(uint64_t *)((int64_t)&arg_68h + iVar7 + iVar8 + iVar6);
    *(undefined8 *)((int64_t)&arg_28h + iVar7 + iVar8 + iVar6) = 0x18020c192;
    fcn.180459870(uVar10 ^ (uint64_t)(&stack0x00000030 + iVar7 + iVar8 + iVar6));
    return;
}

// ============================================================
// Function: FUN_1801faf60
// Address: 0x1801faf60
// Size: 49 bytes
// ============================================================
void fcn.1801faf60(int64_t arg_28h, int64_t arg_a8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1a0h
                  )
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801faf6c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a8h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    if (*(int32_t *)(in_RCX + 0xf0) == 0) {
        *(undefined8 *)((int64_t)&arg_d0h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_d8h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_e0h + iVar3) = unaff_RDI;
        iVar1 = in_RCX + 0x98;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafb8;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafc7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafd6;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafe5;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801faff4;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb00b;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb017;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb02d;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x18) = 0;
        }
        if (*(int64_t *)(in_RCX + 0x20) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb046;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb052;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb068;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x20) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb07b;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb083;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb092;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb09a;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0a9;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0b8;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0c7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0cf;
        func_0x00018020c780(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0de;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0e6;
        func_0x00018020c7b0(iVar1);
        if (*(int64_t *)(in_RCX + 0x28) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0fb;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb107;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb11d;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x28) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb130;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb138;
        fcn.18020ca60(iVar1);
        if (*(int64_t *)(in_RCX + 0x48) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb158;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb15e;
            uVar2 = (*(code *)0x699f74)();
            uVar6 = (uint64_t)uVar2;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb14d;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar6 = *(uint64_t *)(in_RCX + 0x48);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb168;
        func_0x00018020cd60(iVar1, uVar6);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb170;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb178;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb187;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb18f;
        fcn.18020ca60(iVar1);
        if (*(int64_t *)(in_RCX + 0x50) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1ac;
            iVar4 = func_0x000180275060(3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1ba;
            uVar5 = func_0x000180275060(7);
            *(int64_t *)((int64_t)&var_18h + iVar3) = iVar4 + 10;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1d8;
            func_0x000180245f70((int64_t)&arg_28h + iVar3, 0x80, 0x1804b8bf0, uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1e7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb205;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb214;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb21f;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb227;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb22f;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb237;
        func_0x00018020ca90(iVar1);
        *(undefined4 *)(in_RCX + 0xf0) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb269;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_a8h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801faf91
// Address: 0x1801faf91
// Size: 712 bytes
// ============================================================
void fcn.1801faf60(int64_t arg_28h, int64_t arg_a8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1a0h
                  )
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801faf6c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a8h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    if (*(int32_t *)(in_RCX + 0xf0) == 0) {
        *(undefined8 *)((int64_t)&arg_d0h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_d8h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_e0h + iVar3) = unaff_RDI;
        iVar1 = in_RCX + 0x98;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafb8;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafc7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafd6;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafe5;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801faff4;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb00b;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb017;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb02d;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x18) = 0;
        }
        if (*(int64_t *)(in_RCX + 0x20) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb046;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb052;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb068;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x20) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb07b;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb083;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb092;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb09a;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0a9;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0b8;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0c7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0cf;
        func_0x00018020c780(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0de;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0e6;
        func_0x00018020c7b0(iVar1);
        if (*(int64_t *)(in_RCX + 0x28) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0fb;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb107;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb11d;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x28) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb130;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb138;
        fcn.18020ca60(iVar1);
        if (*(int64_t *)(in_RCX + 0x48) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb158;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb15e;
            uVar2 = (*(code *)0x699f74)();
            uVar6 = (uint64_t)uVar2;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb14d;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar6 = *(uint64_t *)(in_RCX + 0x48);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb168;
        func_0x00018020cd60(iVar1, uVar6);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb170;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb178;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb187;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb18f;
        fcn.18020ca60(iVar1);
        if (*(int64_t *)(in_RCX + 0x50) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1ac;
            iVar4 = func_0x000180275060(3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1ba;
            uVar5 = func_0x000180275060(7);
            *(int64_t *)((int64_t)&var_18h + iVar3) = iVar4 + 10;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1d8;
            func_0x000180245f70((int64_t)&arg_28h + iVar3, 0x80, 0x1804b8bf0, uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1e7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb205;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb214;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb21f;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb227;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb22f;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb237;
        func_0x00018020ca90(iVar1);
        *(undefined4 *)(in_RCX + 0xf0) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb269;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_a8h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801fb259
// Address: 0x1801fb259
// Size: 25 bytes
// ============================================================
void fcn.1801faf60(int64_t arg_28h, int64_t arg_a8h, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_1a0h
                  )
{
    int64_t iVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t in_RCX;
    uint64_t uVar6;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RDI;
    int64_t var_18h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801faf6c;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)((int64_t)&arg_a8h + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3);
    if (*(int32_t *)(in_RCX + 0xf0) == 0) {
        *(undefined8 *)((int64_t)&arg_d0h + iVar3) = unaff_RBX;
        *(undefined8 *)((int64_t)&arg_d8h + iVar3) = unaff_RBP;
        *(undefined8 *)((int64_t)&arg_e0h + iVar3) = unaff_RDI;
        iVar1 = in_RCX + 0x98;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafb8;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafc7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafd6;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fafe5;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801faff4;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        if (*(int64_t *)(in_RCX + 0x18) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb00b;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb017;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb02d;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x18) = 0;
        }
        if (*(int64_t *)(in_RCX + 0x20) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb046;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb052;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x20);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb068;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x20) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb07b;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb083;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb092;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb09a;
        fcn.18020ca60(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0a9;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0b8;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0c7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0cf;
        func_0x00018020c780(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0de;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0e6;
        func_0x00018020c7b0(iVar1);
        if (*(int64_t *)(in_RCX + 0x28) != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb0fb;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb107;
            fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar5 = *(undefined8 *)(in_RCX + 0x28);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb11d;
            fcn.180224990(uVar5, 0x1804b8ac8, 0x113);
            *(undefined8 *)(in_RCX + 0x28) = 0;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb130;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb138;
        fcn.18020ca60(iVar1);
        if (*(int64_t *)(in_RCX + 0x48) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb158;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb15e;
            uVar2 = (*(code *)0x699f74)();
            uVar6 = (uint64_t)uVar2;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb14d;
            fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
            uVar6 = *(uint64_t *)(in_RCX + 0x48);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb168;
        func_0x00018020cd60(iVar1, uVar6);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb170;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb178;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb187;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb18f;
        fcn.18020ca60(iVar1);
        if (*(int64_t *)(in_RCX + 0x50) == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1ac;
            iVar4 = func_0x000180275060(3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1ba;
            uVar5 = func_0x000180275060(7);
            *(int64_t *)((int64_t)&var_18h + iVar3) = iVar4 + 10;
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1d8;
            func_0x000180245f70((int64_t)&arg_28h + iVar3, 0x80, 0x1804b8bf0, uVar5);
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb1e7;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb205;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb214;
        fcn.18020c990(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb21f;
        fcn.18020cac0(*(int64_t *)((int64_t)&var_18h + iVar3));
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb227;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb22f;
        func_0x00018020ca90(iVar1);
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb237;
        func_0x00018020ca90(iVar1);
        *(undefined4 *)(in_RCX + 0xf0) = 1;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x1801fb269;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_a8h + iVar3) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar3));
    return;
}

// ============================================================
// Function: FUN_1801fb280
// Address: 0x1801fb280
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801fb280(int64_t arg_28h)
{
    undefined4 uVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    int64_t in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fb290;
    iVar3 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801fb2a8;
    iVar4 = fcn.18020d3c0(in_RCX + 0x10, in_RDX, 1);
    if (iVar4 == 0) {
        *in_R9 = 0;
        return 0;
    }
    uVar1 = *(undefined4 *)(iVar4 + 0x60);
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x1801fb2c3;
    uVar2 = fcn.1801f9ab0(uVar1);
    *in_R9 = (uint64_t)uVar2 + in_R8;
    return 1;
}

// ============================================================
// Function: FUN_1801fb2e0
// Address: 0x1801fb2e0
// Size: 102 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.1801fb2e0(int64_t arg_28h)
{
    undefined4 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t in_RCX;
    undefined8 in_RDX;
    uint64_t in_R8;
    int64_t *in_R9;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fb2f0;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801fb308;
    iVar3 = fcn.18020d3c0(in_RCX + 0x10, in_RDX, 1);
    if (iVar3 != 0) {
        uVar1 = *(undefined4 *)(iVar3 + 0x60);
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x1801fb315;
        uVar4 = fcn.1801f9ab0(uVar1);
        if ((uVar4 & 0xffffffff) < in_R8) {
            *in_R9 = in_R8 - (uVar4 & 0xffffffff);
            return 1;
        }
    }
    *in_R9 = 0;
    return 0;
}

// ============================================================
// Function: FUN_1801fb350
// Address: 0x1801fb350
// Size: 44 bytes
// ============================================================
undefined8 fcn.1801fb350(undefined8 param_1, uint32_t param_2)
{
    int64_t iVar1;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801fb35a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (3 < param_2) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801fb372;
    fcn.18020d2a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000030 + iVar1));
    return 1;
}

// ============================================================
// Function: FUN_1801fb440
// Address: 0x1801fb440
// Size: 85 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel

void fcn.1801fb440(int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined8 unaff_RDI;
    int64_t *piVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801fb451;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x00000530 + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5);
    piVar10 = (int64_t *)0x0;
    if ((*(int64_t *)(in_RCX + 0x388) != 0) && (*(int64_t *)(in_RCX + 0x350) != 0)) {
        *(undefined8 *)(&stack0x00000578 + iVar5) = unaff_RSI;
        *(undefined8 *)(&stack0x00000580 + iVar5) = unaff_RDI;
        *(undefined8 *)(&stack0x00000588 + iVar5) = unaff_R14;
        *(undefined8 *)(&stack0x00000540 + iVar5) = unaff_R15;
        while (piVar7 = *(int64_t **)(in_RCX + 0x388), piVar7 != (int64_t *)0x0) {
            piVar11 = (int64_t *)(&stack0x00000038 + iVar5);
            piVar6 = piVar10;
            do {
                if ((int64_t *)0x1f < piVar6) break;
                piVar11[-1] = (int64_t)(piVar7 + 0xb);
                *piVar11 = piVar7[2];
                piVar11[3] = 0;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb4fd;
                iVar3 = func_0x00018026bea0(piVar7 + 4);
                piVar8 = piVar7 + 4;
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar11[1] = (int64_t)piVar8;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb513;
                iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar7 + 0x3c));
                piVar8 = (int64_t *)((int64_t)piVar7 + 0x3c);
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar6 = (int64_t *)((int64_t)piVar6 + 1);
                piVar11[2] = (int64_t)piVar8;
                piVar11 = piVar11 + 5;
                piVar7 = (int64_t *)*piVar7;
            } while (piVar7 != (int64_t *)0x0);
            if (piVar6 == (int64_t *)0x0) break;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb53a;
            func_0x000180229b10();
            uVar1 = *(undefined8 *)(in_RCX + 0x350);
            *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)&var_20h + iVar5;
            *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb563;
            iVar3 = func_0x00018021af90(uVar1, (int64_t)&arg_30h + iVar5, 0x28, piVar6);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb641;
                uVar4 = func_0x000180220a00();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb648;
                iVar3 = func_0x000180219eb0(uVar4);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb658;
                    func_0x000180229900();
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb651;
                    func_0x0001802299d0();
                }
                break;
            }
            if (*(int64_t *)((int64_t)&var_20h + iVar5) == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5f3;
                func_0x000180229900();
                break;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb577;
            func_0x000180229900();
            if (*(int64_t *)((int64_t)&var_20h + iVar5) != 0) {
                puVar9 = (undefined8 *)((int64_t)&arg_30h + iVar5);
                piVar7 = piVar10;
                do {
                    pcVar2 = *(code **)(in_RCX + 1000);
                    if (pcVar2 != (code *)0x0) {
                        uVar1 = *puVar9;
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x3f0);
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)(in_RCX + 0x3f8);
                        *(undefined8 *)(&stack0x00000000 + iVar5) = puVar9[1];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5cd;
                        (*pcVar2)(1, 1, 0x200, uVar1);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5d5;
                    func_0x0001801fc1e0(in_RCX);
                    piVar7 = (int64_t *)((int64_t)piVar7 + 1);
                    puVar9 = puVar9 + 5;
                } while (piVar7 < *(int64_t **)((int64_t)&var_20h + iVar5));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb62e;
    fcn.180459870(*(uint64_t *)(&stack0x00000530 + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801fb495
// Address: 0x1801fb495
// Size: 393 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel

void fcn.1801fb440(int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined8 unaff_RDI;
    int64_t *piVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801fb451;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x00000530 + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5);
    piVar10 = (int64_t *)0x0;
    if ((*(int64_t *)(in_RCX + 0x388) != 0) && (*(int64_t *)(in_RCX + 0x350) != 0)) {
        *(undefined8 *)(&stack0x00000578 + iVar5) = unaff_RSI;
        *(undefined8 *)(&stack0x00000580 + iVar5) = unaff_RDI;
        *(undefined8 *)(&stack0x00000588 + iVar5) = unaff_R14;
        *(undefined8 *)(&stack0x00000540 + iVar5) = unaff_R15;
        while (piVar7 = *(int64_t **)(in_RCX + 0x388), piVar7 != (int64_t *)0x0) {
            piVar11 = (int64_t *)(&stack0x00000038 + iVar5);
            piVar6 = piVar10;
            do {
                if ((int64_t *)0x1f < piVar6) break;
                piVar11[-1] = (int64_t)(piVar7 + 0xb);
                *piVar11 = piVar7[2];
                piVar11[3] = 0;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb4fd;
                iVar3 = func_0x00018026bea0(piVar7 + 4);
                piVar8 = piVar7 + 4;
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar11[1] = (int64_t)piVar8;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb513;
                iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar7 + 0x3c));
                piVar8 = (int64_t *)((int64_t)piVar7 + 0x3c);
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar6 = (int64_t *)((int64_t)piVar6 + 1);
                piVar11[2] = (int64_t)piVar8;
                piVar11 = piVar11 + 5;
                piVar7 = (int64_t *)*piVar7;
            } while (piVar7 != (int64_t *)0x0);
            if (piVar6 == (int64_t *)0x0) break;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb53a;
            func_0x000180229b10();
            uVar1 = *(undefined8 *)(in_RCX + 0x350);
            *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)&var_20h + iVar5;
            *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb563;
            iVar3 = func_0x00018021af90(uVar1, (int64_t)&arg_30h + iVar5, 0x28, piVar6);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb641;
                uVar4 = func_0x000180220a00();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb648;
                iVar3 = func_0x000180219eb0(uVar4);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb658;
                    func_0x000180229900();
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb651;
                    func_0x0001802299d0();
                }
                break;
            }
            if (*(int64_t *)((int64_t)&var_20h + iVar5) == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5f3;
                func_0x000180229900();
                break;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb577;
            func_0x000180229900();
            if (*(int64_t *)((int64_t)&var_20h + iVar5) != 0) {
                puVar9 = (undefined8 *)((int64_t)&arg_30h + iVar5);
                piVar7 = piVar10;
                do {
                    pcVar2 = *(code **)(in_RCX + 1000);
                    if (pcVar2 != (code *)0x0) {
                        uVar1 = *puVar9;
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x3f0);
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)(in_RCX + 0x3f8);
                        *(undefined8 *)(&stack0x00000000 + iVar5) = puVar9[1];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5cd;
                        (*pcVar2)(1, 1, 0x200, uVar1);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5d5;
                    func_0x0001801fc1e0(in_RCX);
                    piVar7 = (int64_t *)((int64_t)piVar7 + 1);
                    puVar9 = puVar9 + 5;
                } while (piVar7 < *(int64_t **)((int64_t)&var_20h + iVar5));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb62e;
    fcn.180459870(*(uint64_t *)(&stack0x00000530 + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801fb61e
// Address: 0x1801fb61e
// Size: 30 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel

void fcn.1801fb440(int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined8 unaff_RDI;
    int64_t *piVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801fb451;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x00000530 + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5);
    piVar10 = (int64_t *)0x0;
    if ((*(int64_t *)(in_RCX + 0x388) != 0) && (*(int64_t *)(in_RCX + 0x350) != 0)) {
        *(undefined8 *)(&stack0x00000578 + iVar5) = unaff_RSI;
        *(undefined8 *)(&stack0x00000580 + iVar5) = unaff_RDI;
        *(undefined8 *)(&stack0x00000588 + iVar5) = unaff_R14;
        *(undefined8 *)(&stack0x00000540 + iVar5) = unaff_R15;
        while (piVar7 = *(int64_t **)(in_RCX + 0x388), piVar7 != (int64_t *)0x0) {
            piVar11 = (int64_t *)(&stack0x00000038 + iVar5);
            piVar6 = piVar10;
            do {
                if ((int64_t *)0x1f < piVar6) break;
                piVar11[-1] = (int64_t)(piVar7 + 0xb);
                *piVar11 = piVar7[2];
                piVar11[3] = 0;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb4fd;
                iVar3 = func_0x00018026bea0(piVar7 + 4);
                piVar8 = piVar7 + 4;
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar11[1] = (int64_t)piVar8;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb513;
                iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar7 + 0x3c));
                piVar8 = (int64_t *)((int64_t)piVar7 + 0x3c);
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar6 = (int64_t *)((int64_t)piVar6 + 1);
                piVar11[2] = (int64_t)piVar8;
                piVar11 = piVar11 + 5;
                piVar7 = (int64_t *)*piVar7;
            } while (piVar7 != (int64_t *)0x0);
            if (piVar6 == (int64_t *)0x0) break;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb53a;
            func_0x000180229b10();
            uVar1 = *(undefined8 *)(in_RCX + 0x350);
            *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)&var_20h + iVar5;
            *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb563;
            iVar3 = func_0x00018021af90(uVar1, (int64_t)&arg_30h + iVar5, 0x28, piVar6);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb641;
                uVar4 = func_0x000180220a00();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb648;
                iVar3 = func_0x000180219eb0(uVar4);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb658;
                    func_0x000180229900();
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb651;
                    func_0x0001802299d0();
                }
                break;
            }
            if (*(int64_t *)((int64_t)&var_20h + iVar5) == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5f3;
                func_0x000180229900();
                break;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb577;
            func_0x000180229900();
            if (*(int64_t *)((int64_t)&var_20h + iVar5) != 0) {
                puVar9 = (undefined8 *)((int64_t)&arg_30h + iVar5);
                piVar7 = piVar10;
                do {
                    pcVar2 = *(code **)(in_RCX + 1000);
                    if (pcVar2 != (code *)0x0) {
                        uVar1 = *puVar9;
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x3f0);
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)(in_RCX + 0x3f8);
                        *(undefined8 *)(&stack0x00000000 + iVar5) = puVar9[1];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5cd;
                        (*pcVar2)(1, 1, 0x200, uVar1);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5d5;
                    func_0x0001801fc1e0(in_RCX);
                    piVar7 = (int64_t *)((int64_t)piVar7 + 1);
                    puVar9 = puVar9 + 5;
                } while (piVar7 < *(int64_t **)((int64_t)&var_20h + iVar5));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb62e;
    fcn.180459870(*(uint64_t *)(&stack0x00000530 + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801fb63c
// Address: 0x1801fb63c
// Size: 35 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_530h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_578h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_580h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_588h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_540h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5c8h because it doesn't fit into ProtoModel

void fcn.1801fb440(int64_t arg_30h)
{
    undefined8 uVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int64_t in_RCX;
    undefined8 unaff_RSI;
    int64_t *piVar6;
    int64_t *piVar7;
    undefined8 unaff_RDI;
    int64_t *piVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    int64_t *piVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined8 uStack_28;
    
    uStack_28 = 0x1801fb451;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(uint64_t *)(&stack0x00000530 + iVar5) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5);
    piVar10 = (int64_t *)0x0;
    if ((*(int64_t *)(in_RCX + 0x388) != 0) && (*(int64_t *)(in_RCX + 0x350) != 0)) {
        *(undefined8 *)(&stack0x00000578 + iVar5) = unaff_RSI;
        *(undefined8 *)(&stack0x00000580 + iVar5) = unaff_RDI;
        *(undefined8 *)(&stack0x00000588 + iVar5) = unaff_R14;
        *(undefined8 *)(&stack0x00000540 + iVar5) = unaff_R15;
        while (piVar7 = *(int64_t **)(in_RCX + 0x388), piVar7 != (int64_t *)0x0) {
            piVar11 = (int64_t *)(&stack0x00000038 + iVar5);
            piVar6 = piVar10;
            do {
                if ((int64_t *)0x1f < piVar6) break;
                piVar11[-1] = (int64_t)(piVar7 + 0xb);
                *piVar11 = piVar7[2];
                piVar11[3] = 0;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb4fd;
                iVar3 = func_0x00018026bea0(piVar7 + 4);
                piVar8 = piVar7 + 4;
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar11[1] = (int64_t)piVar8;
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb513;
                iVar3 = func_0x00018026bea0((int64_t *)((int64_t)piVar7 + 0x3c));
                piVar8 = (int64_t *)((int64_t)piVar7 + 0x3c);
                if (iVar3 == 0) {
                    piVar8 = piVar10;
                }
                piVar6 = (int64_t *)((int64_t)piVar6 + 1);
                piVar11[2] = (int64_t)piVar8;
                piVar11 = piVar11 + 5;
                piVar7 = (int64_t *)*piVar7;
            } while (piVar7 != (int64_t *)0x0);
            if (piVar6 == (int64_t *)0x0) break;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb53a;
            func_0x000180229b10();
            uVar1 = *(undefined8 *)(in_RCX + 0x350);
            *(int64_t *)((int64_t)&var_8h + iVar5) = (int64_t)&var_20h + iVar5;
            *(undefined8 *)(&stack0x00000000 + iVar5) = 0;
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb563;
            iVar3 = func_0x00018021af90(uVar1, (int64_t)&arg_30h + iVar5, 0x28, piVar6);
            if (iVar3 == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb641;
                uVar4 = func_0x000180220a00();
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb648;
                iVar3 = func_0x000180219eb0(uVar4);
                if (iVar3 == 0) {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb658;
                    func_0x000180229900();
                } else {
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb651;
                    func_0x0001802299d0();
                }
                break;
            }
            if (*(int64_t *)((int64_t)&var_20h + iVar5) == 0) {
                *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5f3;
                func_0x000180229900();
                break;
            }
            *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb577;
            func_0x000180229900();
            if (*(int64_t *)((int64_t)&var_20h + iVar5) != 0) {
                puVar9 = (undefined8 *)((int64_t)&arg_30h + iVar5);
                piVar7 = piVar10;
                do {
                    pcVar2 = *(code **)(in_RCX + 1000);
                    if (pcVar2 != (code *)0x0) {
                        uVar1 = *puVar9;
                        *(undefined8 *)((int64_t)&var_10h + iVar5) = *(undefined8 *)(in_RCX + 0x3f0);
                        *(undefined8 *)((int64_t)&var_8h + iVar5) = *(undefined8 *)(in_RCX + 0x3f8);
                        *(undefined8 *)(&stack0x00000000 + iVar5) = puVar9[1];
                        *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5cd;
                        (*pcVar2)(1, 1, 0x200, uVar1);
                    }
                    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb5d5;
                    func_0x0001801fc1e0(in_RCX);
                    piVar7 = (int64_t *)((int64_t)piVar7 + 1);
                    puVar9 = puVar9 + 5;
                } while (piVar7 < *(int64_t **)((int64_t)&var_20h + iVar5));
            }
        }
    }
    *(undefined8 *)((int64_t)&uStack_28 + iVar5) = 0x1801fb62e;
    fcn.180459870(*(uint64_t *)(&stack0x00000530 + iVar5) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar5));
    return;
}

// ============================================================
// Function: FUN_1801fb660
// Address: 0x1801fb660
// Size: 26 bytes
// ============================================================
void fcn.1801fb660(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fb674;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        puVar1 = *(undefined8 **)(arg1 + 0x388);
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
        while (puVar1 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)*puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6a5;
            fcn.180224990(puVar1, 0x1804b8c10, 0x8c);
            puVar1 = puVar2;
        }
        puVar1 = *(undefined8 **)(arg1 + 0x370);
        while (puVar1 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)*puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6d5;
            fcn.180224990(puVar1, 0x1804b8c10, 0x8c);
            puVar1 = puVar2;
        }
        uVar3 = *(undefined8 *)(arg1 + 0x3b0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6f6;
        fcn.180224990(uVar3, 0x1804b8c10, 0x9b);
        uVar5 = 0;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb70b;
            fcn.18020d2a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
            uVar5 = uVar5 + 1;
        } while (uVar5 < 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb731;
        fcn.180224990(arg1, 0x1804b8c10, 0xa1);
    }
    return;
}

// ============================================================
// Function: FUN_1801fb67a
// Address: 0x1801fb67a
// Size: 188 bytes
// ============================================================
void fcn.1801fb660(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fb674;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        puVar1 = *(undefined8 **)(arg1 + 0x388);
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
        while (puVar1 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)*puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6a5;
            fcn.180224990(puVar1, 0x1804b8c10, 0x8c);
            puVar1 = puVar2;
        }
        puVar1 = *(undefined8 **)(arg1 + 0x370);
        while (puVar1 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)*puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6d5;
            fcn.180224990(puVar1, 0x1804b8c10, 0x8c);
            puVar1 = puVar2;
        }
        uVar3 = *(undefined8 *)(arg1 + 0x3b0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6f6;
        fcn.180224990(uVar3, 0x1804b8c10, 0x9b);
        uVar5 = 0;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb70b;
            fcn.18020d2a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
            uVar5 = uVar5 + 1;
        } while (uVar5 < 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb731;
        fcn.180224990(arg1, 0x1804b8c10, 0xa1);
    }
    return;
}

// ============================================================
// Function: FUN_1801fb736
// Address: 0x1801fb736
// Size: 1 bytes
// ============================================================
void fcn.1801fb660(int64_t arg1, int64_t arg_28h, int64_t arg_30h)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    undefined8 uVar3;
    int64_t iVar4;
    uint32_t uVar5;
    undefined8 unaff_RBX;
    undefined8 unaff_RSI;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x1801fb674;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        *(undefined8 *)((int64_t)&arg_28h + iVar4) = unaff_RBX;
        puVar1 = *(undefined8 **)(arg1 + 0x388);
        *(undefined8 *)((int64_t)&arg_30h + iVar4) = unaff_RSI;
        while (puVar1 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)*puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6a5;
            fcn.180224990(puVar1, 0x1804b8c10, 0x8c);
            puVar1 = puVar2;
        }
        puVar1 = *(undefined8 **)(arg1 + 0x370);
        while (puVar1 != (undefined8 *)0x0) {
            puVar2 = (undefined8 *)*puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6d5;
            fcn.180224990(puVar1, 0x1804b8c10, 0x8c);
            puVar1 = puVar2;
        }
        uVar3 = *(undefined8 *)(arg1 + 0x3b0);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb6f6;
        fcn.180224990(uVar3, 0x1804b8c10, 0x9b);
        uVar5 = 0;
        do {
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb70b;
            fcn.18020d2a0(*(int64_t *)((int64_t)aiStackX_18 + iVar4), *(int64_t *)((int64_t)&arg_28h + iVar4));
            uVar5 = uVar5 + 1;
        } while (uVar5 < 4);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x1801fb731;
        fcn.180224990(arg1, 0x1804b8c10, 0xa1);
    }
    return;
}

// ============================================================
// Function: FUN_1801fb740
// Address: 0x1801fb740
// Size: 54 bytes
// ============================================================
undefined8 fcn.1801fb740(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801fb74a;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x1801fb75c;
    iVar1 = fcn.18020d3c0(param_1 + 0x10, param_2, 1);
    if (iVar1 == 0) {
        return 0xffffffffffffffff;
    }
    return *(undefined8 *)(iVar1 + 0x58);
}

// ============================================================
// Function: FUN_1801fb780
// Address: 0x1801fb780
// Size: 57 bytes
// ============================================================
undefined8 fcn.1801fb780(int64_t param_1, undefined8 param_2)
{
    int32_t iVar1;
    int64_t iVar2;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801fb78a;
    iVar2 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar2) = 0x1801fb79c;
    iVar2 = fcn.18020d3c0(param_1 + 0x10, param_2, 1);
    if (iVar2 == 0) {
        return 0xffffffffffffffff;
    }
    iVar1 = *(int32_t *)(iVar2 + 0x60);
    if (iVar1 == 1) {
        return 0x800000;
    }
    if (iVar1 == 2) {
        return 0x800000;
    }
    if (iVar1 != 3) {
        return 0xffffffffffffffff;
    }
    return 0xfffffffffffffffe;
}

// ============================================================
// Function: FUN_1801fb7e0
// Address: 0x1801fb7e0
// Size: 43 bytes
// ============================================================
bool fcn.1801fb7e0(int64_t param_1, undefined8 param_2)
{
    int64_t iVar1;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801fb7ea;
    iVar1 = fcn.18045a350();
    *(undefined8 *)((int64_t)&uStack_8 - iVar1) = 0x1801fb7fc;
    iVar1 = fcn.18020d3c0(param_1 + 0x10, param_2, 1);
    return iVar1 != 0;
}

// ============================================================
// Function: FUN_1801fb810
// Address: 0x1801fb810
// Size: 128 bytes
// ============================================================
undefined8 * fcn.1801fb810(undefined8 *param_1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x1801fb81c;
    iVar1 = fcn.18045a350();
    if (0x4af < (uint64_t)param_1[3]) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar1) = 0x1801fb843;
        puVar2 = (undefined8 *)fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + -iVar1));
        if (puVar2 != (undefined8 *)0x0) {
            *puVar2 = *param_1;
            puVar2[1] = param_1[1];
            puVar2[0x6a] = param_1[2];
            puVar2[0x6d] = param_1[3];
            puVar2[0x6b] = param_1[4];
            puVar2[0x6c] = param_1[5];
            return puVar2;
        }
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_1801fb890
// Address: 0x1801fb890
// Size: 101 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable arg_3ch
// WARNING: [rz-ghidra] Detected overlap for variable arg_44h

undefined8
fcn.1801fb890(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_80h,
             int64_t arg_88h)
{
    int64_t iVar1;
    undefined8 uVar2;
    uint32_t in_EDX;
    undefined4 in_R8D;
    undefined8 in_R9;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x1801fb89a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (3 < in_EDX) {
        return 0;
    }
    *(undefined4 *)((int64_t)&arg_48h + iVar1) = 1;
    *(undefined *)((int64_t)&arg_40h + iVar1) = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar1) = *(undefined8 *)((int64_t)&arg_88h + iVar1);
    *(undefined8 *)((int64_t)&arg_30h + iVar1) = *(undefined8 *)((int64_t)&arg_80h + iVar1);
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = in_R9;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = in_R8D;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x1801fb8f0;
    uVar2 = fcn.18020d890(*(int64_t *)((int64_t)&var_20h + iVar1), *(int64_t *)((int64_t)&arg_28h + iVar1), 
                          *(int64_t *)((int64_t)&arg_30h + iVar1), *(int64_t *)((int64_t)&arg_38h + iVar1), 
                          *(int64_t *)((int64_t)&arg_48h + iVar1), *(int64_t *)(&stack0x00000050 + iVar1), 
                          *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x000000a0 + iVar1), 
                          *(int64_t *)(&stack0x000000e0 + iVar1), *(int64_t *)(&stack0x000000f8 + iVar1), 
                          *(int64_t *)(&stack0x00000160 + iVar1), *(int64_t *)(&stack0x00000168 + iVar1), 
                          *(int64_t *)(&stack0x00000170 + iVar1), *(int64_t *)(&stack0x00000178 + iVar1), 
                          *(int64_t *)(&stack0x00000180 + iVar1), *(int64_t *)(&stack0x00000188 + iVar1));
    return uVar2;
}

// ============================================================
// Function: FUN_1801fb940
// Address: 0x1801fb940
// Size: 31 bytes
// ============================================================
void fcn.1801fb940(int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h,
                  int64_t arg_68h, int64_t arg_88h, int64_t arg_c8h, int64_t arg_d8h, int64_t arg_108h, int64_t arg_110h
                  )
{
    int64_t iVar1;
    char cVar2;
    undefined4 uVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    uint32_t uVar7;
    int32_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    int64_t in_RCX;
    uint64_t uVar11;
    undefined8 unaff_RBX;
    int64_t iVar12;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    undefined8 unaff_R14;
    undefined8 uStackX_10;
    int64_t var_18h;
    undefined8 uStackX_20;
    
    iVar9 = fcn.18045a350();
    iVar9 = -iVar9;
    in_RCX = in_RCX + 0x10;
    uVar11 = 3;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar9) = unaff_RBX;
    *(undefined8 *)((int64_t)&uStackX_20 + iVar9 + -8) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStackX_10 + iVar9) = 0x18020d61d;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&arg_c8h + iVar10 + iVar9) =
         *(uint64_t *)0x1806a3940 ^ (int64_t)&uStackX_20 + iVar10 + iVar9 + -8;
    if ((((uint32_t)uVar11 < 4) && (iVar12 = (uVar11 & 0xffffffff) * 0xd0 + in_RCX, iVar12 != 0)) &&
       ((uint32_t)uVar11 == 3)) {
        if (*(char *)(iVar12 + 0x68) == '\x01') {
            if (*(char *)(iVar12 + 0x69) == '\0') {
                *(int64_t *)(iVar12 + 0x50) = *(int64_t *)(iVar12 + 0x50) + 1;
                *(undefined *)(iVar12 + 0x68) = 2;
            } else {
                uVar3 = *(undefined4 *)(iVar12 + 0x60);
                *(undefined8 *)((int64_t)&arg_108h + iVar10 + iVar9) = unaff_RBP;
                *(undefined8 *)((int64_t)&arg_110h + iVar10 + iVar9) = unaff_RSI;
                *(undefined8 *)((int64_t)&arg_d8h + iVar10 + iVar9) = unaff_R14;
                *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d6cd;
                uVar7 = func_0x0001801f9c00(uVar3);
                uVar4 = *(undefined8 *)(iVar12 + 0x28);
                iVar1 = iVar12 + 0x8a;
                uVar5 = *(undefined8 *)(iVar12 + 0x48);
                uVar6 = *(undefined8 *)(iVar12 + 0x40);
                *(undefined4 *)((int64_t)&arg_68h + iVar10 + iVar9) = 1;
                uVar11 = (uint64_t)uVar7;
                *(uint64_t *)((int64_t)&arg_60h + iVar10 + iVar9) = uVar11;
                *(int64_t *)((int64_t)&arg_58h + iVar10 + iVar9) = (int64_t)&arg_88h + iVar10 + iVar9;
                *(undefined8 *)((int64_t)&arg_50h + iVar10 + iVar9) = 0;
                *(undefined8 *)((int64_t)&arg_48h + iVar10 + iVar9) = 0;
                *(undefined8 *)((int64_t)&arg_40h + iVar10 + iVar9) = 7;
                *(undefined8 *)((int64_t)&arg_38h + iVar10 + iVar9) = 0x1804ba528;
                *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d723;
                iVar8 = func_0x0001801b4180(uVar6, uVar5, uVar4, iVar1);
                if (iVar8 != 0) {
                    cVar2 = *(char *)(iVar12 + 0x68);
                    if (((cVar2 == '\x01') || (cVar2 == '\x02')) ||
                       ((cVar2 == '\x03' && ((~*(uint32_t *)(iVar12 + 0x50) & 1) != 0)))) {
                        if (*(int64_t *)(iVar12 + 0x30) != 0) {
                            *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d755;
                            func_0x000180211410();
                            *(undefined8 *)(iVar12 + 0x30) = 0;
                        }
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d767;
                        func_0x000180244fc0(iVar12 + 0x6a, 0x10);
                    }
                    *(uint64_t *)((int64_t)&arg_40h + iVar10 + iVar9) = uVar11;
                    *(int64_t *)((int64_t)&arg_38h + iVar10 + iVar9) = iVar1;
                    *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d784;
                    iVar8 = func_0x00018020ce40(in_RCX, 3, 1, 0);
                    if (iVar8 != 0) {
                        *(int64_t *)(iVar12 + 0x50) = *(int64_t *)(iVar12 + 0x50) + 1;
                        *(undefined8 *)(iVar12 + 0x58) = 0;
                        *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d7a0;
                        fcn.180498030(iVar1, (int64_t)&arg_88h + iVar10 + iVar9, uVar11);
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d664;
            fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_40h + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d67c;
            fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_40h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9), 
                          *(int64_t *)((int64_t)&arg_68h + iVar10 + iVar9));
            *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d68e;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar10 + iVar9));
        }
    } else {
        *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d7e0;
        fcn.180229480(*(int64_t *)((int64_t)&arg_38h + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_40h + iVar10 + iVar9)
                     );
        *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d7f8;
        fcn.1802295a0(*(int64_t *)((int64_t)&arg_38h + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_40h + iVar10 + iVar9)
                      , *(int64_t *)((int64_t)&arg_48h + iVar10 + iVar9), 
                      *(int64_t *)((int64_t)&arg_50h + iVar10 + iVar9), *(int64_t *)((int64_t)&arg_68h + iVar10 + iVar9)
                     );
        *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d80a;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_58h + iVar10 + iVar9));
    }
    *(undefined8 *)((int64_t)&uStackX_10 + iVar10 + iVar9) = 0x18020d7cd;
    fcn.180459870(*(uint64_t *)((int64_t)&arg_c8h + iVar10 + iVar9) ^ (int64_t)&uStackX_20 + iVar10 + iVar9 + -8);
    return;
}

// ============================================================
// Function: FUN_1801fb960
// Address: 0x1801fb960
// Size: 1096 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

undefined8 fcn.1801fb960(int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h)
{
    uint32_t uVar1;
    uint64_t uVar2;
    code *pcVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    undefined (*pauVar7) [16];
    uint32_t *puVar8;
    undefined8 uVar9;
    uint32_t uVar10;
    int64_t in_RCX;
    uint32_t *puVar11;
    uint32_t **in_RDX;
    uint32_t *puVar12;
    int64_t iVar13;
    undefined8 uVar14;
    int64_t var_8h;
    undefined8 uStack_40;
    int64_t var_18h;
    int64_t var_10h;
    
    uStack_40 = 0x1801fb97a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar1 = *(uint32_t *)(in_RDX + 6);
    if (*in_RDX == (uint32_t *)0x0) {
        return 0;
    }
    uVar10 = **in_RDX & 0xff;
    uVar14 = 0;
    if (uVar10 == 1) {
code_r0x0001801fb9ee:
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fb9fa;
        iVar5 = func_0x00018020d3f0(in_RCX + 0x10, uVar14);
        if (iVar5 != 1) {
            return 0;
        }
    } else {
        if (uVar10 == 2) {
            uVar14 = 1;
            goto code_r0x0001801fb9ee;
        }
        if (uVar10 == 3) {
            uVar14 = 2;
            goto code_r0x0001801fb9ee;
        }
        if (uVar10 == 5) {
            uVar14 = 3;
            goto code_r0x0001801fb9ee;
        }
        if ((uVar10 - 4 & 0xfffffffd) != 0) {
            return 0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fb9cb;
        func_0x0001801fb380(in_RCX);
        uVar14 = 4;
    }
    iVar13 = *(int64_t *)(in_RCX + 0x3b0);
    if (iVar13 == 0) goto code_r0x0001801fbac0;
    if (*(int64_t *)(iVar13 + 0x10) == 0) goto code_r0x0001801fbac0;
    puVar8 = in_RDX[3];
    iVar13 = iVar13 + 0x20;
    bVar4 = true;
    if (iVar13 == 0) {
code_r0x0001801fba3b:
        if (puVar8 != (uint32_t *)0x0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fba48;
            iVar5 = func_0x00018026bea0(puVar8);
            if (iVar5 != 0) {
                if (iVar13 == 0) goto code_r0x0001801fbab8;
                goto code_r0x0001801fba51;
            }
        }
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fba37;
        iVar5 = func_0x00018026bea0(iVar13);
        if (iVar5 == 0) goto code_r0x0001801fba3b;
code_r0x0001801fba51:
        if (puVar8 == (uint32_t *)0x0) goto code_r0x0001801fbab8;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fba67;
        iVar5 = func_0x000180497f30(iVar13, puVar8, 0x1c);
        if (iVar5 != 0) goto code_r0x0001801fbab8;
    }
    puVar8 = in_RDX[4];
    iVar13 = *(int64_t *)(in_RCX + 0x3b0) + 0x3c;
    if (iVar13 == 0) {
code_r0x0001801fba88:
        if (puVar8 == (uint32_t *)0x0) goto code_r0x0001801fbad0;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fba95;
        iVar5 = func_0x00018026bea0(puVar8);
        if (iVar5 == 0) goto code_r0x0001801fbad0;
        if (iVar13 == 0) goto code_r0x0001801fbab8;
    } else {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fba84;
        iVar5 = func_0x00018026bea0(iVar13);
        if (iVar5 == 0) goto code_r0x0001801fba88;
    }
    if (puVar8 != (uint32_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbab4;
        iVar5 = func_0x000180497f30(iVar13, puVar8, 0x1c);
        if (iVar5 == 0) goto code_r0x0001801fbad0;
    }
code_r0x0001801fbab8:
    while( true ) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbac0;
        func_0x0001801fb380(in_RCX);
code_r0x0001801fbac0:
        bVar4 = false;
code_r0x0001801fbad0:
        pauVar7 = *(undefined (**) [16])(in_RCX + 0x3b0);
        if (pauVar7 == (undefined (*) [16])0x0) {
            pauVar7 = *(undefined (**) [16])(in_RCX + 0x370);
            uVar2 = *(uint64_t *)(in_RCX + 0x368);
            if (pauVar7 == (undefined (*) [16])0x0) {
                if (0xffffffffffffffa6 < uVar2) {
                    return 0;
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbb13;
                pauVar7 = (undefined (*) [16])
                          fcn.1802248d0(*(int64_t *)((int64_t)&var_18h + iVar6), *(int64_t *)((int64_t)&var_10h + iVar6)
                                       );
                if (pauVar7 == (undefined (*) [16])0x0) {
                    return 0;
                }
                *pauVar7 = ZEXT816(0);
                *(uint64_t *)(pauVar7[1] + 8) = uVar2;
                *(undefined8 *)pauVar7[1] = 0;
                if (*(undefined (***) [16])(in_RCX + 0x378) != (undefined (**) [16])0x0) {
                    **(undefined (***) [16])(in_RCX + 0x378) = pauVar7;
                }
                *(undefined8 *)(*pauVar7 + 8) = *(undefined8 *)(in_RCX + 0x378);
                *(undefined8 *)*pauVar7 = 0;
                *(undefined (**) [16])(in_RCX + 0x378) = pauVar7;
                if (*(int64_t *)(in_RCX + 0x370) == 0) {
                    *(undefined (**) [16])(in_RCX + 0x370) = pauVar7;
                }
                *(int64_t *)(in_RCX + 0x380) = *(int64_t *)(in_RCX + 0x380) + 1;
            }
            if (*(undefined (**) [16])(in_RCX + 0x370) == pauVar7) {
                *(undefined8 *)(in_RCX + 0x370) = *(undefined8 *)*pauVar7;
            }
            if (*(undefined (**) [16])(in_RCX + 0x378) == pauVar7) {
                *(undefined8 *)(in_RCX + 0x378) = *(undefined8 *)(*pauVar7 + 8);
            }
            if (*(undefined8 **)(*pauVar7 + 8) != (undefined8 *)0x0) {
                **(undefined8 **)(*pauVar7 + 8) = *(undefined8 *)*pauVar7;
            }
            if (*(int64_t *)*pauVar7 != 0) {
                *(undefined8 *)(*(int64_t *)*pauVar7 + 8) = *(undefined8 *)(*pauVar7 + 8);
            }
            *(int64_t *)(in_RCX + 0x380) = *(int64_t *)(in_RCX + 0x380) + -1;
            *pauVar7 = ZEXT816(0);
            *(undefined (**) [16])(in_RCX + 0x3b0) = pauVar7;
            *(undefined8 *)(in_RCX + 0x3b8) = 0;
            *(undefined8 *)pauVar7[1] = 0;
        }
        if (*(uint64_t *)(pauVar7[1] + 8) < *(uint64_t *)(in_RCX + 0x368)) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbbe7;
            iVar13 = func_0x0001801fc290(in_RCX, 0, pauVar7);
            if (iVar13 == 0) {
                return 0;
            }
        }
        if (!bVar4) {
            if (in_RDX[3] == (uint32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbc25;
                func_0x00018026be30(pauVar7 + 2);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbc02;
                iVar5 = func_0x00018026be40();
                if (iVar5 == 0) {
                    return 0;
                }
            }
            if (in_RDX[4] == (uint32_t *)0x0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbc42;
                func_0x00018026be30(pauVar7[3] + 0xc);
            } else {
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbc37;
                iVar5 = func_0x00018026be40();
                if (iVar5 == 0) {
                    return 0;
                }
            }
        }
        pcVar3 = *(code **)(in_RCX + 0x3d0);
        if (pcVar3 == (code *)0x0) {
            puVar12 = *in_RDX;
            puVar11 = in_RDX[1];
            puVar8 = in_RDX[2];
            *(uint32_t **)((int64_t)&arg_60h + iVar6) = puVar12;
            *(uint32_t **)((int64_t)&arg_58h + iVar6) = puVar11;
            *(uint32_t **)((int64_t)&arg_50h + iVar6) = puVar8;
        } else {
            puVar8 = in_RDX[2];
            puVar11 = in_RDX[1];
            puVar12 = *in_RDX;
            *(undefined8 *)(&stack0xfffffffffffffff8 + iVar6) = *(undefined8 *)(in_RCX + 0x3e0);
            *(int64_t *)((int64_t)&var_10h + iVar6) = (int64_t)&arg_50h + iVar6;
            *(int64_t *)((int64_t)&var_18h + iVar6) = (int64_t)&arg_58h + iVar6;
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbc8a;
            iVar5 = (*pcVar3)(puVar12, puVar11, puVar8, (int64_t)&arg_60h + iVar6);
            if (iVar5 == 0) {
                return 0;
            }
            puVar8 = *(uint32_t **)((int64_t)&arg_50h + iVar6);
            puVar11 = *(uint32_t **)((int64_t)&arg_58h + iVar6);
            puVar12 = *(uint32_t **)((int64_t)&arg_60h + iVar6);
        }
        *(uint32_t **)(&stack0xfffffffffffffff8 + iVar6) = puVar8;
        *(uint32_t **)((int64_t)&var_10h + iVar6) = puVar11;
        *(uint32_t **)((int64_t)&var_18h + iVar6) = puVar12;
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbcef;
        iVar5 = func_0x0001801fc420(in_RCX, in_RDX, pauVar7, uVar14);
        if (iVar5 == 1) {
            pcVar3 = *(code **)(in_RCX + 0x358);
            uVar9 = 0;
            if (pcVar3 != (code *)0x0) {
                uVar9 = *(undefined8 *)(in_RCX + 0x360);
                *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbd10;
                uVar9 = (*pcVar3)(uVar9);
            }
            puVar8 = in_RDX[5];
            *(undefined8 *)((int64_t)&var_10h + iVar6) = *(undefined8 *)(in_RCX + 0x3c8);
            *(undefined8 *)((int64_t)&var_18h + iVar6) = *(undefined8 *)((int64_t)&arg_50h + iVar6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbd45;
            func_0x000180204fa0(uVar9, *(undefined8 *)((int64_t)&arg_60h + iVar6), puVar8, 
                                *(undefined8 *)((int64_t)&arg_58h + iVar6));
        }
        pcVar3 = *(code **)(in_RCX + 0x3d8);
        if (pcVar3 != (code *)0x0) {
            uVar9 = *(undefined8 *)(in_RCX + 0x3e0);
            *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbd5a;
            (*pcVar3)(uVar9);
        }
        if (iVar5 == 1) break;
        if (iVar5 != -2) {
            return 0;
        }
        if (!bVar4) {
            return 0;
        }
    }
    *(int64_t *)(in_RCX + 0x3b8) = *(int64_t *)(in_RCX + 0x3b8) + 1;
    if ((((**in_RDX & 0xff) == 4) || ((**in_RDX & 0xff) - 5 < 2)) || ((uVar1 & 1) == 0)) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar6) = 0x1801fbd9e;
        func_0x0001801fb380(in_RCX);
    }
    return 1;
}

// ============================================================
// Function: FUN_1801fbdb0
// Address: 0x1801fbdb0
// Size: 156 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_6ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.1801fbdb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h,
                  int64_t arg_a8h)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t *piVar14;
    undefined8 unaff_RBX;
    int64_t iVar15;
    int64_t iVar16;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_4h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x1801fbdc4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -8) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar10);
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar10);
    uVar4 = *(undefined8 *)((int64_t)&arg_a8h + iVar10);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar10 + -0x20) = 0;
    *(undefined4 *)((int64_t)&var_4h + iVar10) = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe0b;
    iVar11 = fcn.18020d3c0(in_RCX + 0x10, in_R9 & 0xffffffff, 1);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe18;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe30;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe42;
        fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
    } else {
        uVar2 = *(undefined4 *)(iVar11 + 0x60);
        *(undefined8 *)((int64_t)&arg_30h + iVar10) = unaff_RBX;
        uVar13 = *(uint64_t *)(iVar11 + 0x58);
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe5a;
        uVar12 = func_0x0001801f9b80(uVar2);
        if (uVar13 < uVar12) {
            *(undefined8 *)((int64_t)&arg_28h + iVar10) = unaff_R14;
            iVar5 = *(int64_t *)(iVar11 + 0x30);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbea8;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10))
                ;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbec0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10)
                              , *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                              *(int64_t *)((int64_t)&var_4h + iVar10 + 4), *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbed2;
                fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbee1;
                iVar9 = func_0x00018020e980(iVar5);
                if (iVar9 < 8) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbeeb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbf03;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                  *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbf15;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                } else {
                    iVar15 = (int64_t)iVar9;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbf30;
                    fcn.180498030((int64_t)&var_4h + iVar10 + 4, iVar11 + 0x6a, iVar15);
                    uVar6 = *(undefined8 *)((int64_t)&arg_90h + iVar10);
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10 + 3);
                    *puVar1 = *puVar1 ^ (uint8_t)uVar6;
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10 + 2);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 8);
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = 1;
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10 + 1);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x10);
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x18);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x1d);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x20);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x1e);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x28);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x1f);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x30);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x20);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x38);
                    *(int64_t *)((int64_t)&var_10h + iVar10) = (int64_t)&var_4h + iVar10 + 4;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfa8;
                    iVar9 = func_0x000180211b70(iVar5, 0, 0, 0);
                    if (iVar9 == 1) {
                        *(undefined4 *)((int64_t)&var_10h + iVar10) = *(undefined4 *)((int64_t)&arg_a0h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc000;
                        iVar9 = func_0x000180211bb0(iVar5, 0, (int64_t)&iStackX_20 + iVar10 + -0x20, uVar3);
                        if (iVar9 == 1) {
                            while( true ) {
                                uVar13 = in_RDX[2];
                                if ((uint64_t)in_RDX[1] <= uVar13) break;
                                iVar15 = *in_RDX;
                                piVar14 = (int64_t *)(iVar15 + 8 + uVar13 * 0x10);
                                while( true ) {
                                    iVar7 = *piVar14;
                                    iVar8 = in_RDX[3];
                                    iVar16 = iVar7 - iVar8;
                                    if (iVar16 != 0) break;
                                    uVar13 = uVar13 + 1;
                                    in_RDX[3] = 0;
                                    piVar14 = piVar14 + 2;
                                    in_RDX[2] = uVar13;
                                    if ((uint64_t)in_RDX[1] <= uVar13) goto code_r0x0001801fc083;
                                }
                                *(int32_t *)((int64_t)&var_10h + iVar10) = (int32_t)iVar16;
                                iVar15 = *(int64_t *)(uVar13 * 0x10 + iVar15);
                                in_RDX[4] = in_RDX[4] - iVar16;
                                in_RDX[3] = iVar7;
                                iVar7 = *(int64_t *)(in_R8 + 0x10);
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0fd;
                                iVar9 = func_0x000180211bb0(iVar5, iVar7 + 0x58 + in_R8, 
                                                            (int64_t)&iStackX_20 + iVar10 + -0x20, iVar8 + iVar15);
                                if (iVar9 != 1) {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc110;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc128;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc13a;
                                    fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                                    goto code_r0x0001801fc1bb;
                                }
                                *(int64_t *)(in_R8 + 0x10) = *(int64_t *)(in_R8 + 0x10) + iVar16;
                            }
code_r0x0001801fc083:
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc092;
                            iVar9 = func_0x000180211b40(iVar5, 0, (int64_t)&var_4h + iVar10);
                            if (iVar9 == 1) {
                                iVar15 = *(int64_t *)(in_R8 + 0x10);
                                uVar2 = *(undefined4 *)(iVar11 + 100);
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc15a;
                                iVar9 = func_0x000180210b80(iVar5, 0x10, uVar2, iVar15 + 0x58 + in_R8);
                                if (iVar9 == 1) {
                                    *(int64_t *)(in_R8 + 0x10) =
                                         *(int64_t *)(in_R8 + 0x10) + (uint64_t)*(uint32_t *)(iVar11 + 100);
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc1a4;
                                    iVar9 = func_0x0001801f8a20(iVar11, uVar4);
                                    if (iVar9 != 0) {
                                        *(int64_t *)(iVar11 + 0x58) = *(int64_t *)(iVar11 + 0x58) + 1;
                                    }
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc164;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc17c;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc18e;
                                    fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0a0;
                                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0b8;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                              *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0ca;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc00a;
                            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc022;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                          *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc034;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfb2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                      *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfdc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe64;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe7c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                          *(int64_t *)((int64_t)&var_4h + iVar10 + 4), *(int64_t *)((int64_t)&iStackX_20 + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe8e;
            fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
        }
    }
code_r0x0001801fc1bb:
    uVar13 = *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -8);
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc1c8;
    fcn.180459870(uVar13 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar10));
    return;
}

// ============================================================
// Function: FUN_1801fbe4c
// Address: 0x1801fbe4c
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Removing arg arg_6ah because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Removing arg arg_64h because it doesn't fit into ProtoModel

void fcn.1801fbdb0(int64_t arg_28h, int64_t arg_30h, int64_t arg_58h, int64_t arg_90h, int64_t arg_98h, int64_t arg_a0h,
                  int64_t arg_a8h)
{
    uint8_t *puVar1;
    undefined4 uVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    int64_t iVar5;
    undefined8 uVar6;
    int64_t iVar7;
    int64_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t in_RCX;
    int64_t *in_RDX;
    int64_t *piVar14;
    undefined8 unaff_RBX;
    int64_t iVar15;
    int64_t iVar16;
    int64_t in_R8;
    uint64_t in_R9;
    undefined8 unaff_R14;
    int64_t var_4h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_38;
    int64_t var_10h;
    
    uStack_38 = 0x1801fbdc4;
    iVar10 = fcn.18045a350();
    iVar10 = -iVar10;
    *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -8) =
         *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar10);
    uVar3 = *(undefined8 *)((int64_t)&arg_98h + iVar10);
    uVar4 = *(undefined8 *)((int64_t)&arg_a8h + iVar10);
    *(undefined4 *)((int64_t)&iStackX_20 + iVar10 + -0x20) = 0;
    *(undefined4 *)((int64_t)&var_4h + iVar10) = 0;
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe0b;
    iVar11 = fcn.18020d3c0(in_RCX + 0x10, in_R9 & 0xffffffff, 1);
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe18;
        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe30;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                      *(int64_t *)((int64_t)&iStackX_20 + iVar10));
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe42;
        fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
    } else {
        uVar2 = *(undefined4 *)(iVar11 + 0x60);
        *(undefined8 *)((int64_t)&arg_30h + iVar10) = unaff_RBX;
        uVar13 = *(uint64_t *)(iVar11 + 0x58);
        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe5a;
        uVar12 = func_0x0001801f9b80(uVar2);
        if (uVar13 < uVar12) {
            *(undefined8 *)((int64_t)&arg_28h + iVar10) = unaff_R14;
            iVar5 = *(int64_t *)(iVar11 + 0x30);
            if (iVar5 == 0) {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbea8;
                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10))
                ;
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbec0;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10)
                              , *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                              *(int64_t *)((int64_t)&var_4h + iVar10 + 4), *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbed2;
                fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
            } else {
                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbee1;
                iVar9 = func_0x00018020e980(iVar5);
                if (iVar9 < 8) {
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbeeb;
                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbf03;
                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                  *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbf15;
                    fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                } else {
                    iVar15 = (int64_t)iVar9;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbf30;
                    fcn.180498030((int64_t)&var_4h + iVar10 + 4, iVar11 + 0x6a, iVar15);
                    uVar6 = *(undefined8 *)((int64_t)&arg_90h + iVar10);
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10 + 3);
                    *puVar1 = *puVar1 ^ (uint8_t)uVar6;
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10 + 2);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 8);
                    *(undefined4 *)(&stack0xfffffffffffffff8 + iVar10) = 1;
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10 + 1);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x10);
                    puVar1 = (uint8_t *)((int64_t)&var_4h + iVar15 + iVar10);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x18);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x1d);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x20);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x1e);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x28);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x1f);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x30);
                    puVar1 = (uint8_t *)((int64_t)&iStackX_20 + iVar15 + iVar10 + -0x20);
                    *puVar1 = *puVar1 ^ (uint8_t)((uint64_t)uVar6 >> 0x38);
                    *(int64_t *)((int64_t)&var_10h + iVar10) = (int64_t)&var_4h + iVar10 + 4;
                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfa8;
                    iVar9 = func_0x000180211b70(iVar5, 0, 0, 0);
                    if (iVar9 == 1) {
                        *(undefined4 *)((int64_t)&var_10h + iVar10) = *(undefined4 *)((int64_t)&arg_a0h + iVar10);
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc000;
                        iVar9 = func_0x000180211bb0(iVar5, 0, (int64_t)&iStackX_20 + iVar10 + -0x20, uVar3);
                        if (iVar9 == 1) {
                            while( true ) {
                                uVar13 = in_RDX[2];
                                if ((uint64_t)in_RDX[1] <= uVar13) break;
                                iVar15 = *in_RDX;
                                piVar14 = (int64_t *)(iVar15 + 8 + uVar13 * 0x10);
                                while( true ) {
                                    iVar7 = *piVar14;
                                    iVar8 = in_RDX[3];
                                    iVar16 = iVar7 - iVar8;
                                    if (iVar16 != 0) break;
                                    uVar13 = uVar13 + 1;
                                    in_RDX[3] = 0;
                                    piVar14 = piVar14 + 2;
                                    in_RDX[2] = uVar13;
                                    if ((uint64_t)in_RDX[1] <= uVar13) goto code_r0x0001801fc083;
                                }
                                *(int32_t *)((int64_t)&var_10h + iVar10) = (int32_t)iVar16;
                                iVar15 = *(int64_t *)(uVar13 * 0x10 + iVar15);
                                in_RDX[4] = in_RDX[4] - iVar16;
                                in_RDX[3] = iVar7;
                                iVar7 = *(int64_t *)(in_R8 + 0x10);
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0fd;
                                iVar9 = func_0x000180211bb0(iVar5, iVar7 + 0x58 + in_R8, 
                                                            (int64_t)&iStackX_20 + iVar10 + -0x20, iVar8 + iVar15);
                                if (iVar9 != 1) {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc110;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc128;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc13a;
                                    fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                                    goto code_r0x0001801fc1bb;
                                }
                                *(int64_t *)(in_R8 + 0x10) = *(int64_t *)(in_R8 + 0x10) + iVar16;
                            }
code_r0x0001801fc083:
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc092;
                            iVar9 = func_0x000180211b40(iVar5, 0, (int64_t)&var_4h + iVar10);
                            if (iVar9 == 1) {
                                iVar15 = *(int64_t *)(in_R8 + 0x10);
                                uVar2 = *(undefined4 *)(iVar11 + 100);
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc15a;
                                iVar9 = func_0x000180210b80(iVar5, 0x10, uVar2, iVar15 + 0x58 + in_R8);
                                if (iVar9 == 1) {
                                    *(int64_t *)(in_R8 + 0x10) =
                                         *(int64_t *)(in_R8 + 0x10) + (uint64_t)*(uint32_t *)(iVar11 + 100);
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc1a4;
                                    iVar9 = func_0x0001801f8a20(iVar11, uVar4);
                                    if (iVar9 != 0) {
                                        *(int64_t *)(iVar11 + 0x58) = *(int64_t *)(iVar11 + 0x58) + 1;
                                    }
                                } else {
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc164;
                                    fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc17c;
                                    fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                                  *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                                  *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                                    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc18e;
                                    fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                                }
                            } else {
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0a0;
                                fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0b8;
                                fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                              *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                              *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                                *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc0ca;
                                fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                            }
                        } else {
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc00a;
                            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc022;
                            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                          *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                          *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                          *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc034;
                            fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                        }
                    } else {
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfb2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), 
                                      *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                                      *(int64_t *)((int64_t)&var_4h + iVar10 + 4), 
                                      *(int64_t *)((int64_t)&iStackX_20 + iVar10));
                        *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbfdc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
                    }
                }
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe64;
            fcn.180229480(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe7c;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_10h + iVar10), *(int64_t *)(&stack0xfffffffffffffff8 + iVar10), 
                          *(int64_t *)((int64_t)&iStackX_20 + iVar10 + -0x20), 
                          *(int64_t *)((int64_t)&var_4h + iVar10 + 4), *(int64_t *)((int64_t)&iStackX_20 + iVar10));
            *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fbe8e;
            fcn.1802296d0(*(int64_t *)(&stack0x00000010 + iVar10));
        }
    }
code_r0x0001801fc1bb:
    uVar13 = *(uint64_t *)((int64_t)&iStackX_20 + iVar10 + -8);
    *(undefined8 *)((int64_t)&uStack_38 + iVar10) = 0x1801fc1c8;
    fcn.180459870(uVar13 ^ (uint64_t)(&stack0xffffffffffffffd0 + iVar10));
    return;
}

