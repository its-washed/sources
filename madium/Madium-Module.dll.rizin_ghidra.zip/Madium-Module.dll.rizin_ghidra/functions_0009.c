// Chunk 9 - 50 functions

// ============================================================
// Function: FUN_180014185
// Address: 0x180014185
// Size: 22 bytes
// ============================================================
int64_t fcn.180014185(void)
{
    int64_t in_RAX;
    int64_t unaff_RDI;
    
    return in_RAX - unaff_RDI;
}

// ============================================================
// Function: FUN_1800141a0
// Address: 0x1800141a0
// Size: 300 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.1800141a0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t *puVar1;
    uint64_t *puVar2;
    code *pcVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    uint64_t uVar8;
    undefined8 *puVar9;
    uint64_t uVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    
    puVar9 = *(undefined8 **)arg1;
    puVar1 = (uint64_t *)(arg3 + 0x10);
    uVar10 = *puVar1;
    iVar6 = 0;
    if (0xf < *(uint64_t *)(arg3 + 0x18)) {
        arg3 = *(int64_t *)arg3;
    }
    puVar2 = puVar9 + 2;
    if (0xf < (uint64_t)puVar9[3]) {
        puVar9 = (undefined8 *)*puVar9;
    }
    if ((uVar10 <= *puVar2) &&
       ((uVar10 == 0 ||
        ((iVar4 = *puVar2 + (int64_t)puVar9, iVar6 = func_0x0001804581c0(puVar9, iVar4, arg3), iVar6 != iVar4 &&
         (iVar6 = iVar6 - (int64_t)puVar9, iVar6 != -1)))))) {
        puVar9 = *(undefined8 **)arg1;
        uVar10 = *puVar1 + iVar6;
        puVar1 = puVar9 + 2;
        if (0xf < (uint64_t)puVar9[3]) {
            puVar9 = (undefined8 *)*puVar9;
        }
        if (((uVar10 < *puVar1) &&
            (iVar6 = *puVar1 + (int64_t)puVar9, iVar4 = func_0x0001804580f0(uVar10 + (int64_t)puVar9, iVar6, 0x22),
            iVar4 != iVar6)) && (iVar4 - (int64_t)puVar9 != -1)) {
            puVar7 = *(undefined8 **)arg1;
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            if (uVar10 <= (uint64_t)puVar7[2]) {
                uVar5 = (iVar4 - (int64_t)puVar9) - uVar10;
                uVar8 = puVar7[2] - uVar10;
                if (uVar8 < uVar5) {
                    uVar5 = uVar8;
                }
                if (0xf < (uint64_t)puVar7[3]) {
                    puVar7 = (undefined8 *)*puVar7;
                }
                func_0x000180004830(arg2, uVar10 + (int64_t)puVar7, uVar5);
                return arg2;
            }
            func_0x00018000f930();
            pcVar3 = (code *)swi(3);
            iVar6 = (*pcVar3)();
            return iVar6;
        }
    }
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    *(undefined *)arg2 = 0;
    return arg2;
}

// ============================================================
// Function: FUN_1800142d0
// Address: 0x1800142d0
// Size: 609 bytes
// ============================================================
undefined8 fcn.1800142d0(int64_t arg1, int64_t arg_78h)
{
    int32_t iVar1;
    int64_t iVar2;
    char cVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    
    piVar5 = (int64_t *)func_0x000180013b20(&var_8h);
    iVar2 = *piVar5;
    while( true ) {
        iVar6 = *(int64_t *)(arg1 + 8);
        if (((((iVar6 != 0) && (*(int32_t *)(iVar6 + 0x20) == 2)) && (*(int64_t *)(iVar6 + 8) != 0)) &&
            ((*(int32_t *)(iVar6 + 0x20) < 3 &&
             (iVar1 = *(int32_t *)(iVar6 + 0x14), iVar4 = func_0x000180173bc0(*(undefined8 *)(iVar6 + 8)),
             iVar1 == iVar4)))) && (cVar3 = func_0x000180173be0(*(undefined8 *)(iVar6 + 8)), cVar3 != '\0')) {
            return 1;
        }
        iVar6 = func_0x000180458324();
        iVar7 = func_0x000180458308();
        if (iVar6 == 10000000) {
            iVar7 = iVar7 * 100;
        } else if (iVar6 == 24000000) {
            iVar6 = iVar7 + SUB168(SEXT816(-0x4d0b03f86b6f730d) * SEXT816(iVar7), 8);
            iVar8 = (iVar6 >> 0x18) - (iVar6 >> 0x3f);
            iVar6 = (iVar7 + iVar8 * -24000000) * 1000000000;
            iVar6 = SUB168(SEXT816(-0x4d0b03f86b6f730d) * SEXT816(iVar6), 8) + iVar6;
            iVar7 = iVar8 * 1000000000 + ((iVar6 >> 0x18) - (iVar6 >> 0x3f));
        } else {
            iVar7 = ((iVar7 % iVar6) * 1000000000) / iVar6 + (iVar7 / iVar6) * 1000000000;
        }
        if (iVar2 + 5000000000 <= iVar7) break;
        func_0x000180013b20(&var_8h);
        if (var_8h < 0x7fffffffff67697f) {
            iVar6 = var_8h + 10000000;
        } else {
            iVar6 = 0x7fffffffffffffff;
        }
        while( true ) {
            iVar7 = func_0x000180458324();
            iVar8 = func_0x000180458308();
            if (iVar7 == 10000000) {
                iVar8 = iVar8 * 100;
            } else {
                if (iVar7 == 24000000) {
                    iVar7 = iVar8 + SUB168(SEXT816(-0x4d0b03f86b6f730d) * SEXT816(iVar8), 8);
                    iVar10 = (iVar7 >> 0x18) - (iVar7 >> 0x3f);
                    iVar7 = (iVar8 + iVar10 * -24000000) * 1000000000;
                    iVar7 = iVar7 + SUB168(SEXT816(-0x4d0b03f86b6f730d) * SEXT816(iVar7), 8);
                    iVar8 = (iVar7 >> 0x18) - (iVar7 >> 0x3f);
                } else {
                    iVar10 = iVar8 / iVar7;
                    iVar8 = ((iVar8 % iVar7) * 1000000000) / iVar7;
                }
                iVar8 = iVar8 + iVar10 * 1000000000;
            }
            if ((iVar6 == iVar8) || (iVar6 < iVar8)) break;
            iVar8 = iVar6 - iVar8;
            if (iVar8 < 0x4e94914f0001) {
                uVar9 = iVar8 / 1000000;
                if ((int64_t)(uVar9 * 1000000) < iVar8) {
                    uVar9 = uVar9 + 1;
                }
                func_0x00018045844c(uVar9 & 0xffffffff);
            } else {
                func_0x00018045844c(86400000);
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_180014540
// Address: 0x180014540
// Size: 62 bytes
// ============================================================
void fcn.180014540(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t var_10h;
    
    if (*(int64_t **)(arg1 + 0x38) != (int64_t *)0x0) {
        (**(code **)(**(int64_t **)(arg1 + 0x38) + 0x10))();
        return;
    }
    fcn.180454690();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180014580
// Address: 0x180014580
// Size: 76 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180014580(int64_t arg1)
{
    char cVar1;
    undefined in_DL;
    int64_t var_8h;
    
    cVar1 = *(char *)(arg1 + 0x60);
    if (cVar1 != '\0') {
        if ((((cVar1 != -1) && (cVar1 != '\0')) && (cVar1 != '\x01')) && (cVar1 != '\x02')) {
            fcn.180004e40((undefined *)(arg1 + 0x40));
        }
        *(undefined *)(arg1 + 0x60) = 0;
    }
    *(undefined *)(arg1 + 0x40) = in_DL;
    return;
}

// ============================================================
// Function: FUN_1800145d0
// Address: 0x1800145d0
// Size: 74 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800145d0(int64_t arg1, int64_t arg2)
{
    char cVar1;
    int64_t var_8h;
    
    cVar1 = *(char *)(arg1 + 0x60);
    if (cVar1 != '\x01') {
        if ((((cVar1 != -1) && (cVar1 != '\0')) && (cVar1 != '\x01')) && (cVar1 != '\x02')) {
            fcn.180004e40((undefined4 *)(arg1 + 0x40));
        }
        *(undefined *)(arg1 + 0x60) = 1;
    }
    *(undefined4 *)(arg1 + 0x40) = (int32_t)arg2;
    return;
}

// ============================================================
// Function: FUN_180014620
// Address: 0x180014620
// Size: 93 bytes
// ============================================================
void fcn.180014620(int64_t arg1)
{
    undefined4 *puVar1;
    char cVar2;
    undefined4 in_XMM1_Da;
    int64_t var_18h;
    
    cVar2 = *(char *)(arg1 + 0x60);
    puVar1 = (undefined4 *)(arg1 + 0x40);
    if (cVar2 == '\x02') {
        *puVar1 = in_XMM1_Da;
        return;
    }
    if ((((cVar2 != -1) && (cVar2 != '\0')) && (cVar2 != '\x01')) && (cVar2 != '\x02')) {
        fcn.180004e40(puVar1);
    }
    *puVar1 = in_XMM1_Da;
    *(undefined *)(arg1 + 0x60) = 2;
    return;
}

// ============================================================
// Function: FUN_180014680
// Address: 0x180014680
// Size: 220 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180014680(int64_t arg1, int64_t arg2)
{
    undefined (*pauVar1) [16];
    char cVar2;
    int64_t iVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    int64_t iVar8;
    undefined *puVar9;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    cVar2 = *(char *)(arg1 + 0x60);
    pauVar1 = (undefined (*) [16])(arg1 + 0x40);
    if (cVar2 == '\x03') {
        func_0x000180012c10(pauVar1);
    } else {
        if ((((cVar2 != -1) && (cVar2 != '\0')) && (cVar2 != '\x01')) && (cVar2 != '\x02')) {
            fcn.180004e40(pauVar1);
        }
        *(undefined *)(arg1 + 0x60) = 0xff;
        *pauVar1 = ZEXT816(0);
        *(undefined8 *)(arg1 + 0x50) = 0;
        *(undefined8 *)(arg1 + 0x58) = 0;
        uVar5 = *(undefined4 *)(arg2 + 4);
        uVar6 = *(undefined4 *)(arg2 + 8);
        uVar7 = *(undefined4 *)(arg2 + 0xc);
        *(undefined4 *)*pauVar1 = *(undefined4 *)arg2;
        *(undefined4 *)(arg1 + 0x44) = uVar5;
        *(undefined4 *)(arg1 + 0x48) = uVar6;
        *(undefined4 *)(arg1 + 0x4c) = uVar7;
        uVar5 = *(undefined4 *)(arg2 + 0x14);
        uVar6 = *(undefined4 *)(arg2 + 0x18);
        uVar7 = *(undefined4 *)(arg2 + 0x1c);
        *(undefined4 *)(arg1 + 0x50) = *(undefined4 *)(arg2 + 0x10);
        *(undefined4 *)(arg1 + 0x54) = uVar5;
        *(undefined4 *)(arg1 + 0x58) = uVar6;
        *(undefined4 *)(arg1 + 0x5c) = uVar7;
        *(undefined8 *)(arg2 + 0x10) = 0;
        *(undefined8 *)(arg2 + 0x18) = 0xf;
        *(undefined *)arg2 = 0;
        *(undefined *)(arg1 + 0x60) = 3;
    }
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar3 = *(int64_t *)arg2;
        iVar8 = iVar3;
        puVar9 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg2 + 0x18) + 1) &&
           (iVar8 = *(int64_t *)(iVar3 + -8), puVar9 = auStack_28, 0x1f < (iVar3 - iVar8) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            iVar8 = (*pcVar4)(5);
            puVar9 = auStack_20;
        }
        *(undefined8 *)(puVar9 + -8) = 0x18001473d;
        func_0x000180459c3c(iVar8);
    }
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined *)arg2 = 0;
    *(undefined8 *)(arg2 + 0x18) = 0xf;
    return;
}

// ============================================================
// Function: FUN_180014760
// Address: 0x180014760
// Size: 30 bytes
// ============================================================
void fcn.180014760(int64_t arg1)
{
    code *pcVar1;
    
    if (*(int64_t **)(arg1 + 0x38) != (int64_t *)0x0) {
    // WARNING: Could not recover jumptable at 0x000180014774. Too many branches
    // WARNING: Treating indirect jump as call
        (**(code **)(**(int64_t **)(arg1 + 0x38) + 0x10))();
        return;
    }
    fcn.180454690();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180014780
// Address: 0x180014780
// Size: 84 bytes
// ============================================================
int64_t fcn.180014780(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
    if ((uint64_t)arg3 <= *(uint64_t *)(arg1 + 0x10)) {
        uVar2 = *(uint64_t *)(arg1 + 0x10) - arg3;
        if (uVar2 < (uint64_t)arg4) {
            arg4 = uVar2;
        }
        if (0xf < *(uint64_t *)(arg1 + 0x18)) {
            arg1 = *(int64_t *)arg1;
        }
        fcn.180004830(arg2, arg1 + arg3, arg4);
        return arg2;
    }
    fcn.18000f930();
    pcVar1 = (code *)swi(3);
    iVar3 = (*pcVar1)();
    return iVar3;
}

// ============================================================
// Function: FUN_1800147e0
// Address: 0x1800147e0
// Size: 256 bytes
// ============================================================
int64_t fcn.1800147e0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t *puVar1;
    uint8_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t iVar5;
    uint8_t *puVar6;
    int64_t var_128h;
    
    iVar4 = func_0x000180498cd0(arg2);
    iVar5 = arg1;
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar5 = *(int64_t *)arg1;
    }
    if ((iVar4 != 0) && (uVar3 = *(uint64_t *)(arg1 + 0x10), (uint64_t)arg3 < uVar3)) {
        puVar6 = (uint8_t *)(arg3 + iVar5);
        if (0xf < iVar4 + (uVar3 - arg3)) {
            iVar5 = func_0x000180458040(puVar6, uVar3 - arg3, arg2, iVar4);
            arg3 = iVar5 + arg3;
            if (iVar5 == -1) {
                arg3 = -1;
            }
            return arg3;
        }
        func_0x0001804986e0(&var_128h, 0, 0x100);
        puVar1 = (uint8_t *)(iVar4 + arg2);
        if ((uint8_t *)arg2 != puVar1) {
            do {
                uVar2 = *(uint8_t *)arg2;
                arg2 = arg2 + 1;
                *(undefined *)((int64_t)&var_128h + (uint64_t)uVar2) = 1;
            } while ((uint8_t *)arg2 != puVar1);
        }
        for (; puVar6 < (uint8_t *)(uVar3 + iVar5); puVar6 = puVar6 + 1) {
            if (*(char *)((int64_t)&var_128h + (uint64_t)*puVar6) != '\0') {
                return (int64_t)puVar6 - iVar5;
            }
        }
    }
    return -1;
}

// ============================================================
// Function: FUN_180014900
// Address: 0x180014900
// Size: 549 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_77h
// WARNING: [rz-ghidra] Detected overlap for variable var_87h
// WARNING: [rz-ghidra] Detected overlap for variable var_73h
// WARNING: [rz-ghidra] Detected overlap for variable var_83h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_81h

int64_t fcn.180014900(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    undefined8 *puVar6;
    undefined8 uVar7;
    uint32_t uVar8;
    uint32_t uVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    
    uVar9 = 0;
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    var_78h = arg1;
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 8))();
    }
    iVar11 = *(int64_t *)arg1;
    if (*(int32_t *)((int64_t)*(int32_t *)(iVar11 + 4) + 0x10 + arg1) == 0) {
        iVar2 = *(int64_t *)((int64_t)*(int32_t *)(iVar11 + 4) + 0x50 + arg1);
        if ((iVar2 == 0) || (iVar2 == arg1)) {
            var_70h._0_1_ = true;
        } else {
            func_0x00018000fad0(iVar2);
            iVar11 = *(int64_t *)arg1;
            var_70h._0_1_ = *(int32_t *)((int64_t)*(int32_t *)(iVar11 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        var_70h._0_1_ = false;
    }
    if ((bool)(undefined)var_70h) {
        piVar1 = *(int64_t **)(*(int64_t *)((int64_t)*(int32_t *)(iVar11 + 4) + 0x40 + arg1) + 8);
        var_80h = (int64_t)piVar1;
        (**(code **)(*piVar1 + 8))(piVar1);
        piVar5 = (int64_t *)func_0x000180010a00(&var_88h);
        if ((piVar1 != (int64_t *)0x0) &&
           (puVar6 = (undefined8 *)(**(code **)(*piVar1 + 0x10))(piVar1), puVar6 != (undefined8 *)0x0)) {
            (**(code **)*puVar6)(puVar6, 1);
        }
        iVar11 = *(int32_t *)(*(int64_t *)arg1 + 4) + arg1;
        var_88h._0_1_ = 0;
        var_88h._1_4_ = var_78h._1_4_;
        var_88h._5_2_ = var_78h._5_2_;
        var_88h._7_1_ = var_78h._7_1_;
        var_80h = *(int64_t *)(iVar11 + 0x48);
        var_98h._0_1_ = *(undefined *)(iVar11 + 0x58);
        (**(code **)(*piVar5 + 0x48))(piVar5, &var_68h, &var_88h, iVar11, (undefined)var_98h, (int32_t)arg2);
        uVar9 = 0;
        if ((char)var_68h != '\0') {
            uVar9 = 4;
        }
    }
    iVar11 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar8 = 4;
    if (*(int64_t *)(iVar11 + 0x48 + arg1) != 0) {
        uVar8 = 0;
    }
    uVar9 = uVar8 | *(uint32_t *)(iVar11 + 0x10 + arg1) & 0x17 | uVar9;
    *(uint32_t *)(iVar11 + 0x10 + arg1) = uVar9;
    uVar9 = uVar9 & *(uint32_t *)(iVar11 + 0x14 + arg1);
    if (uVar9 != 0) {
        if ((uVar9 & 4) == 0) {
            uVar10 = 0x1805aae00;
            if ((uVar9 & 2) == 0) {
                uVar10 = 0x1805aae18;
            }
        } else {
            uVar10 = 0x1805aade8;
        }
        uVar7 = func_0x000180005e50(&var_68h, 1);
        func_0x0001800069f0(&var_58h, uVar10, uVar7);
        fcn.18045bae0(CONCAT71(var_98h._1_7_, (undefined)var_98h));
        pcVar3 = (code *)swi(3);
        iVar11 = (*pcVar3)();
        return iVar11;
    }
    iVar4 = func_0x0001804557c0();
    if (iVar4 == 0) {
        func_0x00018000fc20(arg1);
    }
    piVar1 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_180014b30
// Address: 0x180014b30
// Size: 295 bytes
// ============================================================
int64_t fcn.180014b30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    undefined *puVar6;
    uint64_t uVar7;
    int64_t var_1h;
    undefined8 uStack_50;
    undefined auStack_48 [32];
    
    puVar6 = auStack_48;
    uVar5 = 0;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    if (arg2 == arg3) {
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        *(undefined *)arg1 = 0;
        return arg1;
    }
    uVar7 = arg3 - arg2;
    if (0x7fffffffffffffff < uVar7) {
        fcn.1800047c0();
        pcVar1 = (code *)swi(3);
        iVar4 = (*pcVar1)();
        return iVar4;
    }
    if (uVar7 < 0x10) {
        *(uint64_t *)(arg1 + 0x10) = uVar7;
        *(undefined8 *)(arg1 + 0x18) = 0xf;
        fcn.180498030(0, arg2, uVar7);
        *(undefined *)(uVar7 + arg1) = 0;
        return arg1;
    }
    uVar2 = uVar7 | 0xf;
    if (uVar2 < 0x8000000000000000) goto code_r0x000180014bde;
    uVar3 = 0x8000000000000027;
    puVar6 = auStack_48;
    uVar2 = 0x7fffffffffffffff;
    while( true ) {
        *(undefined8 *)(puVar6 + -8) = 0x180014bd2;
        iVar4 = fcn.180459890(uVar3);
        if (iVar4 != 0) break;
        pcVar1 = (code *)swi(0x29);
        uVar2 = (*pcVar1)(5);
        puVar6 = puVar6 + 8;
code_r0x000180014bde:
        if (uVar2 < 0x16) {
            uVar2 = 0x16;
        }
        if (uVar2 == 0xffffffffffffffff) goto code_r0x000180014c20;
        if (uVar2 + 1 < 0x1000) {
            *(undefined8 *)(puVar6 + -8) = 0x180014c1d;
            uVar5 = fcn.180459890();
            goto code_r0x000180014c20;
        }
        uVar3 = uVar2 + 0x28;
        if (uVar3 <= uVar2 + 1) {
            *(undefined8 *)(puVar6 + -8) = 0x180014c56;
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            iVar4 = (*pcVar1)();
            return iVar4;
        }
    }
    uVar5 = iVar4 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar4;
code_r0x000180014c20:
    *(uint64_t *)arg1 = uVar5;
    *(uint64_t *)(arg1 + 0x10) = uVar7;
    *(uint64_t *)(arg1 + 0x18) = uVar2;
    *(undefined8 *)(puVar6 + -8) = 0x180014c39;
    fcn.180498030(uVar5, arg2, uVar7);
    *(undefined *)(uVar7 + uVar5) = 0;
    return arg1;
}

// ============================================================
// Function: FUN_180014c60
// Address: 0x180014c60
// Size: 369 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

int64_t fcn.180014c60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    char cVar1;
    code *pcVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    undefined8 *puVar6;
    undefined8 *puVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t *piVar12;
    undefined8 *puVar13;
    uint32_t uVar14;
    int64_t var_8h;
    int64_t var_19h;
    int64_t var_68h;
    int64_t var_60h;
    
    puVar9 = *(undefined8 **)arg1;
    puVar13 = (undefined8 *)puVar9[1];
    uVar14 = 0;
    cVar1 = *(char *)((int64_t)puVar13 + 0x19);
    puVar7 = puVar13;
    while (puVar6 = puVar13, cVar1 == '\0') {
        piVar12 = puVar6 + 4;
        iVar11 = arg3;
        if (0xf < *(uint64_t *)(arg3 + 0x18)) {
            iVar11 = *(int64_t *)arg3;
        }
        if (0xf < (uint64_t)puVar6[7]) {
            piVar12 = (int64_t *)*piVar12;
        }
        iVar8 = func_0x00018047b6d0(piVar12, iVar11);
        if (-1 < iVar8) {
            puVar13 = (undefined8 *)*puVar6;
            puVar9 = puVar6;
        } else {
            puVar13 = (undefined8 *)puVar6[2];
        }
        uVar14 = (uint32_t)(-1 < iVar8);
        cVar1 = *(char *)((int64_t)puVar13 + 0x19);
        puVar7 = puVar6;
    }
    if (*(char *)((int64_t)puVar9 + 0x19) == '\0') {
        piVar12 = puVar9 + 4;
        if (0xf < (uint64_t)puVar9[7]) {
            piVar12 = (int64_t *)*piVar12;
        }
        iVar11 = arg3;
        if (0xf < *(uint64_t *)(arg3 + 0x18)) {
            iVar11 = *(int64_t *)arg3;
        }
        iVar8 = func_0x00018047b6d0(iVar11, piVar12);
        if (-1 < iVar8) {
            *(undefined8 **)arg2 = puVar9;
            *(undefined *)(arg2 + 8) = 0;
            return arg2;
        }
    }
    if (*(int64_t *)(arg1 + 8) != 0x2aaaaaaaaaaaaaa) {
        uVar10 = *(undefined8 *)arg1;
        var_60h = 0;
        var_68h = arg1;
        puVar9 = (undefined8 *)fcn.180459890(0x60);
        *(undefined (*) [16])(puVar9 + 4) = ZEXT816(0);
        puVar9[6] = 0;
        puVar9[7] = 0;
        uVar3 = *(undefined4 *)(arg3 + 4);
        uVar4 = *(undefined4 *)(arg3 + 8);
        uVar5 = *(undefined4 *)(arg3 + 0xc);
        *(undefined4 *)(puVar9 + 4) = *(undefined4 *)arg3;
        *(undefined4 *)((int64_t)puVar9 + 0x24) = uVar3;
        *(undefined4 *)(puVar9 + 5) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x2c) = uVar5;
        uVar3 = *(undefined4 *)(arg3 + 0x14);
        uVar4 = *(undefined4 *)(arg3 + 0x18);
        uVar5 = *(undefined4 *)(arg3 + 0x1c);
        *(undefined4 *)(puVar9 + 6) = *(undefined4 *)(arg3 + 0x10);
        *(undefined4 *)((int64_t)puVar9 + 0x34) = uVar3;
        *(undefined4 *)(puVar9 + 7) = uVar4;
        *(undefined4 *)((int64_t)puVar9 + 0x3c) = uVar5;
        *(undefined8 *)(arg3 + 0x10) = 0;
        *(undefined8 *)(arg3 + 0x18) = 0xf;
        *(undefined *)arg3 = 0;
        *(undefined (*) [16])(puVar9 + 8) = ZEXT816(0);
        puVar9[10] = 0;
        puVar9[0xb] = 0xf;
        *(undefined *)(puVar9 + 8) = 0;
        *puVar9 = uVar10;
        puVar9[1] = uVar10;
        puVar9[2] = uVar10;
        *(undefined2 *)(puVar9 + 3) = 0;
        var_60h = CONCAT44(var_60h._4_4_, uVar14);
        var_68h = (int64_t)puVar7;
        uVar10 = func_0x0001800156d0(arg1, &var_68h, puVar9);
        *(undefined8 *)arg2 = uVar10;
        *(undefined *)(arg2 + 8) = 1;
        return arg2;
    }
    func_0x000180013c00();
    pcVar2 = (code *)swi(3);
    iVar11 = (*pcVar2)();
    return iVar11;
}

// ============================================================
// Function: FUN_180014de0
// Address: 0x180014de0
// Size: 106 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180014de0(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t var_8h;
    
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg2) {
            uVar2 = (**(code **)(*piVar1 + 8))(piVar1, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar2;
            piVar1 = *(int64_t **)(arg2 + 0x38);
            if (piVar1 != (int64_t *)0x0) {
                (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
                *(undefined8 *)(arg2 + 0x38) = 0;
                return;
            }
        } else {
            *(int64_t **)(arg1 + 0x38) = piVar1;
            *(undefined8 *)(arg2 + 0x38) = 0;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180014e50
// Address: 0x180014e50
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180014e50(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_88h;
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if ((piVar1 != (int64_t *)arg1) && (*(int64_t *)(arg2 + 0x38) != arg2)) {
        *(int64_t *)(arg1 + 0x38) = *(int64_t *)(arg2 + 0x38);
        *(int64_t **)(arg2 + 0x38) = piVar1;
        goto code_r0x000180014f59;
    }
    var_30h = 0;
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg1) {
            var_30h = (**(code **)(*piVar1 + 8))(piVar1, &var_68h);
            piVar1 = *(int64_t **)(arg1 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180014ed5;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
            piVar1 = (int64_t *)var_30h;
        }
        var_30h = (int64_t)piVar1;
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
code_r0x000180014ed5:
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg2) {
            uVar2 = (**(code **)(*piVar1 + 8))(piVar1, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar2;
            piVar1 = *(int64_t **)(arg2 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180014f0f;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
        } else {
            *(int64_t **)(arg1 + 0x38) = piVar1;
        }
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
code_r0x000180014f0f:
    if (var_30h != 0) {
        if ((int64_t *)var_30h == &var_68h) {
            uVar2 = (**(code **)(*(int64_t *)var_30h + 8))(var_30h, arg2);
            *(undefined8 *)(arg2 + 0x38) = uVar2;
            if (var_30h != 0) {
                (**(code **)(*(int64_t *)var_30h + 0x20))
                          (var_30h, CONCAT71((unkint7)((uint64_t)&var_68h >> 8), (int64_t *)var_30h != &var_68h));
            }
        } else {
            *(int64_t *)(arg2 + 0x38) = var_30h;
        }
    }
code_r0x000180014f59:
    func_0x000180459870(var_28h ^ (uint64_t)&var_88h);
    return;
}

// ============================================================
// Function: FUN_180014e8c
// Address: 0x180014e8c
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180014e50(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_88h;
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if ((piVar1 != (int64_t *)arg1) && (*(int64_t *)(arg2 + 0x38) != arg2)) {
        *(int64_t *)(arg1 + 0x38) = *(int64_t *)(arg2 + 0x38);
        *(int64_t **)(arg2 + 0x38) = piVar1;
        goto code_r0x000180014f59;
    }
    var_30h = 0;
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg1) {
            var_30h = (**(code **)(*piVar1 + 8))(piVar1, &var_68h);
            piVar1 = *(int64_t **)(arg1 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180014ed5;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
            piVar1 = (int64_t *)var_30h;
        }
        var_30h = (int64_t)piVar1;
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
code_r0x000180014ed5:
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg2) {
            uVar2 = (**(code **)(*piVar1 + 8))(piVar1, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar2;
            piVar1 = *(int64_t **)(arg2 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180014f0f;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
        } else {
            *(int64_t **)(arg1 + 0x38) = piVar1;
        }
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
code_r0x000180014f0f:
    if (var_30h != 0) {
        if ((int64_t *)var_30h == &var_68h) {
            uVar2 = (**(code **)(*(int64_t *)var_30h + 8))(var_30h, arg2);
            *(undefined8 *)(arg2 + 0x38) = uVar2;
            if (var_30h != 0) {
                (**(code **)(*(int64_t *)var_30h + 0x20))
                          (var_30h, CONCAT71((unkint7)((uint64_t)&var_68h >> 8), (int64_t *)var_30h != &var_68h));
            }
        } else {
            *(int64_t *)(arg2 + 0x38) = var_30h;
        }
    }
code_r0x000180014f59:
    func_0x000180459870(var_28h ^ (uint64_t)&var_88h);
    return;
}

// ============================================================
// Function: FUN_180014f21
// Address: 0x180014f21
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180014e50(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t *piVar1;
    undefined8 uVar2;
    int64_t var_18h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)&var_88h;
    piVar1 = *(int64_t **)(arg1 + 0x38);
    if ((piVar1 != (int64_t *)arg1) && (*(int64_t *)(arg2 + 0x38) != arg2)) {
        *(int64_t *)(arg1 + 0x38) = *(int64_t *)(arg2 + 0x38);
        *(int64_t **)(arg2 + 0x38) = piVar1;
        goto code_r0x000180014f59;
    }
    var_30h = 0;
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg1) {
            var_30h = (**(code **)(*piVar1 + 8))(piVar1, &var_68h);
            piVar1 = *(int64_t **)(arg1 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180014ed5;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg1);
            piVar1 = (int64_t *)var_30h;
        }
        var_30h = (int64_t)piVar1;
        *(undefined8 *)(arg1 + 0x38) = 0;
    }
code_r0x000180014ed5:
    piVar1 = *(int64_t **)(arg2 + 0x38);
    if (piVar1 != (int64_t *)0x0) {
        if (piVar1 == (int64_t *)arg2) {
            uVar2 = (**(code **)(*piVar1 + 8))(piVar1, arg1);
            *(undefined8 *)(arg1 + 0x38) = uVar2;
            piVar1 = *(int64_t **)(arg2 + 0x38);
            if (piVar1 == (int64_t *)0x0) goto code_r0x000180014f0f;
            (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)arg2);
        } else {
            *(int64_t **)(arg1 + 0x38) = piVar1;
        }
        *(undefined8 *)(arg2 + 0x38) = 0;
    }
code_r0x000180014f0f:
    if (var_30h != 0) {
        if ((int64_t *)var_30h == &var_68h) {
            uVar2 = (**(code **)(*(int64_t *)var_30h + 8))(var_30h, arg2);
            *(undefined8 *)(arg2 + 0x38) = uVar2;
            if (var_30h != 0) {
                (**(code **)(*(int64_t *)var_30h + 0x20))
                          (var_30h, CONCAT71((unkint7)((uint64_t)&var_68h >> 8), (int64_t *)var_30h != &var_68h));
            }
        } else {
            *(int64_t *)(arg2 + 0x38) = var_30h;
        }
    }
code_r0x000180014f59:
    func_0x000180459870(var_28h ^ (uint64_t)&var_88h);
    return;
}

// ============================================================
// Function: FUN_180014f70
// Address: 0x180014f70
// Size: 512 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180014f70(int64_t arg1)
{
    code *pcVar1;
    undefined auVar2 [16];
    char cVar3;
    undefined8 uVar4;
    undefined *puVar5;
    undefined *puVar6;
    int64_t iVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStackY_158 [8];
    undefined auStackY_150 [24];
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t in_stack_ffffffffffffff18;
    int64_t var_e0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b0h;
    int64_t var_30h;
    int64_t var_20h;
    int64_t var_18h;
    uint64_t uStack_10;
    uint64_t uVar8;
    
    puVar5 = auStackY_158;
    uStack_10 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_158;
    cVar3 = fcn.1800142d0(*(int64_t *)arg1, in_stack_ffffffffffffff18);
    puVar6 = auStackY_158;
    if (cVar3 == '\0') goto code_r0x00018001513b;
    func_0x00018000c2d0(&var_138h, 1);
    uVar4 = func_0x0001800103b0(&var_138h, 0x18061fee0);
    uVar4 = func_0x0001800107d0(uVar4, *(undefined8 *)(arg1 + 8));
    uVar4 = func_0x0001800103b0(uVar4, 0x18061fed0);
    uVar4 = func_0x0001800107d0(uVar4, *(undefined8 *)(arg1 + 0x10));
    func_0x0001800103b0(uVar4, 0x18061fecc);
    uVar4 = *(undefined8 *)arg1;
    var_20h = 0;
    var_18h = 0xf;
    stack0xffffffffffffffd1 = SUB1615(ZEXT816(0), 1);
    auVar2[15] = 0;
    auVar2._0_15_ = stack0xffffffffffffffd1;
    _var_30h = auVar2 << 8;
    if ((((uint8_t)var_c0h & 0x22) == 2) || (uVar8 = *(uint64_t *)var_f0h, uVar8 == 0)) {
        if ((((uint8_t)var_c0h & 4) == 0) && (*(int64_t *)var_f8h != 0)) {
            var_110h = *(int64_t *)var_118h;
            iVar7 = (*(int32_t *)var_e0h - var_110h) + *(int64_t *)var_f8h;
            goto code_r0x000180015072;
        }
    } else {
        var_110h = *(int64_t *)var_110h;
        if (uVar8 < (uint64_t)var_c8h) {
            uVar8 = var_c8h;
        }
        iVar7 = uVar8 - var_110h;
code_r0x000180015072:
        if (var_110h != 0) {
            func_0x00018000f180(&var_30h, var_110h, iVar7);
        }
    }
    func_0x000180180540(uVar4, &var_30h);
    if (0xf < (uint64_t)var_18h) {
        iVar7 = var_30h;
        puVar5 = auStackY_158;
        if ((0xfff < var_18h + 1U) &&
           (iVar7 = *(int64_t *)(var_30h + -8), puVar5 = auStackY_158, 0x1f < (var_30h - iVar7) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar7 = (*pcVar1)(5);
            puVar5 = auStackY_150;
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800150cf;
        func_0x000180459c3c(iVar7);
    }
    *(undefined8 *)(puVar5 + (int64_t)*(int32_t *)(*(int64_t *)(puVar5 + 0x20) + 4) + 0x20) = 0x1804a6448;
    *(int32_t *)(puVar5 + (int64_t)*(int32_t *)(*(int64_t *)(puVar5 + 0x20) + 4) + 0x1c) =
         *(int32_t *)(*(int64_t *)(puVar5 + 0x20) + 4) + -0x88;
    *(undefined8 *)(puVar5 + -8) = 0x180015101;
    func_0x00018000c970(puVar5 + 0x28);
    *(undefined8 *)(puVar5 + (int64_t)*(int32_t *)(*(int64_t *)(puVar5 + 0x20) + 4) + 0x20) = 0x1804a54f0;
    *(int32_t *)(puVar5 + (int64_t)*(int32_t *)(*(int64_t *)(puVar5 + 0x20) + 4) + 0x1c) =
         *(int32_t *)(*(int64_t *)(puVar5 + 0x20) + 4) + -0x10;
    var_b0h = 0x1804a54d0;
    *(undefined8 *)(puVar5 + -8) = 0x18001513a;
    func_0x000180455c14(&var_b0h);
    puVar6 = puVar5;
code_r0x00018001513b:
    *(undefined8 *)(puVar6 + -8) = 0x180015140;
    func_0x00018045476c();
    *(undefined8 *)(puVar6 + -8) = 0x18001514d;
    func_0x000180459c3c(arg1, 0x18);
    *(undefined8 *)(puVar6 + -8) = 0x18001515b;
    func_0x000180459870(uStack_10 ^ (uint64_t)puVar6);
    return;
}

// ============================================================
// Function: FUN_180015170
// Address: 0x180015170
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180015170(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180015170(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RSI);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x60);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180015190
// Address: 0x180015190
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180015170(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180015170(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RSI);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x60);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_1800151e4
// Address: 0x1800151e4
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180015170(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_38h)
{
    char cVar1;
    int64_t *piVar2;
    int64_t unaff_RSI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    cVar1 = *(char *)(arg3 + 0x19);
    while (cVar1 == '\0') {
        fcn.180015170(arg1, arg2, *(int64_t *)(arg3 + 0x10), unaff_RSI);
        piVar2 = *(int64_t **)arg3;
        fcn.180004e40((int64_t *)(arg3 + 0x40));
        fcn.180004e40((int64_t *)(arg3 + 0x20));
        fcn.180459c3c(arg3, 0x60);
        arg3 = (int64_t)piVar2;
        cVar1 = *(char *)((int64_t)piVar2 + 0x19);
    }
    return;
}

// ============================================================
// Function: FUN_180015200
// Address: 0x180015200
// Size: 57 bytes
// ============================================================
void fcn.180015200(int64_t arg1)
{
    int64_t *arg1_00;
    undefined4 *puVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t in_stack_00000008;
    
    arg1_00 = *(int64_t **)(arg1 + 8);
    if (arg1_00 == (int64_t *)0x0) {
        return;
    }
    fcn.180015170((int64_t)arg1_00, *(int64_t *)arg1, *(int64_t *)(*arg1_00 + 8), in_stack_00000008);
    if ((*arg1_00 != 0) &&
       (iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, *arg1_00, in_R9, unaff_RBX), iVar2 == 0)) {
        uVar3 = (*(code *)0x699ff6)();
        uVar3 = fcn.18046b63c(uVar3);
        puVar1 = (undefined4 *)fcn.18046b77c();
        *puVar1 = uVar3;
    }
    return;
}

// ============================================================
// Function: FUN_180015270
// Address: 0x180015270
// Size: 1086 bytes
// ============================================================
// WARNING: Removing unreachable block (ram,0x00018001542c)
// WARNING: Removing unreachable block (ram,0x000180015458)
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b1h

void fcn.180015270(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined8 *puVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    code *pcVar7;
    undefined auVar8 [16];
    int32_t iVar9;
    int64_t iVar10;
    undefined8 *puVar11;
    int64_t *piVar12;
    int64_t iVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    int64_t iVar16;
    undefined *puVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined (*pauVar20) [16];
    undefined (*pauVar21) [16];
    int32_t iVar22;
    undefined (*unaff_R15) [16];
    bool bVar23;
    undefined8 uStack_f0;
    undefined auStack_e8 [8];
    undefined auStack_e0 [24];
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar17 = auStack_e8;
    puVar18 = auStack_e8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_e8;
    pauVar21 = (undefined (*) [16])0x0;
    puVar19 = auStack_e8;
    var_80h = arg1;
    if (((**(int64_t **)0x1807825b0 == 0) ||
        (iVar10 = *(int64_t *)(**(int64_t **)0x1807825b0 + 0xa80), puVar19 = auStack_e8, iVar10 == 0)) ||
       (var_c8h = *(int64_t *)(iVar10 + 0x1d0), puVar19 = auStack_e8, var_c8h == 0)) goto code_r0x000180015682;
    var_a8h = 7;
    var_a0h = 0xf;
    _var_b8h = ZEXT716(0x73726579616c50);
    piVar12 = *(int64_t **)(var_c8h + 0x78);
    auVar8 = ZEXT816(0);
    var_90h = 0;
    var_88h = 0;
    uVar14 = piVar12[1] - *piVar12 >> 4;
    _var_98h = auVar8;
    if (uVar14 == 0) {
        var_98h = 0;
        pauVar20 = (undefined (*) [16])var_90h;
        unaff_R15 = (undefined (*) [16])var_98h;
    } else {
        if (0xfffffffffffffff < uVar14) {
code_r0x0001800156a8:
            func_0x000180010010();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        uVar15 = uVar14 * 0x10;
        if (uVar15 != 0) {
            if (uVar15 < 0x1000) {
                pauVar21 = (undefined (*) [16])fcn.180459890(uVar15);
            } else {
                if (uVar15 + 0x27 <= uVar15) {
                    fcn.180004720();
                    goto code_r0x0001800156a8;
                }
                iVar10 = fcn.180459890();
                iVar3 = 0;
                if (iVar10 == 0) goto code_r0x0001800155f4;
                pauVar21 = (undefined (*) [16])(iVar10 + 0x27U & 0xffffffffffffffe0);
                *(int64_t *)(pauVar21[-1] + 8) = iVar10;
            }
        }
        var_88h = (int64_t)(pauVar21 + uVar14);
        puVar4 = (undefined8 *)piVar12[1];
        var_90h = (int64_t)pauVar21;
        for (puVar11 = (undefined8 *)*piVar12; puVar11 != puVar4; puVar11 = puVar11 + 2) {
            *(undefined8 *)(undefined *)var_90h = 0;
            *(undefined8 *)((undefined *)var_90h + 8) = 0;
            if (puVar11[1] != 0) {
                LOCK();
                piVar1 = (int32_t *)(puVar11[1] + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            *(undefined8 *)(undefined *)var_90h = *puVar11;
            *(undefined8 *)((undefined *)var_90h + 8) = puVar11[1];
            var_90h = var_90h + 0x10;
        }
        var_98h = (int64_t)pauVar21;
        pauVar20 = (undefined (*) [16])var_90h;
        unaff_R15 = pauVar21;
    }
    iVar10 = var_88h;
    iVar22 = -1;
    for (pauVar21 = unaff_R15; iVar3 = -1, pauVar21 != pauVar20; pauVar21 = pauVar21 + 1) {
        func_0x00018000b4d0(&var_78h, *(undefined8 *)(*(int64_t *)(*(int64_t *)*pauVar21 + 0x18) + 8));
        iVar13 = var_78h;
        piVar12 = &var_78h;
        if (0xf < (uint64_t)var_60h) {
            piVar12 = (int64_t *)var_78h;
        }
        if (var_68h == 7) {
            iVar9 = func_0x000180497f30(piVar12, &var_b8h);
            bVar23 = iVar9 == 0;
        } else {
            bVar23 = false;
        }
        if (0xf < (uint64_t)var_60h) {
            uVar14 = var_60h + 1;
            iVar16 = iVar13;
            if (uVar14 < 0x1000) {
code_r0x000180015497:
                fcn.180459c3c(iVar16, uVar14);
                goto code_r0x00018001549f;
            }
            iVar16 = *(int64_t *)(iVar13 + -8);
            if ((iVar13 - iVar16) - 8U < 0x20) {
                uVar14 = var_60h + 0x28;
                goto code_r0x000180015497;
            }
            pcVar7 = (code *)swi(0x29);
            (*pcVar7)(5);
            puVar18 = auStack_e0;
code_r0x0001800154c7:
            if (*(int64_t *)(*pauVar21 + 8) != 0) {
                LOCK();
                piVar1 = (int32_t *)(*(int64_t *)(*pauVar21 + 8) + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            iVar10 = *(int64_t *)*pauVar21;
            piVar12 = *(int64_t **)(*pauVar21 + 8);
            _var_78h = *pauVar21;
            pauVar21 = unaff_R15;
            if (unaff_R15 != (undefined (*) [16])0x0) goto joined_r0x0001800154f2;
            goto code_r0x00018001560e;
        }
code_r0x00018001549f:
        puVar18 = auStack_e8;
        if (bVar23) goto code_r0x0001800154c7;
    }
    _var_78h = ZEXT816(0);
    puVar18 = auStack_e8;
    iVar22 = -1;
    pauVar21 = unaff_R15;
    if (unaff_R15 != (undefined (*) [16])0x0) {
        for (; pauVar21 != pauVar20; pauVar21 = pauVar21 + 1) {
            piVar12 = *(int64_t **)(*pauVar21 + 8);
            if (piVar12 != (int64_t *)0x0) {
                LOCK();
                piVar5 = piVar12 + 1;
                iVar22 = *(int32_t *)piVar5;
                *(int32_t *)piVar5 = *(int32_t *)piVar5 + -1;
                UNLOCK();
                if (iVar22 == 1) {
                    (**(code **)*piVar12)(piVar12);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
                    iVar22 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar22 == 1) {
                        (**(code **)(*piVar12 + 8))(piVar12);
                    }
                }
            }
        }
        pauVar21 = (undefined (*) [16])(iVar10 - (int64_t)unaff_R15 & 0xfffffffffffffff0);
        iVar22 = -1;
        if ((undefined (*) [16])0xfff < pauVar21) {
            pauVar20 = unaff_R15 + -1;
            unaff_R15 = (undefined (*) [16])((int64_t)unaff_R15 + (-8 - (int64_t)*(undefined (**) [16])(*pauVar20 + 8)))
            ;
            puVar18 = auStack_e8;
            if ((undefined (*) [16])0x1f < unaff_R15) goto code_r0x0001800155f4;
            pauVar21 = (undefined (*) [16])(pauVar21[2] + 7);
            unaff_R15 = *(undefined (**) [16])(*pauVar20 + 8);
            puVar17 = auStack_e8;
            iVar22 = -1;
        }
code_r0x0001800155fe:
        *(undefined8 *)(puVar17 + -8) = 0x180015606;
        fcn.180459c3c(unaff_R15, pauVar21);
        puVar18 = puVar17;
    }
    piVar12 = (int64_t *)var_70h;
    iVar10 = var_78h;
    goto code_r0x00018001560e;
joined_r0x0001800154f2:
    for (; pauVar21 != pauVar20; pauVar21 = pauVar21 + 1) {
        piVar5 = *(int64_t **)(*pauVar21 + 8);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar5 + 1;
            iVar9 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar9 == 1) {
                pcVar7 = *(code **)*piVar5;
                *(undefined8 *)(puVar18 + -8) = 0x180015512;
                (*pcVar7)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar9 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar9 == 1) {
                    pcVar7 = *(code **)(*piVar5 + 8);
                    *(undefined8 *)(puVar18 + -8) = 0x180015528;
                    (*pcVar7)(piVar5);
                }
            }
        }
    }
    uVar14 = var_88h - (int64_t)unaff_R15 & 0xfffffffffffffff0;
    if (uVar14 < 0x1000) {
        *(undefined8 *)(puVar18 + -8) = 0x180015570;
        fcn.180459c3c(unaff_R15);
    } else {
        iVar13 = *(int64_t *)(unaff_R15[-1] + 8);
        unaff_R15 = (undefined (*) [16])((int64_t)unaff_R15 + (-8 - iVar13));
        if ((undefined (*) [16])0x1f < unaff_R15) {
code_r0x0001800155f4:
            iVar22 = iVar3;
            pcVar7 = (code *)swi(0x29);
            (*pcVar7)(5);
            puVar17 = puVar18 + 8;
            goto code_r0x0001800155fe;
        }
        *(undefined8 *)(puVar18 + -8) = 0x180015563;
        fcn.180459c3c(iVar13, uVar14 + 0x27);
    }
code_r0x00018001560e:
    if (iVar10 != 0) {
        iVar13 = *(int64_t *)(*(int64_t *)(iVar10 + 0x138) + 0x2d8);
        if (iVar13 == 0) {
            iVar13 = *(int64_t *)(*(int64_t *)(iVar10 + 0x138) + 0x2e8);
        }
        var_c0h = *(int64_t *)(var_c8h + 0x198);
        uVar6 = *(undefined8 *)(var_80h + 8);
        *(undefined8 *)(puVar18 + -8) = 0x180015652;
        var_c8h = iVar13;
        func_0x000180013fd0(uVar6, &var_c8h);
    }
    puVar19 = puVar18;
    if (piVar12 != (int64_t *)0x0) {
        LOCK();
        piVar5 = piVar12 + 1;
        iVar3 = *(int32_t *)piVar5;
        *(int32_t *)piVar5 = *(int32_t *)piVar5 + iVar22;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar7 = *(code **)*piVar12;
            *(undefined8 *)(puVar18 + -8) = 0x18001566d;
            (*pcVar7)(piVar12);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
            iVar3 = *piVar1;
            *piVar1 = *piVar1 + iVar22;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar7 = *(code **)(*piVar12 + 8);
                *(undefined8 *)(puVar18 + -8) = 0x180015682;
                (*pcVar7)(piVar12);
            }
        }
    }
code_r0x000180015682:
    *(undefined8 *)(puVar19 + -8) = 0x18001568e;
    func_0x000180459870(var_58h ^ (uint64_t)puVar19);
    return;
}

// ============================================================
// Function: FUN_180015950
// Address: 0x180015950
// Size: 116 bytes
// ============================================================
undefined8 * fcn.180015950(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 *arg3_00;
    undefined8 uVar1;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    arg3_00 = *(undefined8 **)arg1;
    if (*(char *)(arg2 + 0x19) == '\0') {
        arg3_00 = (undefined8 *)fcn.180016a70(arg1, arg3_00, arg2 + 0x20);
        arg3_00[1] = arg3;
        *(undefined *)(arg3_00 + 3) = *(undefined *)(arg2 + 0x18);
        uVar1 = fcn.180015950(arg1, *(int64_t *)arg2, (int64_t)arg3_00);
        *arg3_00 = uVar1;
        uVar1 = fcn.180015950(arg1, *(int64_t *)(arg2 + 0x10), (int64_t)arg3_00);
        arg3_00[2] = uVar1;
    }
    return arg3_00;
}

// ============================================================
// Function: FUN_180015a00
// Address: 0x180015a00
// Size: 3912 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f2h
// WARNING: [rz-ghidra] Detected overlap for variable var_f1h

void fcn.180015a00(int64_t arg1, int64_t arg2, int64_t arg_30h)
{
    char cVar1;
    undefined8 uVar2;
    code *pcVar3;
    undefined auVar4 [16];
    int32_t iVar5;
    uint32_t uVar6;
    int64_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t *piVar10;
    int32_t *piVar11;
    int64_t iVar12;
    undefined8 *puVar13;
    undefined8 *puVar14;
    uint8_t *puVar15;
    uint64_t uVar16;
    uint8_t *puVar17;
    undefined *puVar18;
    undefined *puVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    uint64_t uVar22;
    int64_t *piVar23;
    undefined4 uVar24;
    int64_t var_18h;
    undefined8 uStack_290;
    undefined auStack_288 [8];
    undefined auStack_280 [24];
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_250h;
    int64_t var_248h;
    int64_t var_238h;
    int64_t var_218h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    undefined4 var_d0h;
    int64_t var_cch;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    
    puVar19 = auStack_288;
    puVar18 = auStack_288;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_288;
    uVar16 = 0;
    iVar12 = arg2;
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        iVar12 = *(int64_t *)arg2;
    }
    if (((*(uint64_t *)(arg2 + 0x10) < 8) ||
        (iVar8 = *(uint64_t *)(arg2 + 0x10) + iVar12, iVar7 = func_0x0001804581c0(iVar12, iVar8, 0x18061fe70, 8),
        iVar7 == iVar8)) || (iVar7 - iVar12 == -1)) {
        iVar12 = func_0x000180013ef0(arg2, 0x18061fe90, 0);
        if (iVar12 == -1) {
            puVar19 = auStack_288;
            if (*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x2e0) != 0) {
                piVar23 = *(int64_t **)(*(int64_t *)(arg1 + 8) + 0x2e0);
                (**(code **)(*piVar23 + 0x10))(piVar23, arg2);
                puVar19 = auStack_288;
            }
        } else {
            stack0xffffffffffffff38 = 0xc;
            var_c0h = 0xf;
            var_d8h = 0x726f676574614322;
            var_d0h = 0x223a2279;
            var_cch._0_4_ = 0;
            var_260h = arg2;
            fcn.1800141a0((int64_t)&var_260h, (int64_t)&var_78h, (int64_t)&var_d8h);
            if (0xf < (uint64_t)var_c0h) {
                iVar12 = var_d8h;
                puVar19 = auStack_288;
                if ((0xfff < var_c0h + 1U) &&
                   (iVar12 = *(int64_t *)(var_d8h + -8), puVar19 = auStack_288, 0x1f < (var_d8h - iVar12) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar12 = (*pcVar3)(5);
                    puVar19 = auStack_280;
                }
                *(undefined8 *)(puVar19 + -8) = 0x180016568;
                fcn.180459c3c(iVar12);
            }
            var_e8h = 7;
            var_e0h = 0xf;
            _var_f8h = ZEXT716(0x223a2279654b22);
            *(undefined8 *)(puVar19 + -8) = 0x1800165cf;
            fcn.1800141a0((int64_t)(puVar19 + 0x28), (int64_t)&var_d8h, (int64_t)&var_f8h);
            if (0xf < (uint64_t)var_e0h) {
                iVar12 = var_f8h;
                if ((0xfff < var_e0h + 1U) && (iVar12 = *(int64_t *)(var_f8h + -8), 0x1f < (var_f8h - iVar12) - 8U)) {
                    pcVar3 = (code *)swi(0x29);
                    iVar12 = (*pcVar3)(5);
                    puVar19 = puVar19 + 8;
                }
                *(undefined8 *)(puVar19 + -8) = 0x180016616;
                fcn.180459c3c(iVar12);
            }
            var_e8h = 0;
            var_e0h = 0xf;
            auVar4[15] = 0;
            auVar4._0_15_ = stack0xffffffffffffff09;
            _var_f8h = auVar4 << 8;
            if ((var_68h != 0) && (stack0xffffffffffffff38 != 0)) {
                *(undefined8 *)(puVar19 + -8) = 0x180016650;
                puVar9 = (undefined8 *)func_0x000180016e80();
                uVar2 = *puVar9;
                *(undefined8 *)(puVar19 + -8) = 0x18001665f;
                iVar12 = func_0x000180017980(uVar2, &var_78h);
                if (iVar12 != 0) {
                    *(undefined8 *)(puVar19 + -8) = 0x180016677;
                    iVar12 = func_0x000180016e00(iVar12, &var_d8h);
                    if (iVar12 != 0) {
                        *(undefined8 *)(puVar19 + -8) = 0x180016695;
                        iVar8 = func_0x000180013ef0(arg2, 0x18061ff10, 0);
                        if (iVar8 != -1) {
                            uVar16 = iVar8 + 8;
                            uVar20 = *(uint64_t *)(arg2 + 0x10);
                            iVar8 = arg2;
                            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                                iVar8 = *(int64_t *)arg2;
                            }
                            if (uVar16 < uVar20) {
                                puVar17 = (uint8_t *)(iVar8 + uVar16);
                                if ((uVar20 - uVar16) + 2 < 0x10) {
                                    *(undefined8 *)(puVar19 + -8) = 0x18001670c;
                                    func_0x0001804986e0(puVar19 + 0x70, 0, 0x100);
                                    puVar15 = (uint8_t *)0x18061ff1c;
                                    do {
                                        puVar19[(uint64_t)*puVar15 + 0x70] = 1;
                                        puVar15 = puVar15 + 1;
                                    } while (puVar15 != (uint8_t *)0x18061ff1e);
                                    for (; puVar17 < (uint8_t *)(uVar20 + iVar8); puVar17 = puVar17 + 1) {
                                        if (puVar19[(uint64_t)*puVar17 + 0x70] != '\0') {
                                            iVar8 = (int64_t)puVar17 - iVar8;
                                            goto code_r0x00018001675a;
                                        }
                                    }
                                } else {
                                    *(undefined8 *)(puVar19 + -8) = 0x1800166e8;
                                    iVar8 = func_0x000180458040(puVar17, uVar20 - uVar16, 0x18061ff1c, 2);
                                    if (iVar8 != -1) {
                                        iVar8 = iVar8 + uVar16;
                                    }
code_r0x00018001675a:
                                    if (iVar8 != -1) {
                                        *(undefined8 *)(puVar19 + -8) = 0x18001677c;
                                        fcn.180014780(arg2, (int64_t)&var_98h, uVar16, iVar8 - uVar16);
                                        if (var_88h != 0) {
                                            iVar5 = *(int32_t *)(iVar12 + 0x90);
                                            if (iVar5 == 0) {
                                                piVar23 = &var_98h;
                                                if (0xf < (uint64_t)var_80h) {
                                                    piVar23 = (int64_t *)var_98h;
                                                }
                                                if (var_88h == 4) {
                                                    *(undefined8 *)(puVar19 + -8) = 0x180016883;
                                                    func_0x000180497f30(piVar23, 0x1805ab294);
                                                }
                                                *(undefined8 *)(puVar19 + -8) = 0x180016890;
                                                fcn.180014580(iVar12);
                                            } else if (iVar5 == 1) {
                                                *(undefined8 *)(puVar19 + -8) = 0x18001684a;
                                                uVar6 = func_0x000180013c20(&var_98h);
                                                *(undefined8 *)(puVar19 + -8) = 0x180016854;
                                                fcn.1800145d0(iVar12, (uint64_t)uVar6);
                                            } else if (iVar5 == 2) {
                                                *(undefined8 *)(puVar19 + -8) = 0x180016831;
                                                func_0x000180013c90(&var_98h);
                                                *(undefined8 *)(puVar19 + -8) = 0x18001683c;
                                                fcn.180014620(iVar12);
                                            } else if ((iVar5 == 3) && (1 < (uint64_t)var_88h)) {
                                                piVar23 = &var_98h;
                                                if (0xf < (uint64_t)var_80h) {
                                                    piVar23 = (int64_t *)var_98h;
                                                }
                                                if (*(char *)piVar23 == '\"') {
                                                    piVar23 = &var_98h;
                                                    if (0xf < (uint64_t)var_80h) {
                                                        piVar23 = (int64_t *)var_98h;
                                                    }
                                                    if (*(char *)(var_88h + -1 + (int64_t)piVar23) == '\"') {
                                                        *(undefined8 *)(puVar19 + -8) = 0x180016818;
                                                        iVar8 = fcn.180014780((int64_t)&var_98h, 
                                                                              (int64_t)(puVar19 + 0x50), 1, var_88h + -2
                                                                             );
                                                        *(undefined8 *)(puVar19 + -8) = 0x180016823;
                                                        fcn.180014680(iVar12, iVar8);
                                                    }
                                                }
                                            }
                                        }
                                        *(undefined8 *)(puVar19 + -8) = 0x18001689d;
                                        fcn.180004e40(&var_98h);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            *(undefined8 *)(puVar19 + -8) = 0x1800168aa;
            fcn.180004e40(&var_d8h);
            *(undefined8 *)(puVar19 + -8) = 0x1800168b7;
            fcn.180004e40(&var_78h);
        }
    } else {
        iVar12 = arg2;
        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
            iVar12 = *(int64_t *)arg2;
        }
        if ((*(uint64_t *)(arg2 + 0x10) < 10) ||
           (iVar8 = *(uint64_t *)(arg2 + 0x10) + iVar12, iVar7 = func_0x0001804581c0(iVar12, iVar8, 0x18061fe80, 10),
           iVar7 == iVar8)) {
            iVar7 = -1;
        } else {
            iVar7 = iVar7 - iVar12;
        }
        puVar19 = auStack_288;
        if (iVar7 != -1) {
            uVar20 = iVar7 + 10;
            _var_118h = ZEXT816(0);
            var_108h = 0;
            var_100h = 0;
            if (*(uint64_t *)(arg2 + 0x10) < uVar20) {
code_r0x00018001690e:
                fcn.18000f930();
code_r0x000180016914:
                fcn.1804546f8(0x18061fe10);
                pcVar3 = (code *)swi(3);
                (*pcVar3)();
                return;
            }
            iVar8 = *(uint64_t *)(arg2 + 0x10) - uVar20;
            iVar12 = -1;
            if (iVar8 != -1) {
                iVar12 = iVar8;
            }
            if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                arg2 = *(int64_t *)arg2;
            }
            fcn.180004830(&var_118h, arg2 + uVar20, iVar12);
            puVar9 = (undefined8 *)func_0x000180016e80();
            piVar11 = (int32_t *)var_100h;
            uVar20 = var_108h;
            puVar9 = (undefined8 *)*puVar9;
            piVar23 = (int64_t *)var_118h;
            var_260h = (int64_t)puVar9;
            if (var_108h != 0) {
                uVar16 = 0;
                do {
                    piVar10 = &var_118h;
                    if (0xf < piVar11) {
                        piVar10 = piVar23;
                    }
                    iVar5 = func_0x00018046ce40((int32_t)*(char *)((int64_t)piVar10 + uVar16));
                } while ((iVar5 != 0) && (uVar16 = uVar16 + 1, uVar16 < uVar20));
            }
            puVar19 = auStack_288;
            if (uVar16 < uVar20) {
                uVar21 = uVar16 + 1;
                piVar10 = &var_118h;
                if (0xf < piVar11) {
                    piVar10 = piVar23;
                }
                puVar19 = auStack_288;
                var_268h = uVar21;
                if ((*(char *)((int64_t)piVar10 + uVar16) == '{') && (puVar19 = auStack_288, uVar21 < uVar20)) {
                    do {
                        do {
                            piVar10 = &var_118h;
                            if ((int32_t *)0xf < piVar11) {
                                piVar10 = piVar23;
                            }
                            iVar5 = func_0x00018046ce40((int32_t)*(char *)((int64_t)piVar10 + uVar21));
                        } while ((iVar5 != 0) && (uVar21 = uVar21 + 1, var_268h = uVar21, uVar21 < uVar20));
                        piVar10 = &var_118h;
                        if ((int32_t *)0xf < piVar11) {
                            piVar10 = piVar23;
                        }
                        puVar19 = auStack_288;
                        if (*(char *)((int64_t)piVar10 + uVar21) == '}') break;
                        piVar10 = &var_118h;
                        if ((int32_t *)0xf < piVar11) {
                            piVar10 = piVar23;
                        }
                        if (*(char *)((int64_t)piVar10 + uVar21) != ',') {
                            piVar10 = &var_118h;
                            if ((int32_t *)0xf < piVar11) {
                                piVar10 = piVar23;
                            }
                            puVar19 = auStack_288;
                            if (*(char *)((int64_t)piVar10 + uVar21) != '\"') break;
                            func_0x000180017a00(&var_f8h, &var_118h, &var_268h);
                            piVar11 = (int32_t *)var_100h;
                            uVar20 = var_108h;
                            piVar23 = (int64_t *)var_118h;
                            for (uVar16 = var_268h; uVar16 < uVar20; uVar16 = uVar16 + 1) {
                                piVar10 = &var_118h;
                                if (0xf < piVar11) {
                                    piVar10 = piVar23;
                                }
                                iVar5 = func_0x00018046ce40((int32_t)*(char *)((int64_t)piVar10 + uVar16));
                                if (iVar5 == 0) break;
                            }
                            piVar10 = &var_118h;
                            if (0xf < piVar11) {
                                piVar10 = piVar23;
                            }
                            puVar19 = auStack_288;
                            if (*(char *)(uVar16 + (int64_t)piVar10) == ':') {
                                do {
                                    uVar21 = uVar16;
                                    uVar16 = uVar21 + 1;
                                    if (uVar20 <= uVar16) break;
                                    piVar10 = &var_118h;
                                    if (0xf < piVar11) {
                                        piVar10 = piVar23;
                                    }
                                    iVar5 = func_0x00018046ce40((int32_t)*(char *)(uVar16 + (int64_t)piVar10));
                                } while (iVar5 != 0);
                                uVar22 = var_e0h;
                                uVar21 = uVar21 + 2;
                                piVar10 = &var_118h;
                                if (0xf < piVar11) {
                                    piVar10 = piVar23;
                                }
                                puVar19 = auStack_288;
                                var_268h = uVar21;
                                if (*(char *)((int64_t)piVar10 + uVar16) != '{') goto code_r0x000180016417;
                                var_258h = *puVar9;
                                puVar9 = (undefined8 *)puVar9[1];
                                iVar12 = var_f8h;
                                for (; (undefined8 *)var_258h != puVar9; var_258h = var_258h + 0x38) {
                                    piVar10 = &var_f8h;
                                    if (0xf < uVar22) {
                                        piVar10 = (int64_t *)iVar12;
                                    }
                                    puVar13 = (undefined8 *)var_258h;
                                    if (0xf < *(uint64_t *)(var_258h + 0x18)) {
                                        puVar13 = *(undefined8 **)var_258h;
                                    }
                                    if ((*(int64_t *)(var_258h + 0x10) == var_e8h) &&
                                       ((*(int64_t *)(var_258h + 0x10) == 0 ||
                                        (iVar5 = func_0x000180497f30(puVar13, piVar10), iVar5 == 0))))
                                    goto code_r0x000180015d85;
                                }
                                var_258h = 0;
code_r0x000180015d85:
                                if (uVar21 < uVar20) {
                                    do {
                                        do {
                                            piVar10 = &var_118h;
                                            if ((int32_t *)0xf < piVar11) {
                                                piVar10 = piVar23;
                                            }
                                            iVar5 = func_0x00018046ce40((int32_t)*(char *)(uVar21 + (int64_t)piVar10));
                                        } while ((iVar5 != 0) &&
                                                (uVar21 = uVar21 + 1, var_268h = uVar21, uVar21 < uVar20));
                                        piVar10 = &var_118h;
                                        if ((int32_t *)0xf < piVar11) {
                                            piVar10 = piVar23;
                                        }
                                        if (*(char *)((int64_t)piVar10 + uVar21) == '}') {
                                            uVar21 = uVar21 + 1;
                                            var_268h = uVar21;
                                            break;
                                        }
                                        piVar10 = &var_118h;
                                        if ((int32_t *)0xf < piVar11) {
                                            piVar10 = piVar23;
                                        }
                                        if (*(char *)((int64_t)piVar10 + uVar21) == ',') {
                                            uVar21 = uVar21 + 1;
                                            var_268h = uVar21;
                                        } else {
                                            piVar10 = &var_118h;
                                            if ((int32_t *)0xf < piVar11) {
                                                piVar10 = piVar23;
                                            }
                                            puVar19 = auStack_288;
                                            if (*(char *)((int64_t)piVar10 + uVar21) != '\"') goto code_r0x000180016417;
                                            func_0x000180017a00(&var_d8h, &var_118h, &var_268h);
                                            piVar11 = (int32_t *)var_100h;
                                            iVar12 = var_108h;
                                            piVar23 = (int64_t *)var_118h;
                                            for (uVar16 = var_268h; uVar16 < (uint64_t)iVar12; uVar16 = uVar16 + 1) {
                                                piVar10 = &var_118h;
                                                if (0xf < piVar11) {
                                                    piVar10 = piVar23;
                                                }
                                                iVar5 = func_0x00018046ce40((int32_t)*(char *)(uVar16 + (int64_t)piVar10
                                                                                              ));
                                                if (iVar5 == 0) break;
                                            }
                                            var_268h = uVar16 + 1;
                                            piVar10 = &var_118h;
                                            if (0xf < piVar11) {
                                                piVar10 = piVar23;
                                            }
                                            puVar19 = auStack_288;
                                            uVar20 = var_268h;
                                            if (*(char *)((int64_t)piVar10 + uVar16) != ':') {
code_r0x0001800163b4:
                                                puVar18 = puVar19;
                                                if (0xf < (uint64_t)var_c0h) {
                                                    iVar12 = var_d8h;
                                                    if ((0xfff < var_c0h + 1U) &&
                                                       (iVar12 = *(int64_t *)(var_d8h + -8),
                                                       0x1f < (var_d8h - *(int64_t *)(var_d8h + -8)) - 8U)) {
code_r0x0001800163eb:
                                                        pcVar3 = (code *)swi(0x29);
                                                        iVar12 = (*pcVar3)(5);
                                                        puVar18 = puVar18 + 8;
                                                    }
                                                    *(undefined8 *)(puVar18 + -8) = 0x1800163fa;
                                                    fcn.180459c3c(iVar12);
                                                }
                                                stack0xffffffffffffff38 = 0;
                                                var_c0h = 0xf;
                                                var_d8h = var_d8h & 0xffffffffffffff00;
                                                puVar19 = puVar18;
                                                goto code_r0x000180016417;
                                            }
                                            for (; uVar20 < (uint64_t)iVar12; uVar20 = uVar20 + 1) {
                                                piVar10 = &var_118h;
                                                if (0xf < piVar11) {
                                                    piVar10 = piVar23;
                                                }
                                                iVar5 = func_0x00018046ce40((int32_t)*(char *)(uVar20 + (int64_t)piVar10
                                                                                              ));
                                                if (iVar5 == 0) break;
                                            }
                                            iVar8 = stack0xffffffffffffff38;
                                            var_268h = uVar20;
                                            if (var_258h != 0) {
                                                puVar13 = *(undefined8 **)(var_258h + 0x28);
                                                for (puVar9 = *(undefined8 **)(var_258h + 0x20); puVar9 != puVar13;
                                                    puVar9 = puVar9 + 0x13) {
                                                    piVar10 = &var_d8h;
                                                    if (0xf < (uint64_t)var_c0h) {
                                                        piVar10 = (int64_t *)var_d8h;
                                                    }
                                                    puVar14 = puVar9;
                                                    if (0xf < (uint64_t)puVar9[3]) {
                                                        puVar14 = (undefined8 *)*puVar9;
                                                    }
                                                    if ((puVar9[2] == iVar8) &&
                                                       ((puVar9[2] == 0 ||
                                                        (iVar5 = func_0x000180497f30(puVar14, piVar10), iVar5 == 0))))
                                                    goto code_r0x000180015f47;
                                                }
                                            }
                                            puVar9 = (undefined8 *)0x0;
code_r0x000180015f47:
                                            piVar10 = &var_118h;
                                            if (0xf < piVar11) {
                                                piVar10 = piVar23;
                                            }
                                            if (*(char *)((int64_t)piVar10 + uVar20) == '\"') {
                                                func_0x000180017a00(&var_78h, &var_118h, &var_268h);
                                                if ((puVar9 != (undefined8 *)0x0) && (*(int32_t *)(puVar9 + 0x12) == 3))
                                                {
                                                    iVar12 = fcn.18000b4d0(&var_238h, &var_78h);
                                                    fcn.180014680((int64_t)puVar9, iVar12);
                                                }
                                                uVar21 = var_268h;
                                                if (0xf < (uint64_t)var_60h) {
                                                    uVar16 = var_60h + 1;
                                                    iVar12 = var_78h;
                                                    if (0xfff < uVar16) {
                                                        iVar12 = *(int64_t *)(var_78h + -8);
                                                        if (0x1f < (var_78h - iVar12) - 8U) {
code_r0x0001800163ad:
                                                            pcVar3 = (code *)swi(0x29);
                                                            (*pcVar3)(5);
                                                            puVar19 = auStack_280;
                                                            goto code_r0x0001800163b4;
                                                        }
                                                        uVar16 = var_60h + 0x28;
                                                    }
                                                    fcn.180459c3c(iVar12, uVar16);
                                                    uVar21 = var_268h;
                                                }
                                            } else {
                                                uVar21 = uVar20;
                                                if (uVar20 < (uint64_t)iVar12) {
                                                    while( true ) {
                                                        piVar10 = piVar23;
                                                        if (piVar11 < 0x10) {
                                                            piVar10 = &var_118h;
                                                        }
                                                        if (*(char *)((int64_t)piVar10 + uVar21) == ',') break;
                                                        piVar10 = &var_118h;
                                                        if (0xf < piVar11) {
                                                            piVar10 = piVar23;
                                                        }
                                                        if ((*(char *)((int64_t)piVar10 + uVar21) == '}') ||
                                                           (uVar21 = uVar21 + 1, var_268h = uVar21,
                                                           (uint64_t)iVar12 <= uVar21)) break;
                                                    }
                                                }
                                                _var_b8h = ZEXT816(0);
                                                var_a8h = 0;
                                                var_a0h = 0;
                                                if ((uint64_t)iVar12 < uVar20) {
                                                    fcn.18000f930();
                                                    goto code_r0x00018001690e;
                                                }
                                                uVar16 = uVar21 - uVar20;
                                                if (iVar12 - uVar20 < uVar21 - uVar20) {
                                                    uVar16 = iVar12 - uVar20;
                                                }
                                                piVar10 = &var_118h;
                                                if (0xf < piVar11) {
                                                    piVar10 = piVar23;
                                                }
                                                fcn.180004830(&var_b8h, (int64_t)piVar10 + uVar20, uVar16);
                                                iVar12 = var_a8h;
                                                if (puVar9 != (undefined8 *)0x0) {
                                                    piVar10 = &var_b8h;
                                                    if (0xf < (uint64_t)var_a0h) {
                                                        piVar10 = (int64_t *)var_b8h;
                                                    }
                                                    if (((var_a8h == 4) &&
                                                        (iVar5 = func_0x000180497f30(piVar10, 0x1805ab294, 4),
                                                        iVar5 == 0)) && (*(int32_t *)(puVar9 + 0x12) == 0)) {
                                                        cVar1 = *(char *)(puVar9 + 0xc);
                                                        if (cVar1 != '\0') {
                                                            if (((cVar1 != -1) && (cVar1 != '\0')) &&
                                                               ((cVar1 != '\x01' && (cVar1 != '\x02')))) {
                                                                fcn.180004e40(puVar9 + 8);
                                                            }
                                                            *(undefined *)(puVar9 + 0xc) = 0;
                                                        }
                                                        *(undefined *)(puVar9 + 8) = 1;
                                                    } else {
                                                        piVar10 = &var_b8h;
                                                        if (0xf < (uint64_t)var_a0h) {
                                                            piVar10 = (int64_t *)var_b8h;
                                                        }
                                                        if (((iVar12 == 5) &&
                                                            (iVar5 = func_0x000180497f30(piVar10, 0x1805ab28c, 5),
                                                            iVar5 == 0)) && (*(int32_t *)(puVar9 + 0x12) == 0)) {
                                                            cVar1 = *(char *)(puVar9 + 0xc);
                                                            if (cVar1 != '\0') {
                                                                if (((cVar1 != -1) && (cVar1 != '\0')) &&
                                                                   ((cVar1 != '\x01' && (cVar1 != '\x02')))) {
                                                                    fcn.180004e40(puVar9 + 8);
                                                                }
                                                                *(undefined *)(puVar9 + 0xc) = 0;
                                                            }
                                                            *(undefined *)(puVar9 + 8) = 0;
                                                        } else if (*(int32_t *)(puVar9 + 0x12) == 1) {
                                                            piVar11 = (int32_t *)fcn.18046b77c();
                                                            piVar10 = &var_b8h;
                                                            if (0xf < (uint64_t)var_a0h) {
                                                                piVar10 = (int64_t *)var_b8h;
                                                            }
                                                            *piVar11 = 0;
                                                            uVar6 = func_0x00018046c52c(piVar10, &var_250h, 10);
                                                            piVar23 = (int64_t *)(uint64_t)uVar6;
                                                            if (piVar10 == (int64_t *)var_250h) {
                                                                func_0x0001804546b0(0x18061fdf8);
                                                                pcVar3 = (code *)swi(3);
                                                                (*pcVar3)();
                                                                return;
                                                            }
                                                            if (*piVar11 == 0x22) goto code_r0x000180016914;
                                                            cVar1 = *(char *)(puVar9 + 0xc);
                                                            if (cVar1 != '\x01') {
                                                                if ((((cVar1 != -1) && (cVar1 != '\0')) &&
                                                                    (cVar1 != '\x01')) && (cVar1 != '\x02')) {
                                                                    fcn.180004e40(puVar9 + 8);
                                                                }
                                                                *(undefined *)(puVar9 + 0xc) = 1;
                                                            }
                                                            *(uint32_t *)(puVar9 + 8) = uVar6;
                                                        } else if (*(int32_t *)(puVar9 + 0x12) == 2) {
                                                            piVar23 = (int64_t *)fcn.18046b77c();
                                                            piVar10 = &var_b8h;
                                                            if (0xf < (uint64_t)var_a0h) {
                                                                piVar10 = (int64_t *)var_b8h;
                                                            }
                                                            *(int32_t *)piVar23 = 0;
                                                            uVar24 = func_0x00018046b634(piVar10, &var_248h);
                                                            if (piVar10 == (int64_t *)var_248h) {
                                                                func_0x0001804546b0(0x18061fe30);
                                                                pcVar3 = (code *)swi(3);
                                                                (*pcVar3)();
                                                                return;
                                                            }
                                                            if (*(int32_t *)piVar23 == 0x22) {
                                                                fcn.1804546f8(0x18061fe48);
                                                                pcVar3 = (code *)swi(3);
                                                                (*pcVar3)();
                                                                return;
                                                            }
                                                            cVar1 = *(char *)(puVar9 + 0xc);
                                                            if (cVar1 == '\x02') {
                                                                *(undefined4 *)(puVar9 + 8) = uVar24;
                                                            } else {
                                                                if (((cVar1 != -1) && (cVar1 != '\0')) &&
                                                                   ((cVar1 != '\x01' && (cVar1 != '\x02')))) {
                                                                    fcn.180004e40(puVar9 + 8);
                                                                }
                                                                *(undefined4 *)(puVar9 + 8) = uVar24;
                                                                *(undefined *)(puVar9 + 0xc) = 2;
                                                            }
                                                        }
                                                    }
                                                }
                                                if (0xf < (uint64_t)var_a0h) {
                                                    uVar16 = var_a0h + 1;
                                                    iVar12 = var_b8h;
                                                    if (0xfff < uVar16) {
                                                        iVar12 = *(int64_t *)(var_b8h + -8);
                                                        if (0x1f < (var_b8h - iVar12) - 8U) goto code_r0x0001800163ad;
                                                        uVar16 = var_a0h + 0x28;
                                                    }
                                                    fcn.180459c3c(iVar12, uVar16);
                                                }
                                            }
                                            if (0xf < (uint64_t)var_c0h) {
                                                uVar16 = var_c0h + 1;
                                                iVar12 = var_d8h;
                                                if (0xfff < uVar16) {
                                                    iVar12 = *(int64_t *)(var_d8h + -8);
                                                    if (0x1f < (var_d8h - iVar12) - 8U) goto code_r0x0001800163eb;
                                                    uVar16 = var_c0h + 0x28;
                                                }
                                                fcn.180459c3c(iVar12, uVar16);
                                            }
                                            uVar20 = var_108h;
                                            piVar23 = (int64_t *)var_118h;
                                            piVar11 = (int32_t *)var_100h;
                                        }
                                    } while (uVar21 < uVar20);
                                    iVar12 = var_f8h;
                                    uVar22 = var_e0h;
                                }
                                puVar9 = (undefined8 *)var_260h;
                                if (uVar22 < 0x10) goto code_r0x00018001639f;
                                uVar16 = uVar22 + 1;
                                iVar8 = iVar12;
                                if (uVar16 < 0x1000) {
code_r0x000180016392:
                                    fcn.180459c3c(iVar8, uVar16);
                                    puVar9 = (undefined8 *)var_260h;
                                    goto code_r0x00018001639f;
                                }
                                iVar8 = *(int64_t *)(iVar12 + -8);
                                puVar19 = auStack_288;
                                if ((iVar12 - iVar8) - 8U < 0x20) {
                                    uVar16 = uVar22 + 0x28;
                                    goto code_r0x000180016392;
                                }
code_r0x00018001644e:
                                pcVar3 = (code *)swi(0x29);
                                iVar12 = (*pcVar3)(5);
                                puVar19 = puVar19 + 8;
                            } else {
code_r0x000180016417:
                                if ((uint64_t)var_e0h < 0x10) break;
                                iVar12 = var_f8h;
                                if ((0xfff < var_e0h + 1U) &&
                                   (iVar12 = *(int64_t *)(var_f8h + -8),
                                   0x1f < (var_f8h - *(int64_t *)(var_f8h + -8)) - 8U)) goto code_r0x00018001644e;
                            }
                            *(undefined8 *)(puVar19 + -8) = 0x18001645d;
                            fcn.180459c3c(iVar12);
                            break;
                        }
                        uVar21 = uVar21 + 1;
                        var_268h = uVar21;
code_r0x00018001639f:
                        puVar19 = auStack_288;
                    } while (uVar21 < uVar20);
                }
            }
            if ((int32_t *)0xf < piVar11) {
                if (0xfff < (int64_t)piVar11 + 1U) {
                    iVar12 = piVar23[-1];
                    piVar23 = (int64_t *)((int64_t)piVar23 + (-8 - iVar12));
                    if (piVar23 < (int64_t *)0x20) {
                        *(undefined8 *)(puVar19 + -8) = 0x18001648f;
                        fcn.180459c3c(iVar12, piVar11 + 10);
                        goto code_r0x0001800168d6;
                    }
                    pcVar3 = (code *)swi(0x29);
                    (*pcVar3)(5);
                    puVar19 = puVar19 + 8;
                }
                *(undefined8 *)(puVar19 + -8) = 0x1800164a3;
                fcn.180459c3c(piVar23);
            }
        }
    }
code_r0x0001800168d6:
    *(undefined8 *)(puVar19 + -8) = 0x1800168e5;
    func_0x000180459870(var_58h ^ (uint64_t)puVar19);
    return;
}

// ============================================================
// Function: FUN_180016980
// Address: 0x180016980
// Size: 133 bytes
// ============================================================
void fcn.180016980(int64_t arg1)
{
    undefined auStack_b8 [32];
    int64_t var_98h;
    undefined8 uStack_60;
    int64_t var_58h;
    undefined8 uStack_50;
    int64_t var_20h;
    int64_t var_18h;
    
    var_18h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_b8;
    uStack_60 = 0;
    var_58h = 0x18061ff50;
    uStack_50 = *(undefined8 *)(arg1 + 8);
    var_20h = (int64_t)&var_58h;
    fcn.180014540((int64_t)&var_58h, (int64_t)&var_98h);
    if (var_20h != 0) {
        (**(code **)(*(int64_t *)var_20h + 0x20))
                  (var_20h, CONCAT71((unkint7)((uint64_t)&var_58h >> 8), (int64_t *)var_20h != &var_58h));
    }
    fcn.180459870(var_18h ^ (uint64_t)auStack_b8);
    return;
}

// ============================================================
// Function: FUN_180016a30
// Address: 0x180016a30
// Size: 31 bytes
// ============================================================
void fcn.180016a30(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    fcn.180004e40(arg1 + 0x20);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_180016a70
// Address: 0x180016a70
// Size: 111 bytes
// ============================================================
int64_t * fcn.180016a70(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t *piVar1;
    int64_t var_8h;
    int64_t var_38h;
    int64_t var_30h;
    
    piVar1 = (int64_t *)fcn.180459890(0x60);
    fcn.18000b4d0(piVar1 + 4, arg3);
    fcn.18000b4d0(piVar1 + 8, arg3 + 0x20);
    *piVar1 = arg2;
    piVar1[1] = arg2;
    piVar1[2] = arg2;
    *(undefined2 *)(piVar1 + 3) = 0;
    return piVar1;
}

// ============================================================
// Function: FUN_180016af0
// Address: 0x180016af0
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180016af0(void)
{
    code *pcVar1;
    int64_t var_28h;
    int64_t var_18h;
    
    _var_28h = ZEXT816(0);
    var_18h = 0;
    fcn.180016b20(&var_28h);
    fcn.18045bae0(var_28h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180016b40
// Address: 0x180016b40
// Size: 60 bytes
// ============================================================
int64_t fcn.180016b40(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5648;
    return arg1;
}

// ============================================================
// Function: FUN_180016b80
// Address: 0x180016b80
// Size: 197 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_13h

void fcn.180016b80(int64_t arg1, int64_t arg2)
{
    uint64_t uVar1;
    uint32_t uVar2;
    uint64_t uVar3;
    char *arg2_00;
    undefined auStack_58 [32];
    int64_t var_38h;
    int64_t var_30h;
    char acStack_15 [5];
    int64_t var_10h;
    char *pcVar4;
    
    var_10h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    arg2_00 = acStack_15 + 2;
    uVar3 = arg2 & 0xffffffff;
    if ((int32_t)arg2 < 0) {
        uVar2 = -(int32_t)arg2;
        do {
            pcVar4 = arg2_00;
            arg2_00 = pcVar4 + -1;
            *arg2_00 = (char)uVar2 + (char)((uint64_t)uVar2 / 10) * -10 + '0';
            uVar2 = (uint32_t)((uint64_t)uVar2 / 10);
        } while (uVar2 != 0);
        arg2_00 = pcVar4 + -2;
        *arg2_00 = '-';
    } else {
        do {
            arg2_00 = arg2_00 + -1;
            uVar1 = uVar3 / 10;
            *arg2_00 = (char)uVar3 + (char)uVar1 * -10 + '0';
            uVar3 = uVar1;
        } while ((int32_t)uVar1 != 0);
    }
    var_30h = arg1;
    fcn.180014b30(arg1, (int64_t)arg2_00, (int64_t)(acStack_15 + 2));
    fcn.180459870(var_10h ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_180016c50
// Address: 0x180016c50
// Size: 428 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180016c50(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    char cVar2;
    int64_t var_18h;
    undefined auStack_58 [32];
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    int64_t var_28h;
    undefined4 uStack_20;
    undefined4 uStack_1c;
    uint64_t uStack_18;
    
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    cVar2 = *(char *)(arg2 + 0x20);
    if (cVar2 == -1) {
        cVar2 = *(char *)(arg1 + 0x20);
        if ((((cVar2 != -1) && (cVar2 != '\0')) && (cVar2 != '\x01')) && (cVar2 != '\x02')) {
            fcn.180004e40();
        }
        *(undefined *)(arg1 + 0x20) = 0xff;
    } else if (cVar2 == '\0') {
        cVar2 = *(char *)(arg1 + 0x20);
        if (cVar2 == '\0') {
            *(undefined *)arg1 = *(undefined *)arg2;
        } else {
            if (((cVar2 != -1) && (cVar2 != '\0')) && ((cVar2 != '\x01' && (cVar2 != '\x02')))) {
                fcn.180004e40();
            }
            *(undefined *)(arg1 + 0x20) = 0xff;
            *(undefined *)arg1 = *(undefined *)arg2;
            *(undefined *)(arg1 + 0x20) = 0;
        }
    } else {
        if (cVar2 == '\x01') {
            cVar2 = *(char *)(arg1 + 0x20);
            if (cVar2 != '\x01') {
                if (((cVar2 != -1) && (cVar2 != '\0')) && ((cVar2 != '\x01' && (cVar2 != '\x02')))) {
                    fcn.180004e40();
                }
                *(undefined *)(arg1 + 0x20) = 0xff;
                *(undefined4 *)arg1 = *(undefined4 *)arg2;
                *(undefined *)(arg1 + 0x20) = 1;
                goto code_r0x000180016de1;
            }
        } else {
            if (cVar2 != '\x02') {
                if (*(char *)(arg1 + 0x20) == '\x03') {
                    if (arg1 != arg2) {
                        puVar1 = (undefined8 *)(arg2 + 0x10);
                        if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                            arg2 = *(int64_t *)arg2;
                        }
                        func_0x00018000f180(arg1, arg2, *puVar1);
                    }
                } else {
                    fcn.18000b4d0(&var_38h);
                    cVar2 = *(char *)(arg1 + 0x20);
                    if (((cVar2 != -1) && (cVar2 != '\0')) && ((cVar2 != '\x01' && (cVar2 != '\x02')))) {
                        fcn.180004e40(arg1);
                    }
                    *(undefined4 *)arg1 = (undefined4)var_38h;
                    *(undefined4 *)(arg1 + 4) = var_38h._4_4_;
                    *(undefined4 *)(arg1 + 8) = uStack_30;
                    *(undefined4 *)(arg1 + 0xc) = uStack_2c;
                    *(undefined4 *)(arg1 + 0x10) = (undefined4)var_28h;
                    *(undefined4 *)(arg1 + 0x14) = var_28h._4_4_;
                    *(undefined4 *)(arg1 + 0x18) = uStack_20;
                    *(undefined4 *)(arg1 + 0x1c) = uStack_1c;
                    *(undefined *)(arg1 + 0x20) = 3;
                }
                goto code_r0x000180016de1;
            }
            cVar2 = *(char *)(arg1 + 0x20);
            if (cVar2 != '\x02') {
                if ((((cVar2 != -1) && (cVar2 != '\0')) && (cVar2 != '\x01')) && (cVar2 != '\x02')) {
                    fcn.180004e40();
                }
                *(undefined *)(arg1 + 0x20) = 0xff;
                *(undefined4 *)arg1 = *(undefined4 *)arg2;
                *(undefined *)(arg1 + 0x20) = 2;
                goto code_r0x000180016de1;
            }
        }
        *(undefined4 *)arg1 = *(undefined4 *)arg2;
    }
code_r0x000180016de1:
    fcn.180459870(uStack_18 ^ (uint64_t)auStack_58);
    return;
}

// ============================================================
// Function: FUN_180016e00
// Address: 0x180016e00
// Size: 126 bytes
// ============================================================
undefined8 * fcn.180016e00(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    
    puVar7 = *(undefined8 **)(arg1 + 0x20);
    puVar1 = *(undefined8 **)(arg1 + 0x28);
    if (puVar7 != puVar1) {
        uVar2 = *(uint64_t *)(arg2 + 0x18);
        iVar3 = *(int64_t *)(arg2 + 0x10);
        do {
            iVar6 = arg2;
            if (0xf < uVar2) {
                iVar6 = *(int64_t *)arg2;
            }
            puVar5 = puVar7;
            if (0xf < (uint64_t)puVar7[3]) {
                puVar5 = (undefined8 *)*puVar7;
            }
            if ((puVar7[2] == iVar3) && ((puVar7[2] == 0 || (iVar4 = func_0x000180497f30(puVar5, iVar6), iVar4 == 0))))
            {
                return puVar7;
            }
            puVar7 = puVar7 + 0x13;
        } while (puVar7 != puVar1);
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180016e80
// Address: 0x180016e80
// Size: 2617 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_6fch
// WARNING: [rz-ghidra] Detected overlap for variable var_618h
// WARNING: [rz-ghidra] Detected overlap for variable var_620h
// WARNING: [rz-ghidra] Detected overlap for variable var_61ch
// WARNING: [rz-ghidra] Detected overlap for variable var_61bh
// WARNING: [rz-ghidra] Detected overlap for variable var_454h
// WARNING: [rz-ghidra] Detected overlap for variable var_452h
// WARNING: [rz-ghidra] Detected overlap for variable var_451h
// WARNING: [rz-ghidra] Detected overlap for variable var_3b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_3c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_3bch
// WARNING: [rz-ghidra] Detected overlap for variable var_324h
// WARNING: [rz-ghidra] Detected overlap for variable var_322h
// WARNING: [rz-ghidra] Detected overlap for variable var_321h
// WARNING: [rz-ghidra] Detected overlap for variable var_696h
// WARNING: [rz-ghidra] Detected overlap for variable var_695h
// WARNING: [rz-ghidra] Detected overlap for variable var_28eh
// WARNING: [rz-ghidra] Detected overlap for variable var_1fch
// WARNING: [rz-ghidra] Detected overlap for variable var_1fah
// WARNING: [rz-ghidra] Detected overlap for variable var_1f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_650h
// WARNING: [rz-ghidra] Detected overlap for variable var_658h
// WARNING: [rz-ghidra] Detected overlap for variable var_654h

void fcn.180016e80(void)
{
    undefined8 *puVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t unaff_GS_OFFSET;
    undefined auStack_738 [32];
    int64_t var_718h;
    int64_t var_710h;
    int64_t var_708h;
    int64_t var_700h;
    int64_t var_6f8h;
    int64_t var_6f0h;
    int64_t var_6e8h;
    int64_t var_6e0h;
    int64_t var_6d8h;
    int64_t var_6d0h;
    undefined8 uStack_6c8;
    int64_t var_6c0h;
    int64_t var_6b8h;
    int64_t var_6b0h;
    int64_t var_698h;
    int64_t var_688h;
    int64_t var_680h;
    int64_t var_678h;
    int64_t var_660h;
    undefined4 var_658h;
    undefined2 var_654h;
    int64_t var_652h;
    int64_t var_648h;
    int64_t var_640h;
    int64_t var_628h;
    undefined4 var_620h;
    undefined var_61ch;
    undefined var_61bh;
    int64_t var_61ah;
    int64_t var_610h;
    int64_t var_608h;
    undefined8 uStack_600;
    int64_t var_5f8h;
    int64_t var_5f0h;
    int64_t var_5e8h;
    int64_t var_5c8h;
    int64_t var_5c0h;
    int64_t var_5a0h;
    int64_t var_598h;
    int64_t var_590h;
    undefined8 uStack_588;
    int64_t var_580h;
    int64_t var_578h;
    int64_t var_570h;
    undefined8 uStack_568;
    int64_t var_560h;
    int64_t var_558h;
    int64_t var_550h;
    int64_t var_530h;
    int64_t var_528h;
    int64_t var_508h;
    int64_t var_500h;
    int64_t var_4f8h;
    undefined8 uStack_4f0;
    int64_t var_4e8h;
    int64_t var_4e0h;
    int64_t var_4d8h;
    undefined8 uStack_4d0;
    int64_t var_4c8h;
    int64_t var_4c0h;
    int64_t var_4b8h;
    int64_t var_498h;
    int64_t var_490h;
    int64_t var_470h;
    int64_t var_468h;
    int64_t var_460h;
    int64_t var_458h;
    int64_t var_450h;
    int64_t var_448h;
    int64_t var_440h;
    undefined8 uStack_438;
    int64_t var_430h;
    int64_t var_428h;
    int64_t var_420h;
    int64_t var_400h;
    int64_t var_3f8h;
    int64_t var_3d8h;
    int64_t var_3d0h;
    int64_t var_3c8h;
    undefined4 var_3c0h;
    undefined2 var_3bch;
    int64_t var_3bah;
    int64_t var_3b0h;
    int64_t var_3a8h;
    undefined8 uStack_3a0;
    int64_t var_398h;
    int64_t var_390h;
    int64_t var_388h;
    int64_t var_368h;
    int64_t var_360h;
    int64_t var_340h;
    int64_t var_338h;
    int64_t var_330h;
    int64_t var_328h;
    int64_t var_320h;
    int64_t var_318h;
    int64_t var_310h;
    int64_t var_300h;
    int64_t var_2f8h;
    int64_t var_2f0h;
    int64_t var_2d0h;
    int64_t var_2c8h;
    int64_t var_2a8h;
    int64_t var_2a0h;
    int64_t var_298h;
    int64_t var_290h;
    int64_t var_288h;
    int64_t var_280h;
    int64_t var_278h;
    int64_t var_268h;
    int64_t var_260h;
    int64_t var_258h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_210h;
    int64_t var_208h;
    int64_t var_200h;
    int64_t var_1f0h;
    int64_t var_1e8h;
    int64_t var_1e0h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_128h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_b0h;
    int64_t var_90h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    var_38h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_738;
    if (*(int32_t *)(*(int64_t *)(*(int64_t *)(unaff_GS_OFFSET + 0x58) + (uint64_t)*(uint32_t *)0x180781328 * 8) + 8) <
        *(int32_t *)0x1807827f0) {
        fcn.180459d18(0x1807827f0);
        if (*(int32_t *)0x1807827f0 == -1) {
            puVar1 = (undefined8 *)fcn.180459890(0x58);
            *puVar1 = 0;
            puVar1[1] = 0;
            puVar1[2] = 0;
            puVar1[10] = 0;
            var_6f8h = 0xc;
            var_6f0h = 0xf;
            var_700h._0_4_ = 0x73756f6e;
            var_708h = 0x616c6c656373694d;
            var_700h._4_4_ = 0;
            var_61ah._0_2_ = 0;
            stack0xfffffffffffff9e8 = 0xd;
            var_610h = 0xf;
            var_628h = 0x5220656c62616e45;
            var_620h = 0x654e6b61;
            var_61ch = 0x74;
            var_61bh = 0;
            _var_608h = ZEXT816(0);
            var_5f8h = 0;
            var_5f0h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_608h = (int64_t)puVar2;
            var_5f8h = 0x16;
            var_5f0h = 0x1f;
            *puVar2 = 0x62616e45;
            puVar2[1] = 0x2073656c;
            puVar2[2] = 0x4e6b6152;
            puVar2[3] = 0x4c207465;
            *(undefined8 *)((int64_t)puVar2 + 0xe) = 0x7972617262694c20;
            *(undefined *)((int64_t)puVar2 + 0x16) = 0;
            var_5e8h._0_1_ = 0;
            var_5c8h._0_1_ = 0;
            var_5c0h._0_1_ = 0;
            var_5a0h._0_1_ = 0;
            var_598h._0_4_ = 0;
            _var_590h = ZEXT816(0);
            var_580h = 0;
            var_578h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_590h = (int64_t)puVar2;
            var_580h = 0x13;
            var_578h = 0x1f;
            *puVar2 = 0x20657250;
            puVar2[1] = 0x6c706552;
            puVar2[2] = 0x74616369;
            puVar2[3] = 0x69466465;
            *(undefined4 *)((int64_t)puVar2 + 0xf) = 0x74737269;
            *(undefined *)((int64_t)puVar2 + 0x13) = 0;
            _var_570h = ZEXT816(0);
            var_560h = 0;
            var_558h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x40);
            var_570h = (int64_t)puVar2;
            var_560h = 0x32;
            var_558h = 0x3f;
            *puVar2 = 0x6964614d;
            puVar2[1] = 0x77206d75;
            puVar2[2] = 0x206c6c69;
            puVar2[3] = 0x74696e69;
            puVar2[4] = 0x696c6169;
            puVar2[5] = 0x6220657a;
            puVar2[6] = 0x726f6665;
            puVar2[7] = 0x65522065;
            puVar2[8] = 0x63696c70;
            puVar2[9] = 0x64657461;
            puVar2[10] = 0x73726946;
            puVar2[0xb] = 0x75722074;
            *(undefined2 *)(puVar2 + 0xc) = 0x736e;
            *(undefined *)((int64_t)puVar2 + 0x32) = 0;
            var_550h._0_1_ = 0;
            var_530h._0_1_ = 0;
            var_528h._0_1_ = 0;
            var_508h._0_1_ = 0;
            var_500h._0_4_ = 0;
            _var_6e8h = ZEXT816(0);
            var_6d8h = 0;
            iVar3 = fcn.180459890(0x130);
            var_6e0h = iVar3;
            var_6e8h = iVar3;
            var_6d8h = iVar3 + 0x130;
            piVar4 = &var_628h;
            do {
                fcn.180018b70(iVar3, piVar4);
                iVar3 = iVar3 + 0x98;
                piVar4 = piVar4 + 0x13;
            } while (piVar4 != &var_4f8h);
            var_6e0h = iVar3;
            _var_6d0h = ZEXT816(0);
            var_6c0h = 0;
            var_6b8h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_6d0h = (int64_t)puVar2;
            var_6c0h = 0x13;
            var_6b8h = 0x1f;
            *puVar2 = 0x736e6f43;
            puVar2[1] = 0x20656c6f;
            puVar2[2] = 0x69646552;
            puVar2[3] = 0x74636572;
            *(undefined4 *)((int64_t)puVar2 + 0xf) = 0x6e6f6974;
            *(undefined *)((int64_t)puVar2 + 0x13) = 0;
            _var_4f8h = ZEXT816(0);
            var_4e8h = 0;
            var_4e0h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x20);
            var_4f8h = (int64_t)puVar2;
            var_4e8h = 0x1a;
            var_4e0h = 0x1f;
            *puVar2 = 0x62616e45;
            puVar2[1] = 0x4320656c;
            puVar2[2] = 0x6f736e6f;
            puVar2[3] = 0x5220656c;
            *(undefined4 *)((int64_t)puVar2 + 10) = 0x656c6f73;
            *(undefined4 *)((int64_t)puVar2 + 0xe) = 0x64655220;
            *(undefined4 *)((int64_t)puVar2 + 0x12) = 0x63657269;
            *(undefined4 *)((int64_t)puVar2 + 0x16) = 0x6e6f6974;
            *(undefined *)((int64_t)puVar2 + 0x1a) = 0;
            _var_4d8h = ZEXT816(0);
            var_4c8h = 0;
            var_4c0h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x50);
            var_4d8h = (int64_t)puVar2;
            var_4c8h = 0x4d;
            var_4c0h = 0x4f;
            *puVar2 = 0x69646552;
            puVar2[1] = 0x74636572;
            puVar2[2] = 0x78652073;
            puVar2[3] = 0x696f6c70;
            puVar2[4] = 0x6f632074;
            puVar2[5] = 0x6c6f736e;
            puVar2[6] = 0x756f2065;
            puVar2[7] = 0x74757074;
            puVar2[8] = 0x746e6920;
            puVar2[9] = 0x6874206f;
            puVar2[10] = 0x6e692065;
            puVar2[0xb] = 0x7070612d;
            puVar2[0xc] = 0x6e6f6320;
            puVar2[0xd] = 0x656c6f73;
            puVar2[0xe] = 0x646e6120;
            puVar2[0xf] = 0x65687420;
            *(undefined4 *)((int64_t)puVar2 + 0x3d) = 0x20656874;
            *(undefined4 *)((int64_t)puVar2 + 0x41) = 0x65747865;
            *(undefined4 *)((int64_t)puVar2 + 0x45) = 0x6c616e72;
            *(undefined4 *)((int64_t)puVar2 + 0x49) = 0x2e495520;
            *(undefined *)((int64_t)puVar2 + 0x4d) = 0;
            var_4b8h._0_1_ = 0;
            var_498h._0_1_ = 0;
            var_490h._0_1_ = 0;
            var_470h._0_1_ = 0;
            var_468h._0_4_ = 0;
            var_450h = 0xf;
            var_448h = 0xf;
            var_460h = 0x7463657269646552;
            var_458h._0_4_ = 0x69725020;
            var_458h._4_2_ = 0x746e;
            var_458h._6_1_ = 0x73;
            var_458h._7_1_ = 0;
            _var_440h = ZEXT816(0);
            var_430h = 0;
            var_428h = 0;
            puVar2 = (undefined4 *)fcn.180459890(0x50);
            var_440h = (int64_t)puVar2;
            var_430h = 0x49;
            var_428h = 0x4f;
            *puVar2 = 0x69646552;
            puVar2[1] = 0x74636572;
            puVar2[2] = 0x6c612073;
            puVar2[3] = 0x7865206c;
            puVar2[4] = 0x696f6c70;
            puVar2[5] = 0x72702074;
            puVar2[6] = 0x73746e69;
            puVar2[7] = 0x746e6920;
            puVar2[8] = 0x6874206f;
            puVar2[9] = 0x6e692065;
            puVar2[10] = 0x7070612d;
            puVar2[0xb] = 0x6e6f6320;
            puVar2[0xc] = 0x656c6f73;
            puVar2[0xd] = 0x646e6120;
            puVar2[0xe] = 0x65687420;
            puVar2[0xf] = 0x74786520;
            *(undefined4 *)((int64_t)puVar2 + 0x39) = 0x20656874;
            *(undefined4 *)((int64_t)puVar2 + 0x3d) = 0x65747865;
            *(undefined4 *)((int64_t)puVar2 + 0x41) = 0x6c616e72;
            *(undefined4 *)((int64_t)puVar2 + 0x45) = 0x2e495520;
            *(undefined *)((int64_t)puVar2 + 0x49) = 0;
            var_420h._0_1_ = 0;
            var_400h._0_1_ = 0;
            var_3f8h._0_1_ = 0;
            var_3d8h._0_1_ = 0;
            var_3d0h._0_4_ = 0;
            stack0xfffffffffffffc48 = 0xe;
            var_3b0h = 0xf;
            var_3c8h = 0x7463657269646552;
            var_3c0h = 0x72615720;
            var_3bch = 0x736e;
            var_3bah._0_2_ = 0;
            _var_3a8h = ZEXT816(0);
            var_398h = 0;
            var_390h = 0;
            var_718h = 0x4f;
            puVar2 = (undefined4 *)fcn.180004930(&var_3a8h, &var_718h);
            var_3a8h = (int64_t)puVar2;
            var_398h = 0x48;
            var_390h = var_718h;
            *puVar2 = 0x69646552;
            puVar2[1] = 0x74636572;
            puVar2[2] = 0x6c612073;
            puVar2[3] = 0x7865206c;
            puVar2[4] = 0x696f6c70;
            puVar2[5] = 0x61772074;
            puVar2[6] = 0x20736e72;
            puVar2[7] = 0x6f746e69;
            puVar2[8] = 0x65687420;
            puVar2[9] = 0x2d6e6920;
            puVar2[10] = 0x20707061;
            puVar2[0xb] = 0x736e6f63;
            puVar2[0xc] = 0x20656c6f;
            puVar2[0xd] = 0x20646e61;
            puVar2[0xe] = 0x20656874;
            puVar2[0xf] = 0x65747865;
            *(undefined8 *)(puVar2 + 0x10) = 0x2e4955206c616e72;
            *(undefined *)(puVar2 + 0x12) = 0;
            var_388h._0_1_ = 0;
            var_368h._0_1_ = 0;
            var_360h._0_1_ = 0;
            var_340h._0_1_ = 0;
            var_338h._0_4_ = 0;
            var_320h = 0xf;
            var_318h = 0xf;
            var_330h = 0x7463657269646552;
            var_328h._0_4_ = 0x72724520;
            var_328h._4_2_ = 0x726f;
            var_328h._6_1_ = 0x73;
            var_328h._7_1_ = 0;
            _var_310h = ZEXT816(0);
            var_300h = 0;
            var_2f8h = 0;
            fcn.180004830(&var_310h, 0x1806201e0, 0x49);
            var_2f0h._0_1_ = 0;
            var_2d0h._0_1_ = 0;
            var_2c8h._0_1_ = 0;
            var_2a8h._0_1_ = 0;
            var_2a0h._0_4_ = 0;
            var_718h = (int64_t)&var_4f8h;
            var_710h = (int64_t)&var_298h;
            fcn.180017e80(&var_6b0h, &var_718h);
            var_688h = 3;
            var_680h = 0xf;
            stack0xfffffffffffff96c = SUB1612(ZEXT816(0), 4);
            var_698h._0_4_ = 0x535046;
            var_288h = 10;
            var_280h = 0xf;
            var_290h._0_2_ = 0x5350;
            var_298h = 0x46206b636f6c6e55;
            var_290h._2_6_ = 0;
            _var_278h = ZEXT816(0);
            var_268h = 0;
            var_260h = 0;
            fcn.180004830(&var_278h, 0x180620240, 0x3b);
            var_258h._0_1_ = 0;
            var_238h._0_1_ = 0;
            var_230h._0_1_ = 0;
            var_210h._0_1_ = 0;
            var_208h._0_4_ = 0;
            var_1f0h = 7;
            var_1e8h = 0xf;
            _var_200h = ZEXT716(0x70614320535046);
            _var_1e0h = ZEXT816(0);
            var_1d0h = 0;
            var_1c8h = 0;
            fcn.180004830(&var_1e0h, 0x180620288, 0x38);
            var_1c0h._0_4_ = 0xf0;
            var_1a0h._0_1_ = 1;
            var_198h._0_4_ = 0xf0;
            var_178h._0_1_ = 1;
            var_170h._0_4_ = 1;
            var_718h = (int64_t)&var_298h;
            var_710h = (int64_t)&var_168h;
            fcn.180017e80(&var_678h, &var_718h);
            stack0xfffffffffffff9b0 = 0xe;
            var_648h = 0xf;
            var_660h = 0x746e492072657355;
            var_658h = 0x61667265;
            var_654h = 0x6563;
            var_652h._0_2_ = 0;
            _var_168h = ZEXT816(0);
            var_158h = 0;
            var_150h = 0;
            fcn.180004830(&var_168h, 0x1806202d8, 0x12);
            fcn.1800047e0(&var_148h, 0x1806202f0);
            var_128h._0_1_ = 0;
            var_108h._0_1_ = 0;
            var_100h._0_1_ = 0;
            var_e0h._0_1_ = 0;
            var_d8h._0_4_ = 0;
            fcn.1800047e0(&var_d0h, 0x180620338);
            fcn.1800047e0(&var_b0h, 0x180620350);
            var_90h._0_1_ = 0;
            var_70h._0_1_ = 0;
            var_68h._0_1_ = 0;
            var_48h._0_1_ = 0;
            var_40h._0_4_ = 0;
            var_718h = (int64_t)&var_168h;
            var_710h = (int64_t)&var_38h;
            fcn.180017e80(&var_640h, &var_718h);
            var_718h = (int64_t)&var_708h;
            var_710h = (int64_t)&var_628h;
            fcn.180017d90(puVar1, &var_718h);
            fcn.180459d94(&var_708h, 0x38, 4, 0x180017960);
            fcn.180459d94(&var_168h, 0x98, 2, 0x1800178f0);
            fcn.180459d94(&var_298h, 0x98, 2, 0x1800178f0);
            fcn.180459d94(&var_4f8h, 0x98, 4, 0x1800178f0);
            fcn.180459d94(&var_628h, 0x98, 2, 0x1800178f0);
            *(undefined8 **)0x1807827e8 = puVar1;
            fcn.180459c24(0x1804a2100);
            fcn.180459cac(0x1807827f0);
        }
    }
    fcn.180459870(var_38h ^ (uint64_t)auStack_738);
    return;
}

// ============================================================
// Function: FUN_1800178f0
// Address: 0x1800178f0
// Size: 107 bytes
// ============================================================
void fcn.1800178f0(int64_t arg1)
{
    char cVar1;
    int64_t iVar2;
    code *pcVar3;
    int64_t iVar4;
    undefined *puVar5;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    cVar1 = *(char *)(arg1 + 0x88);
    if ((((cVar1 != -1) && (cVar1 != '\0')) && (cVar1 != '\x01')) && (cVar1 != '\x02')) {
        fcn.180004e40();
    }
    cVar1 = *(char *)(arg1 + 0x60);
    if (((cVar1 != -1) && (cVar1 != '\0')) && ((cVar1 != '\x01' && (cVar1 != '\x02')))) {
        fcn.180004e40(arg1 + 0x40);
    }
    fcn.180004e40(arg1 + 0x20);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar2 = *(int64_t *)arg1;
        iVar4 = iVar2;
        puVar5 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar4 = *(int64_t *)(iVar2 + -8), puVar5 = auStack_28, 0x1f < (iVar2 - iVar4) - 8U)) {
            pcVar3 = (code *)swi(0x29);
            iVar4 = (*pcVar3)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x180004e88;
        fcn.180459c3c(iVar4);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_180017960
// Address: 0x180017960
// Size: 31 bytes
// ============================================================
void fcn.180017960(int64_t arg1)
{
    int64_t iVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined *puVar4;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    func_0x000180018470(arg1 + 0x20);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        iVar1 = *(int64_t *)arg1;
        iVar3 = iVar1;
        puVar4 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x18) + 1) &&
           (iVar3 = *(int64_t *)(iVar1 + -8), puVar4 = auStack_28, 0x1f < (iVar1 - iVar3) - 8U)) {
            pcVar2 = (code *)swi(0x29);
            iVar3 = (*pcVar2)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180004e88;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    return;
}

// ============================================================
// Function: FUN_180017980
// Address: 0x180017980
// Size: 122 bytes
// ============================================================
undefined8 * fcn.180017980(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    uint64_t uVar2;
    int64_t iVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    
    puVar7 = *(undefined8 **)arg1;
    puVar1 = *(undefined8 **)(arg1 + 8);
    if (puVar7 != puVar1) {
        uVar2 = *(uint64_t *)(arg2 + 0x18);
        iVar3 = *(int64_t *)(arg2 + 0x10);
        do {
            iVar6 = arg2;
            if (0xf < uVar2) {
                iVar6 = *(int64_t *)arg2;
            }
            puVar5 = puVar7;
            if (0xf < (uint64_t)puVar7[3]) {
                puVar5 = (undefined8 *)*puVar7;
            }
            if ((puVar7[2] == iVar3) && ((puVar7[2] == 0 || (iVar4 = func_0x000180497f30(puVar5, iVar6), iVar4 == 0))))
            {
                return puVar7;
            }
            puVar7 = puVar7 + 7;
        } while (puVar7 != puVar1);
    }
    return (undefined8 *)0x0;
}

// ============================================================
// Function: FUN_180017a00
// Address: 0x180017a00
// Size: 823 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.180017a00(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    char cVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    uint8_t uVar6;
    unkbyte7 Var8;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_48h;
    
    *(int64_t *)arg3 = *(int64_t *)arg3 + 1;
    *(undefined (*) [16])arg1 = ZEXT816(0);
    *(undefined8 *)(arg1 + 0x10) = 0;
    *(undefined8 *)(arg1 + 0x18) = 0xf;
    *(undefined *)arg1 = 0;
    uVar3 = *(uint64_t *)arg3;
    uVar5 = *(uint64_t *)(arg2 + 0x10);
    if (uVar3 < uVar5) {
        do {
            uVar7 = *(uint64_t *)(arg2 + 0x18);
            iVar4 = arg2;
            if (0xf < uVar7) {
                iVar4 = *(int64_t *)arg2;
            }
            if (*(char *)(uVar3 + iVar4) == '\"') break;
            iVar4 = arg2;
            if (0xf < uVar7) {
                iVar4 = *(int64_t *)arg2;
            }
            if ((*(char *)(uVar3 + iVar4) == '\\') && (uVar1 = uVar3 + 1, uVar1 < uVar5)) {
                *(uint64_t *)arg3 = uVar1;
                iVar4 = arg2;
                if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                    iVar4 = *(int64_t *)arg2;
                }
                cVar2 = *(char *)(uVar1 + iVar4);
                Var8 = (unkbyte7)(uVar5 >> 8);
                if (cVar2 == '\"') {
                    uVar3 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(undefined2 *)(uVar3 + arg1) = 0x22;
                        } else {
                            *(undefined2 *)(uVar3 + *(int64_t *)arg1) = 0x22;
                        }
                        goto code_r0x000180017ce4;
                    }
                    uVar7 = CONCAT71(Var8, 0x22);
                } else if (cVar2 == '\\') {
                    uVar3 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(undefined2 *)(uVar3 + arg1) = 0x5c;
                        } else {
                            *(undefined2 *)(uVar3 + *(int64_t *)arg1) = 0x5c;
                        }
                        goto code_r0x000180017ce4;
                    }
                    uVar7 = CONCAT71(Var8, 0x5c);
                } else if (cVar2 == 'n') {
                    uVar3 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(undefined2 *)(uVar3 + arg1) = 10;
                        } else {
                            *(undefined2 *)(uVar3 + *(int64_t *)arg1) = 10;
                        }
                        goto code_r0x000180017ce4;
                    }
                    uVar7 = CONCAT71(Var8, 10);
                } else if (cVar2 == 'r') {
                    uVar3 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(undefined2 *)(uVar3 + arg1) = 0xd;
                        } else {
                            *(undefined2 *)(uVar3 + *(int64_t *)arg1) = 0xd;
                        }
                        goto code_r0x000180017ce4;
                    }
                    uVar7 = CONCAT71(Var8, 0xd);
                } else if (cVar2 == 't') {
                    uVar3 = *(uint64_t *)(arg1 + 0x10);
                    if (uVar3 < *(uint64_t *)(arg1 + 0x18)) {
                        *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                        if (*(uint64_t *)(arg1 + 0x18) < 0x10) {
                            *(undefined2 *)(uVar3 + arg1) = 9;
                        } else {
                            *(undefined2 *)(uVar3 + *(int64_t *)arg1) = 9;
                        }
                        goto code_r0x000180017ce4;
                    }
                    uVar7 = CONCAT71(Var8, 9);
                } else {
                    iVar4 = arg2;
                    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
                        iVar4 = *(int64_t *)arg2;
                    }
                    uVar6 = *(uint8_t *)(uVar1 + iVar4);
                    uVar7 = (uint64_t)uVar6;
                    uVar3 = *(uint64_t *)(arg1 + 0x10);
                    uVar5 = *(uint64_t *)(arg1 + 0x18);
                    if (uVar3 < uVar5) goto code_r0x000180017ca3;
                }
code_r0x000180017cd2:
                func_0x00018000f010(arg1, 1, arg2 & 0xff, uVar7, 1);
            } else {
                iVar4 = arg2;
                if (0xf < uVar7) {
                    iVar4 = *(int64_t *)arg2;
                }
                uVar6 = *(uint8_t *)(uVar3 + iVar4);
                uVar7 = (uint64_t)uVar6;
                uVar3 = *(uint64_t *)(arg1 + 0x10);
                uVar5 = *(uint64_t *)(arg1 + 0x18);
                if (uVar5 <= uVar3) goto code_r0x000180017cd2;
code_r0x000180017ca3:
                *(uint64_t *)(arg1 + 0x10) = uVar3 + 1;
                if (uVar5 < 0x10) {
                    *(uint8_t *)(uVar3 + arg1) = uVar6;
                    *(undefined *)(uVar3 + 1 + arg1) = 0;
                } else {
                    iVar4 = *(int64_t *)arg1;
                    *(uint8_t *)(uVar3 + iVar4) = uVar6;
                    *(undefined *)(uVar3 + 1 + iVar4) = 0;
                }
            }
code_r0x000180017ce4:
            *(int64_t *)arg3 = *(int64_t *)arg3 + 1;
            uVar3 = *(uint64_t *)arg3;
            uVar5 = *(uint64_t *)(arg2 + 0x10);
        } while (uVar3 < uVar5);
    }
    *(uint64_t *)arg3 = uVar3 + 1;
    return arg1;
}

// ============================================================
// Function: FUN_180017d40
// Address: 0x180017d40
// Size: 71 bytes
// ============================================================
bool fcn.180017d40(int64_t arg1, int64_t arg2)
{
    int64_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    
    piVar1 = (int64_t *)(arg2 + 0x10);
    if (0xf < *(uint64_t *)(arg2 + 0x18)) {
        arg2 = *(int64_t *)arg2;
    }
    piVar2 = (int64_t *)(arg1 + 0x10);
    if (0xf < *(uint64_t *)(arg1 + 0x18)) {
        arg1 = *(int64_t *)arg1;
    }
    if (*piVar2 != *piVar1) {
        return false;
    }
    if (*piVar2 == 0) {
        return true;
    }
    iVar3 = func_0x000180497f30(arg1, arg2);
    return iVar3 == 0;
}

// ============================================================
// Function: FUN_180017d90
// Address: 0x180017d90
// Size: 54 bytes
// ============================================================
int64_t fcn.180017d90(int64_t arg1, int64_t arg2)
{
    fcn.180018210(arg1, *(undefined8 *)arg2, (*(int64_t *)(arg2 + 8) - *(int64_t *)arg2 >> 3) * 0x6db6db6db6db6db7);
    return arg1;
}

// ============================================================
// Function: FUN_180017dd0
// Address: 0x180017dd0
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180017dd0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x000180018470(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180017e68;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180017de9
// Address: 0x180017de9
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180017dd0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x000180018470(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180017e68;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180017e3f
// Address: 0x180017e3f
// Size: 65 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180017dd0(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined *puVar4;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != 0) {
        iVar2 = *(int64_t *)(arg1 + 8);
        for (; iVar3 != iVar2; iVar3 = iVar3 + 0x38) {
            func_0x000180018470(iVar3 + 0x20);
            fcn.180004e40(iVar3);
        }
        iVar3 = *(int64_t *)arg1;
        iVar2 = iVar3;
        puVar4 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 3) * 8)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar4 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar4 = auStack_20;
        }
        *(undefined8 *)(puVar4 + -8) = 0x180017e68;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180017e80
// Address: 0x180017e80
// Size: 173 bytes
// ============================================================
int64_t fcn.180017e80(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    iVar2 = *(int64_t *)(arg2 + 8);
    arg2 = *(int64_t *)arg2;
    uVar3 = (iVar2 - arg2 >> 3) * -0x79435e50d79435e5;
    if (uVar3 != 0) {
        if (0x1af286bca1af286 < uVar3) {
            func_0x000180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        func_0x0001800189f0();
        iVar4 = *(int64_t *)arg1;
        for (; arg2 != iVar2; arg2 = arg2 + 0x98) {
            fcn.180018b70(iVar4, arg2);
            iVar4 = iVar4 + 0x98;
        }
        *(int64_t *)(arg1 + 8) = iVar4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180017f30
// Address: 0x180017f30
// Size: 723 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

int64_t fcn.180017f30(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint8_t uVar1;
    uint64_t uVar2;
    int64_t *piVar3;
    int64_t iVar4;
    uint8_t *puVar5;
    code *pcVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined8 uVar9;
    int64_t iVar10;
    undefined8 uVar11;
    uint32_t uVar12;
    uint32_t uVar13;
    int64_t iVar14;
    bool bVar15;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_28h;
    
    iVar14 = 0;
    uVar2 = *(uint64_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x28 + arg1);
    iVar10 = iVar14;
    if ((0 < (int64_t)uVar2) && ((uint64_t)arg3 < uVar2)) {
        iVar10 = uVar2 - arg3;
    }
    piVar3 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 8))();
    }
    iVar8 = *(int64_t *)arg1;
    if (*(int32_t *)((int64_t)*(int32_t *)(iVar8 + 4) + 0x10 + arg1) == 0) {
        iVar4 = *(int64_t *)((int64_t)*(int32_t *)(iVar8 + 4) + 0x50 + arg1);
        if ((iVar4 == 0) || (iVar4 == arg1)) {
            bVar15 = true;
        } else {
            func_0x00018000fad0(iVar4);
            iVar8 = *(int64_t *)arg1;
            bVar15 = *(int32_t *)((int64_t)*(int32_t *)(iVar8 + 4) + 0x10 + arg1) == 0;
        }
    } else {
        bVar15 = false;
    }
    if (bVar15) {
        if ((*(uint32_t *)((int64_t)*(int32_t *)(iVar8 + 4) + 0x18 + arg1) & 0x1c0) != 0x40) {
            for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                piVar3 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
                uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x58 + arg1);
                if (*(int64_t *)piVar3[8] == 0) {
code_r0x000180018059:
                    uVar13 = (**(code **)(*piVar3 + 0x18))(piVar3, uVar1);
                } else {
                    iVar7 = *(int32_t *)piVar3[0xb];
                    if (iVar7 < 1) goto code_r0x000180018059;
                    *(int32_t *)piVar3[0xb] = iVar7 + -1;
                    puVar5 = *(uint8_t **)piVar3[8];
                    *(uint8_t **)piVar3[8] = puVar5 + 1;
                    *puVar5 = uVar1;
                    uVar13 = (uint32_t)uVar1;
                }
                if (uVar13 == 0xffffffff) {
                    iVar14 = 4;
                    goto code_r0x000180018078;
                }
            }
        }
        piVar3 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
        iVar8 = (**(code **)(*piVar3 + 0x48))(piVar3, arg2, arg3);
        if (iVar8 == arg3) {
code_r0x000180018078:
            do {
                uVar13 = (uint32_t)iVar14;
                if (iVar10 == 0) goto code_r0x0001800180f0;
                piVar3 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
                uVar1 = *(uint8_t *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x58 + arg1);
                if (*(int64_t *)piVar3[8] == 0) {
code_r0x0001800180fe:
                    uVar13 = (**(code **)(*piVar3 + 0x18))(piVar3, uVar1);
                } else {
                    iVar7 = *(int32_t *)piVar3[0xb];
                    if (iVar7 < 1) goto code_r0x0001800180fe;
                    *(int32_t *)piVar3[0xb] = iVar7 + -1;
                    puVar5 = *(uint8_t **)piVar3[8];
                    *(uint8_t **)piVar3[8] = puVar5 + 1;
                    *puVar5 = uVar1;
                    uVar13 = (uint32_t)uVar1;
                }
                if (uVar13 == 0xffffffff) {
                    uVar13 = 4;
                    goto code_r0x0001800180f0;
                }
                iVar10 = iVar10 + -1;
            } while( true );
        }
        uVar13 = 4;
code_r0x0001800180f0:
        *(undefined8 *)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x28 + arg1) = 0;
    } else {
        uVar13 = 4;
    }
    iVar10 = (int64_t)*(int32_t *)(*(int64_t *)arg1 + 4);
    uVar12 = 4;
    if (*(int64_t *)(iVar10 + 0x48 + arg1) != 0) {
        uVar12 = 0;
    }
    uVar13 = uVar12 | *(uint32_t *)(iVar10 + 0x10 + arg1) & 0x17 | uVar13;
    *(uint32_t *)(iVar10 + 0x10 + arg1) = uVar13;
    uVar13 = uVar13 & *(uint32_t *)(iVar10 + 0x14 + arg1);
    if (uVar13 != 0) {
        if ((uVar13 & 4) == 0) {
            uVar11 = 0x1805aae00;
            if ((uVar13 & 2) == 0) {
                uVar11 = 0x1805aae18;
            }
        } else {
            uVar11 = 0x1805aade8;
        }
        uVar9 = func_0x000180005e50(&var_68h, 1);
        func_0x0001800069f0(&var_58h, uVar11, uVar9);
        fcn.18045bae0(arg1);
        pcVar6 = (code *)swi(3);
        iVar10 = (*pcVar6)();
        return iVar10;
    }
    iVar7 = func_0x0001804557c0();
    if (iVar7 == 0) {
        func_0x00018000fc20(arg1);
    }
    piVar3 = *(int64_t **)((int64_t)*(int32_t *)(*(int64_t *)arg1 + 4) + 0x48 + arg1);
    if (piVar3 != (int64_t *)0x0) {
        (**(code **)(*piVar3 + 0x10))();
    }
    return arg1;
}

// ============================================================
// Function: FUN_180018210
// Address: 0x180018210
// Size: 64 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180018210(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    uVar7 = *(uint64_t *)arg1;
    uVar5 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar7) >> 3) * 0x6db6db6db6db6db7;
    if ((uint64_t)arg3 <= uVar5) {
        uVar5 = *(uint64_t *)(arg1 + 8);
        iVar6 = (int64_t)(uVar5 - uVar7) >> 3;
        if ((uint64_t)(iVar6 * 0x6db6db6db6db6db7) < (uint64_t)arg3) {
            if (uVar7 != uVar5) {
                do {
                    func_0x000180018520(uVar7, arg2);
                    uVar5 = *(uint64_t *)(arg1 + 8);
                    uVar7 = uVar7 + 0x38;
                    arg2 = arg2 + 0x38;
                } while (uVar7 != uVar5);
            }
            uVar4 = func_0x0001800187f0(arg2, arg3 + iVar6 * -0x6db6db6db6db6db7, uVar5, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        iVar6 = arg3 * 0x38 + uVar7;
        if (arg3 != 0) {
            do {
                func_0x000180018520(uVar7, arg2);
                uVar7 = uVar7 + 0x38;
                arg2 = arg2 + 0x38;
                arg3 = arg3 + -1;
            } while (arg3 != 0);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        for (iVar8 = iVar6; iVar8 != iVar3; iVar8 = iVar8 + 0x38) {
            func_0x000180018470(iVar8 + 0x20);
            fcn.180004e40(iVar8);
        }
        *(int64_t *)(arg1 + 8) = iVar6;
        return;
    }
    if (0x492492492492492 < (uint64_t)arg3) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = 0x492492492492492 - (uVar5 >> 1);
    if (uVar5 < uVar2 || uVar5 - uVar2 == 0) {
        uVar5 = uVar5 + (uVar5 >> 1);
        if (uVar5 < (uint64_t)arg3) {
            uVar5 = arg3;
        }
    } else {
        uVar5 = 0x492492492492492;
    }
    if (uVar7 == 0) {
code_r0x000180018321:
        if (0x492492492492492 < uVar5) {
code_r0x000180018458:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar7 = uVar5 * 0x38;
        if (uVar7 == 0) {
            uVar5 = 0;
            puVar10 = auStack_38;
            goto code_r0x000180018377;
        }
        if (uVar7 < 0x1000) {
            uVar5 = fcn.180459890(uVar7);
            goto code_r0x000180018377;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x000180018458;
        iVar3 = fcn.180459890();
        iVar6 = iVar3;
        if (iVar3 == 0) goto code_r0x00018001835a;
    } else {
        uVar2 = *(uint64_t *)(arg1 + 8);
        for (; uVar7 != uVar2; uVar7 = uVar7 + 0x38) {
            func_0x000180018470(uVar7 + 0x20);
            fcn.180004e40(uVar7);
        }
        iVar6 = *(int64_t *)arg1;
        uVar2 = (*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8;
        if (uVar2 < 0x1000) {
code_r0x000180018302:
            fcn.180459c3c(iVar6, uVar2);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            goto code_r0x000180018321;
        }
        if ((iVar6 - *(int64_t *)(iVar6 + -8)) - 8U < 0x20) {
            uVar2 = uVar2 + 0x27;
            iVar6 = *(int64_t *)(iVar6 + -8);
            goto code_r0x000180018302;
        }
code_r0x00018001835a:
        iVar6 = 5;
        pcVar1 = (code *)swi(0x29);
        iVar3 = (*pcVar1)();
        puVar9 = auStack_30;
    }
    uVar5 = iVar3 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar6;
    puVar10 = puVar9;
code_r0x000180018377:
    *(uint64_t *)arg1 = uVar5;
    *(uint64_t *)(arg1 + 8) = uVar5;
    *(uint64_t *)(arg1 + 0x10) = uVar7 + uVar5;
    *(undefined8 *)(puVar10 + -8) = 0x180018397;
    uVar4 = func_0x0001800187f0(arg2, arg3, uVar5, arg1);
    *(undefined8 *)(arg1 + 8) = uVar4;
    return;
}

// ============================================================
// Function: FUN_180018250
// Address: 0x180018250
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180018210(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    uVar7 = *(uint64_t *)arg1;
    uVar5 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar7) >> 3) * 0x6db6db6db6db6db7;
    if ((uint64_t)arg3 <= uVar5) {
        uVar5 = *(uint64_t *)(arg1 + 8);
        iVar6 = (int64_t)(uVar5 - uVar7) >> 3;
        if ((uint64_t)(iVar6 * 0x6db6db6db6db6db7) < (uint64_t)arg3) {
            if (uVar7 != uVar5) {
                do {
                    func_0x000180018520(uVar7, arg2);
                    uVar5 = *(uint64_t *)(arg1 + 8);
                    uVar7 = uVar7 + 0x38;
                    arg2 = arg2 + 0x38;
                } while (uVar7 != uVar5);
            }
            uVar4 = func_0x0001800187f0(arg2, arg3 + iVar6 * -0x6db6db6db6db6db7, uVar5, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        iVar6 = arg3 * 0x38 + uVar7;
        if (arg3 != 0) {
            do {
                func_0x000180018520(uVar7, arg2);
                uVar7 = uVar7 + 0x38;
                arg2 = arg2 + 0x38;
                arg3 = arg3 + -1;
            } while (arg3 != 0);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        for (iVar8 = iVar6; iVar8 != iVar3; iVar8 = iVar8 + 0x38) {
            func_0x000180018470(iVar8 + 0x20);
            fcn.180004e40(iVar8);
        }
        *(int64_t *)(arg1 + 8) = iVar6;
        return;
    }
    if (0x492492492492492 < (uint64_t)arg3) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = 0x492492492492492 - (uVar5 >> 1);
    if (uVar5 < uVar2 || uVar5 - uVar2 == 0) {
        uVar5 = uVar5 + (uVar5 >> 1);
        if (uVar5 < (uint64_t)arg3) {
            uVar5 = arg3;
        }
    } else {
        uVar5 = 0x492492492492492;
    }
    if (uVar7 == 0) {
code_r0x000180018321:
        if (0x492492492492492 < uVar5) {
code_r0x000180018458:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar7 = uVar5 * 0x38;
        if (uVar7 == 0) {
            uVar5 = 0;
            puVar10 = auStack_38;
            goto code_r0x000180018377;
        }
        if (uVar7 < 0x1000) {
            uVar5 = fcn.180459890(uVar7);
            goto code_r0x000180018377;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x000180018458;
        iVar3 = fcn.180459890();
        iVar6 = iVar3;
        if (iVar3 == 0) goto code_r0x00018001835a;
    } else {
        uVar2 = *(uint64_t *)(arg1 + 8);
        for (; uVar7 != uVar2; uVar7 = uVar7 + 0x38) {
            func_0x000180018470(uVar7 + 0x20);
            fcn.180004e40(uVar7);
        }
        iVar6 = *(int64_t *)arg1;
        uVar2 = (*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8;
        if (uVar2 < 0x1000) {
code_r0x000180018302:
            fcn.180459c3c(iVar6, uVar2);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            goto code_r0x000180018321;
        }
        if ((iVar6 - *(int64_t *)(iVar6 + -8)) - 8U < 0x20) {
            uVar2 = uVar2 + 0x27;
            iVar6 = *(int64_t *)(iVar6 + -8);
            goto code_r0x000180018302;
        }
code_r0x00018001835a:
        iVar6 = 5;
        pcVar1 = (code *)swi(0x29);
        iVar3 = (*pcVar1)();
        puVar9 = auStack_30;
    }
    uVar5 = iVar3 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar6;
    puVar10 = puVar9;
code_r0x000180018377:
    *(uint64_t *)arg1 = uVar5;
    *(uint64_t *)(arg1 + 8) = uVar5;
    *(uint64_t *)(arg1 + 0x10) = uVar7 + uVar5;
    *(undefined8 *)(puVar10 + -8) = 0x180018397;
    uVar4 = func_0x0001800187f0(arg2, arg3, uVar5, arg1);
    *(undefined8 *)(arg1 + 8) = uVar4;
    return;
}

// ============================================================
// Function: FUN_180018292
// Address: 0x180018292
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180018210(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    uVar7 = *(uint64_t *)arg1;
    uVar5 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar7) >> 3) * 0x6db6db6db6db6db7;
    if ((uint64_t)arg3 <= uVar5) {
        uVar5 = *(uint64_t *)(arg1 + 8);
        iVar6 = (int64_t)(uVar5 - uVar7) >> 3;
        if ((uint64_t)(iVar6 * 0x6db6db6db6db6db7) < (uint64_t)arg3) {
            if (uVar7 != uVar5) {
                do {
                    func_0x000180018520(uVar7, arg2);
                    uVar5 = *(uint64_t *)(arg1 + 8);
                    uVar7 = uVar7 + 0x38;
                    arg2 = arg2 + 0x38;
                } while (uVar7 != uVar5);
            }
            uVar4 = func_0x0001800187f0(arg2, arg3 + iVar6 * -0x6db6db6db6db6db7, uVar5, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        iVar6 = arg3 * 0x38 + uVar7;
        if (arg3 != 0) {
            do {
                func_0x000180018520(uVar7, arg2);
                uVar7 = uVar7 + 0x38;
                arg2 = arg2 + 0x38;
                arg3 = arg3 + -1;
            } while (arg3 != 0);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        for (iVar8 = iVar6; iVar8 != iVar3; iVar8 = iVar8 + 0x38) {
            func_0x000180018470(iVar8 + 0x20);
            fcn.180004e40(iVar8);
        }
        *(int64_t *)(arg1 + 8) = iVar6;
        return;
    }
    if (0x492492492492492 < (uint64_t)arg3) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = 0x492492492492492 - (uVar5 >> 1);
    if (uVar5 < uVar2 || uVar5 - uVar2 == 0) {
        uVar5 = uVar5 + (uVar5 >> 1);
        if (uVar5 < (uint64_t)arg3) {
            uVar5 = arg3;
        }
    } else {
        uVar5 = 0x492492492492492;
    }
    if (uVar7 == 0) {
code_r0x000180018321:
        if (0x492492492492492 < uVar5) {
code_r0x000180018458:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar7 = uVar5 * 0x38;
        if (uVar7 == 0) {
            uVar5 = 0;
            puVar10 = auStack_38;
            goto code_r0x000180018377;
        }
        if (uVar7 < 0x1000) {
            uVar5 = fcn.180459890(uVar7);
            goto code_r0x000180018377;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x000180018458;
        iVar3 = fcn.180459890();
        iVar6 = iVar3;
        if (iVar3 == 0) goto code_r0x00018001835a;
    } else {
        uVar2 = *(uint64_t *)(arg1 + 8);
        for (; uVar7 != uVar2; uVar7 = uVar7 + 0x38) {
            func_0x000180018470(uVar7 + 0x20);
            fcn.180004e40(uVar7);
        }
        iVar6 = *(int64_t *)arg1;
        uVar2 = (*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8;
        if (uVar2 < 0x1000) {
code_r0x000180018302:
            fcn.180459c3c(iVar6, uVar2);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            goto code_r0x000180018321;
        }
        if ((iVar6 - *(int64_t *)(iVar6 + -8)) - 8U < 0x20) {
            uVar2 = uVar2 + 0x27;
            iVar6 = *(int64_t *)(iVar6 + -8);
            goto code_r0x000180018302;
        }
code_r0x00018001835a:
        iVar6 = 5;
        pcVar1 = (code *)swi(0x29);
        iVar3 = (*pcVar1)();
        puVar9 = auStack_30;
    }
    uVar5 = iVar3 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar6;
    puVar10 = puVar9;
code_r0x000180018377:
    *(uint64_t *)arg1 = uVar5;
    *(uint64_t *)(arg1 + 8) = uVar5;
    *(uint64_t *)(arg1 + 0x10) = uVar7 + uVar5;
    *(undefined8 *)(puVar10 + -8) = 0x180018397;
    uVar4 = func_0x0001800187f0(arg2, arg3, uVar5, arg1);
    *(undefined8 *)(arg1 + 8) = uVar4;
    return;
}

// ============================================================
// Function: FUN_1800182e8
// Address: 0x1800182e8
// Size: 184 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180018210(int64_t arg1, int64_t arg2, int64_t arg3)
{
    code *pcVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    uint64_t uVar7;
    int64_t iVar8;
    undefined *puVar9;
    undefined *puVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar9 = auStack_38;
    puVar10 = auStack_38;
    uVar7 = *(uint64_t *)arg1;
    uVar5 = ((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar7) >> 3) * 0x6db6db6db6db6db7;
    if ((uint64_t)arg3 <= uVar5) {
        uVar5 = *(uint64_t *)(arg1 + 8);
        iVar6 = (int64_t)(uVar5 - uVar7) >> 3;
        if ((uint64_t)(iVar6 * 0x6db6db6db6db6db7) < (uint64_t)arg3) {
            if (uVar7 != uVar5) {
                do {
                    func_0x000180018520(uVar7, arg2);
                    uVar5 = *(uint64_t *)(arg1 + 8);
                    uVar7 = uVar7 + 0x38;
                    arg2 = arg2 + 0x38;
                } while (uVar7 != uVar5);
            }
            uVar4 = func_0x0001800187f0(arg2, arg3 + iVar6 * -0x6db6db6db6db6db7, uVar5, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        iVar6 = arg3 * 0x38 + uVar7;
        if (arg3 != 0) {
            do {
                func_0x000180018520(uVar7, arg2);
                uVar7 = uVar7 + 0x38;
                arg2 = arg2 + 0x38;
                arg3 = arg3 + -1;
            } while (arg3 != 0);
        }
        iVar3 = *(int64_t *)(arg1 + 8);
        for (iVar8 = iVar6; iVar8 != iVar3; iVar8 = iVar8 + 0x38) {
            func_0x000180018470(iVar8 + 0x20);
            fcn.180004e40(iVar8);
        }
        *(int64_t *)(arg1 + 8) = iVar6;
        return;
    }
    if (0x492492492492492 < (uint64_t)arg3) {
        func_0x000180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar2 = 0x492492492492492 - (uVar5 >> 1);
    if (uVar5 < uVar2 || uVar5 - uVar2 == 0) {
        uVar5 = uVar5 + (uVar5 >> 1);
        if (uVar5 < (uint64_t)arg3) {
            uVar5 = arg3;
        }
    } else {
        uVar5 = 0x492492492492492;
    }
    if (uVar7 == 0) {
code_r0x000180018321:
        if (0x492492492492492 < uVar5) {
code_r0x000180018458:
            fcn.180004720();
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        uVar7 = uVar5 * 0x38;
        if (uVar7 == 0) {
            uVar5 = 0;
            puVar10 = auStack_38;
            goto code_r0x000180018377;
        }
        if (uVar7 < 0x1000) {
            uVar5 = fcn.180459890(uVar7);
            goto code_r0x000180018377;
        }
        if (uVar7 + 0x27 <= uVar7) goto code_r0x000180018458;
        iVar3 = fcn.180459890();
        iVar6 = iVar3;
        if (iVar3 == 0) goto code_r0x00018001835a;
    } else {
        uVar2 = *(uint64_t *)(arg1 + 8);
        for (; uVar7 != uVar2; uVar7 = uVar7 + 0x38) {
            func_0x000180018470(uVar7 + 0x20);
            fcn.180004e40(uVar7);
        }
        iVar6 = *(int64_t *)arg1;
        uVar2 = (*(int64_t *)(arg1 + 0x10) - iVar6 >> 3) * 8;
        if (uVar2 < 0x1000) {
code_r0x000180018302:
            fcn.180459c3c(iVar6, uVar2);
            *(undefined8 *)arg1 = 0;
            *(undefined8 *)(arg1 + 8) = 0;
            *(undefined8 *)(arg1 + 0x10) = 0;
            goto code_r0x000180018321;
        }
        if ((iVar6 - *(int64_t *)(iVar6 + -8)) - 8U < 0x20) {
            uVar2 = uVar2 + 0x27;
            iVar6 = *(int64_t *)(iVar6 + -8);
            goto code_r0x000180018302;
        }
code_r0x00018001835a:
        iVar6 = 5;
        pcVar1 = (code *)swi(0x29);
        iVar3 = (*pcVar1)();
        puVar9 = auStack_30;
    }
    uVar5 = iVar3 + 0x27U & 0xffffffffffffffe0;
    *(int64_t *)(uVar5 - 8) = iVar6;
    puVar10 = puVar9;
code_r0x000180018377:
    *(uint64_t *)arg1 = uVar5;
    *(uint64_t *)(arg1 + 8) = uVar5;
    *(uint64_t *)(arg1 + 0x10) = uVar7 + uVar5;
    *(undefined8 *)(puVar10 + -8) = 0x180018397;
    uVar4 = func_0x0001800187f0(arg2, arg3, uVar5, arg1);
    *(undefined8 *)(arg1 + 8) = uVar4;
    return;
}

