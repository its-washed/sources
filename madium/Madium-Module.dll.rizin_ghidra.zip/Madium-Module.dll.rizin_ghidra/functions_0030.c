// Chunk 30 - 50 functions

// ============================================================
// Function: FUN_180061e3f
// Address: 0x180061e3f
// Size: 11 bytes
// ============================================================
void fcn.180061e3f(int64_t arg_48h)
{
    return;
}

// ============================================================
// Function: FUN_180061e4a
// Address: 0x180061e4a
// Size: 22 bytes
// ============================================================
void fcn.180061e4a(void)
{
    code *pcVar1;
    
    fcn.1804542e8(2);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180061e60
// Address: 0x180061e60
// Size: 649 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.180061e60(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    undefined4 uVar2;
    int64_t iVar3;
    undefined8 uVar4;
    undefined8 *puVar5;
    undefined8 uVar6;
    int64_t var_20h;
    undefined auStack_1b8 [32];
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_50h;
    int64_t var_48h;
    
    var_48h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    iVar3 = func_0x00018045b9a8(0x180624e10, 0x5c);
    uVar2 = (*(code *)0x699ddc)();
    uVar4 = func_0x0001801723e0();
    var_188h = 0x180624de8;
    var_190h._0_4_ = 0x55;
    var_198h = iVar3 + 1;
    func_0x000180172b00(uVar4, 2, 0x180624d88, uVar2);
    LOCK();
    *(undefined4 *)arg1 = 4;
    UNLOCK();
    puVar5 = *(undefined8 **)(arg2 + 0x38);
    if (puVar5 != (undefined8 *)0x0) {
        uVar4 = *(undefined8 *)(arg1 + 8);
        var_178h = (int64_t)&var_160h;
        var_98h = 0;
        var_d8h = arg1;
        var_98h = (**(code **)*puVar5)(puVar5, &var_d0h);
        var_128h = 0;
        puVar5 = (undefined8 *)func_0x000180459890(0x50);
        *puVar5 = 0x180624c70;
        puVar5[1] = var_d8h;
        var_168h = (int64_t)(puVar5 + 2);
        puVar5[9] = 0;
        if (var_98h != 0) {
            var_170h = (int64_t)puVar5;
            uVar6 = (***(code ***)var_98h)(var_98h, var_168h);
            puVar5[9] = uVar6;
        }
        var_168h = (int64_t)&var_160h;
        var_170h = (int64_t)&var_120h;
        var_178h = (int64_t)&var_88h;
        var_50h = 0;
        var_128h = (int64_t)puVar5;
        var_50h = (**(code **)*puVar5)(puVar5, &var_88h);
        var_e8h = 0;
        puVar5 = (undefined8 *)func_0x000180459890(0x48);
        *puVar5 = 0x180624ca0;
        puVar5[8] = 0;
        func_0x000180014de0(puVar5 + 1, &var_88h);
        var_e8h = (int64_t)puVar5;
        func_0x000180061500(uVar4, &var_120h);
        if (var_50h != 0) {
            (**(code **)(*(int64_t *)var_50h + 0x20))
                      (var_50h, CONCAT71((unkint7)((uint64_t)&var_88h >> 8), (int64_t *)var_50h != &var_88h));
        }
        if (var_128h != 0) {
            (**(code **)(*(int64_t *)var_128h + 0x20))
                      (var_128h, CONCAT71((unkint7)((uint64_t)&var_160h >> 8), (int64_t *)var_128h != &var_160h));
            var_128h = 0;
        }
        if (var_98h != 0) {
            (**(code **)(*(int64_t *)var_98h + 0x20))
                      (var_98h, CONCAT71((unkint7)((uint64_t)&var_d0h >> 8), (int64_t *)var_98h != &var_d0h));
        }
    }
    piVar1 = *(int32_t **)(arg1 + 8);
    if ((*(int64_t *)(piVar1 + 2) != 0) && (*piVar1 != 5)) {
        func_0x000180182eb0(1, piVar1);
        LOCK();
        *piVar1 = 5;
        UNLOCK();
        func_0x000180182870(*(undefined8 *)(piVar1 + 2));
        LOCK();
        *piVar1 = 8;
        UNLOCK();
    }
    if (*(int64_t **)(arg3 + 0x38) != (int64_t *)0x0) {
        (**(code **)(**(int64_t **)(arg3 + 0x38) + 0x10))();
    }
    LOCK();
    *(undefined4 *)arg1 = 8;
    UNLOCK();
    iVar3 = func_0x00018045b9a8(0x180624e10, 0x5c);
    uVar2 = (*(code *)0x699ddc)();
    uVar4 = func_0x0001801723e0();
    var_188h = 0x180624de8;
    var_190h._0_4_ = 0x68;
    var_198h = iVar3 + 1;
    func_0x000180172b00(uVar4, 2, 0x180624db8, uVar2);
    func_0x000180459870(var_48h ^ (uint64_t)auStack_1b8);
    return;
}

// ============================================================
// Function: FUN_1800620f0
// Address: 0x1800620f0
// Size: 45 bytes
// ============================================================
void fcn.1800620f0(int64_t arg1)
{
    int64_t *piVar1;
    
    piVar1 = *(int64_t **)(arg1 + 0x40);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 8));
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180062120
// Address: 0x180062120
// Size: 100 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180062120(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_10h._0_1_ = 1;
    *(undefined8 *)arg1 = 0x1804a5358;
    var_18h = 0x1805aadb1;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(&var_18h);
    *(undefined8 *)arg1 = 0x1804a5690;
    *(undefined8 *)(arg1 + 0x20) = 0x1806a45f0;
    *(int32_t *)(arg1 + 0x18) = (int32_t)arg2;
    return arg1;
}

// ============================================================
// Function: FUN_1800621d0
// Address: 0x1800621d0
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h

void fcn.1800621d0(int64_t arg1)
{
    code *pcVar1;
    int64_t var_38h;
    
    fcn.180062120((int64_t)&var_38h, arg1 & 0xffffffff);
    fcn.18045bae0(var_38h);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180062200
// Address: 0x180062200
// Size: 77 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180062200(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5690;
    uVar1 = *(undefined4 *)(arg2 + 0x1c);
    uVar2 = *(undefined4 *)(arg2 + 0x20);
    uVar3 = *(undefined4 *)(arg2 + 0x24);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x1c) = uVar1;
    *(undefined4 *)(arg1 + 0x20) = uVar2;
    *(undefined4 *)(arg1 + 0x24) = uVar3;
    return arg1;
}

// ============================================================
// Function: FUN_180062250
// Address: 0x180062250
// Size: 60 bytes
// ============================================================
int64_t fcn.180062250(int64_t arg1, int64_t arg2)
{
    *(undefined8 *)arg1 = 0x1804a5358;
    *(undefined (*) [16])(arg1 + 8) = ZEXT816(0);
    fcn.18045b4e4(arg2 + 8);
    *(undefined8 *)arg1 = 0x1804a5660;
    return arg1;
}

// ============================================================
// Function: FUN_1800622a0
// Address: 0x1800622a0
// Size: 162 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.1800622a0(undefined8 placeholder_0, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = (int32_t)arg3;
    if (iVar3 == 1) {
        uVar1 = 0x180624ed0;
    } else if (iVar3 == 2) {
        uVar1 = 0x180624ee0;
    } else if (iVar3 == 3) {
        uVar1 = 0x180624ea0;
    } else {
        if (iVar3 != 4) {
            uVar1 = func_0x000180455d14(arg3 & 0xffffffff);
            *(undefined (*) [16])arg2 = ZEXT816(0);
            *(undefined8 *)(arg2 + 0x10) = 0;
            *(undefined8 *)(arg2 + 0x18) = 0;
            goto code_r0x00018006231c;
        }
        uVar1 = 0x180624ec0;
    }
    *(undefined (*) [16])arg2 = ZEXT816(0);
    *(undefined8 *)(arg2 + 0x10) = 0;
    *(undefined8 *)(arg2 + 0x18) = 0;
code_r0x00018006231c:
    uVar2 = func_0x000180498cd0(uVar1);
    func_0x000180004830(arg2, uVar1, uVar2);
    return arg2;
}

// ============================================================
// Function: FUN_180062350
// Address: 0x180062350
// Size: 290 bytes
// ============================================================
int64_t fcn.180062350(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined8 *puVar5;
    undefined (*pauVar6) [16];
    undefined8 uVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_30h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0xffffffffffffffff;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined8 *)(arg1 + 0x28) = 0;
    pauVar6 = (undefined (*) [16])func_0x000180459890(0x38);
    *pauVar6 = ZEXT816(0);
    *(undefined4 *)(*pauVar6 + 8) = 1;
    *(undefined4 *)(*pauVar6 + 0xc) = 1;
    *(undefined8 *)*pauVar6 = 0x180624d38;
    pauVar1 = pauVar6 + 1;
    _var_b8h = ZEXT816(0);
    func_0x0001800618a0(pauVar1, &var_b8h);
    *(undefined (**) [16])(arg1 + 0x30) = pauVar1;
    *(undefined (**) [16])(arg1 + 0x38) = pauVar6;
    *(undefined *)(arg1 + 0x40) = 0;
    var_70h = 0;
    var_30h = 0;
    func_0x000180061b50(pauVar1, 1, &var_68h, &var_a8h);
    iVar3 = *(int64_t *)(arg1 + 0x30);
    uVar7 = func_0x000180459890(0x2a8);
    iVar4 = *(int64_t *)(iVar3 + 0x10);
    if (iVar4 != 0) {
        LOCK();
        piVar2 = (int32_t *)(iVar4 + 8);
        *piVar2 = *piVar2 + 1;
        UNLOCK();
    }
    _var_b8h = *(undefined (*) [16])(iVar3 + 8);
    uVar7 = func_0x00018017caf0(uVar7, &var_b8h);
    puVar5 = *(undefined8 **)(arg1 + 0x28);
    *(undefined8 *)(arg1 + 0x28) = uVar7;
    if (puVar5 != (undefined8 *)0x0) {
        (**(code **)*puVar5)(puVar5, 1);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180062480
// Address: 0x180062480
// Size: 383 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062480(int64_t arg1)
{
    int64_t *piVar1;
    char cVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    int32_t *piVar6;
    undefined8 *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar4 = *(int64_t *)(arg1 + 0x28);
    piVar5 = *(int64_t **)(iVar4 + 0x210);
    if (piVar5 != (int64_t *)0x0) {
        (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar4 + 0x1d8));
        *(undefined8 *)(iVar4 + 0x210) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    piVar5 = *(int64_t **)(iVar4 + 0x250);
    if (piVar5 != (int64_t *)0x0) {
        (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar4 + 0x218));
        *(undefined8 *)(iVar4 + 0x250) = 0;
    }
    iVar4 = *(int64_t *)(arg1 + 0x28);
    piVar5 = *(int64_t **)(iVar4 + 0x1d0);
    if (piVar5 != (int64_t *)0x0) {
        (**(code **)(*piVar5 + 0x20))(piVar5, piVar5 != (int64_t *)(iVar4 + 0x198));
        *(undefined8 *)(iVar4 + 0x1d0) = 0;
    }
    piVar6 = *(int32_t **)(arg1 + 0x30);
    if ((2 < *piVar6) && (*piVar6 < 7)) {
        LOCK();
        *piVar6 = 7;
        UNLOCK();
        if (*(int64_t *)(*(int64_t *)(piVar6 + 2) + 8) == 0) {
            (*(code *)0x699ddc)();
        } else {
            func_0x000180182b10();
        }
        func_0x0001800613a0(*(undefined8 *)(piVar6 + 2));
    }
    func_0x000180061db0(*(undefined8 *)(arg1 + 0x30));
    LOCK();
    cVar2 = *(char *)(arg1 + 0x40);
    *(char *)(arg1 + 0x40) = '\0';
    UNLOCK();
    if (cVar2 != '\0') {
        func_0x00018017f760(*(undefined8 *)(arg1 + 0x28));
    }
    piVar5 = *(int64_t **)(arg1 + 0x38);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar6 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    puVar7 = *(undefined8 **)(arg1 + 0x28);
    if (puVar7 != (undefined8 *)0x0) {
        (**(code **)*puVar7)(puVar7, 1);
    }
    piVar5 = *(int64_t **)(arg1 + 0x20);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar6 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar6;
            *piVar6 = *piVar6 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    piVar5 = *(int64_t **)(arg1 + 8);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar6 = (int32_t *)((int64_t)piVar5 + 0xc);
        iVar3 = *piVar6;
        *piVar6 = *piVar6 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*piVar5 + 8))();
        }
    }
    return;
}

// ============================================================
// Function: FUN_180062600
// Address: 0x180062600
// Size: 164 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062600(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar4 = *(int64_t **)(arg1 + 0x28);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 0x18);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    piVar4 = *(int64_t **)(arg1 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*piVar4 + 8))();
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800626b0
// Address: 0x1800626b0
// Size: 60 bytes
// ============================================================
void fcn.1800626b0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t *piVar3;
    
    fcn.180004e40(arg1 + 0x10);
    piVar3 = *(int64_t **)(arg1 + 8);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar3 + 0xc);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 == 1) {
    // WARNING: Could not recover jumptable at 0x0001800626e2. Too many branches
    // WARNING: Treating indirect jump as call
            (**(code **)(*piVar3 + 8))();
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800626f0
// Address: 0x1800626f0
// Size: 421 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.1800626f0(int64_t arg1, int64_t arg_28h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    undefined *puVar7;
    int64_t iVar8;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar7 = auStack_58;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar1 = *(int64_t **)(arg1 + 0x28);
    piVar6 = piVar1;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) || (*(char *)(*piVar6 + 3) != 'y')) ||
       (piVar6 = (int64_t *)(*piVar6 + 0x10), piVar6 == (int64_t *)0x0)) {
        func_0x0001800883d0(arg1, 1, 0x180624f90);
        pcVar2 = (code *)swi(3);
        (*pcVar2)();
        return;
    }
    iVar5 = *piVar6;
    piVar6 = piVar1 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar1 + 2) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar6 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x00018006286c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
            piVar6 = *(int64_t **)0x180782430;
        }
    }
    iVar8 = *piVar6 + 0x18;
    if (iVar8 != 0) {
        _var_38h = ZEXT816(0);
        var_28h = 0;
        var_20h = 0;
        uVar4 = func_0x000180498cd0(iVar8);
        func_0x000180004830(&var_38h, iVar8, uVar4);
        if (*(char *)(iVar5 + 0x40) != '\0') {
            func_0x000180180540(*(undefined8 *)(iVar5 + 0x28), &var_38h);
        }
        if (0xf < (uint64_t)var_20h) {
            iVar5 = var_38h;
            puVar7 = auStack_58;
            if ((0xfff < var_20h + 1U) &&
               (iVar5 = *(int64_t *)(var_38h + -8), puVar7 = auStack_58, 0x1f < (var_38h - iVar5) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar5 = (*pcVar2)(5);
                puVar7 = auStack_50;
            }
            *(undefined8 *)(puVar7 + -8) = 0x18006284d;
            func_0x000180459c3c(iVar5);
        }
        *(undefined8 *)(puVar7 + -8) = 0x18006285c;
        func_0x000180459870(*(uint64_t *)(puVar7 + 0x40) ^ (uint64_t)puVar7);
        return;
    }
code_r0x00018006286c:
    func_0x000180088470(arg1, 2, 6);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_1800628a0
// Address: 0x1800628a0
// Size: 96 bytes
// ============================================================
undefined8 fcn.1800628a0(int64_t arg1)
{
    char *pcVar1;
    char cVar2;
    int64_t iVar3;
    code *pcVar4;
    int64_t *piVar5;
    undefined8 uVar6;
    
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) == 9) && (*(char *)(*piVar5 + 3) == 'y')) &&
       (piVar5 = (int64_t *)(*piVar5 + 0x10), piVar5 != (int64_t *)0x0)) {
        iVar3 = *piVar5;
        LOCK();
        pcVar1 = (char *)(iVar3 + 0x40);
        cVar2 = *pcVar1;
        *pcVar1 = '\0';
        UNLOCK();
        if (cVar2 != '\0') {
            fcn.18017f760(*(undefined8 *)(iVar3 + 0x28));
        }
        return 0;
    }
    fcn.1800883d0(arg1, 1, 0x180624f90);
    pcVar4 = (code *)swi(3);
    uVar6 = (*pcVar4)();
    return uVar6;
}

// ============================================================
// Function: FUN_180062900
// Address: 0x180062900
// Size: 255 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180062900(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int32_t iVar5;
    undefined8 *puVar6;
    undefined4 *puVar7;
    undefined4 *puVar8;
    int64_t var_8h;
    int64_t in_stack_00000010;
    
    if ((int32_t)arg2 == -1) {
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
           (iVar5 = fcn.180085510(in_stack_00000010), iVar5 == 0)) {
            fcn.180099450(arg1, 0x18063d8d0);
            fcn.180087960(arg1);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0xc) = 0;
        *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
        return;
    }
    if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
        *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
        *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
        *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
    }
    if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(arg1 + 0x18) < *(int64_t *)(arg1 + 0x40) + 0x10U)) &&
       (iVar5 = fcn.180085510(in_stack_00000010), iVar5 == 0)) {
        fcn.180099450(arg1, 0x18063d8d0);
        fcn.180087960(arg1);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    puVar6 = (undefined8 *)fcn.180085370(arg1, 0xffffd8f0);
    puVar7 = (undefined4 *)fcn.1800a0d50(*puVar6, arg2 & 0xffffffff);
    puVar8 = *(undefined4 **)(arg1 + 0x40);
    uVar2 = puVar7[1];
    uVar3 = puVar7[2];
    uVar4 = puVar7[3];
    *puVar8 = *puVar7;
    puVar8[1] = uVar2;
    puVar8[2] = uVar3;
    puVar8[3] = uVar4;
    *(int64_t *)(arg1 + 0x40) = *(int64_t *)(arg1 + 0x40) + 0x10;
    fcn.180086cc0(arg1, 0xffffffff, 0x1806248d4);
    puVar7 = *(undefined4 **)(arg1 + 0x40);
    puVar8 = puVar7 + -4;
    if (puVar8 < puVar7) {
        do {
            puVar8[-4] = *puVar8;
            puVar8[-3] = puVar8[1];
            puVar8[-2] = puVar8[2];
            puVar8[-1] = puVar8[3];
            puVar7 = *(undefined4 **)(arg1 + 0x40);
            puVar8 = puVar8 + 4;
        } while (puVar8 < puVar7);
    }
    *(undefined4 **)(arg1 + 0x40) = puVar7 + -4;
    return;
}

// ============================================================
// Function: FUN_180062a00
// Address: 0x180062a00
// Size: 78 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180062a00(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) != 9) || (*(char *)(*piVar5 + 3) != 'y')) ||
       (piVar5 = (int64_t *)(*piVar5 + 0x10), piVar5 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar8 = piVar6 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x000180062bc6;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar8 + 0x18 == 0) {
code_r0x000180062bc6:
        func_0x000180088470(arg1, 2, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar9 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (piVar9 != *(int64_t **)0x180782430) {
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 6) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 3)) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
                piVar6 = *(int64_t **)0x180782430;
            }
            if (piVar6 == *(int64_t **)0x180782430) {
                piVar6 = (int64_t *)0x0;
            }
            iVar2 = *piVar6;
            if (iVar2 != 0) {
                iVar4 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar4 == 0x7161e4) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else if (iVar4 == 0x10f23d63) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else {
                    if (iVar4 == 0x3e7cc33a) {
                        uVar1 = *(uint32_t *)(*piVar5 + 0x10);
                    } else {
                        if (iVar4 != -0x4b49a6a5) goto code_r0x000180062b9e;
                        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
                    }
                    fcn.180062900(arg1, (uint64_t)uVar1);
                }
                return 1;
            }
        }
    }
code_r0x000180062b9e:
    fcn.180088560(arg1, 0x180624f00, *piVar8 + 0x18);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_180062a4e
// Address: 0x180062a4e
// Size: 320 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180062a00(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) != 9) || (*(char *)(*piVar5 + 3) != 'y')) ||
       (piVar5 = (int64_t *)(*piVar5 + 0x10), piVar5 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar8 = piVar6 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x000180062bc6;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar8 + 0x18 == 0) {
code_r0x000180062bc6:
        func_0x000180088470(arg1, 2, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar9 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (piVar9 != *(int64_t **)0x180782430) {
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 6) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 3)) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
                piVar6 = *(int64_t **)0x180782430;
            }
            if (piVar6 == *(int64_t **)0x180782430) {
                piVar6 = (int64_t *)0x0;
            }
            iVar2 = *piVar6;
            if (iVar2 != 0) {
                iVar4 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar4 == 0x7161e4) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else if (iVar4 == 0x10f23d63) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else {
                    if (iVar4 == 0x3e7cc33a) {
                        uVar1 = *(uint32_t *)(*piVar5 + 0x10);
                    } else {
                        if (iVar4 != -0x4b49a6a5) goto code_r0x000180062b9e;
                        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
                    }
                    fcn.180062900(arg1, (uint64_t)uVar1);
                }
                return 1;
            }
        }
    }
code_r0x000180062b9e:
    fcn.180088560(arg1, 0x180624f00, *piVar8 + 0x18);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_180062b8e
// Address: 0x180062b8e
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180062a00(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) != 9) || (*(char *)(*piVar5 + 3) != 'y')) ||
       (piVar5 = (int64_t *)(*piVar5 + 0x10), piVar5 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar8 = piVar6 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x000180062bc6;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar8 + 0x18 == 0) {
code_r0x000180062bc6:
        func_0x000180088470(arg1, 2, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar9 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (piVar9 != *(int64_t **)0x180782430) {
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 6) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 3)) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
                piVar6 = *(int64_t **)0x180782430;
            }
            if (piVar6 == *(int64_t **)0x180782430) {
                piVar6 = (int64_t *)0x0;
            }
            iVar2 = *piVar6;
            if (iVar2 != 0) {
                iVar4 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar4 == 0x7161e4) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else if (iVar4 == 0x10f23d63) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else {
                    if (iVar4 == 0x3e7cc33a) {
                        uVar1 = *(uint32_t *)(*piVar5 + 0x10);
                    } else {
                        if (iVar4 != -0x4b49a6a5) goto code_r0x000180062b9e;
                        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
                    }
                    fcn.180062900(arg1, (uint64_t)uVar1);
                }
                return 1;
            }
        }
    }
code_r0x000180062b9e:
    fcn.180088560(arg1, 0x180624f00, *piVar8 + 0x18);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_180062bb1
// Address: 0x180062bb1
// Size: 21 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180062a00(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) != 9) || (*(char *)(*piVar5 + 3) != 'y')) ||
       (piVar5 = (int64_t *)(*piVar5 + 0x10), piVar5 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar8 = piVar6 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x000180062bc6;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar8 + 0x18 == 0) {
code_r0x000180062bc6:
        func_0x000180088470(arg1, 2, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar9 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (piVar9 != *(int64_t **)0x180782430) {
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 6) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 3)) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
                piVar6 = *(int64_t **)0x180782430;
            }
            if (piVar6 == *(int64_t **)0x180782430) {
                piVar6 = (int64_t *)0x0;
            }
            iVar2 = *piVar6;
            if (iVar2 != 0) {
                iVar4 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar4 == 0x7161e4) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else if (iVar4 == 0x10f23d63) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else {
                    if (iVar4 == 0x3e7cc33a) {
                        uVar1 = *(uint32_t *)(*piVar5 + 0x10);
                    } else {
                        if (iVar4 != -0x4b49a6a5) goto code_r0x000180062b9e;
                        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
                    }
                    fcn.180062900(arg1, (uint64_t)uVar1);
                }
                return 1;
            }
        }
    }
code_r0x000180062b9e:
    fcn.180088560(arg1, 0x180624f00, *piVar8 + 0x18);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_180062bc6
// Address: 0x180062bc6
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.180062a00(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t *piVar6;
    undefined8 uVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar5 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar5 + 0xc) != 9) || (*(char *)(*piVar5 + 3) != 'y')) ||
       (piVar5 = (int64_t *)(*piVar5 + 0x10), piVar5 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar8 = piVar6 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6 + 2) {
        piVar8 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar8 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar4 = func_0x0001800a8360(arg1);
        if (iVar4 == 0) goto code_r0x000180062bc6;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar8 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar8) {
            piVar8 = *(int64_t **)0x180782430;
        }
    }
    if (*piVar8 + 0x18 == 0) {
code_r0x000180062bc6:
        func_0x000180088470(arg1, 2, 6);
        pcVar3 = (code *)swi(3);
        uVar7 = (*pcVar3)();
        return uVar7;
    }
    piVar6 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    piVar9 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar9 = *(int64_t **)0x180782430;
    }
    if (piVar9 != *(int64_t **)0x180782430) {
        if ((*(int32_t *)((int64_t)piVar9 + 0xc) == 6) || (*(int32_t *)((int64_t)piVar9 + 0xc) == 3)) {
            if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
                piVar6 = *(int64_t **)0x180782430;
            }
            if (piVar6 == *(int64_t **)0x180782430) {
                piVar6 = (int64_t *)0x0;
            }
            iVar2 = *piVar6;
            if (iVar2 != 0) {
                iVar4 = (int32_t)iVar2 + 0x10 + *(int32_t *)(iVar2 + 0x10);
                if (iVar4 == 0x7161e4) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else if (iVar4 == 0x10f23d63) {
                    func_0x000180018f70();
                    func_0x00018001afc0();
                } else {
                    if (iVar4 == 0x3e7cc33a) {
                        uVar1 = *(uint32_t *)(*piVar5 + 0x10);
                    } else {
                        if (iVar4 != -0x4b49a6a5) goto code_r0x000180062b9e;
                        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
                    }
                    fcn.180062900(arg1, (uint64_t)uVar1);
                }
                return 1;
            }
        }
    }
code_r0x000180062b9e:
    fcn.180088560(arg1, 0x180624f00, *piVar8 + 0x18);
    pcVar3 = (code *)swi(3);
    uVar7 = (*pcVar3)();
    return uVar7;
}

// ============================================================
// Function: FUN_180062be0
// Address: 0x180062be0
// Size: 142 bytes
// ============================================================
undefined8 fcn.180062be0(int64_t arg1)
{
    char *pcVar1;
    char cVar2;
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int64_t *piVar7;
    int32_t iVar8;
    undefined *puVar9;
    int64_t iVar10;
    undefined auStack_58 [8];
    undefined auStack_50 [24];
    undefined auStack_38 [16];
    undefined8 uStack_28;
    uint64_t uStack_20;
    uint64_t uStack_18;
    
    piVar6 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar6 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar6 + 0xc) != 9) || (*(char *)(*piVar6 + 3) != 'y')) || (*piVar6 == -0x10)) {
        auStack_38._8_8_ = 0x180062c4f;
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar5 = *(int64_t *)(arg1 + 8);
    if (iVar5 == 0) {
        auStack_38._8_8_ = 0x180062c5c;
        fcn.180088560(arg1, 0x180624f30);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar8 = *(int32_t *)(iVar5 + 0x10) + 0x10 + (int32_t)iVar5;
    if (iVar8 != 0x7161e4) {
        if (iVar8 != 0x10f23d63) {
            auStack_38._8_8_ = 0x180062c6d;
            fcn.180088560(arg1, 0x180624f00, iVar5 + 0x18);
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
        piVar6 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar6 = *(int64_t **)0x180782430;
        }
        if (((*(int32_t *)((int64_t)piVar6 + 0xc) == 9) && (*(char *)(*piVar6 + 3) == 'y')) &&
           (piVar6 = (int64_t *)(*piVar6 + 0x10), piVar6 != (int64_t *)0x0)) {
            iVar5 = *piVar6;
            LOCK();
            pcVar1 = (char *)(iVar5 + 0x40);
            cVar2 = *pcVar1;
            *pcVar1 = '\0';
            UNLOCK();
            if (cVar2 != '\0') {
                auStack_38._8_8_ = 0x1800628e4;
                fcn.18017f760(*(undefined8 *)(iVar5 + 0x28));
            }
            return 0;
        }
        auStack_38._8_8_ = 0x1800628ff;
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    puVar9 = auStack_58;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_58;
    piVar6 = *(int64_t **)(arg1 + 0x28);
    piVar7 = piVar6;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (((*(int32_t *)((int64_t)piVar7 + 0xc) != 9) || (*(char *)(*piVar7 + 3) != 'y')) ||
       (piVar7 = (int64_t *)(*piVar7 + 0x10), piVar7 == (int64_t *)0x0)) {
        fcn.1800883d0(arg1, 1, 0x180624f90);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    iVar5 = *piVar7;
    piVar7 = piVar6 + 2;
    if (*(int64_t **)(arg1 + 0x40) <= piVar6 + 2) {
        piVar7 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar7 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar8 = func_0x0001800a8360(arg1);
        if (iVar8 == 0) goto code_r0x00018006286c;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar7 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar7) {
            piVar7 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar7 + 0x18;
    if (iVar10 != 0) {
        auStack_38 = ZEXT816(0);
        uStack_28 = 0;
        uStack_20 = 0;
        uVar4 = func_0x000180498cd0(iVar10);
        func_0x000180004830(auStack_38, iVar10, uVar4);
        if (*(char *)(iVar5 + 0x40) != '\0') {
            func_0x000180180540(*(undefined8 *)(iVar5 + 0x28), auStack_38);
        }
        if (0xf < uStack_20) {
            iVar5 = auStack_38._0_8_;
            puVar9 = auStack_58;
            if ((0xfff < uStack_20 + 1) &&
               (iVar5 = *(int64_t *)(auStack_38._0_8_ + -8), puVar9 = auStack_58, 0x1f < (auStack_38._0_8_ - iVar5) - 8U
               )) {
                pcVar3 = (code *)swi(0x29);
                iVar5 = (*pcVar3)(5);
                puVar9 = auStack_50;
            }
            *(undefined8 *)(puVar9 + -8) = 0x18006284d;
            func_0x000180459c3c(iVar5);
        }
        *(undefined8 *)(puVar9 + -8) = 0x18006285c;
        uVar4 = func_0x000180459870(*(uint64_t *)(puVar9 + 0x40) ^ (uint64_t)puVar9);
        return uVar4;
    }
code_r0x00018006286c:
    func_0x000180088470(arg1, 2, 6);
    pcVar3 = (code *)swi(3);
    uVar4 = (*pcVar3)();
    return uVar4;
}

// ============================================================
// Function: FUN_180062c70
// Address: 0x180062c70
// Size: 32 bytes
// ============================================================
undefined8 fcn.180062c70(undefined8 param_1)
{
    fcn.1800867f0(param_1, 0x180624f90, 0xf);
    return 1;
}

// ============================================================
// Function: FUN_180062c90
// Address: 0x180062c90
// Size: 10 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    char **ppcVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    ppcVar7 = (char **)func_0x000180008740();
    if ((**ppcVar7 != '\0') && (iVar4 = *(int64_t *)arg2, iVar4 != 0)) {
        uVar5 = *(undefined8 *)(**(int64_t **)(iVar4 + 0x18) + 0x28);
        if (*(int32_t *)(iVar4 + 0x10) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x10) = 0xffffffff;
        }
        if (*(int32_t *)(iVar4 + 0x14) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x14) = 0xffffffff;
        }
    }
    piVar6 = *(int64_t **)(arg2 + 8);
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180062c9a
// Address: 0x180062c9a
// Size: 44 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    char **ppcVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    ppcVar7 = (char **)func_0x000180008740();
    if ((**ppcVar7 != '\0') && (iVar4 = *(int64_t *)arg2, iVar4 != 0)) {
        uVar5 = *(undefined8 *)(**(int64_t **)(iVar4 + 0x18) + 0x28);
        if (*(int32_t *)(iVar4 + 0x10) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x10) = 0xffffffff;
        }
        if (*(int32_t *)(iVar4 + 0x14) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x14) = 0xffffffff;
        }
    }
    piVar6 = *(int64_t **)(arg2 + 8);
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180062cc6
// Address: 0x180062cc6
// Size: 52 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    char **ppcVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    ppcVar7 = (char **)func_0x000180008740();
    if ((**ppcVar7 != '\0') && (iVar4 = *(int64_t *)arg2, iVar4 != 0)) {
        uVar5 = *(undefined8 *)(**(int64_t **)(iVar4 + 0x18) + 0x28);
        if (*(int32_t *)(iVar4 + 0x10) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x10) = 0xffffffff;
        }
        if (*(int32_t *)(iVar4 + 0x14) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x14) = 0xffffffff;
        }
    }
    piVar6 = *(int64_t **)(arg2 + 8);
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180062cfa
// Address: 0x180062cfa
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    char **ppcVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    ppcVar7 = (char **)func_0x000180008740();
    if ((**ppcVar7 != '\0') && (iVar4 = *(int64_t *)arg2, iVar4 != 0)) {
        uVar5 = *(undefined8 *)(**(int64_t **)(iVar4 + 0x18) + 0x28);
        if (*(int32_t *)(iVar4 + 0x10) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x10) = 0xffffffff;
        }
        if (*(int32_t *)(iVar4 + 0x14) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x14) = 0xffffffff;
        }
    }
    piVar6 = *(int64_t **)(arg2 + 8);
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180062d08
// Address: 0x180062d08
// Size: 50 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180062c90(undefined8 placeholder_0, int64_t arg2)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    char **ppcVar7;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    ppcVar7 = (char **)func_0x000180008740();
    if ((**ppcVar7 != '\0') && (iVar4 = *(int64_t *)arg2, iVar4 != 0)) {
        uVar5 = *(undefined8 *)(**(int64_t **)(iVar4 + 0x18) + 0x28);
        if (*(int32_t *)(iVar4 + 0x10) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x10) = 0xffffffff;
        }
        if (*(int32_t *)(iVar4 + 0x14) != -1) {
            (**(code **)0x1807825d0)(uVar5);
            *(undefined4 *)(iVar4 + 0x14) = 0xffffffff;
        }
    }
    piVar6 = *(int64_t **)(arg2 + 8);
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180062d40
// Address: 0x180062d40
// Size: 2079 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch

void fcn.180062d40(int64_t arg1)
{
    undefined (*arg1_00) [16];
    int32_t *piVar1;
    int64_t *piVar2;
    uint32_t *puVar3;
    uint32_t uVar4;
    code *pcVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    int32_t iVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    undefined (*pauVar12) [16];
    undefined (*pauVar13) [16];
    undefined8 uVar14;
    int64_t *piVar15;
    int64_t iVar16;
    int64_t *piVar17;
    uint64_t uVar18;
    undefined *puVar19;
    uint64_t uVar20;
    uint64_t uVar21;
    undefined auStack_1a8 [8];
    undefined auStack_1a0 [24];
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    undefined8 uStack_c0;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar19 = auStack_1a8;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1a8;
    piVar17 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar17 = *(int64_t **)0x180782430;
    }
    var_170h = arg1;
    if (*(int32_t *)((int64_t)piVar17 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar8 = func_0x0001800a8360(arg1);
        if (iVar8 == 0) goto code_r0x000180063532;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar17 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar17 = *(int64_t **)0x180782430;
        }
    }
    iVar16 = *piVar17 + 0x18;
    if (iVar16 == 0) goto code_r0x000180063532;
    uVar4 = *(uint32_t *)(*piVar17 + 0x14);
    uVar21 = (uint64_t)uVar4;
    _var_c8h = ZEXT816(0);
    var_b8h = 0;
    var_b0h = 0;
    if (0xf < uVar21) {
        uVar18 = uVar21 | 0xf;
        if (uVar18 < 0x16) {
            uVar18 = 0x16;
        }
        if (uVar18 + 1 < 0x1000) {
            uVar20 = func_0x000180459890();
code_r0x000180062e7d:
            var_c8h = uVar20;
            var_b8h = uVar21;
            var_b0h = uVar18;
            func_0x000180498030(uVar20, iVar16, uVar21);
            *(undefined *)(uVar21 + uVar20) = 0;
            goto code_r0x000180062e9b;
        }
        if (uVar18 + 0x28 <= uVar18 + 1) {
            func_0x000180004720();
code_r0x00018006354c:
            uVar14 = func_0x00018045f7d4();
code_r0x000180063552:
            func_0x000180093000(uVar14, 0x18063e070);
            pcVar5 = (code *)swi(3);
            (*pcVar5)();
            return;
        }
        iVar11 = func_0x000180459890(uVar18 + 0x28);
        if (iVar11 != 0) {
            uVar20 = iVar11 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar20 - 8) = iVar11;
            goto code_r0x000180062e7d;
        }
code_r0x0001800634e3:
        pcVar5 = (code *)swi(0x29);
        iVar16 = (*pcVar5)(5);
        puVar19 = auStack_1a0;
code_r0x0001800634ed:
        *(undefined8 *)(puVar19 + -8) = 0x1800634f2;
        func_0x000180459c3c(iVar16);
code_r0x0001800634f2:
        *(undefined8 *)(puVar19 + -8) = 0x180063503;
        func_0x000180459870(var_58h ^ (uint64_t)puVar19);
        return;
    }
    var_b0h = 0xf;
    var_b8h = uVar21;
    func_0x000180498030(&var_c8h, iVar16, uVar4);
    *(undefined *)((int64_t)&var_c8h + uVar21) = 0;
code_r0x000180062e9b:
    var_178h = (int64_t)&var_170h;
    uVar9 = func_0x000180063560(&var_178h);
    uVar10 = func_0x000180063560(&var_178h);
    iVar16 = var_170h;
    pauVar12 = (undefined (*) [16])func_0x000180087f70(var_170h, 0x10, 0x79);
    pauVar13 = (undefined (*) [16])func_0x000180459890(0x58);
    *pauVar13 = ZEXT816(0);
    *(undefined4 *)(*pauVar13 + 8) = 1;
    *(undefined4 *)(*pauVar13 + 0xc) = 1;
    *(undefined8 *)*pauVar13 = 0x180624bf0;
    arg1_00 = pauVar13 + 1;
    var_178h = (int64_t)pauVar13;
    fcn.180062350((int64_t)arg1_00);
    var_160h = (int64_t)pauVar13;
    var_168h = (int64_t)arg1_00;
    if ((arg1_00 != (undefined (*) [16])0x0) &&
       ((*(int64_t *)(pauVar13[1] + 8) == 0 || (*(int32_t *)(*(int64_t *)(pauVar13[1] + 8) + 8) == 0)))) {
        LOCK();
        *(int32_t *)(*pauVar13 + 8) = *(int32_t *)(*pauVar13 + 8) + 1;
        UNLOCK();
        LOCK();
        *(int32_t *)(*pauVar13 + 0xc) = *(int32_t *)(*pauVar13 + 0xc) + 1;
        UNLOCK();
        *(undefined (**) [16])*arg1_00 = arg1_00;
        piVar17 = *(int64_t **)(pauVar13[1] + 8);
        *(undefined (**) [16])(pauVar13[1] + 8) = pauVar13;
        if (piVar17 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar17 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)(*piVar17 + 8))();
            }
        }
        LOCK();
        piVar1 = (int32_t *)(*pauVar13 + 8);
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            (***(code ***)*pauVar13)(pauVar13);
            LOCK();
            piVar1 = (int32_t *)(*pauVar13 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)(*(int64_t *)*pauVar13 + 8))(pauVar13);
            }
        }
    }
    *(undefined8 *)*pauVar12 = 0;
    *(undefined8 *)(*pauVar12 + 8) = 0;
    LOCK();
    *(int32_t *)(*pauVar13 + 8) = *(int32_t *)(*pauVar13 + 8) + 1;
    UNLOCK();
    *(undefined (**) [16])*pauVar12 = arg1_00;
    *(undefined (**) [16])(*pauVar12 + 8) = pauVar13;
    iVar8 = func_0x0001800885b0(iVar16, 0x180624f90);
    if (iVar8 != 0) {
        var_188h = 0;
        func_0x0001800869f0(iVar16, fcn.180062a00, 0, 0);
        func_0x000180087370(iVar16, 0xfffffffe, 0x1805aae90);
        var_188h = 0;
        func_0x0001800869f0(iVar16, fcn.180062be0, 0, 0);
        func_0x000180087370(iVar16, 0xfffffffe, 0x1806203d0);
        var_188h = 0;
        func_0x0001800869f0(iVar16, fcn.180062c70, 0, 0);
        func_0x000180087370(iVar16, 0xfffffffe, 0x180622440);
        fcn.1800867f0(iVar16, 0x180624f90, 0xf);
        func_0x000180087370(iVar16, 0xfffffffe, 0x180622470);
        fcn.1800867f0(iVar16, 0x180622458, 0x17);
        func_0x000180087370(iVar16, 0xfffffffe, 0x1806224a0);
    }
    func_0x000180087650(iVar16, 0xfffffffe);
    if (*(int64_t *)(*pauVar12 + 8) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(*pauVar12 + 8) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    iVar16 = *(int64_t *)*pauVar12;
    piVar17 = *(int64_t **)(*pauVar12 + 8);
    auVar6 = *pauVar12;
    LOCK();
    piVar1 = (int32_t *)(*pauVar13 + 8);
    iVar8 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    var_d8h = iVar16;
    var_d0h = (int64_t)piVar17;
    if (iVar8 == 1) {
        (***(code ***)*pauVar13)(pauVar13);
        LOCK();
        piVar1 = (int32_t *)(*pauVar13 + 0xc);
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            (**(code **)(*(int64_t *)*pauVar13 + 8))(pauVar13);
        }
    }
    *(undefined4 *)(iVar16 + 0x10) = uVar9;
    *(undefined4 *)(iVar16 + 0x14) = uVar10;
    uVar14 = func_0x000180085760(var_170h);
    func_0x0001800205e0(&var_130h, uVar14);
    if (var_128h != 0) {
        LOCK();
        *(int32_t *)(var_128h + 8) = *(int32_t *)(var_128h + 8) + 1;
        UNLOCK();
    }
    *(int64_t *)(iVar16 + 0x18) = var_130h;
    piVar15 = *(int64_t **)(iVar16 + 0x20);
    *(int64_t *)(iVar16 + 0x20) = var_128h;
    if (piVar15 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar15 + 1;
        iVar8 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            (**(code **)*piVar15)(piVar15);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar15 + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)(*piVar15 + 8))(piVar15);
            }
        }
    }
    *(int64_t *)(var_170h + 0x40) = *(int64_t *)(var_170h + 0x40) + -0x10;
    func_0x0001800205e0(&var_140h, var_170h);
    piVar15 = (int64_t *)func_0x000180008740();
    iVar16 = *(int64_t *)(*piVar15 + 0x18);
    func_0x0001800137d0();
    var_120h = iVar16;
    func_0x00018000b4d0(&var_118h, &var_c8h);
    if (piVar17 != (int64_t *)0x0) {
        LOCK();
        *(int32_t *)(piVar17 + 1) = *(int32_t *)(piVar17 + 1) + 1;
        UNLOCK();
    }
    if (var_138h != 0) {
        LOCK();
        *(int32_t *)(var_138h + 8) = *(int32_t *)(var_138h + 8) + 1;
        UNLOCK();
    }
    var_e8h = var_140h;
    var_e0h = var_138h;
    var_178h = (int64_t)&var_120h;
    _var_f8h = auVar6;
    iVar16 = func_0x00018045838c();
    var_a8h = var_120h;
    func_0x00018000b4d0(&var_a0h, &var_118h);
    if (var_f0h != 0) {
        LOCK();
        *(int32_t *)(var_f0h + 8) = *(int32_t *)(var_f0h + 8) + 1;
        UNLOCK();
    }
    var_80h = var_f8h;
    var_78h = var_f0h;
    if (var_e0h != 0) {
        LOCK();
        *(int32_t *)(var_e0h + 8) = *(int32_t *)(var_e0h + 8) + 1;
        UNLOCK();
    }
    var_70h = var_e8h;
    var_68h = var_e0h;
    _var_158h = ZEXT816(0);
    var_60h = iVar16;
    var_148h = func_0x000180459890();
    *(undefined4 *)var_148h = 1;
    *(undefined4 *)(var_148h + 4) = 2;
    *(undefined8 *)(var_148h + 8) = 0;
    *(undefined8 *)(var_148h + 0x10) = 0;
    *(undefined4 *)(var_148h + 0x18) = 0;
    piVar15 = (int64_t *)func_0x000180459890(0x50);
    *piVar15 = var_a8h;
    var_168h = (int64_t)piVar15;
    func_0x00018000b4d0(piVar15 + 1, &var_a0h);
    arg1 = var_78h;
    piVar15[5] = 0;
    piVar15[6] = 0;
    if (var_78h != 0) {
        LOCK();
        *(int32_t *)(var_78h + 8) = *(int32_t *)(var_78h + 8) + 1;
        UNLOCK();
    }
    piVar15[5] = var_80h;
    piVar15[6] = var_78h;
    piVar15[7] = var_70h;
    piVar15[8] = var_68h;
    var_70h = 0;
    var_68h = 0;
    piVar15[9] = var_60h;
    var_168h = (int64_t)piVar15;
    var_180h = (int64_t)&var_150h;
    var_188h = var_188h & 0xffffffff00000000;
    iVar16 = func_0x00018045f6e8(0, 0, 0x1800649e0, piVar15);
    auVar6 = _var_158h;
    var_158h = iVar16;
    auVar7 = _var_158h;
    if (iVar16 != 0) {
        var_150h._0_4_ = auVar6._8_4_;
        if ((int32_t)var_150h != 0) {
            var_160h._0_4_ = (int32_t)var_150h;
            var_168h = iVar16;
            var_150h._4_4_ = auVar6._12_4_;
            var_160h._4_4_ = var_150h._4_4_;
            _var_158h = auVar7;
            iVar8 = func_0x000180454a0c(&var_168h);
            auVar7 = _var_158h;
            if (iVar8 == 0) {
                _var_168h = ZEXT816(0);
                _var_158h = ZEXT812(0);
                var_150h._4_4_ = 0;
                if (var_148h != 0) {
                    LOCK();
                    puVar3 = (uint32_t *)(var_148h + 4);
                    uVar4 = *puVar3;
                    *puVar3 = *puVar3 - 2;
                    UNLOCK();
                    if ((uVar4 & 0xfffffffe) == 2) {
                        LOCK();
                        iVar8 = *(int32_t *)var_148h;
                        *(int32_t *)var_148h = *(int32_t *)var_148h + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            func_0x000180459c3c(var_148h, 0x20);
                        }
                    }
                }
                if ((int32_t)var_150h != 0) goto code_r0x00018006354c;
                if (arg1 != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(arg1 + 8);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (***(code ***)arg1)(arg1);
                        LOCK();
                        piVar1 = (int32_t *)(arg1 + 0xc);
                        iVar8 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            (**(code **)(*(int64_t *)arg1 + 8))(arg1);
                        }
                    }
                }
                fcn.180004e40(&var_a0h);
                uVar14 = func_0x000180063610(&var_120h);
                if (*(uint16_t *)(var_170h + 0x6a) < *(uint16_t *)(var_170h + 0x68)) goto code_r0x000180063552;
                *(int64_t *)(var_170h + 0x28) = *(int64_t *)(var_170h + 0x40) + -0x10;
                *(undefined *)(var_170h + 3) = 1;
                if (var_138h != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(var_138h + 8);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (***(code ***)var_138h)(var_138h);
                        LOCK();
                        piVar1 = (int32_t *)(var_138h + 0xc);
                        iVar8 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            (**(code **)(*(int64_t *)var_138h + 8))(var_138h);
                        }
                    }
                }
                if (var_128h != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(var_128h + 8);
                    iVar8 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (***(code ***)var_128h)(var_128h);
                        LOCK();
                        piVar1 = (int32_t *)(var_128h + 0xc);
                        iVar8 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            (**(code **)(*(int64_t *)var_128h + 8))(var_128h);
                        }
                    }
                }
                if (piVar17 != (int64_t *)0x0) {
                    LOCK();
                    piVar15 = piVar17 + 1;
                    iVar8 = *(int32_t *)piVar15;
                    *(int32_t *)piVar15 = *(int32_t *)piVar15 + -1;
                    UNLOCK();
                    if (iVar8 == 1) {
                        (**(code **)*piVar17)(piVar17);
                        LOCK();
                        piVar1 = (int32_t *)((int64_t)piVar17 + 0xc);
                        iVar8 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar8 == 1) {
                            (**(code **)(*piVar17 + 8))(piVar17);
                        }
                    }
                }
                if ((uint64_t)var_b0h < 0x10) goto code_r0x0001800634f2;
                iVar16 = var_c8h;
                puVar19 = auStack_1a8;
                if ((0xfff < var_b0h + 1U) &&
                   (iVar16 = *(int64_t *)(var_c8h + -8), puVar19 = auStack_1a8,
                   0x1f < (var_c8h - *(int64_t *)(var_c8h + -8)) - 8U)) goto code_r0x0001800634e3;
                goto code_r0x0001800634ed;
            }
        }
        _var_158h = auVar7;
        fcn.1804542e8(1);
    }
    var_150h._0_4_ = 0;
    fcn.1804542e8(6);
code_r0x000180063532:
    func_0x000180088470(arg1, 1, 6);
    pcVar5 = (code *)swi(3);
    (*pcVar5)();
    return;
}

// ============================================================
// Function: FUN_180063560
// Address: 0x180063560
// Size: 170 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180063560(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    fcn.1800869f0(0);
    fcn.1800867f0(**(undefined8 **)arg1, 0x1806217a8, 0xd);
    iVar2 = fcn.180094080(0);
    if (iVar2 == 0) {
        (**(code **)0x180782618)(**(undefined8 **)arg1, 0xffffffff);
        *(int64_t *)(**(int64_t **)arg1 + 0x40) = *(int64_t *)(**(int64_t **)arg1 + 0x40) + -0x10;
        return;
    }
    fcn.180087960(**(undefined8 **)arg1);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180063610
// Address: 0x180063610
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180063610(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    int64_t iVar7;
    undefined *puVar8;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    piVar5 = *(int64_t **)(arg1 + 0x40);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    piVar5 = *(int64_t **)(arg1 + 0x30);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar5 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    if (0xf < *(uint64_t *)(arg1 + 0x20)) {
        iVar4 = *(int64_t *)(arg1 + 8);
        iVar7 = iVar4;
        puVar8 = auStack_28;
        if ((0xfff < *(uint64_t *)(arg1 + 0x20) + 1) &&
           (iVar7 = *(int64_t *)(iVar4 + -8), puVar8 = auStack_28, 0x1f < (iVar4 - iVar7) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar7 = (*pcVar6)(5);
            puVar8 = auStack_20;
        }
        *(undefined8 *)(puVar8 + -8) = 0x180004e88;
        func_0x000180459c3c(iVar7);
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0xf;
    *(undefined *)(int64_t *)(arg1 + 8) = 0;
    return;
}

// ============================================================
// Function: FUN_1800636b0
// Address: 0x1800636b0
// Size: 396 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018006372c: Changing call to branch
// WARNING: Possible PIC construction at 0x0001800637fc: Changing call to branch
// WARNING: Possible PIC construction at 0x000180063776: Changing call to branch
// WARNING: Removing unreachable block (ram,0x000180063731)
// WARNING: Removing unreachable block (ram,0x000180063740)
// WARNING: Removing unreachable block (ram,0x000180063762)
// WARNING: Removing unreachable block (ram,0x00018006376e)
// WARNING: Removing unreachable block (ram,0x000180063768)
// WARNING: Removing unreachable block (ram,0x00018006377b)
// WARNING: Removing unreachable block (ram,0x000180063789)
// WARNING: Removing unreachable block (ram,0x00018006379d)
// WARNING: Removing unreachable block (ram,0x0001800637b2)
// WARNING: Removing unreachable block (ram,0x0001800637bb)
// WARNING: Removing unreachable block (ram,0x0001800637cc)
// WARNING: Removing unreachable block (ram,0x000180063824)
// WARNING: Removing unreachable block (ram,0x0001800637dd)
// WARNING: Removing unreachable block (ram,0x000180063801)
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.1800636b0(undefined8 placeholder_0, int64_t arg2)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStackY_a8 [32];
    undefined8 uStackY_88;
    undefined4 uStackY_7c;
    uint64_t uStackY_78;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    *(code **)(*(int64_t *)(arg2 + 0x20) + 0x37f8) = fcn.180062c90;
    func_0x000180018f70();
    func_0x000180086fd0(arg2, 0, 0);
    iVar1 = *(int64_t *)(arg2 + 0x40);
    iVar2 = *(int64_t *)(arg2 + 0x28);
    fcn.1800869f0(0);
    uStackY_78 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_a8;
    iVar4 = (int32_t)(iVar1 - iVar2 >> 4);
    if (iVar4 < 1) {
        if (iVar4 < -9999) {
            uVar5 = fcn.180085370();
        } else {
            uVar5 = (int64_t)iVar4 * 0x10 + *(int64_t *)(arg2 + 0x40);
        }
    } else {
        uVar5 = *(int64_t *)(arg2 + 0x28) + -0x10 + (int64_t)iVar4 * 0x10;
        if (*(uint64_t *)(arg2 + 0x40) <= uVar5) {
            uVar5 = *(uint64_t *)0x180782430;
        }
    }
    piVar6 = (int64_t *)(arg2 + 0x40);
    uVar3 = func_0x000180498cd0(0x180624fe0);
    uStackY_88 = func_0x00018009a8e0(arg2, 0x180624fe0, uVar3);
    uStackY_7c = 6;
    func_0x0001800a8680(arg2, uVar5, &uStackY_88, *piVar6 + -0x10);
    *piVar6 = *piVar6 + -0x10;
    func_0x000180459870(uStackY_78 ^ (uint64_t)auStackY_a8);
    return;
}

// ============================================================
// Function: FUN_180063840
// Address: 0x180063840
// Size: 112 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180063840(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    pauVar1 = (undefined (*) [16])fcn.180459890(0xb8);
    *pauVar1 = ZEXT816(0);
    *(undefined4 *)(*pauVar1 + 8) = 1;
    *(undefined4 *)(*pauVar1 + 0xc) = 1;
    *(undefined8 *)*pauVar1 = 0x1804a6e78;
    fcn.180061290(pauVar1 + 1, 0);
    *(undefined (**) [16])arg1 = pauVar1 + 1;
    *(undefined (**) [16])(arg1 + 8) = pauVar1;
    return arg1;
}

// ============================================================
// Function: FUN_1800638b0
// Address: 0x1800638b0
// Size: 223 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1800638b0(int64_t arg1, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3, int64_t arg_28h)
{
    int64_t *piVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    char cStack_10;
    
    piVar1 = *(int64_t **)arg1;
    if (piVar1 != (int64_t *)0x0) {
        if ((*(char *)(arg1 + 8) == '\0') ||
           ((*(char *)(piVar1 + 0x17) == '\0' && ((*(char *)(arg1 + 8) == '\0' || (*(char *)(piVar1 + 0x17) == '\0')))))
           ) {
            var_18h = (int64_t)(piVar1 + 4);
            cStack_10 = 0;
            iVar3 = func_0x000180456008(var_18h);
            if (iVar3 != 0) {
                fcn.1804542e8(5);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            if (*(int32_t *)((int64_t)piVar1 + 0x6c) == 0x7fffffff) {
                *(undefined4 *)((int64_t)piVar1 + 0x6c) = 0x7ffffffe;
                fcn.1804542e8(6);
                pcVar2 = (code *)swi(3);
                (*pcVar2)();
                return;
            }
            cStack_10 = '\x01';
            if (*(char *)((int64_t)piVar1 + 0xc1) == '\0') {
                *(undefined *)((int64_t)piVar1 + 0xc) = *(undefined *)arg2;
                (**(code **)(*piVar1 + 0x28))(piVar1, &var_18h, 0);
                if (cStack_10 != '\0') {
                    func_0x000180456010(var_18h);
                }
                return;
            }
            fcn.1800621d0(3);
        }
    }
    fcn.1800621d0(4);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180063990
// Address: 0x180063990
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180063990(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = *(undefined8 *)arg2;
    uVar5 = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    piVar6 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)arg1 = uVar4;
    *(undefined8 *)(arg1 + 8) = uVar5;
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_1800639bd
// Address: 0x1800639bd
// Size: 68 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180063990(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = *(undefined8 *)arg2;
    uVar5 = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    piVar6 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)arg1 = uVar4;
    *(undefined8 *)(arg1 + 8) = uVar5;
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180063a01
// Address: 0x180063a01
// Size: 14 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180063990(int64_t arg1, int64_t arg2, int64_t arg_38h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    undefined8 uVar4;
    undefined8 uVar5;
    int64_t *piVar6;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar4 = *(undefined8 *)arg2;
    uVar5 = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)arg2 = 0;
    *(undefined8 *)(arg2 + 8) = 0;
    piVar6 = *(int64_t **)(arg1 + 8);
    *(undefined8 *)arg1 = uVar4;
    *(undefined8 *)(arg1 + 8) = uVar5;
    if (piVar6 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar6 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar6)(piVar6);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar6 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar6 + 8))(piVar6);
            }
        }
        return arg1;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180063a10
// Address: 0x180063a10
// Size: 289 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x000180063ac5: Changing call to branch

void fcn.180063a10(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int64_t *piVar3;
    code *pcVar4;
    int32_t iVar5;
    undefined4 uVar6;
    undefined4 *puVar7;
    int64_t iVar8;
    int64_t iVar9;
    undefined *puVar10;
    undefined8 *puVar11;
    undefined8 uStack_50;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    puVar10 = auStack_48;
    iVar8 = *(int64_t *)(arg1 + 0x20);
    if (iVar8 != 0) {
        do {
            piVar3 = *(int64_t **)
                      (*(int64_t *)
                        (*(int64_t *)(arg1 + 8) +
                        (iVar8 + *(int64_t *)(arg1 + 0x18) + -1 & *(int64_t *)(arg1 + 0x10) - 1U) * 8) + 8);
            if (piVar3 != (int64_t *)0x0) {
                LOCK();
                piVar1 = piVar3 + 1;
                iVar5 = *(int32_t *)piVar1;
                *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
                UNLOCK();
                if (iVar5 == 1) {
                    uStack_50 = 0x180063a6c;
                    (**(code **)*piVar3)(piVar3);
                    LOCK();
                    piVar2 = (int32_t *)((int64_t)piVar3 + 0xc);
                    iVar5 = *piVar2;
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (iVar5 == 1) {
                        uStack_50 = 0x180063a84;
                        (**(code **)(*piVar3 + 8))(piVar3);
                    }
                }
            }
            iVar8 = *(int64_t *)(arg1 + 0x20) + -1;
            *(int64_t *)(arg1 + 0x20) = iVar8;
        } while (iVar8 != 0);
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    if (*(int64_t *)(arg1 + 8) == 0) {
code_r0x000180063b19:
        iVar9 = *(int64_t *)arg1;
        *(undefined8 *)arg1 = 0;
        iVar8 = *(int64_t *)(puVar10 + 0x40);
        puVar11 = (undefined8 *)(puVar10 + 0x48);
    } else {
        iVar8 = *(int64_t *)(arg1 + 0x10);
        do {
            if (iVar8 < 1) {
                iVar8 = *(int64_t *)(arg1 + 8);
                iVar9 = iVar8;
                puVar10 = auStack_48;
                if ((0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 8)) &&
                   (iVar9 = *(int64_t *)(iVar8 + -8), puVar10 = auStack_48, 0x1f < (iVar8 - iVar9) - 8U)) {
                    iVar9 = 5;
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar10 = auStack_40;
                }
                *(undefined8 *)(puVar10 + -8) = 0x180063b11;
                func_0x000180459c3c(iVar9);
                *(undefined8 *)(arg1 + 8) = 0;
                *(undefined8 *)(arg1 + 0x10) = 0;
                goto code_r0x000180063b19;
            }
            iVar8 = iVar8 + -1;
            iVar9 = *(int64_t *)(*(int64_t *)(arg1 + 8) + iVar8 * 8);
        } while (iVar9 == 0);
        puVar11 = &uStack_50;
        uStack_50 = 0x180063aca;
    }
    if (iVar9 != 0) {
        *(int64_t *)((int64_t)puVar11 + -8) = iVar8;
        *(undefined8 *)((int64_t)puVar11 + -0x30) = 0x18047ca3c;
        iVar5 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar9);
        if (iVar5 == 0) {
            *(undefined8 *)((int64_t)puVar11 + -0x30) = 0x18047ca46;
            uVar6 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)puVar11 + -0x30) = 0x18047ca4d;
            uVar6 = func_0x00018046b63c(uVar6);
            *(undefined8 *)((int64_t)puVar11 + -0x30) = 0x18047ca54;
            puVar7 = (undefined4 *)func_0x00018046b77c();
            *puVar7 = uVar6;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180063b50
// Address: 0x180063b50
// Size: 110 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180063b50(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar3 != 0) {
        piVar4 = *(int64_t **)(iVar3 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        func_0x000180459c3c(iVar3, 0x10);
    }
    if ((arg2 & 1U) != 0) {
        func_0x000180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180063bc0
// Address: 0x180063bc0
// Size: 119 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.180063bc0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)(arg1 + 0x10);
    if (iVar3 != 0) {
        fcn.180004e40(iVar3 + 0x10);
        piVar4 = *(int64_t **)(iVar3 + 8);
        if (piVar4 != (int64_t *)0x0) {
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar4 + 8))();
            }
        }
        func_0x000180459c3c(iVar3, 0x30);
    }
    if ((arg2 & 1U) != 0) {
        func_0x000180459c3c(arg1, 0x28);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180063c50
// Address: 0x180063c50
// Size: 477 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180063c50(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t *piVar3;
    code *pcVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    int32_t iVar7;
    int32_t iVar8;
    undefined4 uVar9;
    undefined8 *puVar10;
    undefined4 *puVar11;
    undefined4 *puVar12;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t unaff_R15;
    bool bVar13;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar2 = *(int64_t *)(arg2 + 8);
    var_40h = 0;
    if (iVar2 == 0) {
code_r0x000180063c93:
        var_48h = 0;
    } else {
        iVar8 = *(int32_t *)(iVar2 + 8);
        do {
            if (iVar8 == 0) goto code_r0x000180063c93;
            LOCK();
            iVar7 = *(int32_t *)(iVar2 + 8);
            bVar13 = iVar8 == iVar7;
            if (bVar13) {
                *(int32_t *)(iVar2 + 8) = iVar8 + 1;
                iVar7 = iVar8;
            }
            UNLOCK();
            iVar8 = iVar7;
        } while (!bVar13);
        var_48h = *(int64_t *)arg2;
        var_40h = *(int64_t *)(arg2 + 8);
    }
    if ((var_48h != 0) && (iVar2 = *(int64_t *)(**(int64_t **)(var_48h + 0x18) + 0x28), iVar2 != 0)) {
        uVar9 = *(undefined4 *)(var_48h + 0x14);
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar2 + 0x18) < *(int64_t *)(iVar2 + 0x40) + 0x10U)) &&
           (iVar8 = fcn.180085510(unaff_R15), iVar8 == 0)) {
            fcn.180099450(iVar2, 0x18063d8d0);
            fcn.180087960(iVar2);
            pcVar4 = (code *)swi(3);
            (*pcVar4)();
            return;
        }
        puVar10 = (undefined8 *)fcn.180085370(iVar2, 0xffffd8f0);
        puVar11 = (undefined4 *)fcn.1800a0d50(*puVar10, uVar9);
        puVar12 = *(undefined4 **)(iVar2 + 0x40);
        uVar9 = puVar11[1];
        uVar5 = puVar11[2];
        uVar6 = puVar11[3];
        *puVar12 = *puVar11;
        puVar12[1] = uVar9;
        puVar12[2] = uVar5;
        puVar12[3] = uVar6;
        *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + 0x10;
        fcn.180086cc0(iVar2, 0xffffffff, 0x1806247fc);
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        puVar12 = *(undefined4 **)(iVar2 + 0x40);
        puVar11 = puVar12;
        while (puVar12 + -8 < puVar11) {
            *puVar11 = puVar11[-4];
            puVar11[1] = puVar11[-3];
            puVar11[2] = puVar11[-2];
            puVar11[3] = puVar11[-1];
            puVar11 = puVar11 + -4;
        }
        puVar11 = *(undefined4 **)(iVar2 + 0x40);
        uVar9 = puVar11[1];
        uVar5 = puVar11[2];
        uVar6 = puVar11[3];
        puVar12[-8] = *puVar11;
        puVar12[-7] = uVar9;
        puVar12[-6] = uVar5;
        puVar12[-5] = uVar6;
        func_0x0001800878a0(iVar2, 1, 0);
    }
    if ((int64_t *)var_40h != (int64_t *)0x0) {
        LOCK();
        piVar3 = (int64_t *)(var_40h + 8);
        iVar8 = *(int32_t *)piVar3;
        *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            (***(code ***)var_40h)(var_40h);
            LOCK();
            piVar1 = (int32_t *)(var_40h + 0xc);
            iVar8 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar8 == 1) {
                (**(code **)(*(int64_t *)var_40h + 8))(var_40h);
            }
        }
    }
    piVar3 = *(int64_t **)(arg2 + 8);
    if (piVar3 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar3 + 0xc);
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            (**(code **)(*piVar3 + 8))();
        }
    }
    if ((arg2 != 0) && (iVar8 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg2, in_R9, unaff_RBX), iVar8 == 0))
    {
        uVar9 = (*(code *)0x699ff6)();
        uVar9 = func_0x00018046b63c(uVar9);
        puVar12 = (undefined4 *)func_0x00018046b77c();
        *puVar12 = uVar9;
    }
    return;
}

// ============================================================
// Function: FUN_180063e30
// Address: 0x180063e30
// Size: 511 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch

void fcn.180063e30(undefined8 placeholder_0, int64_t arg2)
{
    int32_t *piVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int32_t iVar6;
    int32_t iVar7;
    undefined4 uVar8;
    undefined8 *puVar9;
    undefined4 *puVar10;
    undefined4 *puVar11;
    int64_t *piVar12;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    int64_t unaff_R15;
    bool bVar13;
    int64_t var_10h;
    int64_t var_48h;
    int64_t var_40h;
    
    iVar2 = *(int64_t *)(arg2 + 8);
    var_40h = 0;
    if (iVar2 == 0) {
code_r0x000180063e73:
        var_48h = 0;
    } else {
        iVar7 = *(int32_t *)(iVar2 + 8);
        do {
            if (iVar7 == 0) goto code_r0x000180063e73;
            LOCK();
            iVar6 = *(int32_t *)(iVar2 + 8);
            bVar13 = iVar7 == iVar6;
            if (bVar13) {
                *(int32_t *)(iVar2 + 8) = iVar7 + 1;
                iVar6 = iVar7;
            }
            UNLOCK();
            iVar7 = iVar6;
        } while (!bVar13);
        var_48h = *(int64_t *)arg2;
        var_40h = *(int64_t *)(arg2 + 8);
    }
    if ((var_48h != 0) && (iVar2 = *(int64_t *)(**(int64_t **)(var_48h + 0x18) + 0x28), iVar2 != 0)) {
        uVar8 = *(undefined4 *)(var_48h + 0x10);
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        if (((*(char *)0x180777010 != '\0') && (**(uint64_t **)(iVar2 + 0x18) < *(int64_t *)(iVar2 + 0x40) + 0x10U)) &&
           (iVar7 = fcn.180085510(unaff_R15), iVar7 == 0)) {
            fcn.180099450(iVar2, 0x18063d8d0);
            fcn.180087960(iVar2);
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        puVar9 = (undefined8 *)fcn.180085370(iVar2, 0xffffd8f0);
        puVar10 = (undefined4 *)fcn.1800a0d50(*puVar9, uVar8);
        puVar11 = *(undefined4 **)(iVar2 + 0x40);
        uVar8 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        *puVar11 = *puVar10;
        puVar11[1] = uVar8;
        puVar11[2] = uVar4;
        puVar11[3] = uVar5;
        *(int64_t *)(iVar2 + 0x40) = *(int64_t *)(iVar2 + 0x40) + 0x10;
        fcn.180086cc0(iVar2, 0xffffffff, 0x1806247fc);
        if ((*(uint8_t *)(iVar2 + 1) & 4) != 0) {
            *(uint8_t *)(iVar2 + 1) = *(uint8_t *)(iVar2 + 1) & 0xfb;
            *(undefined8 *)(iVar2 + 0x48) = *(undefined8 *)(*(int64_t *)(iVar2 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(iVar2 + 0x20) + 0x18) = iVar2;
        }
        puVar11 = *(undefined4 **)(iVar2 + 0x40);
        puVar10 = puVar11;
        while (puVar11 + -8 < puVar10) {
            *puVar10 = puVar10[-4];
            puVar10[1] = puVar10[-3];
            puVar10[2] = puVar10[-2];
            puVar10[3] = puVar10[-1];
            puVar10 = puVar10 + -4;
        }
        puVar10 = *(undefined4 **)(iVar2 + 0x40);
        uVar8 = puVar10[1];
        uVar4 = puVar10[2];
        uVar5 = puVar10[3];
        puVar11[-8] = *puVar10;
        puVar11[-7] = uVar8;
        puVar11[-6] = uVar4;
        puVar11[-5] = uVar5;
        piVar12 = (int64_t *)(arg2 + 0x10);
        if (0xf < *(uint64_t *)(arg2 + 0x28)) {
            piVar12 = (int64_t *)*piVar12;
        }
        fcn.1800867f0(iVar2, piVar12, *(undefined8 *)(arg2 + 0x20));
        func_0x0001800878a0(iVar2, 2, 0);
    }
    if ((int64_t *)var_40h != (int64_t *)0x0) {
        LOCK();
        piVar12 = (int64_t *)(var_40h + 8);
        iVar7 = *(int32_t *)piVar12;
        *(int32_t *)piVar12 = *(int32_t *)piVar12 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (***(code ***)var_40h)(var_40h);
            LOCK();
            piVar1 = (int32_t *)(var_40h + 0xc);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (**(code **)(*(int64_t *)var_40h + 8))(var_40h);
            }
        }
    }
    fcn.180004e40(arg2 + 0x10);
    piVar12 = *(int64_t **)(arg2 + 8);
    if (piVar12 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar12 + 0xc);
        iVar7 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar7 == 1) {
            (**(code **)(*piVar12 + 8))();
        }
    }
    if ((arg2 != 0) && (iVar7 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg2, in_R9, unaff_RBX), iVar7 == 0))
    {
        uVar8 = (*(code *)0x699ff6)();
        uVar8 = func_0x00018046b63c(uVar8);
        puVar11 = (undefined4 *)func_0x00018046b77c();
        *puVar11 = uVar8;
    }
    return;
}

// ============================================================
// Function: FUN_180064040
// Address: 0x180064040
// Size: 77 bytes
// ============================================================
void fcn.180064040(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    fcn.180004e40(arg1 + 0x10);
    piVar2 = *(int64_t **)(arg1 + 8);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar2 + 0xc);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*piVar2 + 8))();
        }
    }
    if ((arg1 != 0) && (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar3 == 0))
    {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = func_0x00018046b63c(uVar4);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_180064090
// Address: 0x180064090
// Size: 68 bytes
// ============================================================
void fcn.180064090(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    undefined4 uVar4;
    undefined4 *puVar5;
    undefined8 unaff_RBX;
    undefined8 in_R9;
    
    arg1 = *(int64_t *)arg1;
    if (arg1 == 0) {
        return;
    }
    piVar2 = *(int64_t **)(arg1 + 8);
    if (piVar2 != (int64_t *)0x0) {
        LOCK();
        piVar1 = (int32_t *)((int64_t)piVar2 + 0xc);
        iVar3 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*piVar2 + 8))();
        }
    }
    if ((arg1 != 0) && (iVar3 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, arg1, in_R9, unaff_RBX), iVar3 == 0))
    {
        uVar4 = (*(code *)0x699ff6)();
        uVar4 = func_0x00018046b63c(uVar4);
        puVar5 = (undefined4 *)func_0x00018046b77c();
        *puVar5 = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800640f0
// Address: 0x1800640f0
// Size: 211 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int32_t fcn.1800640f0(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t *piVar3;
    int32_t iVar4;
    int64_t *piVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    piVar1 = (int32_t *)(arg1 + 0x10);
    if ((2 < *piVar1) && (*piVar1 < 7)) {
        LOCK();
        *piVar1 = 7;
        UNLOCK();
        if (*(int64_t *)(*(int64_t *)(arg1 + 0x18) + 8) == 0) {
            (*(code *)0x699ddc)();
        } else {
            func_0x000180182b10();
        }
        func_0x0001800613a0(*(undefined8 *)(arg1 + 0x18));
    }
    func_0x000180061db0(piVar1);
    piVar5 = *(int64_t **)(arg1 + 0x30);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar5 + 1;
        iVar4 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar3 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar4 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    piVar5 = *(int64_t **)(arg1 + 0x20);
    if (piVar5 != (int64_t *)0x0) {
        LOCK();
        piVar2 = piVar5 + 1;
        iVar4 = *(int32_t *)piVar2;
        *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)*piVar5)(piVar5);
            LOCK();
            piVar3 = (int32_t *)((int64_t)piVar5 + 0xc);
            iVar4 = *piVar3;
            *piVar3 = *piVar3 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (**(code **)(*piVar5 + 8))(piVar5);
            }
        }
    }
    LOCK();
    iVar4 = *piVar1;
    *piVar1 = 9;
    UNLOCK();
    return iVar4;
}

// ============================================================
// Function: FUN_1800641d0
// Address: 0x1800641d0
// Size: 21 bytes
// ============================================================
void fcn.1800641d0(int64_t arg1)
{
    code *pcVar1;
    
    if (*(int32_t *)(arg1 + 0x18) == 0) {
        return;
    }
    fcn.18045f7d4();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_1800641f0
// Address: 0x1800641f0
// Size: 146 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 fcn.1800641f0(int64_t arg1)
{
    undefined4 uVar1;
    int64_t var_8h;
    
    if (*(int64_t *)(arg1 + 0x18) != 0) {
        if (*(int32_t *)(arg1 + 0x10) < 5) {
            if (*(char *)(arg1 + 0x20) != '\0') {
                func_0x0001801821b0(arg1 + 0x18);
            }
        } else {
            LOCK();
            *(undefined4 *)(arg1 + 0x10) = 7;
            UNLOCK();
            func_0x000180182a20(*(undefined8 *)(arg1 + 0x18));
        }
        *(undefined8 *)(arg1 + 0x18) = 0;
    }
    func_0x0001800646d0(arg1 + 0xa0, arg1 + 0xa0, *(undefined8 *)(*(int64_t *)(arg1 + 0xa0) + 8));
    func_0x000180459c3c(*(undefined8 *)(arg1 + 0xa0), 0x38);
    fcn.180063a10(arg1 + 0x78);
    LOCK();
    uVar1 = *(undefined4 *)(arg1 + 0x10);
    *(undefined4 *)(arg1 + 0x10) = 9;
    UNLOCK();
    return uVar1;
}

// ============================================================
// Function: FUN_180064290
// Address: 0x180064290
// Size: 45 bytes
// ============================================================
void fcn.180064290(int64_t arg1)
{
    int64_t *piVar1;
    
    piVar1 = *(int64_t **)(arg1 + 0x88);
    if (piVar1 != (int64_t *)0x0) {
        (**(code **)(*piVar1 + 0x20))(piVar1, piVar1 != (int64_t *)(arg1 + 0x50));
        *(undefined8 *)(arg1 + 0x88) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_180064310
// Address: 0x180064310
// Size: 318 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.180064310(int64_t arg1, int64_t arg_28h)
{
    code *pcVar1;
    char cVar2;
    int32_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    char in_DL;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    int64_t var_20h;
    undefined auStack_18 [16];
    
    var_28h = arg1 + 0x20;
    var_20h._0_1_ = '\0';
    iVar3 = func_0x000180456008(var_28h);
    if (iVar3 != 0) {
code_r0x00018006440f:
        fcn.1804542e8(5);
        pcVar1 = (code *)swi(3);
        iVar5 = (*pcVar1)();
        return iVar5;
    }
    if (*(int32_t *)(arg1 + 0x6c) == 0x7fffffff) {
        *(undefined4 *)(arg1 + 0x6c) = 0x7ffffffe;
        fcn.1804542e8(6);
    } else {
        var_20h._0_1_ = '\x01';
        if ((in_DL == '\0') || (*(char *)(arg1 + 0xb8) == '\0')) {
            cVar2 = func_0x000180459160(arg1 + 0x10);
            if (cVar2 != '\0') {
                uVar4 = func_0x0001800611a0(auStack_18, arg1 + 0x10);
                func_0x0001800611c0(uVar4);
                pcVar1 = (code *)swi(3);
                iVar5 = (*pcVar1)();
                return iVar5;
            }
            *(undefined *)(arg1 + 0xb8) = 1;
            if (*(char *)(arg1 + 0xc2) == '\0') {
                *(undefined *)(arg1 + 0xc2) = 1;
                (**(code **)(*(int64_t *)arg1 + 0x20))(arg1, &var_28h);
            }
            iVar3 = *(int32_t *)(arg1 + 0xbc);
            while (iVar3 == 0) {
                func_0x000180454ac8(arg1 + 0x70, var_28h);
                iVar3 = *(int32_t *)(arg1 + 0xbc);
            }
            cVar2 = func_0x000180459160(arg1 + 0x10);
            if (cVar2 == '\0') {
                if ((char)var_20h != '\0') {
                    func_0x000180456010(var_28h);
                }
                return arg1 + 0xc;
            }
            uVar4 = func_0x0001800611a0(auStack_18, arg1 + 0x10);
            func_0x0001800611c0(uVar4);
            goto code_r0x00018006440f;
        }
    }
    fcn.1800621d0(2);
    pcVar1 = (code *)swi(3);
    iVar5 = (*pcVar1)();
    return iVar5;
}

// ============================================================
// Function: FUN_180064450
// Address: 0x180064450
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180064450(int64_t arg1, int64_t arg_28h)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_10h;
    
    var_18h = arg1 + 0x20;
    var_10h._0_1_ = 0;
    iVar2 = func_0x000180456008(var_18h);
    if (iVar2 != 0) {
        fcn.1804542e8(5);
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    if (*(int32_t *)(arg1 + 0x6c) != 0x7fffffff) {
        var_10h._0_1_ = '\x01';
        if (*(char *)(arg1 + 0xc2) == '\0') {
            *(undefined *)(arg1 + 0xc2) = 1;
            (**(code **)(*(int64_t *)arg1 + 0x20))(arg1, &var_18h);
        }
        iVar2 = *(int32_t *)(arg1 + 0xbc);
        while (iVar2 == 0) {
            func_0x000180454ac8(arg1 + 0x70, var_18h);
            iVar2 = *(int32_t *)(arg1 + 0xbc);
        }
        if ((char)var_10h != '\0') {
            func_0x000180456010(var_18h);
        }
        return;
    }
    *(undefined4 *)(arg1 + 0x6c) = 0x7ffffffe;
    fcn.1804542e8(6);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

