// Chunk 201 - 50 functions

// ============================================================
// Function: FUN_18026c5f8
// Address: 0x18026c5f8
// Size: 101 bytes
// ============================================================
uint64_t fcn.18026c5f8(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_80h, int64_t arg_88h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined2 *puVar7;
    uint32_t *puVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    char cVar11;
    uint32_t unaff_EBX;
    uint64_t unaff_RBP;
    uint64_t unaff_RSI;
    int64_t unaff_RDI;
    char *pcVar12;
    int16_t unaff_R13W;
    char *unaff_R14;
    int16_t unaff_R15W;
    int32_t iVar13;
    bool bVar14;
    int64_t var_20h;
    
    if (unaff_RDI == 0) {
        arg_80h._0_2_ = (int16_t)arg2;
code_r0x00018026c71d:
        iVar13 = (int32_t)arg_30h;
    } else {
        unaff_R13W = func_0x00018046c694();
        if (*(char *)arg_38h == (char)unaff_RSI) {
            arg_80h._0_2_ = (*(code *)0x8000000000000009)(unaff_R13W);
            uVar4 = unaff_EBX;
            if (unaff_EBX == 0) {
                uVar4 = 1;
            }
            arg2 = 0;
            arg_30h = CONCAT44(arg_30h._4_4_, (uint32_t)(unaff_EBX == 0));
            unaff_EBX = uVar4;
            unaff_R13W = (int16_t)arg_80h;
            goto code_r0x00018026c71d;
        }
        if ((unaff_EBX & 0xfffffffd) == 0) {
            iVar5 = (*(code *)0x8000000000000037)();
            if (iVar5 != 0) {
                arg_80h._0_2_ = *(int16_t *)(iVar5 + 0x18);
                unaff_R13W = (int16_t)arg_80h;
            }
            if (unaff_EBX != 0) goto code_r0x00018026c6a2;
code_r0x00018026c6a7:
            iVar5 = (*(code *)0x8000000000000037)();
            if (iVar5 != 0) {
                unaff_R15W = *(int16_t *)(iVar5 + 0x18);
                unaff_R13W = unaff_R15W;
            }
        } else {
code_r0x00018026c6a2:
            if (unaff_EBX == 1) goto code_r0x00018026c6a7;
        }
        if (unaff_R13W == 0) {
            unaff_RSI = 0x2af9;
            if (unaff_EBX != 0) {
                unaff_RSI = 0x277d;
            }
            goto code_r0x00018026c7c8;
        }
        if (unaff_EBX != 0) {
            arg2 = 0;
            goto code_r0x00018026c71d;
        }
        unaff_EBX = 2 - (unaff_R15W != 0);
        if ((unaff_R15W == 0) || ((int16_t)arg_80h == 0)) {
            arg2 = 0;
            iVar13 = 0;
        } else {
            arg2 = 0;
            iVar13 = 1;
        }
    }
    arg_30h._4_4_ = (undefined4)((uint64_t)arg_30h >> 0x20);
    if (unaff_R14 == (char *)0x0) {
        uVar10 = 0x7f000001;
        if ((unaff_RBP & 1) != 0) {
            uVar10 = arg2 & 0xffffffff;
        }
        iVar3 = (*(code *)0x8000000000000008)(uVar10);
code_r0x00018026c8ca:
        puVar8 = (uint32_t *)func_0x00018026cfe0(unaff_EBX, arg_30h._4_4_, unaff_R13W, iVar3);
        *(uint32_t **)arg_98h = puVar8;
        if (puVar8 == (uint32_t *)0x0) {
            unaff_RSI = 8;
        } else {
            if ((unaff_R14 != (char *)0x0) && (*puVar8 = *puVar8 | 4, (unaff_RBP & 2) != 0)) {
                iVar5 = *(int64_t *)arg_98h;
                uVar9 = (*(code *)0x800000000000000c)(iVar3);
                uVar9 = func_0x00018026d090(uVar9);
                *(undefined8 *)(iVar5 + 0x18) = uVar9;
                if (*(uint64_t *)(*(int64_t *)arg_98h + 0x18) == unaff_RSI) {
                    unaff_RSI = 8;
                    goto code_r0x00018026c784;
                }
            }
code_r0x00018026c81a:
            if (iVar13 == 0) goto code_r0x00018026c7c8;
            iVar5 = *(int64_t *)arg_98h;
            while (iVar5 != 0) {
                uVar1 = *(undefined4 *)(iVar5 + 0xc);
                uVar2 = *(undefined4 *)(*(int64_t *)(iVar5 + 0x20) + 4);
                iVar6 = func_0x000180461640(1, 0x30);
                if (iVar6 == 0) break;
                puVar7 = (undefined2 *)func_0x000180461640(1, 0x10);
                if (puVar7 == (undefined2 *)0x0) {
                    func_0x000180460d90(iVar6);
                    break;
                }
                *puVar7 = 2;
                puVar7[1] = (int16_t)arg_80h;
                *(undefined4 *)(puVar7 + 2) = uVar2;
                *(undefined4 *)(iVar6 + 4) = 2;
                *(undefined4 *)(iVar6 + 8) = 2;
                *(undefined4 *)(iVar6 + 0xc) = uVar1;
                *(undefined8 *)(iVar6 + 0x10) = 0x10;
                *(undefined2 **)(iVar6 + 0x20) = puVar7;
                *(undefined8 *)(iVar6 + 0x28) = *(undefined8 *)(iVar5 + 0x28);
                *(int64_t *)(iVar5 + 0x28) = iVar6;
                iVar5 = *(int64_t *)(iVar6 + 0x28);
            }
            unaff_RSI = (uint64_t)(-(uint32_t)(iVar5 != 0) & 8);
            if (iVar5 == 0) goto code_r0x00018026c7c8;
        }
    } else {
        uVar10 = arg2 & 0xffffffff;
        cVar11 = *unaff_R14;
        pcVar12 = unaff_R14;
        if (cVar11 != '\0') {
            do {
                bVar14 = cVar11 != '.';
                cVar11 = pcVar12[1];
                uVar4 = (uint32_t)uVar10 + 1;
                if (bVar14) {
                    uVar4 = (uint32_t)uVar10;
                }
                uVar10 = (uint64_t)uVar4;
                pcVar12 = pcVar12 + 1;
            } while (cVar11 != '\0');
            if ((uVar4 == 3) && (iVar3 = (*(code *)0x800000000000000b)(), iVar3 != -1)) goto code_r0x00018026c8ca;
        }
        if ((unaff_RBP & 4) == 0) {
            uVar4 = func_0x00018026cda0();
            unaff_RSI = (uint64_t)uVar4;
            if (uVar4 == 0) goto code_r0x00018026c81a;
        } else {
            unaff_RSI = 0x2af9;
        }
    }
code_r0x00018026c784:
    iVar5 = *(int64_t *)arg_98h;
    while (iVar5 != 0) {
        if (*(int64_t *)(iVar5 + 0x18) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar5 + 0x20) != 0) {
            func_0x000180460d90();
        }
        iVar6 = *(int64_t *)(iVar5 + 0x28);
        func_0x000180460d90(iVar5);
        iVar5 = iVar6;
    }
    *(undefined8 *)arg_98h = 0;
code_r0x00018026c7c8:
    return unaff_RSI & 0xffffffff;
}

// ============================================================
// Function: FUN_18026c65d
// Address: 0x18026c65d
// Size: 20 bytes
// ============================================================
undefined8 fcn.18026c65d(void)
{
    return 0x2afb;
}

// ============================================================
// Function: FUN_18026c671
// Address: 0x18026c671
// Size: 368 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

uint64_t fcn.18026c5f8(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_80h, int64_t arg_88h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined2 *puVar7;
    uint32_t *puVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    char cVar11;
    uint32_t unaff_EBX;
    uint64_t unaff_RBP;
    uint64_t unaff_RSI;
    int64_t unaff_RDI;
    char *pcVar12;
    int16_t unaff_R13W;
    char *unaff_R14;
    int16_t unaff_R15W;
    int32_t iVar13;
    bool bVar14;
    int64_t var_20h;
    
    if (unaff_RDI == 0) {
        arg_80h._0_2_ = (int16_t)arg2;
code_r0x00018026c71d:
        iVar13 = (int32_t)arg_30h;
    } else {
        unaff_R13W = func_0x00018046c694();
        if (*(char *)arg_38h == (char)unaff_RSI) {
            arg_80h._0_2_ = (*(code *)0x8000000000000009)(unaff_R13W);
            uVar4 = unaff_EBX;
            if (unaff_EBX == 0) {
                uVar4 = 1;
            }
            arg2 = 0;
            arg_30h = CONCAT44(arg_30h._4_4_, (uint32_t)(unaff_EBX == 0));
            unaff_EBX = uVar4;
            unaff_R13W = (int16_t)arg_80h;
            goto code_r0x00018026c71d;
        }
        if ((unaff_EBX & 0xfffffffd) == 0) {
            iVar5 = (*(code *)0x8000000000000037)();
            if (iVar5 != 0) {
                arg_80h._0_2_ = *(int16_t *)(iVar5 + 0x18);
                unaff_R13W = (int16_t)arg_80h;
            }
            if (unaff_EBX != 0) goto code_r0x00018026c6a2;
code_r0x00018026c6a7:
            iVar5 = (*(code *)0x8000000000000037)();
            if (iVar5 != 0) {
                unaff_R15W = *(int16_t *)(iVar5 + 0x18);
                unaff_R13W = unaff_R15W;
            }
        } else {
code_r0x00018026c6a2:
            if (unaff_EBX == 1) goto code_r0x00018026c6a7;
        }
        if (unaff_R13W == 0) {
            unaff_RSI = 0x2af9;
            if (unaff_EBX != 0) {
                unaff_RSI = 0x277d;
            }
            goto code_r0x00018026c7c8;
        }
        if (unaff_EBX != 0) {
            arg2 = 0;
            goto code_r0x00018026c71d;
        }
        unaff_EBX = 2 - (unaff_R15W != 0);
        if ((unaff_R15W == 0) || ((int16_t)arg_80h == 0)) {
            arg2 = 0;
            iVar13 = 0;
        } else {
            arg2 = 0;
            iVar13 = 1;
        }
    }
    arg_30h._4_4_ = (undefined4)((uint64_t)arg_30h >> 0x20);
    if (unaff_R14 == (char *)0x0) {
        uVar10 = 0x7f000001;
        if ((unaff_RBP & 1) != 0) {
            uVar10 = arg2 & 0xffffffff;
        }
        iVar3 = (*(code *)0x8000000000000008)(uVar10);
code_r0x00018026c8ca:
        puVar8 = (uint32_t *)func_0x00018026cfe0(unaff_EBX, arg_30h._4_4_, unaff_R13W, iVar3);
        *(uint32_t **)arg_98h = puVar8;
        if (puVar8 == (uint32_t *)0x0) {
            unaff_RSI = 8;
        } else {
            if ((unaff_R14 != (char *)0x0) && (*puVar8 = *puVar8 | 4, (unaff_RBP & 2) != 0)) {
                iVar5 = *(int64_t *)arg_98h;
                uVar9 = (*(code *)0x800000000000000c)(iVar3);
                uVar9 = func_0x00018026d090(uVar9);
                *(undefined8 *)(iVar5 + 0x18) = uVar9;
                if (*(uint64_t *)(*(int64_t *)arg_98h + 0x18) == unaff_RSI) {
                    unaff_RSI = 8;
                    goto code_r0x00018026c784;
                }
            }
code_r0x00018026c81a:
            if (iVar13 == 0) goto code_r0x00018026c7c8;
            iVar5 = *(int64_t *)arg_98h;
            while (iVar5 != 0) {
                uVar1 = *(undefined4 *)(iVar5 + 0xc);
                uVar2 = *(undefined4 *)(*(int64_t *)(iVar5 + 0x20) + 4);
                iVar6 = func_0x000180461640(1, 0x30);
                if (iVar6 == 0) break;
                puVar7 = (undefined2 *)func_0x000180461640(1, 0x10);
                if (puVar7 == (undefined2 *)0x0) {
                    func_0x000180460d90(iVar6);
                    break;
                }
                *puVar7 = 2;
                puVar7[1] = (int16_t)arg_80h;
                *(undefined4 *)(puVar7 + 2) = uVar2;
                *(undefined4 *)(iVar6 + 4) = 2;
                *(undefined4 *)(iVar6 + 8) = 2;
                *(undefined4 *)(iVar6 + 0xc) = uVar1;
                *(undefined8 *)(iVar6 + 0x10) = 0x10;
                *(undefined2 **)(iVar6 + 0x20) = puVar7;
                *(undefined8 *)(iVar6 + 0x28) = *(undefined8 *)(iVar5 + 0x28);
                *(int64_t *)(iVar5 + 0x28) = iVar6;
                iVar5 = *(int64_t *)(iVar6 + 0x28);
            }
            unaff_RSI = (uint64_t)(-(uint32_t)(iVar5 != 0) & 8);
            if (iVar5 == 0) goto code_r0x00018026c7c8;
        }
    } else {
        uVar10 = arg2 & 0xffffffff;
        cVar11 = *unaff_R14;
        pcVar12 = unaff_R14;
        if (cVar11 != '\0') {
            do {
                bVar14 = cVar11 != '.';
                cVar11 = pcVar12[1];
                uVar4 = (uint32_t)uVar10 + 1;
                if (bVar14) {
                    uVar4 = (uint32_t)uVar10;
                }
                uVar10 = (uint64_t)uVar4;
                pcVar12 = pcVar12 + 1;
            } while (cVar11 != '\0');
            if ((uVar4 == 3) && (iVar3 = (*(code *)0x800000000000000b)(), iVar3 != -1)) goto code_r0x00018026c8ca;
        }
        if ((unaff_RBP & 4) == 0) {
            uVar4 = func_0x00018026cda0();
            unaff_RSI = (uint64_t)uVar4;
            if (uVar4 == 0) goto code_r0x00018026c81a;
        } else {
            unaff_RSI = 0x2af9;
        }
    }
code_r0x00018026c784:
    iVar5 = *(int64_t *)arg_98h;
    while (iVar5 != 0) {
        if (*(int64_t *)(iVar5 + 0x18) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar5 + 0x20) != 0) {
            func_0x000180460d90();
        }
        iVar6 = *(int64_t *)(iVar5 + 0x28);
        func_0x000180460d90(iVar5);
        iVar5 = iVar6;
    }
    *(undefined8 *)arg_98h = 0;
code_r0x00018026c7c8:
    return unaff_RSI & 0xffffffff;
}

// ============================================================
// Function: FUN_18026c7e1
// Address: 0x18026c7e1
// Size: 381 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: arg_88h
// WARNING: [rz-ghidra] Detected overlap for variable arg_34h

uint64_t fcn.18026c5f8(undefined8 placeholder_0, int64_t arg2, undefined8 placeholder_2, undefined8 placeholder_3,
                      int64_t arg_28h, int64_t arg_30h, int64_t arg_80h, int64_t arg_88h, int64_t arg_98h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    int32_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    undefined2 *puVar7;
    uint32_t *puVar8;
    undefined8 uVar9;
    uint64_t uVar10;
    char cVar11;
    uint32_t unaff_EBX;
    uint64_t unaff_RBP;
    uint64_t unaff_RSI;
    int64_t unaff_RDI;
    char *pcVar12;
    int16_t unaff_R13W;
    char *unaff_R14;
    int16_t unaff_R15W;
    int32_t iVar13;
    bool bVar14;
    int64_t var_20h;
    
    if (unaff_RDI == 0) {
        arg_80h._0_2_ = (int16_t)arg2;
code_r0x00018026c71d:
        iVar13 = (int32_t)arg_30h;
    } else {
        unaff_R13W = func_0x00018046c694();
        if (*(char *)arg_38h == (char)unaff_RSI) {
            arg_80h._0_2_ = (*(code *)0x8000000000000009)(unaff_R13W);
            uVar4 = unaff_EBX;
            if (unaff_EBX == 0) {
                uVar4 = 1;
            }
            arg2 = 0;
            arg_30h = CONCAT44(arg_30h._4_4_, (uint32_t)(unaff_EBX == 0));
            unaff_EBX = uVar4;
            unaff_R13W = (int16_t)arg_80h;
            goto code_r0x00018026c71d;
        }
        if ((unaff_EBX & 0xfffffffd) == 0) {
            iVar5 = (*(code *)0x8000000000000037)();
            if (iVar5 != 0) {
                arg_80h._0_2_ = *(int16_t *)(iVar5 + 0x18);
                unaff_R13W = (int16_t)arg_80h;
            }
            if (unaff_EBX != 0) goto code_r0x00018026c6a2;
code_r0x00018026c6a7:
            iVar5 = (*(code *)0x8000000000000037)();
            if (iVar5 != 0) {
                unaff_R15W = *(int16_t *)(iVar5 + 0x18);
                unaff_R13W = unaff_R15W;
            }
        } else {
code_r0x00018026c6a2:
            if (unaff_EBX == 1) goto code_r0x00018026c6a7;
        }
        if (unaff_R13W == 0) {
            unaff_RSI = 0x2af9;
            if (unaff_EBX != 0) {
                unaff_RSI = 0x277d;
            }
            goto code_r0x00018026c7c8;
        }
        if (unaff_EBX != 0) {
            arg2 = 0;
            goto code_r0x00018026c71d;
        }
        unaff_EBX = 2 - (unaff_R15W != 0);
        if ((unaff_R15W == 0) || ((int16_t)arg_80h == 0)) {
            arg2 = 0;
            iVar13 = 0;
        } else {
            arg2 = 0;
            iVar13 = 1;
        }
    }
    arg_30h._4_4_ = (undefined4)((uint64_t)arg_30h >> 0x20);
    if (unaff_R14 == (char *)0x0) {
        uVar10 = 0x7f000001;
        if ((unaff_RBP & 1) != 0) {
            uVar10 = arg2 & 0xffffffff;
        }
        iVar3 = (*(code *)0x8000000000000008)(uVar10);
code_r0x00018026c8ca:
        puVar8 = (uint32_t *)func_0x00018026cfe0(unaff_EBX, arg_30h._4_4_, unaff_R13W, iVar3);
        *(uint32_t **)arg_98h = puVar8;
        if (puVar8 == (uint32_t *)0x0) {
            unaff_RSI = 8;
        } else {
            if ((unaff_R14 != (char *)0x0) && (*puVar8 = *puVar8 | 4, (unaff_RBP & 2) != 0)) {
                iVar5 = *(int64_t *)arg_98h;
                uVar9 = (*(code *)0x800000000000000c)(iVar3);
                uVar9 = func_0x00018026d090(uVar9);
                *(undefined8 *)(iVar5 + 0x18) = uVar9;
                if (*(uint64_t *)(*(int64_t *)arg_98h + 0x18) == unaff_RSI) {
                    unaff_RSI = 8;
                    goto code_r0x00018026c784;
                }
            }
code_r0x00018026c81a:
            if (iVar13 == 0) goto code_r0x00018026c7c8;
            iVar5 = *(int64_t *)arg_98h;
            while (iVar5 != 0) {
                uVar1 = *(undefined4 *)(iVar5 + 0xc);
                uVar2 = *(undefined4 *)(*(int64_t *)(iVar5 + 0x20) + 4);
                iVar6 = func_0x000180461640(1, 0x30);
                if (iVar6 == 0) break;
                puVar7 = (undefined2 *)func_0x000180461640(1, 0x10);
                if (puVar7 == (undefined2 *)0x0) {
                    func_0x000180460d90(iVar6);
                    break;
                }
                *puVar7 = 2;
                puVar7[1] = (int16_t)arg_80h;
                *(undefined4 *)(puVar7 + 2) = uVar2;
                *(undefined4 *)(iVar6 + 4) = 2;
                *(undefined4 *)(iVar6 + 8) = 2;
                *(undefined4 *)(iVar6 + 0xc) = uVar1;
                *(undefined8 *)(iVar6 + 0x10) = 0x10;
                *(undefined2 **)(iVar6 + 0x20) = puVar7;
                *(undefined8 *)(iVar6 + 0x28) = *(undefined8 *)(iVar5 + 0x28);
                *(int64_t *)(iVar5 + 0x28) = iVar6;
                iVar5 = *(int64_t *)(iVar6 + 0x28);
            }
            unaff_RSI = (uint64_t)(-(uint32_t)(iVar5 != 0) & 8);
            if (iVar5 == 0) goto code_r0x00018026c7c8;
        }
    } else {
        uVar10 = arg2 & 0xffffffff;
        cVar11 = *unaff_R14;
        pcVar12 = unaff_R14;
        if (cVar11 != '\0') {
            do {
                bVar14 = cVar11 != '.';
                cVar11 = pcVar12[1];
                uVar4 = (uint32_t)uVar10 + 1;
                if (bVar14) {
                    uVar4 = (uint32_t)uVar10;
                }
                uVar10 = (uint64_t)uVar4;
                pcVar12 = pcVar12 + 1;
            } while (cVar11 != '\0');
            if ((uVar4 == 3) && (iVar3 = (*(code *)0x800000000000000b)(), iVar3 != -1)) goto code_r0x00018026c8ca;
        }
        if ((unaff_RBP & 4) == 0) {
            uVar4 = func_0x00018026cda0();
            unaff_RSI = (uint64_t)uVar4;
            if (uVar4 == 0) goto code_r0x00018026c81a;
        } else {
            unaff_RSI = 0x2af9;
        }
    }
code_r0x00018026c784:
    iVar5 = *(int64_t *)arg_98h;
    while (iVar5 != 0) {
        if (*(int64_t *)(iVar5 + 0x18) != 0) {
            func_0x000180460d90();
        }
        if (*(int64_t *)(iVar5 + 0x20) != 0) {
            func_0x000180460d90();
        }
        iVar6 = *(int64_t *)(iVar5 + 0x28);
        func_0x000180460d90(iVar5);
        iVar5 = iVar6;
    }
    *(undefined8 *)arg_98h = 0;
code_r0x00018026c7c8:
    return unaff_RSI & 0xffffffff;
}

// ============================================================
// Function: FUN_18026c960
// Address: 0x18026c960
// Size: 557 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.18026c960(int64_t arg_50h, int64_t arg_68h, int64_t arg_70h, int64_t arg_78h)
{
    int16_t iVar1;
    uint32_t uVar2;
    undefined4 uVar3;
    undefined2 uVar4;
    int64_t iVar5;
    int64_t *piVar6;
    uint64_t uVar7;
    undefined *puVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int16_t *in_RCX;
    int32_t in_EDX;
    undefined8 uVar11;
    int64_t in_R8;
    uint64_t in_R9;
    int64_t iVar12;
    int64_t var_10h;
    undefined8 uStack_40;
    undefined4 var_18h;
    int64_t var_14h;
    int64_t var_8h;
    
    uStack_40 = 0x18026c97a;
    iVar5 = func_0x00018045a350();
    iVar5 = -iVar5;
    *(uint64_t *)((int64_t)&var_8h + iVar5) = *(uint64_t *)0x1806a3940 ^ (int64_t)&var_18h + iVar5 + -0x20;
    iVar9 = *(int64_t *)((int64_t)&arg_68h + iVar5);
    *(undefined4 *)((int64_t)&var_14h + iVar5) = 0x33353536;
    *(undefined2 *)((int64_t)&var_14h + iVar5 + 4) = 0x35;
    if ((((in_RCX == (int16_t *)0x0) || (in_EDX < 0x10)) || (*in_RCX != 2)) ||
       (((uVar10 = *(uint64_t *)((int64_t)&arg_70h + iVar5), in_R8 == 0 || (in_R9 == 0)) &&
        ((iVar9 == 0 || (uVar10 == 0)))))) goto code_r0x00018026cb68;
    uVar2 = *(uint32_t *)((int64_t)&arg_78h + iVar5);
    if (((uVar2 & 2) != 0) && ((uVar2 & 4) != 0)) goto code_r0x00018026cb68;
    if ((iVar9 != 0) && (uVar10 != 0)) {
        iVar1 = in_RCX[1];
        if ((uVar2 & 8) == 0) {
            uVar11 = 0;
            if ((uVar2 & 0x10) != 0) {
                uVar11 = 0x1804e7510;
            }
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026ca51;
            piVar6 = (int64_t *)(*(code *)0x8000000000000038)(iVar1, uVar11);
            if ((piVar6 == (int64_t *)0x0) || (iVar12 = *piVar6, iVar12 == 0)) goto code_r0x00018026ca63;
        } else {
code_r0x00018026ca63:
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026ca6d;
            uVar4 = (*(code *)0x800000000000000f)(iVar1);
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026ca87;
            func_0x0001800102d0((int64_t)&var_14h + iVar5, 6, 0x180645ac4, uVar4);
            iVar12 = (int64_t)&var_14h + iVar5;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026ca94;
        uVar7 = func_0x000180498cd0(iVar12);
        if (uVar10 <= uVar7) goto code_r0x00018026cb68;
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026caab;
        func_0x000180467b20(iVar9, uVar10, iVar12);
    }
    if ((in_R8 == 0) || (in_R9 == 0)) goto code_r0x00018026cb68;
    uVar3 = *(undefined4 *)(in_RCX + 2);
    *(undefined4 *)((int64_t)&var_18h + iVar5) = uVar3;
    if ((uVar2 & 2) == 0) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026cadf;
        piVar6 = (int64_t *)(*(code *)0x8000000000000033)((int64_t)&var_18h + iVar5, 4, 2);
        if ((piVar6 == (int64_t *)0x0) || (iVar9 = *piVar6, iVar9 == 0)) {
            if ((uVar2 & 4) != 0) {
                *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026cb15;
                (*(code *)0x800000000000006f)();
                goto code_r0x00018026cb68;
            }
            uVar3 = *(undefined4 *)((int64_t)&var_18h + iVar5);
            goto code_r0x00018026cb3b;
        }
        if ((uVar2 & 1) != 0) {
            *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026caff;
            puVar8 = (undefined *)func_0x00018045b928(iVar9, 0x2e);
            if (puVar8 != (undefined *)0x0) {
                *puVar8 = 0;
            }
        }
    } else {
code_r0x00018026cb3b:
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026cb41;
        iVar9 = (*(code *)0x800000000000000c)(uVar3);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026cb4c;
    uVar10 = func_0x000180498cd0(iVar9);
    if (uVar10 < in_R9) {
        *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026cb5f;
        func_0x000180467b20(in_R8, in_R9, iVar9);
    }
code_r0x00018026cb68:
    *(undefined8 *)((int64_t)&uStack_40 + iVar5) = 0x18026cb75;
    func_0x000180459870(*(uint64_t *)((int64_t)&var_8h + iVar5) ^ (int64_t)&var_18h + iVar5 + -0x20);
    return;
}

// ============================================================
// Function: FUN_18026cb90
// Address: 0x18026cb90
// Size: 160 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.18026cb90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h
                  )
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026cba0;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000268 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x18026c4f0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0x1804e7530;
    *(code **)((int64_t)&arg_30h + iVar2) = fcn.18026c960;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804e7540;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0x18026c490;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804e7520;
    if (*(int32_t *)0x18077e778 != 0) goto code_r0x00018026cd69;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc20;
    iVar1 = (*(code *)0x69a1cc)((int64_t)&arg_158h + iVar2, 0x104);
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000288 + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc47;
        func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc5d;
        func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7550);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc68;
        iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
        if (iVar3 == 0) {
code_r0x00018026cc8a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cca1;
            func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccb7;
            func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7558);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccc2;
            iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccda;
                iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
                if (iVar4 != 0) goto code_r0x00018026ccea;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cce8;
                (*(code *)0x699e34)(iVar3);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc7c;
            iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc8a;
                (*(code *)0x699e34)(iVar3);
                goto code_r0x00018026cc8a;
            }
code_r0x00018026ccea:
            *(undefined8 *)(&stack0x00000290 + iVar2) = unaff_RDI;
            piVar5 = (int64_t *)((int64_t)&var_20h + iVar2);
            iVar1 = 0;
            do {
                iVar4 = piVar5[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd0d;
                iVar4 = (*(code *)0x699eee)(iVar3, iVar4);
                *piVar5 = iVar4;
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd4f;
                    (*(code *)0x699e34)(iVar3);
                    goto code_r0x00018026cd5f;
                }
                iVar1 = iVar1 + 1;
                piVar5 = piVar5 + 2;
            } while (iVar1 < 3);
            *(undefined8 *)0x1806a04f0 = *(undefined8 *)((int64_t)&var_20h + iVar2);
            *(undefined8 *)0x1806a0500 = *(undefined8 *)((int64_t)&arg_30h + iVar2);
            *(undefined8 *)0x1806a0510 = *(undefined8 *)((int64_t)&arg_40h + iVar2);
        }
    }
code_r0x00018026cd5f:
    *(int32_t *)0x18077e778 = 1;
code_r0x00018026cd69:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd8b;
    func_0x000180459870(*(uint64_t *)(&stack0x00000268 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026cc30
// Address: 0x18026cc30
// Size: 186 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.18026cb90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h
                  )
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026cba0;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000268 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x18026c4f0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0x1804e7530;
    *(code **)((int64_t)&arg_30h + iVar2) = fcn.18026c960;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804e7540;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0x18026c490;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804e7520;
    if (*(int32_t *)0x18077e778 != 0) goto code_r0x00018026cd69;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc20;
    iVar1 = (*(code *)0x69a1cc)((int64_t)&arg_158h + iVar2, 0x104);
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000288 + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc47;
        func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc5d;
        func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7550);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc68;
        iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
        if (iVar3 == 0) {
code_r0x00018026cc8a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cca1;
            func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccb7;
            func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7558);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccc2;
            iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccda;
                iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
                if (iVar4 != 0) goto code_r0x00018026ccea;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cce8;
                (*(code *)0x699e34)(iVar3);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc7c;
            iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc8a;
                (*(code *)0x699e34)(iVar3);
                goto code_r0x00018026cc8a;
            }
code_r0x00018026ccea:
            *(undefined8 *)(&stack0x00000290 + iVar2) = unaff_RDI;
            piVar5 = (int64_t *)((int64_t)&var_20h + iVar2);
            iVar1 = 0;
            do {
                iVar4 = piVar5[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd0d;
                iVar4 = (*(code *)0x699eee)(iVar3, iVar4);
                *piVar5 = iVar4;
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd4f;
                    (*(code *)0x699e34)(iVar3);
                    goto code_r0x00018026cd5f;
                }
                iVar1 = iVar1 + 1;
                piVar5 = piVar5 + 2;
            } while (iVar1 < 3);
            *(undefined8 *)0x1806a04f0 = *(undefined8 *)((int64_t)&var_20h + iVar2);
            *(undefined8 *)0x1806a0500 = *(undefined8 *)((int64_t)&arg_30h + iVar2);
            *(undefined8 *)0x1806a0510 = *(undefined8 *)((int64_t)&arg_40h + iVar2);
        }
    }
code_r0x00018026cd5f:
    *(int32_t *)0x18077e778 = 1;
code_r0x00018026cd69:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd8b;
    func_0x000180459870(*(uint64_t *)(&stack0x00000268 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026ccea
// Address: 0x18026ccea
// Size: 109 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.18026cb90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h
                  )
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026cba0;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000268 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x18026c4f0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0x1804e7530;
    *(code **)((int64_t)&arg_30h + iVar2) = fcn.18026c960;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804e7540;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0x18026c490;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804e7520;
    if (*(int32_t *)0x18077e778 != 0) goto code_r0x00018026cd69;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc20;
    iVar1 = (*(code *)0x69a1cc)((int64_t)&arg_158h + iVar2, 0x104);
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000288 + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc47;
        func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc5d;
        func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7550);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc68;
        iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
        if (iVar3 == 0) {
code_r0x00018026cc8a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cca1;
            func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccb7;
            func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7558);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccc2;
            iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccda;
                iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
                if (iVar4 != 0) goto code_r0x00018026ccea;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cce8;
                (*(code *)0x699e34)(iVar3);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc7c;
            iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc8a;
                (*(code *)0x699e34)(iVar3);
                goto code_r0x00018026cc8a;
            }
code_r0x00018026ccea:
            *(undefined8 *)(&stack0x00000290 + iVar2) = unaff_RDI;
            piVar5 = (int64_t *)((int64_t)&var_20h + iVar2);
            iVar1 = 0;
            do {
                iVar4 = piVar5[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd0d;
                iVar4 = (*(code *)0x699eee)(iVar3, iVar4);
                *piVar5 = iVar4;
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd4f;
                    (*(code *)0x699e34)(iVar3);
                    goto code_r0x00018026cd5f;
                }
                iVar1 = iVar1 + 1;
                piVar5 = piVar5 + 2;
            } while (iVar1 < 3);
            *(undefined8 *)0x1806a04f0 = *(undefined8 *)((int64_t)&var_20h + iVar2);
            *(undefined8 *)0x1806a0500 = *(undefined8 *)((int64_t)&arg_30h + iVar2);
            *(undefined8 *)0x1806a0510 = *(undefined8 *)((int64_t)&arg_40h + iVar2);
        }
    }
code_r0x00018026cd5f:
    *(int32_t *)0x18077e778 = 1;
code_r0x00018026cd69:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd8b;
    func_0x000180459870(*(uint64_t *)(&stack0x00000268 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026cd57
// Address: 0x18026cd57
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.18026cb90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h
                  )
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026cba0;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000268 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x18026c4f0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0x1804e7530;
    *(code **)((int64_t)&arg_30h + iVar2) = fcn.18026c960;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804e7540;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0x18026c490;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804e7520;
    if (*(int32_t *)0x18077e778 != 0) goto code_r0x00018026cd69;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc20;
    iVar1 = (*(code *)0x69a1cc)((int64_t)&arg_158h + iVar2, 0x104);
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000288 + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc47;
        func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc5d;
        func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7550);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc68;
        iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
        if (iVar3 == 0) {
code_r0x00018026cc8a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cca1;
            func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccb7;
            func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7558);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccc2;
            iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccda;
                iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
                if (iVar4 != 0) goto code_r0x00018026ccea;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cce8;
                (*(code *)0x699e34)(iVar3);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc7c;
            iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc8a;
                (*(code *)0x699e34)(iVar3);
                goto code_r0x00018026cc8a;
            }
code_r0x00018026ccea:
            *(undefined8 *)(&stack0x00000290 + iVar2) = unaff_RDI;
            piVar5 = (int64_t *)((int64_t)&var_20h + iVar2);
            iVar1 = 0;
            do {
                iVar4 = piVar5[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd0d;
                iVar4 = (*(code *)0x699eee)(iVar3, iVar4);
                *piVar5 = iVar4;
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd4f;
                    (*(code *)0x699e34)(iVar3);
                    goto code_r0x00018026cd5f;
                }
                iVar1 = iVar1 + 1;
                piVar5 = piVar5 + 2;
            } while (iVar1 < 3);
            *(undefined8 *)0x1806a04f0 = *(undefined8 *)((int64_t)&var_20h + iVar2);
            *(undefined8 *)0x1806a0500 = *(undefined8 *)((int64_t)&arg_30h + iVar2);
            *(undefined8 *)0x1806a0510 = *(undefined8 *)((int64_t)&arg_40h + iVar2);
        }
    }
code_r0x00018026cd5f:
    *(int32_t *)0x18077e778 = 1;
code_r0x00018026cd69:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd8b;
    func_0x000180459870(*(uint64_t *)(&stack0x00000268 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026cd5f
// Address: 0x18026cd5f
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_18h

void fcn.18026cb90(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_158h
                  )
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026cba0;
    iVar2 = func_0x00018045a350();
    iVar2 = -iVar2;
    *(uint64_t *)(&stack0x00000268 + iVar2) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2);
    *(undefined8 *)((int64_t)&var_20h + iVar2) = 0x18026c4f0;
    *(undefined8 *)((int64_t)&arg_28h + iVar2) = 0x1804e7530;
    *(code **)((int64_t)&arg_30h + iVar2) = fcn.18026c960;
    *(undefined8 *)((int64_t)&arg_38h + iVar2) = 0x1804e7540;
    *(undefined8 *)((int64_t)&arg_40h + iVar2) = 0x18026c490;
    *(undefined8 *)((int64_t)&var_18h + iVar2) = 0x1804e7520;
    if (*(int32_t *)0x18077e778 != 0) goto code_r0x00018026cd69;
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc20;
    iVar1 = (*(code *)0x69a1cc)((int64_t)&arg_158h + iVar2, 0x104);
    if (iVar1 != 0) {
        *(undefined8 *)(&stack0x00000288 + iVar2) = unaff_RSI;
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc47;
        func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc5d;
        func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7550);
        *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc68;
        iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
        if (iVar3 == 0) {
code_r0x00018026cc8a:
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cca1;
            func_0x000180467b20((int64_t)&arg_48h + iVar2, 0x10c, (int64_t)&arg_158h + iVar2);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccb7;
            func_0x000180473f20((int64_t)&arg_48h + iVar2, 0x10c, 0x1804e7558);
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccc2;
            iVar3 = (*(code *)0x699e24)((int64_t)&arg_48h + iVar2);
            if (iVar3 != 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026ccda;
                iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
                if (iVar4 != 0) goto code_r0x00018026ccea;
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cce8;
                (*(code *)0x699e34)(iVar3);
            }
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc7c;
            iVar4 = (*(code *)0x699eee)(iVar3, 0x1804e7520);
            if (iVar4 == 0) {
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cc8a;
                (*(code *)0x699e34)(iVar3);
                goto code_r0x00018026cc8a;
            }
code_r0x00018026ccea:
            *(undefined8 *)(&stack0x00000290 + iVar2) = unaff_RDI;
            piVar5 = (int64_t *)((int64_t)&var_20h + iVar2);
            iVar1 = 0;
            do {
                iVar4 = piVar5[-1];
                *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd0d;
                iVar4 = (*(code *)0x699eee)(iVar3, iVar4);
                *piVar5 = iVar4;
                if (iVar4 == 0) {
                    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd4f;
                    (*(code *)0x699e34)(iVar3);
                    goto code_r0x00018026cd5f;
                }
                iVar1 = iVar1 + 1;
                piVar5 = piVar5 + 2;
            } while (iVar1 < 3);
            *(undefined8 *)0x1806a04f0 = *(undefined8 *)((int64_t)&var_20h + iVar2);
            *(undefined8 *)0x1806a0500 = *(undefined8 *)((int64_t)&arg_30h + iVar2);
            *(undefined8 *)0x1806a0510 = *(undefined8 *)((int64_t)&arg_40h + iVar2);
        }
    }
code_r0x00018026cd5f:
    *(int32_t *)0x18077e778 = 1;
code_r0x00018026cd69:
    *(undefined8 *)((int64_t)&uStack_10 + iVar2) = 0x18026cd8b;
    func_0x000180459870(*(uint64_t *)(&stack0x00000268 + iVar2) ^ (uint64_t)(&stack0xfffffffffffffff8 + iVar2));
    return;
}

// ============================================================
// Function: FUN_18026cda0
// Address: 0x18026cda0
// Size: 562 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_838h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_8a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Variable var_4h extends beyond the stackframe. Try changing its type to something smaller.
// WARNING: [rz-ghidra] Detected overlap for variable var_19h
// WARNING: [rz-ghidra] Removing arg arg_428h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_429h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_848h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_898h because it doesn't fit into ProtoModel

void fcn.18026cda0(undefined8 param_1, undefined4 param_2, undefined4 param_3, undefined2 param_4)
{
    int64_t *piVar1;
    undefined4 uVar2;
    int64_t *piVar3;
    undefined4 *puVar4;
    undefined8 uVar5;
    undefined *puVar6;
    int32_t iVar7;
    int64_t iVar8;
    undefined8 *puVar9;
    int64_t iVar10;
    uint64_t uVar11;
    undefined8 *puVar12;
    uint64_t uVar13;
    uint32_t uVar14;
    undefined *puVar15;
    undefined *puVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_30;
    
    uStack_30 = 0x18026cdc2;
    iVar8 = func_0x00018045a350();
    iVar8 = -iVar8;
    *(uint64_t *)(&stack0x00000838 + iVar8) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8);
    piVar3 = *(int64_t **)(&stack0x000008a0 + iVar8);
    *(undefined4 *)(&stack0xfffffffffffffffc + iVar8) = param_3;
    uVar13 = 0;
    *(undefined4 *)(&stack0x00000000 + iVar8) = param_2;
    *(undefined8 *)((int64_t)&var_8h + iVar8) = param_1;
    *(undefined *)((int64_t)&var_18h + iVar8) = 0;
    *(undefined2 *)(&stack0xfffffffffffffff8 + iVar8) = param_4;
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026ce11;
    func_0x0001804986e0((int64_t)&var_18h + iVar8 + 1, 0, 0x400);
    (&stack0x00000428)[iVar8] = 0;
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026ce2e;
    func_0x0001804986e0(&stack0x00000429 + iVar8, 0, 0x400);
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026ce53;
    func_0x000180473fb0((int64_t)&var_18h + iVar8, 0x401, param_1, 0x400);
    uVar11 = uVar13;
    puVar6 = (undefined *)((int64_t)&var_18h + iVar8);
    puVar16 = &stack0x00000428 + iVar8;
    while( true ) {
        puVar15 = puVar6;
        *piVar3 = 0;
        *puVar16 = 0;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026ce66;
        puVar9 = (undefined8 *)(*(code *)0x8000000000000034)(param_1);
        if (puVar9 == (undefined8 *)0x0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cf78;
            (*(code *)0x800000000000006f)();
            goto code_r0x00018026cf9f;
        }
        if ((*(int16_t *)(puVar9 + 2) == 2) && (*(int16_t *)((int64_t)puVar9 + 0x12) == 4)) {
            puVar12 = (undefined8 *)puVar9[3];
            puVar4 = (undefined4 *)*puVar12;
            piVar1 = piVar3;
            while (puVar4 != (undefined4 *)0x0) {
                uVar2 = *puVar4;
                *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cea6;
                iVar10 = func_0x00018026cfe0(*(undefined4 *)(&stack0x00000000 + iVar8), 
                                             *(undefined4 *)(&stack0xfffffffffffffffc + iVar8), 
                                             *(undefined2 *)(&stack0xfffffffffffffff8 + iVar8), uVar2);
                *piVar1 = iVar10;
                if (iVar10 == 0) goto code_r0x00018026cf9f;
                puVar12 = puVar12 + 1;
                piVar1 = (int64_t *)(iVar10 + 0x28);
                puVar4 = (undefined4 *)*puVar12;
            }
            param_1 = *(undefined8 *)((int64_t)&var_8h + iVar8);
        }
        uVar5 = *puVar9;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cedd;
        func_0x000180473fb0(puVar16, 0x401, uVar5, 0x400);
        if (*piVar3 != 0) break;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026ceeb;
        iVar10 = func_0x000180498cd0(puVar16);
        if (iVar10 == 0) goto code_r0x00018026cf9f;
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026ceff;
        iVar7 = func_0x000180498f10(puVar15, puVar16);
        if ((iVar7 == 0) ||
           (uVar14 = (int32_t)uVar11 + 1, uVar11 = (uint64_t)uVar14, puVar6 = puVar16, puVar16 = puVar15, uVar14 == 0x10
           )) goto code_r0x00018026cf9f;
    }
    if (*(int32_t *)(&stack0x00000898 + iVar8) != 0) {
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cf2d;
        iVar10 = func_0x000180498cd0(puVar16);
        *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cf3e;
        uVar11 = func_0x000180461640(1, iVar10 + 1);
        if (uVar11 != 0) {
            *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cf59;
            func_0x000180467b20(uVar11, iVar10 + 1, puVar16);
            uVar13 = uVar11;
        }
        *(uint64_t *)(*piVar3 + 0x18) = uVar13;
    }
code_r0x00018026cf9f:
    *(undefined8 *)((int64_t)&uStack_30 + iVar8) = 0x18026cfb1;
    func_0x000180459870(*(uint64_t *)(&stack0x00000838 + iVar8) ^ (uint64_t)(&stack0xffffffffffffffd8 + iVar8));
    return;
}

// ============================================================
// Function: FUN_18026cfe0
// Address: 0x18026cfe0
// Size: 169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

int64_t fcn.18026cfe0(int64_t arg_28h, int64_t arg_30h, int64_t arg_38h, int64_t arg_40h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined2 *puVar3;
    undefined4 in_ECX;
    undefined4 in_EDX;
    undefined2 in_R8W;
    undefined4 in_R9D;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d000;
    iVar1 = func_0x00018045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d01e;
    iVar2 = func_0x000180461640(1, 0x30);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d035;
        puVar3 = (undefined2 *)func_0x000180461640(1, 0x10);
        if (puVar3 != (undefined2 *)0x0) {
            puVar3[1] = in_R8W;
            *puVar3 = 2;
            *(undefined4 *)(puVar3 + 2) = in_R9D;
            *(undefined2 **)(iVar2 + 0x20) = puVar3;
            *(undefined4 *)(iVar2 + 4) = 2;
            *(undefined4 *)(iVar2 + 8) = in_ECX;
            *(undefined4 *)(iVar2 + 0xc) = in_EDX;
            *(undefined8 *)(iVar2 + 0x10) = 0x10;
            return iVar2;
        }
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d042;
        func_0x000180460d90(iVar2);
    }
    return 0;
}

// ============================================================
// Function: FUN_18026d090
// Address: 0x18026d090
// Size: 113 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

int64_t fcn.18026d090(int64_t arg_28h, int64_t arg_30h)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_10h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d0a5;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (in_RCX != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d0b5;
        iVar2 = fcn.180498cd0();
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d0c6;
        iVar3 = fcn.180461640(1, iVar2 + 1);
        if (iVar3 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d0dc;
            fcn.180467b20(iVar3, iVar2 + 1, in_RCX);
            return iVar3;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026d110
// Address: 0x18026d110
// Size: 63 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_45h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_47h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_29h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

void fcn.18026d110(int64_t arg_28h, int64_t arg_50h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int16_t iVar6;
    undefined4 uVar7;
    int16_t *in_RCX;
    int32_t in_EDX;
    int64_t *in_R8;
    int64_t *in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x18026d11f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d144;
    iVar2 = func_0x0001802748f0();
    if (iVar2 != 1) goto code_r0x00018026d23c;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined *)((int64_t)&arg_50h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d16c;
    func_0x0001804986e0((int64_t)&arg_50h + iVar3 + 1, 0, 0x400);
    *(undefined *)((int64_t)&arg_28h + iVar3) = 0;
    *(undefined8 *)(&stack0x00000039 + iVar3) = 0;
    *(undefined4 *)(&stack0x00000041 + iVar3) = 0;
    *(undefined2 *)(&stack0x00000045 + iVar3) = 0;
    (&stack0x00000047)[iVar3] = 0;
    uVar7 = 0x1c;
    if (*in_RCX == 2) {
        uVar7 = 0x10;
    }
    *(undefined (*) [16])((int64_t)&arg_28h + iVar3 + 1) = ZEXT816(0);
    if (*(code **)0x18077e788 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1bd;
        *(code **)0x18077e788 =
             (code *)fcn.18026cb90(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                   *(int64_t *)((int64_t)&var_8h + iVar3), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                   *(int64_t *)(&stack0x00000130 + iVar3));
    }
    *(uint32_t *)((int64_t)aiStackX_18 + iVar3 + -8) = -(uint32_t)(in_EDX != 0) & 10;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0x20;
    *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int64_t)&arg_28h + iVar3;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1ee;
    iVar2 = (**(code **)0x18077e788)(in_RCX, uVar7, (int64_t)&arg_50h + iVar3, 0x401);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1f8;
    (*(code *)0x8000000000000070)(iVar2);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d209;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d221;
        func_0x0001802295a0(0x1804e7560, 0xff, 0x1804e7578);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d228;
        uVar4 = func_0x00018026d340(iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d23a;
        func_0x0001802296d0(0x20, 0x80002, uVar4);
        goto code_r0x00018026d23c;
    }
    if (*(char *)((int64_t)&arg_28h + iVar3) == '\0') {
        if (*in_RCX == 2) {
            iVar6 = in_RCX[1];
        } else if (*in_RCX == 0x17) {
            iVar6 = in_RCX[1];
        } else {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d284;
        uVar1 = (*(code *)0x800000000000000f)(iVar6);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d29e;
        func_0x000180245f70((int64_t)&arg_28h + iVar3, 0x20, 0x18063cee0, uVar1);
    }
    if (in_R8 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d2ba;
        iVar5 = func_0x0001802231e0((int64_t)&arg_50h + iVar3, 0x1804e7560, 0x110);
        *in_R8 = iVar5;
    }
    if (in_R9 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d2d9;
        iVar5 = func_0x0001802231e0((int64_t)&arg_28h + iVar3, 0x1804e7560, 0x112);
        *in_R9 = iVar5;
    }
    if ((in_R8 == (int64_t *)0x0) || (*in_R8 != 0)) {
        if ((in_R9 == (int64_t *)0x0) || (*in_R9 != 0)) goto code_r0x00018026d23c;
        if (in_R8 != (int64_t *)0x0) goto code_r0x00018026d2f5;
    } else {
code_r0x00018026d2f5:
        iVar5 = *in_R8;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d30a;
        func_0x000180224990(iVar5, 0x1804e7560, 0x121);
        *in_R8 = 0;
        if (in_R9 == (int64_t *)0x0) goto code_r0x00018026d23c;
    }
    iVar5 = *in_R9;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d32b;
    func_0x000180224990(iVar5, 0x1804e7560, 0x125);
    *in_R9 = 0;
code_r0x00018026d23c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d24c;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18026d14f
// Address: 0x18026d14f
// Size: 181 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_45h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_47h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_29h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

void fcn.18026d110(int64_t arg_28h, int64_t arg_50h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int16_t iVar6;
    undefined4 uVar7;
    int16_t *in_RCX;
    int32_t in_EDX;
    int64_t *in_R8;
    int64_t *in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x18026d11f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d144;
    iVar2 = func_0x0001802748f0();
    if (iVar2 != 1) goto code_r0x00018026d23c;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined *)((int64_t)&arg_50h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d16c;
    func_0x0001804986e0((int64_t)&arg_50h + iVar3 + 1, 0, 0x400);
    *(undefined *)((int64_t)&arg_28h + iVar3) = 0;
    *(undefined8 *)(&stack0x00000039 + iVar3) = 0;
    *(undefined4 *)(&stack0x00000041 + iVar3) = 0;
    *(undefined2 *)(&stack0x00000045 + iVar3) = 0;
    (&stack0x00000047)[iVar3] = 0;
    uVar7 = 0x1c;
    if (*in_RCX == 2) {
        uVar7 = 0x10;
    }
    *(undefined (*) [16])((int64_t)&arg_28h + iVar3 + 1) = ZEXT816(0);
    if (*(code **)0x18077e788 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1bd;
        *(code **)0x18077e788 =
             (code *)fcn.18026cb90(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                   *(int64_t *)((int64_t)&var_8h + iVar3), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                   *(int64_t *)(&stack0x00000130 + iVar3));
    }
    *(uint32_t *)((int64_t)aiStackX_18 + iVar3 + -8) = -(uint32_t)(in_EDX != 0) & 10;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0x20;
    *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int64_t)&arg_28h + iVar3;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1ee;
    iVar2 = (**(code **)0x18077e788)(in_RCX, uVar7, (int64_t)&arg_50h + iVar3, 0x401);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1f8;
    (*(code *)0x8000000000000070)(iVar2);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d209;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d221;
        func_0x0001802295a0(0x1804e7560, 0xff, 0x1804e7578);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d228;
        uVar4 = func_0x00018026d340(iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d23a;
        func_0x0001802296d0(0x20, 0x80002, uVar4);
        goto code_r0x00018026d23c;
    }
    if (*(char *)((int64_t)&arg_28h + iVar3) == '\0') {
        if (*in_RCX == 2) {
            iVar6 = in_RCX[1];
        } else if (*in_RCX == 0x17) {
            iVar6 = in_RCX[1];
        } else {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d284;
        uVar1 = (*(code *)0x800000000000000f)(iVar6);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d29e;
        func_0x000180245f70((int64_t)&arg_28h + iVar3, 0x20, 0x18063cee0, uVar1);
    }
    if (in_R8 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d2ba;
        iVar5 = func_0x0001802231e0((int64_t)&arg_50h + iVar3, 0x1804e7560, 0x110);
        *in_R8 = iVar5;
    }
    if (in_R9 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d2d9;
        iVar5 = func_0x0001802231e0((int64_t)&arg_28h + iVar3, 0x1804e7560, 0x112);
        *in_R9 = iVar5;
    }
    if ((in_R8 == (int64_t *)0x0) || (*in_R8 != 0)) {
        if ((in_R9 == (int64_t *)0x0) || (*in_R9 != 0)) goto code_r0x00018026d23c;
        if (in_R8 != (int64_t *)0x0) goto code_r0x00018026d2f5;
    } else {
code_r0x00018026d2f5:
        iVar5 = *in_R8;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d30a;
        func_0x000180224990(iVar5, 0x1804e7560, 0x121);
        *in_R8 = 0;
        if (in_R9 == (int64_t *)0x0) goto code_r0x00018026d23c;
    }
    iVar5 = *in_R9;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d32b;
    func_0x000180224990(iVar5, 0x1804e7560, 0x125);
    *in_R9 = 0;
code_r0x00018026d23c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d24c;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18026d204
// Address: 0x18026d204
// Size: 313 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_460h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_470h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_51h
// WARNING: [rz-ghidra] Removing arg arg_39h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_41h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_45h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_47h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_29h
// WARNING: [rz-ghidra] Removing arg arg_268h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_298h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_3e8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_288h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_290h because it doesn't fit into ProtoModel

void fcn.18026d110(int64_t arg_28h, int64_t arg_50h)
{
    undefined2 uVar1;
    int32_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t iVar5;
    int16_t iVar6;
    undefined4 uVar7;
    int16_t *in_RCX;
    int32_t in_EDX;
    int64_t *in_R8;
    int64_t *in_R9;
    undefined8 unaff_R14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t aiStackX_18 [2];
    undefined8 uStack_28;
    
    uStack_28 = 0x18026d11f;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    *(uint64_t *)(&stack0x00000460 + iVar3) = *(uint64_t *)0x1806a3940 ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d144;
    iVar2 = func_0x0001802748f0();
    if (iVar2 != 1) goto code_r0x00018026d23c;
    *(undefined8 *)(&stack0x00000470 + iVar3) = unaff_R14;
    *(undefined *)((int64_t)&arg_50h + iVar3) = 0;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d16c;
    func_0x0001804986e0((int64_t)&arg_50h + iVar3 + 1, 0, 0x400);
    *(undefined *)((int64_t)&arg_28h + iVar3) = 0;
    *(undefined8 *)(&stack0x00000039 + iVar3) = 0;
    *(undefined4 *)(&stack0x00000041 + iVar3) = 0;
    *(undefined2 *)(&stack0x00000045 + iVar3) = 0;
    (&stack0x00000047)[iVar3] = 0;
    uVar7 = 0x1c;
    if (*in_RCX == 2) {
        uVar7 = 0x10;
    }
    *(undefined (*) [16])((int64_t)&arg_28h + iVar3 + 1) = ZEXT816(0);
    if (*(code **)0x18077e788 == (code *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1bd;
        *(code **)0x18077e788 =
             (code *)fcn.18026cb90(*(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18), 
                                   *(int64_t *)((int64_t)&var_8h + iVar3), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -8), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3), 
                                   *(int64_t *)((int64_t)aiStackX_18 + iVar3 + 8), 
                                   *(int64_t *)(&stack0x00000130 + iVar3));
    }
    *(uint32_t *)((int64_t)aiStackX_18 + iVar3 + -8) = -(uint32_t)(in_EDX != 0) & 10;
    *(undefined8 *)((int64_t)&var_8h + iVar3) = 0x20;
    *(int64_t *)((int64_t)aiStackX_18 + iVar3 + -0x18) = (int64_t)&arg_28h + iVar3;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1ee;
    iVar2 = (**(code **)0x18077e788)(in_RCX, uVar7, (int64_t)&arg_50h + iVar3, 0x401);
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d1f8;
    (*(code *)0x8000000000000070)(iVar2);
    if (iVar2 != 0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d209;
        func_0x000180229480();
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d221;
        func_0x0001802295a0(0x1804e7560, 0xff, 0x1804e7578);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d228;
        uVar4 = func_0x00018026d340(iVar2);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d23a;
        func_0x0001802296d0(0x20, 0x80002, uVar4);
        goto code_r0x00018026d23c;
    }
    if (*(char *)((int64_t)&arg_28h + iVar3) == '\0') {
        if (*in_RCX == 2) {
            iVar6 = in_RCX[1];
        } else if (*in_RCX == 0x17) {
            iVar6 = in_RCX[1];
        } else {
            iVar6 = 0;
        }
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d284;
        uVar1 = (*(code *)0x800000000000000f)(iVar6);
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d29e;
        func_0x000180245f70((int64_t)&arg_28h + iVar3, 0x20, 0x18063cee0, uVar1);
    }
    if (in_R8 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d2ba;
        iVar5 = func_0x0001802231e0((int64_t)&arg_50h + iVar3, 0x1804e7560, 0x110);
        *in_R8 = iVar5;
    }
    if (in_R9 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d2d9;
        iVar5 = func_0x0001802231e0((int64_t)&arg_28h + iVar3, 0x1804e7560, 0x112);
        *in_R9 = iVar5;
    }
    if ((in_R8 == (int64_t *)0x0) || (*in_R8 != 0)) {
        if ((in_R9 == (int64_t *)0x0) || (*in_R9 != 0)) goto code_r0x00018026d23c;
        if (in_R8 != (int64_t *)0x0) goto code_r0x00018026d2f5;
    } else {
code_r0x00018026d2f5:
        iVar5 = *in_R8;
        *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d30a;
        func_0x000180224990(iVar5, 0x1804e7560, 0x121);
        *in_R8 = 0;
        if (in_R9 == (int64_t *)0x0) goto code_r0x00018026d23c;
    }
    iVar5 = *in_R9;
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d32b;
    func_0x000180224990(iVar5, 0x1804e7560, 0x125);
    *in_R9 = 0;
code_r0x00018026d23c:
    *(undefined8 *)((int64_t)&uStack_28 + iVar3) = 0x18026d24c;
    func_0x000180459870(*(uint64_t *)(&stack0x00000460 + iVar3) ^ (uint64_t)(&stack0xffffffffffffffe0 + iVar3));
    return;
}

// ============================================================
// Function: FUN_18026d340
// Address: 0x18026d340
// Size: 75 bytes
// ============================================================
undefined8 fcn.18026d340(int64_t arg_28h)
{
    int64_t iVar1;
    uint64_t in_RCX;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d34c;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = 0x400;
    *(undefined8 *)((int64_t)&var_18h + iVar1) = 0x180782b80;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d382;
    (*(code *)0x699fbc)(0x12ff, 0, in_RCX & 0xffffffff, 0x400);
    return 0x180782b80;
}

// ============================================================
// Function: FUN_18026d390
// Address: 0x18026d390
// Size: 111 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18026d390(int64_t arg_28h, int64_t arg_50h)
{
    undefined8 uVar1;
    uint64_t uVar2;
    int64_t iVar3;
    undefined8 *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d3a0;
    iVar3 = fcn.18045a350();
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18026d3af;
    (*(code *)0x699f1c)(uVar1);
    uVar2 = in_RCX[3];
    uVar1 = *in_RCX;
    if (uVar2 == 0) {
    // WARNING: Treating indirect jump as call
        (*(code *)0x699f34)();
        return;
    }
    in_RCX[4] = in_RCX[4] + uVar2;
    in_RCX[3] = 0;
    *(undefined4 *)(in_RCX + 7) = 1;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar3) = 0x18026d3e5;
    (*(code *)0x699f34)(uVar1);
    // WARNING: Treating indirect jump as call
    (*(code *)0x69a1e2)(in_RCX[1], uVar2 & 0xffffffff, 0);
    return;
}

// ============================================================
// Function: FUN_18026d400
// Address: 0x18026d400
// Size: 149 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18026d400(int64_t arg_28h)
{
    int64_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t **in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d410;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = *in_RCX;
    if (piVar1 != (int64_t *)0x0) {
        iVar2 = piVar1[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026d428;
        (*(code *)0x699d92)(iVar2);
        iVar2 = piVar1[2];
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026d432;
        (*(code *)0x699d92)(iVar2);
        if (*piVar1 != 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026d440;
            (*(code *)0x699f4c)();
        }
        iVar2 = *piVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026d455;
        fcn.180224990(iVar2, 0x1804e75b0, 0x8d);
        *piVar1 = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar3) = 0x18026d471;
        fcn.180224990(piVar1, 0x1804e75b0, 0x155);
        *in_RCX = (int64_t *)0x0;
        return;
    }
    *in_RCX = (int64_t *)0x0;
    return;
}

// ============================================================
// Function: FUN_18026d4a0
// Address: 0x18026d4a0
// Size: 58 bytes
// ============================================================
int64_t * fcn.18026d4a0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d4ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d4c6;
    piVar2 = (int64_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (piVar2 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d4f0;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar3 == 0) {
        *piVar2 = 0;
        uVar4 = 0x134;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d50c;
        (*(code *)0x699f00)(iVar3);
        *piVar2 = iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d522;
        iVar3 = (*(code *)0x69a220)(0, 0, 0x7fffffff, 0);
        piVar2[1] = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d533;
            fcn.18026d840(piVar2);
            uVar4 = 0x13a;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d54e;
            iVar3 = (*(code *)0x69a220)(0, 0, 0x7fffffff, 0);
            piVar2[2] = iVar3;
            if (iVar3 != 0) {
                piVar2[3] = 0;
                piVar2[4] = 0;
                piVar2[5] = 0;
                *(undefined4 *)(piVar2 + 7) = 0;
                return piVar2;
            }
            iVar3 = piVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d561;
            (*(code *)0x699d92)(iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d569;
            fcn.18026d840(piVar2);
            uVar4 = 0x141;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d57e;
    fcn.180224990(piVar2, 0x1804e75b0, uVar4);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18026d4da
// Address: 0x18026d4da
// Size: 177 bytes
// ============================================================
int64_t * fcn.18026d4a0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d4ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d4c6;
    piVar2 = (int64_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (piVar2 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d4f0;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar3 == 0) {
        *piVar2 = 0;
        uVar4 = 0x134;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d50c;
        (*(code *)0x699f00)(iVar3);
        *piVar2 = iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d522;
        iVar3 = (*(code *)0x69a220)(0, 0, 0x7fffffff, 0);
        piVar2[1] = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d533;
            fcn.18026d840(piVar2);
            uVar4 = 0x13a;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d54e;
            iVar3 = (*(code *)0x69a220)(0, 0, 0x7fffffff, 0);
            piVar2[2] = iVar3;
            if (iVar3 != 0) {
                piVar2[3] = 0;
                piVar2[4] = 0;
                piVar2[5] = 0;
                *(undefined4 *)(piVar2 + 7) = 0;
                return piVar2;
            }
            iVar3 = piVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d561;
            (*(code *)0x699d92)(iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d569;
            fcn.18026d840(piVar2);
            uVar4 = 0x141;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d57e;
    fcn.180224990(piVar2, 0x1804e75b0, uVar4);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18026d58b
// Address: 0x18026d58b
// Size: 31 bytes
// ============================================================
int64_t * fcn.18026d4a0(int64_t arg_28h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    undefined8 unaff_RDI;
    undefined8 uVar4;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d4ac;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d4c6;
    piVar2 = (int64_t *)
             fcn.1802248d0(*(int64_t *)((int64_t)aiStackX_18 + iVar1), *(int64_t *)((int64_t)aiStackX_18 + iVar1 + 8));
    if (piVar2 == (int64_t *)0x0) {
        return (int64_t *)0x0;
    }
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = unaff_RDI;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d4f0;
    iVar3 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar3 == 0) {
        *piVar2 = 0;
        uVar4 = 0x134;
    } else {
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d50c;
        (*(code *)0x699f00)(iVar3);
        *piVar2 = iVar3;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d522;
        iVar3 = (*(code *)0x69a220)(0, 0, 0x7fffffff, 0);
        piVar2[1] = iVar3;
        if (iVar3 == 0) {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d533;
            fcn.18026d840(piVar2);
            uVar4 = 0x13a;
        } else {
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d54e;
            iVar3 = (*(code *)0x69a220)(0, 0, 0x7fffffff, 0);
            piVar2[2] = iVar3;
            if (iVar3 != 0) {
                piVar2[3] = 0;
                piVar2[4] = 0;
                piVar2[5] = 0;
                *(undefined4 *)(piVar2 + 7) = 0;
                return piVar2;
            }
            iVar3 = piVar2[1];
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d561;
            (*(code *)0x699d92)(iVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d569;
            fcn.18026d840(piVar2);
            uVar4 = 0x141;
        }
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d57e;
    fcn.180224990(piVar2, 0x1804e75b0, uVar4);
    return (int64_t *)0x0;
}

// ============================================================
// Function: FUN_18026d5b0
// Address: 0x18026d5b0
// Size: 92 bytes
// ============================================================
void fcn.18026d5b0(undefined8 *param_1)
{
    undefined8 uVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d5bc;
    iVar2 = fcn.18045a350();
    uVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18026d5cb;
    (*(code *)0x699f1c)(uVar1);
    uVar1 = *param_1;
    if (param_1[3] == 0) {
    // WARNING: Treating indirect jump as call
        (*(code *)0x699f34)();
        return;
    }
    param_1[4] = param_1[4] + 1;
    param_1[3] = param_1[3] + -1;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18026d5f4;
    (*(code *)0x699f34)(uVar1);
    // WARNING: Treating indirect jump as call
    (*(code *)0x69a1e2)(param_1[1], 1, 0);
    return;
}

// ============================================================
// Function: FUN_18026d610
// Address: 0x18026d610
// Size: 29 bytes
// ============================================================
void fcn.18026d610(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026d61a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = 0xffffffffffffffff;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_R13;
    *(undefined8 *)(&stack0x00000020 + iVar6 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18026d64c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar9 = *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6);
    bVar4 = false;
    bVar3 = false;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = unaff_R14;
    while( true ) {
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d67a;
        (*(code *)0x699f1c)(uVar1);
        iVar2 = in_RCX[6];
        if (bVar3) {
            if (iVar2 != iVar9) {
                bVar4 = false;
                iVar9 = iVar2;
            }
        } else {
            bVar3 = true;
            iVar9 = iVar2;
        }
        if (*(int32_t *)(in_RCX + 7) == 0) break;
        uVar1 = *in_RCX;
        if (!bVar4) {
            in_RCX[5] = in_RCX[5] + 1;
            bVar4 = true;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d6b5;
        (*(code *)0x699f34)(uVar1);
        uVar1 = in_RCX[2];
        if (uVar10 == 0xffffffffffffffff) {
            uVar8 = 0xffffffff;
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d6c4;
            uVar8 = func_0x0001802450c0();
            if ((uVar10 < uVar8) || (uVar8 = uVar10 - uVar8, uVar8 == 0)) {
                uVar8 = 1;
            } else if (uVar8 < 0xf423ffff0bdc0) {
                uVar8 = uVar8 / 1000000;
            } else {
                uVar8 = 0xfffffffe;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d705;
        iVar5 = (*(code *)0x69a1f6)(uVar1, uVar8);
        if (iVar5 != 0) {
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d716;
            (*(code *)0x699f1c)(uVar1);
            if ((bVar4) && (in_RCX[6] == iVar9)) {
                in_RCX[5] = in_RCX[5] + -1;
            }
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d72d;
            (*(code *)0x699f34)(uVar1);
            return;
        }
    }
    in_RCX[3] = in_RCX[3] + 1;
    if (bVar4) {
        in_RCX[5] = in_RCX[5] + -1;
    }
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d747;
    (*(code *)0x699f34)(uVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d750;
    (*(code *)0x699f34)(in_RDX);
    while( true ) {
        uVar1 = in_RCX[1];
        if (uVar10 == 0xffffffffffffffff) {
            uVar8 = 0xffffffff;
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d76f;
            uVar8 = func_0x0001802450c0();
            if ((uVar10 < uVar8) || (uVar8 = uVar10 - uVar8, uVar8 == 0)) {
                uVar8 = 1;
            } else if (uVar8 < 0xf423ffff0bdc0) {
                uVar8 = uVar8 / 1000000;
            } else {
                uVar8 = 0xfffffffe;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7a9;
        iVar5 = (*(code *)0x69a1f6)(uVar1, uVar8);
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7b4;
        (*(code *)0x699f1c)(uVar1);
        if (in_RCX[4] != 0) break;
        if (iVar5 != 0) {
            in_RCX[3] = in_RCX[3] + -1;
code_r0x00018026d80b:
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d814;
            (*(code *)0x699f34)(uVar1);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d81d;
            (*(code *)0x699f1c)(in_RDX);
            return;
        }
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7ca;
        (*(code *)0x699f34)(uVar1);
    }
    iVar9 = in_RCX[4] + -1;
    in_RCX[4] = iVar9;
    if ((iVar9 == 0) && (*(int32_t *)(in_RCX + 7) != 0)) {
        iVar9 = in_RCX[5];
        *(undefined4 *)(in_RCX + 7) = 0;
        if (iVar9 != 0) {
            uVar1 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7ff;
            (*(code *)0x69a1e2)(uVar1, iVar9, 0);
            in_RCX[6] = in_RCX[6] + 1;
            in_RCX[5] = 0;
        }
    }
    goto code_r0x00018026d80b;
}

// ============================================================
// Function: FUN_18026d630
// Address: 0x18026d630
// Size: 521 bytes
// ============================================================
void fcn.18026d610(int64_t arg_40h, int64_t arg_48h, int64_t arg_50h, int64_t arg_58h, int64_t arg_60h, int64_t arg_68h)
{
    undefined8 uVar1;
    int64_t iVar2;
    bool bVar3;
    bool bVar4;
    int32_t iVar5;
    int64_t iVar6;
    int64_t iVar7;
    uint64_t uVar8;
    int64_t iVar9;
    undefined8 *in_RCX;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    uint64_t uVar10;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    undefined8 unaff_R15;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026d61a;
    iVar6 = fcn.18045a350();
    iVar6 = -iVar6;
    uVar10 = 0xffffffffffffffff;
    *(undefined8 *)((int64_t)&arg_40h + iVar6) = unaff_RBX;
    *(undefined8 *)((int64_t)&arg_48h + iVar6) = unaff_RBP;
    *(undefined8 *)(&stack0x00000020 + iVar6) = unaff_RSI;
    *(undefined8 *)(&stack0x00000018 + iVar6) = unaff_RDI;
    *(undefined8 *)(&stack0x00000010 + iVar6) = unaff_R12;
    *(undefined8 *)(&stack0x00000008 + iVar6) = unaff_R13;
    *(undefined8 *)(&stack0x00000020 + iVar6 + -0x20) = unaff_R15;
    *(undefined8 *)((int64_t)&uStack_8 + iVar6) = 0x18026d64c;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    iVar9 = *(int64_t *)((int64_t)&arg_50h + iVar7 + iVar6);
    bVar4 = false;
    bVar3 = false;
    *(undefined8 *)((int64_t)&arg_58h + iVar7 + iVar6) = unaff_R14;
    while( true ) {
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d67a;
        (*(code *)0x699f1c)(uVar1);
        iVar2 = in_RCX[6];
        if (bVar3) {
            if (iVar2 != iVar9) {
                bVar4 = false;
                iVar9 = iVar2;
            }
        } else {
            bVar3 = true;
            iVar9 = iVar2;
        }
        if (*(int32_t *)(in_RCX + 7) == 0) break;
        uVar1 = *in_RCX;
        if (!bVar4) {
            in_RCX[5] = in_RCX[5] + 1;
            bVar4 = true;
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d6b5;
        (*(code *)0x699f34)(uVar1);
        uVar1 = in_RCX[2];
        if (uVar10 == 0xffffffffffffffff) {
            uVar8 = 0xffffffff;
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d6c4;
            uVar8 = func_0x0001802450c0();
            if ((uVar10 < uVar8) || (uVar8 = uVar10 - uVar8, uVar8 == 0)) {
                uVar8 = 1;
            } else if (uVar8 < 0xf423ffff0bdc0) {
                uVar8 = uVar8 / 1000000;
            } else {
                uVar8 = 0xfffffffe;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d705;
        iVar5 = (*(code *)0x69a1f6)(uVar1, uVar8);
        if (iVar5 != 0) {
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d716;
            (*(code *)0x699f1c)(uVar1);
            if ((bVar4) && (in_RCX[6] == iVar9)) {
                in_RCX[5] = in_RCX[5] + -1;
            }
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d72d;
            (*(code *)0x699f34)(uVar1);
            return;
        }
    }
    in_RCX[3] = in_RCX[3] + 1;
    if (bVar4) {
        in_RCX[5] = in_RCX[5] + -1;
    }
    uVar1 = *in_RCX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d747;
    (*(code *)0x699f34)(uVar1);
    *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d750;
    (*(code *)0x699f34)(in_RDX);
    while( true ) {
        uVar1 = in_RCX[1];
        if (uVar10 == 0xffffffffffffffff) {
            uVar8 = 0xffffffff;
        } else {
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d76f;
            uVar8 = func_0x0001802450c0();
            if ((uVar10 < uVar8) || (uVar8 = uVar10 - uVar8, uVar8 == 0)) {
                uVar8 = 1;
            } else if (uVar8 < 0xf423ffff0bdc0) {
                uVar8 = uVar8 / 1000000;
            } else {
                uVar8 = 0xfffffffe;
            }
        }
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7a9;
        iVar5 = (*(code *)0x69a1f6)(uVar1, uVar8);
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7b4;
        (*(code *)0x699f1c)(uVar1);
        if (in_RCX[4] != 0) break;
        if (iVar5 != 0) {
            in_RCX[3] = in_RCX[3] + -1;
code_r0x00018026d80b:
            uVar1 = *in_RCX;
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d814;
            (*(code *)0x699f34)(uVar1);
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d81d;
            (*(code *)0x699f1c)(in_RDX);
            return;
        }
        uVar1 = *in_RCX;
        *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7ca;
        (*(code *)0x699f34)(uVar1);
    }
    iVar9 = in_RCX[4] + -1;
    in_RCX[4] = iVar9;
    if ((iVar9 == 0) && (*(int32_t *)(in_RCX + 7) != 0)) {
        iVar9 = in_RCX[5];
        *(undefined4 *)(in_RCX + 7) = 0;
        if (iVar9 != 0) {
            uVar1 = in_RCX[2];
            *(undefined8 *)((int64_t)&uStack_8 + iVar7 + iVar6) = 0x18026d7ff;
            (*(code *)0x69a1e2)(uVar1, iVar9, 0);
            in_RCX[6] = in_RCX[6] + 1;
            in_RCX[5] = 0;
        }
    }
    goto code_r0x00018026d80b;
}

// ============================================================
// Function: FUN_18026d840
// Address: 0x18026d840
// Size: 66 bytes
// ============================================================
void fcn.18026d840(int64_t *param_1)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d84c;
    iVar2 = fcn.18045a350();
    if (*param_1 != 0) {
        *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18026d860;
        (*(code *)0x699f4c)();
    }
    iVar1 = *param_1;
    *(undefined8 *)((int64_t)&uStack_10 + -iVar2) = 0x18026d875;
    fcn.180224990(iVar1, 0x1804e75b0, 0x8d);
    *param_1 = 0;
    return;
}

// ============================================================
// Function: FUN_18026d890
// Address: 0x18026d890
// Size: 24 bytes
// ============================================================
void fcn.18026d890(void)
{
    fcn.18045a350();
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f1c)();
    return;
}

// ============================================================
// Function: FUN_18026d8b0
// Address: 0x18026d8b0
// Size: 70 bytes
// ============================================================
int64_t fcn.18026d8b0(void)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t aiStackX_18 [2];
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d8bc;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d8d6;
    iVar2 = fcn.180224d60(*(int64_t *)((int64_t)aiStackX_18 + iVar1));
    if (iVar2 == 0) {
        return 0;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d8ed;
    (*(code *)0x699f00)(iVar2);
    return iVar2;
}

// ============================================================
// Function: FUN_18026d900
// Address: 0x18026d900
// Size: 24 bytes
// ============================================================
void fcn.18026d900(void)
{
    fcn.18045a350();
    // WARNING: Treating indirect jump as call
    (*(code *)0x699f34)();
    return;
}

// ============================================================
// Function: FUN_18026d920
// Address: 0x18026d920
// Size: 104 bytes
// ============================================================
undefined8 fcn.18026d920(int64_t arg_28h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t in_RCX;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d92c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((in_RCX != 0) && (puVar1 = *(undefined8 **)(in_RCX + 0x20), puVar1 != (undefined8 *)0x0)) {
        uVar2 = *puVar1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026d94b;
        iVar3 = (*(code *)0x69a1f6)(uVar2, 0xffffffff);
        if (iVar3 == 0) {
            uVar2 = *puVar1;
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026d95d;
            iVar3 = (*(code *)0x69a20c)(uVar2, (int64_t)&arg_28h + iVar4);
            if ((iVar3 != 0) && (*(int32_t *)((int64_t)&arg_28h + iVar4) == 0)) {
                uVar2 = *puVar1;
                *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026d971;
                iVar3 = (*(code *)0x699d92)(uVar2);
                if (iVar3 != 0) {
                    return 1;
                }
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026d990
// Address: 0x18026d990
// Size: 159 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026d990(int64_t arg_38h, int64_t arg_60h)
{
    int64_t iVar1;
    int64_t *piVar2;
    int64_t iVar3;
    int64_t in_RCX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026d9a0;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d9bd;
    piVar2 = (int64_t *)fcn.180224d60(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8));
    if (piVar2 != (int64_t *)0x0) {
        *(undefined8 *)((int64_t)&iStackX_20 + iVar1) = 0;
        *(undefined4 *)((int64_t)&iStackX_20 + iVar1 + -8) = 0;
        *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026d9e9;
        iVar3 = fcn.18045f6e8(*(int64_t *)((int64_t)&iStackX_20 + iVar1 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1));
        *piVar2 = iVar3;
        if (iVar3 != 0) {
            *(int64_t **)(in_RCX + 0x20) = piVar2;
            return 1;
        }
    }
    *(undefined8 *)(in_RCX + 0x20) = 0;
    *(undefined8 *)((int64_t)&uStack_10 + iVar1) = 0x18026da22;
    fcn.180224990(piVar2, 0x1804e75b0, 0x34);
    return 0;
}

// ============================================================
// Function: FUN_18026da30
// Address: 0x18026da30
// Size: 150 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18026da30(int64_t arg_28h)
{
    undefined8 uVar1;
    code *pcVar2;
    undefined8 *puVar3;
    uint32_t uVar4;
    int64_t iVar5;
    uint32_t *in_RCX;
    int64_t var_8h;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026da40;
    iVar5 = fcn.18045a350();
    iVar5 = -iVar5;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026da4c;
    uVar4 = (*(code *)0x699ddc)();
    uVar1 = *(undefined8 *)(in_RCX + 2);
    in_RCX[0x10] = uVar4;
    pcVar2 = *(code **)(in_RCX + 4);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026da59;
    uVar4 = (*pcVar2)(uVar1);
    uVar1 = *(undefined8 *)(in_RCX + 0xc);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026da65;
    (*(code *)0x699f1c)(uVar1);
    *in_RCX = *in_RCX | 1;
    in_RCX[6] = uVar4;
    puVar3 = *(undefined8 **)(in_RCX + 0xe);
    uVar1 = *puVar3;
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026da78;
    (*(code *)0x699f1c)(uVar1);
    uVar1 = *puVar3;
    if (puVar3[3] == 0) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026da8a;
        (*(code *)0x699f34)();
    } else {
        puVar3[4] = puVar3[4] + 1;
        puVar3[3] = puVar3[3] + -1;
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026da9d;
        (*(code *)0x699f34)(uVar1);
        uVar1 = puVar3[1];
        *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026daaf;
        (*(code *)0x69a1e2)(uVar1, 1, 0);
    }
    uVar1 = *(undefined8 *)(in_RCX + 0xc);
    *(undefined8 *)((int64_t)&uStack_10 + iVar5) = 0x18026dab9;
    (*(code *)0x699f34)(uVar1);
    return 0;
}

// ============================================================
// Function: FUN_18026db10
// Address: 0x18026db10
// Size: 218 bytes
// ============================================================
undefined8
fcn.18026db10(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_b0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    uint32_t *in_RCX;
    undefined4 in_EDX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026db1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(undefined4 *)((int64_t)&arg_b0h + iVar4) = in_EDX;
    if ((in_RCX != (uint32_t *)0x0) && ((*in_RCX & 0x800) != 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026db4f;
        puVar5 = (undefined4 *)fcn.180229d80((int64_t)&iStackX_20 + iVar4 + -8, 0x1804e7648, (int64_t)&arg_b0h + iVar4);
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *(undefined4 *)((int64_t)&arg_48h + iVar4) = *puVar5;
        *(undefined4 *)((int64_t)&arg_48h + iVar4 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000050 + iVar4) = uVar2;
        *(undefined4 *)(&stack0x00000054 + iVar4) = uVar3;
        uVar1 = puVar5[5];
        uVar2 = puVar5[6];
        uVar3 = puVar5[7];
        *(undefined4 *)((int64_t)&arg_58h + iVar4) = puVar5[4];
        *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000060 + iVar4) = uVar2;
        *(undefined4 *)(&stack0x00000064 + iVar4) = uVar3;
        *(undefined8 *)((int64_t)&arg_68h + iVar4) = *(undefined8 *)(puVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026db75;
        puVar5 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar4 + -8);
        uVar1 = puVar5[1];
        uVar2 = puVar5[2];
        uVar3 = puVar5[3];
        *(undefined4 *)((int64_t)&arg_70h + iVar4) = *puVar5;
        *(undefined4 *)((int64_t)&arg_70h + iVar4 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000078 + iVar4) = uVar2;
        *(undefined4 *)(&stack0x0000007c + iVar4) = uVar3;
        uVar1 = puVar5[5];
        uVar2 = puVar5[6];
        uVar3 = puVar5[7];
        *(undefined4 *)((int64_t)&arg_80h + iVar4) = puVar5[4];
        *(undefined4 *)((int64_t)&arg_80h + iVar4 + 4) = uVar1;
        *(undefined4 *)(&stack0x00000088 + iVar4) = uVar2;
        *(undefined4 *)(&stack0x0000008c + iVar4) = uVar3;
        *(undefined8 *)((int64_t)&arg_90h + iVar4) = *(undefined8 *)(puVar5 + 8);
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dba4;
        uVar6 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), 
                              *(int64_t *)((int64_t)&iStackX_20 + iVar4), *(int64_t *)(&stack0x00000028 + iVar4));
        return uVar6;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dbb2;
    fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dbca;
    fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                  *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                  *(int64_t *)((int64_t)&arg_48h + iVar4));
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dbdc;
    fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
    return 0xfffffffe;
}

// ============================================================
// Function: FUN_18026dbf0
// Address: 0x18026dbf0
// Size: 259 bytes
// ============================================================
undefined8
fcn.18026dbf0(uint8_t *placeholder_0, int64_t arg2, int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h,
             int64_t arg_80h, int64_t arg_90h, int64_t arg_b0h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026dbff;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    if ((placeholder_0 == (uint8_t *)0x0) || ((*placeholder_0 & 6) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dcbb;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dcd3;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dce5;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0xfffffffe;
    }
    if (((*(int64_t *)(placeholder_0 + 0x20) == 0) && (**(int32_t **)(placeholder_0 + 0x78) != 0x1c)) &&
       (**(int32_t **)(placeholder_0 + 0x78) != 0x398)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dc58;
    puVar5 = (undefined4 *)fcn.180229bc0((int64_t)&iStackX_20 + iVar4 + -8, 0x1804e7618, (int64_t)&arg_b0h + iVar4);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar4) = *puVar5;
    *(undefined4 *)((int64_t)&arg_48h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000050 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000054 + iVar4) = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar4) = puVar5[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000060 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000064 + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = *(undefined8 *)(puVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dc7e;
    puVar5 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar4 + -8);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar4) = *puVar5;
    *(undefined4 *)((int64_t)&arg_70h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000078 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000007c + iVar4) = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar4) = puVar5[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000088 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000008c + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = *(undefined8 *)(puVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dcad;
    uVar6 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
    return uVar6;
}

// ============================================================
// Function: FUN_18026dd00
// Address: 0x18026dd00
// Size: 267 bytes
// ============================================================
undefined8
fcn.18026dd00(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    uint8_t *in_RCX;
    int32_t in_EDX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026dd0c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_a8h + iVar4) = (int64_t)in_EDX;
    if ((in_RCX == (uint8_t *)0x0) || ((*in_RCX & 6) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026ddd3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026ddeb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026ddfd;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0xfffffffe;
    }
    if (((*(int64_t *)(in_RCX + 0x20) == 0) && (**(int32_t **)(in_RCX + 0x78) != 0x1c)) &&
       (**(int32_t **)(in_RCX + 0x78) != 0x398)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dd70;
    puVar5 = (undefined4 *)fcn.180229cc0((int64_t)&iStackX_20 + iVar4 + -8, 0x1804e7608, (int64_t)&arg_a8h + iVar4);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar4) = *puVar5;
    *(undefined4 *)((int64_t)&arg_48h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000050 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000054 + iVar4) = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar4) = puVar5[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000060 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000064 + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = *(undefined8 *)(puVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dd96;
    puVar5 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar4 + -8);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar4) = *puVar5;
    *(undefined4 *)((int64_t)&arg_70h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000078 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000007c + iVar4) = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar4) = puVar5[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000088 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000008c + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = *(undefined8 *)(puVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026ddc5;
    uVar6 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
    return uVar6;
}

// ============================================================
// Function: FUN_18026de10
// Address: 0x18026de10
// Size: 267 bytes
// ============================================================
undefined8
fcn.18026de10(int64_t arg_48h, int64_t arg_58h, int64_t arg_68h, int64_t arg_70h, int64_t arg_80h, int64_t arg_90h,
             int64_t arg_a8h)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    undefined8 uVar6;
    uint8_t *in_RCX;
    int32_t in_EDX;
    int64_t var_18h;
    int64_t iStackX_20;
    undefined8 uStack_10;
    
    uStack_10 = 0x18026de1c;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    *(int64_t *)((int64_t)&arg_a8h + iVar4) = (int64_t)in_EDX;
    if ((in_RCX == (uint8_t *)0x0) || ((*in_RCX & 6) == 0)) {
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dee3;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026defb;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                      *(int64_t *)(&stack0x00000028 + iVar4), *(int64_t *)(&stack0x00000030 + iVar4), 
                      *(int64_t *)((int64_t)&arg_48h + iVar4));
        *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026df0d;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar4));
        return 0xfffffffe;
    }
    if (((*(int64_t *)(in_RCX + 0x20) == 0) && (**(int32_t **)(in_RCX + 0x78) != 0x1c)) &&
       (**(int32_t **)(in_RCX + 0x78) != 0x398)) {
        return 0xffffffff;
    }
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026de80;
    puVar5 = (undefined4 *)fcn.180229cc0((int64_t)&iStackX_20 + iVar4 + -8, 0x1804e7610, (int64_t)&arg_a8h + iVar4);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)((int64_t)&arg_48h + iVar4) = *puVar5;
    *(undefined4 *)((int64_t)&arg_48h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000050 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000054 + iVar4) = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    *(undefined4 *)((int64_t)&arg_58h + iVar4) = puVar5[4];
    *(undefined4 *)((int64_t)&arg_58h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000060 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x00000064 + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_68h + iVar4) = *(undefined8 *)(puVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dea6;
    puVar5 = (undefined4 *)fcn.180229ba0((int64_t)&iStackX_20 + iVar4 + -8);
    uVar1 = puVar5[1];
    uVar2 = puVar5[2];
    uVar3 = puVar5[3];
    *(undefined4 *)((int64_t)&arg_70h + iVar4) = *puVar5;
    *(undefined4 *)((int64_t)&arg_70h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000078 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000007c + iVar4) = uVar3;
    uVar1 = puVar5[5];
    uVar2 = puVar5[6];
    uVar3 = puVar5[7];
    *(undefined4 *)((int64_t)&arg_80h + iVar4) = puVar5[4];
    *(undefined4 *)((int64_t)&arg_80h + iVar4 + 4) = uVar1;
    *(undefined4 *)(&stack0x00000088 + iVar4) = uVar2;
    *(undefined4 *)(&stack0x0000008c + iVar4) = uVar3;
    *(undefined8 *)((int64_t)&arg_90h + iVar4) = *(undefined8 *)(puVar5 + 8);
    *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026ded5;
    uVar6 = fcn.180259dc0(*(int64_t *)((int64_t)&iStackX_20 + iVar4 + -8), *(int64_t *)((int64_t)&iStackX_20 + iVar4), 
                          *(int64_t *)(&stack0x00000028 + iVar4));
    return uVar6;
}

// ============================================================
// Function: FUN_18026df20
// Address: 0x18026df20
// Size: 53 bytes
// ============================================================
void fcn.18026df20(int64_t arg_28h)
{
    int64_t iVar1;
    undefined4 in_EDX;
    int64_t var_20h;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026df2a;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    *(undefined8 *)((int64_t)&arg_28h + iVar1) = 0;
    *(undefined4 *)((int64_t)&var_20h + iVar1) = in_EDX;
    *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026df50;
    fcn.180258740(*(int64_t *)(&stack0x00000040 + iVar1), *(int64_t *)(&stack0x00000048 + iVar1), 
                  *(int64_t *)(&stack0x00000050 + iVar1), *(int64_t *)(&stack0x00000058 + iVar1), 
                  *(int64_t *)(&stack0x00000060 + iVar1), *(int64_t *)(&stack0x00000068 + iVar1));
    return;
}

// ============================================================
// Function: FUN_18026df60
// Address: 0x18026df60
// Size: 95 bytes
// ============================================================
void fcn.18026df60(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026df70;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026df9b;
            fcn.180224990(uVar3, 0x1804e7678, 0x1ba);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dfa4;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026dfb9;
            fcn.180224990(arg1, 0x1804e7678, 0x1bd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18026dfc0
// Address: 0x18026dfc0
// Size: 219 bytes
// ============================================================
undefined8 fcn.18026dfc0(int64_t arg_60h)
{
    int64_t iVar1;
    int64_t iVar2;
    undefined8 uVar3;
    int32_t *in_RCX;
    int64_t in_RDX;
    int64_t in_R8;
    int64_t in_R9;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026dfca;
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    if ((((in_RCX == (int32_t *)0x0) || (in_R9 == 0)) || (*(int64_t *)((int64_t)&arg_60h + iVar2) == 0)) ||
       ((in_RDX == 0 && (in_R8 == 0)))) {
        return 0;
    }
    if (*in_RCX != 0x2000) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026e008;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026e020;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026e032;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0xffffffff;
    }
    if (*(int64_t *)(in_RCX + 0xc) == 0) {
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026e048;
        fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026e060;
        fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar2), *(int64_t *)(&stack0x00000028 + iVar2), 
                      *(int64_t *)(&stack0x00000030 + iVar2), *(int64_t *)(&stack0x00000038 + iVar2), 
                      *(int64_t *)(&stack0x00000050 + iVar2));
        *(undefined8 *)((int64_t)&uStack_8 + iVar2) = 0x18026e072;
        fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar2));
        return 0xfffffffe;
    }
    iVar1 = *(int64_t *)(in_RCX + 10);
    uVar3 = *(undefined8 *)(in_RCX + 0xc);
    *(int64_t *)((int64_t)&arg_60h + iVar2) = *(int64_t *)((int64_t)&arg_60h + iVar2);
    // WARNING: Could not recover jumptable at 0x00018026e091. Too many branches
    // WARNING: Treating indirect jump as call
    uVar3 = (**(code **)(iVar1 + 0x48))(uVar3);
    return uVar3;
}

// ============================================================
// Function: FUN_18026e0a0
// Address: 0x18026e0a0
// Size: 33 bytes
// ============================================================
int32_t fcn.18026e0a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h,
                     int64_t arg_68h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
                     int64_t arg_168h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t arg1;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined4 *in_RCX;
    undefined4 uVar14;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar16;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18026e0aa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar15 = (int32_t *)0x0;
    uVar14 = 0x2000;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0x2000;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x18026e5e0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    arg1 = 0;
    iVar16 = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    uVar13 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar8 + iVar7) = 0;
    if ((in_RCX == (undefined4 *)0x0) || (*(int64_t *)(in_RCX + 6) == 0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb92;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebbc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e625;
    func_0x000180259930();
    piVar2 = *(int32_t **)(in_RCX + 0x22);
    *in_RCX = uVar14;
    if (piVar2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e639;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e651;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e663;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    if ((piVar15 != (int32_t *)0x0) && (*piVar15 != *piVar2)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e678;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e690;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6a2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    if ((*(int64_t *)(piVar2 + 0x18) != 0) && (*(int64_t *)(piVar2 + 0x18) != *(int64_t *)(in_RCX + 8))) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6cf;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6f9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    uVar10 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e70c;
    iVar9 = func_0x00018029f2b0(uVar10, 0xe);
    *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e71b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e733;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e745;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    iVar16 = 1;
    iVar9 = 0;
    do {
        if (iVar9 != 0) goto code_r0x00018026e9e1;
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar1 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar1 < 2) {
                uVar10 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e794;
                fcn.180224990(uVar10, 0x1804e7678, 0x1ba);
                uVar10 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e79d;
                fcn.18027edb0(uVar10);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7b2;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7bf;
        func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
        if (iVar16 == 1) {
            uVar10 = *(undefined8 *)(in_RCX + 4);
            uVar3 = *(undefined8 *)(in_RCX + 2);
            *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar7) = 0x18026e1c0;
            *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
            *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = 0x18026e220;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e872;
            arg1 = func_0x000180280c20(uVar3, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
            if (arg1 != 0) {
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                goto code_r0x00018026e882;
            }
        } else {
            if (iVar16 == 2) {
                uVar13 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7e3;
                uVar13 = func_0x0001801dd170(uVar13);
                uVar10 = *(undefined8 *)(in_RCX + 4);
                *(undefined8 *)((int64_t)&arg_28h + iVar8 + iVar7) = 0x18026e1c0;
                *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                *(undefined8 *)((int64_t)&var_18h + iVar8 + iVar7) = 0x18026e220;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e820;
                arg1 = func_0x000180280ca0(uVar13, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
                if (arg1 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e82d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x00018026eb3f;
                }
            } else if (arg1 == 0) goto code_r0x00018026e916;
code_r0x00018026e882:
            uVar10 = *(undefined8 *)(in_RCX + 8);
            uVar3 = *(undefined8 *)(in_RCX + 4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e88f;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e89d;
            iVar11 = func_0x000180257b60(uVar13, uVar10, uVar3);
            *(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) = iVar11;
            if (iVar11 != 0) {
                uVar10 = *(undefined8 *)(in_RCX + 4);
                uVar3 = *(undefined8 *)(in_RCX + 2);
                uVar4 = *(undefined8 *)(in_RCX + 0x22);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8c9;
                iVar9 = func_0x000180230ea0(uVar4, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                if ((iVar9 != 0) && (iVar12 = *(int64_t *)((int64_t)&arg_c0h + iVar8 + iVar7), iVar12 != 0)) {
                    uVar10 = *(undefined8 *)(in_RCX + 4);
                    uVar3 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8f6;
                    iVar12 = func_0x000180230ea0(iVar12, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                    *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar12;
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ad;
                        fcn.18026df60(arg1);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9b2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9dc;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                        goto code_r0x00018026eb6a;
                    }
                }
            }
            if (*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e916;
                func_0x000180257a00(iVar11);
            }
        }
code_r0x00018026e916:
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    if (iVar9 == 0) {
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar16 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar16 < 2) {
                uVar13 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e953;
                fcn.180224990(uVar13, 0x1804e7678, 0x1ba);
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e95c;
                fcn.18027edb0(uVar13);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e971;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e976;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e98e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9a0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
code_r0x00018026e9e1:
    *(int64_t *)(in_RCX + 10) = arg1;
    uVar13 = *(undefined8 *)(arg1 + 0x18);
    pcVar5 = *(code **)(arg1 + 0x28);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f2;
    uVar13 = func_0x00018027e810(uVar13);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f7;
    iVar11 = (*pcVar5)(uVar13);
    *(int64_t *)(in_RCX + 0xc) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea08;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea20;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea32;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
    iVar16 = *(int32_t *)((int64_t)&arg_b0h + iVar8 + iVar7);
    if (iVar16 == 0x1000) {
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            pcVar5 = *(code **)(arg1 + 0x30);
            if (pcVar5 == (code *)0x0) goto code_r0x00018026eb35;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb0a;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x80);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eb35:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb3a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x00018026eb3f:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb52;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb64;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                iVar6 = -2;
                goto code_r0x00018026eb6a;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaf1;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    } else {
        if (iVar16 != 0x2000) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea55;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea7f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            goto code_r0x00018026eb6a;
        }
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            if (*(int64_t *)(arg1 + 0x30) == 0) goto code_r0x00018026eac2;
            pcVar5 = *(code **)(arg1 + 0x40);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac0;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x88);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eac2:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x00018026eb3f;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaa7;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb1a;
    func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    if (0 < iVar6) {
        return 1;
    }
code_r0x00018026eb6a:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb72;
    func_0x000180259930(in_RCX);
    uVar13 = *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb85;
    func_0x000180257a00(uVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_18026e0d0
// Address: 0x18026e0d0
// Size: 188 bytes
// ============================================================
undefined8 fcn.18026e0d0(int32_t *param_1, int64_t param_2, undefined8 param_3, int64_t param_4)
{
    int64_t iVar1;
    undefined8 uVar2;
    int64_t iStackX_20;
    undefined8 uStack_8;
    
    uStack_8 = 0x18026e0da;
    iVar1 = fcn.18045a350();
    iVar1 = -iVar1;
    if (param_1 != (int32_t *)0x0) {
        if (*param_1 != 0x1000) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026e0f3;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026e10b;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026e11d;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
            return 0xffffffff;
        }
        if (*(int64_t *)(param_1 + 0xc) == 0) {
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026e135;
            fcn.180229480(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026e14d;
            fcn.1802295a0(*(int64_t *)((int64_t)&iStackX_20 + iVar1), *(int64_t *)(&stack0x00000028 + iVar1), 
                          *(int64_t *)(&stack0x00000030 + iVar1), *(int64_t *)(&stack0x00000038 + iVar1), 
                          *(int64_t *)(&stack0x00000050 + iVar1));
            *(undefined8 *)((int64_t)&uStack_8 + iVar1) = 0x18026e15f;
            fcn.1802296d0(*(int64_t *)(&stack0x00000040 + iVar1));
            return 0xfffffffe;
        }
        if ((param_2 == 0) || (param_4 != 0)) {
    // WARNING: Could not recover jumptable at 0x00018026e182. Too many branches
    // WARNING: Treating indirect jump as call
            uVar2 = (**(code **)(*(int64_t *)(param_1 + 10) + 0x38))(*(int64_t *)(param_1 + 0xc));
            return uVar2;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18026e190
// Address: 0x18026e190
// Size: 33 bytes
// ============================================================
int32_t fcn.18026e190(undefined4 *param_1, undefined8 param_2)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t arg1;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined4 uVar14;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar16;
    undefined8 unaff_R15;
    int64_t aiStack_10 [2];
    
    aiStack_10[1] = 0x18026e19a;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar15 = (int32_t *)0x0;
    uVar14 = 0x1000;
    *(undefined8 *)(&stack0x00000048 + iVar7) = 0;
    *(undefined8 *)(&stack0x00000040 + iVar7) = param_2;
    *(undefined4 *)(&stack0x00000038 + iVar7) = 0x1000;
    *(undefined8 *)(&stack0x00000020 + iVar7) = unaff_RBX;
    *(undefined8 *)(&stack0x00000018 + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000020 + iVar7 + -0x20) = unaff_R14;
    *(undefined8 *)((int64_t)aiStack_10 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)aiStack_10 + iVar7) = 0x18026e5e0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    arg1 = 0;
    iVar16 = 0;
    iVar6 = 0;
    *(undefined8 *)(&stack0x000000a8 + iVar8 + iVar7) = 0;
    uVar13 = 0;
    *(undefined8 *)(&stack0x00000038 + iVar8 + iVar7) = 0;
    if ((param_1 == (undefined4 *)0x0) || (*(int64_t *)(param_1 + 6) == 0)) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb92;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ebaa;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ebbc;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)(&stack0x00000068 + iVar8 + iVar7) = unaff_R12;
    *(undefined8 *)(&stack0x00000060 + iVar8 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e625;
    func_0x000180259930();
    piVar2 = *(int32_t **)(param_1 + 0x22);
    *param_1 = uVar14;
    if (piVar2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e639;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e651;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e663;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    if ((piVar15 != (int32_t *)0x0) && (*piVar15 != *piVar2)) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e678;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e690;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e6a2;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        return 0;
    }
    if ((*(int64_t *)(piVar2 + 0x18) != 0) && (*(int64_t *)(piVar2 + 0x18) != *(int64_t *)(param_1 + 8))) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e6cf;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e6e7;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e6f9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    uVar10 = *(undefined8 *)(param_1 + 8);
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e70c;
    iVar9 = func_0x00018029f2b0(uVar10, 0xe);
    *(int64_t *)(&stack0x00000040 + iVar8 + iVar7) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e71b;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e733;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e745;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    iVar16 = 1;
    iVar9 = 0;
    do {
        if (iVar9 != 0) goto code_r0x00018026e9e1;
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar1 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar1 < 2) {
                uVar10 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e794;
                fcn.180224990(uVar10, 0x1804e7678, 0x1ba);
                uVar10 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e79d;
                fcn.18027edb0(uVar10);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e7b2;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e7bf;
        func_0x000180257a00(*(undefined8 *)(&stack0x000000a8 + iVar8 + iVar7));
        if (iVar16 == 1) {
            uVar10 = *(undefined8 *)(param_1 + 4);
            uVar3 = *(undefined8 *)(param_1 + 2);
            *(undefined8 *)(&stack0x00000028 + iVar8 + iVar7) = 0x18026e1c0;
            *(undefined8 *)(&stack0x00000020 + iVar8 + iVar7) = 0x180248230;
            *(undefined8 *)(&stack0x00000018 + iVar8 + iVar7) = 0x18026e220;
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e872;
            arg1 = func_0x000180280c20(uVar3, 0xe, *(undefined8 *)(&stack0x00000040 + iVar8 + iVar7), uVar10);
            if (arg1 != 0) {
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                goto code_r0x00018026e882;
            }
        } else {
            if (iVar16 == 2) {
                uVar13 = *(undefined8 *)(param_1 + 8);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e7e3;
                uVar13 = func_0x0001801dd170(uVar13);
                uVar10 = *(undefined8 *)(param_1 + 4);
                *(undefined8 *)(&stack0x00000028 + iVar8 + iVar7) = 0x18026e1c0;
                *(undefined8 *)(&stack0x00000020 + iVar8 + iVar7) = 0x180248230;
                *(undefined8 *)(&stack0x00000018 + iVar8 + iVar7) = 0x18026e220;
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e820;
                arg1 = func_0x000180280ca0(uVar13, 0xe, *(undefined8 *)(&stack0x00000040 + iVar8 + iVar7), uVar10);
                if (arg1 == 0) {
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e82d;
                    fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                  *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                    goto code_r0x00018026eb3f;
                }
            } else if (arg1 == 0) goto code_r0x00018026e916;
code_r0x00018026e882:
            uVar10 = *(undefined8 *)(param_1 + 8);
            uVar3 = *(undefined8 *)(param_1 + 4);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e88f;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e89d;
            iVar11 = func_0x000180257b60(uVar13, uVar10, uVar3);
            *(int64_t *)(&stack0x000000a8 + iVar8 + iVar7) = iVar11;
            if (iVar11 != 0) {
                uVar10 = *(undefined8 *)(param_1 + 4);
                uVar3 = *(undefined8 *)(param_1 + 2);
                uVar4 = *(undefined8 *)(param_1 + 0x22);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e8c9;
                iVar9 = func_0x000180230ea0(uVar4, uVar3, &stack0x000000a8 + iVar8 + iVar7, uVar10);
                if ((iVar9 != 0) && (*(int64_t *)(&stack0x000000c0 + iVar8 + iVar7) != 0)) {
                    uVar10 = *(undefined8 *)(param_1 + 4);
                    uVar3 = *(undefined8 *)(param_1 + 2);
                    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e8f6;
                    iVar12 = func_0x000180230ea0(*(int64_t *)(&stack0x000000c0 + iVar8 + iVar7), uVar3, 
                                                 &stack0x000000a8 + iVar8 + iVar7, uVar10);
                    *(int64_t *)(&stack0x00000038 + iVar8 + iVar7) = iVar12;
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9ad;
                        fcn.18026df60(arg1);
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9b2;
                        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9ca;
                        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9dc;
                        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                        goto code_r0x00018026eb6a;
                    }
                }
            }
            if (*(int64_t *)(&stack0x000000a8 + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e916;
                func_0x000180257a00(iVar11);
            }
        }
code_r0x00018026e916:
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    if (iVar9 == 0) {
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar16 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar16 < 2) {
                uVar13 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e953;
                fcn.180224990(uVar13, 0x1804e7678, 0x1ba);
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e95c;
                fcn.18027edb0(uVar13);
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e971;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e976;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e98e;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9a0;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
code_r0x00018026e9e1:
    *(int64_t *)(param_1 + 10) = arg1;
    uVar13 = *(undefined8 *)(arg1 + 0x18);
    pcVar5 = *(code **)(arg1 + 0x28);
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9f2;
    uVar13 = func_0x00018027e810(uVar13);
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026e9f7;
    iVar11 = (*pcVar5)(uVar13);
    *(int64_t *)(param_1 + 0xc) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ea08;
        fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ea20;
        fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
        *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ea32;
        fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
    if (*(int32_t *)(&stack0x000000b0 + iVar8 + iVar7) == 0x1000) {
        if (*(int64_t *)(&stack0x00000038 + iVar8 + iVar7) == 0) {
            pcVar5 = *(code **)(arg1 + 0x30);
            if (pcVar5 == (code *)0x0) goto code_r0x00018026eb35;
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb0a;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)(&stack0x000000b8 + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x80);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eb35:
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb3a;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
code_r0x00018026eb3f:
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb52;
                fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000048 + iVar8 + iVar7));
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb64;
                fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
                iVar6 = -2;
                goto code_r0x00018026eb6a;
            }
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eaf1;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                              *(undefined8 *)(&stack0x000000b8 + iVar8 + iVar7));
        }
    } else {
        if (*(int32_t *)(&stack0x000000b0 + iVar8 + iVar7) != 0x2000) {
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ea55;
            fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ea6d;
            fcn.1802295a0(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), *(int64_t *)(&stack0x00000020 + iVar8 + iVar7)
                          , *(int64_t *)(&stack0x00000028 + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), *(int64_t *)(&stack0x00000048 + iVar8 + iVar7)
                         );
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026ea7f;
            fcn.1802296d0(*(int64_t *)(&stack0x00000038 + iVar8 + iVar7));
            goto code_r0x00018026eb6a;
        }
        if (*(int64_t *)(&stack0x00000038 + iVar8 + iVar7) == 0) {
            if (*(int64_t *)(arg1 + 0x30) == 0) goto code_r0x00018026eac2;
            pcVar5 = *(code **)(arg1 + 0x40);
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eac0;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)(&stack0x000000b8 + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x88);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eac2:
                *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eac7;
                fcn.180229480(*(int64_t *)(&stack0x00000018 + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000020 + iVar8 + iVar7));
                goto code_r0x00018026eb3f;
            }
            *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eaa7;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(int64_t *)(&stack0x00000038 + iVar8 + iVar7), 
                              *(undefined8 *)(&stack0x000000b8 + iVar8 + iVar7));
        }
    }
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb1a;
    func_0x000180257a00(*(undefined8 *)(&stack0x000000a8 + iVar8 + iVar7));
    *(undefined8 *)(&stack0x000000a8 + iVar8 + iVar7) = 0;
    if (0 < iVar6) {
        return 1;
    }
code_r0x00018026eb6a:
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb72;
    func_0x000180259930(param_1);
    uVar13 = *(undefined8 *)(&stack0x000000a8 + iVar8 + iVar7);
    *param_1 = 0;
    *(undefined8 *)((int64_t)aiStack_10 + iVar8 + iVar7) = 0x18026eb85;
    func_0x000180257a00(uVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_18026e1c0
// Address: 0x18026e1c0
// Size: 95 bytes
// ============================================================
void fcn.18026e1c0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    undefined8 uVar3;
    int64_t iVar4;
    undefined8 uStack_10;
    
    if (arg1 != 0) {
        uStack_10 = 0x18026e1d0;
        iVar4 = fcn.18045a350();
        iVar4 = -iVar4;
        LOCK();
        piVar1 = (int32_t *)(arg1 + 0x20);
        iVar2 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar2 < 2) {
            uVar3 = *(undefined8 *)(arg1 + 8);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026e1fb;
            fcn.180224990(uVar3, 0x1804e7678, 0x1ba);
            uVar3 = *(undefined8 *)(arg1 + 0x18);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026e204;
            fcn.18027edb0(uVar3);
            *(undefined8 *)((int64_t)&uStack_10 + iVar4) = 0x18026e219;
            fcn.180224990(arg1, 0x1804e7678, 0x1bd);
        }
    }
    return;
}

// ============================================================
// Function: FUN_18026e220
// Address: 0x18026e220
// Size: 920 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.18026e220(int64_t arg_38h, int64_t arg_40h, int64_t arg_50h)
{
    int32_t *piVar1;
    undefined8 uVar2;
    int32_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    undefined4 in_ECX;
    uint32_t uVar7;
    int64_t in_RDX;
    undefined8 *puVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    undefined8 in_R8;
    int32_t iVar11;
    int32_t iVar12;
    int64_t var_8h;
    int64_t var_18h;
    undefined8 uStack_40;
    
    uStack_40 = 0x18026e23a;
    iVar4 = fcn.18045a350();
    iVar4 = -iVar4;
    piVar1 = *(int32_t **)(in_RDX + 0x10);
    iVar11 = 0;
    *(undefined4 *)((int64_t)&arg_40h + iVar4) = 0;
    uVar9 = 0;
    uVar10 = 0;
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e26f;
    puVar5 = (undefined4 *)fcn.180224d60(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4));
    if (puVar5 != (undefined4 *)0x0) {
        puVar5[8] = 1;
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e28a;
        iVar3 = func_0x00018027fb30(in_R8);
        if (iVar3 != 0) {
            *(undefined8 *)(puVar5 + 6) = in_R8;
            *puVar5 = in_ECX;
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e2a1;
            iVar6 = func_0x000180282210(in_RDX);
            *(int64_t *)(puVar5 + 2) = iVar6;
            if (iVar6 != 0) {
                *(undefined8 *)(puVar5 + 4) = *(undefined8 *)(in_RDX + 0x18);
                iVar3 = *piVar1;
                if (iVar3 != 0) {
                    puVar8 = (undefined8 *)(piVar1 + 2);
                    iVar12 = 0;
                    do {
    // switch table (13 cases) at 0x18026e584
                        switch(iVar3) {
                        case 1:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 10) == 0) {
                                iVar11 = iVar11 + 1;
                                *(undefined8 *)(puVar5 + 10) = *puVar8;
                            }
                            break;
                        case 2:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0xc) == 0) {
                                uVar9 = uVar9 + 1;
                                *(undefined8 *)(puVar5 + 0xc) = *puVar8;
                            }
                            break;
                        case 3:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0xe) == 0) {
                                uVar9 = uVar9 + 1;
                                *(undefined8 *)(puVar5 + 0xe) = *puVar8;
                            }
                            break;
                        case 4:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x10) == 0) {
                                uVar10 = uVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x10) = *puVar8;
                            }
                            break;
                        case 5:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x12) == 0) {
                                uVar10 = uVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x12) = *puVar8;
                            }
                            break;
                        case 6:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x14) == 0) {
                                iVar11 = iVar11 + 1;
                                *(undefined8 *)(puVar5 + 0x14) = *puVar8;
                            }
                            break;
                        case 7:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x16) == 0) {
                                *(undefined8 *)(puVar5 + 0x16) = *puVar8;
                            }
                            break;
                        case 8:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x18) == 0) {
                                uVar7 = uVar7 + 1;
                                *(undefined8 *)(puVar5 + 0x18) = *puVar8;
                                *(uint32_t *)((int64_t)&arg_40h + iVar4) = uVar7;
                            }
                            break;
                        case 9:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x1a) == 0) {
                                uVar7 = uVar7 + 1;
                                *(undefined8 *)(puVar5 + 0x1a) = *puVar8;
                                *(uint32_t *)((int64_t)&arg_40h + iVar4) = uVar7;
                            }
                            break;
                        case 10:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x1c) == 0) {
                                iVar12 = iVar12 + 1;
                                *(undefined8 *)(puVar5 + 0x1c) = *puVar8;
                            }
                            break;
                        case 0xb:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x1e) == 0) {
                                iVar12 = iVar12 + 1;
                                *(undefined8 *)(puVar5 + 0x1e) = *puVar8;
                            }
                            break;
                        case 0xc:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x20) == 0) {
                                uVar9 = uVar9 + 1;
                                *(undefined8 *)(puVar5 + 0x20) = *puVar8;
                            }
                            break;
                        case 0xd:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                            if (*(int64_t *)(puVar5 + 0x22) == 0) {
                                uVar10 = uVar10 + 1;
                                *(undefined8 *)(puVar5 + 0x22) = *puVar8;
                            }
                            break;
                        default:
                            uVar7 = *(uint32_t *)((int64_t)&arg_40h + iVar4);
                        }
                        iVar3 = *(int32_t *)(puVar8 + 1);
                        puVar8 = puVar8 + 2;
                    } while (iVar3 != 0);
                    *(int32_t *)((int64_t)&arg_50h + iVar4) = iVar12;
                    if (((((iVar11 == 2) && ((uVar9 & 0xfffffffc) == 0)) && (uVar9 != 1)) &&
                        (((uVar10 & 0xfffffffc) == 0 && (uVar10 != 1)))) &&
                       ((uVar9 == uVar10 &&
                        (((uVar7 & 0xfffffffd) == 0 && ((*(uint32_t *)((int64_t)&arg_50h + iVar4) & 0xfffffffd) == 0))))
                       )) {
                        return puVar5;
                    }
                }
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e4b9;
                fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e4d1;
                fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                              *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                              *(int64_t *)((int64_t)&var_18h + iVar4));
                *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e4e3;
                fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
            }
            LOCK();
            piVar1 = puVar5 + 8;
            iVar11 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (1 < iVar11) {
                return (undefined4 *)0x0;
            }
            uVar2 = *(undefined8 *)(puVar5 + 2);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e508;
            fcn.180224990(uVar2, 0x1804e7678, 0x1ba);
            uVar2 = *(undefined8 *)(puVar5 + 6);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e511;
            fcn.18027edb0(uVar2);
            *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e526;
            fcn.180224990(puVar5, 0x1804e7678, 0x1bd);
            return (undefined4 *)0x0;
        }
        *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e53d;
        fcn.180224990(puVar5, 0x1804e7678, 0x126);
    }
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e542;
    fcn.180229480(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4));
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e55a;
    fcn.1802295a0(*(int64_t *)(&stack0xffffffffffffffe8 + iVar4), *(int64_t *)(&stack0xfffffffffffffff0 + iVar4), 
                  *(int64_t *)(&stack0xfffffffffffffff8 + iVar4), *(int64_t *)(&stack0x00000000 + iVar4), 
                  *(int64_t *)((int64_t)&var_18h + iVar4));
    *(undefined8 *)((int64_t)&uStack_40 + iVar4) = 0x18026e56c;
    fcn.1802296d0(*(int64_t *)((int64_t)&var_8h + iVar4));
    return (undefined4 *)0x0;
}

// ============================================================
// Function: FUN_18026e5c0
// Address: 0x18026e5c0
// Size: 86 bytes
// ============================================================
int32_t fcn.18026e0a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h,
                     int64_t arg_68h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
                     int64_t arg_168h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t arg1;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined4 *in_RCX;
    undefined4 uVar14;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar16;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18026e0aa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar15 = (int32_t *)0x0;
    uVar14 = 0x2000;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0x2000;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x18026e5e0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    arg1 = 0;
    iVar16 = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    uVar13 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar8 + iVar7) = 0;
    if ((in_RCX == (undefined4 *)0x0) || (*(int64_t *)(in_RCX + 6) == 0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb92;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebbc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e625;
    func_0x000180259930();
    piVar2 = *(int32_t **)(in_RCX + 0x22);
    *in_RCX = uVar14;
    if (piVar2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e639;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e651;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e663;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    if ((piVar15 != (int32_t *)0x0) && (*piVar15 != *piVar2)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e678;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e690;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6a2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    if ((*(int64_t *)(piVar2 + 0x18) != 0) && (*(int64_t *)(piVar2 + 0x18) != *(int64_t *)(in_RCX + 8))) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6cf;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6f9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    uVar10 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e70c;
    iVar9 = func_0x00018029f2b0(uVar10, 0xe);
    *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e71b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e733;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e745;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    iVar16 = 1;
    iVar9 = 0;
    do {
        if (iVar9 != 0) goto code_r0x00018026e9e1;
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar1 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar1 < 2) {
                uVar10 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e794;
                fcn.180224990(uVar10, 0x1804e7678, 0x1ba);
                uVar10 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e79d;
                fcn.18027edb0(uVar10);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7b2;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7bf;
        func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
        if (iVar16 == 1) {
            uVar10 = *(undefined8 *)(in_RCX + 4);
            uVar3 = *(undefined8 *)(in_RCX + 2);
            *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
            *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
            *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e872;
            arg1 = func_0x000180280c20(uVar3, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
            if (arg1 != 0) {
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                goto code_r0x00018026e882;
            }
        } else {
            if (iVar16 == 2) {
                uVar13 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7e3;
                uVar13 = func_0x0001801dd170(uVar13);
                uVar10 = *(undefined8 *)(in_RCX + 4);
                *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
                *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e820;
                arg1 = func_0x000180280ca0(uVar13, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
                if (arg1 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e82d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x00018026eb3f;
                }
            } else if (arg1 == 0) goto code_r0x00018026e916;
code_r0x00018026e882:
            uVar10 = *(undefined8 *)(in_RCX + 8);
            uVar3 = *(undefined8 *)(in_RCX + 4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e88f;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e89d;
            iVar11 = func_0x000180257b60(uVar13, uVar10, uVar3);
            *(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) = iVar11;
            if (iVar11 != 0) {
                uVar10 = *(undefined8 *)(in_RCX + 4);
                uVar3 = *(undefined8 *)(in_RCX + 2);
                uVar4 = *(undefined8 *)(in_RCX + 0x22);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8c9;
                iVar9 = func_0x000180230ea0(uVar4, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                if ((iVar9 != 0) && (iVar12 = *(int64_t *)((int64_t)&arg_c0h + iVar8 + iVar7), iVar12 != 0)) {
                    uVar10 = *(undefined8 *)(in_RCX + 4);
                    uVar3 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8f6;
                    iVar12 = func_0x000180230ea0(iVar12, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                    *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar12;
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ad;
                        fcn.18026df60(arg1);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9b2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9dc;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                        goto code_r0x00018026eb6a;
                    }
                }
            }
            if (*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e916;
                func_0x000180257a00(iVar11);
            }
        }
code_r0x00018026e916:
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    if (iVar9 == 0) {
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar16 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar16 < 2) {
                uVar13 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e953;
                fcn.180224990(uVar13, 0x1804e7678, 0x1ba);
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e95c;
                fcn.18027edb0(uVar13);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e971;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e976;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e98e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9a0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
code_r0x00018026e9e1:
    *(int64_t *)(in_RCX + 10) = arg1;
    uVar13 = *(undefined8 *)(arg1 + 0x18);
    pcVar5 = *(code **)(arg1 + 0x28);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f2;
    uVar13 = func_0x00018027e810(uVar13);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f7;
    iVar11 = (*pcVar5)(uVar13);
    *(int64_t *)(in_RCX + 0xc) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea08;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea20;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea32;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
    iVar16 = *(int32_t *)((int64_t)&arg_b0h + iVar8 + iVar7);
    if (iVar16 == 0x1000) {
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            pcVar5 = *(code **)(arg1 + 0x30);
            if (pcVar5 == (code *)0x0) goto code_r0x00018026eb35;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb0a;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x80);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eb35:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb3a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x00018026eb3f:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb52;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb64;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                iVar6 = -2;
                goto code_r0x00018026eb6a;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaf1;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    } else {
        if (iVar16 != 0x2000) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea55;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea7f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            goto code_r0x00018026eb6a;
        }
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            if (*(int64_t *)(arg1 + 0x30) == 0) goto code_r0x00018026eac2;
            pcVar5 = *(code **)(arg1 + 0x40);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac0;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x88);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eac2:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x00018026eb3f;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaa7;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb1a;
    func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    if (0 < iVar6) {
        return 1;
    }
code_r0x00018026eb6a:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb72;
    func_0x000180259930(in_RCX);
    uVar13 = *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb85;
    func_0x000180257a00(uVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_18026e616
// Address: 0x18026e616
// Size: 165 bytes
// ============================================================
int32_t fcn.18026e0a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h,
                     int64_t arg_68h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
                     int64_t arg_168h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t arg1;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined4 *in_RCX;
    undefined4 uVar14;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar16;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18026e0aa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar15 = (int32_t *)0x0;
    uVar14 = 0x2000;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0x2000;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x18026e5e0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    arg1 = 0;
    iVar16 = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    uVar13 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar8 + iVar7) = 0;
    if ((in_RCX == (undefined4 *)0x0) || (*(int64_t *)(in_RCX + 6) == 0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb92;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebbc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e625;
    func_0x000180259930();
    piVar2 = *(int32_t **)(in_RCX + 0x22);
    *in_RCX = uVar14;
    if (piVar2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e639;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e651;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e663;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    if ((piVar15 != (int32_t *)0x0) && (*piVar15 != *piVar2)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e678;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e690;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6a2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    if ((*(int64_t *)(piVar2 + 0x18) != 0) && (*(int64_t *)(piVar2 + 0x18) != *(int64_t *)(in_RCX + 8))) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6cf;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6f9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    uVar10 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e70c;
    iVar9 = func_0x00018029f2b0(uVar10, 0xe);
    *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e71b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e733;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e745;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    iVar16 = 1;
    iVar9 = 0;
    do {
        if (iVar9 != 0) goto code_r0x00018026e9e1;
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar1 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar1 < 2) {
                uVar10 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e794;
                fcn.180224990(uVar10, 0x1804e7678, 0x1ba);
                uVar10 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e79d;
                fcn.18027edb0(uVar10);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7b2;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7bf;
        func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
        if (iVar16 == 1) {
            uVar10 = *(undefined8 *)(in_RCX + 4);
            uVar3 = *(undefined8 *)(in_RCX + 2);
            *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
            *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
            *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e872;
            arg1 = func_0x000180280c20(uVar3, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
            if (arg1 != 0) {
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                goto code_r0x00018026e882;
            }
        } else {
            if (iVar16 == 2) {
                uVar13 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7e3;
                uVar13 = func_0x0001801dd170(uVar13);
                uVar10 = *(undefined8 *)(in_RCX + 4);
                *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
                *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e820;
                arg1 = func_0x000180280ca0(uVar13, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
                if (arg1 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e82d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x00018026eb3f;
                }
            } else if (arg1 == 0) goto code_r0x00018026e916;
code_r0x00018026e882:
            uVar10 = *(undefined8 *)(in_RCX + 8);
            uVar3 = *(undefined8 *)(in_RCX + 4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e88f;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e89d;
            iVar11 = func_0x000180257b60(uVar13, uVar10, uVar3);
            *(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) = iVar11;
            if (iVar11 != 0) {
                uVar10 = *(undefined8 *)(in_RCX + 4);
                uVar3 = *(undefined8 *)(in_RCX + 2);
                uVar4 = *(undefined8 *)(in_RCX + 0x22);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8c9;
                iVar9 = func_0x000180230ea0(uVar4, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                if ((iVar9 != 0) && (iVar12 = *(int64_t *)((int64_t)&arg_c0h + iVar8 + iVar7), iVar12 != 0)) {
                    uVar10 = *(undefined8 *)(in_RCX + 4);
                    uVar3 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8f6;
                    iVar12 = func_0x000180230ea0(iVar12, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                    *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar12;
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ad;
                        fcn.18026df60(arg1);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9b2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9dc;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                        goto code_r0x00018026eb6a;
                    }
                }
            }
            if (*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e916;
                func_0x000180257a00(iVar11);
            }
        }
code_r0x00018026e916:
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    if (iVar9 == 0) {
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar16 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar16 < 2) {
                uVar13 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e953;
                fcn.180224990(uVar13, 0x1804e7678, 0x1ba);
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e95c;
                fcn.18027edb0(uVar13);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e971;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e976;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e98e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9a0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
code_r0x00018026e9e1:
    *(int64_t *)(in_RCX + 10) = arg1;
    uVar13 = *(undefined8 *)(arg1 + 0x18);
    pcVar5 = *(code **)(arg1 + 0x28);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f2;
    uVar13 = func_0x00018027e810(uVar13);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f7;
    iVar11 = (*pcVar5)(uVar13);
    *(int64_t *)(in_RCX + 0xc) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea08;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea20;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea32;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
    iVar16 = *(int32_t *)((int64_t)&arg_b0h + iVar8 + iVar7);
    if (iVar16 == 0x1000) {
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            pcVar5 = *(code **)(arg1 + 0x30);
            if (pcVar5 == (code *)0x0) goto code_r0x00018026eb35;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb0a;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x80);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eb35:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb3a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x00018026eb3f:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb52;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb64;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                iVar6 = -2;
                goto code_r0x00018026eb6a;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaf1;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    } else {
        if (iVar16 != 0x2000) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea55;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea7f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            goto code_r0x00018026eb6a;
        }
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            if (*(int64_t *)(arg1 + 0x30) == 0) goto code_r0x00018026eac2;
            pcVar5 = *(code **)(arg1 + 0x40);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac0;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x88);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eac2:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x00018026eb3f;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaa7;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb1a;
    func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    if (0 < iVar6) {
        return 1;
    }
code_r0x00018026eb6a:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb72;
    func_0x000180259930(in_RCX);
    uVar13 = *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb85;
    func_0x000180257a00(uVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_18026e6bb
// Address: 0x18026e6bb
// Size: 1234 bytes
// ============================================================
int32_t fcn.18026e0a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h,
                     int64_t arg_68h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
                     int64_t arg_168h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t arg1;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined4 *in_RCX;
    undefined4 uVar14;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar16;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18026e0aa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar15 = (int32_t *)0x0;
    uVar14 = 0x2000;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0x2000;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x18026e5e0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    arg1 = 0;
    iVar16 = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    uVar13 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar8 + iVar7) = 0;
    if ((in_RCX == (undefined4 *)0x0) || (*(int64_t *)(in_RCX + 6) == 0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb92;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebbc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e625;
    func_0x000180259930();
    piVar2 = *(int32_t **)(in_RCX + 0x22);
    *in_RCX = uVar14;
    if (piVar2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e639;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e651;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e663;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    if ((piVar15 != (int32_t *)0x0) && (*piVar15 != *piVar2)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e678;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e690;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6a2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    if ((*(int64_t *)(piVar2 + 0x18) != 0) && (*(int64_t *)(piVar2 + 0x18) != *(int64_t *)(in_RCX + 8))) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6cf;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6f9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    uVar10 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e70c;
    iVar9 = func_0x00018029f2b0(uVar10, 0xe);
    *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e71b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e733;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e745;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    iVar16 = 1;
    iVar9 = 0;
    do {
        if (iVar9 != 0) goto code_r0x00018026e9e1;
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar1 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar1 < 2) {
                uVar10 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e794;
                fcn.180224990(uVar10, 0x1804e7678, 0x1ba);
                uVar10 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e79d;
                fcn.18027edb0(uVar10);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7b2;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7bf;
        func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
        if (iVar16 == 1) {
            uVar10 = *(undefined8 *)(in_RCX + 4);
            uVar3 = *(undefined8 *)(in_RCX + 2);
            *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
            *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
            *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e872;
            arg1 = func_0x000180280c20(uVar3, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
            if (arg1 != 0) {
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                goto code_r0x00018026e882;
            }
        } else {
            if (iVar16 == 2) {
                uVar13 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7e3;
                uVar13 = func_0x0001801dd170(uVar13);
                uVar10 = *(undefined8 *)(in_RCX + 4);
                *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
                *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e820;
                arg1 = func_0x000180280ca0(uVar13, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
                if (arg1 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e82d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x00018026eb3f;
                }
            } else if (arg1 == 0) goto code_r0x00018026e916;
code_r0x00018026e882:
            uVar10 = *(undefined8 *)(in_RCX + 8);
            uVar3 = *(undefined8 *)(in_RCX + 4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e88f;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e89d;
            iVar11 = func_0x000180257b60(uVar13, uVar10, uVar3);
            *(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) = iVar11;
            if (iVar11 != 0) {
                uVar10 = *(undefined8 *)(in_RCX + 4);
                uVar3 = *(undefined8 *)(in_RCX + 2);
                uVar4 = *(undefined8 *)(in_RCX + 0x22);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8c9;
                iVar9 = func_0x000180230ea0(uVar4, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                if ((iVar9 != 0) && (iVar12 = *(int64_t *)((int64_t)&arg_c0h + iVar8 + iVar7), iVar12 != 0)) {
                    uVar10 = *(undefined8 *)(in_RCX + 4);
                    uVar3 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8f6;
                    iVar12 = func_0x000180230ea0(iVar12, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                    *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar12;
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ad;
                        fcn.18026df60(arg1);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9b2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9dc;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                        goto code_r0x00018026eb6a;
                    }
                }
            }
            if (*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e916;
                func_0x000180257a00(iVar11);
            }
        }
code_r0x00018026e916:
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    if (iVar9 == 0) {
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar16 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar16 < 2) {
                uVar13 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e953;
                fcn.180224990(uVar13, 0x1804e7678, 0x1ba);
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e95c;
                fcn.18027edb0(uVar13);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e971;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e976;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e98e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9a0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
code_r0x00018026e9e1:
    *(int64_t *)(in_RCX + 10) = arg1;
    uVar13 = *(undefined8 *)(arg1 + 0x18);
    pcVar5 = *(code **)(arg1 + 0x28);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f2;
    uVar13 = func_0x00018027e810(uVar13);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f7;
    iVar11 = (*pcVar5)(uVar13);
    *(int64_t *)(in_RCX + 0xc) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea08;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea20;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea32;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
    iVar16 = *(int32_t *)((int64_t)&arg_b0h + iVar8 + iVar7);
    if (iVar16 == 0x1000) {
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            pcVar5 = *(code **)(arg1 + 0x30);
            if (pcVar5 == (code *)0x0) goto code_r0x00018026eb35;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb0a;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x80);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eb35:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb3a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x00018026eb3f:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb52;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb64;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                iVar6 = -2;
                goto code_r0x00018026eb6a;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaf1;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    } else {
        if (iVar16 != 0x2000) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea55;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea7f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            goto code_r0x00018026eb6a;
        }
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            if (*(int64_t *)(arg1 + 0x30) == 0) goto code_r0x00018026eac2;
            pcVar5 = *(code **)(arg1 + 0x40);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac0;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x88);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eac2:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x00018026eb3f;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaa7;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb1a;
    func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    if (0 < iVar6) {
        return 1;
    }
code_r0x00018026eb6a:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb72;
    func_0x000180259930(in_RCX);
    uVar13 = *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb85;
    func_0x000180257a00(uVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_18026eb8d
// Address: 0x18026eb8d
// Size: 62 bytes
// ============================================================
int32_t fcn.18026e0a0(int64_t arg_28h, int64_t arg_38h, int64_t arg_40h, int64_t arg_48h, int64_t arg_60h,
                     int64_t arg_68h, int64_t arg_a8h, int64_t arg_b0h, int64_t arg_b8h, int64_t arg_c0h,
                     int64_t arg_168h)
{
    int32_t iVar1;
    int32_t *piVar2;
    undefined8 uVar3;
    undefined8 uVar4;
    code *pcVar5;
    int32_t iVar6;
    int64_t iVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t arg1;
    undefined8 uVar10;
    int64_t iVar11;
    int64_t iVar12;
    undefined8 uVar13;
    undefined4 *in_RCX;
    undefined4 uVar14;
    undefined8 in_RDX;
    undefined8 unaff_RBX;
    undefined8 unaff_RBP;
    undefined8 unaff_RSI;
    undefined8 unaff_RDI;
    int32_t *piVar15;
    undefined8 unaff_R12;
    undefined8 unaff_R13;
    undefined8 unaff_R14;
    int32_t iVar16;
    undefined8 unaff_R15;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 auStack_10 [2];
    
    auStack_10[1] = 0x18026e0aa;
    iVar7 = fcn.18045a350();
    iVar7 = -iVar7;
    piVar15 = (int32_t *)0x0;
    uVar14 = 0x2000;
    *(undefined8 *)((int64_t)&arg_48h + iVar7) = 0;
    *(undefined8 *)((int64_t)&arg_40h + iVar7) = in_RDX;
    *(undefined4 *)((int64_t)&arg_38h + iVar7) = 0x2000;
    *(undefined8 *)((int64_t)&var_20h + iVar7) = unaff_RBX;
    *(undefined8 *)((int64_t)&var_18h + iVar7) = unaff_RBP;
    *(undefined8 *)(&stack0x00000010 + iVar7) = unaff_RSI;
    *(undefined8 *)(&stack0x00000008 + iVar7) = unaff_RDI;
    *(undefined8 *)(&stack0x00000000 + iVar7) = unaff_R14;
    *(undefined8 *)((int64_t)auStack_10 + iVar7 + 8) = unaff_R15;
    *(undefined8 *)((int64_t)auStack_10 + iVar7) = 0x18026e5e0;
    iVar8 = fcn.18045a350();
    iVar8 = -iVar8;
    arg1 = 0;
    iVar16 = 0;
    iVar6 = 0;
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    uVar13 = 0;
    *(undefined8 *)((int64_t)&arg_38h + iVar8 + iVar7) = 0;
    if ((in_RCX == (undefined4 *)0x0) || (*(int64_t *)(in_RCX + 6) == 0)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb92;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebaa;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ebbc;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    *(undefined8 *)((int64_t)&arg_68h + iVar8 + iVar7) = unaff_R12;
    *(undefined8 *)((int64_t)&arg_60h + iVar8 + iVar7) = unaff_R13;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e625;
    func_0x000180259930();
    piVar2 = *(int32_t **)(in_RCX + 0x22);
    *in_RCX = uVar14;
    if (piVar2 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e639;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e651;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e663;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    if ((piVar15 != (int32_t *)0x0) && (*piVar15 != *piVar2)) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e678;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e690;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6a2;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        return 0;
    }
    if ((*(int64_t *)(piVar2 + 0x18) != 0) && (*(int64_t *)(piVar2 + 0x18) != *(int64_t *)(in_RCX + 8))) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6cf;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6e7;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e6f9;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    uVar10 = *(undefined8 *)(in_RCX + 8);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e70c;
    iVar9 = func_0x00018029f2b0(uVar10, 0xe);
    *(int64_t *)((int64_t)&arg_40h + iVar8 + iVar7) = iVar9;
    if (iVar9 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e71b;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e733;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e745;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        iVar6 = iVar16;
        goto code_r0x00018026eb6a;
    }
    iVar16 = 1;
    iVar9 = 0;
    do {
        if (iVar9 != 0) goto code_r0x00018026e9e1;
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar1 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar1 < 2) {
                uVar10 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e794;
                fcn.180224990(uVar10, 0x1804e7678, 0x1ba);
                uVar10 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e79d;
                fcn.18027edb0(uVar10);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7b2;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7bf;
        func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
        if (iVar16 == 1) {
            uVar10 = *(undefined8 *)(in_RCX + 4);
            uVar3 = *(undefined8 *)(in_RCX + 2);
            *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
            *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
            *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e872;
            arg1 = func_0x000180280c20(uVar3, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
            if (arg1 != 0) {
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                goto code_r0x00018026e882;
            }
        } else {
            if (iVar16 == 2) {
                uVar13 = *(undefined8 *)(in_RCX + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e7e3;
                uVar13 = func_0x0001801dd170(uVar13);
                uVar10 = *(undefined8 *)(in_RCX + 4);
                *(code **)((int64_t)&arg_28h + iVar8 + iVar7) = fcn.18026e1c0;
                *(undefined8 *)((int64_t)&var_20h + iVar8 + iVar7) = 0x180248230;
                *(code **)((int64_t)&var_18h + iVar8 + iVar7) = fcn.18026e220;
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e820;
                arg1 = func_0x000180280ca0(uVar13, 0xe, *(undefined8 *)((int64_t)&arg_40h + iVar8 + iVar7), uVar10);
                if (arg1 == 0) {
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e82d;
                    fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                  *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                    goto code_r0x00018026eb3f;
                }
            } else if (arg1 == 0) goto code_r0x00018026e916;
code_r0x00018026e882:
            uVar10 = *(undefined8 *)(in_RCX + 8);
            uVar3 = *(undefined8 *)(in_RCX + 4);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e88f;
            uVar10 = func_0x0001801dd6c0(uVar10);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e89d;
            iVar11 = func_0x000180257b60(uVar13, uVar10, uVar3);
            *(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) = iVar11;
            if (iVar11 != 0) {
                uVar10 = *(undefined8 *)(in_RCX + 4);
                uVar3 = *(undefined8 *)(in_RCX + 2);
                uVar4 = *(undefined8 *)(in_RCX + 0x22);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8c9;
                iVar9 = func_0x000180230ea0(uVar4, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                if ((iVar9 != 0) && (iVar12 = *(int64_t *)((int64_t)&arg_c0h + iVar8 + iVar7), iVar12 != 0)) {
                    uVar10 = *(undefined8 *)(in_RCX + 4);
                    uVar3 = *(undefined8 *)(in_RCX + 2);
                    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e8f6;
                    iVar12 = func_0x000180230ea0(iVar12, uVar3, (int64_t)&arg_a8h + iVar8 + iVar7, uVar10);
                    *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7) = iVar12;
                    if (iVar12 == 0) {
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ad;
                        fcn.18026df60(arg1);
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9b2;
                        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9ca;
                        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                                      *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9dc;
                        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                        goto code_r0x00018026eb6a;
                    }
                }
            }
            if (*(int64_t *)((int64_t)&arg_a8h + iVar8 + iVar7) == 0) {
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e916;
                func_0x000180257a00(iVar11);
            }
        }
code_r0x00018026e916:
        iVar16 = iVar16 + 1;
    } while (iVar16 < 3);
    if (iVar9 == 0) {
        if (arg1 != 0) {
            LOCK();
            piVar15 = (int32_t *)(arg1 + 0x20);
            iVar16 = *piVar15;
            *piVar15 = *piVar15 + -1;
            UNLOCK();
            if (iVar16 < 2) {
                uVar13 = *(undefined8 *)(arg1 + 8);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e953;
                fcn.180224990(uVar13, 0x1804e7678, 0x1ba);
                uVar13 = *(undefined8 *)(arg1 + 0x18);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e95c;
                fcn.18027edb0(uVar13);
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e971;
                fcn.180224990(arg1, 0x1804e7678, 0x1bd);
            }
        }
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e976;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e98e;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9a0;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
code_r0x00018026e9e1:
    *(int64_t *)(in_RCX + 10) = arg1;
    uVar13 = *(undefined8 *)(arg1 + 0x18);
    pcVar5 = *(code **)(arg1 + 0x28);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f2;
    uVar13 = func_0x00018027e810(uVar13);
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026e9f7;
    iVar11 = (*pcVar5)(uVar13);
    *(int64_t *)(in_RCX + 0xc) = iVar11;
    if (iVar11 == 0) {
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea08;
        fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea20;
        fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                      *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
        *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea32;
        fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
        goto code_r0x00018026eb6a;
    }
    iVar16 = *(int32_t *)((int64_t)&arg_b0h + iVar8 + iVar7);
    if (iVar16 == 0x1000) {
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            pcVar5 = *(code **)(arg1 + 0x30);
            if (pcVar5 == (code *)0x0) goto code_r0x00018026eb35;
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb0a;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x80);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eb35:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb3a;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
code_r0x00018026eb3f:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb52;
                fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                              *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb64;
                fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
                iVar6 = -2;
                goto code_r0x00018026eb6a;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaf1;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    } else {
        if (iVar16 != 0x2000) {
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea55;
            fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea6d;
            fcn.1802295a0(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_28h + iVar8 + iVar7), 
                          *(int64_t *)(&stack0x00000030 + iVar8 + iVar7), 
                          *(int64_t *)((int64_t)&arg_48h + iVar8 + iVar7));
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026ea7f;
            fcn.1802296d0(*(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7));
            goto code_r0x00018026eb6a;
        }
        iVar12 = *(int64_t *)((int64_t)&arg_38h + iVar8 + iVar7);
        if (iVar12 == 0) {
            if (*(int64_t *)(arg1 + 0x30) == 0) goto code_r0x00018026eac2;
            pcVar5 = *(code **)(arg1 + 0x40);
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac0;
            iVar6 = (*pcVar5)(iVar11, iVar9, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        } else {
            pcVar5 = *(code **)(arg1 + 0x88);
            if (pcVar5 == (code *)0x0) {
code_r0x00018026eac2:
                *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eac7;
                fcn.180229480(*(int64_t *)((int64_t)&var_18h + iVar8 + iVar7), 
                              *(int64_t *)((int64_t)&var_20h + iVar8 + iVar7));
                goto code_r0x00018026eb3f;
            }
            *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eaa7;
            iVar6 = (*pcVar5)(iVar11, iVar9, iVar12, *(undefined8 *)((int64_t)&arg_b8h + iVar8 + iVar7));
        }
    }
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb1a;
    func_0x000180257a00(*(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7));
    *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7) = 0;
    if (0 < iVar6) {
        return 1;
    }
code_r0x00018026eb6a:
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb72;
    func_0x000180259930(in_RCX);
    uVar13 = *(undefined8 *)((int64_t)&arg_a8h + iVar8 + iVar7);
    *in_RCX = 0;
    *(undefined8 *)((int64_t)auStack_10 + iVar8 + iVar7) = 0x18026eb85;
    func_0x000180257a00(uVar13);
    return iVar6;
}

// ============================================================
// Function: FUN_18026ebd0
// Address: 0x18026ebd0
// Size: 27 bytes
// ============================================================
undefined8 fcn.18026ebd0(int64_t arg_30h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    code *UNRECOVERED_JUMPTABLE;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x18026ec20;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = *(int32_t **)(in_RCX + 0x88);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ec37;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ec4f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ec61;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ec7b;
    uVar4 = fcn.18026edf0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                         );
    if ((int32_t)uVar4 == -1) {
        if ((*piVar1 != 0) &&
           ((UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x78) + 0xf0),
            UNRECOVERED_JUMPTABLE != (code *)0x0 ||
            ((*(int64_t *)(piVar1 + 2) != 0 &&
             (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(piVar1 + 2) + 0xf0), UNRECOVERED_JUMPTABLE != (code *)0x0)
             ))))) {
    // WARNING: Could not recover jumptable at 0x00018026eca2. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (*UNRECOVERED_JUMPTABLE)(piVar1);
            return uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ecbf;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ecd7;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ece9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        uVar4 = 0xfffffffe;
    }
    return uVar4;
}

// ============================================================
// Function: FUN_18026ebf0
// Address: 0x18026ebf0
// Size: 24 bytes
// ============================================================
undefined8 fcn.18026ebf0(int64_t arg_30h, int64_t arg_50h)
{
    int32_t *piVar1;
    int64_t iVar2;
    int64_t iVar3;
    undefined8 uVar4;
    int64_t in_RCX;
    code *UNRECOVERED_JUMPTABLE;
    undefined8 unaff_RBX;
    undefined8 unaff_RDI;
    undefined8 auStackX_18 [2];
    
    iVar2 = fcn.18045a350();
    iVar2 = -iVar2;
    *(undefined8 *)((int64_t)&arg_30h + iVar2) = unaff_RBX;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2 + 8) = unaff_RDI;
    *(undefined8 *)((int64_t)auStackX_18 + iVar2) = 0x18026ed10;
    iVar3 = fcn.18045a350();
    iVar3 = -iVar3;
    piVar1 = *(int32_t **)(in_RCX + 0x88);
    if (piVar1 == (int32_t *)0x0) {
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ed27;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ed3f;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ed51;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        return 0;
    }
    *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026ed6b;
    uVar4 = fcn.18026edf0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2)
                         );
    if ((int32_t)uVar4 == -1) {
        if ((*piVar1 != 0) &&
           ((UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(in_RCX + 0x78) + 0xe8),
            UNRECOVERED_JUMPTABLE != (code *)0x0 ||
            ((*(int64_t *)(piVar1 + 2) != 0 &&
             (UNRECOVERED_JUMPTABLE = *(code **)(*(int64_t *)(piVar1 + 2) + 0xe8), UNRECOVERED_JUMPTABLE != (code *)0x0)
             ))))) {
    // WARNING: Could not recover jumptable at 0x00018026ed92. Too many branches
    // WARNING: Treating indirect jump as call
            uVar4 = (*UNRECOVERED_JUMPTABLE)(piVar1);
            return uVar4;
        }
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026edaf;
        fcn.180229480(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026edc7;
        fcn.1802295a0(*(int64_t *)(&stack0x00000040 + iVar3 + iVar2), *(int64_t *)(&stack0x00000048 + iVar3 + iVar2), 
                      *(int64_t *)((int64_t)&arg_50h + iVar3 + iVar2), *(int64_t *)(&stack0x00000058 + iVar3 + iVar2), 
                      *(int64_t *)(&stack0x00000070 + iVar3 + iVar2));
        *(undefined8 *)((int64_t)auStackX_18 + iVar3 + iVar2) = 0x18026edd9;
        fcn.1802296d0(*(int64_t *)(&stack0x00000060 + iVar3 + iVar2));
        uVar4 = 0xfffffffe;
    }
    return uVar4;
}

