// Chunk 32 - 50 functions

// ============================================================
// Function: FUN_180066619
// Address: 0x180066619
// Size: 1 bytes
// ============================================================
void fcn.180066619(void)
{
    return;
}

// ============================================================
// Function: FUN_180066620
// Address: 0x180066620
// Size: 25 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.180066620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    if (arg2 != 0) {
        var_18h = arg3;
        var_20h = arg4;
        fcn.1800102c0();
        fcn.180467554(0, (int64_t)&var_18h);
    }
    return;
}

// ============================================================
// Function: FUN_180066639
// Address: 0x180066639
// Size: 83 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.180066620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    if (arg2 != 0) {
        var_18h = arg3;
        var_20h = arg4;
        fcn.1800102c0();
        fcn.180467554(0, (int64_t)&var_18h);
    }
    return;
}

// ============================================================
// Function: FUN_18006668c
// Address: 0x18006668c
// Size: 1 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ffh
// WARNING: [rz-ghidra] Detected overlap for variable var_4fbh
// WARNING: [rz-ghidra] Detected overlap for variable var_4f9h
// WARNING: [rz-ghidra] Detected overlap for variable var_500h
// WARNING: [rz-ghidra] Detected overlap for variable var_494h
// WARNING: [rz-ghidra] Detected overlap for variable var_490h
// WARNING: [rz-ghidra] Detected overlap for variable var_46ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4c4h
// WARNING: [rz-ghidra] Removing arg arg_84h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_4cch

void fcn.180066620(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_10h;
    
    if (arg2 != 0) {
        var_18h = arg3;
        var_20h = arg4;
        fcn.1800102c0();
        fcn.180467554(0, (int64_t)&var_18h);
    }
    return;
}

// ============================================================
// Function: FUN_180066690
// Address: 0x180066690
// Size: 133 bytes
// ============================================================
undefined fcn.180066690(int64_t arg1)
{
    int64_t *piVar1;
    uint64_t uVar2;
    int64_t var_8h;
    
    piVar1 = (int64_t *)fcn.180013b20(&var_8h);
    uVar2 = *piVar1 / 1000000 - *(int64_t *)(arg1 + 0x2008);
    if ((uint64_t)(int64_t)(*(int32_t *)(arg1 + 0x2004) + 300) < uVar2) {
        return 3;
    }
    if ((uint64_t)(int64_t)(*(int32_t *)(arg1 + 0x2004) + 0x96) < uVar2) {
        return 2;
    }
    return 0x96 < uVar2;
}

// ============================================================
// Function: FUN_180066720
// Address: 0x180066720
// Size: 169 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1bch
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ach
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.180066720(void)
{
    int32_t *piVar1;
    int32_t *arg1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_1f8 [32];
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    float var_1b8h;
    int64_t var_1b4h;
    float var_1ach;
    int64_t var_1a8h;
    undefined4 uStack_1a0;
    undefined4 uStack_19c;
    undefined4 uStack_198;
    int64_t var_190h;
    undefined4 var_188h;
    undefined4 var_184h;
    float var_180h;
    float var_17ch;
    float fStack_178;
    float fStack_174;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    float fStack_168;
    float fStack_164;
    float fStack_160;
    float fStack_15c;
    undefined8 uStack_158;
    undefined4 uStack_150;
    float fStack_14c;
    undefined4 uStack_148;
    undefined4 uStack_144;
    undefined4 uStack_140;
    float fStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    undefined4 uStack_130;
    float fStack_12c;
    undefined auStack_128 [8];
    undefined auStack_120 [8];
    undefined auStack_118 [8];
    undefined auStack_110 [56];
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_6ch;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1f8;
    iVar11 = 0;
    fVar15 = 0.0;
    var_1b4h._0_4_ = 0.0;
    var_1c8h._0_4_ = 0.0;
    iVar5 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    var_1c0h._0_4_ = *(float *)(iVar5 + 8);
    var_1b8h = *(float *)(iVar5 + 0xc);
    var_1c8h._4_4_ = *(float *)(iVar5 + 0x10);
    var_1c0h._4_4_ = *(float *)(iVar5 + 0x14);
    if (0 < (int32_t)(*(int64_t *)0x18077b000 - *(int64_t *)0x18077aff8 >> 4) * -0x7fc01ff) {
        do {
            uVar18 = 0x3e4ccccd;
            uVar17 = 0x3e800000;
            arg1 = (int32_t *)((int64_t)iVar11 * 0x2010 + *(int64_t *)0x18077aff8);
            piVar8 = (int64_t *)fcn.180013b20(auStack_128);
            if ((uint64_t)(int64_t)(arg1[0x801] + 300) < (uint64_t)(*piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802))) {
                iVar9 = *(int64_t *)0x18077aff8 + (int64_t)iVar11 * 0x2010;
                iVar5 = iVar9 + 0x2010;
                func_0x000180498030(iVar9, iVar5, *(int64_t *)0x18077b000 - iVar5);
                *(int64_t *)0x18077b000 = *(int64_t *)0x18077b000 + -0x2010;
                iVar11 = iVar11 + -1;
            } else {
                piVar1 = arg1 + 0x401;
                iVar6 = fcn.180066690((int64_t)arg1);
                piVar8 = (int64_t *)fcn.180013b20(auStack_120);
                uVar10 = *piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802);
                if (iVar6 == 0) {
                    if ((int64_t)uVar10 < 0) {
                        fVar13 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar13 = (fVar13 + fVar13) / 150.0;
                    } else {
                        fVar13 = (float)uVar10 / 150.0;
                    }
                } else if (iVar6 == 2) {
                    if ((int64_t)uVar10 < 0) {
                        fVar13 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar13 = fVar13 + fVar13;
                    } else {
                        fVar13 = (float)uVar10;
                    }
                    fVar13 = 1.0 - ((fVar13 - 150.0) - (float)arg1[0x801]) / 150.0;
                } else {
                    fVar13 = 1.0;
                }
                iVar6 = arg1[0x801];
                piVar8 = (int64_t *)fcn.180013b20(auStack_118);
                if (fVar15 < (float)(iVar6 + 300)) {
                    uVar10 = *piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802);
                    if ((int64_t)uVar10 < 0) {
                        fVar12 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar12 = fVar12 + fVar12;
                    } else {
                        fVar12 = (float)uVar10;
                    }
                    fVar12 = 1.0 - fVar12 / (float)(iVar6 + 300);
                    if ((fVar15 <= fVar12) && (fVar15 = 1.0, fVar12 <= 1.0)) {
                        fVar15 = fVar12;
                    }
                }
                iVar6 = *arg1;
                if (iVar6 == 1) {
                    uVar17 = 0x3f47ae14;
                    uVar16 = 0x3e4ccccd;
                    uVar18 = 0x3eb33333;
                } else if (iVar6 == 2) {
                    uVar16 = 0x3f733333;
                    uVar17 = 0x3f30a3d7;
                } else if (iVar6 == 3) {
                    uVar18 = 0x3e6b851f;
                    uVar16 = 0x3f666666;
                } else if (iVar6 == 4) {
                    uVar16 = 0x3e4ccccd;
                    uVar17 = 0x3f19999a;
                    uVar18 = 0x3f800000;
                } else {
                    uVar16 = 0x3f59999a;
                    uVar17 = 0x3f59999a;
                    uVar18 = 0x3f59999a;
                }
                uVar2 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0xef0);
                uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                fVar14 = fVar13 * 0.9 * *(float *)(*(int64_t *)0x180781f28 + 0xefc);
                uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
                uVar3 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0xf20);
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0xf2c);
                func_0x000180065f60(auStack_110, 0x32, 0x18063cc58, iVar11);
                func_0x0001800f6810(3, 0x41000000);
                func_0x0001800f6810(4, 0x3f800000);
                var_190h._0_4_ = 0x41600000;
                var_190h._4_4_ = 0x41400000;
                func_0x0001800f6960(2, &var_190h);
                var_188h = 0x41000000;
                var_184h = 0x41000000;
                func_0x0001800f6960(0xe, &var_188h);
                iVar5 = *(int64_t *)0x180781f28;
                var_1a8h._0_4_ = 2;
                var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef0);
                uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef4);
                uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xefc);
                func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                if (*(int32_t *)(iVar5 + 0x20bc) != 2) {
                    *(undefined8 *)(iVar5 + 0xef0) = uVar2;
                    *(undefined4 *)(iVar5 + 0xef8) = uVar7;
                    *(float *)(iVar5 + 0xefc) = fVar14;
                }
                iVar5 = *(int64_t *)0x180781f28;
                var_1a8h._0_4_ = 5;
                var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
                uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
                uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
                uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf2c);
                func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                if (*(int32_t *)(iVar5 + 0x20bc) != 5) {
                    *(undefined8 *)(iVar5 + 0xf20) = uVar3;
                    *(undefined4 *)(iVar5 + 0xf28) = uVar4;
                    *(float *)(iVar5 + 0xf2c) = fVar13 * 0.25 * fVar12;
                }
                iVar5 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x51
                ;
                *(float *)(iVar5 + 0x2070) = fVar14;
                *(undefined4 *)(iVar5 + 0x2024) = 0x3f800000;
                *(undefined4 *)(iVar5 + 0x2028) = 0x3f800000;
                *(undefined4 *)(iVar5 + 0x200c) = 1;
                *(undefined *)(iVar5 + 0x204c) = 1;
                *(float *)(iVar5 + 0x201c) = (var_1c8h._4_4_ + (float)var_1c0h) - 20.0;
                *(float *)(iVar5 + 0x2020) = ((var_1c0h._4_4_ + var_1b8h) - 20.0) - (float)var_1c8h;
                *(undefined8 *)(iVar5 + 0x2050) = 0x43340000;
                *(undefined4 *)(iVar5 + 0x2058) = 0x43a00000;
                *(undefined4 *)(iVar5 + 0x205c) = 0x7f7fffff;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
                func_0x0001801019f0(auStack_110, 0, 0x3326b);
                iVar9 = *(int64_t *)0x180781f28;
                fStack_14c = fVar13 * 0.1;
                uStack_158 = 0;
                uStack_150 = 0;
                iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                fVar12 = *(float *)(iVar5 + 0x60);
                fStack_178 = fVar12 + 3.0;
                fVar14 = *(float *)(iVar5 + 0x68) + fVar12;
                fVar19 = *(float *)(iVar5 + 0x6c) + *(float *)(iVar5 + 100);
                *(undefined *)(iVar5 + 0x10b) = 1;
                fStack_174 = *(float *)(iVar5 + 100) + 3.0;
                uVar2 = *(undefined8 *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
                var_180h = fVar14 + 3.0;
                var_17ch = fVar19 + 3.0;
                uVar7 = func_0x0001800f5fa0(&uStack_158);
                var_1d0h._0_4_ = 0;
                var_1d8h._0_4_ = 0x41000000;
                func_0x000180126550(uVar2, &fStack_178, &var_180h, uVar7);
                func_0x0001801061c0(var_1c8h._4_4_ / 3.2);
                if ((piVar1 != (int32_t *)0x0) &&
                   (iVar9 = func_0x000180498cd0(piVar1), iVar5 = *(int64_t *)0x180781f28, iVar9 != 0)) {
                    var_1a8h._0_4_ = 0;
                    var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
                    uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                    uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                    uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xedc);
                    func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                    if (*(int32_t *)(iVar5 + 0x20bc) != 0) {
                        *(undefined4 *)(iVar5 + 0xed0) = 0x3f6b851f;
                        *(undefined4 *)(iVar5 + 0xed4) = 0x3f6b851f;
                        *(undefined4 *)(iVar5 + 0xed8) = 0x3f6b851f;
                        *(float *)(iVar5 + 0xedc) = fVar13;
                    }
                    func_0x000180139c80(0x18063cc8c, piVar1);
                    func_0x0001800f6770(1);
                }
                uStack_170 = 0;
                uStack_16c = 0x41000000;
                func_0x00018013c3d0(&uStack_170);
                iVar9 = *(int64_t *)0x180781f28;
                iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                iVar6 = *(int32_t *)(iVar5 + 600);
                if (iVar6 < 1) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644678);
                        iVar9 = *(int64_t *)0x180781f28;
                    }
                } else {
                    uVar7 = *(undefined4 *)(*(int64_t *)(iVar5 + 0x260) + -4 + (int64_t)iVar6 * 4);
                    *(int32_t *)(iVar5 + 600) = iVar6 + -1;
                    *(undefined4 *)(iVar5 + 0x244) = uVar7;
                }
                fVar19 = fVar19 - 8.0;
                fVar12 = fVar12 + 12.0;
                fVar14 = fVar14 - 12.0;
                uStack_148 = 0x3f800000;
                uStack_144 = 0x3f800000;
                var_1ach = fVar19 - 3.0;
                uStack_140 = 0x3f800000;
                fStack_13c = fVar13 * 0.08 * *(float *)(iVar9 + 0xd9c);
                var_1b4h._4_4_ = fVar12;
                fStack_168 = fVar14;
                fStack_164 = fVar19;
                uVar7 = func_0x0001800f5fa0(&uStack_148);
                var_1d0h._0_4_ = 0;
                var_1d8h._0_4_ = 0x40400000;
                func_0x000180126550(uVar2, (int64_t)&var_1b4h + 4, &fStack_168, uVar7);
                fVar15 = (fVar14 - fVar12) * fVar15;
                if (1.0 < fVar15) {
                    fStack_160 = fVar15 + fVar12;
                    fStack_12c = fVar13 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    fStack_15c = fVar19;
                    uStack_138 = uVar16;
                    uStack_134 = uVar17;
                    uStack_130 = uVar18;
                    uVar17 = func_0x0001800f5fa0(&uStack_138);
                    var_1d0h._0_4_ = 0;
                    var_1d8h._0_4_ = 0x40400000;
                    func_0x000180126550(uVar2, (int64_t)&var_1b4h + 4, &fStack_160, uVar17);
                }
                var_1c8h._0_4_ =
                     (float)var_1c8h + *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x6c) + 10.0;
                func_0x000180105c20();
                func_0x0001800f6770(2);
                func_0x0001800f6a20(4);
                fVar15 = (float)var_1b4h;
            }
            iVar11 = iVar11 + 1;
        } while (iVar11 < (int32_t)(*(int64_t *)0x18077b000 - *(int64_t *)0x18077aff8 >> 4) * -0x7fc01ff);
    }
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_1f8);
    return;
}

// ============================================================
// Function: FUN_1800667c9
// Address: 0x1800667c9
// Size: 2254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1bch
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ach
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.180066720(void)
{
    int32_t *piVar1;
    int32_t *arg1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_1f8 [32];
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    float var_1b8h;
    int64_t var_1b4h;
    float var_1ach;
    int64_t var_1a8h;
    undefined4 uStack_1a0;
    undefined4 uStack_19c;
    undefined4 uStack_198;
    int64_t var_190h;
    undefined4 var_188h;
    undefined4 var_184h;
    float var_180h;
    float var_17ch;
    float fStack_178;
    float fStack_174;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    float fStack_168;
    float fStack_164;
    float fStack_160;
    float fStack_15c;
    undefined8 uStack_158;
    undefined4 uStack_150;
    float fStack_14c;
    undefined4 uStack_148;
    undefined4 uStack_144;
    undefined4 uStack_140;
    float fStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    undefined4 uStack_130;
    float fStack_12c;
    undefined auStack_128 [8];
    undefined auStack_120 [8];
    undefined auStack_118 [8];
    undefined auStack_110 [56];
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_6ch;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1f8;
    iVar11 = 0;
    fVar15 = 0.0;
    var_1b4h._0_4_ = 0.0;
    var_1c8h._0_4_ = 0.0;
    iVar5 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    var_1c0h._0_4_ = *(float *)(iVar5 + 8);
    var_1b8h = *(float *)(iVar5 + 0xc);
    var_1c8h._4_4_ = *(float *)(iVar5 + 0x10);
    var_1c0h._4_4_ = *(float *)(iVar5 + 0x14);
    if (0 < (int32_t)(*(int64_t *)0x18077b000 - *(int64_t *)0x18077aff8 >> 4) * -0x7fc01ff) {
        do {
            uVar18 = 0x3e4ccccd;
            uVar17 = 0x3e800000;
            arg1 = (int32_t *)((int64_t)iVar11 * 0x2010 + *(int64_t *)0x18077aff8);
            piVar8 = (int64_t *)fcn.180013b20(auStack_128);
            if ((uint64_t)(int64_t)(arg1[0x801] + 300) < (uint64_t)(*piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802))) {
                iVar9 = *(int64_t *)0x18077aff8 + (int64_t)iVar11 * 0x2010;
                iVar5 = iVar9 + 0x2010;
                func_0x000180498030(iVar9, iVar5, *(int64_t *)0x18077b000 - iVar5);
                *(int64_t *)0x18077b000 = *(int64_t *)0x18077b000 + -0x2010;
                iVar11 = iVar11 + -1;
            } else {
                piVar1 = arg1 + 0x401;
                iVar6 = fcn.180066690((int64_t)arg1);
                piVar8 = (int64_t *)fcn.180013b20(auStack_120);
                uVar10 = *piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802);
                if (iVar6 == 0) {
                    if ((int64_t)uVar10 < 0) {
                        fVar13 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar13 = (fVar13 + fVar13) / 150.0;
                    } else {
                        fVar13 = (float)uVar10 / 150.0;
                    }
                } else if (iVar6 == 2) {
                    if ((int64_t)uVar10 < 0) {
                        fVar13 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar13 = fVar13 + fVar13;
                    } else {
                        fVar13 = (float)uVar10;
                    }
                    fVar13 = 1.0 - ((fVar13 - 150.0) - (float)arg1[0x801]) / 150.0;
                } else {
                    fVar13 = 1.0;
                }
                iVar6 = arg1[0x801];
                piVar8 = (int64_t *)fcn.180013b20(auStack_118);
                if (fVar15 < (float)(iVar6 + 300)) {
                    uVar10 = *piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802);
                    if ((int64_t)uVar10 < 0) {
                        fVar12 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar12 = fVar12 + fVar12;
                    } else {
                        fVar12 = (float)uVar10;
                    }
                    fVar12 = 1.0 - fVar12 / (float)(iVar6 + 300);
                    if ((fVar15 <= fVar12) && (fVar15 = 1.0, fVar12 <= 1.0)) {
                        fVar15 = fVar12;
                    }
                }
                iVar6 = *arg1;
                if (iVar6 == 1) {
                    uVar17 = 0x3f47ae14;
                    uVar16 = 0x3e4ccccd;
                    uVar18 = 0x3eb33333;
                } else if (iVar6 == 2) {
                    uVar16 = 0x3f733333;
                    uVar17 = 0x3f30a3d7;
                } else if (iVar6 == 3) {
                    uVar18 = 0x3e6b851f;
                    uVar16 = 0x3f666666;
                } else if (iVar6 == 4) {
                    uVar16 = 0x3e4ccccd;
                    uVar17 = 0x3f19999a;
                    uVar18 = 0x3f800000;
                } else {
                    uVar16 = 0x3f59999a;
                    uVar17 = 0x3f59999a;
                    uVar18 = 0x3f59999a;
                }
                uVar2 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0xef0);
                uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                fVar14 = fVar13 * 0.9 * *(float *)(*(int64_t *)0x180781f28 + 0xefc);
                uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
                uVar3 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0xf20);
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0xf2c);
                func_0x000180065f60(auStack_110, 0x32, 0x18063cc58, iVar11);
                func_0x0001800f6810(3, 0x41000000);
                func_0x0001800f6810(4, 0x3f800000);
                var_190h._0_4_ = 0x41600000;
                var_190h._4_4_ = 0x41400000;
                func_0x0001800f6960(2, &var_190h);
                var_188h = 0x41000000;
                var_184h = 0x41000000;
                func_0x0001800f6960(0xe, &var_188h);
                iVar5 = *(int64_t *)0x180781f28;
                var_1a8h._0_4_ = 2;
                var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef0);
                uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef4);
                uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xefc);
                func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                if (*(int32_t *)(iVar5 + 0x20bc) != 2) {
                    *(undefined8 *)(iVar5 + 0xef0) = uVar2;
                    *(undefined4 *)(iVar5 + 0xef8) = uVar7;
                    *(float *)(iVar5 + 0xefc) = fVar14;
                }
                iVar5 = *(int64_t *)0x180781f28;
                var_1a8h._0_4_ = 5;
                var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
                uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
                uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
                uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf2c);
                func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                if (*(int32_t *)(iVar5 + 0x20bc) != 5) {
                    *(undefined8 *)(iVar5 + 0xf20) = uVar3;
                    *(undefined4 *)(iVar5 + 0xf28) = uVar4;
                    *(float *)(iVar5 + 0xf2c) = fVar13 * 0.25 * fVar12;
                }
                iVar5 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x51
                ;
                *(float *)(iVar5 + 0x2070) = fVar14;
                *(undefined4 *)(iVar5 + 0x2024) = 0x3f800000;
                *(undefined4 *)(iVar5 + 0x2028) = 0x3f800000;
                *(undefined4 *)(iVar5 + 0x200c) = 1;
                *(undefined *)(iVar5 + 0x204c) = 1;
                *(float *)(iVar5 + 0x201c) = (var_1c8h._4_4_ + (float)var_1c0h) - 20.0;
                *(float *)(iVar5 + 0x2020) = ((var_1c0h._4_4_ + var_1b8h) - 20.0) - (float)var_1c8h;
                *(undefined8 *)(iVar5 + 0x2050) = 0x43340000;
                *(undefined4 *)(iVar5 + 0x2058) = 0x43a00000;
                *(undefined4 *)(iVar5 + 0x205c) = 0x7f7fffff;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
                func_0x0001801019f0(auStack_110, 0, 0x3326b);
                iVar9 = *(int64_t *)0x180781f28;
                fStack_14c = fVar13 * 0.1;
                uStack_158 = 0;
                uStack_150 = 0;
                iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                fVar12 = *(float *)(iVar5 + 0x60);
                fStack_178 = fVar12 + 3.0;
                fVar14 = *(float *)(iVar5 + 0x68) + fVar12;
                fVar19 = *(float *)(iVar5 + 0x6c) + *(float *)(iVar5 + 100);
                *(undefined *)(iVar5 + 0x10b) = 1;
                fStack_174 = *(float *)(iVar5 + 100) + 3.0;
                uVar2 = *(undefined8 *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
                var_180h = fVar14 + 3.0;
                var_17ch = fVar19 + 3.0;
                uVar7 = func_0x0001800f5fa0(&uStack_158);
                var_1d0h._0_4_ = 0;
                var_1d8h._0_4_ = 0x41000000;
                func_0x000180126550(uVar2, &fStack_178, &var_180h, uVar7);
                func_0x0001801061c0(var_1c8h._4_4_ / 3.2);
                if ((piVar1 != (int32_t *)0x0) &&
                   (iVar9 = func_0x000180498cd0(piVar1), iVar5 = *(int64_t *)0x180781f28, iVar9 != 0)) {
                    var_1a8h._0_4_ = 0;
                    var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
                    uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                    uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                    uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xedc);
                    func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                    if (*(int32_t *)(iVar5 + 0x20bc) != 0) {
                        *(undefined4 *)(iVar5 + 0xed0) = 0x3f6b851f;
                        *(undefined4 *)(iVar5 + 0xed4) = 0x3f6b851f;
                        *(undefined4 *)(iVar5 + 0xed8) = 0x3f6b851f;
                        *(float *)(iVar5 + 0xedc) = fVar13;
                    }
                    func_0x000180139c80(0x18063cc8c, piVar1);
                    func_0x0001800f6770(1);
                }
                uStack_170 = 0;
                uStack_16c = 0x41000000;
                func_0x00018013c3d0(&uStack_170);
                iVar9 = *(int64_t *)0x180781f28;
                iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                iVar6 = *(int32_t *)(iVar5 + 600);
                if (iVar6 < 1) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644678);
                        iVar9 = *(int64_t *)0x180781f28;
                    }
                } else {
                    uVar7 = *(undefined4 *)(*(int64_t *)(iVar5 + 0x260) + -4 + (int64_t)iVar6 * 4);
                    *(int32_t *)(iVar5 + 600) = iVar6 + -1;
                    *(undefined4 *)(iVar5 + 0x244) = uVar7;
                }
                fVar19 = fVar19 - 8.0;
                fVar12 = fVar12 + 12.0;
                fVar14 = fVar14 - 12.0;
                uStack_148 = 0x3f800000;
                uStack_144 = 0x3f800000;
                var_1ach = fVar19 - 3.0;
                uStack_140 = 0x3f800000;
                fStack_13c = fVar13 * 0.08 * *(float *)(iVar9 + 0xd9c);
                var_1b4h._4_4_ = fVar12;
                fStack_168 = fVar14;
                fStack_164 = fVar19;
                uVar7 = func_0x0001800f5fa0(&uStack_148);
                var_1d0h._0_4_ = 0;
                var_1d8h._0_4_ = 0x40400000;
                func_0x000180126550(uVar2, (int64_t)&var_1b4h + 4, &fStack_168, uVar7);
                fVar15 = (fVar14 - fVar12) * fVar15;
                if (1.0 < fVar15) {
                    fStack_160 = fVar15 + fVar12;
                    fStack_12c = fVar13 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    fStack_15c = fVar19;
                    uStack_138 = uVar16;
                    uStack_134 = uVar17;
                    uStack_130 = uVar18;
                    uVar17 = func_0x0001800f5fa0(&uStack_138);
                    var_1d0h._0_4_ = 0;
                    var_1d8h._0_4_ = 0x40400000;
                    func_0x000180126550(uVar2, (int64_t)&var_1b4h + 4, &fStack_160, uVar17);
                }
                var_1c8h._0_4_ =
                     (float)var_1c8h + *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x6c) + 10.0;
                func_0x000180105c20();
                func_0x0001800f6770(2);
                func_0x0001800f6a20(4);
                fVar15 = (float)var_1b4h;
            }
            iVar11 = iVar11 + 1;
        } while (iVar11 < (int32_t)(*(int64_t *)0x18077b000 - *(int64_t *)0x18077aff8 >> 4) * -0x7fc01ff);
    }
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_1f8);
    return;
}

// ============================================================
// Function: FUN_180067097
// Address: 0x180067097
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_1b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_1bch
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_1a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_1b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ach
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h

void fcn.180066720(void)
{
    int32_t *piVar1;
    int32_t *arg1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    undefined4 uVar7;
    int64_t *piVar8;
    int64_t iVar9;
    uint64_t uVar10;
    int32_t iVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    undefined4 uVar17;
    undefined4 uVar18;
    float fVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    undefined auStack_1f8 [32];
    int64_t var_1d8h;
    int64_t var_1d0h;
    int64_t var_1c8h;
    int64_t var_1c0h;
    float var_1b8h;
    int64_t var_1b4h;
    float var_1ach;
    int64_t var_1a8h;
    undefined4 uStack_1a0;
    undefined4 uStack_19c;
    undefined4 uStack_198;
    int64_t var_190h;
    undefined4 var_188h;
    undefined4 var_184h;
    float var_180h;
    float var_17ch;
    float fStack_178;
    float fStack_174;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    float fStack_168;
    float fStack_164;
    float fStack_160;
    float fStack_15c;
    undefined8 uStack_158;
    undefined4 uStack_150;
    float fStack_14c;
    undefined4 uStack_148;
    undefined4 uStack_144;
    undefined4 uStack_140;
    float fStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    undefined4 uStack_130;
    float fStack_12c;
    undefined auStack_128 [8];
    undefined auStack_120 [8];
    undefined auStack_118 [8];
    undefined auStack_110 [56];
    uint64_t uStack_d8;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_6ch;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    
    uStack_d8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1f8;
    iVar11 = 0;
    fVar15 = 0.0;
    var_1b4h._0_4_ = 0.0;
    var_1c8h._0_4_ = 0.0;
    iVar5 = **(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    var_1c0h._0_4_ = *(float *)(iVar5 + 8);
    var_1b8h = *(float *)(iVar5 + 0xc);
    var_1c8h._4_4_ = *(float *)(iVar5 + 0x10);
    var_1c0h._4_4_ = *(float *)(iVar5 + 0x14);
    if (0 < (int32_t)(*(int64_t *)0x18077b000 - *(int64_t *)0x18077aff8 >> 4) * -0x7fc01ff) {
        do {
            uVar18 = 0x3e4ccccd;
            uVar17 = 0x3e800000;
            arg1 = (int32_t *)((int64_t)iVar11 * 0x2010 + *(int64_t *)0x18077aff8);
            piVar8 = (int64_t *)fcn.180013b20(auStack_128);
            if ((uint64_t)(int64_t)(arg1[0x801] + 300) < (uint64_t)(*piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802))) {
                iVar9 = *(int64_t *)0x18077aff8 + (int64_t)iVar11 * 0x2010;
                iVar5 = iVar9 + 0x2010;
                func_0x000180498030(iVar9, iVar5, *(int64_t *)0x18077b000 - iVar5);
                *(int64_t *)0x18077b000 = *(int64_t *)0x18077b000 + -0x2010;
                iVar11 = iVar11 + -1;
            } else {
                piVar1 = arg1 + 0x401;
                iVar6 = fcn.180066690((int64_t)arg1);
                piVar8 = (int64_t *)fcn.180013b20(auStack_120);
                uVar10 = *piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802);
                if (iVar6 == 0) {
                    if ((int64_t)uVar10 < 0) {
                        fVar13 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar13 = (fVar13 + fVar13) / 150.0;
                    } else {
                        fVar13 = (float)uVar10 / 150.0;
                    }
                } else if (iVar6 == 2) {
                    if ((int64_t)uVar10 < 0) {
                        fVar13 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar13 = fVar13 + fVar13;
                    } else {
                        fVar13 = (float)uVar10;
                    }
                    fVar13 = 1.0 - ((fVar13 - 150.0) - (float)arg1[0x801]) / 150.0;
                } else {
                    fVar13 = 1.0;
                }
                iVar6 = arg1[0x801];
                piVar8 = (int64_t *)fcn.180013b20(auStack_118);
                if (fVar15 < (float)(iVar6 + 300)) {
                    uVar10 = *piVar8 / 1000000 - *(int64_t *)(arg1 + 0x802);
                    if ((int64_t)uVar10 < 0) {
                        fVar12 = (float)(uVar10 >> 1 | (uint64_t)((uint32_t)uVar10 & 1));
                        fVar12 = fVar12 + fVar12;
                    } else {
                        fVar12 = (float)uVar10;
                    }
                    fVar12 = 1.0 - fVar12 / (float)(iVar6 + 300);
                    if ((fVar15 <= fVar12) && (fVar15 = 1.0, fVar12 <= 1.0)) {
                        fVar15 = fVar12;
                    }
                }
                iVar6 = *arg1;
                if (iVar6 == 1) {
                    uVar17 = 0x3f47ae14;
                    uVar16 = 0x3e4ccccd;
                    uVar18 = 0x3eb33333;
                } else if (iVar6 == 2) {
                    uVar16 = 0x3f733333;
                    uVar17 = 0x3f30a3d7;
                } else if (iVar6 == 3) {
                    uVar18 = 0x3e6b851f;
                    uVar16 = 0x3f666666;
                } else if (iVar6 == 4) {
                    uVar16 = 0x3e4ccccd;
                    uVar17 = 0x3f19999a;
                    uVar18 = 0x3f800000;
                } else {
                    uVar16 = 0x3f59999a;
                    uVar17 = 0x3f59999a;
                    uVar18 = 0x3f59999a;
                }
                uVar2 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0xef0);
                uVar7 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                fVar14 = fVar13 * 0.9 * *(float *)(*(int64_t *)0x180781f28 + 0xefc);
                uVar4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
                uVar3 = *(undefined8 *)(*(int64_t *)0x180781f28 + 0xf20);
                fVar12 = *(float *)(*(int64_t *)0x180781f28 + 0xf2c);
                func_0x000180065f60(auStack_110, 0x32, 0x18063cc58, iVar11);
                func_0x0001800f6810(3, 0x41000000);
                func_0x0001800f6810(4, 0x3f800000);
                var_190h._0_4_ = 0x41600000;
                var_190h._4_4_ = 0x41400000;
                func_0x0001800f6960(2, &var_190h);
                var_188h = 0x41000000;
                var_184h = 0x41000000;
                func_0x0001800f6960(0xe, &var_188h);
                iVar5 = *(int64_t *)0x180781f28;
                var_1a8h._0_4_ = 2;
                var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef0);
                uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef4);
                uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xefc);
                func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                if (*(int32_t *)(iVar5 + 0x20bc) != 2) {
                    *(undefined8 *)(iVar5 + 0xef0) = uVar2;
                    *(undefined4 *)(iVar5 + 0xef8) = uVar7;
                    *(float *)(iVar5 + 0xefc) = fVar14;
                }
                iVar5 = *(int64_t *)0x180781f28;
                var_1a8h._0_4_ = 5;
                var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
                uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
                uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
                uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf2c);
                func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                if (*(int32_t *)(iVar5 + 0x20bc) != 5) {
                    *(undefined8 *)(iVar5 + 0xf20) = uVar3;
                    *(undefined4 *)(iVar5 + 0xf28) = uVar4;
                    *(float *)(iVar5 + 0xf2c) = fVar13 * 0.25 * fVar12;
                }
                iVar5 = *(int64_t *)0x180781f28;
                *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2008) | 0x51
                ;
                *(float *)(iVar5 + 0x2070) = fVar14;
                *(undefined4 *)(iVar5 + 0x2024) = 0x3f800000;
                *(undefined4 *)(iVar5 + 0x2028) = 0x3f800000;
                *(undefined4 *)(iVar5 + 0x200c) = 1;
                *(undefined *)(iVar5 + 0x204c) = 1;
                *(float *)(iVar5 + 0x201c) = (var_1c8h._4_4_ + (float)var_1c0h) - 20.0;
                *(float *)(iVar5 + 0x2020) = ((var_1c0h._4_4_ + var_1b8h) - 20.0) - (float)var_1c8h;
                *(undefined8 *)(iVar5 + 0x2050) = 0x43340000;
                *(undefined4 *)(iVar5 + 0x2058) = 0x43a00000;
                *(undefined4 *)(iVar5 + 0x205c) = 0x7f7fffff;
                *(undefined8 *)(iVar5 + 0x2060) = 0;
                *(undefined8 *)(iVar5 + 0x2068) = 0;
                func_0x0001801019f0(auStack_110, 0, 0x3326b);
                iVar9 = *(int64_t *)0x180781f28;
                fStack_14c = fVar13 * 0.1;
                uStack_158 = 0;
                uStack_150 = 0;
                iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                fVar12 = *(float *)(iVar5 + 0x60);
                fStack_178 = fVar12 + 3.0;
                fVar14 = *(float *)(iVar5 + 0x68) + fVar12;
                fVar19 = *(float *)(iVar5 + 0x6c) + *(float *)(iVar5 + 100);
                *(undefined *)(iVar5 + 0x10b) = 1;
                fStack_174 = *(float *)(iVar5 + 100) + 3.0;
                uVar2 = *(undefined8 *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
                var_180h = fVar14 + 3.0;
                var_17ch = fVar19 + 3.0;
                uVar7 = func_0x0001800f5fa0(&uStack_158);
                var_1d0h._0_4_ = 0;
                var_1d8h._0_4_ = 0x41000000;
                func_0x000180126550(uVar2, &fStack_178, &var_180h, uVar7);
                func_0x0001801061c0(var_1c8h._4_4_ / 3.2);
                if ((piVar1 != (int32_t *)0x0) &&
                   (iVar9 = func_0x000180498cd0(piVar1), iVar5 = *(int64_t *)0x180781f28, iVar9 != 0)) {
                    var_1a8h._0_4_ = 0;
                    var_1a8h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
                    uStack_1a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
                    uStack_19c = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
                    uStack_198 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xedc);
                    func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_1a8h);
                    if (*(int32_t *)(iVar5 + 0x20bc) != 0) {
                        *(undefined4 *)(iVar5 + 0xed0) = 0x3f6b851f;
                        *(undefined4 *)(iVar5 + 0xed4) = 0x3f6b851f;
                        *(undefined4 *)(iVar5 + 0xed8) = 0x3f6b851f;
                        *(float *)(iVar5 + 0xedc) = fVar13;
                    }
                    func_0x000180139c80(0x18063cc8c, piVar1);
                    func_0x0001800f6770(1);
                }
                uStack_170 = 0;
                uStack_16c = 0x41000000;
                func_0x00018013c3d0(&uStack_170);
                iVar9 = *(int64_t *)0x180781f28;
                iVar5 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
                iVar6 = *(int32_t *)(iVar5 + 600);
                if (iVar6 < 1) {
                    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 
                                   0x180644678);
                        iVar9 = *(int64_t *)0x180781f28;
                    }
                } else {
                    uVar7 = *(undefined4 *)(*(int64_t *)(iVar5 + 0x260) + -4 + (int64_t)iVar6 * 4);
                    *(int32_t *)(iVar5 + 600) = iVar6 + -1;
                    *(undefined4 *)(iVar5 + 0x244) = uVar7;
                }
                fVar19 = fVar19 - 8.0;
                fVar12 = fVar12 + 12.0;
                fVar14 = fVar14 - 12.0;
                uStack_148 = 0x3f800000;
                uStack_144 = 0x3f800000;
                var_1ach = fVar19 - 3.0;
                uStack_140 = 0x3f800000;
                fStack_13c = fVar13 * 0.08 * *(float *)(iVar9 + 0xd9c);
                var_1b4h._4_4_ = fVar12;
                fStack_168 = fVar14;
                fStack_164 = fVar19;
                uVar7 = func_0x0001800f5fa0(&uStack_148);
                var_1d0h._0_4_ = 0;
                var_1d8h._0_4_ = 0x40400000;
                func_0x000180126550(uVar2, (int64_t)&var_1b4h + 4, &fStack_168, uVar7);
                fVar15 = (fVar14 - fVar12) * fVar15;
                if (1.0 < fVar15) {
                    fStack_160 = fVar15 + fVar12;
                    fStack_12c = fVar13 * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    fStack_15c = fVar19;
                    uStack_138 = uVar16;
                    uStack_134 = uVar17;
                    uStack_130 = uVar18;
                    uVar17 = func_0x0001800f5fa0(&uStack_138);
                    var_1d0h._0_4_ = 0;
                    var_1d8h._0_4_ = 0x40400000;
                    func_0x000180126550(uVar2, (int64_t)&var_1b4h + 4, &fStack_160, uVar17);
                }
                var_1c8h._0_4_ =
                     (float)var_1c8h + *(float *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x6c) + 10.0;
                func_0x000180105c20();
                func_0x0001800f6770(2);
                func_0x0001800f6a20(4);
                fVar15 = (float)var_1b4h;
            }
            iVar11 = iVar11 + 1;
        } while (iVar11 < (int32_t)(*(int64_t *)0x18077b000 - *(int64_t *)0x18077aff8 >> 4) * -0x7fc01ff);
    }
    func_0x000180459870(uStack_d8 ^ (uint64_t)auStack_1f8);
    return;
}

// ============================================================
// Function: FUN_1800670c0
// Address: 0x1800670c0
// Size: 4487 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d3h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_96h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_cdh
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_cfh
// WARNING: [rz-ghidra] Detected overlap for variable var_90h

void fcn.1800670c0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
                  int64_t arg_30h)
{
    int32_t *piVar1;
    char **ppcVar2;
    char **ppcVar3;
    bool bVar4;
    char cVar5;
    uint8_t uVar6;
    undefined2 uVar7;
    uint16_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    undefined4 uVar14;
    int32_t iVar15;
    int64_t iVar16;
    uint8_t *puVar17;
    uint8_t *puVar18;
    undefined *puVar19;
    undefined extraout_AH;
    int64_t *piVar20;
    char *pcVar21;
    int64_t iVar22;
    undefined uVar23;
    char cVar24;
    char cVar25;
    int32_t iVar26;
    uint64_t uVar27;
    int64_t iVar28;
    undefined *puVar29;
    uint8_t uVar30;
    uint8_t *puVar31;
    undefined2 *puVar32;
    uint32_t uVar33;
    uint8_t uVar34;
    uint8_t uVar35;
    uint32_t uVar36;
    float fVar37;
    float fVar38;
    int64_t var_20h;
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    uint32_t var_d8h;
    undefined4 var_d4h;
    undefined4 var_d0h;
    int64_t var_cch;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined8 var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    iVar10 = 8;
    var_c0h = arg_30h;
    *(undefined8 *)arg_30h = 8;
    *(undefined4 *)(arg_30h + 8) = 0;
    var_b8h = arg2;
    var_b0h = arg3;
    iVar9 = func_0x00018006f850();
    pcVar21 = *(char **)(arg1 + 0xd0);
    ppcVar2 = (char **)(arg1 + 0xc0);
    ppcVar3 = (char **)(arg1 + 200);
    *ppcVar2 = pcVar21;
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    if (iVar9 != 0) {
        var_98h = arg1;
        iVar9 = func_0x0001800708b0(&var_98h, 0, 4);
        iVar16 = var_80h;
        if (iVar9 != 0) {
            if (8 < (int32_t)var_78h) {
                if ((int32_t)var_78h != 0x10) goto code_r0x000180068d5b;
                iVar10 = 0x10;
            }
            *(int32_t *)arg_30h = iVar10;
            var_80h = 0;
            if (*(int32_t *)(var_98h + 0xc) != 4) {
                var_f8h._0_4_ = *(uint32_t *)(var_98h + 4);
                if (iVar10 == 8) {
                    iVar16 = func_0x000180069b10(iVar16, *(int32_t *)(var_98h + 0xc), 4);
                } else {
                    iVar16 = func_0x000180069fc0(iVar16);
                }
                *(undefined4 *)(var_98h + 0xc) = 4;
                if (iVar16 == 0) goto code_r0x000180068d5b;
            }
            *(undefined4 *)var_b8h = *(undefined4 *)var_98h;
            *(undefined4 *)arg3 = *(undefined4 *)(var_98h + 4);
        }
        func_0x000180460d90(var_80h);
        var_80h = 0;
        func_0x000180460d90(var_88h);
        var_88h = 0;
        func_0x000180460d90(var_90h);
        goto code_r0x000180068d5b;
    }
    if (pcVar21 < *(char **)(arg1 + 0xd8)) {
        cVar5 = *pcVar21;
code_r0x000180067232:
        *ppcVar2 = pcVar21 + 1;
        if ((cVar5 != 'B') || (cVar5 = func_0x0001800697d0(arg1), cVar5 != 'M')) goto code_r0x000180067246;
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        iVar9 = func_0x000180069a30(arg1);
        iVar10 = func_0x000180069a30(arg1);
        uVar11 = iVar10 * 0x10000 + iVar9;
        if ((((uVar11 < 0x39) && ((0x100010000001000U >> ((uint64_t)uVar11 & 0x3f) & 1) != 0)) || (uVar11 == 0x6c)) ||
           (uVar11 == 0x7c)) {
            bVar4 = true;
        } else {
            bVar4 = false;
        }
        *ppcVar2 = *(char **)(arg1 + 0xd0);
        *ppcVar3 = *(char **)(arg1 + 0xd8);
        arg2 = var_b8h;
        if (bVar4) {
            var_f0h = arg_30h;
            var_f8h._0_4_ = 4;
            func_0x000180071bc0(arg1, var_b8h, var_b0h, 0);
            goto code_r0x000180068d5b;
        }
    } else {
        if (*(int32_t *)(arg1 + 0x30) != 0) {
            func_0x000180069750(arg1);
            pcVar21 = *ppcVar2;
            cVar5 = *pcVar21;
            goto code_r0x000180067232;
        }
code_r0x000180067246:
        *ppcVar2 = *(char **)(arg1 + 0xd0);
        *ppcVar3 = *(char **)(arg1 + 0xd8);
    }
    iVar9 = func_0x000180072ce0(arg1);
    if (iVar9 != 0) {
        func_0x000180073b70(arg1, arg2, var_b0h);
        goto code_r0x000180068d5b;
    }
    iVar9 = func_0x000180069950(arg1);
    iVar10 = func_0x000180069950(arg1);
    *ppcVar2 = *(char **)(arg1 + 0xd0);
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    if (iVar10 + iVar9 * 0x10000 == 0x38425053) {
        iVar9 = func_0x000180069950();
        iVar10 = func_0x000180069950(arg1);
        if ((iVar10 + iVar9 * 0x10000 == 0x38425053) && (iVar9 = func_0x000180069950(arg1), iVar9 == 1)) {
            if ((*(int64_t *)(arg1 + 0x10) == 0) || (iVar9 = *(int32_t *)ppcVar2, 5 < *(int32_t *)ppcVar3 - iVar9)) {
                *ppcVar2 = *ppcVar2 + 6;
            } else {
                *ppcVar2 = *ppcVar3;
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 6 - (*(int32_t *)ppcVar3 - iVar9));
            }
            uVar11 = func_0x000180069950(arg1);
            var_e8h._4_4_ = uVar11;
            if (uVar11 < 0x11) {
                uVar12 = func_0x000180069a00(arg1);
                var_cch._4_4_ = uVar12;
                iVar9 = func_0x000180069a00(arg1);
                var_cch._0_4_ = iVar9;
                if ((((int32_t)uVar12 < 0x1000001) && (iVar9 < 0x1000001)) &&
                   ((iVar10 = func_0x000180069950(arg1), (iVar10 - 8U & 0xfffffff7) == 0 &&
                    (iVar13 = func_0x000180069950(arg1), iVar13 == 3)))) {
                    uVar14 = func_0x000180069a00(arg1);
                    func_0x000180069830(arg1, uVar14);
                    uVar14 = func_0x000180069a00(arg1);
                    func_0x000180069830(arg1, uVar14);
                    func_0x000180069a00(arg1);
                    func_0x000180069830(arg1);
                    iVar13 = func_0x000180069950(arg1);
                    if ((((iVar13 < 2) && (-1 < iVar9)) &&
                        ((iVar9 == 0 || (3 < (int32_t)(0x7fffffff / (int64_t)iVar9))))) &&
                       (((-1 < iVar9 * 4 && (-1 < (int32_t)uVar12)) &&
                        ((uVar12 == 0 || (iVar9 * 4 <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12))))))) {
                        uVar12 = uVar12 * iVar9;
                        iVar16 = func_0x00018046d050((int64_t)(int32_t)(uVar12 * 4));
                        var_a8h = iVar16;
                        if (iVar16 != 0) {
                            if (iVar13 == 0) {
                                uVar27 = 0;
                                do {
                                    iVar9 = (int32_t)uVar27;
                                    if (iVar9 < (int32_t)uVar11) {
                                        iVar13 = 0;
                                        uVar11 = var_e8h._4_4_;
                                        if (*(int32_t *)var_c0h == 0x10) {
                                            puVar32 = (undefined2 *)(iVar16 + uVar27 * 2);
                                            if (0 < (int32_t)uVar12) {
                                                do {
                                                    uVar7 = func_0x000180069950(arg1);
                                                    iVar13 = iVar13 + 1;
                                                    *puVar32 = uVar7;
                                                    puVar32 = puVar32 + 4;
                                                    uVar11 = var_e8h._4_4_;
                                                } while (iVar13 < (int32_t)uVar12);
                                            }
                                        } else {
                                            puVar19 = (undefined *)(uVar27 + iVar16);
                                            if (iVar10 == 0x10) {
                                                if (0 < (int32_t)uVar12) {
                                                    do {
                                                        func_0x000180069950(arg1);
                                                        iVar13 = iVar13 + 1;
                                                        *puVar19 = extraout_AH;
                                                        puVar19 = puVar19 + 4;
                                                        uVar11 = var_e8h._4_4_;
                                                    } while (iVar13 < (int32_t)uVar12);
                                                }
                                            } else if (0 < (int32_t)uVar12) {
                                                do {
                                                    puVar29 = *(undefined **)(undefined8 *)(arg1 + 0xc0);
                                                    if (puVar29 < *(undefined **)(arg1 + 200)) {
                                                        uVar23 = *puVar29;
                                                        *(undefined8 *)(arg1 + 0xc0) = puVar29 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar23 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        puVar29 = *(undefined **)(undefined8 *)(arg1 + 0xc0);
                                                        uVar23 = *puVar29;
                                                        *(undefined8 *)(arg1 + 0xc0) = puVar29 + 1;
                                                    }
                                                    *puVar19 = uVar23;
                                                    iVar13 = iVar13 + 1;
                                                    puVar19 = puVar19 + 4;
                                                    iVar16 = var_a8h;
                                                    uVar11 = var_e8h._4_4_;
                                                } while (iVar13 < (int32_t)uVar12);
                                            }
                                        }
                                    } else {
                                        uVar23 = 0;
                                        puVar19 = (undefined *)(uVar27 + iVar16);
                                        if (iVar9 == 3) {
                                            uVar23 = 0xff;
                                        }
                                        iVar13 = 0;
                                        if (0 < (int32_t)uVar12) {
                                            do {
                                                iVar13 = iVar13 + 1;
                                                *puVar19 = uVar23;
                                                puVar19 = puVar19 + 4;
                                            } while (iVar13 < (int32_t)uVar12);
                                        }
                                    }
                                    uVar27 = (uint64_t)(iVar9 + 1U);
                                } while ((int32_t)(iVar9 + 1U) < 4);
                            } else {
                                func_0x000180069830();
                                var_d8h = 0;
                                do {
                                    puVar31 = (uint8_t *)((int32_t)var_d8h + iVar16);
                                    if ((int32_t)var_d8h < (int32_t)uVar11) {
                                        iVar9 = 0;
                                        uVar36 = uVar12;
                                        while (0 < (int32_t)uVar36) {
                                            puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar17 < *(uint8_t **)(arg1 + 200)) {
code_r0x000180067598:
                                                uVar30 = *puVar17;
                                                puVar18 = puVar17 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar18;
                                                if (uVar30 != 0x80) {
                                                    uVar11 = (uint32_t)uVar30;
                                                    if (uVar30 < 0x80) goto code_r0x00018006761f;
                                                    if (0x80 < uVar30) {
                                                        iVar10 = 0x101 - (uint32_t)uVar30;
                                                        if ((int32_t)uVar36 < iVar10) goto code_r0x0001800676a8;
                                                        if (puVar18 < *(uint8_t **)(arg1 + 200)) {
                                                            uVar30 = *puVar18;
                                                            *(uint8_t **)(arg1 + 0xc0) = puVar17 + 2;
                                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                            uVar30 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                            uVar30 = *puVar17;
                                                            *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                        }
                                                        iVar9 = iVar9 + iVar10;
                                                        for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                                                            *puVar31 = uVar30;
                                                            puVar31 = puVar31 + 4;
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) {
                                                    func_0x000180069750();
                                                    puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x000180067598;
                                                }
                                                uVar11 = 0;
code_r0x00018006761f:
                                                uVar11 = uVar11 + 1;
                                                if (uVar36 < uVar11) {
code_r0x0001800676a8:
                                                    func_0x000180460d90(iVar16);
                                                    goto code_r0x000180068d5b;
                                                }
                                                iVar9 = iVar9 + uVar11;
                                                do {
                                                    puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                    if (puVar17 < *(uint8_t **)(arg1 + 200)) {
                                                        uVar30 = *puVar17;
                                                        *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar30 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                        uVar30 = *puVar17;
                                                        *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                    }
                                                    *puVar31 = uVar30;
                                                    puVar31 = puVar31 + 4;
                                                    uVar11 = uVar11 - 1;
                                                } while (uVar11 != 0);
                                            }
                                            uVar11 = var_e8h._4_4_;
                                            uVar36 = uVar12 - iVar9;
                                        }
                                    } else {
                                        iVar9 = 0;
                                        if (0 < (int32_t)uVar12) {
                                            uVar30 = 0;
                                            if (var_d8h == 3) {
                                                uVar30 = 0xff;
                                            }
                                            do {
                                                iVar9 = iVar9 + 1;
                                                *puVar31 = uVar30;
                                                puVar31 = puVar31 + 4;
                                            } while (iVar9 < (int32_t)uVar12);
                                        }
                                    }
                                    var_d8h = var_d8h + 1;
                                } while ((int32_t)var_d8h < 4);
                            }
                            if (3 < (int32_t)uVar11) {
                                iVar9 = 0;
                                if (*(int32_t *)var_c0h == 0x10) {
                                    if (3 < (int32_t)uVar12) {
                                        do {
                                            iVar28 = (int64_t)(iVar9 * 4);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            uVar8 = *(uint16_t *)(iVar16 + 0xe + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + 8 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 8 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 10 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 10 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 0xc + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 0xc + iVar28 * 2)
                                                                        * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 8);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 0xc);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            iVar9 = iVar9 + 4;
                                        } while (iVar9 < (int32_t)(uVar12 - 3));
                                    }
                                    for (; iVar9 < (int32_t)uVar12; iVar9 = iVar9 + 1) {
                                        iVar28 = (int64_t)(iVar9 * 4);
                                        uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                        if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                            fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                            fVar37 = (1.0 - fVar38) * 65535.0;
                                            *(int16_t *)(iVar16 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)*(uint16_t *)(iVar16 + iVar28 * 2)
                                                                    * fVar38 + fVar37);
                                            *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)
                                                                           *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                    fVar38 + fVar37);
                                            *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)
                                                                           *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                    fVar38 + fVar37);
                                        }
                                    }
                                } else {
                                    if (3 < (int32_t)uVar12) {
                                        do {
                                            iVar28 = (int64_t)(iVar9 * 4);
                                            uVar30 = *(uint8_t *)(iVar16 + 3 + iVar28);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar16 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + iVar28) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar16 + 1 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 1 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 2 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 2 + iVar28)
                                                                     * fVar38 + fVar37);
                                            }
                                            uVar30 = *(uint8_t *)(iVar16 + 7 + iVar28);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar16 + 4 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 4 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 5 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 5 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 6 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 6 + iVar28)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 8);
                                            uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar28 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar28 + 1 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar28 + 2 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 0xc);
                                            uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar28 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar28 + 1 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar28 + 2 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar9 = iVar9 + 4;
                                        } while (iVar9 < (int32_t)(uVar12 - 3));
                                    }
                                    for (; iVar9 < (int32_t)uVar12; iVar9 = iVar9 + 1) {
                                        iVar28 = (int64_t)(iVar9 * 4);
                                        uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                        if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                            fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                            fVar37 = (1.0 - fVar38) * 255.0;
                                            *(char *)(iVar28 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) * fVar38
                                                                + fVar37);
                                            *(char *)(iVar28 + 1 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16) *
                                                                 fVar38 + fVar37);
                                            *(char *)(iVar28 + 2 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16) *
                                                                 fVar38 + fVar37);
                                        }
                                    }
                                }
                            }
                            *(uint32_t *)var_b0h = var_cch._4_4_;
                            *(int32_t *)var_b8h = (int32_t)var_cch;
                        }
                    }
                }
            }
        }
        goto code_r0x000180068d5b;
    }
    iVar9 = func_0x000180072b70(arg1, 0x18063cc84);
    if (iVar9 != 0) {
        iVar9 = 0x54;
        do {
            if (*ppcVar2 < *ppcVar3) {
                *ppcVar2 = *ppcVar2 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) != 0) {
                func_0x000180069750(arg1);
                *ppcVar2 = *ppcVar2 + 1;
            }
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
        iVar9 = func_0x000180072b70(arg1, 0x18063cc7c);
        if (iVar9 != 0) {
            pcVar21 = *(char **)(arg1 + 0xd0);
            ppcVar2 = (char **)(arg1 + 0xc0);
            iVar9 = 0x5c;
            *ppcVar2 = pcVar21;
            *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
            do {
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*(int32_t *)(arg1 + 0x30) != 0) {
                    func_0x000180069750(arg1);
                    *ppcVar2 = *ppcVar2 + 1;
                    pcVar21 = *ppcVar2;
                }
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
            uVar11 = func_0x000180069950(arg1);
            var_e8h._4_4_ = uVar11;
            uVar12 = func_0x000180069950(arg1);
            var_d8h = uVar12;
            if ((0x1000000 < (int32_t)uVar12) || (0x1000000 < (int32_t)uVar11)) goto code_r0x000180068d5b;
            if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180068e24:
                if (*(char **)(arg1 + 200) <= *ppcVar2) goto code_r0x000180068d5b;
            } else {
                iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                if (iVar9 != 0) {
                    if (*(int32_t *)(arg1 + 0x30) == 0) goto code_r0x000180068d5b;
                    goto code_r0x000180068e24;
                }
            }
            if (((((int32_t)uVar11 < 0) || ((int32_t)uVar12 < 0)) ||
                ((uVar12 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12) < (int32_t)uVar11)))) ||
               (0x1fffffff < uVar11 * uVar12)) goto code_r0x000180068d5b;
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            if ((uVar12 != 0) && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12) < (int32_t)uVar11))
            goto code_r0x000180068d5b;
            iVar16 = (int64_t)(int32_t)(uVar11 * uVar12 * 4);
            var_c0h = func_0x00018046d050(iVar16);
            if (var_c0h == 0) goto code_r0x000180068d5b;
            func_0x0001804986e0(var_c0h, 0xff, iVar16);
            var_e0h._4_4_ = 0;
            do {
                if (var_e0h._4_4_ == 10) goto code_r0x0001800693c0;
                iVar16 = (int64_t)var_e0h._4_4_;
                pcVar21 = *ppcVar2;
                piVar1 = (int32_t *)(arg1 + 0x30);
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar5 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar5 = '\0';
                } else {
                    func_0x000180069750();
                    cVar5 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar24 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar24 = '\0';
                } else {
                    func_0x000180069750();
                    cVar24 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                *(char *)((int64_t)&var_98h + iVar16 * 3) = cVar24;
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar25 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar25 = '\0';
                } else {
                    func_0x000180069750(arg1);
                    cVar25 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                *(char *)((int64_t)&var_98h + iVar16 * 3 + 1) = cVar25;
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar25 = *pcVar21;
                    *ppcVar2 = pcVar21 + 1;
                } else if (*piVar1 == 0) {
                    cVar25 = '\0';
                } else {
                    func_0x000180069750(arg1);
                    cVar25 = **ppcVar2;
                    *ppcVar2 = *ppcVar2 + 1;
                }
                iVar28 = *(int64_t *)(arg1 + 0x10);
                *(char *)((int64_t)&var_98h + iVar16 * 3 + 2) = cVar25;
                if (iVar28 == 0) {
code_r0x000180068fed:
                    if (*(char **)(arg1 + 200) <= *ppcVar2) goto code_r0x0001800693c0;
                } else {
                    iVar9 = (**(code **)(arg1 + 0x20))();
                    if (iVar9 != 0) {
                        if (*piVar1 != 0) goto code_r0x000180068fed;
                        goto code_r0x0001800693c0;
                    }
                }
                if (cVar24 != '\b') goto code_r0x0001800693c0;
                iVar9 = var_e0h._4_4_ + 1;
                var_e0h._4_4_ = iVar9;
            } while (cVar5 != '\0');
            var_cch._0_4_ = 0;
            var_f8h._0_4_ = var_d8h;
            if (0 < (int32_t)var_d8h) {
                do {
                    uVar27 = 0;
                    var_cch._4_4_ = 0;
                    if (0 < iVar9) {
                        puVar19 = (undefined *)((int32_t)((int32_t)var_cch * var_e8h._4_4_ * 4) + var_c0h);
                        var_a0h = (int64_t)puVar19;
                        uVar11 = var_e8h._4_4_;
                        do {
                            iVar16 = uVar27 * 3;
                            cVar5 = *(char *)((int64_t)&var_98h + iVar16 + 1);
                            var_a8h = iVar16;
                            if (cVar5 == '\0') {
                                if (0 < (int32_t)uVar11) {
                                    uVar23 = *(undefined *)((int64_t)&var_98h + iVar16 + 2);
                                    iVar9 = 0;
                                    puVar29 = puVar19;
                                    do {
                                        iVar16 = func_0x000180072c10(arg1, uVar23, puVar29);
                                        if (iVar16 == 0) goto code_r0x0001800693c0;
                                        iVar9 = iVar9 + 1;
                                        puVar29 = puVar29 + 4;
                                        puVar19 = (undefined *)var_a0h;
                                    } while (iVar9 < (int32_t)uVar11);
                                }
                            } else {
                                puVar29 = puVar19;
                                uVar12 = uVar11;
                                if (cVar5 == '\x01') {
                                    while (0 < (int32_t)uVar12) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar11 = (uint32_t)*puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar11 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar11 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180069294:
                                            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0))
                                            goto code_r0x0001800693c0;
                                        } else {
                                            iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                                            if (iVar9 != 0) {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x000180069294;
                                                goto code_r0x0001800693c0;
                                            }
                                        }
                                        if (uVar12 < uVar11) {
                                            uVar11 = uVar12 & 0xff;
                                        }
                                        uVar30 = *(uint8_t *)((int64_t)&var_98h + iVar16 + 2);
                                        iVar28 = func_0x000180072c10(arg1, uVar30, &var_d4h);
                                        if (iVar28 == 0) goto code_r0x0001800693c0;
                                        iVar9 = 0;
                                        if ((char)uVar11 != '\0') {
                                            do {
                                                if ((uVar30 & 0x80) != 0) {
                                                    *puVar29 = (char)var_d4h;
                                                }
                                                if ((uVar30 & 0x40) != 0) {
                                                    puVar29[1] = var_d4h._1_1_;
                                                }
                                                if ((uVar30 & 0x20) != 0) {
                                                    puVar29[2] = var_d4h._2_1_;
                                                }
                                                if ((uVar30 & 0x10) != 0) {
                                                    puVar29[3] = var_d4h._3_1_;
                                                }
                                                iVar9 = iVar9 + 1;
                                                puVar29 = puVar29 + 4;
                                                iVar16 = var_a8h;
                                            } while (iVar9 < (int32_t)uVar11);
                                        }
                                        puVar19 = (undefined *)var_a0h;
                                        uVar12 = uVar12 - uVar11;
                                        uVar11 = var_e8h._4_4_;
                                    }
                                } else {
                                    if (cVar5 != '\x02') goto code_r0x0001800693c0;
                                    while (0 < (int32_t)uVar12) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar30 = *puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar30 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar30 = **(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800690ff:
                                            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0))
                                            goto code_r0x0001800693c0;
                                        } else {
                                            iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                                            if (iVar9 != 0) {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x0001800690ff;
                                                goto code_r0x0001800693c0;
                                            }
                                        }
                                        uVar11 = (uint32_t)uVar30;
                                        if (uVar11 < 0x80) {
                                            uVar11 = uVar11 + 1;
                                            if (uVar12 < uVar11) goto code_r0x0001800693c0;
                                            if (uVar11 != 0) {
                                                uVar23 = *(undefined *)((int64_t)&var_98h + iVar16 + 2);
                                                iVar9 = 0;
                                                do {
                                                    iVar16 = func_0x000180072c10(arg1, uVar23, puVar29);
                                                    if (iVar16 == 0) goto code_r0x0001800693c0;
                                                    iVar9 = iVar9 + 1;
                                                    puVar29 = puVar29 + 4;
                                                    iVar16 = var_a8h;
                                                } while (iVar9 < (int32_t)uVar11);
                                            }
                                        } else {
                                            if (uVar11 == 0x80) {
                                                uVar11 = func_0x000180069950(arg1);
                                            } else {
                                                uVar11 = uVar30 - 0x7f;
                                            }
                                            if ((int32_t)uVar12 < (int32_t)uVar11) goto code_r0x0001800693c0;
                                            uVar30 = *(uint8_t *)((int64_t)&var_98h + iVar16 + 2);
                                            iVar28 = func_0x000180072c10(arg1, uVar30, &var_d0h);
                                            if (iVar28 == 0) goto code_r0x0001800693c0;
                                            iVar9 = 0;
                                            if (0 < (int32_t)uVar11) {
                                                do {
                                                    if ((uVar30 & 0x80) != 0) {
                                                        *puVar29 = (char)var_d0h;
                                                    }
                                                    if ((uVar30 & 0x40) != 0) {
                                                        puVar29[1] = var_d0h._1_1_;
                                                    }
                                                    if ((uVar30 & 0x20) != 0) {
                                                        puVar29[2] = var_d0h._2_1_;
                                                    }
                                                    if ((uVar30 & 0x10) != 0) {
                                                        puVar29[3] = var_d0h._3_1_;
                                                    }
                                                    iVar9 = iVar9 + 1;
                                                    puVar29 = puVar29 + 4;
                                                    iVar16 = var_a8h;
                                                } while (iVar9 < (int32_t)uVar11);
                                            }
                                        }
                                        puVar19 = (undefined *)var_a0h;
                                        uVar12 = uVar12 - uVar11;
                                        uVar11 = var_e8h._4_4_;
                                    }
                                }
                            }
                            var_cch._4_4_ = var_cch._4_4_ + 1;
                            uVar27 = (uint64_t)var_cch._4_4_;
                            iVar9 = var_e0h._4_4_;
                            var_f8h._0_4_ = var_d8h;
                        } while ((int32_t)var_cch._4_4_ < var_e0h._4_4_);
                    }
                    var_cch._0_4_ = (int32_t)var_cch + 1;
                } while ((int32_t)var_cch < (int32_t)(uint32_t)var_f8h);
            }
            goto code_r0x0001800693d5;
        }
    }
    *ppcVar2 = *(char **)(arg1 + 0xd0);
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    piVar20 = (int64_t *)func_0x00018046d050();
    if (piVar20 != (int64_t *)0x0) {
        *piVar20 = arg1;
        func_0x00018006e660(piVar20);
        iVar9 = func_0x00018006d480(piVar20, 1);
        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
        *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
        func_0x000180460d90();
        if (iVar9 != 0) {
            piVar20 = (int64_t *)func_0x00018046d050(0x4888);
            if (piVar20 != (int64_t *)0x0) {
                *piVar20 = arg1;
                func_0x00018006e660(piVar20);
                var_f8h._0_4_ = 4;
                func_0x00018006e6e0(piVar20, var_b8h, var_b0h, 0);
                func_0x000180460d90(piVar20);
            }
            goto code_r0x000180068d5b;
        }
    }
    pcVar21 = *(char **)(arg1 + 0xc0);
    if (pcVar21 < *(char **)(arg1 + 200)) {
        cVar5 = *pcVar21;
        pcVar21 = pcVar21 + 1;
        *(char **)(arg1 + 0xc0) = pcVar21;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar5 = '\0';
    } else {
        func_0x000180069750();
        cVar5 = **(char **)(arg1 + 0xc0);
        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
        *(char **)(arg1 + 0xc0) = pcVar21;
    }
    if (pcVar21 < *(char **)(arg1 + 200)) {
        cVar24 = *pcVar21;
        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar24 = '\0';
    } else {
        func_0x000180069750(arg1);
        cVar24 = **(char **)(arg1 + 0xc0);
        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
    }
    if ((cVar5 == 'P') && (cVar24 == '5' || cVar24 == '6')) {
        iVar9 = func_0x000180074950(arg1, arg1, arg1 + 4, arg1 + 8);
        *(int32_t *)arg_30h = iVar9;
        if ((iVar9 != 0) && ((*(uint32_t *)(arg1 + 4) < 0x1000001 && (*(uint32_t *)arg1 < 0x1000001)))) {
            *(uint32_t *)var_b8h = *(uint32_t *)arg1;
            *(undefined4 *)var_b0h = *(undefined4 *)(arg1 + 4);
            iVar9 = *(int32_t *)(arg1 + 8);
            if (-1 < iVar9) {
                iVar10 = *(int32_t *)arg1;
                if ((-1 < iVar10) &&
                   (((iVar10 == 0 || (iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))) && (-1 < iVar9 * iVar10)))) {
                    iVar13 = *(int32_t *)(arg1 + 4);
                    if ((-1 < iVar13) &&
                       (((iVar13 == 0 || (iVar9 * iVar10 <= (int32_t)(0x7fffffff / (int64_t)iVar13))) &&
                        (iVar26 = iVar9 * iVar10 * iVar13, -1 < iVar26)))) {
                        uVar11 = *(int32_t *)arg_30h >> 0x1f & 7;
                        uVar27 = (uint64_t)uVar11;
                        iVar15 = (int32_t)(*(int32_t *)arg_30h + uVar11) >> 3;
                        if ((((-1 < iVar15) &&
                             ((iVar15 == 0 ||
                              (uVar27 = 0x7fffffff % (int64_t)iVar15 & 0xffffffff,
                              iVar26 <= (int32_t)(0x7fffffff / (int64_t)iVar15))))) &&
                            ((iVar10 == 0 ||
                             (uVar27 = 0x7fffffff % (int64_t)iVar10 & 0xffffffff,
                             iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))))) &&
                           ((iVar13 == 0 ||
                            (uVar27 = 0x7fffffff % (int64_t)iVar13 & 0xffffffff,
                            iVar9 * iVar10 <= (int32_t)(0x7fffffff / (int64_t)iVar13))))) {
                            iVar26 = iVar9 * iVar13 * iVar10;
                            if ((-1 < iVar26) &&
                               (((iVar15 == 0 ||
                                 (uVar27 = 0x7fffffff % (int64_t)iVar15 & 0xffffffff,
                                 iVar26 <= (int32_t)(0x7fffffff / (int64_t)iVar15))) &&
                                (iVar16 = func_0x00018046d050((int64_t)(iVar9 * iVar13 * iVar15 * iVar10), uVar27),
                                iVar16 != 0)))) {
                                func_0x000180069890(arg1, iVar16, 
                                                    *(int32_t *)(arg1 + 8) * *(int32_t *)(arg1 + 4) *
                                                    ((int32_t)(*(int32_t *)arg_30h + (*(int32_t *)arg_30h >> 0x1f & 7U))
                                                    >> 3) * *(int32_t *)arg1);
                                if (*(int32_t *)(arg1 + 8) != 4) {
                                    var_f8h._0_4_ = *(uint32_t *)(arg1 + 4);
                                    func_0x000180069b10(iVar16, *(int32_t *)(arg1 + 8), 4, *(undefined4 *)arg1);
                                }
                            }
                        }
                    }
                }
            }
        }
        goto code_r0x000180068d5b;
    }
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    iVar9 = func_0x000180073cf0(arg1);
    iVar28 = var_b0h;
    iVar16 = var_b8h;
    if (iVar9 != 0) {
        iVar22 = func_0x000180073fe0(arg1, var_b8h);
        if (iVar22 != 0) {
            iVar9 = *(int32_t *)iVar16;
            if (-1 < iVar9) {
                iVar10 = *(int32_t *)iVar28;
                if ((((-1 < iVar10) && ((iVar10 == 0 || (iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))))) &&
                    (uVar11 = iVar9 * iVar10, uVar11 < 0x20000000)) &&
                   (iVar16 = func_0x00018046d050((int64_t)(int32_t)(uVar11 * 4)), iVar16 != 0)) {
                    var_d8h = 0;
                    var_c0h = iVar16;
                    if (0 < (int32_t)uVar11) {
                        do {
                            iVar10 = 0;
                            iVar9 = var_d8h * 4;
                            do {
                                iVar28 = (int64_t)iVar9;
                                fVar37 = (float)func_0x000180492580(*(undefined4 *)(iVar22 + iVar28 * 4));
                                iVar10 = iVar10 + 1;
                                iVar9 = iVar9 + 1;
                                fVar38 = fVar37 * 255.0 + 0.5;
                                fVar37 = 0.0;
                                if (0.0 <= fVar38) {
                                    fVar37 = fVar38;
                                }
                                fVar38 = 255.0;
                                if (fVar37 <= 255.0) {
                                    fVar38 = fVar37;
                                }
                                *(char *)(iVar28 + var_c0h) = (char)(int32_t)fVar38;
                            } while (iVar10 < 3);
                            iVar9 = var_d8h * 4;
                            var_d8h = var_d8h + 1;
                            iVar28 = (int64_t)(iVar9 + iVar10);
                            fVar38 = *(float *)(iVar22 + iVar28 * 4) * 255.0 + 0.5;
                            fVar37 = 0.0;
                            if (0.0 <= fVar38) {
                                fVar37 = fVar38;
                            }
                            fVar38 = 255.0;
                            if (fVar37 <= 255.0) {
                                fVar38 = fVar37;
                            }
                            *(char *)(iVar28 + iVar16) = (char)(int32_t)fVar38;
                        } while ((int32_t)var_d8h < (int32_t)uVar11);
                    }
                    func_0x000180460d90(iVar22);
                    goto code_r0x000180068d5b;
                }
            }
            func_0x000180460d90(iVar22);
        }
        goto code_r0x000180068d5b;
    }
    puVar31 = *(uint8_t **)(arg1 + 0xc0);
    if (puVar31 < *(uint8_t **)(arg1 + 200)) {
code_r0x000180068377:
        puVar31 = puVar31 + 1;
        *(uint8_t **)(arg1 + 0xc0) = puVar31;
    } else if (*(int32_t *)(arg1 + 0x30) != 0) {
        func_0x000180069750(arg1);
        puVar31 = *(uint8_t **)(arg1 + 0xc0);
        goto code_r0x000180068377;
    }
    if (puVar31 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800683ad:
        uVar30 = *puVar31;
        *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
        if (uVar30 < 2) {
            cVar5 = func_0x0001800697d0(arg1);
            if (uVar30 != 1) goto code_r0x000180068480;
            if ((cVar5 - 1U & 0xf7) == 0) {
                if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                   (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 3 < iVar9)) {
                    *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 4;
                } else {
                    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                    (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 4 - iVar9);
                }
                uVar6 = func_0x0001800697d0(arg1);
                if ((uVar6 < 0x21) && ((0x101018100U >> ((uint64_t)uVar6 & 0x3f) & 1) != 0)) {
                    if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                       (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 3 < iVar9)) {
                        *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 4;
                    } else {
                        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                        (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 4 - iVar9);
                    }
                    goto code_r0x0001800684c8;
                }
            }
        }
    } else {
        if (*(int32_t *)(arg1 + 0x30) != 0) {
            func_0x000180069750();
            puVar31 = *(uint8_t **)(arg1 + 0xc0);
            goto code_r0x0001800683ad;
        }
        uVar30 = 0;
        cVar5 = func_0x0001800697d0(arg1);
code_r0x000180068480:
        if ((cVar5 - 2U & 0xf6) == 0) {
            if ((*(int64_t *)(arg1 + 0x10) == 0) ||
               (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 8 < iVar9)) {
                *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 9;
            } else {
                *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 9 - iVar9);
            }
code_r0x0001800684c8:
            iVar9 = func_0x000180069a30(arg1);
            if ((0 < iVar9) && (iVar9 = func_0x000180069a30(arg1), 0 < iVar9)) {
                uVar6 = func_0x0001800697d0(arg1);
                if (uVar30 == 1) {
                    if (uVar6 != 8) {
                        if (uVar6 != 0x10) goto code_r0x000180068d3d;
                        goto code_r0x000180068503;
                    }
                } else {
code_r0x000180068503:
                    if ((0x20 < uVar6) || ((0x101018100U >> ((uint64_t)uVar6 & 0x3f) & 1) == 0))
                    goto code_r0x000180068d3d;
                }
                puVar31 = *(uint8_t **)(arg1 + 0xd0);
                *(uint8_t **)(arg1 + 0xc0) = puVar31;
                *(uint8_t **)(arg1 + 200) = *(uint8_t **)(arg1 + 0xd8);
                if (puVar31 < *(uint8_t **)(arg1 + 0xd8)) {
                    var_e0h._0_1_ = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    var_e0h._0_1_ = 0;
                } else {
                    func_0x000180069750(arg1);
                    var_e0h._0_1_ = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    var_e8h._0_1_ = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    var_e8h._0_1_ = 0;
                } else {
                    func_0x000180069750(arg1);
                    var_e8h._0_1_ = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar30 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar30 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar30 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                var_cch._0_4_ = func_0x000180069a30(arg1);
                var_d0h = func_0x000180069a30(arg1);
                puVar31 = *(uint8_t **)(arg1 + 0xc0);
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar6 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar6 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar6 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                func_0x000180069a30(arg1);
                func_0x000180069a30(arg1);
                var_e0h._4_4_ = func_0x000180069a30(arg1);
                uVar11 = func_0x000180069a30(arg1);
                puVar31 = *(uint8_t **)(arg1 + 0xc0);
                var_cch._4_4_ = uVar11;
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar34 = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar34 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar34 = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar35 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar35 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar35 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                iVar9 = var_e0h._4_4_;
                uVar12 = 0;
                var_d4h = 0;
                if ((0x1000000 < (int32_t)uVar11) || (0x1000000 < var_e0h._4_4_)) goto code_r0x000180068d5b;
                var_d8h = (uint32_t)uVar30;
                uVar33 = (uint32_t)uVar34;
                var_a8h = CONCAT44(var_a8h._4_4_, uVar33);
                uVar36 = uVar30 - 8;
                var_e8h._4_4_ = 0;
                if (var_d8h < 8) {
                    uVar36 = (uint32_t)uVar30;
                }
                if ((uint8_t)var_e8h == 0) {
                    if (uVar33 == 8) goto code_r0x0001800687c1;
                    if (uVar33 == 0xf) {
code_r0x0001800687b5:
                        uVar12 = 3;
                        var_e8h._4_4_ = 1;
                    } else if (uVar33 == 0x10) {
                        if (uVar36 != 3) goto code_r0x0001800687b5;
                        uVar12 = 2;
                    } else {
                        if ((uVar33 == 0x18) || (uVar33 == 0x20)) {
                            uVar36 = (uint32_t)uVar34;
                            goto code_r0x0001800687a4;
                        }
                        uVar12 = 0;
                    }
                } else {
                    uVar36 = (uint32_t)uVar6;
                    if (uVar36 != 8) {
                        if ((uVar36 != 0xf) && (uVar36 != 0x10)) {
                            if ((uVar36 == 0x18) || (uVar36 == 0x20)) {
code_r0x0001800687a4:
                                uVar12 = uVar36 >> 3;
                            }
                            goto code_r0x0001800687c4;
                        }
                        goto code_r0x0001800687b5;
                    }
code_r0x0001800687c1:
                    uVar12 = 1;
                }
code_r0x0001800687c4:
                if (uVar12 == 0) goto code_r0x000180068d5b;
                *(int32_t *)var_b8h = var_e0h._4_4_;
                *(uint32_t *)var_b0h = uVar11;
                if (((((var_e0h._4_4_ < 0) || ((int32_t)uVar11 < 0)) ||
                     ((uVar11 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar11) < var_e0h._4_4_)))) ||
                    ((((int32_t)(var_e0h._4_4_ * uVar11) < 0 ||
                      (uVar27 = 0x7fffffff % (uint64_t)uVar12,
                      (int32_t)(0x7fffffff / (uint64_t)uVar12) < (int32_t)(var_e0h._4_4_ * uVar11))) ||
                     ((uVar11 != 0 &&
                      (uVar27 = 0x7fffffff % (int64_t)(int32_t)uVar11 & 0xffffffff,
                      (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar11) < var_e0h._4_4_)))))) ||
                   (puVar19 = (undefined *)
                              func_0x00018046d050((int64_t)(int32_t)(uVar12 * var_e0h._4_4_ * uVar11), uVar27),
                   puVar19 == (undefined *)0x0)) goto code_r0x000180068d5b;
                iVar13 = 1 - (uVar35 >> 5 & 1);
                var_b8h = CONCAT44(var_b8h._4_4_, iVar13);
                func_0x000180069830();
                iVar10 = var_d0h;
                if ((uint8_t)var_e8h == 0) {
                    if ((var_d8h < 8) && (var_e8h._4_4_ == 0)) {
                        if (0 < (int32_t)uVar11) {
                            iVar10 = 0;
                            if (iVar13 == 0) {
                                iVar13 = uVar12 * var_e0h._4_4_;
                                do {
                                    func_0x000180069890(arg1, puVar19 + iVar13 * iVar10);
                                    iVar10 = iVar10 + 1;
                                    iVar9 = var_e0h._4_4_;
                                } while (iVar10 < (int32_t)uVar11);
                            } else {
                                iVar13 = uVar12 * var_e0h._4_4_;
                                do {
                                    func_0x000180069890(arg1, puVar19 + (int32_t)(((uVar11 - iVar10) + -1) * iVar13));
                                    iVar10 = iVar10 + 1;
                                    iVar9 = var_e0h._4_4_;
                                } while (iVar10 < (int32_t)uVar11);
                            }
                        }
                    } else {
                        var_c0h = 0;
                        iVar16 = 0;
code_r0x0001800689e1:
                        bVar4 = true;
                        var_cch._0_4_ = 0;
                        iVar9 = var_e0h._4_4_ * uVar11;
                        iVar10 = 0;
                        var_b0h = CONCAT44(var_b0h._4_4_, iVar9);
                        if (0 < iVar9) {
                            uVar36 = 0;
                            do {
                                if (var_d8h < 8) {
code_r0x000180068a7a:
                                    if ((uint8_t)var_e8h == 0) {
                                        if (var_e8h._4_4_ == 0) {
                                            uVar27 = 0;
                                            if (uVar12 != 0) {
                                                do {
                                                    puVar29 = *(undefined **)(arg1 + 0xc0);
                                                    if (puVar29 < *(undefined **)(arg1 + 200)) {
                                                        uVar23 = *puVar29;
                                                        *(undefined **)(arg1 + 0xc0) = puVar29 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar23 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        uVar23 = **(undefined **)(arg1 + 0xc0);
                                                        *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
                                                    }
                                                    *(undefined *)((int64_t)&var_d4h + uVar27) = uVar23;
                                                    uVar11 = (int32_t)uVar27 + 1;
                                                    uVar27 = (uint64_t)uVar11;
                                                } while ((int32_t)uVar11 < (int32_t)uVar12);
                                            }
                                        } else {
                                            uVar8 = func_0x000180069a30(arg1);
                                            uVar14 = var_d4h;
                                            var_d4h._3_1_ = SUB41(uVar14, 3);
                                        }
                                    } else {
                                        if ((int32_t)var_a8h == 8) {
                                            puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                                uVar30 = *puVar31;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                                uVar11 = (uint32_t)uVar30;
                                            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                uVar11 = 0;
                                            } else {
                                                func_0x000180069750(arg1);
                                                uVar30 = **(uint8_t **)(arg1 + 0xc0);
                                                *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                uVar11 = (uint32_t)uVar30;
                                            }
                                        } else {
                                            uVar11 = func_0x000180069a30();
                                        }
                                        uVar33 = 0;
                                        if ((int32_t)uVar11 < var_d0h) {
                                            uVar33 = uVar11;
                                        }
                                        uVar27 = 0;
                                        if (uVar12 != 0) {
                                            do {
                                                *(undefined *)((int64_t)&var_d4h + uVar27) =
                                                     *(undefined *)
                                                      ((int32_t)((int32_t)uVar27 + uVar33 * uVar12) + iVar16);
                                                uVar11 = (int32_t)uVar27 + 1;
                                                uVar27 = (uint64_t)uVar11;
                                            } while ((int32_t)uVar11 < (int32_t)uVar12);
                                        }
                                    }
                                    bVar4 = false;
                                    iVar9 = (int32_t)var_b0h;
                                } else {
                                    if (iVar10 == 0) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar36 = (uint32_t)*puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar36 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar36 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        iVar10 = (uVar36 & 0x7f) + 1;
                                        uVar36 = uVar36 >> 7;
                                        goto code_r0x000180068a7a;
                                    }
                                    if ((uVar36 == 0) || (bVar4)) goto code_r0x000180068a7a;
                                }
                                if (uVar12 != 0) {
                                    uVar27 = 0;
                                    do {
                                        iVar13 = (int32_t)uVar27;
                                        puVar29 = (undefined *)((int64_t)&var_d4h + uVar27);
                                        uVar11 = iVar13 + 1;
                                        uVar27 = (uint64_t)uVar11;
                                        puVar19[(int32_t)(uVar12 * (int32_t)var_cch + iVar13)] = *puVar29;
                                    } while ((int32_t)uVar11 < (int32_t)uVar12);
                                }
                                var_cch._0_4_ = (int32_t)var_cch + 1;
                                iVar10 = iVar10 + -1;
                                iVar16 = var_c0h;
                                uVar11 = var_cch._4_4_;
                            } while ((int32_t)var_cch < iVar9);
                        }
                        if (((int32_t)var_b8h != 0) && (iVar9 = 0, 0 < (int32_t)uVar11)) {
                            iVar10 = uVar12 * var_e0h._4_4_;
                            do {
                                iVar26 = iVar10 * iVar9;
                                iVar15 = ((uVar11 - iVar9) + -1) * iVar10;
                                for (iVar13 = iVar10; 0 < iVar13; iVar13 = iVar13 + -1) {
                                    uVar23 = puVar19[iVar26];
                                    puVar19[iVar26] = puVar19[iVar15];
                                    puVar19[iVar15] = uVar23;
                                    iVar26 = iVar26 + 1;
                                    iVar15 = iVar15 + 1;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 * 2 < (int32_t)uVar11);
                        }
                        iVar9 = var_e0h._4_4_;
                        if (var_c0h != 0) {
                            func_0x000180460d90(var_c0h);
                            iVar9 = var_e0h._4_4_;
                        }
                    }
                    if ((2 < uVar12) && (var_e8h._4_4_ == 0)) {
                        iVar10 = 0;
                        if (0 < (int32_t)(iVar9 * uVar11)) {
                            puVar29 = puVar19;
                            do {
                                uVar23 = *puVar29;
                                iVar10 = iVar10 + 1;
                                *puVar29 = puVar29[2];
                                puVar29[2] = uVar23;
                                puVar29 = puVar29 + uVar12;
                            } while (iVar10 < (int32_t)(iVar9 * uVar11));
                        }
                    }
                    if (uVar12 != 4) {
                        var_f8h._0_4_ = uVar11;
                        func_0x000180069b10(puVar19, uVar12, 4, iVar9);
                    }
                } else {
                    if (((var_d0h != 0) && (func_0x000180069830(arg1), -1 < iVar10)) &&
                       (iVar10 <= (int32_t)(0x7fffffff / (uint64_t)uVar12))) {
                        iVar16 = func_0x00018046d050();
                        iVar9 = var_d0h;
                        var_c0h = iVar16;
                        if (iVar16 != 0) {
                            if (var_e8h._4_4_ == 0) {
                                iVar9 = func_0x000180069890();
                                if (iVar9 == 0) {
                                    func_0x000180460d90(puVar19);
                                    func_0x000180460d90(iVar16);
                                    goto code_r0x000180068d5b;
                                }
                            } else {
                                iVar10 = 0;
                                if (0 < var_d0h) {
                                    do {
                                        func_0x000180072ae0();
                                        iVar10 = iVar10 + 1;
                                        iVar16 = var_c0h;
                                        uVar11 = var_cch._4_4_;
                                    } while (iVar10 < iVar9);
                                }
                            }
                            goto code_r0x0001800689e1;
                        }
                    }
                    func_0x000180460d90(puVar19);
                }
                goto code_r0x000180068d5b;
            }
        }
    }
code_r0x000180068d3d:
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
code_r0x000180068d5b:
    func_0x000180459870(var_70h ^ (uint64_t)auStack_118);
    return;
code_r0x0001800693c0:
    func_0x000180460d90(var_c0h);
    var_c0h = 0;
    var_f8h._0_4_ = var_d8h;
code_r0x0001800693d5:
    *(uint32_t *)var_b8h = var_e8h._4_4_;
    *(uint32_t *)var_b0h = (uint32_t)var_f8h;
    func_0x000180069b10(var_c0h, 4, 4);
    goto code_r0x000180068d5b;
}

// ============================================================
// Function: FUN_180068247
// Address: 0x180068247
// Size: 232 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d3h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_96h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_cdh
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_cfh
// WARNING: [rz-ghidra] Detected overlap for variable var_90h

void fcn.1800670c0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
                  int64_t arg_30h)
{
    int32_t *piVar1;
    char **ppcVar2;
    char **ppcVar3;
    bool bVar4;
    char cVar5;
    uint8_t uVar6;
    undefined2 uVar7;
    uint16_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    undefined4 uVar14;
    int32_t iVar15;
    int64_t iVar16;
    uint8_t *puVar17;
    uint8_t *puVar18;
    undefined *puVar19;
    undefined extraout_AH;
    int64_t *piVar20;
    char *pcVar21;
    int64_t iVar22;
    undefined uVar23;
    char cVar24;
    char cVar25;
    int32_t iVar26;
    uint64_t uVar27;
    int64_t iVar28;
    undefined *puVar29;
    uint8_t uVar30;
    uint8_t *puVar31;
    undefined2 *puVar32;
    uint32_t uVar33;
    uint8_t uVar34;
    uint8_t uVar35;
    uint32_t uVar36;
    float fVar37;
    float fVar38;
    int64_t var_20h;
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    uint32_t var_d8h;
    undefined4 var_d4h;
    undefined4 var_d0h;
    int64_t var_cch;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined8 var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    iVar10 = 8;
    var_c0h = arg_30h;
    *(undefined8 *)arg_30h = 8;
    *(undefined4 *)(arg_30h + 8) = 0;
    var_b8h = arg2;
    var_b0h = arg3;
    iVar9 = func_0x00018006f850();
    pcVar21 = *(char **)(arg1 + 0xd0);
    ppcVar2 = (char **)(arg1 + 0xc0);
    ppcVar3 = (char **)(arg1 + 200);
    *ppcVar2 = pcVar21;
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    if (iVar9 != 0) {
        var_98h = arg1;
        iVar9 = func_0x0001800708b0(&var_98h, 0, 4);
        iVar16 = var_80h;
        if (iVar9 != 0) {
            if (8 < (int32_t)var_78h) {
                if ((int32_t)var_78h != 0x10) goto code_r0x000180068d5b;
                iVar10 = 0x10;
            }
            *(int32_t *)arg_30h = iVar10;
            var_80h = 0;
            if (*(int32_t *)(var_98h + 0xc) != 4) {
                var_f8h._0_4_ = *(uint32_t *)(var_98h + 4);
                if (iVar10 == 8) {
                    iVar16 = func_0x000180069b10(iVar16, *(int32_t *)(var_98h + 0xc), 4);
                } else {
                    iVar16 = func_0x000180069fc0(iVar16);
                }
                *(undefined4 *)(var_98h + 0xc) = 4;
                if (iVar16 == 0) goto code_r0x000180068d5b;
            }
            *(undefined4 *)var_b8h = *(undefined4 *)var_98h;
            *(undefined4 *)arg3 = *(undefined4 *)(var_98h + 4);
        }
        func_0x000180460d90(var_80h);
        var_80h = 0;
        func_0x000180460d90(var_88h);
        var_88h = 0;
        func_0x000180460d90(var_90h);
        goto code_r0x000180068d5b;
    }
    if (pcVar21 < *(char **)(arg1 + 0xd8)) {
        cVar5 = *pcVar21;
code_r0x000180067232:
        *ppcVar2 = pcVar21 + 1;
        if ((cVar5 != 'B') || (cVar5 = func_0x0001800697d0(arg1), cVar5 != 'M')) goto code_r0x000180067246;
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        iVar9 = func_0x000180069a30(arg1);
        iVar10 = func_0x000180069a30(arg1);
        uVar11 = iVar10 * 0x10000 + iVar9;
        if ((((uVar11 < 0x39) && ((0x100010000001000U >> ((uint64_t)uVar11 & 0x3f) & 1) != 0)) || (uVar11 == 0x6c)) ||
           (uVar11 == 0x7c)) {
            bVar4 = true;
        } else {
            bVar4 = false;
        }
        *ppcVar2 = *(char **)(arg1 + 0xd0);
        *ppcVar3 = *(char **)(arg1 + 0xd8);
        arg2 = var_b8h;
        if (bVar4) {
            var_f0h = arg_30h;
            var_f8h._0_4_ = 4;
            func_0x000180071bc0(arg1, var_b8h, var_b0h, 0);
            goto code_r0x000180068d5b;
        }
    } else {
        if (*(int32_t *)(arg1 + 0x30) != 0) {
            func_0x000180069750(arg1);
            pcVar21 = *ppcVar2;
            cVar5 = *pcVar21;
            goto code_r0x000180067232;
        }
code_r0x000180067246:
        *ppcVar2 = *(char **)(arg1 + 0xd0);
        *ppcVar3 = *(char **)(arg1 + 0xd8);
    }
    iVar9 = func_0x000180072ce0(arg1);
    if (iVar9 != 0) {
        func_0x000180073b70(arg1, arg2, var_b0h);
        goto code_r0x000180068d5b;
    }
    iVar9 = func_0x000180069950(arg1);
    iVar10 = func_0x000180069950(arg1);
    *ppcVar2 = *(char **)(arg1 + 0xd0);
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    if (iVar10 + iVar9 * 0x10000 == 0x38425053) {
        iVar9 = func_0x000180069950();
        iVar10 = func_0x000180069950(arg1);
        if ((iVar10 + iVar9 * 0x10000 == 0x38425053) && (iVar9 = func_0x000180069950(arg1), iVar9 == 1)) {
            if ((*(int64_t *)(arg1 + 0x10) == 0) || (iVar9 = *(int32_t *)ppcVar2, 5 < *(int32_t *)ppcVar3 - iVar9)) {
                *ppcVar2 = *ppcVar2 + 6;
            } else {
                *ppcVar2 = *ppcVar3;
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 6 - (*(int32_t *)ppcVar3 - iVar9));
            }
            uVar11 = func_0x000180069950(arg1);
            var_e8h._4_4_ = uVar11;
            if (uVar11 < 0x11) {
                uVar12 = func_0x000180069a00(arg1);
                var_cch._4_4_ = uVar12;
                iVar9 = func_0x000180069a00(arg1);
                var_cch._0_4_ = iVar9;
                if ((((int32_t)uVar12 < 0x1000001) && (iVar9 < 0x1000001)) &&
                   ((iVar10 = func_0x000180069950(arg1), (iVar10 - 8U & 0xfffffff7) == 0 &&
                    (iVar13 = func_0x000180069950(arg1), iVar13 == 3)))) {
                    uVar14 = func_0x000180069a00(arg1);
                    func_0x000180069830(arg1, uVar14);
                    uVar14 = func_0x000180069a00(arg1);
                    func_0x000180069830(arg1, uVar14);
                    func_0x000180069a00(arg1);
                    func_0x000180069830(arg1);
                    iVar13 = func_0x000180069950(arg1);
                    if ((((iVar13 < 2) && (-1 < iVar9)) &&
                        ((iVar9 == 0 || (3 < (int32_t)(0x7fffffff / (int64_t)iVar9))))) &&
                       (((-1 < iVar9 * 4 && (-1 < (int32_t)uVar12)) &&
                        ((uVar12 == 0 || (iVar9 * 4 <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12))))))) {
                        uVar12 = uVar12 * iVar9;
                        iVar16 = func_0x00018046d050((int64_t)(int32_t)(uVar12 * 4));
                        var_a8h = iVar16;
                        if (iVar16 != 0) {
                            if (iVar13 == 0) {
                                uVar27 = 0;
                                do {
                                    iVar9 = (int32_t)uVar27;
                                    if (iVar9 < (int32_t)uVar11) {
                                        iVar13 = 0;
                                        uVar11 = var_e8h._4_4_;
                                        if (*(int32_t *)var_c0h == 0x10) {
                                            puVar32 = (undefined2 *)(iVar16 + uVar27 * 2);
                                            if (0 < (int32_t)uVar12) {
                                                do {
                                                    uVar7 = func_0x000180069950(arg1);
                                                    iVar13 = iVar13 + 1;
                                                    *puVar32 = uVar7;
                                                    puVar32 = puVar32 + 4;
                                                    uVar11 = var_e8h._4_4_;
                                                } while (iVar13 < (int32_t)uVar12);
                                            }
                                        } else {
                                            puVar19 = (undefined *)(uVar27 + iVar16);
                                            if (iVar10 == 0x10) {
                                                if (0 < (int32_t)uVar12) {
                                                    do {
                                                        func_0x000180069950(arg1);
                                                        iVar13 = iVar13 + 1;
                                                        *puVar19 = extraout_AH;
                                                        puVar19 = puVar19 + 4;
                                                        uVar11 = var_e8h._4_4_;
                                                    } while (iVar13 < (int32_t)uVar12);
                                                }
                                            } else if (0 < (int32_t)uVar12) {
                                                do {
                                                    puVar29 = *(undefined **)(undefined8 *)(arg1 + 0xc0);
                                                    if (puVar29 < *(undefined **)(arg1 + 200)) {
                                                        uVar23 = *puVar29;
                                                        *(undefined8 *)(arg1 + 0xc0) = puVar29 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar23 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        puVar29 = *(undefined **)(undefined8 *)(arg1 + 0xc0);
                                                        uVar23 = *puVar29;
                                                        *(undefined8 *)(arg1 + 0xc0) = puVar29 + 1;
                                                    }
                                                    *puVar19 = uVar23;
                                                    iVar13 = iVar13 + 1;
                                                    puVar19 = puVar19 + 4;
                                                    iVar16 = var_a8h;
                                                    uVar11 = var_e8h._4_4_;
                                                } while (iVar13 < (int32_t)uVar12);
                                            }
                                        }
                                    } else {
                                        uVar23 = 0;
                                        puVar19 = (undefined *)(uVar27 + iVar16);
                                        if (iVar9 == 3) {
                                            uVar23 = 0xff;
                                        }
                                        iVar13 = 0;
                                        if (0 < (int32_t)uVar12) {
                                            do {
                                                iVar13 = iVar13 + 1;
                                                *puVar19 = uVar23;
                                                puVar19 = puVar19 + 4;
                                            } while (iVar13 < (int32_t)uVar12);
                                        }
                                    }
                                    uVar27 = (uint64_t)(iVar9 + 1U);
                                } while ((int32_t)(iVar9 + 1U) < 4);
                            } else {
                                func_0x000180069830();
                                var_d8h = 0;
                                do {
                                    puVar31 = (uint8_t *)((int32_t)var_d8h + iVar16);
                                    if ((int32_t)var_d8h < (int32_t)uVar11) {
                                        iVar9 = 0;
                                        uVar36 = uVar12;
                                        while (0 < (int32_t)uVar36) {
                                            puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar17 < *(uint8_t **)(arg1 + 200)) {
code_r0x000180067598:
                                                uVar30 = *puVar17;
                                                puVar18 = puVar17 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar18;
                                                if (uVar30 != 0x80) {
                                                    uVar11 = (uint32_t)uVar30;
                                                    if (uVar30 < 0x80) goto code_r0x00018006761f;
                                                    if (0x80 < uVar30) {
                                                        iVar10 = 0x101 - (uint32_t)uVar30;
                                                        if ((int32_t)uVar36 < iVar10) goto code_r0x0001800676a8;
                                                        if (puVar18 < *(uint8_t **)(arg1 + 200)) {
                                                            uVar30 = *puVar18;
                                                            *(uint8_t **)(arg1 + 0xc0) = puVar17 + 2;
                                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                            uVar30 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                            uVar30 = *puVar17;
                                                            *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                        }
                                                        iVar9 = iVar9 + iVar10;
                                                        for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                                                            *puVar31 = uVar30;
                                                            puVar31 = puVar31 + 4;
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) {
                                                    func_0x000180069750();
                                                    puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x000180067598;
                                                }
                                                uVar11 = 0;
code_r0x00018006761f:
                                                uVar11 = uVar11 + 1;
                                                if (uVar36 < uVar11) {
code_r0x0001800676a8:
                                                    func_0x000180460d90(iVar16);
                                                    goto code_r0x000180068d5b;
                                                }
                                                iVar9 = iVar9 + uVar11;
                                                do {
                                                    puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                    if (puVar17 < *(uint8_t **)(arg1 + 200)) {
                                                        uVar30 = *puVar17;
                                                        *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar30 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                        uVar30 = *puVar17;
                                                        *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                    }
                                                    *puVar31 = uVar30;
                                                    puVar31 = puVar31 + 4;
                                                    uVar11 = uVar11 - 1;
                                                } while (uVar11 != 0);
                                            }
                                            uVar11 = var_e8h._4_4_;
                                            uVar36 = uVar12 - iVar9;
                                        }
                                    } else {
                                        iVar9 = 0;
                                        if (0 < (int32_t)uVar12) {
                                            uVar30 = 0;
                                            if (var_d8h == 3) {
                                                uVar30 = 0xff;
                                            }
                                            do {
                                                iVar9 = iVar9 + 1;
                                                *puVar31 = uVar30;
                                                puVar31 = puVar31 + 4;
                                            } while (iVar9 < (int32_t)uVar12);
                                        }
                                    }
                                    var_d8h = var_d8h + 1;
                                } while ((int32_t)var_d8h < 4);
                            }
                            if (3 < (int32_t)uVar11) {
                                iVar9 = 0;
                                if (*(int32_t *)var_c0h == 0x10) {
                                    if (3 < (int32_t)uVar12) {
                                        do {
                                            iVar28 = (int64_t)(iVar9 * 4);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            uVar8 = *(uint16_t *)(iVar16 + 0xe + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + 8 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 8 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 10 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 10 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 0xc + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 0xc + iVar28 * 2)
                                                                        * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 8);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 0xc);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            iVar9 = iVar9 + 4;
                                        } while (iVar9 < (int32_t)(uVar12 - 3));
                                    }
                                    for (; iVar9 < (int32_t)uVar12; iVar9 = iVar9 + 1) {
                                        iVar28 = (int64_t)(iVar9 * 4);
                                        uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                        if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                            fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                            fVar37 = (1.0 - fVar38) * 65535.0;
                                            *(int16_t *)(iVar16 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)*(uint16_t *)(iVar16 + iVar28 * 2)
                                                                    * fVar38 + fVar37);
                                            *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)
                                                                           *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                    fVar38 + fVar37);
                                            *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)
                                                                           *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                    fVar38 + fVar37);
                                        }
                                    }
                                } else {
                                    if (3 < (int32_t)uVar12) {
                                        do {
                                            iVar28 = (int64_t)(iVar9 * 4);
                                            uVar30 = *(uint8_t *)(iVar16 + 3 + iVar28);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar16 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + iVar28) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar16 + 1 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 1 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 2 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 2 + iVar28)
                                                                     * fVar38 + fVar37);
                                            }
                                            uVar30 = *(uint8_t *)(iVar16 + 7 + iVar28);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar16 + 4 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 4 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 5 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 5 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 6 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 6 + iVar28)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 8);
                                            uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar28 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar28 + 1 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar28 + 2 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 0xc);
                                            uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar28 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar28 + 1 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar28 + 2 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar9 = iVar9 + 4;
                                        } while (iVar9 < (int32_t)(uVar12 - 3));
                                    }
                                    for (; iVar9 < (int32_t)uVar12; iVar9 = iVar9 + 1) {
                                        iVar28 = (int64_t)(iVar9 * 4);
                                        uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                        if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                            fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                            fVar37 = (1.0 - fVar38) * 255.0;
                                            *(char *)(iVar28 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) * fVar38
                                                                + fVar37);
                                            *(char *)(iVar28 + 1 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16) *
                                                                 fVar38 + fVar37);
                                            *(char *)(iVar28 + 2 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16) *
                                                                 fVar38 + fVar37);
                                        }
                                    }
                                }
                            }
                            *(uint32_t *)var_b0h = var_cch._4_4_;
                            *(int32_t *)var_b8h = (int32_t)var_cch;
                        }
                    }
                }
            }
        }
        goto code_r0x000180068d5b;
    }
    iVar9 = func_0x000180072b70(arg1, 0x18063cc84);
    if (iVar9 != 0) {
        iVar9 = 0x54;
        do {
            if (*ppcVar2 < *ppcVar3) {
                *ppcVar2 = *ppcVar2 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) != 0) {
                func_0x000180069750(arg1);
                *ppcVar2 = *ppcVar2 + 1;
            }
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
        iVar9 = func_0x000180072b70(arg1, 0x18063cc7c);
        if (iVar9 != 0) {
            pcVar21 = *(char **)(arg1 + 0xd0);
            ppcVar2 = (char **)(arg1 + 0xc0);
            iVar9 = 0x5c;
            *ppcVar2 = pcVar21;
            *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
            do {
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*(int32_t *)(arg1 + 0x30) != 0) {
                    func_0x000180069750(arg1);
                    *ppcVar2 = *ppcVar2 + 1;
                    pcVar21 = *ppcVar2;
                }
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
            uVar11 = func_0x000180069950(arg1);
            var_e8h._4_4_ = uVar11;
            uVar12 = func_0x000180069950(arg1);
            var_d8h = uVar12;
            if ((0x1000000 < (int32_t)uVar12) || (0x1000000 < (int32_t)uVar11)) goto code_r0x000180068d5b;
            if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180068e24:
                if (*(char **)(arg1 + 200) <= *ppcVar2) goto code_r0x000180068d5b;
            } else {
                iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                if (iVar9 != 0) {
                    if (*(int32_t *)(arg1 + 0x30) == 0) goto code_r0x000180068d5b;
                    goto code_r0x000180068e24;
                }
            }
            if (((((int32_t)uVar11 < 0) || ((int32_t)uVar12 < 0)) ||
                ((uVar12 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12) < (int32_t)uVar11)))) ||
               (0x1fffffff < uVar11 * uVar12)) goto code_r0x000180068d5b;
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            if ((uVar12 != 0) && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12) < (int32_t)uVar11))
            goto code_r0x000180068d5b;
            iVar16 = (int64_t)(int32_t)(uVar11 * uVar12 * 4);
            var_c0h = func_0x00018046d050(iVar16);
            if (var_c0h == 0) goto code_r0x000180068d5b;
            func_0x0001804986e0(var_c0h, 0xff, iVar16);
            var_e0h._4_4_ = 0;
            do {
                if (var_e0h._4_4_ == 10) goto code_r0x0001800693c0;
                iVar16 = (int64_t)var_e0h._4_4_;
                pcVar21 = *ppcVar2;
                piVar1 = (int32_t *)(arg1 + 0x30);
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar5 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar5 = '\0';
                } else {
                    func_0x000180069750();
                    cVar5 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar24 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar24 = '\0';
                } else {
                    func_0x000180069750();
                    cVar24 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                *(char *)((int64_t)&var_98h + iVar16 * 3) = cVar24;
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar25 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar25 = '\0';
                } else {
                    func_0x000180069750(arg1);
                    cVar25 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                *(char *)((int64_t)&var_98h + iVar16 * 3 + 1) = cVar25;
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar25 = *pcVar21;
                    *ppcVar2 = pcVar21 + 1;
                } else if (*piVar1 == 0) {
                    cVar25 = '\0';
                } else {
                    func_0x000180069750(arg1);
                    cVar25 = **ppcVar2;
                    *ppcVar2 = *ppcVar2 + 1;
                }
                iVar28 = *(int64_t *)(arg1 + 0x10);
                *(char *)((int64_t)&var_98h + iVar16 * 3 + 2) = cVar25;
                if (iVar28 == 0) {
code_r0x000180068fed:
                    if (*(char **)(arg1 + 200) <= *ppcVar2) goto code_r0x0001800693c0;
                } else {
                    iVar9 = (**(code **)(arg1 + 0x20))();
                    if (iVar9 != 0) {
                        if (*piVar1 != 0) goto code_r0x000180068fed;
                        goto code_r0x0001800693c0;
                    }
                }
                if (cVar24 != '\b') goto code_r0x0001800693c0;
                iVar9 = var_e0h._4_4_ + 1;
                var_e0h._4_4_ = iVar9;
            } while (cVar5 != '\0');
            var_cch._0_4_ = 0;
            var_f8h._0_4_ = var_d8h;
            if (0 < (int32_t)var_d8h) {
                do {
                    uVar27 = 0;
                    var_cch._4_4_ = 0;
                    if (0 < iVar9) {
                        puVar19 = (undefined *)((int32_t)((int32_t)var_cch * var_e8h._4_4_ * 4) + var_c0h);
                        var_a0h = (int64_t)puVar19;
                        uVar11 = var_e8h._4_4_;
                        do {
                            iVar16 = uVar27 * 3;
                            cVar5 = *(char *)((int64_t)&var_98h + iVar16 + 1);
                            var_a8h = iVar16;
                            if (cVar5 == '\0') {
                                if (0 < (int32_t)uVar11) {
                                    uVar23 = *(undefined *)((int64_t)&var_98h + iVar16 + 2);
                                    iVar9 = 0;
                                    puVar29 = puVar19;
                                    do {
                                        iVar16 = func_0x000180072c10(arg1, uVar23, puVar29);
                                        if (iVar16 == 0) goto code_r0x0001800693c0;
                                        iVar9 = iVar9 + 1;
                                        puVar29 = puVar29 + 4;
                                        puVar19 = (undefined *)var_a0h;
                                    } while (iVar9 < (int32_t)uVar11);
                                }
                            } else {
                                puVar29 = puVar19;
                                uVar12 = uVar11;
                                if (cVar5 == '\x01') {
                                    while (0 < (int32_t)uVar12) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar11 = (uint32_t)*puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar11 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar11 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180069294:
                                            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0))
                                            goto code_r0x0001800693c0;
                                        } else {
                                            iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                                            if (iVar9 != 0) {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x000180069294;
                                                goto code_r0x0001800693c0;
                                            }
                                        }
                                        if (uVar12 < uVar11) {
                                            uVar11 = uVar12 & 0xff;
                                        }
                                        uVar30 = *(uint8_t *)((int64_t)&var_98h + iVar16 + 2);
                                        iVar28 = func_0x000180072c10(arg1, uVar30, &var_d4h);
                                        if (iVar28 == 0) goto code_r0x0001800693c0;
                                        iVar9 = 0;
                                        if ((char)uVar11 != '\0') {
                                            do {
                                                if ((uVar30 & 0x80) != 0) {
                                                    *puVar29 = (char)var_d4h;
                                                }
                                                if ((uVar30 & 0x40) != 0) {
                                                    puVar29[1] = var_d4h._1_1_;
                                                }
                                                if ((uVar30 & 0x20) != 0) {
                                                    puVar29[2] = var_d4h._2_1_;
                                                }
                                                if ((uVar30 & 0x10) != 0) {
                                                    puVar29[3] = var_d4h._3_1_;
                                                }
                                                iVar9 = iVar9 + 1;
                                                puVar29 = puVar29 + 4;
                                                iVar16 = var_a8h;
                                            } while (iVar9 < (int32_t)uVar11);
                                        }
                                        puVar19 = (undefined *)var_a0h;
                                        uVar12 = uVar12 - uVar11;
                                        uVar11 = var_e8h._4_4_;
                                    }
                                } else {
                                    if (cVar5 != '\x02') goto code_r0x0001800693c0;
                                    while (0 < (int32_t)uVar12) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar30 = *puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar30 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar30 = **(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800690ff:
                                            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0))
                                            goto code_r0x0001800693c0;
                                        } else {
                                            iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                                            if (iVar9 != 0) {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x0001800690ff;
                                                goto code_r0x0001800693c0;
                                            }
                                        }
                                        uVar11 = (uint32_t)uVar30;
                                        if (uVar11 < 0x80) {
                                            uVar11 = uVar11 + 1;
                                            if (uVar12 < uVar11) goto code_r0x0001800693c0;
                                            if (uVar11 != 0) {
                                                uVar23 = *(undefined *)((int64_t)&var_98h + iVar16 + 2);
                                                iVar9 = 0;
                                                do {
                                                    iVar16 = func_0x000180072c10(arg1, uVar23, puVar29);
                                                    if (iVar16 == 0) goto code_r0x0001800693c0;
                                                    iVar9 = iVar9 + 1;
                                                    puVar29 = puVar29 + 4;
                                                    iVar16 = var_a8h;
                                                } while (iVar9 < (int32_t)uVar11);
                                            }
                                        } else {
                                            if (uVar11 == 0x80) {
                                                uVar11 = func_0x000180069950(arg1);
                                            } else {
                                                uVar11 = uVar30 - 0x7f;
                                            }
                                            if ((int32_t)uVar12 < (int32_t)uVar11) goto code_r0x0001800693c0;
                                            uVar30 = *(uint8_t *)((int64_t)&var_98h + iVar16 + 2);
                                            iVar28 = func_0x000180072c10(arg1, uVar30, &var_d0h);
                                            if (iVar28 == 0) goto code_r0x0001800693c0;
                                            iVar9 = 0;
                                            if (0 < (int32_t)uVar11) {
                                                do {
                                                    if ((uVar30 & 0x80) != 0) {
                                                        *puVar29 = (char)var_d0h;
                                                    }
                                                    if ((uVar30 & 0x40) != 0) {
                                                        puVar29[1] = var_d0h._1_1_;
                                                    }
                                                    if ((uVar30 & 0x20) != 0) {
                                                        puVar29[2] = var_d0h._2_1_;
                                                    }
                                                    if ((uVar30 & 0x10) != 0) {
                                                        puVar29[3] = var_d0h._3_1_;
                                                    }
                                                    iVar9 = iVar9 + 1;
                                                    puVar29 = puVar29 + 4;
                                                    iVar16 = var_a8h;
                                                } while (iVar9 < (int32_t)uVar11);
                                            }
                                        }
                                        puVar19 = (undefined *)var_a0h;
                                        uVar12 = uVar12 - uVar11;
                                        uVar11 = var_e8h._4_4_;
                                    }
                                }
                            }
                            var_cch._4_4_ = var_cch._4_4_ + 1;
                            uVar27 = (uint64_t)var_cch._4_4_;
                            iVar9 = var_e0h._4_4_;
                            var_f8h._0_4_ = var_d8h;
                        } while ((int32_t)var_cch._4_4_ < var_e0h._4_4_);
                    }
                    var_cch._0_4_ = (int32_t)var_cch + 1;
                } while ((int32_t)var_cch < (int32_t)(uint32_t)var_f8h);
            }
            goto code_r0x0001800693d5;
        }
    }
    *ppcVar2 = *(char **)(arg1 + 0xd0);
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    piVar20 = (int64_t *)func_0x00018046d050();
    if (piVar20 != (int64_t *)0x0) {
        *piVar20 = arg1;
        func_0x00018006e660(piVar20);
        iVar9 = func_0x00018006d480(piVar20, 1);
        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
        *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
        func_0x000180460d90();
        if (iVar9 != 0) {
            piVar20 = (int64_t *)func_0x00018046d050(0x4888);
            if (piVar20 != (int64_t *)0x0) {
                *piVar20 = arg1;
                func_0x00018006e660(piVar20);
                var_f8h._0_4_ = 4;
                func_0x00018006e6e0(piVar20, var_b8h, var_b0h, 0);
                func_0x000180460d90(piVar20);
            }
            goto code_r0x000180068d5b;
        }
    }
    pcVar21 = *(char **)(arg1 + 0xc0);
    if (pcVar21 < *(char **)(arg1 + 200)) {
        cVar5 = *pcVar21;
        pcVar21 = pcVar21 + 1;
        *(char **)(arg1 + 0xc0) = pcVar21;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar5 = '\0';
    } else {
        func_0x000180069750();
        cVar5 = **(char **)(arg1 + 0xc0);
        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
        *(char **)(arg1 + 0xc0) = pcVar21;
    }
    if (pcVar21 < *(char **)(arg1 + 200)) {
        cVar24 = *pcVar21;
        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar24 = '\0';
    } else {
        func_0x000180069750(arg1);
        cVar24 = **(char **)(arg1 + 0xc0);
        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
    }
    if ((cVar5 == 'P') && (cVar24 == '5' || cVar24 == '6')) {
        iVar9 = func_0x000180074950(arg1, arg1, arg1 + 4, arg1 + 8);
        *(int32_t *)arg_30h = iVar9;
        if ((iVar9 != 0) && ((*(uint32_t *)(arg1 + 4) < 0x1000001 && (*(uint32_t *)arg1 < 0x1000001)))) {
            *(uint32_t *)var_b8h = *(uint32_t *)arg1;
            *(undefined4 *)var_b0h = *(undefined4 *)(arg1 + 4);
            iVar9 = *(int32_t *)(arg1 + 8);
            if (-1 < iVar9) {
                iVar10 = *(int32_t *)arg1;
                if ((-1 < iVar10) &&
                   (((iVar10 == 0 || (iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))) && (-1 < iVar9 * iVar10)))) {
                    iVar13 = *(int32_t *)(arg1 + 4);
                    if ((-1 < iVar13) &&
                       (((iVar13 == 0 || (iVar9 * iVar10 <= (int32_t)(0x7fffffff / (int64_t)iVar13))) &&
                        (iVar26 = iVar9 * iVar10 * iVar13, -1 < iVar26)))) {
                        uVar11 = *(int32_t *)arg_30h >> 0x1f & 7;
                        uVar27 = (uint64_t)uVar11;
                        iVar15 = (int32_t)(*(int32_t *)arg_30h + uVar11) >> 3;
                        if ((((-1 < iVar15) &&
                             ((iVar15 == 0 ||
                              (uVar27 = 0x7fffffff % (int64_t)iVar15 & 0xffffffff,
                              iVar26 <= (int32_t)(0x7fffffff / (int64_t)iVar15))))) &&
                            ((iVar10 == 0 ||
                             (uVar27 = 0x7fffffff % (int64_t)iVar10 & 0xffffffff,
                             iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))))) &&
                           ((iVar13 == 0 ||
                            (uVar27 = 0x7fffffff % (int64_t)iVar13 & 0xffffffff,
                            iVar9 * iVar10 <= (int32_t)(0x7fffffff / (int64_t)iVar13))))) {
                            iVar26 = iVar9 * iVar13 * iVar10;
                            if ((-1 < iVar26) &&
                               (((iVar15 == 0 ||
                                 (uVar27 = 0x7fffffff % (int64_t)iVar15 & 0xffffffff,
                                 iVar26 <= (int32_t)(0x7fffffff / (int64_t)iVar15))) &&
                                (iVar16 = func_0x00018046d050((int64_t)(iVar9 * iVar13 * iVar15 * iVar10), uVar27),
                                iVar16 != 0)))) {
                                func_0x000180069890(arg1, iVar16, 
                                                    *(int32_t *)(arg1 + 8) * *(int32_t *)(arg1 + 4) *
                                                    ((int32_t)(*(int32_t *)arg_30h + (*(int32_t *)arg_30h >> 0x1f & 7U))
                                                    >> 3) * *(int32_t *)arg1);
                                if (*(int32_t *)(arg1 + 8) != 4) {
                                    var_f8h._0_4_ = *(uint32_t *)(arg1 + 4);
                                    func_0x000180069b10(iVar16, *(int32_t *)(arg1 + 8), 4, *(undefined4 *)arg1);
                                }
                            }
                        }
                    }
                }
            }
        }
        goto code_r0x000180068d5b;
    }
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    iVar9 = func_0x000180073cf0(arg1);
    iVar28 = var_b0h;
    iVar16 = var_b8h;
    if (iVar9 != 0) {
        iVar22 = func_0x000180073fe0(arg1, var_b8h);
        if (iVar22 != 0) {
            iVar9 = *(int32_t *)iVar16;
            if (-1 < iVar9) {
                iVar10 = *(int32_t *)iVar28;
                if ((((-1 < iVar10) && ((iVar10 == 0 || (iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))))) &&
                    (uVar11 = iVar9 * iVar10, uVar11 < 0x20000000)) &&
                   (iVar16 = func_0x00018046d050((int64_t)(int32_t)(uVar11 * 4)), iVar16 != 0)) {
                    var_d8h = 0;
                    var_c0h = iVar16;
                    if (0 < (int32_t)uVar11) {
                        do {
                            iVar10 = 0;
                            iVar9 = var_d8h * 4;
                            do {
                                iVar28 = (int64_t)iVar9;
                                fVar37 = (float)func_0x000180492580(*(undefined4 *)(iVar22 + iVar28 * 4));
                                iVar10 = iVar10 + 1;
                                iVar9 = iVar9 + 1;
                                fVar38 = fVar37 * 255.0 + 0.5;
                                fVar37 = 0.0;
                                if (0.0 <= fVar38) {
                                    fVar37 = fVar38;
                                }
                                fVar38 = 255.0;
                                if (fVar37 <= 255.0) {
                                    fVar38 = fVar37;
                                }
                                *(char *)(iVar28 + var_c0h) = (char)(int32_t)fVar38;
                            } while (iVar10 < 3);
                            iVar9 = var_d8h * 4;
                            var_d8h = var_d8h + 1;
                            iVar28 = (int64_t)(iVar9 + iVar10);
                            fVar38 = *(float *)(iVar22 + iVar28 * 4) * 255.0 + 0.5;
                            fVar37 = 0.0;
                            if (0.0 <= fVar38) {
                                fVar37 = fVar38;
                            }
                            fVar38 = 255.0;
                            if (fVar37 <= 255.0) {
                                fVar38 = fVar37;
                            }
                            *(char *)(iVar28 + iVar16) = (char)(int32_t)fVar38;
                        } while ((int32_t)var_d8h < (int32_t)uVar11);
                    }
                    func_0x000180460d90(iVar22);
                    goto code_r0x000180068d5b;
                }
            }
            func_0x000180460d90(iVar22);
        }
        goto code_r0x000180068d5b;
    }
    puVar31 = *(uint8_t **)(arg1 + 0xc0);
    if (puVar31 < *(uint8_t **)(arg1 + 200)) {
code_r0x000180068377:
        puVar31 = puVar31 + 1;
        *(uint8_t **)(arg1 + 0xc0) = puVar31;
    } else if (*(int32_t *)(arg1 + 0x30) != 0) {
        func_0x000180069750(arg1);
        puVar31 = *(uint8_t **)(arg1 + 0xc0);
        goto code_r0x000180068377;
    }
    if (puVar31 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800683ad:
        uVar30 = *puVar31;
        *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
        if (uVar30 < 2) {
            cVar5 = func_0x0001800697d0(arg1);
            if (uVar30 != 1) goto code_r0x000180068480;
            if ((cVar5 - 1U & 0xf7) == 0) {
                if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                   (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 3 < iVar9)) {
                    *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 4;
                } else {
                    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                    (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 4 - iVar9);
                }
                uVar6 = func_0x0001800697d0(arg1);
                if ((uVar6 < 0x21) && ((0x101018100U >> ((uint64_t)uVar6 & 0x3f) & 1) != 0)) {
                    if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                       (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 3 < iVar9)) {
                        *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 4;
                    } else {
                        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                        (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 4 - iVar9);
                    }
                    goto code_r0x0001800684c8;
                }
            }
        }
    } else {
        if (*(int32_t *)(arg1 + 0x30) != 0) {
            func_0x000180069750();
            puVar31 = *(uint8_t **)(arg1 + 0xc0);
            goto code_r0x0001800683ad;
        }
        uVar30 = 0;
        cVar5 = func_0x0001800697d0(arg1);
code_r0x000180068480:
        if ((cVar5 - 2U & 0xf6) == 0) {
            if ((*(int64_t *)(arg1 + 0x10) == 0) ||
               (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 8 < iVar9)) {
                *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 9;
            } else {
                *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 9 - iVar9);
            }
code_r0x0001800684c8:
            iVar9 = func_0x000180069a30(arg1);
            if ((0 < iVar9) && (iVar9 = func_0x000180069a30(arg1), 0 < iVar9)) {
                uVar6 = func_0x0001800697d0(arg1);
                if (uVar30 == 1) {
                    if (uVar6 != 8) {
                        if (uVar6 != 0x10) goto code_r0x000180068d3d;
                        goto code_r0x000180068503;
                    }
                } else {
code_r0x000180068503:
                    if ((0x20 < uVar6) || ((0x101018100U >> ((uint64_t)uVar6 & 0x3f) & 1) == 0))
                    goto code_r0x000180068d3d;
                }
                puVar31 = *(uint8_t **)(arg1 + 0xd0);
                *(uint8_t **)(arg1 + 0xc0) = puVar31;
                *(uint8_t **)(arg1 + 200) = *(uint8_t **)(arg1 + 0xd8);
                if (puVar31 < *(uint8_t **)(arg1 + 0xd8)) {
                    var_e0h._0_1_ = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    var_e0h._0_1_ = 0;
                } else {
                    func_0x000180069750(arg1);
                    var_e0h._0_1_ = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    var_e8h._0_1_ = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    var_e8h._0_1_ = 0;
                } else {
                    func_0x000180069750(arg1);
                    var_e8h._0_1_ = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar30 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar30 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar30 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                var_cch._0_4_ = func_0x000180069a30(arg1);
                var_d0h = func_0x000180069a30(arg1);
                puVar31 = *(uint8_t **)(arg1 + 0xc0);
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar6 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar6 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar6 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                func_0x000180069a30(arg1);
                func_0x000180069a30(arg1);
                var_e0h._4_4_ = func_0x000180069a30(arg1);
                uVar11 = func_0x000180069a30(arg1);
                puVar31 = *(uint8_t **)(arg1 + 0xc0);
                var_cch._4_4_ = uVar11;
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar34 = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar34 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar34 = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar35 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar35 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar35 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                iVar9 = var_e0h._4_4_;
                uVar12 = 0;
                var_d4h = 0;
                if ((0x1000000 < (int32_t)uVar11) || (0x1000000 < var_e0h._4_4_)) goto code_r0x000180068d5b;
                var_d8h = (uint32_t)uVar30;
                uVar33 = (uint32_t)uVar34;
                var_a8h = CONCAT44(var_a8h._4_4_, uVar33);
                uVar36 = uVar30 - 8;
                var_e8h._4_4_ = 0;
                if (var_d8h < 8) {
                    uVar36 = (uint32_t)uVar30;
                }
                if ((uint8_t)var_e8h == 0) {
                    if (uVar33 == 8) goto code_r0x0001800687c1;
                    if (uVar33 == 0xf) {
code_r0x0001800687b5:
                        uVar12 = 3;
                        var_e8h._4_4_ = 1;
                    } else if (uVar33 == 0x10) {
                        if (uVar36 != 3) goto code_r0x0001800687b5;
                        uVar12 = 2;
                    } else {
                        if ((uVar33 == 0x18) || (uVar33 == 0x20)) {
                            uVar36 = (uint32_t)uVar34;
                            goto code_r0x0001800687a4;
                        }
                        uVar12 = 0;
                    }
                } else {
                    uVar36 = (uint32_t)uVar6;
                    if (uVar36 != 8) {
                        if ((uVar36 != 0xf) && (uVar36 != 0x10)) {
                            if ((uVar36 == 0x18) || (uVar36 == 0x20)) {
code_r0x0001800687a4:
                                uVar12 = uVar36 >> 3;
                            }
                            goto code_r0x0001800687c4;
                        }
                        goto code_r0x0001800687b5;
                    }
code_r0x0001800687c1:
                    uVar12 = 1;
                }
code_r0x0001800687c4:
                if (uVar12 == 0) goto code_r0x000180068d5b;
                *(int32_t *)var_b8h = var_e0h._4_4_;
                *(uint32_t *)var_b0h = uVar11;
                if (((((var_e0h._4_4_ < 0) || ((int32_t)uVar11 < 0)) ||
                     ((uVar11 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar11) < var_e0h._4_4_)))) ||
                    ((((int32_t)(var_e0h._4_4_ * uVar11) < 0 ||
                      (uVar27 = 0x7fffffff % (uint64_t)uVar12,
                      (int32_t)(0x7fffffff / (uint64_t)uVar12) < (int32_t)(var_e0h._4_4_ * uVar11))) ||
                     ((uVar11 != 0 &&
                      (uVar27 = 0x7fffffff % (int64_t)(int32_t)uVar11 & 0xffffffff,
                      (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar11) < var_e0h._4_4_)))))) ||
                   (puVar19 = (undefined *)
                              func_0x00018046d050((int64_t)(int32_t)(uVar12 * var_e0h._4_4_ * uVar11), uVar27),
                   puVar19 == (undefined *)0x0)) goto code_r0x000180068d5b;
                iVar13 = 1 - (uVar35 >> 5 & 1);
                var_b8h = CONCAT44(var_b8h._4_4_, iVar13);
                func_0x000180069830();
                iVar10 = var_d0h;
                if ((uint8_t)var_e8h == 0) {
                    if ((var_d8h < 8) && (var_e8h._4_4_ == 0)) {
                        if (0 < (int32_t)uVar11) {
                            iVar10 = 0;
                            if (iVar13 == 0) {
                                iVar13 = uVar12 * var_e0h._4_4_;
                                do {
                                    func_0x000180069890(arg1, puVar19 + iVar13 * iVar10);
                                    iVar10 = iVar10 + 1;
                                    iVar9 = var_e0h._4_4_;
                                } while (iVar10 < (int32_t)uVar11);
                            } else {
                                iVar13 = uVar12 * var_e0h._4_4_;
                                do {
                                    func_0x000180069890(arg1, puVar19 + (int32_t)(((uVar11 - iVar10) + -1) * iVar13));
                                    iVar10 = iVar10 + 1;
                                    iVar9 = var_e0h._4_4_;
                                } while (iVar10 < (int32_t)uVar11);
                            }
                        }
                    } else {
                        var_c0h = 0;
                        iVar16 = 0;
code_r0x0001800689e1:
                        bVar4 = true;
                        var_cch._0_4_ = 0;
                        iVar9 = var_e0h._4_4_ * uVar11;
                        iVar10 = 0;
                        var_b0h = CONCAT44(var_b0h._4_4_, iVar9);
                        if (0 < iVar9) {
                            uVar36 = 0;
                            do {
                                if (var_d8h < 8) {
code_r0x000180068a7a:
                                    if ((uint8_t)var_e8h == 0) {
                                        if (var_e8h._4_4_ == 0) {
                                            uVar27 = 0;
                                            if (uVar12 != 0) {
                                                do {
                                                    puVar29 = *(undefined **)(arg1 + 0xc0);
                                                    if (puVar29 < *(undefined **)(arg1 + 200)) {
                                                        uVar23 = *puVar29;
                                                        *(undefined **)(arg1 + 0xc0) = puVar29 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar23 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        uVar23 = **(undefined **)(arg1 + 0xc0);
                                                        *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
                                                    }
                                                    *(undefined *)((int64_t)&var_d4h + uVar27) = uVar23;
                                                    uVar11 = (int32_t)uVar27 + 1;
                                                    uVar27 = (uint64_t)uVar11;
                                                } while ((int32_t)uVar11 < (int32_t)uVar12);
                                            }
                                        } else {
                                            uVar8 = func_0x000180069a30(arg1);
                                            uVar14 = var_d4h;
                                            var_d4h._3_1_ = SUB41(uVar14, 3);
                                        }
                                    } else {
                                        if ((int32_t)var_a8h == 8) {
                                            puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                                uVar30 = *puVar31;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                                uVar11 = (uint32_t)uVar30;
                                            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                uVar11 = 0;
                                            } else {
                                                func_0x000180069750(arg1);
                                                uVar30 = **(uint8_t **)(arg1 + 0xc0);
                                                *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                uVar11 = (uint32_t)uVar30;
                                            }
                                        } else {
                                            uVar11 = func_0x000180069a30();
                                        }
                                        uVar33 = 0;
                                        if ((int32_t)uVar11 < var_d0h) {
                                            uVar33 = uVar11;
                                        }
                                        uVar27 = 0;
                                        if (uVar12 != 0) {
                                            do {
                                                *(undefined *)((int64_t)&var_d4h + uVar27) =
                                                     *(undefined *)
                                                      ((int32_t)((int32_t)uVar27 + uVar33 * uVar12) + iVar16);
                                                uVar11 = (int32_t)uVar27 + 1;
                                                uVar27 = (uint64_t)uVar11;
                                            } while ((int32_t)uVar11 < (int32_t)uVar12);
                                        }
                                    }
                                    bVar4 = false;
                                    iVar9 = (int32_t)var_b0h;
                                } else {
                                    if (iVar10 == 0) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar36 = (uint32_t)*puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar36 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar36 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        iVar10 = (uVar36 & 0x7f) + 1;
                                        uVar36 = uVar36 >> 7;
                                        goto code_r0x000180068a7a;
                                    }
                                    if ((uVar36 == 0) || (bVar4)) goto code_r0x000180068a7a;
                                }
                                if (uVar12 != 0) {
                                    uVar27 = 0;
                                    do {
                                        iVar13 = (int32_t)uVar27;
                                        puVar29 = (undefined *)((int64_t)&var_d4h + uVar27);
                                        uVar11 = iVar13 + 1;
                                        uVar27 = (uint64_t)uVar11;
                                        puVar19[(int32_t)(uVar12 * (int32_t)var_cch + iVar13)] = *puVar29;
                                    } while ((int32_t)uVar11 < (int32_t)uVar12);
                                }
                                var_cch._0_4_ = (int32_t)var_cch + 1;
                                iVar10 = iVar10 + -1;
                                iVar16 = var_c0h;
                                uVar11 = var_cch._4_4_;
                            } while ((int32_t)var_cch < iVar9);
                        }
                        if (((int32_t)var_b8h != 0) && (iVar9 = 0, 0 < (int32_t)uVar11)) {
                            iVar10 = uVar12 * var_e0h._4_4_;
                            do {
                                iVar26 = iVar10 * iVar9;
                                iVar15 = ((uVar11 - iVar9) + -1) * iVar10;
                                for (iVar13 = iVar10; 0 < iVar13; iVar13 = iVar13 + -1) {
                                    uVar23 = puVar19[iVar26];
                                    puVar19[iVar26] = puVar19[iVar15];
                                    puVar19[iVar15] = uVar23;
                                    iVar26 = iVar26 + 1;
                                    iVar15 = iVar15 + 1;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 * 2 < (int32_t)uVar11);
                        }
                        iVar9 = var_e0h._4_4_;
                        if (var_c0h != 0) {
                            func_0x000180460d90(var_c0h);
                            iVar9 = var_e0h._4_4_;
                        }
                    }
                    if ((2 < uVar12) && (var_e8h._4_4_ == 0)) {
                        iVar10 = 0;
                        if (0 < (int32_t)(iVar9 * uVar11)) {
                            puVar29 = puVar19;
                            do {
                                uVar23 = *puVar29;
                                iVar10 = iVar10 + 1;
                                *puVar29 = puVar29[2];
                                puVar29[2] = uVar23;
                                puVar29 = puVar29 + uVar12;
                            } while (iVar10 < (int32_t)(iVar9 * uVar11));
                        }
                    }
                    if (uVar12 != 4) {
                        var_f8h._0_4_ = uVar11;
                        func_0x000180069b10(puVar19, uVar12, 4, iVar9);
                    }
                } else {
                    if (((var_d0h != 0) && (func_0x000180069830(arg1), -1 < iVar10)) &&
                       (iVar10 <= (int32_t)(0x7fffffff / (uint64_t)uVar12))) {
                        iVar16 = func_0x00018046d050();
                        iVar9 = var_d0h;
                        var_c0h = iVar16;
                        if (iVar16 != 0) {
                            if (var_e8h._4_4_ == 0) {
                                iVar9 = func_0x000180069890();
                                if (iVar9 == 0) {
                                    func_0x000180460d90(puVar19);
                                    func_0x000180460d90(iVar16);
                                    goto code_r0x000180068d5b;
                                }
                            } else {
                                iVar10 = 0;
                                if (0 < var_d0h) {
                                    do {
                                        func_0x000180072ae0();
                                        iVar10 = iVar10 + 1;
                                        iVar16 = var_c0h;
                                        uVar11 = var_cch._4_4_;
                                    } while (iVar10 < iVar9);
                                }
                            }
                            goto code_r0x0001800689e1;
                        }
                    }
                    func_0x000180460d90(puVar19);
                }
                goto code_r0x000180068d5b;
            }
        }
    }
code_r0x000180068d3d:
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
code_r0x000180068d5b:
    func_0x000180459870(var_70h ^ (uint64_t)auStack_118);
    return;
code_r0x0001800693c0:
    func_0x000180460d90(var_c0h);
    var_c0h = 0;
    var_f8h._0_4_ = var_d8h;
code_r0x0001800693d5:
    *(uint32_t *)var_b8h = var_e8h._4_4_;
    *(uint32_t *)var_b0h = (uint32_t)var_f8h;
    func_0x000180069b10(var_c0h, 4, 4);
    goto code_r0x000180068d5b;
}

// ============================================================
// Function: FUN_18006832f
// Address: 0x18006832f
// Size: 4306 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_d0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_d3h
// WARNING: [rz-ghidra] Detected overlap for variable var_d2h
// WARNING: [rz-ghidra] Detected overlap for variable var_97h
// WARNING: [rz-ghidra] Detected overlap for variable var_96h
// WARNING: [rz-ghidra] Detected overlap for variable var_d1h
// WARNING: [rz-ghidra] Detected overlap for variable var_cdh
// WARNING: [rz-ghidra] Detected overlap for variable var_ceh
// WARNING: [rz-ghidra] Detected overlap for variable var_cfh
// WARNING: [rz-ghidra] Detected overlap for variable var_90h

void fcn.1800670c0(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, undefined8 placeholder_4,
                  int64_t arg_30h)
{
    int32_t *piVar1;
    char **ppcVar2;
    char **ppcVar3;
    bool bVar4;
    char cVar5;
    uint8_t uVar6;
    undefined2 uVar7;
    uint16_t uVar8;
    int32_t iVar9;
    int32_t iVar10;
    uint32_t uVar11;
    uint32_t uVar12;
    int32_t iVar13;
    undefined4 uVar14;
    int32_t iVar15;
    int64_t iVar16;
    uint8_t *puVar17;
    uint8_t *puVar18;
    undefined *puVar19;
    undefined extraout_AH;
    int64_t *piVar20;
    char *pcVar21;
    int64_t iVar22;
    undefined uVar23;
    char cVar24;
    char cVar25;
    int32_t iVar26;
    uint64_t uVar27;
    int64_t iVar28;
    undefined *puVar29;
    uint8_t uVar30;
    uint8_t *puVar31;
    undefined2 *puVar32;
    uint32_t uVar33;
    uint8_t uVar34;
    uint8_t uVar35;
    uint32_t uVar36;
    float fVar37;
    float fVar38;
    int64_t var_20h;
    undefined auStack_118 [32];
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    uint32_t var_d8h;
    undefined4 var_d4h;
    undefined4 var_d0h;
    int64_t var_cch;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    undefined8 var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    
    var_70h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_118;
    iVar10 = 8;
    var_c0h = arg_30h;
    *(undefined8 *)arg_30h = 8;
    *(undefined4 *)(arg_30h + 8) = 0;
    var_b8h = arg2;
    var_b0h = arg3;
    iVar9 = func_0x00018006f850();
    pcVar21 = *(char **)(arg1 + 0xd0);
    ppcVar2 = (char **)(arg1 + 0xc0);
    ppcVar3 = (char **)(arg1 + 200);
    *ppcVar2 = pcVar21;
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    if (iVar9 != 0) {
        var_98h = arg1;
        iVar9 = func_0x0001800708b0(&var_98h, 0, 4);
        iVar16 = var_80h;
        if (iVar9 != 0) {
            if (8 < (int32_t)var_78h) {
                if ((int32_t)var_78h != 0x10) goto code_r0x000180068d5b;
                iVar10 = 0x10;
            }
            *(int32_t *)arg_30h = iVar10;
            var_80h = 0;
            if (*(int32_t *)(var_98h + 0xc) != 4) {
                var_f8h._0_4_ = *(uint32_t *)(var_98h + 4);
                if (iVar10 == 8) {
                    iVar16 = func_0x000180069b10(iVar16, *(int32_t *)(var_98h + 0xc), 4);
                } else {
                    iVar16 = func_0x000180069fc0(iVar16);
                }
                *(undefined4 *)(var_98h + 0xc) = 4;
                if (iVar16 == 0) goto code_r0x000180068d5b;
            }
            *(undefined4 *)var_b8h = *(undefined4 *)var_98h;
            *(undefined4 *)arg3 = *(undefined4 *)(var_98h + 4);
        }
        func_0x000180460d90(var_80h);
        var_80h = 0;
        func_0x000180460d90(var_88h);
        var_88h = 0;
        func_0x000180460d90(var_90h);
        goto code_r0x000180068d5b;
    }
    if (pcVar21 < *(char **)(arg1 + 0xd8)) {
        cVar5 = *pcVar21;
code_r0x000180067232:
        *ppcVar2 = pcVar21 + 1;
        if ((cVar5 != 'B') || (cVar5 = func_0x0001800697d0(arg1), cVar5 != 'M')) goto code_r0x000180067246;
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        func_0x000180069a30(arg1);
        iVar9 = func_0x000180069a30(arg1);
        iVar10 = func_0x000180069a30(arg1);
        uVar11 = iVar10 * 0x10000 + iVar9;
        if ((((uVar11 < 0x39) && ((0x100010000001000U >> ((uint64_t)uVar11 & 0x3f) & 1) != 0)) || (uVar11 == 0x6c)) ||
           (uVar11 == 0x7c)) {
            bVar4 = true;
        } else {
            bVar4 = false;
        }
        *ppcVar2 = *(char **)(arg1 + 0xd0);
        *ppcVar3 = *(char **)(arg1 + 0xd8);
        arg2 = var_b8h;
        if (bVar4) {
            var_f0h = arg_30h;
            var_f8h._0_4_ = 4;
            func_0x000180071bc0(arg1, var_b8h, var_b0h, 0);
            goto code_r0x000180068d5b;
        }
    } else {
        if (*(int32_t *)(arg1 + 0x30) != 0) {
            func_0x000180069750(arg1);
            pcVar21 = *ppcVar2;
            cVar5 = *pcVar21;
            goto code_r0x000180067232;
        }
code_r0x000180067246:
        *ppcVar2 = *(char **)(arg1 + 0xd0);
        *ppcVar3 = *(char **)(arg1 + 0xd8);
    }
    iVar9 = func_0x000180072ce0(arg1);
    if (iVar9 != 0) {
        func_0x000180073b70(arg1, arg2, var_b0h);
        goto code_r0x000180068d5b;
    }
    iVar9 = func_0x000180069950(arg1);
    iVar10 = func_0x000180069950(arg1);
    *ppcVar2 = *(char **)(arg1 + 0xd0);
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    if (iVar10 + iVar9 * 0x10000 == 0x38425053) {
        iVar9 = func_0x000180069950();
        iVar10 = func_0x000180069950(arg1);
        if ((iVar10 + iVar9 * 0x10000 == 0x38425053) && (iVar9 = func_0x000180069950(arg1), iVar9 == 1)) {
            if ((*(int64_t *)(arg1 + 0x10) == 0) || (iVar9 = *(int32_t *)ppcVar2, 5 < *(int32_t *)ppcVar3 - iVar9)) {
                *ppcVar2 = *ppcVar2 + 6;
            } else {
                *ppcVar2 = *ppcVar3;
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 6 - (*(int32_t *)ppcVar3 - iVar9));
            }
            uVar11 = func_0x000180069950(arg1);
            var_e8h._4_4_ = uVar11;
            if (uVar11 < 0x11) {
                uVar12 = func_0x000180069a00(arg1);
                var_cch._4_4_ = uVar12;
                iVar9 = func_0x000180069a00(arg1);
                var_cch._0_4_ = iVar9;
                if ((((int32_t)uVar12 < 0x1000001) && (iVar9 < 0x1000001)) &&
                   ((iVar10 = func_0x000180069950(arg1), (iVar10 - 8U & 0xfffffff7) == 0 &&
                    (iVar13 = func_0x000180069950(arg1), iVar13 == 3)))) {
                    uVar14 = func_0x000180069a00(arg1);
                    func_0x000180069830(arg1, uVar14);
                    uVar14 = func_0x000180069a00(arg1);
                    func_0x000180069830(arg1, uVar14);
                    func_0x000180069a00(arg1);
                    func_0x000180069830(arg1);
                    iVar13 = func_0x000180069950(arg1);
                    if ((((iVar13 < 2) && (-1 < iVar9)) &&
                        ((iVar9 == 0 || (3 < (int32_t)(0x7fffffff / (int64_t)iVar9))))) &&
                       (((-1 < iVar9 * 4 && (-1 < (int32_t)uVar12)) &&
                        ((uVar12 == 0 || (iVar9 * 4 <= (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12))))))) {
                        uVar12 = uVar12 * iVar9;
                        iVar16 = func_0x00018046d050((int64_t)(int32_t)(uVar12 * 4));
                        var_a8h = iVar16;
                        if (iVar16 != 0) {
                            if (iVar13 == 0) {
                                uVar27 = 0;
                                do {
                                    iVar9 = (int32_t)uVar27;
                                    if (iVar9 < (int32_t)uVar11) {
                                        iVar13 = 0;
                                        uVar11 = var_e8h._4_4_;
                                        if (*(int32_t *)var_c0h == 0x10) {
                                            puVar32 = (undefined2 *)(iVar16 + uVar27 * 2);
                                            if (0 < (int32_t)uVar12) {
                                                do {
                                                    uVar7 = func_0x000180069950(arg1);
                                                    iVar13 = iVar13 + 1;
                                                    *puVar32 = uVar7;
                                                    puVar32 = puVar32 + 4;
                                                    uVar11 = var_e8h._4_4_;
                                                } while (iVar13 < (int32_t)uVar12);
                                            }
                                        } else {
                                            puVar19 = (undefined *)(uVar27 + iVar16);
                                            if (iVar10 == 0x10) {
                                                if (0 < (int32_t)uVar12) {
                                                    do {
                                                        func_0x000180069950(arg1);
                                                        iVar13 = iVar13 + 1;
                                                        *puVar19 = extraout_AH;
                                                        puVar19 = puVar19 + 4;
                                                        uVar11 = var_e8h._4_4_;
                                                    } while (iVar13 < (int32_t)uVar12);
                                                }
                                            } else if (0 < (int32_t)uVar12) {
                                                do {
                                                    puVar29 = *(undefined **)(undefined8 *)(arg1 + 0xc0);
                                                    if (puVar29 < *(undefined **)(arg1 + 200)) {
                                                        uVar23 = *puVar29;
                                                        *(undefined8 *)(arg1 + 0xc0) = puVar29 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar23 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        puVar29 = *(undefined **)(undefined8 *)(arg1 + 0xc0);
                                                        uVar23 = *puVar29;
                                                        *(undefined8 *)(arg1 + 0xc0) = puVar29 + 1;
                                                    }
                                                    *puVar19 = uVar23;
                                                    iVar13 = iVar13 + 1;
                                                    puVar19 = puVar19 + 4;
                                                    iVar16 = var_a8h;
                                                    uVar11 = var_e8h._4_4_;
                                                } while (iVar13 < (int32_t)uVar12);
                                            }
                                        }
                                    } else {
                                        uVar23 = 0;
                                        puVar19 = (undefined *)(uVar27 + iVar16);
                                        if (iVar9 == 3) {
                                            uVar23 = 0xff;
                                        }
                                        iVar13 = 0;
                                        if (0 < (int32_t)uVar12) {
                                            do {
                                                iVar13 = iVar13 + 1;
                                                *puVar19 = uVar23;
                                                puVar19 = puVar19 + 4;
                                            } while (iVar13 < (int32_t)uVar12);
                                        }
                                    }
                                    uVar27 = (uint64_t)(iVar9 + 1U);
                                } while ((int32_t)(iVar9 + 1U) < 4);
                            } else {
                                func_0x000180069830();
                                var_d8h = 0;
                                do {
                                    puVar31 = (uint8_t *)((int32_t)var_d8h + iVar16);
                                    if ((int32_t)var_d8h < (int32_t)uVar11) {
                                        iVar9 = 0;
                                        uVar36 = uVar12;
                                        while (0 < (int32_t)uVar36) {
                                            puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar17 < *(uint8_t **)(arg1 + 200)) {
code_r0x000180067598:
                                                uVar30 = *puVar17;
                                                puVar18 = puVar17 + 1;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar18;
                                                if (uVar30 != 0x80) {
                                                    uVar11 = (uint32_t)uVar30;
                                                    if (uVar30 < 0x80) goto code_r0x00018006761f;
                                                    if (0x80 < uVar30) {
                                                        iVar10 = 0x101 - (uint32_t)uVar30;
                                                        if ((int32_t)uVar36 < iVar10) goto code_r0x0001800676a8;
                                                        if (puVar18 < *(uint8_t **)(arg1 + 200)) {
                                                            uVar30 = *puVar18;
                                                            *(uint8_t **)(arg1 + 0xc0) = puVar17 + 2;
                                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                            uVar30 = 0;
                                                        } else {
                                                            func_0x000180069750(arg1);
                                                            puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                            uVar30 = *puVar17;
                                                            *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                        }
                                                        iVar9 = iVar9 + iVar10;
                                                        for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                                                            *puVar31 = uVar30;
                                                            puVar31 = puVar31 + 4;
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) {
                                                    func_0x000180069750();
                                                    puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                    goto code_r0x000180067598;
                                                }
                                                uVar11 = 0;
code_r0x00018006761f:
                                                uVar11 = uVar11 + 1;
                                                if (uVar36 < uVar11) {
code_r0x0001800676a8:
                                                    func_0x000180460d90(iVar16);
                                                    goto code_r0x000180068d5b;
                                                }
                                                iVar9 = iVar9 + uVar11;
                                                do {
                                                    puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                    if (puVar17 < *(uint8_t **)(arg1 + 200)) {
                                                        uVar30 = *puVar17;
                                                        *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar30 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        puVar17 = *(uint8_t **)(arg1 + 0xc0);
                                                        uVar30 = *puVar17;
                                                        *(uint8_t **)(arg1 + 0xc0) = puVar17 + 1;
                                                    }
                                                    *puVar31 = uVar30;
                                                    puVar31 = puVar31 + 4;
                                                    uVar11 = uVar11 - 1;
                                                } while (uVar11 != 0);
                                            }
                                            uVar11 = var_e8h._4_4_;
                                            uVar36 = uVar12 - iVar9;
                                        }
                                    } else {
                                        iVar9 = 0;
                                        if (0 < (int32_t)uVar12) {
                                            uVar30 = 0;
                                            if (var_d8h == 3) {
                                                uVar30 = 0xff;
                                            }
                                            do {
                                                iVar9 = iVar9 + 1;
                                                *puVar31 = uVar30;
                                                puVar31 = puVar31 + 4;
                                            } while (iVar9 < (int32_t)uVar12);
                                        }
                                    }
                                    var_d8h = var_d8h + 1;
                                } while ((int32_t)var_d8h < 4);
                            }
                            if (3 < (int32_t)uVar11) {
                                iVar9 = 0;
                                if (*(int32_t *)var_c0h == 0x10) {
                                    if (3 < (int32_t)uVar12) {
                                        do {
                                            iVar28 = (int64_t)(iVar9 * 4);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            uVar8 = *(uint16_t *)(iVar16 + 0xe + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + 8 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 8 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 10 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 10 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 0xc + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 0xc + iVar28 * 2)
                                                                        * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 8);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 0xc);
                                            uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                            if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                                fVar37 = (1.0 - fVar38) * 65535.0;
                                                *(int16_t *)(iVar16 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                                *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                     (int16_t)(int32_t)((float)(uint32_t)
                                                                               *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                        fVar38 + fVar37);
                                            }
                                            iVar9 = iVar9 + 4;
                                        } while (iVar9 < (int32_t)(uVar12 - 3));
                                    }
                                    for (; iVar9 < (int32_t)uVar12; iVar9 = iVar9 + 1) {
                                        iVar28 = (int64_t)(iVar9 * 4);
                                        uVar8 = *(uint16_t *)(iVar16 + 6 + iVar28 * 2);
                                        if ((uint16_t)(uVar8 - 1) < 0xfffe) {
                                            fVar38 = 1.0 / ((float)(uint32_t)uVar8 / 65535.0);
                                            fVar37 = (1.0 - fVar38) * 65535.0;
                                            *(int16_t *)(iVar16 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)*(uint16_t *)(iVar16 + iVar28 * 2)
                                                                    * fVar38 + fVar37);
                                            *(int16_t *)(iVar16 + 2 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)
                                                                           *(uint16_t *)(iVar16 + 2 + iVar28 * 2) *
                                                                    fVar38 + fVar37);
                                            *(int16_t *)(iVar16 + 4 + iVar28 * 2) =
                                                 (int16_t)(int32_t)((float)(uint32_t)
                                                                           *(uint16_t *)(iVar16 + 4 + iVar28 * 2) *
                                                                    fVar38 + fVar37);
                                        }
                                    }
                                } else {
                                    if (3 < (int32_t)uVar12) {
                                        do {
                                            iVar28 = (int64_t)(iVar9 * 4);
                                            uVar30 = *(uint8_t *)(iVar16 + 3 + iVar28);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar16 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + iVar28) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar16 + 1 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 1 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 2 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 2 + iVar28)
                                                                     * fVar38 + fVar37);
                                            }
                                            uVar30 = *(uint8_t *)(iVar16 + 7 + iVar28);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar16 + 4 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 4 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 5 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 5 + iVar28)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar16 + 6 + iVar28) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar16 + 6 + iVar28)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 8);
                                            uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar28 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar28 + 1 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar28 + 2 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar28 = (int64_t)(iVar9 * 4 + 0xc);
                                            uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                            if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                                fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                                fVar37 = (1.0 - fVar38) * 255.0;
                                                *(char *)(iVar28 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) *
                                                                     fVar38 + fVar37);
                                                *(char *)(iVar28 + 1 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16)
                                                                     * fVar38 + fVar37);
                                                *(char *)(iVar28 + 2 + iVar16) =
                                                     (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16)
                                                                     * fVar38 + fVar37);
                                            }
                                            iVar9 = iVar9 + 4;
                                        } while (iVar9 < (int32_t)(uVar12 - 3));
                                    }
                                    for (; iVar9 < (int32_t)uVar12; iVar9 = iVar9 + 1) {
                                        iVar28 = (int64_t)(iVar9 * 4);
                                        uVar30 = *(uint8_t *)(iVar28 + 3 + iVar16);
                                        if ((uint8_t)(uVar30 - 1) < 0xfe) {
                                            fVar38 = 1.0 / ((float)(uint32_t)uVar30 / 255.0);
                                            fVar37 = (1.0 - fVar38) * 255.0;
                                            *(char *)(iVar28 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + iVar16) * fVar38
                                                                + fVar37);
                                            *(char *)(iVar28 + 1 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 1 + iVar16) *
                                                                 fVar38 + fVar37);
                                            *(char *)(iVar28 + 2 + iVar16) =
                                                 (char)(int32_t)((float)(uint32_t)*(uint8_t *)(iVar28 + 2 + iVar16) *
                                                                 fVar38 + fVar37);
                                        }
                                    }
                                }
                            }
                            *(uint32_t *)var_b0h = var_cch._4_4_;
                            *(int32_t *)var_b8h = (int32_t)var_cch;
                        }
                    }
                }
            }
        }
        goto code_r0x000180068d5b;
    }
    iVar9 = func_0x000180072b70(arg1, 0x18063cc84);
    if (iVar9 != 0) {
        iVar9 = 0x54;
        do {
            if (*ppcVar2 < *ppcVar3) {
                *ppcVar2 = *ppcVar2 + 1;
            } else if (*(int32_t *)(arg1 + 0x30) != 0) {
                func_0x000180069750(arg1);
                *ppcVar2 = *ppcVar2 + 1;
            }
            iVar9 = iVar9 + -1;
        } while (iVar9 != 0);
        iVar9 = func_0x000180072b70(arg1, 0x18063cc7c);
        if (iVar9 != 0) {
            pcVar21 = *(char **)(arg1 + 0xd0);
            ppcVar2 = (char **)(arg1 + 0xc0);
            iVar9 = 0x5c;
            *ppcVar2 = pcVar21;
            *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
            do {
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*(int32_t *)(arg1 + 0x30) != 0) {
                    func_0x000180069750(arg1);
                    *ppcVar2 = *ppcVar2 + 1;
                    pcVar21 = *ppcVar2;
                }
                iVar9 = iVar9 + -1;
            } while (iVar9 != 0);
            uVar11 = func_0x000180069950(arg1);
            var_e8h._4_4_ = uVar11;
            uVar12 = func_0x000180069950(arg1);
            var_d8h = uVar12;
            if ((0x1000000 < (int32_t)uVar12) || (0x1000000 < (int32_t)uVar11)) goto code_r0x000180068d5b;
            if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180068e24:
                if (*(char **)(arg1 + 200) <= *ppcVar2) goto code_r0x000180068d5b;
            } else {
                iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                if (iVar9 != 0) {
                    if (*(int32_t *)(arg1 + 0x30) == 0) goto code_r0x000180068d5b;
                    goto code_r0x000180068e24;
                }
            }
            if (((((int32_t)uVar11 < 0) || ((int32_t)uVar12 < 0)) ||
                ((uVar12 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12) < (int32_t)uVar11)))) ||
               (0x1fffffff < uVar11 * uVar12)) goto code_r0x000180068d5b;
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            func_0x000180069950(arg1);
            if ((uVar12 != 0) && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar12) < (int32_t)uVar11))
            goto code_r0x000180068d5b;
            iVar16 = (int64_t)(int32_t)(uVar11 * uVar12 * 4);
            var_c0h = func_0x00018046d050(iVar16);
            if (var_c0h == 0) goto code_r0x000180068d5b;
            func_0x0001804986e0(var_c0h, 0xff, iVar16);
            var_e0h._4_4_ = 0;
            do {
                if (var_e0h._4_4_ == 10) goto code_r0x0001800693c0;
                iVar16 = (int64_t)var_e0h._4_4_;
                pcVar21 = *ppcVar2;
                piVar1 = (int32_t *)(arg1 + 0x30);
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar5 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar5 = '\0';
                } else {
                    func_0x000180069750();
                    cVar5 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar24 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar24 = '\0';
                } else {
                    func_0x000180069750();
                    cVar24 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                *(char *)((int64_t)&var_98h + iVar16 * 3) = cVar24;
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar25 = *pcVar21;
                    pcVar21 = pcVar21 + 1;
                    *ppcVar2 = pcVar21;
                } else if (*piVar1 == 0) {
                    cVar25 = '\0';
                } else {
                    func_0x000180069750(arg1);
                    cVar25 = **ppcVar2;
                    pcVar21 = *ppcVar2 + 1;
                    *ppcVar2 = pcVar21;
                }
                *(char *)((int64_t)&var_98h + iVar16 * 3 + 1) = cVar25;
                if (pcVar21 < *(char **)(arg1 + 200)) {
                    cVar25 = *pcVar21;
                    *ppcVar2 = pcVar21 + 1;
                } else if (*piVar1 == 0) {
                    cVar25 = '\0';
                } else {
                    func_0x000180069750(arg1);
                    cVar25 = **ppcVar2;
                    *ppcVar2 = *ppcVar2 + 1;
                }
                iVar28 = *(int64_t *)(arg1 + 0x10);
                *(char *)((int64_t)&var_98h + iVar16 * 3 + 2) = cVar25;
                if (iVar28 == 0) {
code_r0x000180068fed:
                    if (*(char **)(arg1 + 200) <= *ppcVar2) goto code_r0x0001800693c0;
                } else {
                    iVar9 = (**(code **)(arg1 + 0x20))();
                    if (iVar9 != 0) {
                        if (*piVar1 != 0) goto code_r0x000180068fed;
                        goto code_r0x0001800693c0;
                    }
                }
                if (cVar24 != '\b') goto code_r0x0001800693c0;
                iVar9 = var_e0h._4_4_ + 1;
                var_e0h._4_4_ = iVar9;
            } while (cVar5 != '\0');
            var_cch._0_4_ = 0;
            var_f8h._0_4_ = var_d8h;
            if (0 < (int32_t)var_d8h) {
                do {
                    uVar27 = 0;
                    var_cch._4_4_ = 0;
                    if (0 < iVar9) {
                        puVar19 = (undefined *)((int32_t)((int32_t)var_cch * var_e8h._4_4_ * 4) + var_c0h);
                        var_a0h = (int64_t)puVar19;
                        uVar11 = var_e8h._4_4_;
                        do {
                            iVar16 = uVar27 * 3;
                            cVar5 = *(char *)((int64_t)&var_98h + iVar16 + 1);
                            var_a8h = iVar16;
                            if (cVar5 == '\0') {
                                if (0 < (int32_t)uVar11) {
                                    uVar23 = *(undefined *)((int64_t)&var_98h + iVar16 + 2);
                                    iVar9 = 0;
                                    puVar29 = puVar19;
                                    do {
                                        iVar16 = func_0x000180072c10(arg1, uVar23, puVar29);
                                        if (iVar16 == 0) goto code_r0x0001800693c0;
                                        iVar9 = iVar9 + 1;
                                        puVar29 = puVar29 + 4;
                                        puVar19 = (undefined *)var_a0h;
                                    } while (iVar9 < (int32_t)uVar11);
                                }
                            } else {
                                puVar29 = puVar19;
                                uVar12 = uVar11;
                                if (cVar5 == '\x01') {
                                    while (0 < (int32_t)uVar12) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar11 = (uint32_t)*puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar11 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar11 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x000180069294:
                                            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0))
                                            goto code_r0x0001800693c0;
                                        } else {
                                            iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                                            if (iVar9 != 0) {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x000180069294;
                                                goto code_r0x0001800693c0;
                                            }
                                        }
                                        if (uVar12 < uVar11) {
                                            uVar11 = uVar12 & 0xff;
                                        }
                                        uVar30 = *(uint8_t *)((int64_t)&var_98h + iVar16 + 2);
                                        iVar28 = func_0x000180072c10(arg1, uVar30, &var_d4h);
                                        if (iVar28 == 0) goto code_r0x0001800693c0;
                                        iVar9 = 0;
                                        if ((char)uVar11 != '\0') {
                                            do {
                                                if ((uVar30 & 0x80) != 0) {
                                                    *puVar29 = (char)var_d4h;
                                                }
                                                if ((uVar30 & 0x40) != 0) {
                                                    puVar29[1] = var_d4h._1_1_;
                                                }
                                                if ((uVar30 & 0x20) != 0) {
                                                    puVar29[2] = var_d4h._2_1_;
                                                }
                                                if ((uVar30 & 0x10) != 0) {
                                                    puVar29[3] = var_d4h._3_1_;
                                                }
                                                iVar9 = iVar9 + 1;
                                                puVar29 = puVar29 + 4;
                                                iVar16 = var_a8h;
                                            } while (iVar9 < (int32_t)uVar11);
                                        }
                                        puVar19 = (undefined *)var_a0h;
                                        uVar12 = uVar12 - uVar11;
                                        uVar11 = var_e8h._4_4_;
                                    }
                                } else {
                                    if (cVar5 != '\x02') goto code_r0x0001800693c0;
                                    while (0 < (int32_t)uVar12) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar30 = *puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar30 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar30 = **(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        if (*(int64_t *)(arg1 + 0x10) == 0) {
code_r0x0001800690ff:
                                            if (*(uint64_t *)(arg1 + 200) <= *(uint64_t *)(arg1 + 0xc0))
                                            goto code_r0x0001800693c0;
                                        } else {
                                            iVar9 = (**(code **)(arg1 + 0x20))(*(undefined8 *)(arg1 + 0x28));
                                            if (iVar9 != 0) {
                                                if (*(int32_t *)(arg1 + 0x30) != 0) goto code_r0x0001800690ff;
                                                goto code_r0x0001800693c0;
                                            }
                                        }
                                        uVar11 = (uint32_t)uVar30;
                                        if (uVar11 < 0x80) {
                                            uVar11 = uVar11 + 1;
                                            if (uVar12 < uVar11) goto code_r0x0001800693c0;
                                            if (uVar11 != 0) {
                                                uVar23 = *(undefined *)((int64_t)&var_98h + iVar16 + 2);
                                                iVar9 = 0;
                                                do {
                                                    iVar16 = func_0x000180072c10(arg1, uVar23, puVar29);
                                                    if (iVar16 == 0) goto code_r0x0001800693c0;
                                                    iVar9 = iVar9 + 1;
                                                    puVar29 = puVar29 + 4;
                                                    iVar16 = var_a8h;
                                                } while (iVar9 < (int32_t)uVar11);
                                            }
                                        } else {
                                            if (uVar11 == 0x80) {
                                                uVar11 = func_0x000180069950(arg1);
                                            } else {
                                                uVar11 = uVar30 - 0x7f;
                                            }
                                            if ((int32_t)uVar12 < (int32_t)uVar11) goto code_r0x0001800693c0;
                                            uVar30 = *(uint8_t *)((int64_t)&var_98h + iVar16 + 2);
                                            iVar28 = func_0x000180072c10(arg1, uVar30, &var_d0h);
                                            if (iVar28 == 0) goto code_r0x0001800693c0;
                                            iVar9 = 0;
                                            if (0 < (int32_t)uVar11) {
                                                do {
                                                    if ((uVar30 & 0x80) != 0) {
                                                        *puVar29 = (char)var_d0h;
                                                    }
                                                    if ((uVar30 & 0x40) != 0) {
                                                        puVar29[1] = var_d0h._1_1_;
                                                    }
                                                    if ((uVar30 & 0x20) != 0) {
                                                        puVar29[2] = var_d0h._2_1_;
                                                    }
                                                    if ((uVar30 & 0x10) != 0) {
                                                        puVar29[3] = var_d0h._3_1_;
                                                    }
                                                    iVar9 = iVar9 + 1;
                                                    puVar29 = puVar29 + 4;
                                                    iVar16 = var_a8h;
                                                } while (iVar9 < (int32_t)uVar11);
                                            }
                                        }
                                        puVar19 = (undefined *)var_a0h;
                                        uVar12 = uVar12 - uVar11;
                                        uVar11 = var_e8h._4_4_;
                                    }
                                }
                            }
                            var_cch._4_4_ = var_cch._4_4_ + 1;
                            uVar27 = (uint64_t)var_cch._4_4_;
                            iVar9 = var_e0h._4_4_;
                            var_f8h._0_4_ = var_d8h;
                        } while ((int32_t)var_cch._4_4_ < var_e0h._4_4_);
                    }
                    var_cch._0_4_ = (int32_t)var_cch + 1;
                } while ((int32_t)var_cch < (int32_t)(uint32_t)var_f8h);
            }
            goto code_r0x0001800693d5;
        }
    }
    *ppcVar2 = *(char **)(arg1 + 0xd0);
    *ppcVar3 = *(char **)(arg1 + 0xd8);
    piVar20 = (int64_t *)func_0x00018046d050();
    if (piVar20 != (int64_t *)0x0) {
        *piVar20 = arg1;
        func_0x00018006e660(piVar20);
        iVar9 = func_0x00018006d480(piVar20, 1);
        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
        *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
        func_0x000180460d90();
        if (iVar9 != 0) {
            piVar20 = (int64_t *)func_0x00018046d050(0x4888);
            if (piVar20 != (int64_t *)0x0) {
                *piVar20 = arg1;
                func_0x00018006e660(piVar20);
                var_f8h._0_4_ = 4;
                func_0x00018006e6e0(piVar20, var_b8h, var_b0h, 0);
                func_0x000180460d90(piVar20);
            }
            goto code_r0x000180068d5b;
        }
    }
    pcVar21 = *(char **)(arg1 + 0xc0);
    if (pcVar21 < *(char **)(arg1 + 200)) {
        cVar5 = *pcVar21;
        pcVar21 = pcVar21 + 1;
        *(char **)(arg1 + 0xc0) = pcVar21;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar5 = '\0';
    } else {
        func_0x000180069750();
        cVar5 = **(char **)(arg1 + 0xc0);
        pcVar21 = *(char **)(arg1 + 0xc0) + 1;
        *(char **)(arg1 + 0xc0) = pcVar21;
    }
    if (pcVar21 < *(char **)(arg1 + 200)) {
        cVar24 = *pcVar21;
        *(char **)(arg1 + 0xc0) = pcVar21 + 1;
    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
        cVar24 = '\0';
    } else {
        func_0x000180069750(arg1);
        cVar24 = **(char **)(arg1 + 0xc0);
        *(char **)(arg1 + 0xc0) = *(char **)(arg1 + 0xc0) + 1;
    }
    if ((cVar5 == 'P') && (cVar24 == '5' || cVar24 == '6')) {
        iVar9 = func_0x000180074950(arg1, arg1, arg1 + 4, arg1 + 8);
        *(int32_t *)arg_30h = iVar9;
        if ((iVar9 != 0) && ((*(uint32_t *)(arg1 + 4) < 0x1000001 && (*(uint32_t *)arg1 < 0x1000001)))) {
            *(uint32_t *)var_b8h = *(uint32_t *)arg1;
            *(undefined4 *)var_b0h = *(undefined4 *)(arg1 + 4);
            iVar9 = *(int32_t *)(arg1 + 8);
            if (-1 < iVar9) {
                iVar10 = *(int32_t *)arg1;
                if ((-1 < iVar10) &&
                   (((iVar10 == 0 || (iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))) && (-1 < iVar9 * iVar10)))) {
                    iVar13 = *(int32_t *)(arg1 + 4);
                    if ((-1 < iVar13) &&
                       (((iVar13 == 0 || (iVar9 * iVar10 <= (int32_t)(0x7fffffff / (int64_t)iVar13))) &&
                        (iVar26 = iVar9 * iVar10 * iVar13, -1 < iVar26)))) {
                        uVar11 = *(int32_t *)arg_30h >> 0x1f & 7;
                        uVar27 = (uint64_t)uVar11;
                        iVar15 = (int32_t)(*(int32_t *)arg_30h + uVar11) >> 3;
                        if ((((-1 < iVar15) &&
                             ((iVar15 == 0 ||
                              (uVar27 = 0x7fffffff % (int64_t)iVar15 & 0xffffffff,
                              iVar26 <= (int32_t)(0x7fffffff / (int64_t)iVar15))))) &&
                            ((iVar10 == 0 ||
                             (uVar27 = 0x7fffffff % (int64_t)iVar10 & 0xffffffff,
                             iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))))) &&
                           ((iVar13 == 0 ||
                            (uVar27 = 0x7fffffff % (int64_t)iVar13 & 0xffffffff,
                            iVar9 * iVar10 <= (int32_t)(0x7fffffff / (int64_t)iVar13))))) {
                            iVar26 = iVar9 * iVar13 * iVar10;
                            if ((-1 < iVar26) &&
                               (((iVar15 == 0 ||
                                 (uVar27 = 0x7fffffff % (int64_t)iVar15 & 0xffffffff,
                                 iVar26 <= (int32_t)(0x7fffffff / (int64_t)iVar15))) &&
                                (iVar16 = func_0x00018046d050((int64_t)(iVar9 * iVar13 * iVar15 * iVar10), uVar27),
                                iVar16 != 0)))) {
                                func_0x000180069890(arg1, iVar16, 
                                                    *(int32_t *)(arg1 + 8) * *(int32_t *)(arg1 + 4) *
                                                    ((int32_t)(*(int32_t *)arg_30h + (*(int32_t *)arg_30h >> 0x1f & 7U))
                                                    >> 3) * *(int32_t *)arg1);
                                if (*(int32_t *)(arg1 + 8) != 4) {
                                    var_f8h._0_4_ = *(uint32_t *)(arg1 + 4);
                                    func_0x000180069b10(iVar16, *(int32_t *)(arg1 + 8), 4, *(undefined4 *)arg1);
                                }
                            }
                        }
                    }
                }
            }
        }
        goto code_r0x000180068d5b;
    }
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
    iVar9 = func_0x000180073cf0(arg1);
    iVar28 = var_b0h;
    iVar16 = var_b8h;
    if (iVar9 != 0) {
        iVar22 = func_0x000180073fe0(arg1, var_b8h);
        if (iVar22 != 0) {
            iVar9 = *(int32_t *)iVar16;
            if (-1 < iVar9) {
                iVar10 = *(int32_t *)iVar28;
                if ((((-1 < iVar10) && ((iVar10 == 0 || (iVar9 <= (int32_t)(0x7fffffff / (int64_t)iVar10))))) &&
                    (uVar11 = iVar9 * iVar10, uVar11 < 0x20000000)) &&
                   (iVar16 = func_0x00018046d050((int64_t)(int32_t)(uVar11 * 4)), iVar16 != 0)) {
                    var_d8h = 0;
                    var_c0h = iVar16;
                    if (0 < (int32_t)uVar11) {
                        do {
                            iVar10 = 0;
                            iVar9 = var_d8h * 4;
                            do {
                                iVar28 = (int64_t)iVar9;
                                fVar37 = (float)func_0x000180492580(*(undefined4 *)(iVar22 + iVar28 * 4));
                                iVar10 = iVar10 + 1;
                                iVar9 = iVar9 + 1;
                                fVar38 = fVar37 * 255.0 + 0.5;
                                fVar37 = 0.0;
                                if (0.0 <= fVar38) {
                                    fVar37 = fVar38;
                                }
                                fVar38 = 255.0;
                                if (fVar37 <= 255.0) {
                                    fVar38 = fVar37;
                                }
                                *(char *)(iVar28 + var_c0h) = (char)(int32_t)fVar38;
                            } while (iVar10 < 3);
                            iVar9 = var_d8h * 4;
                            var_d8h = var_d8h + 1;
                            iVar28 = (int64_t)(iVar9 + iVar10);
                            fVar38 = *(float *)(iVar22 + iVar28 * 4) * 255.0 + 0.5;
                            fVar37 = 0.0;
                            if (0.0 <= fVar38) {
                                fVar37 = fVar38;
                            }
                            fVar38 = 255.0;
                            if (fVar37 <= 255.0) {
                                fVar38 = fVar37;
                            }
                            *(char *)(iVar28 + iVar16) = (char)(int32_t)fVar38;
                        } while ((int32_t)var_d8h < (int32_t)uVar11);
                    }
                    func_0x000180460d90(iVar22);
                    goto code_r0x000180068d5b;
                }
            }
            func_0x000180460d90(iVar22);
        }
        goto code_r0x000180068d5b;
    }
    puVar31 = *(uint8_t **)(arg1 + 0xc0);
    if (puVar31 < *(uint8_t **)(arg1 + 200)) {
code_r0x000180068377:
        puVar31 = puVar31 + 1;
        *(uint8_t **)(arg1 + 0xc0) = puVar31;
    } else if (*(int32_t *)(arg1 + 0x30) != 0) {
        func_0x000180069750(arg1);
        puVar31 = *(uint8_t **)(arg1 + 0xc0);
        goto code_r0x000180068377;
    }
    if (puVar31 < *(uint8_t **)(arg1 + 200)) {
code_r0x0001800683ad:
        uVar30 = *puVar31;
        *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
        if (uVar30 < 2) {
            cVar5 = func_0x0001800697d0(arg1);
            if (uVar30 != 1) goto code_r0x000180068480;
            if ((cVar5 - 1U & 0xf7) == 0) {
                if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                   (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 3 < iVar9)) {
                    *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 4;
                } else {
                    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                    (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 4 - iVar9);
                }
                uVar6 = func_0x0001800697d0(arg1);
                if ((uVar6 < 0x21) && ((0x101018100U >> ((uint64_t)uVar6 & 0x3f) & 1) != 0)) {
                    if ((*(int64_t *)(arg1 + 0x10) == 0) ||
                       (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 3 < iVar9)) {
                        *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 4;
                    } else {
                        *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                        (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 4 - iVar9);
                    }
                    goto code_r0x0001800684c8;
                }
            }
        }
    } else {
        if (*(int32_t *)(arg1 + 0x30) != 0) {
            func_0x000180069750();
            puVar31 = *(uint8_t **)(arg1 + 0xc0);
            goto code_r0x0001800683ad;
        }
        uVar30 = 0;
        cVar5 = func_0x0001800697d0(arg1);
code_r0x000180068480:
        if ((cVar5 - 2U & 0xf6) == 0) {
            if ((*(int64_t *)(arg1 + 0x10) == 0) ||
               (iVar9 = *(int32_t *)(arg1 + 200) - *(int32_t *)(arg1 + 0xc0), 8 < iVar9)) {
                *(int64_t *)(arg1 + 0xc0) = *(int64_t *)(arg1 + 0xc0) + 9;
            } else {
                *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 200);
                (**(code **)(arg1 + 0x18))(*(undefined8 *)(arg1 + 0x28), 9 - iVar9);
            }
code_r0x0001800684c8:
            iVar9 = func_0x000180069a30(arg1);
            if ((0 < iVar9) && (iVar9 = func_0x000180069a30(arg1), 0 < iVar9)) {
                uVar6 = func_0x0001800697d0(arg1);
                if (uVar30 == 1) {
                    if (uVar6 != 8) {
                        if (uVar6 != 0x10) goto code_r0x000180068d3d;
                        goto code_r0x000180068503;
                    }
                } else {
code_r0x000180068503:
                    if ((0x20 < uVar6) || ((0x101018100U >> ((uint64_t)uVar6 & 0x3f) & 1) == 0))
                    goto code_r0x000180068d3d;
                }
                puVar31 = *(uint8_t **)(arg1 + 0xd0);
                *(uint8_t **)(arg1 + 0xc0) = puVar31;
                *(uint8_t **)(arg1 + 200) = *(uint8_t **)(arg1 + 0xd8);
                if (puVar31 < *(uint8_t **)(arg1 + 0xd8)) {
                    var_e0h._0_1_ = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    var_e0h._0_1_ = 0;
                } else {
                    func_0x000180069750(arg1);
                    var_e0h._0_1_ = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    var_e8h._0_1_ = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    var_e8h._0_1_ = 0;
                } else {
                    func_0x000180069750(arg1);
                    var_e8h._0_1_ = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar30 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar30 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar30 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                var_cch._0_4_ = func_0x000180069a30(arg1);
                var_d0h = func_0x000180069a30(arg1);
                puVar31 = *(uint8_t **)(arg1 + 0xc0);
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar6 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar6 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar6 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                func_0x000180069a30(arg1);
                func_0x000180069a30(arg1);
                var_e0h._4_4_ = func_0x000180069a30(arg1);
                uVar11 = func_0x000180069a30(arg1);
                puVar31 = *(uint8_t **)(arg1 + 0xc0);
                var_cch._4_4_ = uVar11;
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar34 = *puVar31;
                    puVar31 = puVar31 + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar34 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar34 = **(uint8_t **)(arg1 + 0xc0);
                    puVar31 = *(uint8_t **)(arg1 + 0xc0) + 1;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31;
                }
                if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                    uVar35 = *puVar31;
                    *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                    uVar35 = 0;
                } else {
                    func_0x000180069750(arg1);
                    uVar35 = **(uint8_t **)(arg1 + 0xc0);
                    *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                }
                iVar9 = var_e0h._4_4_;
                uVar12 = 0;
                var_d4h = 0;
                if ((0x1000000 < (int32_t)uVar11) || (0x1000000 < var_e0h._4_4_)) goto code_r0x000180068d5b;
                var_d8h = (uint32_t)uVar30;
                uVar33 = (uint32_t)uVar34;
                var_a8h = CONCAT44(var_a8h._4_4_, uVar33);
                uVar36 = uVar30 - 8;
                var_e8h._4_4_ = 0;
                if (var_d8h < 8) {
                    uVar36 = (uint32_t)uVar30;
                }
                if ((uint8_t)var_e8h == 0) {
                    if (uVar33 == 8) goto code_r0x0001800687c1;
                    if (uVar33 == 0xf) {
code_r0x0001800687b5:
                        uVar12 = 3;
                        var_e8h._4_4_ = 1;
                    } else if (uVar33 == 0x10) {
                        if (uVar36 != 3) goto code_r0x0001800687b5;
                        uVar12 = 2;
                    } else {
                        if ((uVar33 == 0x18) || (uVar33 == 0x20)) {
                            uVar36 = (uint32_t)uVar34;
                            goto code_r0x0001800687a4;
                        }
                        uVar12 = 0;
                    }
                } else {
                    uVar36 = (uint32_t)uVar6;
                    if (uVar36 != 8) {
                        if ((uVar36 != 0xf) && (uVar36 != 0x10)) {
                            if ((uVar36 == 0x18) || (uVar36 == 0x20)) {
code_r0x0001800687a4:
                                uVar12 = uVar36 >> 3;
                            }
                            goto code_r0x0001800687c4;
                        }
                        goto code_r0x0001800687b5;
                    }
code_r0x0001800687c1:
                    uVar12 = 1;
                }
code_r0x0001800687c4:
                if (uVar12 == 0) goto code_r0x000180068d5b;
                *(int32_t *)var_b8h = var_e0h._4_4_;
                *(uint32_t *)var_b0h = uVar11;
                if (((((var_e0h._4_4_ < 0) || ((int32_t)uVar11 < 0)) ||
                     ((uVar11 != 0 && ((int32_t)(0x7fffffff / (int64_t)(int32_t)uVar11) < var_e0h._4_4_)))) ||
                    ((((int32_t)(var_e0h._4_4_ * uVar11) < 0 ||
                      (uVar27 = 0x7fffffff % (uint64_t)uVar12,
                      (int32_t)(0x7fffffff / (uint64_t)uVar12) < (int32_t)(var_e0h._4_4_ * uVar11))) ||
                     ((uVar11 != 0 &&
                      (uVar27 = 0x7fffffff % (int64_t)(int32_t)uVar11 & 0xffffffff,
                      (int32_t)(0x7fffffff / (int64_t)(int32_t)uVar11) < var_e0h._4_4_)))))) ||
                   (puVar19 = (undefined *)
                              func_0x00018046d050((int64_t)(int32_t)(uVar12 * var_e0h._4_4_ * uVar11), uVar27),
                   puVar19 == (undefined *)0x0)) goto code_r0x000180068d5b;
                iVar13 = 1 - (uVar35 >> 5 & 1);
                var_b8h = CONCAT44(var_b8h._4_4_, iVar13);
                func_0x000180069830();
                iVar10 = var_d0h;
                if ((uint8_t)var_e8h == 0) {
                    if ((var_d8h < 8) && (var_e8h._4_4_ == 0)) {
                        if (0 < (int32_t)uVar11) {
                            iVar10 = 0;
                            if (iVar13 == 0) {
                                iVar13 = uVar12 * var_e0h._4_4_;
                                do {
                                    func_0x000180069890(arg1, puVar19 + iVar13 * iVar10);
                                    iVar10 = iVar10 + 1;
                                    iVar9 = var_e0h._4_4_;
                                } while (iVar10 < (int32_t)uVar11);
                            } else {
                                iVar13 = uVar12 * var_e0h._4_4_;
                                do {
                                    func_0x000180069890(arg1, puVar19 + (int32_t)(((uVar11 - iVar10) + -1) * iVar13));
                                    iVar10 = iVar10 + 1;
                                    iVar9 = var_e0h._4_4_;
                                } while (iVar10 < (int32_t)uVar11);
                            }
                        }
                    } else {
                        var_c0h = 0;
                        iVar16 = 0;
code_r0x0001800689e1:
                        bVar4 = true;
                        var_cch._0_4_ = 0;
                        iVar9 = var_e0h._4_4_ * uVar11;
                        iVar10 = 0;
                        var_b0h = CONCAT44(var_b0h._4_4_, iVar9);
                        if (0 < iVar9) {
                            uVar36 = 0;
                            do {
                                if (var_d8h < 8) {
code_r0x000180068a7a:
                                    if ((uint8_t)var_e8h == 0) {
                                        if (var_e8h._4_4_ == 0) {
                                            uVar27 = 0;
                                            if (uVar12 != 0) {
                                                do {
                                                    puVar29 = *(undefined **)(arg1 + 0xc0);
                                                    if (puVar29 < *(undefined **)(arg1 + 200)) {
                                                        uVar23 = *puVar29;
                                                        *(undefined **)(arg1 + 0xc0) = puVar29 + 1;
                                                    } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                        uVar23 = 0;
                                                    } else {
                                                        func_0x000180069750(arg1);
                                                        uVar23 = **(undefined **)(arg1 + 0xc0);
                                                        *(undefined **)(arg1 + 0xc0) = *(undefined **)(arg1 + 0xc0) + 1;
                                                    }
                                                    *(undefined *)((int64_t)&var_d4h + uVar27) = uVar23;
                                                    uVar11 = (int32_t)uVar27 + 1;
                                                    uVar27 = (uint64_t)uVar11;
                                                } while ((int32_t)uVar11 < (int32_t)uVar12);
                                            }
                                        } else {
                                            uVar8 = func_0x000180069a30(arg1);
                                            uVar14 = var_d4h;
                                            var_d4h._3_1_ = SUB41(uVar14, 3);
                                        }
                                    } else {
                                        if ((int32_t)var_a8h == 8) {
                                            puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                            if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                                uVar30 = *puVar31;
                                                *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                                uVar11 = (uint32_t)uVar30;
                                            } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                                uVar11 = 0;
                                            } else {
                                                func_0x000180069750(arg1);
                                                uVar30 = **(uint8_t **)(arg1 + 0xc0);
                                                *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                                uVar11 = (uint32_t)uVar30;
                                            }
                                        } else {
                                            uVar11 = func_0x000180069a30();
                                        }
                                        uVar33 = 0;
                                        if ((int32_t)uVar11 < var_d0h) {
                                            uVar33 = uVar11;
                                        }
                                        uVar27 = 0;
                                        if (uVar12 != 0) {
                                            do {
                                                *(undefined *)((int64_t)&var_d4h + uVar27) =
                                                     *(undefined *)
                                                      ((int32_t)((int32_t)uVar27 + uVar33 * uVar12) + iVar16);
                                                uVar11 = (int32_t)uVar27 + 1;
                                                uVar27 = (uint64_t)uVar11;
                                            } while ((int32_t)uVar11 < (int32_t)uVar12);
                                        }
                                    }
                                    bVar4 = false;
                                    iVar9 = (int32_t)var_b0h;
                                } else {
                                    if (iVar10 == 0) {
                                        puVar31 = *(uint8_t **)(arg1 + 0xc0);
                                        if (puVar31 < *(uint8_t **)(arg1 + 200)) {
                                            uVar36 = (uint32_t)*puVar31;
                                            *(uint8_t **)(arg1 + 0xc0) = puVar31 + 1;
                                        } else if (*(int32_t *)(arg1 + 0x30) == 0) {
                                            uVar36 = 0;
                                        } else {
                                            func_0x000180069750(arg1);
                                            uVar36 = (uint32_t)**(uint8_t **)(arg1 + 0xc0);
                                            *(uint8_t **)(arg1 + 0xc0) = *(uint8_t **)(arg1 + 0xc0) + 1;
                                        }
                                        iVar10 = (uVar36 & 0x7f) + 1;
                                        uVar36 = uVar36 >> 7;
                                        goto code_r0x000180068a7a;
                                    }
                                    if ((uVar36 == 0) || (bVar4)) goto code_r0x000180068a7a;
                                }
                                if (uVar12 != 0) {
                                    uVar27 = 0;
                                    do {
                                        iVar13 = (int32_t)uVar27;
                                        puVar29 = (undefined *)((int64_t)&var_d4h + uVar27);
                                        uVar11 = iVar13 + 1;
                                        uVar27 = (uint64_t)uVar11;
                                        puVar19[(int32_t)(uVar12 * (int32_t)var_cch + iVar13)] = *puVar29;
                                    } while ((int32_t)uVar11 < (int32_t)uVar12);
                                }
                                var_cch._0_4_ = (int32_t)var_cch + 1;
                                iVar10 = iVar10 + -1;
                                iVar16 = var_c0h;
                                uVar11 = var_cch._4_4_;
                            } while ((int32_t)var_cch < iVar9);
                        }
                        if (((int32_t)var_b8h != 0) && (iVar9 = 0, 0 < (int32_t)uVar11)) {
                            iVar10 = uVar12 * var_e0h._4_4_;
                            do {
                                iVar26 = iVar10 * iVar9;
                                iVar15 = ((uVar11 - iVar9) + -1) * iVar10;
                                for (iVar13 = iVar10; 0 < iVar13; iVar13 = iVar13 + -1) {
                                    uVar23 = puVar19[iVar26];
                                    puVar19[iVar26] = puVar19[iVar15];
                                    puVar19[iVar15] = uVar23;
                                    iVar26 = iVar26 + 1;
                                    iVar15 = iVar15 + 1;
                                }
                                iVar9 = iVar9 + 1;
                            } while (iVar9 * 2 < (int32_t)uVar11);
                        }
                        iVar9 = var_e0h._4_4_;
                        if (var_c0h != 0) {
                            func_0x000180460d90(var_c0h);
                            iVar9 = var_e0h._4_4_;
                        }
                    }
                    if ((2 < uVar12) && (var_e8h._4_4_ == 0)) {
                        iVar10 = 0;
                        if (0 < (int32_t)(iVar9 * uVar11)) {
                            puVar29 = puVar19;
                            do {
                                uVar23 = *puVar29;
                                iVar10 = iVar10 + 1;
                                *puVar29 = puVar29[2];
                                puVar29[2] = uVar23;
                                puVar29 = puVar29 + uVar12;
                            } while (iVar10 < (int32_t)(iVar9 * uVar11));
                        }
                    }
                    if (uVar12 != 4) {
                        var_f8h._0_4_ = uVar11;
                        func_0x000180069b10(puVar19, uVar12, 4, iVar9);
                    }
                } else {
                    if (((var_d0h != 0) && (func_0x000180069830(arg1), -1 < iVar10)) &&
                       (iVar10 <= (int32_t)(0x7fffffff / (uint64_t)uVar12))) {
                        iVar16 = func_0x00018046d050();
                        iVar9 = var_d0h;
                        var_c0h = iVar16;
                        if (iVar16 != 0) {
                            if (var_e8h._4_4_ == 0) {
                                iVar9 = func_0x000180069890();
                                if (iVar9 == 0) {
                                    func_0x000180460d90(puVar19);
                                    func_0x000180460d90(iVar16);
                                    goto code_r0x000180068d5b;
                                }
                            } else {
                                iVar10 = 0;
                                if (0 < var_d0h) {
                                    do {
                                        func_0x000180072ae0();
                                        iVar10 = iVar10 + 1;
                                        iVar16 = var_c0h;
                                        uVar11 = var_cch._4_4_;
                                    } while (iVar10 < iVar9);
                                }
                            }
                            goto code_r0x0001800689e1;
                        }
                    }
                    func_0x000180460d90(puVar19);
                }
                goto code_r0x000180068d5b;
            }
        }
    }
code_r0x000180068d3d:
    *(undefined8 *)(arg1 + 0xc0) = *(undefined8 *)(arg1 + 0xd0);
    *(undefined8 *)(arg1 + 200) = *(undefined8 *)(arg1 + 0xd8);
code_r0x000180068d5b:
    func_0x000180459870(var_70h ^ (uint64_t)auStack_118);
    return;
code_r0x0001800693c0:
    func_0x000180460d90(var_c0h);
    var_c0h = 0;
    var_f8h._0_4_ = var_d8h;
code_r0x0001800693d5:
    *(uint32_t *)var_b8h = var_e8h._4_4_;
    *(uint32_t *)var_b0h = (uint32_t)var_f8h;
    func_0x000180069b10(var_c0h, 4, 4);
    goto code_r0x000180068d5b;
}

// ============================================================
// Function: FUN_180069410
// Address: 0x180069410
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180069410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined auStack_888 [32];
    int64_t var_868h;
    int64_t var_858h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_888;
    var_868h._0_4_ = (uint32_t)arg3;
    uVar7 = 0;
    uVar8 = (int64_t)(int32_t)arg4 * (int64_t)(int32_t)arg2;
    iVar5 = (int32_t)(uint32_t)var_868h >> 1;
    if (0 < iVar5) {
        do {
            iVar3 = uVar7 * uVar8 + arg1;
            iVar1 = (int64_t)(((int32_t)arg3 - (int32_t)uVar7) + -1) * uVar8 + arg1;
            uVar2 = uVar8;
            if (uVar8 != 0) {
                do {
                    uVar4 = 0x800;
                    if (uVar2 < 0x800) {
                        uVar4 = uVar2;
                    }
                    func_0x000180498030(&var_858h, iVar3, uVar4);
                    func_0x000180498030(iVar3, iVar1, uVar4);
                    func_0x000180498030(iVar1, &var_858h, uVar4);
                    iVar3 = iVar3 + uVar4;
                    iVar1 = iVar1 + uVar4;
                    uVar2 = uVar2 - uVar4;
                } while (uVar2 != 0);
                arg3 = (int64_t)(uint32_t)var_868h;
            }
            uVar6 = (int32_t)uVar7 + 1;
            uVar7 = (uint64_t)uVar6;
        } while ((int32_t)uVar6 < iVar5);
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_888);
    return;
}

// ============================================================
// Function: FUN_180069458
// Address: 0x180069458
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180069410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined auStack_888 [32];
    int64_t var_868h;
    int64_t var_858h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_888;
    var_868h._0_4_ = (uint32_t)arg3;
    uVar7 = 0;
    uVar8 = (int64_t)(int32_t)arg4 * (int64_t)(int32_t)arg2;
    iVar5 = (int32_t)(uint32_t)var_868h >> 1;
    if (0 < iVar5) {
        do {
            iVar3 = uVar7 * uVar8 + arg1;
            iVar1 = (int64_t)(((int32_t)arg3 - (int32_t)uVar7) + -1) * uVar8 + arg1;
            uVar2 = uVar8;
            if (uVar8 != 0) {
                do {
                    uVar4 = 0x800;
                    if (uVar2 < 0x800) {
                        uVar4 = uVar2;
                    }
                    func_0x000180498030(&var_858h, iVar3, uVar4);
                    func_0x000180498030(iVar3, iVar1, uVar4);
                    func_0x000180498030(iVar1, &var_858h, uVar4);
                    iVar3 = iVar3 + uVar4;
                    iVar1 = iVar1 + uVar4;
                    uVar2 = uVar2 - uVar4;
                } while (uVar2 != 0);
                arg3 = (int64_t)(uint32_t)var_868h;
            }
            uVar6 = (int32_t)uVar7 + 1;
            uVar7 = (uint64_t)uVar6;
        } while ((int32_t)uVar6 < iVar5);
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_888);
    return;
}

// ============================================================
// Function: FUN_180069516
// Address: 0x180069516
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h

void fcn.180069410(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    uint64_t uVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int32_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    undefined auStack_888 [32];
    int64_t var_868h;
    int64_t var_858h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_888;
    var_868h._0_4_ = (uint32_t)arg3;
    uVar7 = 0;
    uVar8 = (int64_t)(int32_t)arg4 * (int64_t)(int32_t)arg2;
    iVar5 = (int32_t)(uint32_t)var_868h >> 1;
    if (0 < iVar5) {
        do {
            iVar3 = uVar7 * uVar8 + arg1;
            iVar1 = (int64_t)(((int32_t)arg3 - (int32_t)uVar7) + -1) * uVar8 + arg1;
            uVar2 = uVar8;
            if (uVar8 != 0) {
                do {
                    uVar4 = 0x800;
                    if (uVar2 < 0x800) {
                        uVar4 = uVar2;
                    }
                    func_0x000180498030(&var_858h, iVar3, uVar4);
                    func_0x000180498030(iVar3, iVar1, uVar4);
                    func_0x000180498030(iVar1, &var_858h, uVar4);
                    iVar3 = iVar3 + uVar4;
                    iVar1 = iVar1 + uVar4;
                    uVar2 = uVar2 - uVar4;
                } while (uVar2 != 0);
                arg3 = (int64_t)(uint32_t)var_868h;
            }
            uVar6 = (int32_t)uVar7 + 1;
            uVar7 = (uint64_t)uVar6;
        } while ((int32_t)uVar6 < iVar5);
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_888);
    return;
}

// ============================================================
// Function: FUN_180069540
// Address: 0x180069540
// Size: 69 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069585
// Address: 0x180069585
// Size: 313 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_1800696be
// Address: 0x1800696be
// Size: 50 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_1800696f0
// Address: 0x1800696f0
// Size: 34 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069712
// Address: 0x180069712
// Size: 56 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069750
// Address: 0x180069750
// Size: 116 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_1800697d0
// Address: 0x1800697d0
// Size: 89 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069890
// Address: 0x180069890
// Size: 191 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069950
// Address: 0x180069950
// Size: 162 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069a00
// Address: 0x180069a00
// Size: 44 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069a30
// Address: 0x180069a30
// Size: 162 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069ae0
// Address: 0x180069ae0
// Size: 44 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069b10
// Address: 0x180069b10
// Size: 40 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069b38
// Address: 0x180069b38
// Size: 116 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069bac
// Address: 0x180069bac
// Size: 873 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069f15
// Address: 0x180069f15
// Size: 20 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069f29
// Address: 0x180069f29
// Size: 20 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069f3d
// Address: 0x180069f3d
// Size: 119 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069fc0
// Address: 0x180069fc0
// Size: 37 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_180069fe5
// Address: 0x180069fe5
// Size: 50 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a017
// Address: 0x18006a017
// Size: 963 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a3da
// Address: 0x18006a3da
// Size: 126 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a460
// Address: 0x18006a460
// Size: 375 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a5e0
// Address: 0x18006a5e0
// Size: 342 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a740
// Address: 0x18006a740
// Size: 267 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a850
// Address: 0x18006a850
// Size: 120 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a8d0
// Address: 0x18006a8d0
// Size: 84 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006a930
// Address: 0x18006a930
// Size: 447 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006aaf0
// Address: 0x18006aaf0
// Size: 286 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006ac10
// Address: 0x18006ac10
// Size: 956 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006afd0
// Address: 0x18006afd0
// Size: 1599 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006b610
// Address: 0x18006b610
// Size: 2096 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006be40
// Address: 0x18006be40
// Size: 53 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006be75
// Address: 0x18006be75
// Size: 83 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006bec8
// Address: 0x18006bec8
// Size: 16 bytes
// ============================================================
// (decompilation failed)

// ============================================================
// Function: FUN_18006bee0
// Address: 0x18006bee0
// Size: 2089 bytes
// ============================================================
// (decompilation failed)

