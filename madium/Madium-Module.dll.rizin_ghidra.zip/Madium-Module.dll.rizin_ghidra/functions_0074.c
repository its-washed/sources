// Chunk 74 - 50 functions

// ============================================================
// Function: FUN_1800f6553
// Address: 0x1800f6553
// Size: 5 bytes
// ============================================================
void fcn.1800f6553(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t unaff_RBX;
    int32_t unaff_EBP;
    int32_t unaff_R15D;
    int64_t in_stack_00000038;
    
    fcn.18011f640(in_stack_00000038);
    fcn.180498030((int64_t)(unaff_R15D + -1) + *(int64_t *)(unaff_RBX + 8));
    *(undefined *)((int64_t)unaff_EBP + -1 + *(int64_t *)(unaff_RBX + 8)) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f6558
// Address: 0x1800f6558
// Size: 64 bytes
// ============================================================
void fcn.1800f6553(int64_t arg_40h, int64_t arg_50h, int64_t arg_58h)
{
    int64_t unaff_RBX;
    int32_t unaff_EBP;
    int32_t unaff_R15D;
    int64_t in_stack_00000038;
    
    fcn.18011f640(in_stack_00000038);
    fcn.180498030((int64_t)(unaff_R15D + -1) + *(int64_t *)(unaff_RBX + 8));
    *(undefined *)((int64_t)unaff_EBP + -1 + *(int64_t *)(unaff_RBX + 8)) = 0;
    return;
}

// ============================================================
// Function: FUN_1800f65a0
// Address: 0x1800f65a0
// Size: 19 bytes
// ============================================================
void fcn.1800f65a0(undefined8 placeholder_0, undefined8 placeholder_1, int64_t arg3, int64_t arg4)
{
    int64_t var_18h;
    int64_t var_20h;
    
    return;
}

// ============================================================
// Function: FUN_1800f65c0
// Address: 0x1800f65c0
// Size: 71 bytes
// ============================================================
void fcn.1800f65c0(int64_t arg1)
{
    undefined4 *puVar1;
    float in_XMM1_Da;
    int64_t var_18h;
    undefined4 uStack_10;
    int64_t var_ch;
    
    puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + 0xd90 + ((int64_t)(int32_t)arg1 + 0x14) * 0x10);
    var_18h._0_4_ = *puVar1;
    var_18h._4_4_ = puVar1[1];
    uStack_10 = puVar1[2];
    var_ch._0_4_ = (float)puVar1[3] * in_XMM1_Da * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    fcn.1800f5fa0(&var_18h);
    return;
}

// ============================================================
// Function: FUN_1800f6650
// Address: 0x1800f6650
// Size: 182 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.1800f6650(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined4 *puVar2;
    int64_t iVar3;
    int32_t iVar4;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    undefined4 uStack_38;
    
    iVar3 = *(int64_t *)0x180781f28;
    iVar4 = (int32_t)arg1;
    iVar1 = (int64_t)iVar4 + 0xed;
    puVar2 = (undefined4 *)(*(int64_t *)0x180781f28 + iVar1 * 0x10);
    var_48h._4_4_ = *puVar2;
    uStack_40 = puVar2[1];
    uStack_3c = puVar2[2];
    uStack_38 = puVar2[3];
    var_48h._0_4_ = iVar4;
    fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_48h);
    if (*(int32_t *)(iVar3 + 0x20bc) != iVar4) {
        *(float *)(iVar3 + iVar1 * 0x10) = (float)(arg2 & 0xff) * 0.003921569;
        *(float *)(iVar3 + 4 + iVar1 * 0x10) = (float)((arg2 & 0xffffffffU) >> 8 & 0xff) * 0.003921569;
        *(float *)(iVar3 + 8 + iVar1 * 0x10) = (float)((uint64_t)arg2 >> 0x10 & 0xff) * 0.003921569;
        *(float *)(iVar3 + 0xc + iVar1 * 0x10) = (float)((uint64_t)arg2 >> 0x18 & 0xff) * 0.003921569;
    }
    return;
}

// ============================================================
// Function: FUN_1800f6710
// Address: 0x1800f6710
// Size: 87 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_44h

void fcn.1800f6710(int64_t arg1, int64_t arg2)
{
    undefined4 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t var_48h;
    undefined4 uStack_40;
    undefined4 uStack_3c;
    undefined4 uStack_38;
    
    iVar5 = *(int64_t *)0x180781f28;
    iVar6 = (int32_t)arg1;
    puVar1 = (undefined4 *)(*(int64_t *)0x180781f28 + ((int64_t)iVar6 + 0xed) * 0x10);
    var_48h._4_4_ = *puVar1;
    uStack_40 = puVar1[1];
    uStack_3c = puVar1[2];
    uStack_38 = puVar1[3];
    var_48h._0_4_ = iVar6;
    fcn.18011f2b0(*(int64_t *)0x180781f28 + 0x20c0, &var_48h);
    if (*(int32_t *)(iVar5 + 0x20bc) != iVar6) {
        uVar2 = *(undefined4 *)(arg2 + 4);
        uVar3 = *(undefined4 *)(arg2 + 8);
        uVar4 = *(undefined4 *)(arg2 + 0xc);
        puVar1 = (undefined4 *)(iVar5 + ((int64_t)iVar6 + 0xed) * 0x10);
        *puVar1 = *(undefined4 *)arg2;
        puVar1[1] = uVar2;
        puVar1[2] = uVar3;
        puVar1[3] = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800f6770
// Address: 0x1800f6770
// Size: 148 bytes
// ============================================================
void fcn.1800f6770(int64_t arg1)
{
    undefined4 *puVar1;
    undefined4 *puVar2;
    undefined4 uVar3;
    undefined4 uVar4;
    undefined4 uVar5;
    int64_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    uint64_t uVar9;
    
    iVar6 = *(int64_t *)0x180781f28;
    uVar9 = arg1 & 0xffffffff;
    uVar7 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x20c0);
    if ((int32_t)uVar7 < (int32_t)arg1) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644230);
        }
        uVar7 = *(uint32_t *)(iVar6 + 0x20c0);
        uVar9 = (uint64_t)uVar7;
    }
    uVar8 = (uint32_t)uVar9;
    while (0 < (int32_t)uVar8) {
        uVar8 = (int32_t)uVar9 - 1;
        uVar9 = (uint64_t)uVar8;
        puVar2 = (undefined4 *)(*(int64_t *)(iVar6 + 0x20c8) + -0x10 + (int64_t)(int32_t)uVar7 * 0x14);
        uVar3 = puVar2[1];
        uVar4 = puVar2[2];
        uVar5 = puVar2[3];
        puVar1 = (undefined4 *)
                 (iVar6 + ((int64_t)*(int32_t *)(*(int64_t *)(iVar6 + 0x20c8) + -0x14 + (int64_t)(int32_t)uVar7 * 0x14)
                          + 0xed) * 0x10);
        *puVar1 = *puVar2;
        puVar1[1] = uVar3;
        puVar1[2] = uVar4;
        puVar1[3] = uVar5;
        uVar7 = *(int32_t *)(iVar6 + 0x20c0) - 1;
        *(uint32_t *)(iVar6 + 0x20c0) = uVar7;
    }
    return;
}

// ============================================================
// Function: FUN_1800f6810
// Address: 0x1800f6810
// Size: 45 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1800f6810(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_28h._0_4_ = (int32_t)arg1;
    if ((*(char *)((int64_t)(int32_t)var_28h * 4 + 0x180618f41) == '\b') &&
       (uVar1 = *(uint32_t *)((int64_t)(int32_t)var_28h * 4 + 0x180618f40), (char)uVar1 == '\x01')) {
        uVar3 = (uint64_t)(uVar1 >> 0x10);
        var_28h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
        fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_28h);
        *(undefined4 *)(uVar3 + 0xd90 + iVar2) = in_XMM1_Da;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f683d
// Address: 0x1800f683d
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1800f6810(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_28h._0_4_ = (int32_t)arg1;
    if ((*(char *)((int64_t)(int32_t)var_28h * 4 + 0x180618f41) == '\b') &&
       (uVar1 = *(uint32_t *)((int64_t)(int32_t)var_28h * 4 + 0x180618f40), (char)uVar1 == '\x01')) {
        uVar3 = (uint64_t)(uVar1 >> 0x10);
        var_28h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
        fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_28h);
        *(undefined4 *)(uVar3 + 0xd90 + iVar2) = in_XMM1_Da;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f6885
// Address: 0x1800f6885
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.1800f6810(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    int64_t var_28h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_28h._0_4_ = (int32_t)arg1;
    if ((*(char *)((int64_t)(int32_t)var_28h * 4 + 0x180618f41) == '\b') &&
       (uVar1 = *(uint32_t *)((int64_t)(int32_t)var_28h * 4 + 0x180618f40), (char)uVar1 == '\x01')) {
        uVar3 = (uint64_t)(uVar1 >> 0x10);
        var_28h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
        fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_28h);
        *(undefined4 *)(uVar3 + 0xd90 + iVar2) = in_XMM1_Da;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f68b0
// Address: 0x1800f68b0
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1800f68b0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    int64_t var_28h;
    undefined4 var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_28h._0_4_ = (int32_t)arg1;
    if ((*(char *)((int64_t)(int32_t)var_28h * 4 + 0x180618f41) == '\b') &&
       (uVar1 = *(uint32_t *)((int64_t)(int32_t)var_28h * 4 + 0x180618f40), (char)uVar1 == '\x02')) {
        uVar3 = (uint64_t)(uVar1 >> 0x10);
        var_28h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
        var_20h = *(undefined4 *)(uVar3 + 0xd94 + *(int64_t *)0x180781f28);
        fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_28h);
        *(undefined4 *)(uVar3 + 0xd90 + iVar2) = in_XMM1_Da;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f68de
// Address: 0x1800f68de
// Size: 87 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1800f68b0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    int64_t var_28h;
    undefined4 var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_28h._0_4_ = (int32_t)arg1;
    if ((*(char *)((int64_t)(int32_t)var_28h * 4 + 0x180618f41) == '\b') &&
       (uVar1 = *(uint32_t *)((int64_t)(int32_t)var_28h * 4 + 0x180618f40), (char)uVar1 == '\x02')) {
        uVar3 = (uint64_t)(uVar1 >> 0x10);
        var_28h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
        var_20h = *(undefined4 *)(uVar3 + 0xd94 + *(int64_t *)0x180781f28);
        fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_28h);
        *(undefined4 *)(uVar3 + 0xd90 + iVar2) = in_XMM1_Da;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f6935
// Address: 0x1800f6935
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_20h

void fcn.1800f68b0(int64_t arg1)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    undefined4 in_XMM1_Da;
    int64_t var_8h;
    int64_t var_28h;
    undefined4 var_20h;
    int64_t var_18h;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_28h._0_4_ = (int32_t)arg1;
    if ((*(char *)((int64_t)(int32_t)var_28h * 4 + 0x180618f41) == '\b') &&
       (uVar1 = *(uint32_t *)((int64_t)(int32_t)var_28h * 4 + 0x180618f40), (char)uVar1 == '\x02')) {
        uVar3 = (uint64_t)(uVar1 >> 0x10);
        var_28h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
        var_20h = *(undefined4 *)(uVar3 + 0xd94 + *(int64_t *)0x180781f28);
        fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_28h);
        *(undefined4 *)(uVar3 + 0xd90 + iVar2) = in_XMM1_Da;
        return;
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f6960
// Address: 0x1800f6960
// Size: 48 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f6960(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (int32_t)arg1;
    if (*(char *)((int64_t)(int32_t)var_18h * 4 + 0x180618f41) == '\b') {
        uVar1 = *(uint32_t *)((int64_t)(int32_t)var_18h * 4 + 0x180618f40);
        if ((char)uVar1 == '\x02') {
            uVar3 = (uint64_t)(uVar1 >> 0x10);
            var_18h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
            uStack_10 = *(undefined4 *)(uVar3 + 0xd94 + *(int64_t *)0x180781f28);
            fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_18h);
            *(undefined8 *)(uVar3 + 0xd90 + iVar2) = *(undefined8 *)arg2;
            return;
        }
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f6990
// Address: 0x1800f6990
// Size: 92 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f6960(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (int32_t)arg1;
    if (*(char *)((int64_t)(int32_t)var_18h * 4 + 0x180618f41) == '\b') {
        uVar1 = *(uint32_t *)((int64_t)(int32_t)var_18h * 4 + 0x180618f40);
        if ((char)uVar1 == '\x02') {
            uVar3 = (uint64_t)(uVar1 >> 0x10);
            var_18h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
            uStack_10 = *(undefined4 *)(uVar3 + 0xd94 + *(int64_t *)0x180781f28);
            fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_18h);
            *(undefined8 *)(uVar3 + 0xd90 + iVar2) = *(undefined8 *)arg2;
            return;
        }
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f69ec
// Address: 0x1800f69ec
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h

void fcn.1800f6960(int64_t arg1, int64_t arg2)
{
    uint32_t uVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined4 uStack_10;
    
    iVar2 = *(int64_t *)0x180781f28;
    var_18h._0_4_ = (int32_t)arg1;
    if (*(char *)((int64_t)(int32_t)var_18h * 4 + 0x180618f41) == '\b') {
        uVar1 = *(uint32_t *)((int64_t)(int32_t)var_18h * 4 + 0x180618f40);
        if ((char)uVar1 == '\x02') {
            uVar3 = (uint64_t)(uVar1 >> 0x10);
            var_18h._4_4_ = *(undefined4 *)(uVar3 + 0xd90 + *(int64_t *)0x180781f28);
            uStack_10 = *(undefined4 *)(uVar3 + 0xd94 + *(int64_t *)0x180781f28);
            fcn.18011f1f0(*(int64_t *)0x180781f28 + 0x20d0, &var_18h);
            *(undefined8 *)(uVar3 + 0xd90 + iVar2) = *(undefined8 *)arg2;
            return;
        }
    }
    if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
        (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                  (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644258);
    }
    return;
}

// ============================================================
// Function: FUN_1800f6a20
// Address: 0x1800f6a20
// Size: 643 bytes
// ============================================================
void fcn.1800f6a20(int64_t arg1)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint32_t uVar4;
    int64_t iVar5;
    int64_t iVar6;
    uint64_t uVar7;
    uint64_t uVar8;
    uint32_t uVar9;
    uint32_t uVar10;
    
    iVar3 = *(int64_t *)0x180781f28;
    uVar7 = arg1 & 0xffffffff;
    uVar4 = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x20d0);
    if ((int32_t)uVar4 < (int32_t)arg1) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644288);
        }
        uVar4 = *(uint32_t *)(iVar3 + 0x20d0);
        uVar7 = (uint64_t)uVar4;
    }
    uVar9 = (uint32_t)uVar7;
    while (uVar10 = (uint32_t)uVar7, 3 < (int32_t)uVar9) {
        iVar2 = *(int64_t *)(iVar3 + 0x20d8);
        iVar5 = (int64_t)(int32_t)uVar4;
        iVar6 = (int64_t)*(int32_t *)(iVar2 + -0xc + iVar5 * 0xc);
        if (*(char *)(iVar6 * 4 + 0x180618f41) == '\b') {
            uVar7 = (uint64_t)*(uint16_t *)(iVar6 * 4 + 0x180618f42);
            uVar4 = *(uint32_t *)(iVar6 * 4 + 0x180618f40) & 0xff;
            if (uVar4 == 1) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar2 + -8 + iVar5 * 0xc);
            } else if (uVar4 == 2) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar2 + -8 + iVar5 * 0xc);
                *(undefined4 *)(uVar7 + 0xd94 + iVar3) = *(undefined4 *)(iVar2 + -4 + iVar5 * 0xc);
            }
        }
        iVar1 = *(int32_t *)(iVar3 + 0x20d0);
        *(int32_t *)(iVar3 + 0x20d0) = iVar1 + -1;
        iVar2 = (int64_t)iVar1 + -2;
        iVar5 = *(int64_t *)(iVar3 + 0x20d8);
        iVar6 = (int64_t)*(int32_t *)(iVar5 + iVar2 * 0xc);
        if (*(char *)(iVar6 * 4 + 0x180618f41) == '\b') {
            uVar7 = (uint64_t)*(uint16_t *)(iVar6 * 4 + 0x180618f42);
            uVar4 = *(uint32_t *)(iVar6 * 4 + 0x180618f40) & 0xff;
            if (uVar4 == 1) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar5 + 4 + iVar2 * 0xc);
            } else if (uVar4 == 2) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar5 + 4 + iVar2 * 0xc);
                *(undefined4 *)(uVar7 + 0xd94 + iVar3) = *(undefined4 *)(iVar5 + 8 + iVar2 * 0xc);
            }
        }
        iVar1 = *(int32_t *)(iVar3 + 0x20d0);
        *(int32_t *)(iVar3 + 0x20d0) = iVar1 + -1;
        iVar2 = (int64_t)iVar1 + -2;
        iVar5 = *(int64_t *)(iVar3 + 0x20d8);
        iVar6 = (int64_t)*(int32_t *)(iVar5 + iVar2 * 0xc);
        if (*(char *)(iVar6 * 4 + 0x180618f41) == '\b') {
            uVar7 = (uint64_t)*(uint16_t *)(iVar6 * 4 + 0x180618f42);
            uVar4 = *(uint32_t *)(iVar6 * 4 + 0x180618f40) & 0xff;
            if (uVar4 == 1) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar5 + 4 + iVar2 * 0xc);
            } else if (uVar4 == 2) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar5 + 4 + iVar2 * 0xc);
                *(undefined4 *)(uVar7 + 0xd94 + iVar3) = *(undefined4 *)(iVar5 + 8 + iVar2 * 0xc);
            }
        }
        iVar1 = *(int32_t *)(iVar3 + 0x20d0);
        *(int32_t *)(iVar3 + 0x20d0) = iVar1 + -1;
        iVar2 = (int64_t)iVar1 + -2;
        iVar5 = *(int64_t *)(iVar3 + 0x20d8);
        iVar6 = (int64_t)*(int32_t *)(iVar5 + iVar2 * 0xc);
        if (*(char *)(iVar6 * 4 + 0x180618f41) == '\b') {
            uVar7 = (uint64_t)*(uint16_t *)(iVar6 * 4 + 0x180618f42);
            uVar4 = *(uint32_t *)(iVar6 * 4 + 0x180618f40) & 0xff;
            if (uVar4 == 1) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar5 + 4 + iVar2 * 0xc);
            } else if (uVar4 == 2) {
                *(undefined4 *)(uVar7 + 0xd90 + iVar3) = *(undefined4 *)(iVar5 + 4 + iVar2 * 0xc);
                *(undefined4 *)(uVar7 + 0xd94 + iVar3) = *(undefined4 *)(iVar5 + 8 + iVar2 * 0xc);
            }
        }
        uVar9 = uVar10 - 4;
        uVar7 = (uint64_t)uVar9;
        uVar4 = *(int32_t *)(iVar3 + 0x20d0) - 1;
        *(uint32_t *)(iVar3 + 0x20d0) = uVar4;
    }
    while (0 < (int32_t)uVar10) {
        iVar2 = *(int64_t *)(iVar3 + 0x20d8);
        iVar5 = (int64_t)(int32_t)uVar4;
        iVar6 = (int64_t)*(int32_t *)(iVar2 + -0xc + iVar5 * 0xc);
        if (*(char *)(iVar6 * 4 + 0x180618f41) == '\b') {
            uVar8 = (uint64_t)*(uint16_t *)(iVar6 * 4 + 0x180618f42);
            uVar4 = *(uint32_t *)(iVar6 * 4 + 0x180618f40) & 0xff;
            if (uVar4 == 1) {
                *(undefined4 *)(uVar8 + 0xd90 + iVar3) = *(undefined4 *)(iVar2 + -8 + iVar5 * 0xc);
            } else if (uVar4 == 2) {
                *(undefined4 *)(uVar8 + 0xd90 + iVar3) = *(undefined4 *)(iVar2 + -8 + iVar5 * 0xc);
                *(undefined4 *)(uVar8 + 0xd94 + iVar3) = *(undefined4 *)(iVar2 + -4 + iVar5 * 0xc);
            }
        }
        uVar10 = (int32_t)uVar7 - 1;
        uVar7 = (uint64_t)uVar10;
        uVar4 = *(int32_t *)(iVar3 + 0x20d0) - 1;
        *(uint32_t *)(iVar3 + 0x20d0) = uVar4;
    }
    return;
}

// ============================================================
// Function: FUN_1800f6cb0
// Address: 0x1800f6cb0
// Size: 107 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel

void fcn.1800f6cb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    float fVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *pcVar12;
    int64_t iVar13;
    char in_R9B;
    float fVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    int64_t var_24h;
    
    pcVar12 = (char *)arg2;
    var_38h = arg1;
    if (in_R9B == '\0') {
        pcVar12 = (char *)arg3;
        if (arg3 == 0) {
            iVar9 = func_0x000180498cd0(arg2);
            pcVar12 = (char *)(iVar9 + arg2);
        }
    } else {
        pcVar11 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar11 = (char *)arg3;
        }
        if ((uint64_t)arg2 < pcVar11) {
            while (*pcVar12 != '\0') {
                pcVar8 = pcVar12 + 1;
                if (((*pcVar12 == '#') && (*pcVar8 == '#')) || (pcVar12 = pcVar8, pcVar11 <= pcVar8)) break;
            }
        }
    }
    iVar9 = *(int64_t *)0x180781f28;
    if ((char *)arg2 != pcVar12) {
        var_30h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        var_30h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        var_24h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = fcn.1800f5fa0(&var_30h);
        iVar13 = iVar9;
        if (((uVar5 & 0xff000000) != 0) && (*(char *)arg2 != '\0')) {
            iVar13 = *(int64_t *)(iVar9 + 0x12e8);
            fVar14 = *(float *)(iVar9 + 0x12f8);
            iVar3 = *(int64_t *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(*(int64_t *)(iVar3 + 0x38) + 0x18);
            }
            if (fVar14 == 0.0) {
                fVar14 = *(float *)(*(int64_t *)(iVar3 + 0x38) + 0x20);
            }
            var_30h._0_4_ = *(undefined4 *)(iVar3 + 0x60);
            var_30h._4_4_ = *(undefined4 *)(iVar3 + 100);
            uStack_28 = *(undefined4 *)(iVar3 + 0x68);
            var_24h._0_4_ = *(float *)(iVar3 + 0x6c);
            var_68h = (int64_t)uVar5;
            func_0x00018012f9d0(iVar13, iVar3, fVar14, &var_38h, var_68h, &var_30h, arg2, pcVar12, 0, 0);
            iVar13 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(iVar9 + 0x29f8) != '\0') {
            iVar9 = *(int64_t *)(iVar13 + 0x2a20);
            iVar3 = *(int64_t *)(iVar13 + 0x15e0);
            iVar4 = *(int64_t *)(iVar13 + 0x2a28);
            *(undefined8 *)(iVar13 + 0x2a28) = 0;
            *(undefined8 *)(iVar13 + 0x2a20) = 0;
            if ((pcVar12 == (char *)0x0) && (pcVar12 = (char *)arg2, arg2 != -1)) {
                while (*pcVar12 != '\0') {
                    pcVar11 = pcVar12 + 1;
                    if (((*pcVar12 == '#') && (*pcVar11 == '#')) ||
                       (pcVar12 = pcVar11, pcVar11 == (char *)0xffffffffffffffff)) break;
                }
            }
            fVar14 = *(float *)(iVar13 + 0xde0);
            if (*(float *)(iVar13 + 0xde0) <= *(float *)(iVar13 + 0xdf0)) {
                fVar14 = *(float *)(iVar13 + 0xdf0);
            }
            fVar1 = *(float *)(iVar13 + 0x2a30);
            *(float *)(iVar13 + 0x2a30) = var_38h._4_4_;
            if (fVar14 + fVar1 + 1.0 < var_38h._4_4_) {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar13 + 0x29f9) = 1;
            }
            if (iVar9 != 0) {
                iVar7 = func_0x000180498cd0(iVar9);
                func_0x000180112520(&var_38h, iVar9, iVar7 + iVar9);
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            iVar6 = *(int32_t *)(iVar13 + 0x2a34);
            if (iVar2 < iVar6) {
                *(int32_t *)(iVar13 + 0x2a34) = iVar2;
                iVar6 = iVar2;
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            while( true ) {
                pcVar8 = (char *)func_0x000180498a80(arg2, 10, (int64_t)pcVar12 - arg2);
                pcVar11 = pcVar12;
                if (pcVar8 != (char *)0x0) {
                    pcVar11 = pcVar8;
                }
                if (((char *)arg2 == pcVar11) && (pcVar11 == pcVar12)) break;
                iVar10 = (iVar2 - iVar6) * 4;
                if (*(char *)(iVar13 + 0x29f9) == '\0') {
                    iVar10 = 1;
                }
                func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg2, arg2);
                *(undefined *)(iVar13 + 0x29f9) = 0;
                if (*pcVar11 == '\n') {
                    func_0x0001801124e0(0x180644f68);
                    *(undefined *)(iVar13 + 0x29f9) = 1;
                }
                if (pcVar11 == pcVar12) break;
                arg2 = (int64_t)(pcVar11 + 1);
            }
            if (iVar4 != 0) {
                iVar9 = func_0x000180498cd0(iVar4);
                func_0x000180112520(&var_38h, iVar4, iVar9 + iVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f6d1b
// Address: 0x1800f6d1b
// Size: 238 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel

void fcn.1800f6cb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    float fVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *pcVar12;
    int64_t iVar13;
    char in_R9B;
    float fVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    int64_t var_24h;
    
    pcVar12 = (char *)arg2;
    var_38h = arg1;
    if (in_R9B == '\0') {
        pcVar12 = (char *)arg3;
        if (arg3 == 0) {
            iVar9 = func_0x000180498cd0(arg2);
            pcVar12 = (char *)(iVar9 + arg2);
        }
    } else {
        pcVar11 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar11 = (char *)arg3;
        }
        if ((uint64_t)arg2 < pcVar11) {
            while (*pcVar12 != '\0') {
                pcVar8 = pcVar12 + 1;
                if (((*pcVar12 == '#') && (*pcVar8 == '#')) || (pcVar12 = pcVar8, pcVar11 <= pcVar8)) break;
            }
        }
    }
    iVar9 = *(int64_t *)0x180781f28;
    if ((char *)arg2 != pcVar12) {
        var_30h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        var_30h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        var_24h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = fcn.1800f5fa0(&var_30h);
        iVar13 = iVar9;
        if (((uVar5 & 0xff000000) != 0) && (*(char *)arg2 != '\0')) {
            iVar13 = *(int64_t *)(iVar9 + 0x12e8);
            fVar14 = *(float *)(iVar9 + 0x12f8);
            iVar3 = *(int64_t *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(*(int64_t *)(iVar3 + 0x38) + 0x18);
            }
            if (fVar14 == 0.0) {
                fVar14 = *(float *)(*(int64_t *)(iVar3 + 0x38) + 0x20);
            }
            var_30h._0_4_ = *(undefined4 *)(iVar3 + 0x60);
            var_30h._4_4_ = *(undefined4 *)(iVar3 + 100);
            uStack_28 = *(undefined4 *)(iVar3 + 0x68);
            var_24h._0_4_ = *(float *)(iVar3 + 0x6c);
            var_68h = (int64_t)uVar5;
            func_0x00018012f9d0(iVar13, iVar3, fVar14, &var_38h, var_68h, &var_30h, arg2, pcVar12, 0, 0);
            iVar13 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(iVar9 + 0x29f8) != '\0') {
            iVar9 = *(int64_t *)(iVar13 + 0x2a20);
            iVar3 = *(int64_t *)(iVar13 + 0x15e0);
            iVar4 = *(int64_t *)(iVar13 + 0x2a28);
            *(undefined8 *)(iVar13 + 0x2a28) = 0;
            *(undefined8 *)(iVar13 + 0x2a20) = 0;
            if ((pcVar12 == (char *)0x0) && (pcVar12 = (char *)arg2, arg2 != -1)) {
                while (*pcVar12 != '\0') {
                    pcVar11 = pcVar12 + 1;
                    if (((*pcVar12 == '#') && (*pcVar11 == '#')) ||
                       (pcVar12 = pcVar11, pcVar11 == (char *)0xffffffffffffffff)) break;
                }
            }
            fVar14 = *(float *)(iVar13 + 0xde0);
            if (*(float *)(iVar13 + 0xde0) <= *(float *)(iVar13 + 0xdf0)) {
                fVar14 = *(float *)(iVar13 + 0xdf0);
            }
            fVar1 = *(float *)(iVar13 + 0x2a30);
            *(float *)(iVar13 + 0x2a30) = var_38h._4_4_;
            if (fVar14 + fVar1 + 1.0 < var_38h._4_4_) {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar13 + 0x29f9) = 1;
            }
            if (iVar9 != 0) {
                iVar7 = func_0x000180498cd0(iVar9);
                func_0x000180112520(&var_38h, iVar9, iVar7 + iVar9);
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            iVar6 = *(int32_t *)(iVar13 + 0x2a34);
            if (iVar2 < iVar6) {
                *(int32_t *)(iVar13 + 0x2a34) = iVar2;
                iVar6 = iVar2;
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            while( true ) {
                pcVar8 = (char *)func_0x000180498a80(arg2, 10, (int64_t)pcVar12 - arg2);
                pcVar11 = pcVar12;
                if (pcVar8 != (char *)0x0) {
                    pcVar11 = pcVar8;
                }
                if (((char *)arg2 == pcVar11) && (pcVar11 == pcVar12)) break;
                iVar10 = (iVar2 - iVar6) * 4;
                if (*(char *)(iVar13 + 0x29f9) == '\0') {
                    iVar10 = 1;
                }
                func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg2, arg2);
                *(undefined *)(iVar13 + 0x29f9) = 0;
                if (*pcVar11 == '\n') {
                    func_0x0001801124e0(0x180644f68);
                    *(undefined *)(iVar13 + 0x29f9) = 1;
                }
                if (pcVar11 == pcVar12) break;
                arg2 = (int64_t)(pcVar11 + 1);
            }
            if (iVar4 != 0) {
                iVar9 = func_0x000180498cd0(iVar4);
                func_0x000180112520(&var_38h, iVar4, iVar9 + iVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f6e09
// Address: 0x1800f6e09
// Size: 380 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel

void fcn.1800f6cb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    float fVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *pcVar12;
    int64_t iVar13;
    char in_R9B;
    float fVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    int64_t var_24h;
    
    pcVar12 = (char *)arg2;
    var_38h = arg1;
    if (in_R9B == '\0') {
        pcVar12 = (char *)arg3;
        if (arg3 == 0) {
            iVar9 = func_0x000180498cd0(arg2);
            pcVar12 = (char *)(iVar9 + arg2);
        }
    } else {
        pcVar11 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar11 = (char *)arg3;
        }
        if ((uint64_t)arg2 < pcVar11) {
            while (*pcVar12 != '\0') {
                pcVar8 = pcVar12 + 1;
                if (((*pcVar12 == '#') && (*pcVar8 == '#')) || (pcVar12 = pcVar8, pcVar11 <= pcVar8)) break;
            }
        }
    }
    iVar9 = *(int64_t *)0x180781f28;
    if ((char *)arg2 != pcVar12) {
        var_30h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        var_30h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        var_24h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = fcn.1800f5fa0(&var_30h);
        iVar13 = iVar9;
        if (((uVar5 & 0xff000000) != 0) && (*(char *)arg2 != '\0')) {
            iVar13 = *(int64_t *)(iVar9 + 0x12e8);
            fVar14 = *(float *)(iVar9 + 0x12f8);
            iVar3 = *(int64_t *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(*(int64_t *)(iVar3 + 0x38) + 0x18);
            }
            if (fVar14 == 0.0) {
                fVar14 = *(float *)(*(int64_t *)(iVar3 + 0x38) + 0x20);
            }
            var_30h._0_4_ = *(undefined4 *)(iVar3 + 0x60);
            var_30h._4_4_ = *(undefined4 *)(iVar3 + 100);
            uStack_28 = *(undefined4 *)(iVar3 + 0x68);
            var_24h._0_4_ = *(float *)(iVar3 + 0x6c);
            var_68h = (int64_t)uVar5;
            func_0x00018012f9d0(iVar13, iVar3, fVar14, &var_38h, var_68h, &var_30h, arg2, pcVar12, 0, 0);
            iVar13 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(iVar9 + 0x29f8) != '\0') {
            iVar9 = *(int64_t *)(iVar13 + 0x2a20);
            iVar3 = *(int64_t *)(iVar13 + 0x15e0);
            iVar4 = *(int64_t *)(iVar13 + 0x2a28);
            *(undefined8 *)(iVar13 + 0x2a28) = 0;
            *(undefined8 *)(iVar13 + 0x2a20) = 0;
            if ((pcVar12 == (char *)0x0) && (pcVar12 = (char *)arg2, arg2 != -1)) {
                while (*pcVar12 != '\0') {
                    pcVar11 = pcVar12 + 1;
                    if (((*pcVar12 == '#') && (*pcVar11 == '#')) ||
                       (pcVar12 = pcVar11, pcVar11 == (char *)0xffffffffffffffff)) break;
                }
            }
            fVar14 = *(float *)(iVar13 + 0xde0);
            if (*(float *)(iVar13 + 0xde0) <= *(float *)(iVar13 + 0xdf0)) {
                fVar14 = *(float *)(iVar13 + 0xdf0);
            }
            fVar1 = *(float *)(iVar13 + 0x2a30);
            *(float *)(iVar13 + 0x2a30) = var_38h._4_4_;
            if (fVar14 + fVar1 + 1.0 < var_38h._4_4_) {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar13 + 0x29f9) = 1;
            }
            if (iVar9 != 0) {
                iVar7 = func_0x000180498cd0(iVar9);
                func_0x000180112520(&var_38h, iVar9, iVar7 + iVar9);
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            iVar6 = *(int32_t *)(iVar13 + 0x2a34);
            if (iVar2 < iVar6) {
                *(int32_t *)(iVar13 + 0x2a34) = iVar2;
                iVar6 = iVar2;
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            while( true ) {
                pcVar8 = (char *)func_0x000180498a80(arg2, 10, (int64_t)pcVar12 - arg2);
                pcVar11 = pcVar12;
                if (pcVar8 != (char *)0x0) {
                    pcVar11 = pcVar8;
                }
                if (((char *)arg2 == pcVar11) && (pcVar11 == pcVar12)) break;
                iVar10 = (iVar2 - iVar6) * 4;
                if (*(char *)(iVar13 + 0x29f9) == '\0') {
                    iVar10 = 1;
                }
                func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg2, arg2);
                *(undefined *)(iVar13 + 0x29f9) = 0;
                if (*pcVar11 == '\n') {
                    func_0x0001801124e0(0x180644f68);
                    *(undefined *)(iVar13 + 0x29f9) = 1;
                }
                if (pcVar11 == pcVar12) break;
                arg2 = (int64_t)(pcVar11 + 1);
            }
            if (iVar4 != 0) {
                iVar9 = func_0x000180498cd0(iVar4);
                func_0x000180112520(&var_38h, iVar4, iVar9 + iVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f6f85
// Address: 0x1800f6f85
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel

void fcn.1800f6cb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    float fVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *pcVar12;
    int64_t iVar13;
    char in_R9B;
    float fVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    int64_t var_24h;
    
    pcVar12 = (char *)arg2;
    var_38h = arg1;
    if (in_R9B == '\0') {
        pcVar12 = (char *)arg3;
        if (arg3 == 0) {
            iVar9 = func_0x000180498cd0(arg2);
            pcVar12 = (char *)(iVar9 + arg2);
        }
    } else {
        pcVar11 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar11 = (char *)arg3;
        }
        if ((uint64_t)arg2 < pcVar11) {
            while (*pcVar12 != '\0') {
                pcVar8 = pcVar12 + 1;
                if (((*pcVar12 == '#') && (*pcVar8 == '#')) || (pcVar12 = pcVar8, pcVar11 <= pcVar8)) break;
            }
        }
    }
    iVar9 = *(int64_t *)0x180781f28;
    if ((char *)arg2 != pcVar12) {
        var_30h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        var_30h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        var_24h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = fcn.1800f5fa0(&var_30h);
        iVar13 = iVar9;
        if (((uVar5 & 0xff000000) != 0) && (*(char *)arg2 != '\0')) {
            iVar13 = *(int64_t *)(iVar9 + 0x12e8);
            fVar14 = *(float *)(iVar9 + 0x12f8);
            iVar3 = *(int64_t *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(*(int64_t *)(iVar3 + 0x38) + 0x18);
            }
            if (fVar14 == 0.0) {
                fVar14 = *(float *)(*(int64_t *)(iVar3 + 0x38) + 0x20);
            }
            var_30h._0_4_ = *(undefined4 *)(iVar3 + 0x60);
            var_30h._4_4_ = *(undefined4 *)(iVar3 + 100);
            uStack_28 = *(undefined4 *)(iVar3 + 0x68);
            var_24h._0_4_ = *(float *)(iVar3 + 0x6c);
            var_68h = (int64_t)uVar5;
            func_0x00018012f9d0(iVar13, iVar3, fVar14, &var_38h, var_68h, &var_30h, arg2, pcVar12, 0, 0);
            iVar13 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(iVar9 + 0x29f8) != '\0') {
            iVar9 = *(int64_t *)(iVar13 + 0x2a20);
            iVar3 = *(int64_t *)(iVar13 + 0x15e0);
            iVar4 = *(int64_t *)(iVar13 + 0x2a28);
            *(undefined8 *)(iVar13 + 0x2a28) = 0;
            *(undefined8 *)(iVar13 + 0x2a20) = 0;
            if ((pcVar12 == (char *)0x0) && (pcVar12 = (char *)arg2, arg2 != -1)) {
                while (*pcVar12 != '\0') {
                    pcVar11 = pcVar12 + 1;
                    if (((*pcVar12 == '#') && (*pcVar11 == '#')) ||
                       (pcVar12 = pcVar11, pcVar11 == (char *)0xffffffffffffffff)) break;
                }
            }
            fVar14 = *(float *)(iVar13 + 0xde0);
            if (*(float *)(iVar13 + 0xde0) <= *(float *)(iVar13 + 0xdf0)) {
                fVar14 = *(float *)(iVar13 + 0xdf0);
            }
            fVar1 = *(float *)(iVar13 + 0x2a30);
            *(float *)(iVar13 + 0x2a30) = var_38h._4_4_;
            if (fVar14 + fVar1 + 1.0 < var_38h._4_4_) {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar13 + 0x29f9) = 1;
            }
            if (iVar9 != 0) {
                iVar7 = func_0x000180498cd0(iVar9);
                func_0x000180112520(&var_38h, iVar9, iVar7 + iVar9);
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            iVar6 = *(int32_t *)(iVar13 + 0x2a34);
            if (iVar2 < iVar6) {
                *(int32_t *)(iVar13 + 0x2a34) = iVar2;
                iVar6 = iVar2;
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            while( true ) {
                pcVar8 = (char *)func_0x000180498a80(arg2, 10, (int64_t)pcVar12 - arg2);
                pcVar11 = pcVar12;
                if (pcVar8 != (char *)0x0) {
                    pcVar11 = pcVar8;
                }
                if (((char *)arg2 == pcVar11) && (pcVar11 == pcVar12)) break;
                iVar10 = (iVar2 - iVar6) * 4;
                if (*(char *)(iVar13 + 0x29f9) == '\0') {
                    iVar10 = 1;
                }
                func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg2, arg2);
                *(undefined *)(iVar13 + 0x29f9) = 0;
                if (*pcVar11 == '\n') {
                    func_0x0001801124e0(0x180644f68);
                    *(undefined *)(iVar13 + 0x29f9) = 1;
                }
                if (pcVar11 == pcVar12) break;
                arg2 = (int64_t)(pcVar11 + 1);
            }
            if (iVar4 != 0) {
                iVar9 = func_0x000180498cd0(iVar4);
                func_0x000180112520(&var_38h, iVar4, iVar9 + iVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f6fa3
// Address: 0x1800f6fa3
// Size: 16 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel

void fcn.1800f6cb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    float fVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *pcVar12;
    int64_t iVar13;
    char in_R9B;
    float fVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    int64_t var_24h;
    
    pcVar12 = (char *)arg2;
    var_38h = arg1;
    if (in_R9B == '\0') {
        pcVar12 = (char *)arg3;
        if (arg3 == 0) {
            iVar9 = func_0x000180498cd0(arg2);
            pcVar12 = (char *)(iVar9 + arg2);
        }
    } else {
        pcVar11 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar11 = (char *)arg3;
        }
        if ((uint64_t)arg2 < pcVar11) {
            while (*pcVar12 != '\0') {
                pcVar8 = pcVar12 + 1;
                if (((*pcVar12 == '#') && (*pcVar8 == '#')) || (pcVar12 = pcVar8, pcVar11 <= pcVar8)) break;
            }
        }
    }
    iVar9 = *(int64_t *)0x180781f28;
    if ((char *)arg2 != pcVar12) {
        var_30h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        var_30h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        var_24h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = fcn.1800f5fa0(&var_30h);
        iVar13 = iVar9;
        if (((uVar5 & 0xff000000) != 0) && (*(char *)arg2 != '\0')) {
            iVar13 = *(int64_t *)(iVar9 + 0x12e8);
            fVar14 = *(float *)(iVar9 + 0x12f8);
            iVar3 = *(int64_t *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(*(int64_t *)(iVar3 + 0x38) + 0x18);
            }
            if (fVar14 == 0.0) {
                fVar14 = *(float *)(*(int64_t *)(iVar3 + 0x38) + 0x20);
            }
            var_30h._0_4_ = *(undefined4 *)(iVar3 + 0x60);
            var_30h._4_4_ = *(undefined4 *)(iVar3 + 100);
            uStack_28 = *(undefined4 *)(iVar3 + 0x68);
            var_24h._0_4_ = *(float *)(iVar3 + 0x6c);
            var_68h = (int64_t)uVar5;
            func_0x00018012f9d0(iVar13, iVar3, fVar14, &var_38h, var_68h, &var_30h, arg2, pcVar12, 0, 0);
            iVar13 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(iVar9 + 0x29f8) != '\0') {
            iVar9 = *(int64_t *)(iVar13 + 0x2a20);
            iVar3 = *(int64_t *)(iVar13 + 0x15e0);
            iVar4 = *(int64_t *)(iVar13 + 0x2a28);
            *(undefined8 *)(iVar13 + 0x2a28) = 0;
            *(undefined8 *)(iVar13 + 0x2a20) = 0;
            if ((pcVar12 == (char *)0x0) && (pcVar12 = (char *)arg2, arg2 != -1)) {
                while (*pcVar12 != '\0') {
                    pcVar11 = pcVar12 + 1;
                    if (((*pcVar12 == '#') && (*pcVar11 == '#')) ||
                       (pcVar12 = pcVar11, pcVar11 == (char *)0xffffffffffffffff)) break;
                }
            }
            fVar14 = *(float *)(iVar13 + 0xde0);
            if (*(float *)(iVar13 + 0xde0) <= *(float *)(iVar13 + 0xdf0)) {
                fVar14 = *(float *)(iVar13 + 0xdf0);
            }
            fVar1 = *(float *)(iVar13 + 0x2a30);
            *(float *)(iVar13 + 0x2a30) = var_38h._4_4_;
            if (fVar14 + fVar1 + 1.0 < var_38h._4_4_) {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar13 + 0x29f9) = 1;
            }
            if (iVar9 != 0) {
                iVar7 = func_0x000180498cd0(iVar9);
                func_0x000180112520(&var_38h, iVar9, iVar7 + iVar9);
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            iVar6 = *(int32_t *)(iVar13 + 0x2a34);
            if (iVar2 < iVar6) {
                *(int32_t *)(iVar13 + 0x2a34) = iVar2;
                iVar6 = iVar2;
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            while( true ) {
                pcVar8 = (char *)func_0x000180498a80(arg2, 10, (int64_t)pcVar12 - arg2);
                pcVar11 = pcVar12;
                if (pcVar8 != (char *)0x0) {
                    pcVar11 = pcVar8;
                }
                if (((char *)arg2 == pcVar11) && (pcVar11 == pcVar12)) break;
                iVar10 = (iVar2 - iVar6) * 4;
                if (*(char *)(iVar13 + 0x29f9) == '\0') {
                    iVar10 = 1;
                }
                func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg2, arg2);
                *(undefined *)(iVar13 + 0x29f9) = 0;
                if (*pcVar11 == '\n') {
                    func_0x0001801124e0(0x180644f68);
                    *(undefined *)(iVar13 + 0x29f9) = 1;
                }
                if (pcVar11 == pcVar12) break;
                arg2 = (int64_t)(pcVar11 + 1);
            }
            if (iVar4 != 0) {
                iVar9 = func_0x000180498cd0(iVar4);
                func_0x000180112520(&var_38h, iVar4, iVar9 + iVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f6fb3
// Address: 0x1800f6fb3
// Size: 7 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: Variable defined which should be unmapped: var_60h
// WARNING: Variable defined which should be unmapped: var_58h
// WARNING: Variable defined which should be unmapped: var_50h
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_ed0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_d9ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2998h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1558h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Removing arg arg_d58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29a8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_29ach because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2971h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1260h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_1270h because it doesn't fit into ProtoModel

void fcn.1800f6cb0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    float fVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *pcVar12;
    int64_t iVar13;
    char in_R9B;
    float fVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    undefined4 uStack_28;
    int64_t var_24h;
    
    pcVar12 = (char *)arg2;
    var_38h = arg1;
    if (in_R9B == '\0') {
        pcVar12 = (char *)arg3;
        if (arg3 == 0) {
            iVar9 = func_0x000180498cd0(arg2);
            pcVar12 = (char *)(iVar9 + arg2);
        }
    } else {
        pcVar11 = (char *)0xffffffffffffffff;
        if (arg3 != 0) {
            pcVar11 = (char *)arg3;
        }
        if ((uint64_t)arg2 < pcVar11) {
            while (*pcVar12 != '\0') {
                pcVar8 = pcVar12 + 1;
                if (((*pcVar12 == '#') && (*pcVar8 == '#')) || (pcVar12 = pcVar8, pcVar11 <= pcVar8)) break;
            }
        }
    }
    iVar9 = *(int64_t *)0x180781f28;
    if ((char *)arg2 != pcVar12) {
        var_30h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        var_30h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_28 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        var_24h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar5 = fcn.1800f5fa0(&var_30h);
        iVar13 = iVar9;
        if (((uVar5 & 0xff000000) != 0) && (*(char *)arg2 != '\0')) {
            iVar13 = *(int64_t *)(iVar9 + 0x12e8);
            fVar14 = *(float *)(iVar9 + 0x12f8);
            iVar3 = *(int64_t *)(*(int64_t *)(iVar9 + 0x15e0) + 800);
            if (iVar13 == 0) {
                iVar13 = *(int64_t *)(*(int64_t *)(iVar3 + 0x38) + 0x18);
            }
            if (fVar14 == 0.0) {
                fVar14 = *(float *)(*(int64_t *)(iVar3 + 0x38) + 0x20);
            }
            var_30h._0_4_ = *(undefined4 *)(iVar3 + 0x60);
            var_30h._4_4_ = *(undefined4 *)(iVar3 + 100);
            uStack_28 = *(undefined4 *)(iVar3 + 0x68);
            var_24h._0_4_ = *(float *)(iVar3 + 0x6c);
            var_68h = (int64_t)uVar5;
            func_0x00018012f9d0(iVar13, iVar3, fVar14, &var_38h, var_68h, &var_30h, arg2, pcVar12, 0, 0);
            iVar13 = *(int64_t *)0x180781f28;
        }
        if (*(char *)(iVar9 + 0x29f8) != '\0') {
            iVar9 = *(int64_t *)(iVar13 + 0x2a20);
            iVar3 = *(int64_t *)(iVar13 + 0x15e0);
            iVar4 = *(int64_t *)(iVar13 + 0x2a28);
            *(undefined8 *)(iVar13 + 0x2a28) = 0;
            *(undefined8 *)(iVar13 + 0x2a20) = 0;
            if ((pcVar12 == (char *)0x0) && (pcVar12 = (char *)arg2, arg2 != -1)) {
                while (*pcVar12 != '\0') {
                    pcVar11 = pcVar12 + 1;
                    if (((*pcVar12 == '#') && (*pcVar11 == '#')) ||
                       (pcVar12 = pcVar11, pcVar11 == (char *)0xffffffffffffffff)) break;
                }
            }
            fVar14 = *(float *)(iVar13 + 0xde0);
            if (*(float *)(iVar13 + 0xde0) <= *(float *)(iVar13 + 0xdf0)) {
                fVar14 = *(float *)(iVar13 + 0xdf0);
            }
            fVar1 = *(float *)(iVar13 + 0x2a30);
            *(float *)(iVar13 + 0x2a30) = var_38h._4_4_;
            if (fVar14 + fVar1 + 1.0 < var_38h._4_4_) {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar13 + 0x29f9) = 1;
            }
            if (iVar9 != 0) {
                iVar7 = func_0x000180498cd0(iVar9);
                func_0x000180112520(&var_38h, iVar9, iVar7 + iVar9);
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            iVar6 = *(int32_t *)(iVar13 + 0x2a34);
            if (iVar2 < iVar6) {
                *(int32_t *)(iVar13 + 0x2a34) = iVar2;
                iVar6 = iVar2;
            }
            iVar2 = *(int32_t *)(iVar3 + 0x1e0);
            while( true ) {
                pcVar8 = (char *)func_0x000180498a80(arg2, 10, (int64_t)pcVar12 - arg2);
                pcVar11 = pcVar12;
                if (pcVar8 != (char *)0x0) {
                    pcVar11 = pcVar8;
                }
                if (((char *)arg2 == pcVar11) && (pcVar11 == pcVar12)) break;
                iVar10 = (iVar2 - iVar6) * 4;
                if (*(char *)(iVar13 + 0x29f9) == '\0') {
                    iVar10 = 1;
                }
                func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg2, arg2);
                *(undefined *)(iVar13 + 0x29f9) = 0;
                if (*pcVar11 == '\n') {
                    func_0x0001801124e0(0x180644f68);
                    *(undefined *)(iVar13 + 0x29f9) = 1;
                }
                if (pcVar11 == pcVar12) break;
                arg2 = (int64_t)(pcVar11 + 1);
            }
            if (iVar4 != 0) {
                iVar9 = func_0x000180498cd0(iVar4);
                func_0x000180112520(&var_38h, iVar4, iVar9 + iVar4);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f6fc0
// Address: 0x1800f6fc0
// Size: 573 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_a8h
// WARNING: Variable defined which should be unmapped: var_a0h
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_90h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f6fc0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_40h)
{
    bool bVar1;
    uint8_t uVar2;
    uint32_t uVar3;
    int64_t *piVar4;
    float *pfVar5;
    float *pfVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    int64_t var_10h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    float var_68h;
    int64_t var_64h;
    int64_t var_58h;
    int64_t var_48h;
    
    var_10h = *(int64_t *)arg2;
    fVar8 = (float)var_10h;
    if (arg_30h == 0) {
        piVar4 = (int64_t *)func_0x0001800fe0a0(&arg_30h, arg4, arg_28h, 0, 0);
    } else {
        piVar4 = &var_78h;
        var_78h = *(int64_t *)arg_30h;
    }
    pfVar5 = (float *)arg_40h;
    if (arg_40h == 0) {
        pfVar5 = (float *)arg2;
    }
    pfVar6 = (float *)(arg_40h + 8);
    if (arg_40h == 0) {
        pfVar6 = (float *)arg3;
    }
    fVar9 = var_10h._4_4_;
    if ((*pfVar6 <= *(float *)piVar4 + fVar8) || (pfVar6[1] <= *(float *)((int64_t)piVar4 + 4) + var_10h._4_4_)) {
        bVar1 = true;
    } else {
        bVar1 = false;
    }
    if (arg_40h != 0) {
        if ((fVar8 < *pfVar5) || (var_10h._4_4_ < pfVar5[1])) {
            uVar2 = 1;
        } else {
            uVar2 = 0;
        }
        bVar1 = (bool)(bVar1 | uVar2);
    }
    if (0.0 < *(float *)arg_38h) {
        fVar7 = ((*(float *)arg3 - fVar8) - *(float *)piVar4) * *(float *)arg_38h + fVar8;
        if (fVar8 <= fVar7) {
            fVar8 = fVar7;
        }
        var_10h = CONCAT44(var_10h._4_4_, fVar8);
    }
    if (0.0 < *(float *)(arg_38h + 4)) {
        fVar8 = ((*(float *)(arg3 + 4) - fVar9) - *(float *)((int64_t)piVar4 + 4)) * *(float *)(arg_38h + 4) + fVar9;
        if (fVar9 <= fVar8) {
            fVar9 = fVar8;
        }
        var_10h = CONCAT44(fVar9, (undefined4)var_10h);
    }
    var_70h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed0);
    var_70h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xed4);
    var_68h = *(float *)(*(int64_t *)0x180781f28 + 0xed8);
    var_64h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    if (bVar1) {
        uVar3 = fcn.1800f5fa0(&var_70h);
        if ((uVar3 & 0xff000000) == 0) {
            return;
        }
        if (arg4 == arg_28h) {
            return;
        }
        if (*(char *)arg4 == '\0') {
            return;
        }
        var_80h._0_4_ = 1;
        var_70h._0_4_ = *(float *)(arg1 + 0x60);
        if (*(float *)(arg1 + 0x60) <= *pfVar5) {
            var_70h._0_4_ = *pfVar5;
        }
        var_68h = *(float *)(arg1 + 0x68);
        if (*pfVar6 <= *(float *)(arg1 + 0x68)) {
            var_68h = *pfVar6;
        }
        var_70h._4_4_ = *(float *)(arg1 + 100);
        if (*(float *)(arg1 + 100) <= pfVar5[1]) {
            var_70h._4_4_ = pfVar5[1];
        }
        var_64h._0_4_ = *(float *)(arg1 + 0x6c);
        if (pfVar6[1] <= *(float *)(arg1 + 0x6c)) {
            var_64h._0_4_ = pfVar6[1];
        }
    } else {
        uVar3 = fcn.1800f5fa0(&var_70h);
        if ((uVar3 & 0xff000000) == 0) {
            return;
        }
        if (arg4 == arg_28h) {
            return;
        }
        if (*(char *)arg4 == '\0') {
            return;
        }
        var_70h._0_4_ = *(float *)(arg1 + 0x60);
        var_70h._4_4_ = *(float *)(arg1 + 100);
        var_68h = *(float *)(arg1 + 0x68);
        var_80h._0_4_ = 0;
        var_64h._0_4_ = *(float *)(arg1 + 0x6c);
    }
    func_0x00018012f9d0(*(undefined8 *)(*(int64_t *)(arg1 + 0x38) + 0x18), arg1, 
                        *(undefined4 *)(*(int64_t *)(arg1 + 0x38) + 0x20), &var_10h, uVar3, &var_70h, arg4, arg_28h, 0, 
                        (undefined4)var_80h);
    return;
}

// ============================================================
// Function: FUN_1800f7200
// Address: 0x1800f7200
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_70h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *arg_28h_00;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000038;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    pcVar11 = (char *)0xffffffffffffffff;
    if (arg4 != 0) {
        pcVar11 = (char *)arg4;
    }
    arg_28h_00 = (char *)arg3;
    if ((uint64_t)arg3 < pcVar11) {
        while (*arg_28h_00 != '\0') {
            if (((*arg_28h_00 == '#') && (arg_28h_00[1] == '#')) || (arg_28h_00 = arg_28h_00 + 1, pcVar11 <= arg_28h_00)
               ) break;
        }
    }
    if ((int32_t)arg_28h_00 == (int32_t)arg3) {
        return;
    }
    fcn.1800f6fc0(*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 800), arg1, arg2, arg3, 
                  (int64_t)arg_28h_00, arg_28h, arg_30h, in_stack_00000038);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar9 + 0x29f8) == '\0') {
        return;
    }
    iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
    *(undefined8 *)(iVar5 + 0x2a20) = 0;
    if ((arg_28h_00 == (char *)0x0) && (arg_28h_00 = (char *)arg3, arg3 != -1)) {
        do {
            if ((*arg_28h_00 == '\0') || ((pcVar11 = arg_28h_00 + 1, *arg_28h_00 == '#' && (*pcVar11 == '#')))) break;
            arg_28h_00 = pcVar11;
        } while (pcVar11 != (char *)0xffffffffffffffff);
    }
    if (arg1 != 0) {
        fVar12 = *(float *)(iVar5 + 0xde0);
        if (*(float *)(iVar5 + 0xde0) <= *(float *)(iVar5 + 0xdf0)) {
            fVar12 = *(float *)(iVar5 + 0xdf0);
        }
        if (*(float *)(arg1 + 4) <= fVar12 + *(float *)(iVar5 + 0x2a30) + 1.0) {
            if (arg1 == 0) goto code_r0x0001800f7368;
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        *(float *)(iVar5 + 0x2a30) = *(float *)(arg1 + 4);
        if (bVar4) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
    }
code_r0x0001800f7368:
    if (iVar9 != 0) {
        iVar7 = func_0x000180498cd0(iVar9);
        func_0x000180112520(arg1, iVar9, iVar7 + iVar9);
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    iVar6 = *(int32_t *)(iVar5 + 0x2a34);
    if (iVar1 < iVar6) {
        *(int32_t *)(iVar5 + 0x2a34) = iVar1;
        iVar6 = iVar1;
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    while( true ) {
        pcVar8 = (char *)func_0x000180498a80(arg3, 10, (int64_t)arg_28h_00 - arg3);
        pcVar11 = arg_28h_00;
        if (pcVar8 != (char *)0x0) {
            pcVar11 = pcVar8;
        }
        if (((char *)arg3 == pcVar11) && (pcVar11 == arg_28h_00)) break;
        iVar10 = (iVar1 - iVar6) * 4;
        if (*(char *)(iVar5 + 0x29f9) == '\0') {
            iVar10 = 1;
        }
        func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg3, arg3);
        *(undefined *)(iVar5 + 0x29f9) = 0;
        if (*pcVar11 == '\n') {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
        if (pcVar11 == arg_28h_00) break;
        arg3 = (int64_t)(pcVar11 + 1);
    }
    if (iVar2 != 0) {
        iVar9 = func_0x000180498cd0(iVar2);
        func_0x000180112520(arg1, iVar2, iVar9 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1800f7275
// Address: 0x1800f7275
// Size: 49 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_70h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *arg_28h_00;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000038;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    pcVar11 = (char *)0xffffffffffffffff;
    if (arg4 != 0) {
        pcVar11 = (char *)arg4;
    }
    arg_28h_00 = (char *)arg3;
    if ((uint64_t)arg3 < pcVar11) {
        while (*arg_28h_00 != '\0') {
            if (((*arg_28h_00 == '#') && (arg_28h_00[1] == '#')) || (arg_28h_00 = arg_28h_00 + 1, pcVar11 <= arg_28h_00)
               ) break;
        }
    }
    if ((int32_t)arg_28h_00 == (int32_t)arg3) {
        return;
    }
    fcn.1800f6fc0(*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 800), arg1, arg2, arg3, 
                  (int64_t)arg_28h_00, arg_28h, arg_30h, in_stack_00000038);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar9 + 0x29f8) == '\0') {
        return;
    }
    iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
    *(undefined8 *)(iVar5 + 0x2a20) = 0;
    if ((arg_28h_00 == (char *)0x0) && (arg_28h_00 = (char *)arg3, arg3 != -1)) {
        do {
            if ((*arg_28h_00 == '\0') || ((pcVar11 = arg_28h_00 + 1, *arg_28h_00 == '#' && (*pcVar11 == '#')))) break;
            arg_28h_00 = pcVar11;
        } while (pcVar11 != (char *)0xffffffffffffffff);
    }
    if (arg1 != 0) {
        fVar12 = *(float *)(iVar5 + 0xde0);
        if (*(float *)(iVar5 + 0xde0) <= *(float *)(iVar5 + 0xdf0)) {
            fVar12 = *(float *)(iVar5 + 0xdf0);
        }
        if (*(float *)(arg1 + 4) <= fVar12 + *(float *)(iVar5 + 0x2a30) + 1.0) {
            if (arg1 == 0) goto code_r0x0001800f7368;
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        *(float *)(iVar5 + 0x2a30) = *(float *)(arg1 + 4);
        if (bVar4) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
    }
code_r0x0001800f7368:
    if (iVar9 != 0) {
        iVar7 = func_0x000180498cd0(iVar9);
        func_0x000180112520(arg1, iVar9, iVar7 + iVar9);
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    iVar6 = *(int32_t *)(iVar5 + 0x2a34);
    if (iVar1 < iVar6) {
        *(int32_t *)(iVar5 + 0x2a34) = iVar1;
        iVar6 = iVar1;
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    while( true ) {
        pcVar8 = (char *)func_0x000180498a80(arg3, 10, (int64_t)arg_28h_00 - arg3);
        pcVar11 = arg_28h_00;
        if (pcVar8 != (char *)0x0) {
            pcVar11 = pcVar8;
        }
        if (((char *)arg3 == pcVar11) && (pcVar11 == arg_28h_00)) break;
        iVar10 = (iVar1 - iVar6) * 4;
        if (*(char *)(iVar5 + 0x29f9) == '\0') {
            iVar10 = 1;
        }
        func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg3, arg3);
        *(undefined *)(iVar5 + 0x29f9) = 0;
        if (*pcVar11 == '\n') {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
        if (pcVar11 == arg_28h_00) break;
        arg3 = (int64_t)(pcVar11 + 1);
    }
    if (iVar2 != 0) {
        iVar9 = func_0x000180498cd0(iVar2);
        func_0x000180112520(arg1, iVar2, iVar9 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1800f72a6
// Address: 0x1800f72a6
// Size: 417 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_70h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *arg_28h_00;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000038;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    pcVar11 = (char *)0xffffffffffffffff;
    if (arg4 != 0) {
        pcVar11 = (char *)arg4;
    }
    arg_28h_00 = (char *)arg3;
    if ((uint64_t)arg3 < pcVar11) {
        while (*arg_28h_00 != '\0') {
            if (((*arg_28h_00 == '#') && (arg_28h_00[1] == '#')) || (arg_28h_00 = arg_28h_00 + 1, pcVar11 <= arg_28h_00)
               ) break;
        }
    }
    if ((int32_t)arg_28h_00 == (int32_t)arg3) {
        return;
    }
    fcn.1800f6fc0(*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 800), arg1, arg2, arg3, 
                  (int64_t)arg_28h_00, arg_28h, arg_30h, in_stack_00000038);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar9 + 0x29f8) == '\0') {
        return;
    }
    iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
    *(undefined8 *)(iVar5 + 0x2a20) = 0;
    if ((arg_28h_00 == (char *)0x0) && (arg_28h_00 = (char *)arg3, arg3 != -1)) {
        do {
            if ((*arg_28h_00 == '\0') || ((pcVar11 = arg_28h_00 + 1, *arg_28h_00 == '#' && (*pcVar11 == '#')))) break;
            arg_28h_00 = pcVar11;
        } while (pcVar11 != (char *)0xffffffffffffffff);
    }
    if (arg1 != 0) {
        fVar12 = *(float *)(iVar5 + 0xde0);
        if (*(float *)(iVar5 + 0xde0) <= *(float *)(iVar5 + 0xdf0)) {
            fVar12 = *(float *)(iVar5 + 0xdf0);
        }
        if (*(float *)(arg1 + 4) <= fVar12 + *(float *)(iVar5 + 0x2a30) + 1.0) {
            if (arg1 == 0) goto code_r0x0001800f7368;
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        *(float *)(iVar5 + 0x2a30) = *(float *)(arg1 + 4);
        if (bVar4) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
    }
code_r0x0001800f7368:
    if (iVar9 != 0) {
        iVar7 = func_0x000180498cd0(iVar9);
        func_0x000180112520(arg1, iVar9, iVar7 + iVar9);
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    iVar6 = *(int32_t *)(iVar5 + 0x2a34);
    if (iVar1 < iVar6) {
        *(int32_t *)(iVar5 + 0x2a34) = iVar1;
        iVar6 = iVar1;
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    while( true ) {
        pcVar8 = (char *)func_0x000180498a80(arg3, 10, (int64_t)arg_28h_00 - arg3);
        pcVar11 = arg_28h_00;
        if (pcVar8 != (char *)0x0) {
            pcVar11 = pcVar8;
        }
        if (((char *)arg3 == pcVar11) && (pcVar11 == arg_28h_00)) break;
        iVar10 = (iVar1 - iVar6) * 4;
        if (*(char *)(iVar5 + 0x29f9) == '\0') {
            iVar10 = 1;
        }
        func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg3, arg3);
        *(undefined *)(iVar5 + 0x29f9) = 0;
        if (*pcVar11 == '\n') {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
        if (pcVar11 == arg_28h_00) break;
        arg3 = (int64_t)(pcVar11 + 1);
    }
    if (iVar2 != 0) {
        iVar9 = func_0x000180498cd0(iVar2);
        func_0x000180112520(arg1, iVar2, iVar9 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1800f7447
// Address: 0x1800f7447
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_70h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *arg_28h_00;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000038;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    pcVar11 = (char *)0xffffffffffffffff;
    if (arg4 != 0) {
        pcVar11 = (char *)arg4;
    }
    arg_28h_00 = (char *)arg3;
    if ((uint64_t)arg3 < pcVar11) {
        while (*arg_28h_00 != '\0') {
            if (((*arg_28h_00 == '#') && (arg_28h_00[1] == '#')) || (arg_28h_00 = arg_28h_00 + 1, pcVar11 <= arg_28h_00)
               ) break;
        }
    }
    if ((int32_t)arg_28h_00 == (int32_t)arg3) {
        return;
    }
    fcn.1800f6fc0(*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 800), arg1, arg2, arg3, 
                  (int64_t)arg_28h_00, arg_28h, arg_30h, in_stack_00000038);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar9 + 0x29f8) == '\0') {
        return;
    }
    iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
    *(undefined8 *)(iVar5 + 0x2a20) = 0;
    if ((arg_28h_00 == (char *)0x0) && (arg_28h_00 = (char *)arg3, arg3 != -1)) {
        do {
            if ((*arg_28h_00 == '\0') || ((pcVar11 = arg_28h_00 + 1, *arg_28h_00 == '#' && (*pcVar11 == '#')))) break;
            arg_28h_00 = pcVar11;
        } while (pcVar11 != (char *)0xffffffffffffffff);
    }
    if (arg1 != 0) {
        fVar12 = *(float *)(iVar5 + 0xde0);
        if (*(float *)(iVar5 + 0xde0) <= *(float *)(iVar5 + 0xdf0)) {
            fVar12 = *(float *)(iVar5 + 0xdf0);
        }
        if (*(float *)(arg1 + 4) <= fVar12 + *(float *)(iVar5 + 0x2a30) + 1.0) {
            if (arg1 == 0) goto code_r0x0001800f7368;
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        *(float *)(iVar5 + 0x2a30) = *(float *)(arg1 + 4);
        if (bVar4) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
    }
code_r0x0001800f7368:
    if (iVar9 != 0) {
        iVar7 = func_0x000180498cd0(iVar9);
        func_0x000180112520(arg1, iVar9, iVar7 + iVar9);
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    iVar6 = *(int32_t *)(iVar5 + 0x2a34);
    if (iVar1 < iVar6) {
        *(int32_t *)(iVar5 + 0x2a34) = iVar1;
        iVar6 = iVar1;
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    while( true ) {
        pcVar8 = (char *)func_0x000180498a80(arg3, 10, (int64_t)arg_28h_00 - arg3);
        pcVar11 = arg_28h_00;
        if (pcVar8 != (char *)0x0) {
            pcVar11 = pcVar8;
        }
        if (((char *)arg3 == pcVar11) && (pcVar11 == arg_28h_00)) break;
        iVar10 = (iVar1 - iVar6) * 4;
        if (*(char *)(iVar5 + 0x29f9) == '\0') {
            iVar10 = 1;
        }
        func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg3, arg3);
        *(undefined *)(iVar5 + 0x29f9) = 0;
        if (*pcVar11 == '\n') {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
        if (pcVar11 == arg_28h_00) break;
        arg3 = (int64_t)(pcVar11 + 1);
    }
    if (iVar2 != 0) {
        iVar9 = func_0x000180498cd0(iVar2);
        func_0x000180112520(arg1, iVar2, iVar9 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1800f7463
// Address: 0x1800f7463
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_70h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *arg_28h_00;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000038;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    pcVar11 = (char *)0xffffffffffffffff;
    if (arg4 != 0) {
        pcVar11 = (char *)arg4;
    }
    arg_28h_00 = (char *)arg3;
    if ((uint64_t)arg3 < pcVar11) {
        while (*arg_28h_00 != '\0') {
            if (((*arg_28h_00 == '#') && (arg_28h_00[1] == '#')) || (arg_28h_00 = arg_28h_00 + 1, pcVar11 <= arg_28h_00)
               ) break;
        }
    }
    if ((int32_t)arg_28h_00 == (int32_t)arg3) {
        return;
    }
    fcn.1800f6fc0(*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 800), arg1, arg2, arg3, 
                  (int64_t)arg_28h_00, arg_28h, arg_30h, in_stack_00000038);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar9 + 0x29f8) == '\0') {
        return;
    }
    iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
    *(undefined8 *)(iVar5 + 0x2a20) = 0;
    if ((arg_28h_00 == (char *)0x0) && (arg_28h_00 = (char *)arg3, arg3 != -1)) {
        do {
            if ((*arg_28h_00 == '\0') || ((pcVar11 = arg_28h_00 + 1, *arg_28h_00 == '#' && (*pcVar11 == '#')))) break;
            arg_28h_00 = pcVar11;
        } while (pcVar11 != (char *)0xffffffffffffffff);
    }
    if (arg1 != 0) {
        fVar12 = *(float *)(iVar5 + 0xde0);
        if (*(float *)(iVar5 + 0xde0) <= *(float *)(iVar5 + 0xdf0)) {
            fVar12 = *(float *)(iVar5 + 0xdf0);
        }
        if (*(float *)(arg1 + 4) <= fVar12 + *(float *)(iVar5 + 0x2a30) + 1.0) {
            if (arg1 == 0) goto code_r0x0001800f7368;
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        *(float *)(iVar5 + 0x2a30) = *(float *)(arg1 + 4);
        if (bVar4) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
    }
code_r0x0001800f7368:
    if (iVar9 != 0) {
        iVar7 = func_0x000180498cd0(iVar9);
        func_0x000180112520(arg1, iVar9, iVar7 + iVar9);
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    iVar6 = *(int32_t *)(iVar5 + 0x2a34);
    if (iVar1 < iVar6) {
        *(int32_t *)(iVar5 + 0x2a34) = iVar1;
        iVar6 = iVar1;
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    while( true ) {
        pcVar8 = (char *)func_0x000180498a80(arg3, 10, (int64_t)arg_28h_00 - arg3);
        pcVar11 = arg_28h_00;
        if (pcVar8 != (char *)0x0) {
            pcVar11 = pcVar8;
        }
        if (((char *)arg3 == pcVar11) && (pcVar11 == arg_28h_00)) break;
        iVar10 = (iVar1 - iVar6) * 4;
        if (*(char *)(iVar5 + 0x29f9) == '\0') {
            iVar10 = 1;
        }
        func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg3, arg3);
        *(undefined *)(iVar5 + 0x29f9) = 0;
        if (*pcVar11 == '\n') {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
        if (pcVar11 == arg_28h_00) break;
        arg3 = (int64_t)(pcVar11 + 1);
    }
    if (iVar2 != 0) {
        iVar9 = func_0x000180498cd0(iVar2);
        func_0x000180112520(arg1, iVar2, iVar9 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1800f7468
// Address: 0x1800f7468
// Size: 9 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7200(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_70h, int64_t arg_98h)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    bool bVar4;
    int64_t iVar5;
    int32_t iVar6;
    int64_t iVar7;
    char *pcVar8;
    int64_t iVar9;
    int32_t iVar10;
    char *pcVar11;
    char *arg_28h_00;
    float fVar12;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t in_stack_00000038;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar9 = *(int64_t *)0x180781f28;
    pcVar11 = (char *)0xffffffffffffffff;
    if (arg4 != 0) {
        pcVar11 = (char *)arg4;
    }
    arg_28h_00 = (char *)arg3;
    if ((uint64_t)arg3 < pcVar11) {
        while (*arg_28h_00 != '\0') {
            if (((*arg_28h_00 == '#') && (arg_28h_00[1] == '#')) || (arg_28h_00 = arg_28h_00 + 1, pcVar11 <= arg_28h_00)
               ) break;
        }
    }
    if ((int32_t)arg_28h_00 == (int32_t)arg3) {
        return;
    }
    fcn.1800f6fc0(*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 800), arg1, arg2, arg3, 
                  (int64_t)arg_28h_00, arg_28h, arg_30h, in_stack_00000038);
    iVar5 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar9 + 0x29f8) == '\0') {
        return;
    }
    iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
    iVar2 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
    iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
    *(undefined8 *)(iVar5 + 0x2a20) = 0;
    if ((arg_28h_00 == (char *)0x0) && (arg_28h_00 = (char *)arg3, arg3 != -1)) {
        do {
            if ((*arg_28h_00 == '\0') || ((pcVar11 = arg_28h_00 + 1, *arg_28h_00 == '#' && (*pcVar11 == '#')))) break;
            arg_28h_00 = pcVar11;
        } while (pcVar11 != (char *)0xffffffffffffffff);
    }
    if (arg1 != 0) {
        fVar12 = *(float *)(iVar5 + 0xde0);
        if (*(float *)(iVar5 + 0xde0) <= *(float *)(iVar5 + 0xdf0)) {
            fVar12 = *(float *)(iVar5 + 0xdf0);
        }
        if (*(float *)(arg1 + 4) <= fVar12 + *(float *)(iVar5 + 0x2a30) + 1.0) {
            if (arg1 == 0) goto code_r0x0001800f7368;
            bVar4 = false;
        } else {
            bVar4 = true;
        }
        *(float *)(iVar5 + 0x2a30) = *(float *)(arg1 + 4);
        if (bVar4) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
    }
code_r0x0001800f7368:
    if (iVar9 != 0) {
        iVar7 = func_0x000180498cd0(iVar9);
        func_0x000180112520(arg1, iVar9, iVar7 + iVar9);
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    iVar6 = *(int32_t *)(iVar5 + 0x2a34);
    if (iVar1 < iVar6) {
        *(int32_t *)(iVar5 + 0x2a34) = iVar1;
        iVar6 = iVar1;
    }
    iVar1 = *(int32_t *)(iVar3 + 0x1e0);
    while( true ) {
        pcVar8 = (char *)func_0x000180498a80(arg3, 10, (int64_t)arg_28h_00 - arg3);
        pcVar11 = arg_28h_00;
        if (pcVar8 != (char *)0x0) {
            pcVar11 = pcVar8;
        }
        if (((char *)arg3 == pcVar11) && (pcVar11 == arg_28h_00)) break;
        iVar10 = (iVar1 - iVar6) * 4;
        if (*(char *)(iVar5 + 0x29f9) == '\0') {
            iVar10 = 1;
        }
        func_0x0001801124e0(0x180644f70, iVar10, 0x1805aadb1, (int32_t)pcVar11 - (int32_t)arg3, arg3);
        *(undefined *)(iVar5 + 0x29f9) = 0;
        if (*pcVar11 == '\n') {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar5 + 0x29f9) = 1;
        }
        if (pcVar11 == arg_28h_00) break;
        arg3 = (int64_t)(pcVar11 + 1);
    }
    if (iVar2 != 0) {
        iVar9 = func_0x000180498cd0(iVar2);
        func_0x000180112520(arg1, iVar2, iVar9 + iVar2);
    }
    return;
}

// ============================================================
// Function: FUN_1800f7480
// Address: 0x1800f7480
// Size: 47 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_57h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_69h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Removing arg arg_63h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7480(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int32_t *piVar8;
    int64_t iVar9;
    uint32_t *puVar10;
    int64_t iVar11;
    char *pcVar12;
    int64_t iVar13;
    uint32_t uVar14;
    int32_t iVar15;
    char *arg_28h;
    char *pcVar16;
    char *pcVar17;
    float fVar18;
    float fVar19;
    float in_XMM3_Da;
    float fVar20;
    float fVar21;
    float fVar22;
    undefined4 *puStackX_18;
    int64_t var_20h;
    char *in_stack_00000028;
    uint32_t uStack0000000000000030;
    undefined4 uStack0000000000000034;
    char **in_stack_00000038;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    float fStack_b8;
    float fStack_b4;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    undefined4 uStack_a0;
    float fStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar13 = *(int64_t *)0x180781f28;
    arg_28h = _uStack0000000000000030;
    if ((_uStack0000000000000030 == (char *)0x0) &&
       (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff)) {
        while (*arg_28h != '\0') {
            pcVar17 = arg_28h + 1;
            if (((*arg_28h == '#') && (*pcVar17 == '#')) || (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff))
            break;
        }
    }
    puStackX_18 = (undefined4 *)arg3;
    if (in_stack_00000038 == (char **)0x0) {
        var_e8h = var_e8h & 0xffffffff00000000;
        puVar7 = (undefined8 *)func_0x0001800fe0a0(&stack0x00000030, in_stack_00000028, arg_28h, 0, var_e8h);
    } else {
        puVar7 = (undefined8 *)&stack0x00000030;
        _uStack0000000000000030 = *in_stack_00000038;
    }
    in_stack_00000038 = (char **)*puVar7;
    if (SUB84(in_stack_00000038, 0) <= *(float *)arg3 - *(float *)arg2) {
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)arg_28h, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
    } else {
        iVar9 = *(int64_t *)(arg1 + 0x38);
        iVar3 = *(int64_t *)(iVar9 + 0x18);
        fVar22 = *(float *)(iVar9 + 0x24);
        fVar1 = *(float *)(iVar9 + 0x20);
        piVar8 = (int32_t *)func_0x00018012ec80(iVar3);
        uVar2 = *(uint16_t *)(iVar3 + 0x30);
        if ((*piVar8 <= (int32_t)(uint32_t)uVar2) ||
           (fVar18 = *(float *)(*(int64_t *)(piVar8 + 2) + (uint64_t)uVar2 * 4), fVar18 < 0.0)) {
            fVar18 = (float)func_0x00018012bbd0(piVar8, (uint64_t)uVar2);
        }
        fVar20 = *(float *)arg3;
        if (*(float *)arg3 <= in_XMM3_Da) {
            fVar20 = in_XMM3_Da;
        }
        fVar22 = (fVar20 - fVar22 * fVar18) - *(float *)arg2;
        if (fVar22 <= 1.0) {
            fVar22 = 1.0;
        }
        pcVar17 = arg_28h;
        if (arg_28h == (char *)0x0) {
            iVar9 = func_0x000180498cd0(in_stack_00000028);
            pcVar17 = in_stack_00000028 + iVar9;
        }
        puVar10 = (uint32_t *)func_0x00018012ec80(iVar3);
        fVar21 = 0.0;
        fVar20 = 0.0;
        fVar18 = (float)puVar10[5];
        pcVar12 = in_stack_00000028;
        if (in_stack_00000028 < pcVar17) {
            do {
                uVar14 = (uint32_t)*pcVar12;
                _uStack0000000000000030 = (char *)CONCAT44(uStack0000000000000034, uVar14);
                if (uVar14 < 0x80) {
                    pcVar16 = pcVar12 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&stack0x00000030, pcVar12, pcVar17);
                    pcVar16 = pcVar12 + iVar5;
                    uVar14 = uStack0000000000000030;
                }
                if (uVar14 == 10) {
                    if (fVar21 <= fVar20) {
                        fVar21 = fVar20;
                    }
                    fVar19 = 0.0;
                } else {
                    fVar19 = fVar20;
                    if (uVar14 != 0xd) {
                        if ((*puVar10 <= uVar14) ||
                           (fVar19 = *(float *)(*(int64_t *)(puVar10 + 2) + (uint64_t)uVar14 * 4), fVar19 < 0.0)) {
                            fVar19 = (float)func_0x00018012bbd0(puVar10);
                        }
                        fVar19 = fVar19 * (fVar1 / fVar18) + fVar20;
                        arg3 = (int64_t)puStackX_18;
                        if (fVar22 <= fVar19) break;
                    }
                }
                pcVar12 = pcVar16;
                arg3 = (int64_t)puStackX_18;
                fVar20 = fVar19;
            } while (pcVar16 < pcVar17);
        }
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)pcVar12, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
        fStack_b8 = *(float *)arg2;
        if (fVar20 <= fVar21) {
            fVar20 = fVar21;
        }
        uStack_b0 = *(undefined4 *)arg3;
        fStack_b4 = *(float *)(arg2 + 4);
        uStack_ac = *(undefined4 *)(arg3 + 4);
        uStack_a8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_a4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        puStackX_18 = (undefined4 *)CONCAT44((float)(int32_t)fStack_b4, (float)(int32_t)(fVar20 + fStack_b8));
        fStack_9c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = fcn.1800f5fa0(&uStack_a8);
        var_e0h = CONCAT62((unkint6)((uint64_t)&stack0x00000038 >> 0x10), *(undefined2 *)(iVar3 + 0x30));
        var_e8h = (int64_t)uVar14;
        func_0x00018012f6c0(iVar3, arg1, fVar1, &puStackX_18, var_e8h, var_e0h, &fStack_b8);
    }
    iVar9 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar13 + 0x29f8) != '\0') {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar9 + 0x2a20) = 0;
        if ((arg_28h == (char *)0x0) && (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff))
        {
            while (*arg_28h != '\0') {
                pcVar17 = arg_28h + 1;
                if (((*arg_28h == '#') && (*pcVar17 == '#')) ||
                   (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar22 = *(float *)(iVar9 + 0xde0);
        if (*(float *)(iVar9 + 0xde0) <= *(float *)(iVar9 + 0xdf0)) {
            fVar22 = *(float *)(iVar9 + 0xdf0);
        }
        fVar1 = *(float *)(iVar9 + 0x2a30);
        fVar18 = *(float *)(arg2 + 4);
        *(undefined4 *)(iVar9 + 0x2a30) = *(undefined4 *)(arg2 + 4);
        if (fVar22 + fVar1 + 1.0 < fVar18) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar9 + 0x29f9) = 1;
        }
        if (iVar13 != 0) {
            iVar11 = func_0x000180498cd0(iVar13);
            func_0x000180112520(arg2, iVar13, iVar11 + iVar13);
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        iVar6 = *(int32_t *)(iVar9 + 0x2a34);
        if (iVar5 < iVar6) {
            *(int32_t *)(iVar9 + 0x2a34) = iVar5;
            iVar6 = iVar5;
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        while( true ) {
            pcVar12 = (char *)func_0x000180498a80(in_stack_00000028, 10, (int64_t)arg_28h - (int64_t)in_stack_00000028);
            pcVar17 = arg_28h;
            if (pcVar12 != (char *)0x0) {
                pcVar17 = pcVar12;
            }
            if ((in_stack_00000028 == pcVar17) && (pcVar17 == arg_28h)) break;
            iVar15 = (iVar5 - iVar6) * 4;
            if (*(char *)(iVar9 + 0x29f9) == '\0') {
                iVar15 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar15, 0x1805aadb1, (int32_t)pcVar17 - (int32_t)in_stack_00000028, 
                                in_stack_00000028);
            *(undefined *)(iVar9 + 0x29f9) = 0;
            if (*pcVar17 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar9 + 0x29f9) = 1;
            }
            if (pcVar17 == arg_28h) break;
            in_stack_00000028 = pcVar17 + 1;
        }
        if (iVar3 != 0) {
            iVar13 = func_0x000180498cd0(iVar3);
            func_0x000180112520(arg2, iVar3, iVar13 + iVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f74af
// Address: 0x1800f74af
// Size: 193 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_57h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_69h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Removing arg arg_63h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7480(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int32_t *piVar8;
    int64_t iVar9;
    uint32_t *puVar10;
    int64_t iVar11;
    char *pcVar12;
    int64_t iVar13;
    uint32_t uVar14;
    int32_t iVar15;
    char *arg_28h;
    char *pcVar16;
    char *pcVar17;
    float fVar18;
    float fVar19;
    float in_XMM3_Da;
    float fVar20;
    float fVar21;
    float fVar22;
    undefined4 *puStackX_18;
    int64_t var_20h;
    char *in_stack_00000028;
    uint32_t uStack0000000000000030;
    undefined4 uStack0000000000000034;
    char **in_stack_00000038;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    float fStack_b8;
    float fStack_b4;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    undefined4 uStack_a0;
    float fStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar13 = *(int64_t *)0x180781f28;
    arg_28h = _uStack0000000000000030;
    if ((_uStack0000000000000030 == (char *)0x0) &&
       (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff)) {
        while (*arg_28h != '\0') {
            pcVar17 = arg_28h + 1;
            if (((*arg_28h == '#') && (*pcVar17 == '#')) || (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff))
            break;
        }
    }
    puStackX_18 = (undefined4 *)arg3;
    if (in_stack_00000038 == (char **)0x0) {
        var_e8h = var_e8h & 0xffffffff00000000;
        puVar7 = (undefined8 *)func_0x0001800fe0a0(&stack0x00000030, in_stack_00000028, arg_28h, 0, var_e8h);
    } else {
        puVar7 = (undefined8 *)&stack0x00000030;
        _uStack0000000000000030 = *in_stack_00000038;
    }
    in_stack_00000038 = (char **)*puVar7;
    if (SUB84(in_stack_00000038, 0) <= *(float *)arg3 - *(float *)arg2) {
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)arg_28h, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
    } else {
        iVar9 = *(int64_t *)(arg1 + 0x38);
        iVar3 = *(int64_t *)(iVar9 + 0x18);
        fVar22 = *(float *)(iVar9 + 0x24);
        fVar1 = *(float *)(iVar9 + 0x20);
        piVar8 = (int32_t *)func_0x00018012ec80(iVar3);
        uVar2 = *(uint16_t *)(iVar3 + 0x30);
        if ((*piVar8 <= (int32_t)(uint32_t)uVar2) ||
           (fVar18 = *(float *)(*(int64_t *)(piVar8 + 2) + (uint64_t)uVar2 * 4), fVar18 < 0.0)) {
            fVar18 = (float)func_0x00018012bbd0(piVar8, (uint64_t)uVar2);
        }
        fVar20 = *(float *)arg3;
        if (*(float *)arg3 <= in_XMM3_Da) {
            fVar20 = in_XMM3_Da;
        }
        fVar22 = (fVar20 - fVar22 * fVar18) - *(float *)arg2;
        if (fVar22 <= 1.0) {
            fVar22 = 1.0;
        }
        pcVar17 = arg_28h;
        if (arg_28h == (char *)0x0) {
            iVar9 = func_0x000180498cd0(in_stack_00000028);
            pcVar17 = in_stack_00000028 + iVar9;
        }
        puVar10 = (uint32_t *)func_0x00018012ec80(iVar3);
        fVar21 = 0.0;
        fVar20 = 0.0;
        fVar18 = (float)puVar10[5];
        pcVar12 = in_stack_00000028;
        if (in_stack_00000028 < pcVar17) {
            do {
                uVar14 = (uint32_t)*pcVar12;
                _uStack0000000000000030 = (char *)CONCAT44(uStack0000000000000034, uVar14);
                if (uVar14 < 0x80) {
                    pcVar16 = pcVar12 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&stack0x00000030, pcVar12, pcVar17);
                    pcVar16 = pcVar12 + iVar5;
                    uVar14 = uStack0000000000000030;
                }
                if (uVar14 == 10) {
                    if (fVar21 <= fVar20) {
                        fVar21 = fVar20;
                    }
                    fVar19 = 0.0;
                } else {
                    fVar19 = fVar20;
                    if (uVar14 != 0xd) {
                        if ((*puVar10 <= uVar14) ||
                           (fVar19 = *(float *)(*(int64_t *)(puVar10 + 2) + (uint64_t)uVar14 * 4), fVar19 < 0.0)) {
                            fVar19 = (float)func_0x00018012bbd0(puVar10);
                        }
                        fVar19 = fVar19 * (fVar1 / fVar18) + fVar20;
                        arg3 = (int64_t)puStackX_18;
                        if (fVar22 <= fVar19) break;
                    }
                }
                pcVar12 = pcVar16;
                arg3 = (int64_t)puStackX_18;
                fVar20 = fVar19;
            } while (pcVar16 < pcVar17);
        }
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)pcVar12, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
        fStack_b8 = *(float *)arg2;
        if (fVar20 <= fVar21) {
            fVar20 = fVar21;
        }
        uStack_b0 = *(undefined4 *)arg3;
        fStack_b4 = *(float *)(arg2 + 4);
        uStack_ac = *(undefined4 *)(arg3 + 4);
        uStack_a8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_a4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        puStackX_18 = (undefined4 *)CONCAT44((float)(int32_t)fStack_b4, (float)(int32_t)(fVar20 + fStack_b8));
        fStack_9c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = fcn.1800f5fa0(&uStack_a8);
        var_e0h = CONCAT62((unkint6)((uint64_t)&stack0x00000038 >> 0x10), *(undefined2 *)(iVar3 + 0x30));
        var_e8h = (int64_t)uVar14;
        func_0x00018012f6c0(iVar3, arg1, fVar1, &puStackX_18, var_e8h, var_e0h, &fStack_b8);
    }
    iVar9 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar13 + 0x29f8) != '\0') {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar9 + 0x2a20) = 0;
        if ((arg_28h == (char *)0x0) && (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff))
        {
            while (*arg_28h != '\0') {
                pcVar17 = arg_28h + 1;
                if (((*arg_28h == '#') && (*pcVar17 == '#')) ||
                   (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar22 = *(float *)(iVar9 + 0xde0);
        if (*(float *)(iVar9 + 0xde0) <= *(float *)(iVar9 + 0xdf0)) {
            fVar22 = *(float *)(iVar9 + 0xdf0);
        }
        fVar1 = *(float *)(iVar9 + 0x2a30);
        fVar18 = *(float *)(arg2 + 4);
        *(undefined4 *)(iVar9 + 0x2a30) = *(undefined4 *)(arg2 + 4);
        if (fVar22 + fVar1 + 1.0 < fVar18) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar9 + 0x29f9) = 1;
        }
        if (iVar13 != 0) {
            iVar11 = func_0x000180498cd0(iVar13);
            func_0x000180112520(arg2, iVar13, iVar11 + iVar13);
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        iVar6 = *(int32_t *)(iVar9 + 0x2a34);
        if (iVar5 < iVar6) {
            *(int32_t *)(iVar9 + 0x2a34) = iVar5;
            iVar6 = iVar5;
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        while( true ) {
            pcVar12 = (char *)func_0x000180498a80(in_stack_00000028, 10, (int64_t)arg_28h - (int64_t)in_stack_00000028);
            pcVar17 = arg_28h;
            if (pcVar12 != (char *)0x0) {
                pcVar17 = pcVar12;
            }
            if ((in_stack_00000028 == pcVar17) && (pcVar17 == arg_28h)) break;
            iVar15 = (iVar5 - iVar6) * 4;
            if (*(char *)(iVar9 + 0x29f9) == '\0') {
                iVar15 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar15, 0x1805aadb1, (int32_t)pcVar17 - (int32_t)in_stack_00000028, 
                                in_stack_00000028);
            *(undefined *)(iVar9 + 0x29f9) = 0;
            if (*pcVar17 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar9 + 0x29f9) = 1;
            }
            if (pcVar17 == arg_28h) break;
            in_stack_00000028 = pcVar17 + 1;
        }
        if (iVar3 != 0) {
            iVar13 = func_0x000180498cd0(iVar3);
            func_0x000180112520(arg2, iVar3, iVar13 + iVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7570
// Address: 0x1800f7570
// Size: 615 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_57h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_69h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Removing arg arg_63h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7480(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int32_t *piVar8;
    int64_t iVar9;
    uint32_t *puVar10;
    int64_t iVar11;
    char *pcVar12;
    int64_t iVar13;
    uint32_t uVar14;
    int32_t iVar15;
    char *arg_28h;
    char *pcVar16;
    char *pcVar17;
    float fVar18;
    float fVar19;
    float in_XMM3_Da;
    float fVar20;
    float fVar21;
    float fVar22;
    undefined4 *puStackX_18;
    int64_t var_20h;
    char *in_stack_00000028;
    uint32_t uStack0000000000000030;
    undefined4 uStack0000000000000034;
    char **in_stack_00000038;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    float fStack_b8;
    float fStack_b4;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    undefined4 uStack_a0;
    float fStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar13 = *(int64_t *)0x180781f28;
    arg_28h = _uStack0000000000000030;
    if ((_uStack0000000000000030 == (char *)0x0) &&
       (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff)) {
        while (*arg_28h != '\0') {
            pcVar17 = arg_28h + 1;
            if (((*arg_28h == '#') && (*pcVar17 == '#')) || (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff))
            break;
        }
    }
    puStackX_18 = (undefined4 *)arg3;
    if (in_stack_00000038 == (char **)0x0) {
        var_e8h = var_e8h & 0xffffffff00000000;
        puVar7 = (undefined8 *)func_0x0001800fe0a0(&stack0x00000030, in_stack_00000028, arg_28h, 0, var_e8h);
    } else {
        puVar7 = (undefined8 *)&stack0x00000030;
        _uStack0000000000000030 = *in_stack_00000038;
    }
    in_stack_00000038 = (char **)*puVar7;
    if (SUB84(in_stack_00000038, 0) <= *(float *)arg3 - *(float *)arg2) {
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)arg_28h, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
    } else {
        iVar9 = *(int64_t *)(arg1 + 0x38);
        iVar3 = *(int64_t *)(iVar9 + 0x18);
        fVar22 = *(float *)(iVar9 + 0x24);
        fVar1 = *(float *)(iVar9 + 0x20);
        piVar8 = (int32_t *)func_0x00018012ec80(iVar3);
        uVar2 = *(uint16_t *)(iVar3 + 0x30);
        if ((*piVar8 <= (int32_t)(uint32_t)uVar2) ||
           (fVar18 = *(float *)(*(int64_t *)(piVar8 + 2) + (uint64_t)uVar2 * 4), fVar18 < 0.0)) {
            fVar18 = (float)func_0x00018012bbd0(piVar8, (uint64_t)uVar2);
        }
        fVar20 = *(float *)arg3;
        if (*(float *)arg3 <= in_XMM3_Da) {
            fVar20 = in_XMM3_Da;
        }
        fVar22 = (fVar20 - fVar22 * fVar18) - *(float *)arg2;
        if (fVar22 <= 1.0) {
            fVar22 = 1.0;
        }
        pcVar17 = arg_28h;
        if (arg_28h == (char *)0x0) {
            iVar9 = func_0x000180498cd0(in_stack_00000028);
            pcVar17 = in_stack_00000028 + iVar9;
        }
        puVar10 = (uint32_t *)func_0x00018012ec80(iVar3);
        fVar21 = 0.0;
        fVar20 = 0.0;
        fVar18 = (float)puVar10[5];
        pcVar12 = in_stack_00000028;
        if (in_stack_00000028 < pcVar17) {
            do {
                uVar14 = (uint32_t)*pcVar12;
                _uStack0000000000000030 = (char *)CONCAT44(uStack0000000000000034, uVar14);
                if (uVar14 < 0x80) {
                    pcVar16 = pcVar12 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&stack0x00000030, pcVar12, pcVar17);
                    pcVar16 = pcVar12 + iVar5;
                    uVar14 = uStack0000000000000030;
                }
                if (uVar14 == 10) {
                    if (fVar21 <= fVar20) {
                        fVar21 = fVar20;
                    }
                    fVar19 = 0.0;
                } else {
                    fVar19 = fVar20;
                    if (uVar14 != 0xd) {
                        if ((*puVar10 <= uVar14) ||
                           (fVar19 = *(float *)(*(int64_t *)(puVar10 + 2) + (uint64_t)uVar14 * 4), fVar19 < 0.0)) {
                            fVar19 = (float)func_0x00018012bbd0(puVar10);
                        }
                        fVar19 = fVar19 * (fVar1 / fVar18) + fVar20;
                        arg3 = (int64_t)puStackX_18;
                        if (fVar22 <= fVar19) break;
                    }
                }
                pcVar12 = pcVar16;
                arg3 = (int64_t)puStackX_18;
                fVar20 = fVar19;
            } while (pcVar16 < pcVar17);
        }
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)pcVar12, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
        fStack_b8 = *(float *)arg2;
        if (fVar20 <= fVar21) {
            fVar20 = fVar21;
        }
        uStack_b0 = *(undefined4 *)arg3;
        fStack_b4 = *(float *)(arg2 + 4);
        uStack_ac = *(undefined4 *)(arg3 + 4);
        uStack_a8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_a4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        puStackX_18 = (undefined4 *)CONCAT44((float)(int32_t)fStack_b4, (float)(int32_t)(fVar20 + fStack_b8));
        fStack_9c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = fcn.1800f5fa0(&uStack_a8);
        var_e0h = CONCAT62((unkint6)((uint64_t)&stack0x00000038 >> 0x10), *(undefined2 *)(iVar3 + 0x30));
        var_e8h = (int64_t)uVar14;
        func_0x00018012f6c0(iVar3, arg1, fVar1, &puStackX_18, var_e8h, var_e0h, &fStack_b8);
    }
    iVar9 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar13 + 0x29f8) != '\0') {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar9 + 0x2a20) = 0;
        if ((arg_28h == (char *)0x0) && (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff))
        {
            while (*arg_28h != '\0') {
                pcVar17 = arg_28h + 1;
                if (((*arg_28h == '#') && (*pcVar17 == '#')) ||
                   (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar22 = *(float *)(iVar9 + 0xde0);
        if (*(float *)(iVar9 + 0xde0) <= *(float *)(iVar9 + 0xdf0)) {
            fVar22 = *(float *)(iVar9 + 0xdf0);
        }
        fVar1 = *(float *)(iVar9 + 0x2a30);
        fVar18 = *(float *)(arg2 + 4);
        *(undefined4 *)(iVar9 + 0x2a30) = *(undefined4 *)(arg2 + 4);
        if (fVar22 + fVar1 + 1.0 < fVar18) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar9 + 0x29f9) = 1;
        }
        if (iVar13 != 0) {
            iVar11 = func_0x000180498cd0(iVar13);
            func_0x000180112520(arg2, iVar13, iVar11 + iVar13);
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        iVar6 = *(int32_t *)(iVar9 + 0x2a34);
        if (iVar5 < iVar6) {
            *(int32_t *)(iVar9 + 0x2a34) = iVar5;
            iVar6 = iVar5;
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        while( true ) {
            pcVar12 = (char *)func_0x000180498a80(in_stack_00000028, 10, (int64_t)arg_28h - (int64_t)in_stack_00000028);
            pcVar17 = arg_28h;
            if (pcVar12 != (char *)0x0) {
                pcVar17 = pcVar12;
            }
            if ((in_stack_00000028 == pcVar17) && (pcVar17 == arg_28h)) break;
            iVar15 = (iVar5 - iVar6) * 4;
            if (*(char *)(iVar9 + 0x29f9) == '\0') {
                iVar15 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar15, 0x1805aadb1, (int32_t)pcVar17 - (int32_t)in_stack_00000028, 
                                in_stack_00000028);
            *(undefined *)(iVar9 + 0x29f9) = 0;
            if (*pcVar17 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar9 + 0x29f9) = 1;
            }
            if (pcVar17 == arg_28h) break;
            in_stack_00000028 = pcVar17 + 1;
        }
        if (iVar3 != 0) {
            iVar13 = func_0x000180498cd0(iVar3);
            func_0x000180112520(arg2, iVar3, iVar13 + iVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f77d7
// Address: 0x1800f77d7
// Size: 91 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_57h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_69h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Removing arg arg_63h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7480(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int32_t *piVar8;
    int64_t iVar9;
    uint32_t *puVar10;
    int64_t iVar11;
    char *pcVar12;
    int64_t iVar13;
    uint32_t uVar14;
    int32_t iVar15;
    char *arg_28h;
    char *pcVar16;
    char *pcVar17;
    float fVar18;
    float fVar19;
    float in_XMM3_Da;
    float fVar20;
    float fVar21;
    float fVar22;
    undefined4 *puStackX_18;
    int64_t var_20h;
    char *in_stack_00000028;
    uint32_t uStack0000000000000030;
    undefined4 uStack0000000000000034;
    char **in_stack_00000038;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    float fStack_b8;
    float fStack_b4;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    undefined4 uStack_a0;
    float fStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar13 = *(int64_t *)0x180781f28;
    arg_28h = _uStack0000000000000030;
    if ((_uStack0000000000000030 == (char *)0x0) &&
       (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff)) {
        while (*arg_28h != '\0') {
            pcVar17 = arg_28h + 1;
            if (((*arg_28h == '#') && (*pcVar17 == '#')) || (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff))
            break;
        }
    }
    puStackX_18 = (undefined4 *)arg3;
    if (in_stack_00000038 == (char **)0x0) {
        var_e8h = var_e8h & 0xffffffff00000000;
        puVar7 = (undefined8 *)func_0x0001800fe0a0(&stack0x00000030, in_stack_00000028, arg_28h, 0, var_e8h);
    } else {
        puVar7 = (undefined8 *)&stack0x00000030;
        _uStack0000000000000030 = *in_stack_00000038;
    }
    in_stack_00000038 = (char **)*puVar7;
    if (SUB84(in_stack_00000038, 0) <= *(float *)arg3 - *(float *)arg2) {
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)arg_28h, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
    } else {
        iVar9 = *(int64_t *)(arg1 + 0x38);
        iVar3 = *(int64_t *)(iVar9 + 0x18);
        fVar22 = *(float *)(iVar9 + 0x24);
        fVar1 = *(float *)(iVar9 + 0x20);
        piVar8 = (int32_t *)func_0x00018012ec80(iVar3);
        uVar2 = *(uint16_t *)(iVar3 + 0x30);
        if ((*piVar8 <= (int32_t)(uint32_t)uVar2) ||
           (fVar18 = *(float *)(*(int64_t *)(piVar8 + 2) + (uint64_t)uVar2 * 4), fVar18 < 0.0)) {
            fVar18 = (float)func_0x00018012bbd0(piVar8, (uint64_t)uVar2);
        }
        fVar20 = *(float *)arg3;
        if (*(float *)arg3 <= in_XMM3_Da) {
            fVar20 = in_XMM3_Da;
        }
        fVar22 = (fVar20 - fVar22 * fVar18) - *(float *)arg2;
        if (fVar22 <= 1.0) {
            fVar22 = 1.0;
        }
        pcVar17 = arg_28h;
        if (arg_28h == (char *)0x0) {
            iVar9 = func_0x000180498cd0(in_stack_00000028);
            pcVar17 = in_stack_00000028 + iVar9;
        }
        puVar10 = (uint32_t *)func_0x00018012ec80(iVar3);
        fVar21 = 0.0;
        fVar20 = 0.0;
        fVar18 = (float)puVar10[5];
        pcVar12 = in_stack_00000028;
        if (in_stack_00000028 < pcVar17) {
            do {
                uVar14 = (uint32_t)*pcVar12;
                _uStack0000000000000030 = (char *)CONCAT44(uStack0000000000000034, uVar14);
                if (uVar14 < 0x80) {
                    pcVar16 = pcVar12 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&stack0x00000030, pcVar12, pcVar17);
                    pcVar16 = pcVar12 + iVar5;
                    uVar14 = uStack0000000000000030;
                }
                if (uVar14 == 10) {
                    if (fVar21 <= fVar20) {
                        fVar21 = fVar20;
                    }
                    fVar19 = 0.0;
                } else {
                    fVar19 = fVar20;
                    if (uVar14 != 0xd) {
                        if ((*puVar10 <= uVar14) ||
                           (fVar19 = *(float *)(*(int64_t *)(puVar10 + 2) + (uint64_t)uVar14 * 4), fVar19 < 0.0)) {
                            fVar19 = (float)func_0x00018012bbd0(puVar10);
                        }
                        fVar19 = fVar19 * (fVar1 / fVar18) + fVar20;
                        arg3 = (int64_t)puStackX_18;
                        if (fVar22 <= fVar19) break;
                    }
                }
                pcVar12 = pcVar16;
                arg3 = (int64_t)puStackX_18;
                fVar20 = fVar19;
            } while (pcVar16 < pcVar17);
        }
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)pcVar12, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
        fStack_b8 = *(float *)arg2;
        if (fVar20 <= fVar21) {
            fVar20 = fVar21;
        }
        uStack_b0 = *(undefined4 *)arg3;
        fStack_b4 = *(float *)(arg2 + 4);
        uStack_ac = *(undefined4 *)(arg3 + 4);
        uStack_a8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_a4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        puStackX_18 = (undefined4 *)CONCAT44((float)(int32_t)fStack_b4, (float)(int32_t)(fVar20 + fStack_b8));
        fStack_9c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = fcn.1800f5fa0(&uStack_a8);
        var_e0h = CONCAT62((unkint6)((uint64_t)&stack0x00000038 >> 0x10), *(undefined2 *)(iVar3 + 0x30));
        var_e8h = (int64_t)uVar14;
        func_0x00018012f6c0(iVar3, arg1, fVar1, &puStackX_18, var_e8h, var_e0h, &fStack_b8);
    }
    iVar9 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar13 + 0x29f8) != '\0') {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar9 + 0x2a20) = 0;
        if ((arg_28h == (char *)0x0) && (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff))
        {
            while (*arg_28h != '\0') {
                pcVar17 = arg_28h + 1;
                if (((*arg_28h == '#') && (*pcVar17 == '#')) ||
                   (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar22 = *(float *)(iVar9 + 0xde0);
        if (*(float *)(iVar9 + 0xde0) <= *(float *)(iVar9 + 0xdf0)) {
            fVar22 = *(float *)(iVar9 + 0xdf0);
        }
        fVar1 = *(float *)(iVar9 + 0x2a30);
        fVar18 = *(float *)(arg2 + 4);
        *(undefined4 *)(iVar9 + 0x2a30) = *(undefined4 *)(arg2 + 4);
        if (fVar22 + fVar1 + 1.0 < fVar18) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar9 + 0x29f9) = 1;
        }
        if (iVar13 != 0) {
            iVar11 = func_0x000180498cd0(iVar13);
            func_0x000180112520(arg2, iVar13, iVar11 + iVar13);
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        iVar6 = *(int32_t *)(iVar9 + 0x2a34);
        if (iVar5 < iVar6) {
            *(int32_t *)(iVar9 + 0x2a34) = iVar5;
            iVar6 = iVar5;
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        while( true ) {
            pcVar12 = (char *)func_0x000180498a80(in_stack_00000028, 10, (int64_t)arg_28h - (int64_t)in_stack_00000028);
            pcVar17 = arg_28h;
            if (pcVar12 != (char *)0x0) {
                pcVar17 = pcVar12;
            }
            if ((in_stack_00000028 == pcVar17) && (pcVar17 == arg_28h)) break;
            iVar15 = (iVar5 - iVar6) * 4;
            if (*(char *)(iVar9 + 0x29f9) == '\0') {
                iVar15 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar15, 0x1805aadb1, (int32_t)pcVar17 - (int32_t)in_stack_00000028, 
                                in_stack_00000028);
            *(undefined *)(iVar9 + 0x29f9) = 0;
            if (*pcVar17 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar9 + 0x29f9) = 1;
            }
            if (pcVar17 == arg_28h) break;
            in_stack_00000028 = pcVar17 + 1;
        }
        if (iVar3 != 0) {
            iVar13 = func_0x000180498cd0(iVar3);
            func_0x000180112520(arg2, iVar3, iVar13 + iVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7832
// Address: 0x1800f7832
// Size: 461 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: Variable defined which should be unmapped: var_e0h
// WARNING: Variable defined which should be unmapped: var_d8h
// WARNING: Variable defined which should be unmapped: var_d0h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Removing arg arg_77h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_6fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_7fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_4fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_5fh because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_57h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_61h
// WARNING: [rz-ghidra] Detected overlap for variable var_69h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_6dh
// WARNING: [rz-ghidra] Removing arg arg_63h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_55h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.1800f7480(int64_t arg1, int64_t arg2, int64_t arg3)
{
    float fVar1;
    uint16_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 *puVar7;
    int32_t *piVar8;
    int64_t iVar9;
    uint32_t *puVar10;
    int64_t iVar11;
    char *pcVar12;
    int64_t iVar13;
    uint32_t uVar14;
    int32_t iVar15;
    char *arg_28h;
    char *pcVar16;
    char *pcVar17;
    float fVar18;
    float fVar19;
    float in_XMM3_Da;
    float fVar20;
    float fVar21;
    float fVar22;
    undefined4 *puStackX_18;
    int64_t var_20h;
    char *in_stack_00000028;
    uint32_t uStack0000000000000030;
    undefined4 uStack0000000000000034;
    char **in_stack_00000038;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    float fStack_b8;
    float fStack_b4;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    undefined4 uStack_a8;
    undefined4 uStack_a4;
    undefined4 uStack_a0;
    float fStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_79h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar13 = *(int64_t *)0x180781f28;
    arg_28h = _uStack0000000000000030;
    if ((_uStack0000000000000030 == (char *)0x0) &&
       (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff)) {
        while (*arg_28h != '\0') {
            pcVar17 = arg_28h + 1;
            if (((*arg_28h == '#') && (*pcVar17 == '#')) || (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff))
            break;
        }
    }
    puStackX_18 = (undefined4 *)arg3;
    if (in_stack_00000038 == (char **)0x0) {
        var_e8h = var_e8h & 0xffffffff00000000;
        puVar7 = (undefined8 *)func_0x0001800fe0a0(&stack0x00000030, in_stack_00000028, arg_28h, 0, var_e8h);
    } else {
        puVar7 = (undefined8 *)&stack0x00000030;
        _uStack0000000000000030 = *in_stack_00000038;
    }
    in_stack_00000038 = (char **)*puVar7;
    if (SUB84(in_stack_00000038, 0) <= *(float *)arg3 - *(float *)arg2) {
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)arg_28h, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
    } else {
        iVar9 = *(int64_t *)(arg1 + 0x38);
        iVar3 = *(int64_t *)(iVar9 + 0x18);
        fVar22 = *(float *)(iVar9 + 0x24);
        fVar1 = *(float *)(iVar9 + 0x20);
        piVar8 = (int32_t *)func_0x00018012ec80(iVar3);
        uVar2 = *(uint16_t *)(iVar3 + 0x30);
        if ((*piVar8 <= (int32_t)(uint32_t)uVar2) ||
           (fVar18 = *(float *)(*(int64_t *)(piVar8 + 2) + (uint64_t)uVar2 * 4), fVar18 < 0.0)) {
            fVar18 = (float)func_0x00018012bbd0(piVar8, (uint64_t)uVar2);
        }
        fVar20 = *(float *)arg3;
        if (*(float *)arg3 <= in_XMM3_Da) {
            fVar20 = in_XMM3_Da;
        }
        fVar22 = (fVar20 - fVar22 * fVar18) - *(float *)arg2;
        if (fVar22 <= 1.0) {
            fVar22 = 1.0;
        }
        pcVar17 = arg_28h;
        if (arg_28h == (char *)0x0) {
            iVar9 = func_0x000180498cd0(in_stack_00000028);
            pcVar17 = in_stack_00000028 + iVar9;
        }
        puVar10 = (uint32_t *)func_0x00018012ec80(iVar3);
        fVar21 = 0.0;
        fVar20 = 0.0;
        fVar18 = (float)puVar10[5];
        pcVar12 = in_stack_00000028;
        if (in_stack_00000028 < pcVar17) {
            do {
                uVar14 = (uint32_t)*pcVar12;
                _uStack0000000000000030 = (char *)CONCAT44(uStack0000000000000034, uVar14);
                if (uVar14 < 0x80) {
                    pcVar16 = pcVar12 + 1;
                } else {
                    iVar5 = func_0x0001800f5c80(&stack0x00000030, pcVar12, pcVar17);
                    pcVar16 = pcVar12 + iVar5;
                    uVar14 = uStack0000000000000030;
                }
                if (uVar14 == 10) {
                    if (fVar21 <= fVar20) {
                        fVar21 = fVar20;
                    }
                    fVar19 = 0.0;
                } else {
                    fVar19 = fVar20;
                    if (uVar14 != 0xd) {
                        if ((*puVar10 <= uVar14) ||
                           (fVar19 = *(float *)(*(int64_t *)(puVar10 + 2) + (uint64_t)uVar14 * 4), fVar19 < 0.0)) {
                            fVar19 = (float)func_0x00018012bbd0(puVar10);
                        }
                        fVar19 = fVar19 * (fVar1 / fVar18) + fVar20;
                        arg3 = (int64_t)puStackX_18;
                        if (fVar22 <= fVar19) break;
                    }
                }
                pcVar12 = pcVar16;
                arg3 = (int64_t)puStackX_18;
                fVar20 = fVar19;
            } while (pcVar16 < pcVar17);
        }
        puStackX_18 = (undefined4 *)0x0;
        fcn.1800f6fc0(arg1, arg2, arg3, (int64_t)in_stack_00000028, (int64_t)pcVar12, (int64_t)&stack0x00000038, 
                      (int64_t)&puStackX_18, 0);
        fStack_b8 = *(float *)arg2;
        if (fVar20 <= fVar21) {
            fVar20 = fVar21;
        }
        uStack_b0 = *(undefined4 *)arg3;
        fStack_b4 = *(float *)(arg2 + 4);
        uStack_ac = *(undefined4 *)(arg3 + 4);
        uStack_a8 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed0);
        uStack_a4 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed4);
        uStack_a0 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xed8);
        puStackX_18 = (undefined4 *)CONCAT44((float)(int32_t)fStack_b4, (float)(int32_t)(fVar20 + fStack_b8));
        fStack_9c = *(float *)(*(int64_t *)0x180781f28 + 0xedc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        uVar14 = fcn.1800f5fa0(&uStack_a8);
        var_e0h = CONCAT62((unkint6)((uint64_t)&stack0x00000038 >> 0x10), *(undefined2 *)(iVar3 + 0x30));
        var_e8h = (int64_t)uVar14;
        func_0x00018012f6c0(iVar3, arg1, fVar1, &puStackX_18, var_e8h, var_e0h, &fStack_b8);
    }
    iVar9 = *(int64_t *)0x180781f28;
    if (*(char *)(iVar13 + 0x29f8) != '\0') {
        iVar13 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a20);
        iVar3 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x2a28);
        iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a28) = 0;
        *(undefined8 *)(iVar9 + 0x2a20) = 0;
        if ((arg_28h == (char *)0x0) && (arg_28h = in_stack_00000028, in_stack_00000028 != (char *)0xffffffffffffffff))
        {
            while (*arg_28h != '\0') {
                pcVar17 = arg_28h + 1;
                if (((*arg_28h == '#') && (*pcVar17 == '#')) ||
                   (arg_28h = pcVar17, pcVar17 == (char *)0xffffffffffffffff)) break;
            }
        }
        fVar22 = *(float *)(iVar9 + 0xde0);
        if (*(float *)(iVar9 + 0xde0) <= *(float *)(iVar9 + 0xdf0)) {
            fVar22 = *(float *)(iVar9 + 0xdf0);
        }
        fVar1 = *(float *)(iVar9 + 0x2a30);
        fVar18 = *(float *)(arg2 + 4);
        *(undefined4 *)(iVar9 + 0x2a30) = *(undefined4 *)(arg2 + 4);
        if (fVar22 + fVar1 + 1.0 < fVar18) {
            func_0x0001801124e0(0x180644f68);
            *(undefined *)(iVar9 + 0x29f9) = 1;
        }
        if (iVar13 != 0) {
            iVar11 = func_0x000180498cd0(iVar13);
            func_0x000180112520(arg2, iVar13, iVar11 + iVar13);
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        iVar6 = *(int32_t *)(iVar9 + 0x2a34);
        if (iVar5 < iVar6) {
            *(int32_t *)(iVar9 + 0x2a34) = iVar5;
            iVar6 = iVar5;
        }
        iVar5 = *(int32_t *)(iVar4 + 0x1e0);
        while( true ) {
            pcVar12 = (char *)func_0x000180498a80(in_stack_00000028, 10, (int64_t)arg_28h - (int64_t)in_stack_00000028);
            pcVar17 = arg_28h;
            if (pcVar12 != (char *)0x0) {
                pcVar17 = pcVar12;
            }
            if ((in_stack_00000028 == pcVar17) && (pcVar17 == arg_28h)) break;
            iVar15 = (iVar5 - iVar6) * 4;
            if (*(char *)(iVar9 + 0x29f9) == '\0') {
                iVar15 = 1;
            }
            func_0x0001801124e0(0x180644f70, iVar15, 0x1805aadb1, (int32_t)pcVar17 - (int32_t)in_stack_00000028, 
                                in_stack_00000028);
            *(undefined *)(iVar9 + 0x29f9) = 0;
            if (*pcVar17 == '\n') {
                func_0x0001801124e0(0x180644f68);
                *(undefined *)(iVar9 + 0x29f9) = 1;
            }
            if (pcVar17 == arg_28h) break;
            in_stack_00000028 = pcVar17 + 1;
        }
        if (iVar3 != 0) {
            iVar13 = func_0x000180498cd0(iVar3);
            func_0x000180112520(arg2, iVar3, iVar13 + iVar3);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7a00
// Address: 0x1800f7a00
// Size: 67 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7a00(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    float fVar1;
    int64_t iVar2;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_74h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    int64_t var_4ch;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fcn.180126550(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(unaff_XMM7_Dd, unaff_XMM7_Dc));
    if (((char)placeholder_3 != '\0') && (fVar1 = *(float *)(iVar2 + 0xde8), 0.0 < fVar1)) {
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf30);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf34);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf38);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf3c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
    }
    return;
}

// ============================================================
// Function: FUN_1800f7a43
// Address: 0x1800f7a43
// Size: 69 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7a00(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    float fVar1;
    int64_t iVar2;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_74h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    int64_t var_4ch;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fcn.180126550(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(unaff_XMM7_Dd, unaff_XMM7_Dc));
    if (((char)placeholder_3 != '\0') && (fVar1 = *(float *)(iVar2 + 0xde8), 0.0 < fVar1)) {
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf30);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf34);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf38);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf3c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
    }
    return;
}

// ============================================================
// Function: FUN_1800f7a88
// Address: 0x1800f7a88
// Size: 268 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7a00(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    float fVar1;
    int64_t iVar2;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_74h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    int64_t var_4ch;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fcn.180126550(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(unaff_XMM7_Dd, unaff_XMM7_Dc));
    if (((char)placeholder_3 != '\0') && (fVar1 = *(float *)(iVar2 + 0xde8), 0.0 < fVar1)) {
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf30);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf34);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf38);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf3c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
    }
    return;
}

// ============================================================
// Function: FUN_1800f7b94
// Address: 0x1800f7b94
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Removing arg arg_4ch because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7a00(int64_t arg1, int64_t arg2, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h)
{
    float fVar1;
    int64_t iVar2;
    undefined4 unaff_XMM7_Dc;
    undefined4 unaff_XMM7_Dd;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_74h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    int64_t var_4ch;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)0x180781f28;
    fcn.180126550(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(unaff_XMM7_Dd, unaff_XMM7_Dc));
    if (((char)placeholder_3 != '\0') && (fVar1 = *(float *)(iVar2 + 0xde8), 0.0 < fVar1)) {
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf30);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf34);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf38);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf3c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
        var_58h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
        var_58h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
        uStack_50 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
        var_4ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_58h);
        fcn.180126460(CONCAT44(var_98h._4_4_, (undefined4)arg_28h), CONCAT44(var_88h._4_4_, fVar1));
    }
    return;
}

// ============================================================
// Function: FUN_1800f7bc0
// Address: 0x1800f7bc0
// Size: 313 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_78h
// WARNING: Variable defined which should be unmapped: var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7bc0(int64_t arg1, int64_t arg2)
{
    float fVar1;
    undefined4 in_XMM2_Da;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    undefined4 uStack_38;
    int64_t var_34h;
    int64_t var_28h;
    int64_t var_18h;
    
    fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0xde8);
    if (0.0 < fVar1) {
        var_40h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf30);
        var_40h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf34);
        uStack_38 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf38);
        var_34h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf3c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_40h);
        fcn.180126460(CONCAT44(var_78h._4_4_, in_XMM2_Da), CONCAT44(var_68h._4_4_, fVar1));
        var_40h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf20);
        var_40h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf24);
        uStack_38 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xf28);
        var_34h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xf2c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
        fcn.1800f5fa0(&var_40h);
        fcn.180126460(CONCAT44(var_78h._4_4_, in_XMM2_Da), CONCAT44(var_68h._4_4_, fVar1));
    }
    return;
}

// ============================================================
// Function: FUN_1800f7d00
// Address: 0x1800f7d00
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7d42
// Address: 0x1800f7d42
// Size: 28 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7d5e
// Address: 0x1800f7d5e
// Size: 262 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7e64
// Address: 0x1800f7e64
// Size: 73 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7ead
// Address: 0x1800f7ead
// Size: 204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7f79
// Address: 0x1800f7f79
// Size: 99 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f7fdc
// Address: 0x1800f7fdc
// Size: 43 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f8007
// Address: 0x1800f8007
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f800f
// Address: 0x1800f800f
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1800f7d00(int64_t arg1, int64_t arg2, int64_t arg_a8h)
{
    int32_t *piVar1;
    float fVar2;
    float fVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t iVar6;
    bool bVar7;
    int32_t iVar8;
    int32_t iVar9;
    int64_t iVar10;
    uint64_t in_R8;
    float fVar11;
    float fVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    undefined4 uVar16;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_6ch;
    undefined4 uStack_64;
    undefined4 uStack_60;
    float var_5ch;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    if (((((int32_t)arg2 == *(int32_t *)(*(int64_t *)0x180781f28 + 0x21d0)) &&
         ((*(char *)(*(int64_t *)0x180781f28 + 0x21cc) != '\0' || ((in_R8 & 4) != 0)))) &&
        (((int32_t)arg2 != *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8) ||
         ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x1fbc) & 2) == 0)))) &&
       (iVar4 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0), *(char *)(iVar4 + 0x1b9) == '\0')) {
        if ((in_R8 & 8) == 0) {
            uVar16 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xde4);
        } else {
            uVar16 = 0;
        }
        fVar14 = *(float *)(iVar4 + 700);
        fVar15 = *(float *)(iVar4 + 0x2b8);
        fVar2 = *(float *)(iVar4 + 0x2c4);
        fVar3 = *(float *)(iVar4 + 0x2c0);
        fVar12 = *(float *)(arg1 + 4);
        if (*(float *)(arg1 + 4) <= fVar14) {
            fVar12 = fVar14;
        }
        fVar13 = *(float *)arg1;
        if (*(float *)arg1 <= fVar15) {
            fVar13 = fVar15;
        }
        var_6ch._0_4_ = *(float *)(arg1 + 0xc);
        if (fVar2 <= *(float *)(arg1 + 0xc)) {
            var_6ch._0_4_ = fVar2;
        }
        fVar11 = *(float *)(arg1 + 8);
        if (fVar3 <= *(float *)(arg1 + 8)) {
            fVar11 = fVar3;
        }
        if ((in_R8 & 2) == 0) {
            fVar13 = fVar13 - 4.0;
            fVar12 = fVar12 - 4.0;
            fVar11 = fVar11 + 4.0;
            var_6ch._0_4_ = (float)var_6ch + 4.0;
            if ((((fVar13 < fVar15) || (fVar12 < fVar14)) || (fVar3 < fVar11)) || (fVar2 < (float)var_6ch)) {
                bVar7 = false;
                iVar5 = *(int64_t *)(iVar4 + 800);
                fVar14 = fVar13;
                if (fVar13 <= fVar11) {
                    fVar14 = fVar11;
                }
                fVar15 = fVar12;
                if (fVar12 <= (float)var_6ch) {
                    fVar15 = (float)var_6ch;
                }
                piVar1 = (int32_t *)(iVar5 + 0xa0);
                iVar8 = *(int32_t *)(iVar5 + 0xa4);
                if (*piVar1 == iVar8) {
                    iVar9 = *piVar1 + 1;
                    if (iVar8 == 0) {
                        iVar8 = 8;
                    } else {
                        iVar8 = iVar8 / 2 + iVar8;
                    }
                    if (iVar9 < iVar8) {
                        iVar9 = iVar8;
                    }
                    func_0x00018011faa0(piVar1, iVar9);
                }
                iVar10 = (int64_t)*piVar1;
                iVar6 = *(int64_t *)(iVar5 + 0xa8);
                *(float *)(iVar6 + iVar10 * 0x10) = fVar13;
                *(float *)(iVar6 + 4 + iVar10 * 0x10) = fVar12;
                *(float *)(iVar6 + 8 + iVar10 * 0x10) = fVar14;
                *(float *)(iVar6 + 0xc + iVar10 * 0x10) = fVar15;
                *piVar1 = *piVar1 + 1;
                *(float *)(iVar5 + 0x60) = fVar13;
                *(float *)(iVar5 + 100) = fVar12;
                *(float *)(iVar5 + 0x68) = fVar14;
                *(float *)(iVar5 + 0x6c) = fVar15;
                func_0x0001801242c0(iVar5);
            } else {
                bVar7 = true;
            }
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
            if (!bVar7) {
                func_0x0001801245e0(*(undefined8 *)(iVar4 + 800));
            }
        } else {
            var_6ch._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1270);
            uStack_64 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1274);
            uStack_60 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1278);
            var_5ch = *(float *)(*(int64_t *)0x180781f28 + 0x127c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fcn.1800f5fa0((int64_t)&var_6ch + 4);
            fcn.180126460(CONCAT44(var_98h._4_4_, uVar16), CONCAT44(var_88h._4_4_, 0x40000000));
        }
    }
    return;
}

// ============================================================
// Function: FUN_1800f8020
// Address: 0x1800f8020
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_178h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_154h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h

void fcn.1800f8020(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int32_t *piVar1;
    int64_t *piVar2;
    undefined4 *puVar3;
    float fVar4;
    uint8_t *puVar5;
    int64_t iVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t iVar11;
    int32_t iVar12;
    int64_t iVar13;
    int64_t iVar14;
    undefined8 *puVar15;
    int32_t iVar16;
    int64_t *piVar17;
    uint32_t uVar18;
    int64_t iVar19;
    int64_t iVar20;
    float fVar21;
    float in_XMM1_Da;
    undefined4 in_XMM1_Db;
    undefined4 in_XMM1_Dc;
    undefined4 in_XMM1_Dd;
    float fVar22;
    undefined auVar23 [16];
    undefined auVar24 [16];
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    int64_t var_18h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_188h;
    int64_t var_180h;
    undefined4 var_178h;
    undefined4 uStack_174;
    undefined4 uStack_170;
    undefined4 uStack_16c;
    int64_t var_168h;
    float var_160h;
    float var_15ch;
    int64_t var_158h;
    float var_150h;
    float var_14ch;
    float fStack_148;
    float fStack_144;
    float fStack_140;
    float fStack_13c;
    float fStack_138;
    float fStack_134;
    float fStack_130;
    float fStack_12c;
    undefined8 uStack_128;
    undefined8 uStack_120;
    undefined4 uStack_118;
    undefined4 uStack_114;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    undefined auStack_108 [8];
    undefined4 uStack_100;
    float fStack_fc;
    undefined auStack_f8 [8];
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    uint64_t uStack_e8;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_20h;
    
    iVar11 = *(int64_t *)0x180781f28;
    uStack_e8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    uVar18 = (uint32_t)arg3;
    if (10 < uVar18) {
        uVar18 = 0;
    }
    piVar17 = *(int64_t **)(*(int64_t *)0x180781f28 + 0x2158);
    puVar5 = *(uint8_t **)(*(int64_t *)0x180781f28 + 0x1320);
    piVar2 = piVar17 + *(int32_t *)(*(int64_t *)0x180781f28 + 0x2150);
    var_188h._0_4_ = in_XMM1_Da;
    iVar14 = *(int64_t *)0x180781f28;
    for (; var_168h = arg1, piVar17 != piVar2; piVar17 = piVar17 + 1) {
        _auStack_108 = ZEXT816(0);
        _auStack_f8 = ZEXT816(0);
        if ((uVar18 < 0xb) && ((*puVar5 & 2) == 0)) {
            iVar6 = *(int64_t *)(puVar5 + 0x2b0);
            fVar27 = *(float *)(puVar5 + 0x54);
            iVar20 = *piVar17;
            var_168h._4_4_ = (float)((uint64_t)arg1 >> 0x20);
            var_168h._0_4_ = (float)arg1;
            iVar19 = (int64_t)(*(int32_t *)
                                (*(int64_t *)(iVar6 + 0x78) + (uint64_t)(*(uint32_t *)(iVar6 + 0xec) & 0x7ffff) * 4) <<
                              0xc) >> 0xc;
            iVar13 = (int64_t)(int32_t)uVar18;
            fVar21 = *(float *)(iVar13 * 0x18 + 0x18061ee58);
            fVar28 = var_168h._4_4_ - *(float *)(iVar13 * 0x18 + 0x18061ee64);
            fVar4 = *(float *)(iVar13 * 0x18 + 0x18061ee5c);
            fVar29 = (float)var_168h - *(float *)(iVar13 * 0x18 + 0x18061ee60);
            fVar25 = (float)(uint32_t)*(uint16_t *)(*(int64_t *)(iVar6 + 0x68) + iVar19 * 8) +
                     *(float *)(iVar13 * 0x18 + 0x18061ee50);
            fVar22 = (float)(uint32_t)*(uint16_t *)(*(int64_t *)(iVar6 + 0x68) + 2 + iVar19 * 8) +
                     *(float *)(iVar13 * 0x18 + 0x18061ee54);
            auStack_108._4_4_ = fVar22 * *(float *)(puVar5 + 0x58);
            fStack_fc = (fVar4 + fVar22) * *(float *)(puVar5 + 0x58);
            auStack_108._0_4_ = fVar25 * fVar27;
            uStack_100 = (fVar21 + fVar25) * fVar27;
            auStack_f8._4_4_ = auStack_108._4_4_;
            auStack_f8._0_4_ = (fVar25 + 123.0) * fVar27;
            uStack_f0 = (fVar21 + fVar25 + 123.0) * fVar27;
            uStack_ec = fStack_fc;
            var_180h._0_4_ = fVar29;
            var_180h._4_4_ = fVar28;
            if (fVar28 < *(float *)(iVar20 + 0xc) + *(float *)(iVar20 + 0x14)) {
                fVar27 = in_XMM1_Da * *(float *)(iVar20 + 0x30);
                if (((*(float *)(iVar20 + 0xc) < (fVar4 + 2.0) * fVar27 + fVar28) &&
                    (fVar29 < *(float *)(iVar20 + 8) + *(float *)(iVar20 + 0x10))) &&
                   (fVar22 = (fVar21 + 2.0) * fVar27 + fVar29, *(float *)(iVar20 + 8) < fVar22)) {
                    if (iVar20 == 0) {
                        iVar20 = *(int64_t *)(*(int64_t *)(iVar14 + 0x15e0) + 0x48);
                    }
                    iVar14 = func_0x0001800fa7f0(iVar20, 1, 0x1806444d0);
                    uVar7 = *(undefined4 *)(puVar5 + 0x28);
                    uVar8 = *(undefined4 *)(puVar5 + 0x2c);
                    uVar9 = *(undefined4 *)(puVar5 + 0x30);
                    uVar10 = *(undefined4 *)(puVar5 + 0x34);
                    iVar12 = *(int32_t *)(iVar14 + 0xb4);
                    piVar1 = (int32_t *)(iVar14 + 0xb0);
                    if (*piVar1 == iVar12) {
                        iVar16 = *piVar1 + 1;
                        if (iVar12 == 0) {
                            iVar12 = 8;
                        } else {
                            iVar12 = iVar12 / 2 + iVar12;
                        }
                        if (iVar16 < iVar12) {
                            iVar16 = iVar12;
                        }
                        func_0x00018011faa0(piVar1, iVar16);
                    }
                    puVar3 = (undefined4 *)(*(int64_t *)(iVar14 + 0xb8) + (int64_t)*piVar1 * 0x10);
                    *puVar3 = uVar7;
                    puVar3[1] = uVar8;
                    puVar3[2] = uVar9;
                    puVar3[3] = uVar10;
                    *piVar1 = *piVar1 + 1;
                    *(undefined4 *)(iVar14 + 0x70) = uVar7;
                    *(undefined4 *)(iVar14 + 0x74) = uVar8;
                    *(undefined4 *)(iVar14 + 0x78) = uVar9;
                    *(undefined4 *)(iVar14 + 0x7c) = uVar10;
                    func_0x000180124360(iVar14);
                    var_198h._0_4_ = 0x30000000;
                    var_1a0h = (int64_t)(auStack_f8 + 8);
                    var_1a8h = (int64_t)auStack_f8;
                    var_160h = (fVar21 + 1.0) * fVar27 + fVar29;
                    fVar25 = fVar27 * 0.0 + fVar28;
                    fVar26 = (fVar4 + 0.0) * fVar27 + fVar28;
                    var_158h._0_4_ = fVar27 + fVar29;
                    var_178h = uVar7;
                    uStack_174 = uVar8;
                    uStack_170 = uVar9;
                    uStack_16c = uVar10;
                    var_15ch = fVar26;
                    var_158h._4_4_ = fVar25;
                    func_0x0001801268f0(iVar14, &var_178h, &var_158h, &var_160h);
                    var_198h._0_4_ = 0x30000000;
                    var_1a0h = (int64_t)(auStack_f8 + 8);
                    var_1a8h = (int64_t)auStack_f8;
                    fStack_148 = fVar27 + fVar27 + fVar29;
                    var_178h = uVar7;
                    uStack_174 = uVar8;
                    uStack_170 = uVar9;
                    uStack_16c = uVar10;
                    var_150h = fVar22;
                    var_14ch = fVar26;
                    fStack_144 = fVar25;
                    func_0x0001801268f0(iVar14, &var_178h, &fStack_148, &var_150h);
                    var_198h._0_4_ = 0xff000000;
                    var_1a0h = (int64_t)(auStack_f8 + 8);
                    fStack_140 = fVar27 * fVar21 + fVar29;
                    var_1a8h = (int64_t)auStack_f8;
                    fStack_13c = fVar27 * fVar4 + fVar28;
                    var_178h = uVar7;
                    uStack_174 = uVar8;
                    uStack_170 = uVar9;
                    uStack_16c = uVar10;
                    func_0x0001801268f0(iVar14, &var_178h, &var_180h, &fStack_140);
                    fStack_138 = fVar27 * fVar21 + fVar29;
                    fStack_134 = fVar27 * fVar4 + fVar28;
                    var_1a0h = (int64_t)(auStack_108 + 8);
                    var_198h._0_4_ = 0xffffffff;
                    var_1a8h = (int64_t)auStack_108;
                    var_178h = uVar7;
                    uStack_174 = uVar8;
                    uStack_170 = uVar9;
                    uStack_16c = uVar10;
                    func_0x0001801268f0(iVar14, &var_178h, &var_180h, &fStack_138);
                    if (uVar18 - 8 < 2) {
                        fVar21 = (float)func_0x000180490df0((float)*(double *)(iVar11 + 0x18) * 5.0, 0x40c90fdb);
                        var_1a0h = var_1a0h & 0xffffffff00000000;
                        auVar23._4_4_ = in_XMM1_Db;
                        auVar23._0_4_ = fVar27;
                        auVar23._8_4_ = in_XMM1_Dc;
                        auVar23._12_4_ = in_XMM1_Dd;
                        auVar24._4_12_ = auVar23._4_12_;
                        auVar24._0_4_ = fVar27 * 6.0;
                        fStack_130 = fVar27 * 14.0 + fVar29;
                        fStack_12c = fVar28 - fVar27 * 1.0;
                        var_1a8h = CONCAT44(var_1a8h._4_4_, fVar21 + 5.183628);
                        func_0x000180125bc0(iVar14, &fStack_130, auVar24._0_8_, fVar21);
                        var_1a0h = CONCAT44(var_1a0h._4_4_, fVar27 * 3.0);
                        var_1a8h = var_1a8h & 0xffffffff00000000;
                        func_0x0001801248e0(iVar14, *(undefined8 *)(iVar14 + 0x58), *(undefined4 *)(iVar14 + 0x50), 
                                            0xffffffff);
                        *(undefined4 *)(iVar14 + 0x50) = 0;
                    }
                    iVar12 = *piVar1;
                    iVar16 = iVar12 + -1;
                    *piVar1 = iVar16;
                    if (iVar16 == 0) {
                        uStack_128 = 0;
                        puVar15 = &uStack_128;
                        uStack_120 = 0;
                    } else {
                        puVar3 = (undefined4 *)(*(int64_t *)(iVar14 + 0xb8) + ((int64_t)iVar12 + -2) * 0x10);
                        puVar15 = (undefined8 *)&uStack_118;
                        uStack_118 = *puVar3;
                        uStack_114 = puVar3[1];
                        uStack_110 = puVar3[2];
                        uStack_10c = puVar3[3];
                    }
                    uVar7 = *(undefined4 *)((int64_t)puVar15 + 4);
                    uVar8 = *(undefined4 *)(puVar15 + 1);
                    uVar9 = *(undefined4 *)((int64_t)puVar15 + 0xc);
                    *(undefined4 *)(iVar14 + 0x70) = *(undefined4 *)puVar15;
                    *(undefined4 *)(iVar14 + 0x74) = uVar7;
                    *(undefined4 *)(iVar14 + 0x78) = uVar8;
                    *(undefined4 *)(iVar14 + 0x7c) = uVar9;
                    func_0x000180124360(iVar14);
                    iVar14 = *(int64_t *)0x180781f28;
                }
                in_XMM1_Db = 0;
                in_XMM1_Dc = 0;
                in_XMM1_Dd = 0;
                in_XMM1_Da = (float)var_188h;
            }
        }
        arg1 = var_168h;
    }
    func_0x000180459870(uStack_e8 ^ (uint64_t)auStack_1c8);
    return;
}

