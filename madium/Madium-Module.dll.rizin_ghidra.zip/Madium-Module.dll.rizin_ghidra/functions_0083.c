// Chunk 83 - 50 functions

// ============================================================
// Function: FUN_180116d20
// Address: 0x180116d20
// Size: 108 bytes
// ============================================================
void fcn.180116d20(int64_t arg1, int64_t arg2)
{
    float fVar1;
    float fVar2;
    int64_t iVar3;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar3 = *(int64_t *)0x180781f28;
    fcn.1800faa00(arg2);
    fVar1 = *(float *)(arg1 + 0x4c);
    fVar2 = *(float *)(arg1 + 0x48);
    *(int64_t *)(iVar3 + 0x1600) = arg2;
    *(float *)(iVar3 + 0x1670) = *(float *)(iVar3 + 0xb00) - fVar1;
    *(float *)(iVar3 + 0x166c) = *(float *)(iVar3 + 0xafc) - fVar2;
    *(uint8_t *)(arg1 + 0xdd) = *(uint8_t *)(arg1 + 0xdd) & 0xfe;
    return;
}

// ============================================================
// Function: FUN_180116d90
// Address: 0x180116d90
// Size: 923 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_18011712b
// Address: 0x18011712b
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_180117133
// Address: 0x180117133
// Size: 933 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_1801174d8
// Address: 0x1801174d8
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_180117569
// Address: 0x180117569
// Size: 130 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_1801175eb
// Address: 0x1801175eb
// Size: 648 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_180117873
// Address: 0x180117873
// Size: 385 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_1801179f4
// Address: 0x1801179f4
// Size: 174 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_180117aa2
// Address: 0x180117aa2
// Size: 32 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.180116d90(int64_t arg1)
{
    int64_t *piVar1;
    undefined8 uVar2;
    undefined uVar3;
    int64_t iVar4;
    int64_t iVar5;
    bool bVar6;
    undefined4 uVar7;
    int64_t iVar8;
    uint8_t uVar9;
    char cVar10;
    int32_t iVar11;
    undefined4 uVar12;
    int64_t iVar13;
    uint32_t uVar14;
    uint32_t uVar15;
    undefined4 *puVar16;
    uint64_t uVar17;
    undefined4 *puVar18;
    undefined4 *puVar19;
    int64_t iVar20;
    undefined2 uVar21;
    int64_t *piVar22;
    undefined2 uVar23;
    undefined4 uVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_d8 [32];
    int64_t var_b8h;
    int64_t var_b0h;
    char var_a8h;
    int64_t var_a4h;
    undefined4 var_9ch;
    undefined var_98h [4];
    int64_t var_94h;
    undefined4 uStack_8c;
    int64_t var_88h;
    float var_80h;
    float var_7ch;
    float var_78h;
    float var_74h;
    float var_70h;
    float var_6ch;
    undefined var_68h [24];
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    
    iVar8 = *(int64_t *)0x180781f28;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_d8;
    puVar18 = (undefined4 *)0x0;
    uVar12 = *(undefined4 *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfb;
    *(undefined4 *)(arg1 + 0xbc) = uVar12;
    *(undefined8 *)(arg1 + 0xb0) = 0;
    *(undefined8 *)(arg1 + 0xa8) = 0;
    iVar20 = iVar8;
    if (*(int64_t *)(arg1 + 0x18) == 0) {
        func_0x000180116a00();
        _var_98h = (undefined4 *)0x0;
        bVar6 = 0 < *(int32_t *)(arg1 + 0x30);
        if (bVar6) {
            _var_98h = (undefined4 *)arg1;
        }
        stack0xffffffffffffff70 = (uint64_t)bVar6;
        stack0xffffffffffffff60 = 0;
        if ((*(uint32_t *)(arg1 + 0x10) & 0x800) != 0) {
            unique0x10000db4 = arg1;
        }
        puVar19 = _var_98h;
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x20), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            func_0x000180116990(*(int64_t *)(arg1 + 0x28), (int64_t)&var_a4h + 4);
            puVar19 = _var_98h;
        }
        *(int64_t *)(arg1 + 0xa8) = stack0xffffffffffffff60;
        *(int32_t *)(arg1 + 0xb8) = var_94h._4_4_;
        puVar16 = puVar18;
        if (var_94h._4_4_ == 1) {
            puVar16 = puVar19;
        }
        *(undefined4 **)(arg1 + 0xb0) = puVar16;
        if (*(int32_t *)(arg1 + 200) == 0) {
            if (puVar19 != (undefined4 *)0x0) {
                *(undefined4 *)(arg1 + 200) = *puVar19;
                goto code_r0x000180116e8f;
            }
        } else {
code_r0x000180116e8f:
            if (puVar19 != (undefined4 *)0x0) {
                iVar20 = **(int64_t **)(puVar19 + 0xe);
                uVar12 = *(undefined4 *)(iVar20 + 0x24);
                uVar24 = *(undefined4 *)(iVar20 + 0x28);
                uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                *(undefined4 *)(arg1 + 0x6c) = uVar12;
                *(undefined4 *)(arg1 + 0x70) = uVar24;
                *(undefined4 *)(arg1 + 0x74) = uVar7;
                uVar12 = *(undefined4 *)(iVar20 + 0x34);
                uVar24 = *(undefined4 *)(iVar20 + 0x38);
                uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                *(undefined4 *)(arg1 + 0x7c) = uVar12;
                *(undefined4 *)(arg1 + 0x80) = uVar24;
                *(undefined4 *)(arg1 + 0x84) = uVar7;
                *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                if (1 < (int32_t)puVar19[0xc]) {
                    uVar17 = 1;
                    do {
                        iVar20 = *(int64_t *)(*(int64_t *)(puVar19 + 0xe) + uVar17 * 8);
                        if (*(char *)(iVar20 + 0x3d) == '\0') {
                            uVar12 = *(undefined4 *)(iVar20 + 0x24);
                            uVar24 = *(undefined4 *)(iVar20 + 0x28);
                            uVar7 = *(undefined4 *)(iVar20 + 0x2c);
                            *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(iVar20 + 0x20);
                            *(undefined4 *)(arg1 + 0x6c) = uVar12;
                            *(undefined4 *)(arg1 + 0x70) = uVar24;
                            *(undefined4 *)(arg1 + 0x74) = uVar7;
                            uVar12 = *(undefined4 *)(iVar20 + 0x34);
                            uVar24 = *(undefined4 *)(iVar20 + 0x38);
                            uVar7 = *(undefined4 *)(iVar20 + 0x3c);
                            *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(iVar20 + 0x30);
                            *(undefined4 *)(arg1 + 0x7c) = uVar12;
                            *(undefined4 *)(arg1 + 0x80) = uVar24;
                            *(undefined4 *)(arg1 + 0x84) = uVar7;
                            *(undefined8 *)(arg1 + 0x88) = *(undefined8 *)(iVar20 + 0x40);
                            break;
                        }
                        uVar14 = (int32_t)uVar17 + 1;
                        uVar17 = (uint64_t)uVar14;
                    } while ((int32_t)uVar14 < (int32_t)puVar19[0xc]);
                }
            }
        }
        iVar20 = *(int64_t *)0x180781f28;
        for (iVar13 = *(int64_t *)(arg1 + 0xa8); *(int64_t *)0x180781f28 = iVar20, iVar13 != 0;
            iVar13 = *(int64_t *)(iVar13 + 0x18)) {
            *(uint8_t *)(iVar13 + 0xdc) = *(uint8_t *)(iVar13 + 0xdc) | 0x20;
            iVar20 = *(int64_t *)0x180781f28;
        }
    }
    if ((*(int64_t *)(arg1 + 0x40) != 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x1000) != 0)) {
        func_0x000180119090(arg1);
        iVar20 = *(int64_t *)0x180781f28;
    }
    if ((*(int64_t *)(arg1 + 0x18) == 0) && ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0)) {
        iVar11 = *(int32_t *)(arg1 + 0x30);
        bVar6 = false;
        if (((iVar11 < 2) && ((*(int64_t *)(arg1 + 0x20) == 0 && (*(char *)(iVar8 + 0x83) == '\0')))) &&
           ((iVar11 == 0 || (*(char *)(**(int64_t **)(arg1 + 0x38) + 0x3c) == '\0')))) {
            bVar6 = true;
        }
        if ((*(int32_t *)(arg1 + 0xb8) == 0) || (bVar6)) {
            if (iVar11 == 1) {
                iVar20 = **(int64_t **)(arg1 + 0x38);
                *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(iVar20 + 0x60);
                uVar2 = *(undefined8 *)(iVar20 + 0x70);
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe92;
                *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) | 0x92;
                *(undefined8 *)(arg1 + 0x50) = uVar2;
                if ((*(int64_t *)(arg1 + 0x98) != 0) && (*(int64_t *)(iVar8 + 0x21d8) == *(int64_t *)(arg1 + 0x98))) {
                    func_0x00018010e050(iVar20, 0);
                }
                if (*(int64_t *)(arg1 + 0x98) != 0) {
                    puVar18 = *(undefined4 **)(*(int64_t *)(arg1 + 0x98) + 0x48);
                    *(undefined4 **)(iVar20 + 0x48) = puVar18;
                    *(undefined4 *)(iVar20 + 0x50) = *(undefined4 *)(*(int64_t *)(arg1 + 0x98) + 0x50);
                    if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x108) != '\0') {
                        *puVar18 = *(undefined4 *)(iVar20 + 0x10);
                        *(int64_t *)(*(int64_t *)(iVar20 + 0x48) + 0x78) = iVar20;
                        *(undefined *)(iVar20 + 0x108) = 1;
                    }
                }
                *(undefined4 *)(arg1 + 0xd4) = *(undefined4 *)(iVar20 + 0x50);
            }
            func_0x0001801168f0(arg1);
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xa7;
            *(undefined4 *)(arg1 + 0x14) = 1;
            *(undefined4 *)(arg1 + 0xd0) = 0;
            *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
            if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int32_t *)(arg1 + 0x30) == 1)) {
                fcn.180116d20(arg1, **(int64_t **)(arg1 + 0x38));
            }
            goto code_r0x000180117aa7;
        }
    }
    if (((((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) == 0)) &&
        (*(int64_t *)(arg1 + 0x18) == 0)) &&
       (((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0 && (*(int64_t *)(arg1 + 0x20) == 0)))) {
        if (*(int32_t *)(arg1 + 0xcc) != 0) {
            piVar22 = *(int64_t **)(arg1 + 0x38);
            piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
            for (; piVar22 != piVar1; piVar22 = piVar22 + 1) {
                iVar13 = *piVar22;
                if (*(int32_t *)(iVar13 + 0x10) == *(int32_t *)(arg1 + 0xcc)) {
                    if (iVar13 != 0) goto code_r0x000180117106;
                    break;
                }
            }
        }
        iVar13 = **(int64_t **)(arg1 + 0x38);
code_r0x000180117106:
        if (('\0' < *(char *)(iVar13 + 0x128)) || ('\0' < *(char *)(iVar13 + 0x129))) {
            *(undefined4 *)(arg1 + 0x14) = 2;
            goto code_r0x000180117aa7;
        }
    }
    uVar14 = *(uint32_t *)(arg1 + 0x10);
    if ((*(int32_t *)(arg1 + 0x30) < 1) || ((uVar14 >> 0xe & 1) != 0)) {
        uVar9 = 0;
    } else {
        uVar9 = 0x10;
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xe7 | uVar9;
    piVar22 = *(int64_t **)(arg1 + 0x38);
    piVar1 = piVar22 + *(int32_t *)(arg1 + 0x30);
    uVar15 = uVar14;
    if (piVar22 != piVar1) {
        do {
            iVar13 = *piVar22;
            *(uint8_t *)(arg1 + 0xdc) =
                 (*(char *)(iVar13 + 0x114) << 3 | *(uint8_t *)(arg1 + 0xdc)) & 8 ^ *(uint8_t *)(arg1 + 0xdc) & 0xf7;
            piVar22 = piVar22 + 1;
            *(uint8_t *)(iVar13 + 0x495) = 1 < *(int32_t *)(arg1 + 0x30) | *(uint8_t *)(iVar13 + 0x495) & 0xfe;
        } while (piVar22 != piVar1);
        uVar15 = *(uint32_t *)(arg1 + 0x10);
    }
    if (((uVar14 >> 0xf & 1) != 0) || (*(char *)(iVar8 + 0xeb8) == '\0')) {
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xf7;
    }
    var_a8h = '\0';
    var_a4h._0_4_ = uVar14;
    if ((uVar15 >> 10 & 1) == 0) {
        iVar13 = *(int64_t *)(arg1 + 0x18);
        if ((iVar13 == 0) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            if (0 < *(int32_t *)(arg1 + 0x30)) {
                puVar18 = (undefined4 *)**(undefined8 **)(arg1 + 0x38);
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1d) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x18);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x18) >> 0x20);
code_r0x00018011725d:
                    *(undefined *)(iVar20 + 0x204c) = 1;
                    *(undefined4 *)(iVar20 + 0x200c) = 1;
                    *(undefined8 *)(iVar20 + 0x2024) = 0;
                    *(uint64_t *)(iVar20 + 0x201c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 1;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x48);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x48) >> 0x20);
                goto code_r0x00018011725d;
            }
            iVar11 = (*(int32_t *)(arg1 + 0xd8) << 0x1a) >> 0x1d;
            if (iVar11 == 2) {
                if (puVar18 != (undefined4 *)0x0) {
                    *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                    uVar12 = (undefined4)*(undefined8 *)(puVar18 + 0x1c);
                    uVar24 = (undefined4)((uint64_t)*(undefined8 *)(puVar18 + 0x1c) >> 0x20);
code_r0x0001801172b1:
                    *(undefined4 *)(iVar20 + 0x2010) = 1;
                    *(uint64_t *)(iVar20 + 0x202c) = CONCAT44(uVar24, uVar12);
                }
            } else if (iVar11 == 1) {
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 2;
                uVar12 = (undefined4)*(undefined8 *)(arg1 + 0x50);
                uVar24 = (undefined4)((uint64_t)*(undefined8 *)(arg1 + 0x50) >> 0x20);
                goto code_r0x0001801172b1;
            }
            if ((((uint8_t)*(undefined4 *)(arg1 + 0xd8) & 0x38) == 0x10) && (puVar18 != (undefined4 *)0x0)) {
                uVar3 = *(undefined *)(puVar18 + 0x43);
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 8;
                *(undefined *)(iVar20 + 0x204d) = uVar3;
                *(undefined4 *)(iVar20 + 0x2014) = 1;
            }
            if ((*(uint32_t *)(arg1 + 0xd8) & 0x1c0) == 0x80) {
                if (puVar18 == (undefined4 *)0x0) {
                    iVar11 = *(int32_t *)(arg1 + 0xd4);
                    if (iVar11 == 0) goto code_r0x000180117328;
                } else {
                    iVar11 = puVar18[0x14];
                }
                *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x800;
                *(int32_t *)(iVar20 + 0x2074) = iVar11;
            }
code_r0x000180117328:
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x2000;
            uVar12 = *(undefined4 *)(arg1 + 0x6c);
            uVar24 = *(undefined4 *)(arg1 + 0x70);
            uVar7 = *(undefined4 *)(arg1 + 0x74);
            var_88h = 0;
            *(undefined4 *)(iVar20 + 0x2080) = *(undefined4 *)(arg1 + 0x68);
            *(undefined4 *)(iVar20 + 0x2084) = uVar12;
            *(undefined4 *)(iVar20 + 0x2088) = uVar24;
            *(undefined4 *)(iVar20 + 0x208c) = uVar7;
            uVar12 = *(undefined4 *)(arg1 + 0x7c);
            uVar24 = *(undefined4 *)(arg1 + 0x80);
            uVar7 = *(undefined4 *)(arg1 + 0x84);
            *(undefined4 *)(iVar20 + 0x2090) = *(undefined4 *)(arg1 + 0x78);
            *(undefined4 *)(iVar20 + 0x2094) = uVar12;
            *(undefined4 *)(iVar20 + 0x2098) = uVar24;
            *(undefined4 *)(iVar20 + 0x209c) = uVar7;
            uVar2 = *(undefined8 *)(arg1 + 0x88);
            *(uint32_t *)(iVar20 + 0x2008) = *(uint32_t *)(iVar20 + 0x2008) | 0x40;
            *(undefined8 *)(iVar20 + 0x20a0) = uVar2;
            *(undefined4 *)(iVar20 + 0x2070) = 0;
            func_0x0001800f6960(2, &var_88h);
            func_0x0001801019f0(var_68h, 0, 0x821139);
            func_0x0001800f6a20(1);
            puVar19 = *(undefined4 **)(arg1 + 0x98);
            puVar18 = *(undefined4 **)(iVar8 + 0x15e0);
            var_a8h = '\x01';
            if (((puVar19 != (undefined4 *)0x0) && (puVar19 != puVar18)) && (*(int64_t *)(puVar19 + 0x132) == arg1)) {
                *(undefined8 *)(puVar19 + 0x132) = 0;
            }
            *(int64_t *)(puVar18 + 0x132) = arg1;
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            uVar12 = puVar18[0x19];
            puVar18[0x56] = puVar18[0x18];
            puVar18[0x57] = uVar12;
            *(undefined4 *)(arg1 + 0x48) = puVar18[0x18];
            *(undefined4 *)(arg1 + 0x4c) = uVar12;
            *(undefined8 *)(arg1 + 0x50) = *(undefined8 *)(puVar18 + 0x1a);
            iVar20 = *(int64_t *)0x180781f28;
            if (*(char *)(*(int64_t *)(arg1 + 0x98) + 0x110) != '\0') {
                func_0x00018010dfb0();
                iVar20 = *(int64_t *)0x180781f28;
            }
code_r0x00018011742f:
            *(uint32_t *)(arg1 + 0xd8) = *(uint32_t *)(arg1 + 0xd8) & 0xfffffe00;
        } else if (iVar13 != 0) {
            puVar18 = *(undefined4 **)(iVar13 + 0x98);
            *(undefined4 **)(arg1 + 0x98) = puVar18;
            goto code_r0x00018011742f;
        }
        if (((*(uint8_t *)(arg1 + 0xdd) & 1) != 0) && (*(int64_t *)(arg1 + 0x98) != 0)) {
            fcn.180116d20(arg1, *(int64_t *)(arg1 + 0x98));
            iVar20 = *(int64_t *)0x180781f28;
        }
    } else {
        puVar18 = *(undefined4 **)(arg1 + 0x98);
    }
    *(undefined4 *)(arg1 + 0xd4) = 0;
    if (((*(int64_t *)(arg1 + 0x18) == 0) && (*(int64_t *)(iVar8 + 0x21d8) != 0)) &&
       (iVar13 = *(int64_t *)(*(int64_t *)(iVar8 + 0x21d8) + 0x418), iVar13 != 0)) {
        while (iVar4 = *(int64_t *)(iVar13 + 0x4c0), iVar4 != 0) {
            iVar5 = *(int64_t *)(iVar4 + 0x18);
            while (iVar5 != 0) {
                iVar4 = *(int64_t *)(iVar4 + 0x18);
                iVar5 = *(int64_t *)(iVar4 + 0x18);
            }
            if (iVar4 == arg1) {
                *(undefined4 *)(arg1 + 200) = **(undefined4 **)(iVar13 + 0x4c0);
                break;
            }
            if ((*(int64_t *)(iVar4 + 0x98) == 0) ||
               (iVar13 = *(int64_t *)(*(int64_t *)(iVar4 + 0x98) + 0x418), iVar13 == 0)) break;
        }
    }
    iVar13 = *(int64_t *)(arg1 + 0xa8);
    if ((*(int64_t *)(arg1 + 0x18) == 0) &&
       ((((puVar18 != (undefined4 *)0x0 && ((uVar14 & 8) != 0)) && (iVar13 != 0)) &&
        ((*(int64_t *)(iVar13 + 0x20) == 0 && (*(int32_t *)(iVar13 + 0x30) == 0)))))) {
        bVar6 = true;
        if (((*(char *)(iVar20 + 0x2400) != '\0') && (*(int32_t *)(iVar20 + 0x2424) != -1)) &&
           (((undefined8 *)(iVar20 + 0x2410) != (undefined8 *)0x0 &&
            ((iVar11 = func_0x000180498f10(0x180644588, iVar20 + 0x2428), iVar11 == 0 &&
             (cVar10 = func_0x0001801191b0(puVar18, **(undefined8 **)(undefined8 *)(iVar20 + 0x2410)), cVar10 != '\0')))
            ))) goto code_r0x00018011768f;
        iVar5 = *(int64_t *)(iVar13 + 0x18);
        iVar4 = iVar13;
        while (iVar5 != 0) {
            iVar4 = *(int64_t *)(iVar4 + 0x18);
            iVar5 = *(int64_t *)(iVar4 + 0x18);
        }
        fVar27 = *(float *)(iVar13 + 0x48);
        fVar26 = *(float *)(iVar13 + 0x4c);
        fVar28 = fVar27 + *(float *)(iVar13 + 0x50);
        fVar25 = fVar26 + *(float *)(iVar13 + 0x54);
        if (*(float *)(iVar4 + 0x48) < fVar27) {
            fVar27 = fVar27 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < *(float *)(iVar4 + 0x48) + *(float *)(iVar4 + 0x50)) {
            fVar28 = fVar28 - *(float *)(iVar8 + 0x15d4);
        }
        if (*(float *)(iVar4 + 0x4c) <= fVar26 && fVar26 != *(float *)(iVar4 + 0x4c)) {
            fVar26 = fVar26 + *(float *)(iVar8 + 0x15d4);
        }
        if (fVar25 < *(float *)(iVar4 + 0x4c) + *(float *)(iVar4 + 0x54)) {
            fVar25 = fVar25 - *(float *)(iVar8 + 0x15d4);
        }
        if (fVar28 < fVar27) goto code_r0x00018011768f;
        if (fVar26 <= fVar25) {
            iVar4 = *(int64_t *)(puVar18 + 0x102);
            uVar23 = (undefined2)(int32_t)(fVar25 - fVar26);
            *(undefined2 *)((int64_t)puVar18 + 0x2da) = uVar23;
            uVar21 = (undefined2)(int32_t)(fVar28 - fVar27);
            *(undefined2 *)(puVar18 + 0xb6) = uVar21;
            *(int16_t *)((int64_t)puVar18 + 0x2de) = (int16_t)(int32_t)(fVar26 - (float)puVar18[0x19]);
            *(int16_t *)(puVar18 + 0xb7) = (int16_t)(int32_t)(fVar27 - (float)puVar18[0x18]);
            if (iVar4 == 0) goto code_r0x00018011768f;
            *(undefined2 *)(iVar4 + 0x2d8) = uVar21;
            *(undefined2 *)(iVar4 + 0x2da) = uVar23;
            *(int16_t *)(iVar4 + 0x2de) = (int16_t)(int32_t)(fVar26 - *(float *)(iVar4 + 100));
            *(int16_t *)(iVar4 + 0x2dc) = (int16_t)(int32_t)(fVar27 - *(float *)(iVar4 + 0x60));
        }
code_r0x000180117698:
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x00018011b1e0(arg1, *(undefined8 *)(puVar18 + 0x18), *(undefined8 *)(puVar18 + 0x1a), 0);
            var_9ch = *(undefined4 *)(iVar20 + 0x1080);
            var_a4h._4_4_ = 0x1b;
            var_98h = (undefined  [4])*(undefined4 *)(iVar20 + 0x1084);
            var_94h._0_4_ = *(undefined4 *)(iVar20 + 0x1088);
            var_94h._4_4_ = *(undefined4 *)(iVar20 + 0x108c);
            func_0x00018011f2b0(iVar20 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1b) {
                uVar12 = *(undefined4 *)(iVar8 + 0xf24);
                uVar24 = *(undefined4 *)(iVar8 + 0xf28);
                uVar7 = *(undefined4 *)(iVar8 + 0xf2c);
                *(undefined4 *)(iVar20 + 0x1080) = *(undefined4 *)(iVar8 + 0xf20);
                *(undefined4 *)(iVar20 + 0x1084) = uVar12;
                *(undefined4 *)(iVar20 + 0x1088) = uVar24;
                *(undefined4 *)(iVar20 + 0x108c) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_94h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10ac);
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a0);
            var_a4h._4_4_ = 0x1d;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a4);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x10a8);
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1d) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10d4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10d8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10dc);
                *(undefined4 *)(iVar20 + 0x10a0) = *(undefined4 *)(iVar8 + 0x10d0);
                *(undefined4 *)(iVar20 + 0x10a4) = uVar12;
                *(undefined4 *)(iVar20 + 0x10a8) = uVar24;
                *(undefined4 *)(iVar20 + 0x10ac) = uVar7;
            }
            iVar20 = *(int64_t *)0x180781f28;
            var_9ch = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1090);
            var_a4h._4_4_ = 0x1c;
            var_98h = (undefined  [4])*(undefined4 *)(*(int64_t *)0x180781f28 + 0x1094);
            var_94h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0x1098);
            stack0xffffffffffffff70 = CONCAT44(uStack_8c, *(undefined4 *)(*(int64_t *)0x180781f28 + 0x109c));
            func_0x00018011f2b0(*(int64_t *)0x180781f28 + 0x20c0, (int64_t)&var_a4h + 4);
            if (*(int32_t *)(iVar20 + 0x20bc) != 0x1c) {
                uVar12 = *(undefined4 *)(iVar8 + 0x10c4);
                uVar24 = *(undefined4 *)(iVar8 + 0x10c8);
                uVar7 = *(undefined4 *)(iVar8 + 0x10cc);
                *(undefined4 *)(iVar20 + 0x1090) = *(undefined4 *)(iVar8 + 0x10c0);
                *(undefined4 *)(iVar20 + 0x1094) = uVar12;
                *(undefined4 *)(iVar20 + 0x1098) = uVar24;
                *(undefined4 *)(iVar20 + 0x109c) = uVar7;
            }
            func_0x00018011b5d0(arg1);
            func_0x0001800f6770(3);
        }
        uVar14 = (uint32_t)var_a4h;
        if (((*(int64_t *)(arg1 + 0x20) == 0) && (*(int32_t *)(arg1 + 0x30) == 0)) &&
           ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            uVar14 = (uint32_t)var_a4h;
            if (((uint32_t)var_a4h & 8) == 0) {
                var_78h = *(float *)(*(int64_t *)0x180781f28 + 0x1170);
                var_74h = *(float *)(*(int64_t *)0x180781f28 + 0x1174);
                var_70h = *(float *)(*(int64_t *)0x180781f28 + 0x1178);
                var_6ch = *(float *)(*(int64_t *)0x180781f28 + 0x117c) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                iVar11 = func_0x0001800f5fa0(&var_78h);
                *(int32_t *)(arg1 + 0x90) = iVar11;
                if (iVar11 != 0) {
                    var_b0h._0_4_ = 0;
                    var_b8h._0_4_ = 0;
                    var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                       *(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48));
                    func_0x000180126550(*(undefined8 *)(puVar18 + 200), (float *)(arg1 + 0x48), &var_88h, iVar11);
                }
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
            } else {
                *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 4;
                *(undefined4 *)(arg1 + 0x90) = 0;
            }
        }
    } else {
        bVar6 = false;
code_r0x00018011768f:
        uVar14 = (uint32_t)var_a4h;
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117698;
    }
    if (puVar18 == (undefined4 *)0x0) {
code_r0x0001801179c9:
        *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbd;
        *(undefined4 *)(arg1 + 0xd0) = 0;
    } else {
        if (((*(int64_t *)(arg1 + 0x18) == 0) && ((uVar14 & 8) != 0)) && ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0)) {
            func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 0);
            var_94h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            stack0xffffffffffffff60 = *(undefined (*) [12])(*(int64_t *)0x180781f28 + 0xef0);
            if (bVar6) {
                var_88h = *(int64_t *)(iVar13 + 0x48);
                var_80h = *(float *)(int64_t *)(iVar13 + 0x48) + *(float *)(iVar13 + 0x50);
                var_7ch = *(float *)(iVar13 + 0x4c) + *(float *)(iVar13 + 0x54);
                var_78h = *(float *)(arg1 + 0x48);
                var_74h = *(float *)(arg1 + 0x4c);
                var_70h = var_78h + *(float *)(arg1 + 0x50);
                var_6ch = var_74h + *(float *)(arg1 + 0x54);
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b8h._0_4_ = 0;
                func_0x000180130c50(*(undefined8 *)(puVar18 + 200), &var_78h, &var_88h, uVar12);
            } else {
                var_88h = CONCAT44(*(float *)(arg1 + 0x54) + *(float *)(arg1 + 0x4c), 
                                   *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50));
                uVar12 = func_0x0001800f5fa0((int64_t)&var_a4h + 4);
                var_b0h._0_4_ = 0;
                var_b8h._0_4_ = 0;
                func_0x000180126550(*(undefined8 *)(puVar18 + 200), arg1 + 0x48, &var_88h, uVar12);
            }
        }
        func_0x000180127010(*(int64_t *)(puVar18 + 200) + 0x88, *(int64_t *)(puVar18 + 200), 1);
        if (*(int32_t *)(arg1 + 0x30) < 1) goto code_r0x0001801179c9;
        func_0x000180117c60(arg1, puVar18);
    }
    if ((*(int64_t *)(arg1 + 0x40) == 0) || (iVar11 = *(int32_t *)(*(int64_t *)(arg1 + 0x40) + 0x20), iVar11 == 0)) {
        if (0 < *(int32_t *)(arg1 + 0x30)) {
            *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(**(int64_t **)(arg1 + 0x38) + 200);
        }
    } else {
        *(int32_t *)(arg1 + 0xcc) = iVar11;
    }
    if ((((puVar18 == (undefined4 *)0x0) || ((*(uint8_t *)(arg1 + 0xdc) & 1) == 0)) || (*(int64_t *)(arg1 + 0x18) != 0))
       || ((*(int64_t *)(iVar8 + 0x1600) != 0 && (*(undefined4 **)(*(int64_t *)(iVar8 + 0x1600) + 0x428) == puVar18))))
    {
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
        if (puVar18 != (undefined4 *)0x0) goto code_r0x000180117a69;
    } else {
        func_0x00018011d040(puVar18);
        *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(iVar8 + 4);
code_r0x000180117a69:
        if (*(int64_t *)(arg1 + 0x20) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x20));
        }
        if (*(int64_t *)(arg1 + 0x28) != 0) {
            fcn.180116d90(*(int64_t *)(arg1 + 0x28));
        }
        if (*(int64_t *)(arg1 + 0x18) == 0) {
            func_0x000180100a00(puVar18);
        }
    }
    if (var_a8h != '\0') {
        func_0x000180105c20();
    }
code_r0x000180117aa7:
    func_0x000180459870(var_50h ^ (uint64_t)auStack_d8);
    return;
}

// ============================================================
// Function: FUN_180117b20
// Address: 0x180117b20
// Size: 104 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180117b20(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_60h)
{
    int64_t iVar1;
    char cVar2;
    int32_t iVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg3 + 8) == 1) {
        cVar2 = fcn.180148270(CONCAT71(var_28h._1_7_, 1));
        if (cVar2 != '\0') {
            *(uint8_t *)(arg2 + 0xdd) = *(uint8_t *)(arg2 + 0xdd) | 4;
            return;
        }
    } else {
        iVar3 = 0;
        if (0 < *(int32_t *)(arg3 + 8)) {
            do {
                iVar1 = *(int64_t *)(arg3 + 0x10);
                if ((*(uint32_t *)((int64_t)iVar3 * 0x38 + 4 + iVar1) & 0x200000) == 0) {
                    cVar2 = fcn.180146c70(unaff_RDI, 0);
                    if (cVar2 != '\0') {
                        *(undefined4 *)(arg3 + 0x24) = *(undefined4 *)((int64_t)iVar3 * 0x38 + iVar1);
                    }
                    fcn.18010bd60(0, 0xbf800000);
                    fcn.180139ae0(0x180645118);
                }
                iVar3 = iVar3 + 1;
            } while (iVar3 < *(int32_t *)(arg3 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180117b88
// Address: 0x180117b88
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180117b20(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_60h)
{
    int64_t iVar1;
    char cVar2;
    int32_t iVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg3 + 8) == 1) {
        cVar2 = fcn.180148270(CONCAT71(var_28h._1_7_, 1));
        if (cVar2 != '\0') {
            *(uint8_t *)(arg2 + 0xdd) = *(uint8_t *)(arg2 + 0xdd) | 4;
            return;
        }
    } else {
        iVar3 = 0;
        if (0 < *(int32_t *)(arg3 + 8)) {
            do {
                iVar1 = *(int64_t *)(arg3 + 0x10);
                if ((*(uint32_t *)((int64_t)iVar3 * 0x38 + 4 + iVar1) & 0x200000) == 0) {
                    cVar2 = fcn.180146c70(unaff_RDI, 0);
                    if (cVar2 != '\0') {
                        *(undefined4 *)(arg3 + 0x24) = *(undefined4 *)((int64_t)iVar3 * 0x38 + iVar1);
                    }
                    fcn.18010bd60(0, 0xbf800000);
                    fcn.180139ae0(0x180645118);
                }
                iVar3 = iVar3 + 1;
            } while (iVar3 < *(int32_t *)(arg3 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180117b97
// Address: 0x180117b97
// Size: 176 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180117b20(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_60h)
{
    int64_t iVar1;
    char cVar2;
    int32_t iVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg3 + 8) == 1) {
        cVar2 = fcn.180148270(CONCAT71(var_28h._1_7_, 1));
        if (cVar2 != '\0') {
            *(uint8_t *)(arg2 + 0xdd) = *(uint8_t *)(arg2 + 0xdd) | 4;
            return;
        }
    } else {
        iVar3 = 0;
        if (0 < *(int32_t *)(arg3 + 8)) {
            do {
                iVar1 = *(int64_t *)(arg3 + 0x10);
                if ((*(uint32_t *)((int64_t)iVar3 * 0x38 + 4 + iVar1) & 0x200000) == 0) {
                    cVar2 = fcn.180146c70(unaff_RDI, 0);
                    if (cVar2 != '\0') {
                        *(undefined4 *)(arg3 + 0x24) = *(undefined4 *)((int64_t)iVar3 * 0x38 + iVar1);
                    }
                    fcn.18010bd60(0, 0xbf800000);
                    fcn.180139ae0(0x180645118);
                }
                iVar3 = iVar3 + 1;
            } while (iVar3 < *(int32_t *)(arg3 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180117c47
// Address: 0x180117c47
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180117b20(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_60h)
{
    int64_t iVar1;
    char cVar2;
    int32_t iVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg3 + 8) == 1) {
        cVar2 = fcn.180148270(CONCAT71(var_28h._1_7_, 1));
        if (cVar2 != '\0') {
            *(uint8_t *)(arg2 + 0xdd) = *(uint8_t *)(arg2 + 0xdd) | 4;
            return;
        }
    } else {
        iVar3 = 0;
        if (0 < *(int32_t *)(arg3 + 8)) {
            do {
                iVar1 = *(int64_t *)(arg3 + 0x10);
                if ((*(uint32_t *)((int64_t)iVar3 * 0x38 + 4 + iVar1) & 0x200000) == 0) {
                    cVar2 = fcn.180146c70(unaff_RDI, 0);
                    if (cVar2 != '\0') {
                        *(undefined4 *)(arg3 + 0x24) = *(undefined4 *)((int64_t)iVar3 * 0x38 + iVar1);
                    }
                    fcn.18010bd60(0, 0xbf800000);
                    fcn.180139ae0(0x180645118);
                }
                iVar3 = iVar3 + 1;
            } while (iVar3 < *(int32_t *)(arg3 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180117c4c
// Address: 0x180117c4c
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_15e0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_12f8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Removing arg arg_1fc0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_ee0h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_dech because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_10ch
// WARNING: [rz-ghidra] Detected overlap for variable var_108h
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_114h
// WARNING: [rz-ghidra] Detected overlap for variable var_100h
// WARNING: [rz-ghidra] Detected overlap for variable var_113h
// WARNING: [rz-ghidra] Detected overlap for variable var_117h
// WARNING: [rz-ghidra] Detected overlap for variable var_116h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_e0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_115h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch

void fcn.180117b20(undefined8 placeholder_0, int64_t arg2, int64_t arg3, int64_t arg_60h)
{
    int64_t iVar1;
    char cVar2;
    int32_t iVar3;
    int64_t unaff_RDI;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_20h;
    int64_t var_28h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg3 + 8) == 1) {
        cVar2 = fcn.180148270(CONCAT71(var_28h._1_7_, 1));
        if (cVar2 != '\0') {
            *(uint8_t *)(arg2 + 0xdd) = *(uint8_t *)(arg2 + 0xdd) | 4;
            return;
        }
    } else {
        iVar3 = 0;
        if (0 < *(int32_t *)(arg3 + 8)) {
            do {
                iVar1 = *(int64_t *)(arg3 + 0x10);
                if ((*(uint32_t *)((int64_t)iVar3 * 0x38 + 4 + iVar1) & 0x200000) == 0) {
                    cVar2 = fcn.180146c70(unaff_RDI, 0);
                    if (cVar2 != '\0') {
                        *(undefined4 *)(arg3 + 0x24) = *(undefined4 *)((int64_t)iVar3 * 0x38 + iVar1);
                    }
                    fcn.18010bd60(0, 0xbf800000);
                    fcn.180139ae0(0x180645118);
                }
                iVar3 = iVar3 + 1;
            } while (iVar3 < *(int32_t *)(arg3 + 8));
        }
    }
    return;
}

// ============================================================
// Function: FUN_180117c60
// Address: 0x180117c60
// Size: 339 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180117db3
// Address: 0x180117db3
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180117e3b
// Address: 0x180117e3b
// Size: 8 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180117e43
// Address: 0x180117e43
// Size: 794 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_18011815d
// Address: 0x18011815d
// Size: 3204 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180118de1
// Address: 0x180118de1
// Size: 344 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180118f39
// Address: 0x180118f39
// Size: 218 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_196h
// WARNING: [rz-ghidra] Detected overlap for variable var_198h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_160h
// WARNING: [rz-ghidra] Detected overlap for variable var_15ch
// WARNING: [rz-ghidra] Detected overlap for variable var_150h
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_197h
// WARNING: [rz-ghidra] Detected overlap for variable var_174h

void fcn.180117c60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    float fVar2;
    undefined4 uVar3;
    uint32_t uVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t iVar10;
    int64_t *piVar11;
    uint32_t uVar12;
    uint64_t uVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    char *pcVar17;
    int32_t iVar18;
    bool bVar19;
    float fVar20;
    undefined4 uVar21;
    undefined4 uVar22;
    int64_t var_18h;
    uint8_t var_198h;
    char var_197h;
    char var_196h;
    int64_t var_195h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_188h;
    float var_180h;
    undefined4 var_17ch;
    int64_t var_178h;
    int32_t var_170h;
    int64_t var_16ch;
    float var_164h;
    float var_160h;
    float var_15ch;
    undefined4 uStack_158;
    float var_150h;
    float var_14ch;
    int64_t var_148h;
    int64_t var_140h;
    undefined4 uStack_138;
    float var_134h;
    int64_t var_130h;
    int64_t var_128h;
    undefined4 uStack_120;
    undefined4 uStack_11c;
    int64_t var_118h;
    undefined4 uStack_110;
    undefined4 uStack_10c;
    int64_t var_108h;
    undefined4 uStack_100;
    undefined4 uStack_fc;
    int64_t var_f8h;
    undefined4 uStack_f0;
    undefined4 uStack_ec;
    int64_t var_e8h;
    undefined4 uStack_e0;
    undefined4 uStack_dc;
    int64_t var_d8h;
    undefined4 uStack_d0;
    undefined4 uStack_cc;
    int64_t var_c8h;
    undefined4 uStack_c0;
    undefined4 uStack_bc;
    int64_t var_b8h;
    undefined4 uStack_b0;
    undefined4 uStack_ac;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_98h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    var_16ch._0_4_ = *(int32_t *)(*(int64_t *)0x180781f28 + 4);
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xbf;
    *(undefined4 *)(arg1 + 0xd0) = 0;
    iVar15 = *(int64_t *)(arg1 + 0x18);
    iVar14 = arg1;
    while (iVar15 != 0) {
        iVar14 = *(int64_t *)(iVar14 + 0x18);
        iVar15 = *(int64_t *)(iVar14 + 0x18);
    }
    if (*(int64_t *)(iVar6 + 0x23c0) == 0) {
        if ((*(int64_t *)(iVar6 + 0x21d8) != 0) && (*(int32_t *)(iVar14 + 200) == *(int32_t *)arg1)) {
            iVar15 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418);
            uVar12 = *(uint32_t *)(iVar15 + 0x14);
            while ((uVar12 & 0x10000000) != 0) {
                iVar15 = *(int64_t *)(*(int64_t *)(iVar15 + 0x408) + 0x418);
                uVar12 = *(uint32_t *)(iVar15 + 0x14);
            }
            iVar10 = *(int64_t *)(iVar15 + 0x4c8);
            if (iVar10 != 0) goto code_r0x000180117d51;
            for (iVar10 = *(int64_t *)(iVar15 + 0x4c0); iVar10 != 0;
                iVar10 = *(int64_t *)(*(int64_t *)(*(int64_t *)(iVar10 + 0x98) + 0x418) + 0x4c0)) {
code_r0x000180117d51:
                iVar15 = *(int64_t *)(iVar10 + 0x18);
                while (iVar15 != 0) {
                    iVar10 = *(int64_t *)(iVar10 + 0x18);
                    iVar15 = *(int64_t *)(iVar10 + 0x18);
                }
                if (iVar10 == iVar14) {
                    bVar19 = true;
                    goto code_r0x000180117d96;
                }
                if (*(int64_t *)(iVar10 + 0x98) == 0) break;
            }
        }
        bVar19 = false;
    } else {
        bVar19 = *(int64_t *)(*(int64_t *)(iVar6 + 0x23c0) + 0x4c0) == arg1;
    }
code_r0x000180117d96:
    uVar12 = *(uint32_t *)(arg1 + 0x10);
    var_148h = iVar14;
    if (((uVar12 >> 0xd & 1) != 0) || ((uVar12 >> 0xc & 1) != 0)) {
        if (*(int32_t *)(arg1 + 0x30) < 1) {
            iVar15 = 0;
        } else {
            iVar15 = **(int64_t **)(arg1 + 0x38);
        }
        *(int64_t *)(arg1 + 0xa0) = iVar15;
        *(uint8_t *)(arg1 + 0xdc) = bVar19 * '\x02' | *(uint8_t *)(arg1 + 0xdc) & 0xfd;
        if (bVar19 != false) {
            *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
        }
        if (iVar15 != 0) {
            if ((bVar19 != false) || (*(int64_t *)(iVar14 + 0xa0) == 0)) {
                *(int64_t *)(iVar14 + 0xa0) = iVar15;
            }
            if (*(int64_t *)(arg1 + 0x40) != 0) {
                *(undefined4 *)(*(int64_t *)(arg1 + 0x40) + 0x2c) = *(undefined4 *)(*(int64_t *)(arg1 + 0xa0) + 200);
            }
        }
        goto code_r0x000180118ff0;
    }
    var_170h = *(int32_t *)(arg1 + 0xc0) + 1;
    var_195h._0_1_ = *(undefined *)(arg2 + 0x10e);
    if ((uVar12 >> 10 & 1) == 0) {
        *(undefined *)(arg2 + 0x10e) = 0;
        *(undefined4 *)(arg2 + 0x1b0) = 1;
    }
    func_0x0001801076d0(*(undefined4 *)arg1);
    iVar15 = *(int64_t *)(arg1 + 0x40);
    var_130h = iVar15;
    if (iVar15 == 0) {
        func_0x000180119020(arg1);
        iVar15 = *(int64_t *)(arg1 + 0x40);
    }
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0xfd;
    var_195h._1_4_ = 0;
    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | bVar19 * '\x02';
    iVar10 = *(int64_t *)0x180781f28;
    uVar21 = 0;
    uVar8 = *(uint8_t *)(arg1 + 0xdc);
    var_198h = bVar19;
    if (((*(uint32_t *)(arg1 + 0x10) & 0x4000) == 0) && (*(int32_t *)(iVar6 + 0xdc8) != -1)) {
        var_196h = '\x01';
        iVar9 = func_0x0001800f5a90(0x180645120);
        if ((*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) &&
           (*(int32_t *)((int64_t)*(int32_t *)(iVar10 + 0x2130) * 0x38 + *(int64_t *)(iVar10 + 0x2128)) == iVar9)) {
            unique0x0000c180 = *(int32_t *)(iVar15 + 0x24);
            fVar20 = *(float *)(arg1 + 0x48);
            fVar2 = *(float *)(arg1 + 0x4c);
            if (*(int32_t *)(iVar10 + 0xdc8) == 0) {
                uVar22 = 0;
            } else {
                fVar20 = fVar20 + *(float *)(arg1 + 0x50);
                uVar22 = 0x3f800000;
            }
            *(uint32_t *)(iVar10 + 0x2008) = *(uint32_t *)(iVar10 + 0x2008) | 1;
            *(float *)(iVar10 + 0x201c) = fVar20;
            *(float *)(iVar10 + 0x2020) =
                 *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0xde0) + *(float *)(iVar10 + 0x12f8) + fVar2;
            *(undefined4 *)(iVar10 + 0x2024) = uVar22;
            *(undefined4 *)(iVar10 + 0x2028) = uVar21;
            *(undefined4 *)(iVar10 + 0x200c) = 1;
            *(undefined *)(iVar10 + 0x204c) = 1;
            if (*(int32_t *)(iVar10 + 0x2130) < *(int32_t *)(iVar10 + 0x2120)) {
                uVar21 = func_0x0001800f5a90(0x180645120, 0);
                cVar7 = func_0x00018010d4b0(uVar21, 0x141);
                if (cVar7 != '\0') {
                    *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 2;
                    (**(code **)(iVar10 + 0x2920))(iVar10, arg1);
                    func_0x00018010d5c0();
                }
            } else {
                *(undefined4 *)(iVar10 + 0x2008) = 0;
            }
            iVar9 = *(int32_t *)(iVar15 + 0x24);
            if ((iVar9 != 0) && (var_195h._1_4_ = iVar9, iVar9 == *(int32_t *)0x10)) {
                var_195h._1_4_ = 0;
            }
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
            var_198h = uVar8 >> 1 & 1 | bVar19;
        } else {
            uVar8 = *(uint8_t *)(arg1 + 0xdc);
        }
    } else {
        var_196h = '\0';
    }
    var_164h = *(float *)(arg1 + 0x4c);
    fVar20 = *(float *)(undefined8 *)(arg1 + 0x48);
    var_178h = 0;
    var_180h = fVar20 + *(float *)(arg1 + 0x50);
    var_188h = *(undefined8 *)(arg1 + 0x48);
    var_15ch = *(float *)(*(int64_t *)0x180781f28 + 0xde0) + *(float *)(*(int64_t *)0x180781f28 + 0xde0) +
               var_164h + *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_17ch = var_15ch;
    fVar2 = *(float *)(*(int64_t *)0x180781f28 + 0x12f8);
    var_14ch = var_164h + *(float *)(*(int64_t *)0x180781f28 + 0xde0);
    var_16ch._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0xdb0) + fVar20 + *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    var_160h = (var_180h - *(float *)(*(int64_t *)0x180781f28 + 0xdb0)) - *(float *)(*(int64_t *)0x180781f28 + 0xddc);
    if ((uVar8 & 8) != 0) {
        var_178h = CONCAT44(var_14ch, var_160h - fVar2);
        var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
    }
    var_150h = var_16ch._4_4_;
    if ((uVar8 & 0x10) != 0) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 0) {
            var_16ch._4_4_ = fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4) + var_16ch._4_4_;
        } else if (*(int32_t *)(*(int64_t *)0x180781f28 + 0xdc8) == 1) {
            var_150h = var_160h - fVar2;
            var_160h = var_160h - (fVar2 + *(float *)(*(int64_t *)0x180781f28 + 0xdf4));
        }
    }
    unique0x0000c180 = *(int32_t *)(iVar15 + 8);
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        piVar11 = (int64_t *)(iVar15 + 0x10);
        iVar9 = 0;
        var_140h = (int64_t)piVar11;
        do {
            iVar18 = *(int32_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar9 * 8) + 200);
            if ((iVar18 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *piVar11) == iVar18) {
                        piVar11 = (int64_t *)var_140h;
                        if (*(int64_t *)var_140h + uVar13 * 0x38 != 0) goto code_r0x0001801181d4;
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
            func_0x00018014ab80(iVar15);
code_r0x0001801181d4:
            iVar9 = iVar9 + 1;
        } while (iVar9 < *(int32_t *)(arg1 + 0x30));
    }
    iVar9 = stack0xfffffffffffffe70;
    uVar8 = var_198h;
    if (var_198h != 0) {
        *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(iVar6 + 4);
    }
    if (*(char *)(arg2 + 0x10c) == '\0') {
        iVar10 = (uint64_t)(var_198h != 0) + 10;
    } else {
        iVar10 = 0xc;
    }
    piVar11 = (int64_t *)(*(int64_t *)0x180781f28 + 0xd90 + (iVar10 + 0x14) * 0x10);
    var_140h = *piVar11;
    uStack_138 = *(undefined4 *)(piVar11 + 1);
    var_134h = *(float *)((int64_t)piVar11 + 0xc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    uVar21 = fcn.1800f5fa0(&var_140h);
    func_0x000180126550(*(undefined8 *)(arg2 + 800), &var_188h, &var_180h, uVar21);
    if (var_196h != '\0') {
        uVar21 = func_0x0001800f5a90(0x180644220, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013afb0(uVar21, &var_150h, arg1);
        if (cVar7 != '\0') {
            uVar21 = func_0x0001800f5a90(0x180645120, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148)
                                          * 4));
            func_0x00018010d030(uVar21);
        }
        if ((*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) != 0) &&
           (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == *(int32_t *)(*(int64_t *)0x180781f28 + 0x1fb8))) {
            var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
        }
        cVar7 = func_0x0001800fa150(0x11000);
        if ((cVar7 != '\0') && (0.5 < *(float *)(iVar6 + 0x1648))) {
            func_0x00018010ce60(0x18063cc8c);
        }
    }
    uVar12 = *(uint32_t *)(iVar15 + 8);
    while (uVar16 = uVar12 - 1, -1 < (int32_t)uVar16) {
        uVar4 = *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10));
        if ((uVar4 >> 0x17 & 1) == 0) break;
        *(uint32_t *)((uint64_t)uVar16 * 0x38 + 4 + *(int64_t *)(iVar15 + 0x10)) = uVar4 & 0xff7fffff;
        uVar12 = uVar16;
    }
    iVar18 = *(int32_t *)(iVar15 + 8);
    if ((((int32_t)uVar12 < iVar18) && ((int32_t)(uVar12 + 1) < iVar18)) &&
       (1 < (uint64_t)(int64_t)(int32_t)(iVar18 - uVar12))) {
        func_0x00018046f0d0((int64_t)(int32_t)uVar12 * 0x38 + *(int64_t *)(iVar15 + 0x10), 
                            (int64_t)(int32_t)(iVar18 - uVar12), 0x38, 0x180117ad0);
    }
    if ((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
       (iVar10 = *(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418), *(int64_t *)(iVar10 + 0x4c0) == arg1)) {
        *(undefined4 *)(iVar15 + 0x20) = *(undefined4 *)(iVar10 + 200);
    }
    if (((var_130h == 0) && (iVar18 = *(int32_t *)(arg1 + 0xcc), iVar18 != 0)) && (0 < *(int32_t *)(iVar15 + 8))) {
        uVar13 = 0;
        do {
            if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == iVar18) {
                *(int32_t *)(iVar15 + 0x24) = iVar18;
                *(int32_t *)(iVar15 + 0x20) = iVar18;
                goto code_r0x000180118509;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    if (iVar9 < *(int32_t *)(iVar15 + 8)) {
        uVar21 = *(undefined4 *)
                  (*(int64_t *)((int64_t)*(int32_t *)(iVar15 + 8) * 0x38 + -0x30 + *(int64_t *)(iVar15 + 0x10)) + 200);
        *(undefined4 *)(iVar15 + 0x24) = uVar21;
        *(undefined4 *)(iVar15 + 0x20) = uVar21;
    }
code_r0x000180118509:
    uVar21 = 0x5000c3;
    if ((*(char *)(arg2 + 0x10c) == '\0') && (uVar21 = 0x7000c3, uVar8 == 0)) {
        uVar21 = 0x5000c3;
    }
    *(undefined4 *)(iVar15 + 0x1c) = *(undefined4 *)arg1;
    *(float *)(iVar15 + 0x74) = *(float *)(arg1 + 0x48) + *(float *)(arg2 + 0x9c);
    *(float *)(iVar15 + 0x78) = (*(float *)(arg1 + 0x50) + *(float *)(arg1 + 0x48)) - *(float *)(arg2 + 0x9c);
    func_0x000180148ad0(iVar15, (int64_t)&var_16ch + 4, uVar21);
    iVar9 = var_170h;
    piVar11 = &var_128h;
    iVar10 = 9;
    do {
        *piVar11 = 0;
        piVar11[1] = 0;
        piVar11 = piVar11 + 2;
        iVar10 = iVar10 + -1;
    } while (iVar10 != 0);
    var_128h._0_4_ = *(undefined4 *)(iVar6 + 0xed0);
    var_128h._4_4_ = *(undefined4 *)(iVar6 + 0xed4);
    uStack_120 = *(undefined4 *)(iVar6 + 0xed8);
    uStack_11c = *(undefined4 *)(iVar6 + 0xedc);
    iVar18 = 0;
    var_118h._0_4_ = *(undefined4 *)(iVar6 + 0x10f0);
    var_118h._4_4_ = *(undefined4 *)(iVar6 + 0x10f4);
    uStack_110 = *(undefined4 *)(iVar6 + 0x10f8);
    uStack_10c = *(undefined4 *)(iVar6 + 0x10fc);
    var_108h._0_4_ = *(undefined4 *)(iVar6 + 0x1100);
    var_108h._4_4_ = *(undefined4 *)(iVar6 + 0x1104);
    uStack_100 = *(undefined4 *)(iVar6 + 0x1108);
    uStack_fc = *(undefined4 *)(iVar6 + 0x110c);
    var_f8h._0_4_ = *(undefined4 *)(iVar6 + 0x1110);
    var_f8h._4_4_ = *(undefined4 *)(iVar6 + 0x1114);
    uStack_f0 = *(undefined4 *)(iVar6 + 0x1118);
    uStack_ec = *(undefined4 *)(iVar6 + 0x111c);
    var_e8h._0_4_ = *(undefined4 *)(iVar6 + 0x1120);
    var_e8h._4_4_ = *(undefined4 *)(iVar6 + 0x1124);
    uStack_e0 = *(undefined4 *)(iVar6 + 0x1128);
    uStack_dc = *(undefined4 *)(iVar6 + 0x112c);
    var_d8h._0_4_ = *(undefined4 *)(iVar6 + 0x1130);
    var_d8h._4_4_ = *(undefined4 *)(iVar6 + 0x1134);
    uStack_d0 = *(undefined4 *)(iVar6 + 0x1138);
    uStack_cc = *(undefined4 *)(iVar6 + 0x113c);
    var_c8h._0_4_ = *(undefined4 *)(iVar6 + 0x1140);
    var_c8h._4_4_ = *(undefined4 *)(iVar6 + 0x1144);
    uStack_c0 = *(undefined4 *)(iVar6 + 0x1148);
    uStack_bc = *(undefined4 *)(iVar6 + 0x114c);
    var_b8h._0_4_ = *(undefined4 *)(iVar6 + 0x1150);
    var_b8h._4_4_ = *(undefined4 *)(iVar6 + 0x1154);
    uStack_b0 = *(undefined4 *)(iVar6 + 0x1158);
    uStack_ac = *(undefined4 *)(iVar6 + 0x115c);
    var_a8h._0_4_ = *(undefined4 *)(iVar6 + 0x1260);
    var_a8h._4_4_ = *(undefined4 *)(iVar6 + 0x1264);
    uStack_a0 = *(undefined4 *)(iVar6 + 0x1268);
    uStack_9c = *(undefined4 *)(iVar6 + 0x126c);
    *(undefined8 *)(arg1 + 0xa0) = 0;
    if (0 < *(int32_t *)(arg1 + 0x30)) {
        do {
            iVar14 = *(int64_t *)(*(int64_t *)(arg1 + 0x38) + (int64_t)iVar18 * 8);
            if ((*(int32_t *)(iVar6 + 4) <= *(int32_t *)(iVar14 + 0x2e0) + 1) || (iVar9 != (int32_t)var_16ch)) {
                uVar12 = *(uint32_t *)(iVar14 + 0x498);
                uVar16 = *(uint32_t *)(iVar14 + 0x34) | 1;
                if ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0) {
                    uVar16 = *(uint32_t *)(iVar14 + 0x34);
                }
                uVar4 = uVar16 | 4;
                if ((*(uint8_t *)(iVar15 + 0x18) & 8) == 0) {
                    uVar4 = uVar16;
                }
                *(float *)(iVar6 + 0xed0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xed8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0xedc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x49c);
                *(float *)(iVar6 + 0x10f0) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f4) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10f8) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x10fc) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a0);
                *(float *)(iVar6 + 0x1100) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1104) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1108) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x110c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a4);
                *(float *)(iVar6 + 0x1110) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1114) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1118) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x111c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4a8);
                *(float *)(iVar6 + 0x1120) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1124) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1128) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x112c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4ac);
                *(float *)(iVar6 + 0x1130) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1134) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1138) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x113c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b0);
                *(float *)(iVar6 + 0x1140) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1144) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1148) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x114c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b4);
                *(float *)(iVar6 + 0x1150) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1154) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1158) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x115c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                uVar12 = *(uint32_t *)(iVar14 + 0x4b8);
                *(float *)(iVar6 + 0x1260) = (float)(uint64_t)(uVar12 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1264) = (float)(uint64_t)(uVar12 >> 8 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x1268) = (float)(uint64_t)(uVar12 >> 0x10 & 0xff) * 0.003921569;
                *(float *)(iVar6 + 0x126c) = (float)(uint64_t)(uVar12 >> 0x18) * 0.003921569;
                var_197h = '\x01';
                pcVar17 = &var_197h;
                if (*(char *)(iVar14 + 0x114) == '\0') {
                    pcVar17 = (char *)0x0;
                }
                func_0x00018014ae50(iVar15, *(undefined8 *)(iVar14 + 8), pcVar17, uVar4);
                if (var_197h == '\0') {
                    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(iVar14 + 200);
                }
                if (*(int32_t *)(iVar15 + 0x2c) == *(int32_t *)(iVar14 + 200)) {
                    *(int64_t *)(arg1 + 0xa0) = iVar14;
                }
                *(undefined4 *)(iVar14 + 0x228) = *(undefined4 *)(iVar6 + 0x1fc0);
                uVar21 = *(undefined4 *)(iVar6 + 0x1fc8);
                uVar22 = *(undefined4 *)(iVar6 + 0x1fcc);
                uVar3 = *(undefined4 *)(iVar6 + 0x1fd0);
                *(undefined4 *)(iVar14 + 0x22c) = *(undefined4 *)(iVar6 + 0x1fc4);
                *(undefined4 *)(iVar14 + 0x230) = uVar21;
                *(undefined4 *)(iVar14 + 0x234) = uVar22;
                *(undefined4 *)(iVar14 + 0x238) = uVar3;
                if (((*(int64_t *)(iVar6 + 0x21d8) != 0) &&
                    (*(int64_t *)(*(int64_t *)(iVar6 + 0x21d8) + 0x418) == iVar14)) &&
                   ((*(uint8_t *)(iVar14 + 0x1b4) & 2) == 0)) {
                    *(undefined4 *)(arg2 + 0x454) = *(undefined4 *)(iVar14 + 200);
                }
            }
            iVar18 = iVar18 + 1;
            iVar14 = var_148h;
            uVar8 = var_198h;
        } while (iVar18 < *(int32_t *)(arg1 + 0x30));
    }
    auVar5._4_4_ = var_128h._4_4_;
    auVar5._0_4_ = (undefined4)var_128h;
    auVar5._8_4_ = uStack_120;
    auVar5._12_4_ = uStack_11c;
    *(undefined (*) [16])(iVar6 + 0xed0) = auVar5;
    *(undefined4 *)(iVar6 + 0x10f0) = (undefined4)var_118h;
    *(undefined4 *)(iVar6 + 0x10f4) = var_118h._4_4_;
    *(undefined4 *)(iVar6 + 0x10f8) = uStack_110;
    *(undefined4 *)(iVar6 + 0x10fc) = uStack_10c;
    *(undefined4 *)(iVar6 + 0x1100) = (undefined4)var_108h;
    *(undefined4 *)(iVar6 + 0x1104) = var_108h._4_4_;
    *(undefined4 *)(iVar6 + 0x1108) = uStack_100;
    *(undefined4 *)(iVar6 + 0x110c) = uStack_fc;
    *(undefined4 *)(iVar6 + 0x1110) = (undefined4)var_f8h;
    *(undefined4 *)(iVar6 + 0x1114) = var_f8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1118) = uStack_f0;
    *(undefined4 *)(iVar6 + 0x111c) = uStack_ec;
    *(undefined4 *)(iVar6 + 0x1120) = (undefined4)var_e8h;
    *(undefined4 *)(iVar6 + 0x1124) = var_e8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1128) = uStack_e0;
    *(undefined4 *)(iVar6 + 0x112c) = uStack_dc;
    *(undefined4 *)(iVar6 + 0x1130) = (undefined4)var_d8h;
    *(undefined4 *)(iVar6 + 0x1134) = var_d8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1138) = uStack_d0;
    *(undefined4 *)(iVar6 + 0x113c) = uStack_cc;
    *(undefined4 *)(iVar6 + 0x1140) = (undefined4)var_c8h;
    *(undefined4 *)(iVar6 + 0x1144) = var_c8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1148) = uStack_c0;
    *(undefined4 *)(iVar6 + 0x114c) = uStack_bc;
    *(undefined4 *)(iVar6 + 0x1150) = (undefined4)var_b8h;
    *(undefined4 *)(iVar6 + 0x1154) = var_b8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1158) = uStack_b0;
    *(undefined4 *)(iVar6 + 0x115c) = uStack_ac;
    *(undefined4 *)(iVar6 + 0x1260) = (undefined4)var_a8h;
    *(undefined4 *)(iVar6 + 0x1264) = var_a8h._4_4_;
    *(undefined4 *)(iVar6 + 0x1268) = uStack_a0;
    *(undefined4 *)(iVar6 + 0x126c) = uStack_9c;
    if ((*(int64_t *)(arg1 + 0xa0) != 0) && ((uVar8 != 0 || (*(int64_t *)(iVar14 + 0xa0) == 0)))) {
        *(int64_t *)(iVar14 + 0xa0) = *(int64_t *)(arg1 + 0xa0);
    }
    iVar14 = *(int64_t *)0x180781f28;
    uVar8 = *(uint8_t *)(arg1 + 0xdc) & 8;
    if (((uVar8 == 0) || (*(int64_t *)(arg1 + 0xa0) == 0)) || (*(char *)(*(int64_t *)(arg1 + 0xa0) + 0x114) == '\0')) {
        if (uVar8 != 0) {
            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) = *(uint32_t *)(*(int64_t *)0x180781f28 + 0x1f78) | 0x40;
            piVar1 = (int32_t *)(iVar14 + 0x2100);
            iVar9 = *(int32_t *)(iVar14 + 0x2104);
            uVar21 = *(undefined4 *)(iVar14 + 0x1f78);
            iVar10 = iVar14;
            if (*piVar1 == iVar9) {
                iVar18 = *piVar1 + 1;
                if (iVar9 == 0) {
                    iVar9 = 8;
                } else {
                    iVar9 = iVar9 / 2 + iVar9;
                }
                if (iVar18 < iVar9) {
                    iVar18 = iVar9;
                }
                fcn.18011fb10(piVar1, iVar18);
                iVar10 = *(int64_t *)0x180781f28;
            }
            *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + (int64_t)*piVar1 * 4) = uVar21;
            *piVar1 = *piVar1 + 1;
            var_164h = *(float *)(iVar10 + 0xed0);
            var_160h = *(float *)(iVar10 + 0xed4);
            var_15ch = *(float *)(iVar10 + 0xed8);
            uStack_158 = *(undefined4 *)(iVar10 + 0xedc);
            var_16ch._4_4_ = 0.0;
            uVar21 = *(undefined4 *)(iVar6 + 0xed0);
            uVar22 = *(undefined4 *)(iVar6 + 0xed4);
            uVar3 = *(undefined4 *)(iVar6 + 0xed8);
            fVar20 = *(float *)(iVar6 + 0xedc);
            fcn.18011f2b0(iVar10 + 0x20c0, (int64_t)&var_16ch + 4);
            bVar19 = false;
            if (*(int32_t *)(iVar10 + 0x20bc) != 0) {
                *(undefined4 *)(iVar10 + 0xed0) = uVar21;
                *(undefined4 *)(iVar10 + 0xed4) = uVar22;
                *(undefined4 *)(iVar10 + 0xed8) = uVar3;
                *(float *)(iVar10 + 0xedc) = fVar20 * 0.4;
            }
            goto code_r0x000180118c99;
        }
    } else {
        bVar19 = true;
code_r0x000180118c99:
        uVar21 = func_0x0001800f5a90(0x1806445a0, 0, 
                                     *(undefined4 *)
                                      (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
        cVar7 = func_0x00018013ac70(uVar21, &var_178h);
        if (cVar7 != '\0') {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) | 0x40;
            iVar9 = 0;
            if (0 < *(int32_t *)(iVar15 + 8)) {
                do {
                    iVar10 = (int64_t)iVar9 * 0x38;
                    iVar14 = *(int64_t *)(iVar15 + 0x10);
                    uVar12 = *(uint32_t *)(iVar10 + 4 + iVar14);
                    if ((uVar12 >> 0x15 & 1) == 0) {
                        iVar18 = *(int32_t *)(iVar10 + iVar14);
                        if ((uVar12 & 0x101) == 0) {
                            *(undefined *)(iVar10 + 0x30 + iVar14) = 1;
                            if (*(int32_t *)(iVar15 + 0x2c) == iVar18) {
                                *(undefined4 *)(iVar10 + 0x10 + iVar14) = 0xffffffff;
                                *(undefined8 *)(iVar15 + 0x20) = 0;
                            }
                        } else if (*(int32_t *)(iVar15 + 0x2c) != iVar18) {
                            *(int32_t *)(iVar15 + 0x24) = iVar18;
                        }
                    }
                    iVar9 = iVar9 + 1;
                } while (iVar9 < *(int32_t *)(iVar15 + 8));
            }
        }
        if (!bVar19) {
            fcn.1800f6770(1);
            iVar14 = *(int64_t *)0x180781f28;
            iVar9 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100);
            if (iVar9 < 2) {
                if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
                    (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                              (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x180644628);
                }
            } else {
                *(int32_t *)(*(int64_t *)0x180781f28 + 0x2100) = iVar9 + -1;
                *(undefined4 *)(iVar14 + 0x1f78) =
                     *(undefined4 *)(*(int64_t *)(iVar14 + 0x2108) + -8 + (int64_t)iVar9 * 4);
            }
        }
    }
    iVar9 = func_0x0001800f5a90(0x180645130, 0, 
                                *(undefined4 *)
                                 (*(int64_t *)(arg2 + 0x150) + -4 + (int64_t)*(int32_t *)(arg2 + 0x148) * 4));
    iVar14 = *(int64_t *)0x180781f28;
    if (((*(int32_t *)(iVar6 + 0x163c) == 0) || (*(int32_t *)(iVar6 + 0x163c) == iVar9)) ||
       (*(int32_t *)(iVar6 + 0x1654) == iVar9)) {
        if (*(int32_t *)(*(int64_t *)0x180781f28 + 0x1654) == iVar9) {
            *(int32_t *)(*(int64_t *)0x180781f28 + 0x1658) = iVar9;
        }
        if (*(int32_t *)(iVar14 + 0x1684) == iVar9) {
            *(undefined *)(iVar14 + 0x168d) = 1;
        }
        func_0x000180139d40(&var_188h, iVar9, 0, &var_197h);
        if (*(int32_t *)(iVar6 + 0x163c) == iVar9) {
            *(int32_t *)(iVar6 + 0x1fb8) = iVar9;
        }
        if (var_197h != '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                var_195h._1_4_ = *(int32_t *)(iVar15 + 0x20);
            }
            if ((*(int32_t *)(iVar15 + 0x20) != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
                uVar13 = 0;
                do {
                    if (*(int32_t *)(uVar13 * 0x38 + *(int64_t *)(iVar15 + 0x10)) == *(int32_t *)(iVar15 + 0x20)) {
                        iVar14 = *(int64_t *)(uVar13 * 0x38 + 8 + *(int64_t *)(iVar15 + 0x10));
                        if (iVar14 == 0) {
                            iVar14 = *(int64_t *)(arg1 + 0x98);
                        }
                        func_0x0001800faaf0(iVar14, arg1, 0);
                        break;
                    }
                    uVar12 = (int32_t)uVar13 + 1;
                    uVar13 = (uint64_t)uVar12;
                } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
            }
        }
    }
    iVar9 = *(int32_t *)(iVar15 + 0x24);
    if (*(int32_t *)(iVar15 + 0x24) == 0) {
        iVar9 = var_195h._1_4_;
    }
    if ((iVar9 != 0) && (0 < *(int32_t *)(iVar15 + 8))) {
        iVar14 = *(int64_t *)(iVar15 + 0x10);
        uVar13 = 0;
        do {
            iVar10 = uVar13 * 0x38;
            if (*(int32_t *)(iVar10 + iVar14) == iVar9) {
                iVar15 = *(int64_t *)(iVar10 + 8 + iVar14);
                if ((iVar15 != 0) && (func_0x00018010e050(iVar15, 0), *(int32_t *)(iVar6 + 0x21d0) == 0)) {
                    func_0x00018010ee50(*(undefined8 *)(iVar10 + 8 + iVar14), 0);
                }
                break;
            }
            uVar12 = (int32_t)uVar13 + 1;
            uVar13 = (uint64_t)uVar12;
        } while ((int32_t)uVar12 < *(int32_t *)(iVar15 + 8));
    }
    func_0x000180148e50();
    iVar9 = *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148);
    if (iVar9 < 2) {
        if (*(code **)(*(int64_t *)0x180781f28 + 0x2a40) != (code *)0x0) {
            (**(code **)(*(int64_t *)0x180781f28 + 0x2a40))
                      (*(int64_t *)0x180781f28, *(undefined8 *)(*(int64_t *)0x180781f28 + 0x2a48), 0x1806445f8);
        }
    } else {
        *(int32_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar9 + -1;
    }
    if ((*(uint32_t *)(arg1 + 0x10) & 0x400) == 0) {
        *(undefined *)(arg2 + 0x10e) = (undefined)var_195h;
        *(undefined4 *)(arg2 + 0x1b0) = 0;
    }
code_r0x000180118ff0:
    func_0x000180459870(var_98h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_180119020
// Address: 0x180119020
// Size: 101 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180119020(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_10h;
    
    iVar1 = fcn.18046d050(0xb0);
    if (iVar1 != 0) {
        fcn.1804986e0(iVar1, 0, 0xb0);
        *(undefined8 *)(iVar1 + 0x30) = 0xffffffffffffffff;
        *(undefined2 *)(iVar1 + 0x8a) = 0xffff;
        *(int64_t *)(arg1 + 0x40) = iVar1;
        return;
    }
    *(undefined8 *)(arg1 + 0x40) = 0;
    return;
}

// ============================================================
// Function: FUN_180119090
// Address: 0x180119090
// Size: 82 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180119090(int64_t arg1)
{
    int64_t iVar1;
    int64_t var_8h;
    
    iVar1 = *(int64_t *)(arg1 + 0x40);
    if (iVar1 != 0) {
        if (*(int64_t *)(iVar1 + 0xa8) != 0) {
            fcn.180460d90();
        }
        if (*(int64_t *)(iVar1 + 0x10) != 0) {
            fcn.180460d90();
        }
        fcn.180460d90(iVar1);
        *(undefined8 *)(arg1 + 0x40) = 0;
    }
    return;
}

// ============================================================
// Function: FUN_1801191b0
// Address: 0x1801191b0
// Size: 313 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_11eh because it doesn't fit into ProtoModel

undefined8 fcn.1801191b0(int64_t arg1, int64_t arg2)
{
    int32_t iVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int32_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t iVar9;
    int32_t iVar10;
    int64_t var_20h;
    
    iVar2 = *(int64_t *)(arg2 + 0x4c8);
    if (iVar2 == 0) {
        iVar7 = 1;
    } else {
        if (*(int64_t *)(iVar2 + 0x20) != 0) {
            return 1;
        }
        iVar7 = *(int32_t *)(iVar2 + 0x30);
        if (iVar7 < 1) {
            return 0;
        }
    }
    iVar3 = *(int64_t *)(arg1 + 0x4c8);
    iVar10 = 0;
    do {
        iVar9 = arg2;
        if (iVar2 != 0) {
            iVar9 = *(int64_t *)(*(int64_t *)(iVar2 + 0x38) + (int64_t)iVar10 * 8);
        }
        if (((iVar3 == 0) || ((*(uint32_t *)(iVar3 + 0x10) & 0x400) == 0)) ||
           (*(int16_t *)(arg1 + 0x11e) <= *(int16_t *)(iVar9 + 0x11e))) {
            piVar6 = (int32_t *)(iVar3 + 0x68);
            if (iVar3 == 0) {
                piVar6 = (int32_t *)(arg1 + 0x20);
            }
            iVar8 = *(int32_t *)(iVar9 + 0x20);
            iVar1 = *piVar6;
            if (iVar1 == iVar8) goto code_r0x000180119270;
            if ((iVar1 == 0) || (*(char *)((int64_t)piVar6 + 0x1d) == '\0')) {
                if (iVar8 == 0) goto code_r0x0001801192d2;
            } else if (iVar8 == 0) goto code_r0x000180119270;
            if ((*(char *)(iVar9 + 0x3d) != '\0') && (iVar1 == 0)) {
code_r0x000180119270:
                iVar8 = *(int32_t *)(*(int64_t *)0x180781f28 + 0x2120) + -1;
                if (iVar8 < 0) {
                    return 1;
                }
                do {
                    iVar4 = *(int64_t *)((int64_t)iVar8 * 0x38 + 8 + *(int64_t *)(*(int64_t *)0x180781f28 + 0x2128));
                    if (iVar4 != 0) {
                        iVar5 = iVar9;
                        if (*(int64_t *)(iVar9 + 0x418) == iVar4) break;
                        do {
                            if (iVar5 == iVar4) goto code_r0x0001801192d2;
                            iVar5 = *(int64_t *)(iVar5 + 0x410);
                        } while (iVar5 != 0);
                    }
                    iVar8 = iVar8 + -1;
                    if (iVar8 < 0) {
                        return 1;
                    }
                } while( true );
            }
        }
code_r0x0001801192d2:
        iVar10 = iVar10 + 1;
        if (iVar7 <= iVar10) {
            return 0;
        }
    } while( true );
}

// ============================================================
// Function: FUN_1801192f0
// Address: 0x1801192f0
// Size: 582 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_180119536
// Address: 0x180119536
// Size: 33 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_180119557
// Address: 0x180119557
// Size: 2338 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_180119e79
// Address: 0x180119e79
// Size: 634 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_18011a0f3
// Address: 0x18011a0f3
// Size: 81 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_18011a144
// Address: 0x18011a144
// Size: 251 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_18011a23f
// Address: 0x18011a23f
// Size: 46 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_18011a26d
// Address: 0x18011a26d
// Size: 84 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_18011a2c1
// Address: 0x18011a2c1
// Size: 72 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: [rz-ghidra] Detected overlap for variable arg_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_f8h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.1801192f0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h, int64_t arg_30h,
                  int64_t arg_38h, int64_t arg_c8h)
{
    float *pfVar1;
    int64_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int64_t *piVar11;
    uint8_t uVar12;
    uint32_t uVar13;
    undefined8 *puVar14;
    int64_t iVar15;
    uint32_t uVar16;
    int64_t *piVar17;
    undefined8 *puVar18;
    int64_t *piVar19;
    undefined8 *puVar20;
    bool bVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    float fVar28;
    float fVar29;
    float fVar30;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    
    iVar4 = arg_28h;
    iVar3 = *(int64_t *)0x180781f28;
    puVar20 = &var_f8h;
    puVar14 = &var_f8h;
    puVar18 = &var_f8h;
    iVar15 = *(int64_t *)(arg3 + 0x4c8);
    iVar6 = arg2;
    if ((arg2 != 0) && ((*(uint8_t *)(arg2 + 0xdc) & 1) == 0)) {
        iVar2 = *(int64_t *)(arg2 + 0x18);
        while (iVar2 != 0) {
            iVar6 = *(int64_t *)(iVar6 + 0x18);
            iVar2 = *(int64_t *)(iVar6 + 0x18);
        }
    }
    if (iVar15 == 0) {
        uVar16 = *(uint32_t *)(arg3 + 0x38);
    } else {
        uVar16 = *(uint32_t *)(iVar15 + 0x10);
    }
    if (arg2 == 0) {
        uVar13 = *(uint32_t *)(arg1 + 0x38);
    } else {
        uVar13 = *(uint32_t *)(arg2 + 0x10);
    }
    *(undefined *)(arg_28h + 0xe1) = 1;
    if ((((char)arg_38h == '\0') && (*(char *)(iVar3 + 0x81) == '\0')) && ((uVar13 >> 0x14 & 1) == 0)) {
        if (arg2 != 0) {
            if (((uVar13 & 4) == 0) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)) {
                if ((*(int64_t *)(arg2 + 0x20) != 0) || (*(int32_t *)(arg2 + 0x30) != 0)) goto code_r0x0001801193b3;
                goto code_r0x0001801193c9;
            }
            goto code_r0x0001801193fb;
        }
code_r0x0001801193b3:
        if (((iVar15 != 0) && (*(int64_t *)(iVar15 + 0x20) != 0)) && (*(int64_t *)(iVar15 + 0xb0) == 0))
        goto code_r0x0001801193fb;
code_r0x0001801193c9:
        if ((((uVar16 >> 0x15 & 1) != 0) &&
            (((arg2 == 0 || (*(int64_t *)(arg2 + 0x20) != 0)) || (*(int32_t *)(arg2 + 0x30) != 0)))) ||
           ((((uVar16 >> 0x16 & 1) != 0 && (arg2 != 0)) &&
            ((*(int64_t *)(arg2 + 0x20) == 0 && (*(int32_t *)(arg2 + 0x30) == 0)))))) goto code_r0x0001801193fb;
    } else {
code_r0x0001801193fb:
        *(undefined *)(arg_28h + 0xe1) = 0;
    }
    *(undefined *)(arg_28h + 0xe2) = 1;
    if (((uVar13 & 0x10) == 0) && (*(char *)(iVar3 + 0x80) == '\0')) {
        if (((char)arg_38h != '\0') ||
           (((arg2 == 0 || (*(int64_t *)(arg2 + 0x18) != 0)) || ((*(uint32_t *)(arg2 + 0x10) & 0x800) == 0)))) {
            if ((uVar16 >> 0x13 & 1) != 0) goto code_r0x000180119452;
            goto code_r0x000180119459;
        }
        *(undefined *)(arg_28h + 0xe2) = 0;
        uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
    } else {
code_r0x000180119452:
        *(undefined *)(arg_28h + 0xe2) = 0;
code_r0x000180119459:
        if (arg2 == 0) {
            uVar12 = *(uint8_t *)(arg1 + 0x114);
        } else {
            uVar12 = *(uint8_t *)(arg2 + 0xdc) >> 3 & 1;
        }
    }
    if ((uVar12 != 0) || (uVar12 = 0, *(char *)(arg3 + 0x114) != '\0')) {
        uVar12 = 8;
    }
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) & 0xf7;
    *(uint8_t *)(arg_28h + 0xdc) = *(uint8_t *)(arg_28h + 0xdc) | uVar12;
    if (arg2 == 0) {
        uVar12 = ~(uint8_t)(*(uint32_t *)(arg1 + 0x14) >> 5) & 1;
    } else {
        uVar12 = 1;
    }
    *(uint8_t *)(arg_28h + 0xdc) = uVar12 << 4 | *(uint8_t *)(arg_28h + 0xdc) & 0xef;
    puVar7 = (undefined8 *)(iVar6 + 0x48);
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x60);
    }
    *(undefined8 *)(arg_28h + 0x48) = *puVar7;
    if (iVar6 == 0) {
        puVar7 = (undefined8 *)(arg1 + 0x68);
    } else {
        puVar7 = (undefined8 *)(iVar6 + 0x50);
    }
    *(undefined8 *)(arg_28h + 0x50) = *puVar7;
    *(int64_t *)(arg_28h + 0xe8) = arg2;
    *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
    *(undefined *)(arg_28h + 0xe3) = 0;
    if (*(char *)(arg1 + 0x10c) != '\0') goto code_r0x00018011a0f3;
    if (*(char *)(arg_28h + 0xe1) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar24 = fVar27 - fVar23;
        fVar22 = fVar28 - fVar30;
        if (fVar22 <= fVar24) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h != '\0') {
            fVar26 = fVar26 * 1.5;
        }
        fVar22 = (float)(int32_t)fVar26;
        fVar26 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
        fVar24 = fVar22 + fVar26;
        fVar23 = fVar26 - fVar22;
        fVar25 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
        *(float *)(arg_28h + 0xf8) = fVar23;
        fVar30 = fVar22 + fVar25;
        fVar27 = fVar25 - fVar22;
        *(float *)(arg_28h + 0xfc) = fVar27;
        *(float *)(arg_28h + 0x100) = fVar24;
        *(float *)(arg_28h + 0x104) = fVar30;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar25 = *(float *)(iVar3 + 0x11c) - fVar25;
                fVar25 = (*pfVar1 - fVar26) * (*pfVar1 - fVar26) + fVar25 * fVar25;
                if (fVar22 * 1.4 * fVar22 * 1.4 <= fVar25) {
                    fVar26 = (float)(int32_t)(fVar22 * 0.3);
                    fVar23 = fVar23 - fVar26;
                    fVar27 = fVar27 - fVar26;
                    fVar24 = fVar26 + fVar24;
                    fVar30 = fVar26 + fVar30;
                    if (fVar25 < fVar22 * 2.6 * fVar22 * 2.6) goto code_r0x00018011973a;
                    goto code_r0x00018011970b;
                }
            } else {
code_r0x00018011970b:
                if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar27)) ||
                   ((fVar24 <= *pfVar1 || (fVar30 <= fVar23)))) goto code_r0x00018011973a;
            }
            *(undefined4 *)(arg_28h + 0xf0) = 0xffffffff;
            *(undefined *)(arg_28h + 0xe3) = 1;
        }
    }
code_r0x00018011973a:
    if (*(char *)(arg_28h + 0xe2) != '\0') {
        fVar23 = *(float *)(arg_28h + 0x48);
        pfVar1 = (float *)(iVar3 + 0x118);
        fVar30 = *(float *)(arg_28h + 0x4c);
        fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
        fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
        fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
        fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
        fVar27 = fVar28 - fVar23;
        fVar22 = fVar29 - fVar30;
        fVar24 = fVar27;
        if (fVar22 <= fVar27) {
            fVar24 = fVar22;
        }
        if (fVar25 <= fVar24 * 0.125) {
            fVar25 = fVar24 * 0.125;
        }
        if (fVar25 <= fVar26) {
            fVar26 = fVar25;
        }
        if ((char)arg_38h == '\0') {
            fVar25 = (float)(int32_t)fVar26;
            fVar24 = (float)(int32_t)(fVar26 * 0.9);
            fVar26 = fVar25 * 2.4;
        } else {
            fVar25 = (float)(int32_t)(fVar26 * 1.5);
            fVar24 = (float)(int32_t)(fVar26 * 0.8);
            fVar26 = fVar27 * 0.5 - fVar24;
        }
        fVar22 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
        fVar27 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
        fVar23 = fVar25 + fVar27;
        fVar28 = fVar27 - fVar25;
        fVar30 = fVar22 - (float)(int32_t)fVar26;
        fVar26 = fVar30 - fVar24;
        fVar30 = fVar30 + fVar24;
        *(float *)(arg_28h + 0x108) = fVar26;
        *(float *)(arg_28h + 0x10c) = fVar28;
        *(float *)(arg_28h + 0x110) = fVar30;
        *(float *)(arg_28h + 0x114) = fVar23;
        if (pfVar1 != (float *)0x0) {
            if ((char)arg_38h == '\0') {
                fVar22 = *pfVar1 - fVar22;
                fVar27 = *(float *)(iVar3 + 0x11c) - fVar27;
                fVar24 = fVar22 * fVar22 + fVar27 * fVar27;
                if (fVar24 < fVar25 * 1.4 * fVar25 * 1.4) goto code_r0x0001801199cc;
                if (fVar25 * 2.6 * fVar25 * 2.6 <= fVar24) {
                    fVar25 = (float)(int32_t)(fVar25 * 0.3);
                    fVar26 = fVar26 - fVar25;
                    fVar28 = fVar28 - fVar25;
                    fVar30 = fVar30 + fVar25;
                    fVar23 = fVar25 + fVar23;
                    goto code_r0x00018011996c;
                }
                if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar27 & 0x7fffffff)) {
                    bVar21 = 0.0 < fVar27 == 0xfffffffe;
                } else {
                    bVar21 = fVar22 <= 0.0;
                }
            } else {
code_r0x00018011996c:
                if ((((*pfVar1 < fVar26) || (fVar25 = *(float *)(iVar3 + 0x11c), fVar25 < fVar28)) ||
                    (fVar30 <= *pfVar1)) || (fVar23 <= fVar25)) {
                    bVar21 = false;
                } else {
                    bVar21 = true;
                }
            }
            if (bVar21) {
                *(undefined4 *)(arg_28h + 0xf0) = 0;
                *(undefined *)(arg_28h + 0xe3) = 1;
            }
        }
code_r0x0001801199cc:
        if (*(char *)(arg_28h + 0xe2) != '\0') {
            fVar23 = *(float *)(arg_28h + 0x48);
            pfVar1 = (float *)(iVar3 + 0x118);
            fVar30 = *(float *)(arg_28h + 0x4c);
            fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
            fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
            fVar28 = fVar23 + *(float *)(arg_28h + 0x50);
            fVar29 = fVar30 + *(float *)(arg_28h + 0x54);
            fVar27 = fVar28 - fVar23;
            fVar22 = fVar29 - fVar30;
            fVar24 = fVar27;
            if (fVar22 <= fVar27) {
                fVar24 = fVar22;
            }
            if (fVar25 <= fVar24 * 0.125) {
                fVar25 = fVar24 * 0.125;
            }
            if (fVar25 <= fVar26) {
                fVar26 = fVar25;
            }
            if ((char)arg_38h == '\0') {
                fVar24 = (float)(int32_t)fVar26;
                fVar25 = (float)(int32_t)(fVar26 * 0.9);
                fVar26 = fVar24 * 2.4;
            } else {
                fVar24 = (float)(int32_t)(fVar26 * 1.5);
                fVar25 = (float)(int32_t)(fVar26 * 0.8);
                fVar26 = fVar27 * 0.5 - fVar25;
            }
            fVar27 = (float)(int32_t)((fVar28 + fVar23) * 0.5);
            fVar28 = (float)(int32_t)((fVar29 + fVar30) * 0.5);
            fVar22 = fVar24 + fVar28;
            fVar29 = fVar28 - fVar24;
            fVar23 = (float)(int32_t)fVar26 + fVar27;
            fVar30 = fVar23 - fVar25;
            fVar23 = fVar23 + fVar25;
            *(float *)(arg_28h + 0x118) = fVar30;
            *(float *)(arg_28h + 0x11c) = fVar29;
            *(float *)(arg_28h + 0x120) = fVar23;
            *(float *)(arg_28h + 0x124) = fVar22;
            if (pfVar1 != (float *)0x0) {
                if ((char)arg_38h == '\0') {
                    fVar27 = *pfVar1 - fVar27;
                    fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
                    fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
                    if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x000180119c13;
                    if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) {
                        fVar25 = (float)(int32_t)(fVar24 * 0.3);
                        fVar30 = fVar30 - fVar25;
                        fVar29 = fVar29 - fVar25;
                        fVar23 = fVar23 + fVar25;
                        fVar22 = fVar25 + fVar22;
                        goto code_r0x000180119bd9;
                    }
                    if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
                        bVar21 = 0.0 < fVar28 == 0xffffffff;
                    } else {
                        bVar21 = 0.0 < fVar27;
                    }
                } else {
code_r0x000180119bd9:
                    if (((*pfVar1 < fVar30) || (fVar30 = *(float *)(iVar3 + 0x11c), fVar30 < fVar29)) ||
                       ((fVar23 <= *pfVar1 || (fVar22 <= fVar30)))) {
                        bVar21 = false;
                    } else {
                        bVar21 = true;
                    }
                }
                if (bVar21) {
                    *(undefined4 *)(arg_28h + 0xf0) = 1;
                    *(undefined *)(arg_28h + 0xe3) = 1;
                }
            }
code_r0x000180119c13:
            if (*(char *)(arg_28h + 0xe2) != '\0') {
                fVar23 = *(float *)(arg_28h + 0x48);
                pfVar1 = (float *)(iVar3 + 0x118);
                fVar30 = *(float *)(arg_28h + 0x4c);
                fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
                fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
                fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
                fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
                fVar24 = fVar27 - fVar23;
                fVar22 = fVar28 - fVar30;
                if (fVar22 <= fVar24) {
                    fVar24 = fVar22;
                }
                if (fVar25 <= fVar24 * 0.125) {
                    fVar25 = fVar24 * 0.125;
                }
                if (fVar25 <= fVar26) {
                    fVar26 = fVar25;
                }
                if ((char)arg_38h == '\0') {
                    fVar29 = (float)(int32_t)fVar26;
                    fVar24 = fVar29 * 2.4;
                    fVar25 = (float)(int32_t)(fVar26 * 0.9);
                } else {
                    fVar29 = (float)(int32_t)(fVar26 * 1.5);
                    fVar25 = (float)(int32_t)(fVar26 * 0.8);
                    fVar24 = fVar22 * 0.5 - fVar25;
                }
                fVar22 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
                fVar26 = fVar29 + fVar22;
                fVar30 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
                fVar24 = fVar30 - (float)(int32_t)fVar24;
                fVar23 = fVar22 - fVar29;
                fVar27 = fVar24 + fVar25;
                *(float *)(arg_28h + 0x128) = fVar23;
                fVar24 = fVar24 - fVar25;
                *(float *)(arg_28h + 300) = fVar24;
                *(float *)(arg_28h + 0x130) = fVar26;
                *(float *)(arg_28h + 0x134) = fVar27;
                if (pfVar1 != (float *)0x0) {
                    if ((char)arg_38h == '\0') {
                        fVar22 = *pfVar1 - fVar22;
                        fVar30 = *(float *)(iVar3 + 0x11c) - fVar30;
                        fVar25 = fVar22 * fVar22 + fVar30 * fVar30;
                        if (fVar25 < fVar29 * 1.4 * fVar29 * 1.4) goto code_r0x000180119e66;
                        if (fVar29 * 2.6 * fVar29 * 2.6 <= fVar25) {
                            fVar30 = (float)(int32_t)(fVar29 * 0.3);
                            fVar23 = fVar23 - fVar30;
                            fVar26 = fVar30 + fVar26;
                            fVar24 = fVar24 - fVar30;
                            fVar27 = fVar27 + fVar30;
                            goto code_r0x000180119e29;
                        }
                        if ((float)((uint32_t)fVar22 & 0x7fffffff) <= (float)((uint32_t)fVar30 & 0x7fffffff)) {
                            bVar21 = fVar30 <= 0.0;
                        } else {
                            bVar21 = 0.0 < fVar22 == true;
                        }
                    } else {
code_r0x000180119e29:
                        if (((*pfVar1 < fVar23) || (fVar23 = *(float *)(iVar3 + 0x11c), fVar23 < fVar24)) ||
                           ((fVar26 <= *pfVar1 || (fVar27 <= fVar23)))) {
                            bVar21 = false;
                        } else {
                            bVar21 = true;
                        }
                    }
                    if (bVar21) {
                        *(undefined4 *)(arg_28h + 0xf0) = 2;
                        *(undefined *)(arg_28h + 0xe3) = 1;
                    }
                }
            }
        }
    }
code_r0x000180119e66:
    if (*(char *)(arg_28h + 0xe2) == '\0') goto code_r0x00018011a0f3;
    fVar23 = *(float *)(arg_28h + 0x48);
    pfVar1 = (float *)(iVar3 + 0x118);
    fVar30 = *(float *)(arg_28h + 0x4c);
    fVar25 = *(float *)(iVar3 + 0x12f8) * 0.5;
    fVar26 = *(float *)(iVar3 + 0x12f8) * 1.5;
    fVar27 = fVar23 + *(float *)(arg_28h + 0x50);
    fVar28 = fVar30 + *(float *)(arg_28h + 0x54);
    fVar24 = fVar27 - fVar23;
    fVar22 = fVar28 - fVar30;
    if (fVar22 <= fVar24) {
        fVar24 = fVar22;
    }
    if (fVar25 <= fVar24 * 0.125) {
        fVar25 = fVar24 * 0.125;
    }
    if (fVar25 <= fVar26) {
        fVar26 = fVar25;
    }
    if ((char)arg_38h == '\0') {
        fVar24 = (float)(int32_t)fVar26;
        fVar22 = fVar24 * 2.4;
        fVar25 = (float)(int32_t)(fVar26 * 0.9);
    } else {
        fVar24 = (float)(int32_t)(fVar26 * 1.5);
        fVar25 = (float)(int32_t)(fVar26 * 0.8);
        fVar22 = fVar22 * 0.5 - fVar25;
    }
    fVar27 = (float)(int32_t)((fVar27 + fVar23) * 0.5);
    fVar26 = fVar24 + fVar27;
    fVar28 = (float)(int32_t)((fVar28 + fVar30) * 0.5);
    fVar30 = (float)(int32_t)fVar22 + fVar28;
    fVar22 = fVar30 + fVar25;
    fVar30 = fVar30 - fVar25;
    fVar23 = fVar27 - fVar24;
    *(float *)(arg_28h + 0x138) = fVar23;
    *(float *)(arg_28h + 0x13c) = fVar30;
    *(float *)(arg_28h + 0x140) = fVar26;
    *(float *)(arg_28h + 0x144) = fVar22;
    if (pfVar1 == (float *)0x0) goto code_r0x00018011a0f3;
    if ((char)arg_38h == '\0') {
        fVar27 = *pfVar1 - fVar27;
        fVar28 = *(float *)(iVar3 + 0x11c) - fVar28;
        fVar25 = fVar27 * fVar27 + fVar28 * fVar28;
        if (fVar25 < fVar24 * 1.4 * fVar24 * 1.4) goto code_r0x00018011a0f3;
        fVar29 = (float)(int32_t)(fVar24 * 0.3);
        fVar23 = fVar23 - fVar29;
        fVar26 = fVar29 + fVar26;
        fVar30 = fVar30 - fVar29;
        fVar22 = fVar22 + fVar29;
        if (fVar24 * 2.6 * fVar24 * 2.6 <= fVar25) goto code_r0x00018011a07a;
        if ((float)((uint32_t)fVar27 & 0x7fffffff) <= (float)((uint32_t)fVar28 & 0x7fffffff)) {
            bVar21 = 0.0 < fVar28;
        } else {
            bVar21 = 0.0 < fVar27 == true;
        }
    } else {
code_r0x00018011a07a:
        if ((((*pfVar1 < fVar23) || (*(float *)(iVar3 + 0x11c) < fVar30)) || (fVar26 <= *pfVar1)) ||
           (fVar22 <= *(float *)(iVar3 + 0x11c))) {
            bVar21 = false;
        } else {
            bVar21 = true;
        }
    }
    if (bVar21) {
        *(undefined4 *)(arg_28h + 0xf0) = 3;
        *(undefined *)(arg_28h + 0xe3) = 1;
    }
code_r0x00018011a0f3:
    uVar16 = *(uint32_t *)(arg_28h + 0xf0);
    if ((uVar16 == 0xffffffff) && (*(char *)(arg_28h + 0xe1) == '\0')) {
        uVar5 = 0;
    } else {
        uVar5 = 1;
    }
    *(undefined *)(arg_28h + 0xe0) = uVar5;
    if ((((char)arg_30h == '\0') && (*(char *)(arg_28h + 0xe3) == '\0')) && (*(char *)(iVar3 + 0x82) == '\0')) {
        *(undefined *)(arg_28h + 0xe0) = 0;
    }
    *(undefined4 *)(arg_28h + 0xf4) = 0;
    if (uVar16 != 0xffffffff) {
        if (uVar16 < 2) {
            iVar15 = 0x50;
        } else {
            puVar14 = (undefined8 *)((int64_t)&var_f8h + 4);
            iVar15 = 0x54;
        }
        fVar23 = *(float *)(iVar3 + 0xdf4);
        arg_28h = *(int64_t *)(arg_28h + 0x48);
        var_f0h = *(int64_t *)(iVar4 + 0x50);
        var_20h = 0;
        var_f8h = 0;
        var_e8h = *(int64_t *)(arg3 + 0x68);
        bVar21 = uVar16 < 2;
        if (bVar21) {
            var_10h = (int64_t)&var_20h;
            piVar19 = &arg_28h;
            piVar8 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar17 = &var_f0h;
            piVar9 = &var_e8h;
            piVar11 = (int64_t *)((int64_t)&var_20h + 4);
            piVar10 = (int64_t *)((int64_t)&var_f0h + 4);
            puVar20 = (undefined8 *)((int64_t)&var_f8h + 4);
        } else {
            var_10h = (int64_t)&var_20h + 4;
            piVar19 = (int64_t *)((int64_t)&arg_28h + 4);
            piVar8 = &arg_28h;
            piVar17 = (int64_t *)((int64_t)&var_f0h + 4);
            piVar9 = (int64_t *)((int64_t)&var_e8h + 4);
            puVar18 = (undefined8 *)((int64_t)&var_f8h + 4);
            piVar11 = &var_20h;
            piVar10 = &var_f0h;
        }
        var_8h = (int64_t)!bVar21;
        fVar25 = *(float *)piVar17 - fVar23;
        fVar30 = *(float *)piVar9;
        *(undefined4 *)piVar11 = *(undefined4 *)piVar8;
        *(undefined4 *)puVar20 = *(undefined4 *)piVar10;
        fVar24 = fVar25 * 0.5;
        if ((fVar30 <= 0.0) || (fVar24 < fVar30)) {
            fVar30 = (float)(int32_t)fVar24;
        }
        *(float *)puVar18 = fVar30;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            *(float *)var_10h = (float)(int32_t)(fVar25 - fVar30) + *(float *)piVar19 + fVar23;
        } else if ((uVar16 & 0xfffffffd) == 0) {
            *(undefined4 *)((int64_t)&var_20h + (uint64_t)!bVar21 * 4) = *(undefined4 *)((int64_t)&arg_28h + var_8h * 4)
            ;
        }
        fVar30 = *(float *)puVar14 / *(float *)(iVar15 + iVar4);
        fVar23 = 0.0;
        if ((0.0 <= fVar30) && (fVar23 = 1.0, fVar30 <= 1.0)) {
            fVar23 = fVar30;
        }
        *(int64_t *)(iVar4 + 0x48) = var_20h;
        *(undefined8 *)(iVar4 + 0x50) = var_f8h;
        if ((uVar16 - 1 & 0xfffffffd) == 0) {
            fVar23 = 1.0 - fVar23;
        }
        *(float *)(iVar4 + 0xf4) = fVar23;
    }
    return;
}

// ============================================================
// Function: FUN_18011a310
// Address: 0x18011a310
// Size: 3166 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1a8h
// WARNING: Variable defined which should be unmapped: var_1a0h
// WARNING: Variable defined which should be unmapped: var_198h
// WARNING: Variable defined which should be unmapped: var_190h
// WARNING: Variable defined which should be unmapped: var_188h
// WARNING: Variable defined which should be unmapped: var_180h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_168h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_50h
// WARNING: [rz-ghidra] Detected overlap for variable var_4ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_14ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_170h

void fcn.18011a310(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_d0h, int64_t arg_d8h,
                  int64_t arg_e0h, int64_t arg_e8h)
{
    int32_t *piVar1;
    int64_t iVar2;
    bool bVar3;
    bool bVar4;
    bool bVar5;
    bool bVar6;
    undefined4 uVar7;
    undefined4 uVar8;
    bool bVar9;
    char cVar10;
    undefined4 uVar11;
    uint32_t uVar12;
    undefined4 *puVar13;
    int64_t iVar14;
    int64_t iVar15;
    uint32_t uVar16;
    undefined8 uVar17;
    int64_t iVar18;
    int64_t *piVar19;
    int32_t iVar20;
    uint32_t uVar21;
    int32_t iVar22;
    undefined8 uVar23;
    float *pfVar24;
    uint32_t uVar25;
    int32_t iVar26;
    int32_t iVar27;
    int32_t iVar28;
    float fVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    float fVar38;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    int64_t var_190h;
    int64_t var_188h;
    int64_t var_180h;
    int64_t var_178h;
    float var_170h;
    int64_t var_16ch;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_150h;
    float fStack_148;
    float fStack_144;
    float fStack_140;
    float fStack_13c;
    undefined4 uStack_138;
    undefined4 uStack_134;
    float fStack_130;
    float fStack_12c;
    float fStack_128;
    float fStack_124;
    undefined4 uStack_120;
    float fStack_11c;
    float fStack_118;
    float fStack_114;
    float fStack_110;
    float fStack_10c;
    int64_t aiStack_108 [2];
    float fStack_f8;
    float fStack_f4;
    float fStack_f0;
    float fStack_ec;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_54h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    iVar14 = *(int64_t *)(arg1 + 0x48);
    var_160h = *(int64_t *)0x180781f28;
    cVar10 = *(char *)(*(int64_t *)0x180781f28 + 0x84);
    if (iVar14 == 0) {
        iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x48);
    }
    aiStack_108[0] = func_0x0001800fa7f0(iVar14, 1, 0x1806444d0);
    iVar14 = *(int64_t *)(arg3 + 0x48);
    iVar27 = 1;
    fVar30 = 0.6;
    var_158h._0_4_ = 1;
    fVar29 = fVar30;
    if (*(int64_t *)(arg1 + 0x48) == iVar14) {
        iVar20 = 1;
        if (cVar10 == '\0') goto code_r0x00018011a425;
    } else if (cVar10 == '\0') {
        if (iVar14 == 0) {
            iVar14 = *(int64_t *)(*(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0) + 0x48);
        }
        aiStack_108[1] = func_0x0001800fa7f0(iVar14, 1, 0x1806444d0);
        var_158h._0_4_ = 2;
        iVar20 = 2;
code_r0x00018011a425:
        iVar27 = iVar20;
        fVar29 = 0.4;
    }
    var_178h._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1160);
    var_178h._4_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x1164);
    var_170h = *(float *)(*(int64_t *)0x180781f28 + 0x1168);
    fVar33 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
    var_16ch._0_4_ = *(float *)(*(int64_t *)0x180781f28 + 0x116c) * fVar33 * fVar29;
    iVar14 = *(int64_t *)0x180781f28;
    uVar11 = fcn.1800f5fa0(&var_178h);
    fStack_128 = *(float *)(iVar14 + 0x1160);
    fStack_124 = *(float *)(iVar14 + 0x1164);
    uStack_120 = *(undefined4 *)(iVar14 + 0x1168);
    if (cVar10 == '\0') {
        fStack_11c = fVar33 * 0.7;
        var_178h._0_4_ = *(float *)(iVar14 + 0x1160);
        var_178h._4_4_ = *(float *)(iVar14 + 0x1164);
        var_170h = *(float *)(iVar14 + 0x1168);
        var_16ch._0_4_ = *(float *)(iVar14 + 0x116c) * fVar33;
    } else {
        fStack_11c = fVar33 * 0.9;
        fVar30 = 0.8;
        var_178h._0_4_ = *(float *)(iVar14 + 0x1160);
        var_178h._4_4_ = *(float *)(iVar14 + 0x1164);
        var_170h = *(float *)(iVar14 + 0x1168);
        var_16ch._0_4_ = *(float *)(iVar14 + 0x116c) * fVar33 * 1.2;
    }
    fStack_11c = *(float *)(iVar14 + 0x116c) * fStack_11c;
    uStack_138 = fcn.1800f5fa0(&var_178h);
    uStack_134 = fcn.1800f5fa0(&fStack_128);
    var_178h._0_4_ = *(float *)(iVar14 + 0x1280);
    var_178h._4_4_ = *(float *)(iVar14 + 0x1284);
    var_170h = *(float *)(iVar14 + 0x1288);
    var_16ch._0_4_ = *(float *)(iVar14 + 0x128c) * fVar33 * fVar30;
    var_16ch._4_4_ = fcn.1800f5fa0(&var_178h);
    iVar15 = var_160h;
    if ((*(int64_t *)(arg3 + 0x4c8) == 0) || (0 < *(int32_t *)(*(int64_t *)(arg3 + 0x4c8) + 0x30))) {
        bVar9 = true;
    } else {
        bVar9 = false;
    }
    if (*(char *)(arg4 + 0xe0) == '\0') goto code_r0x00018011abe8;
    fVar29 = *(float *)(arg4 + 0x48);
    var_178h._4_4_ = *(float *)(arg4 + 0x4c);
    fVar30 = fVar29 + *(float *)(arg4 + 0x50);
    fVar33 = var_178h._4_4_ + *(float *)(arg4 + 0x54);
    var_178h._0_4_ = fVar29;
    var_170h = fVar30;
    var_16ch._0_4_ = fVar33;
    if (*(int32_t *)(arg4 + 0xf0) == -1) {
        if (bVar9) {
            var_178h._4_4_ =
                 *(float *)(iVar14 + 0xde0) + *(float *)(iVar14 + 0xde0) + *(float *)(iVar14 + 0x12f8) + var_178h._4_4_;
        }
        if (*(char *)(arg4 + 0xe1) != '\0') goto code_r0x00018011a5e7;
    } else {
code_r0x00018011a5e7:
        fVar34 = var_178h._4_4_;
        iVar20 = 0;
        do {
            fVar37 = *(float *)(iVar15 + 0xebc);
            bVar3 = *(float *)(arg1 + 0x60) + fVar37 < fVar29;
            bVar4 = fVar30 < (*(float *)(arg1 + 0x60) + *(float *)(arg1 + 0x68)) - fVar37;
            bVar5 = *(float *)(arg1 + 100) + fVar37 < fVar34;
            bVar6 = fVar33 < (*(float *)(arg1 + 100) + *(float *)(arg1 + 0x6c)) - fVar37;
            if ((bVar5) || (bVar3)) {
                uVar16 = 0;
                if (!bVar5) goto code_r0x00018011a662;
code_r0x00018011a66c:
                uVar25 = 0x100;
            } else {
                uVar16 = 0x10;
code_r0x00018011a662:
                uVar25 = 0x120;
                if (bVar4) goto code_r0x00018011a66c;
            }
            if ((bVar6) || (bVar3)) {
                uVar21 = 0;
                if (!bVar6) goto code_r0x00018011a688;
code_r0x00018011a694:
                uVar12 = 0;
            } else {
                uVar21 = 0x40;
code_r0x00018011a688:
                if (bVar4) goto code_r0x00018011a694;
                uVar12 = 0x80;
            }
            var_1a8h = CONCAT44(var_1a8h._4_4_, *(undefined4 *)(arg1 + 0x98));
            func_0x000180126550(aiStack_108[iVar20], &var_178h, &var_170h, uVar11, var_1a8h, 
                                uVar12 | uVar16 | uVar21 | uVar25);
            iVar20 = iVar20 + 1;
            iVar14 = *(int64_t *)0x180781f28;
        } while (iVar20 < iVar27);
    }
    if ((((*(char *)(arg4 + 0xe0) == '\0') || (!bVar9)) || (*(int32_t *)(arg4 + 0xf0) != -1)) ||
       (*(char *)(arg4 + 0xe1) == '\0')) goto code_r0x00018011abe8;
    fVar29 = *(float *)(iVar14 + 0x12f8);
    fVar30 = *(float *)(arg4 + 0x4c);
    fVar37 = *(float *)(iVar14 + 0xde0) + *(float *)(iVar14 + 0xde0) + fVar29 + fVar30;
    fVar33 = *(float *)(iVar14 + 0xdb0) + *(float *)(arg4 + 0x48) + *(float *)(iVar14 + 0xddc);
    fVar34 = ((*(float *)(arg4 + 0x48) + *(float *)(arg4 + 0x50)) - *(float *)(iVar14 + 0xdb0)) -
             *(float *)(iVar14 + 0xddc);
    if ((*(uint8_t *)(arg4 + 0xdc) & 8) != 0) {
        fVar34 = fVar34 - (fVar29 + *(float *)(iVar14 + 0xdf4));
    }
    if ((*(uint8_t *)(arg4 + 0xdc) & 0x10) != 0) {
        if (*(int32_t *)(iVar14 + 0xdc8) == 0) {
            fVar33 = fVar29 + *(float *)(iVar14 + 0xdf4) + fVar33;
        } else if (*(int32_t *)(iVar14 + 0xdc8) == 1) {
            fVar34 = fVar34 - (fVar29 + *(float *)(iVar14 + 0xdf4));
        }
    }
    if ((arg2 == 0) || (*(int64_t *)(arg2 + 0x40) == 0)) {
        fVar29 = fVar33;
        if ((*(uint32_t *)(arg1 + 0x14) >> 0x17 & 1) == 0) {
            if ((*(char *)(arg1 + 0x114) == '\0') && ((*(uint32_t *)(arg1 + 0x14) >> 0x12 & 1) == 0)) {
                uVar17 = *(undefined8 *)(arg1 + 8);
                uVar23 = 0;
            } else {
                uVar17 = *(undefined8 *)(arg1 + 8);
                uVar23 = 1;
            }
            goto code_r0x00018011a817;
        }
    } else {
        if (((*(uint32_t *)(arg2 + 0x10) >> 0xd & 1) == 0) && ((*(uint32_t *)(arg2 + 0x10) >> 0xc & 1) == 0)) {
            fVar29 = *(float *)(*(int64_t *)(arg2 + 0x40) + 0x54);
        } else {
            iVar14 = **(int64_t **)(arg2 + 0x38);
            if ((*(char *)(iVar14 + 0x114) == '\0') && ((*(uint32_t *)(iVar14 + 0x14) & 0x40000) == 0)) {
                uVar23 = 0;
            } else {
                uVar23 = 1;
            }
            uVar17 = *(undefined8 *)(iVar14 + 8);
code_r0x00018011a817:
            func_0x00018014be50(&var_178h, uVar17, uVar23);
            fVar29 = (float)var_178h;
        }
        fVar29 = fVar29 + *(float *)(var_160h + 0xdf4) + fVar33;
    }
    if (*(int64_t *)(arg3 + 0x4c8) == 0) {
        var_150h = 0;
code_r0x00018011a8b0:
        fStack_140 = 1.401298e-45;
        fStack_148 = 0.0;
        iVar14 = var_150h;
    } else {
        iVar14 = *(int64_t *)(*(int64_t *)(arg3 + 0x4c8) + 0x40);
        var_150h = iVar14;
        if (iVar14 == 0) goto code_r0x00018011a8b0;
        fStack_140 = *(float *)(iVar14 + 8);
        fStack_148 = 0.0;
        if ((int32_t)fStack_140 < 1) goto code_r0x00018011abe8;
    }
    do {
        iVar2 = var_160h;
        iVar27 = 0;
        iVar15 = arg3;
        fVar38 = fVar29;
        if (((iVar14 == 0) ||
            (iVar15 = *(int64_t *)((int64_t)(int32_t)fStack_148 * 0x38 + 8 + *(int64_t *)(iVar14 + 0x10)), iVar15 != 0))
           && (cVar10 = func_0x0001801190f0(iVar15, arg1), iVar14 = var_150h, cVar10 != '\0')) {
            if ((*(char *)(iVar15 + 0x114) == '\0') && ((*(uint32_t *)(iVar15 + 0x14) & 0x40000) == 0)) {
                uVar17 = 0;
            } else {
                uVar17 = 1;
            }
            func_0x00018014be50(&fStack_130, *(undefined8 *)(iVar15 + 8), uVar17);
            fVar35 = fStack_130 + fVar29;
            fVar36 = fStack_12c + fVar30;
            uVar16 = *(uint32_t *)(iVar15 + 0x498);
            fVar32 = *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
            fVar38 = fVar29 + fStack_130 + *(float *)(iVar2 + 0xdf4);
            if (fVar32 < 1.0) {
                uVar16 = (int32_t)(int64_t)((float)(uint64_t)(uVar16 >> 0x18) * fVar32) << 0x18 | uVar16 & 0xffffff;
            }
            uVar25 = *(uint32_t *)(iVar15 + 0x4a4);
            if (fVar32 < 1.0) {
                uVar25 = (int32_t)(int64_t)((float)(uint64_t)(uVar25 >> 0x18) * fVar32) << 0x18 | uVar25 & 0xffffff;
            }
            uVar21 = *(uint32_t *)(iVar15 + 0x4b8);
            if (fVar32 < 1.0) {
                uVar21 = (int32_t)(int64_t)((float)(uint64_t)(uVar21 >> 0x18) * fVar32) << 0x18 | uVar21 & 0xffffff;
            }
            var_178h._0_4_ = fVar29;
            var_178h._4_4_ = fVar30;
            var_170h = fVar35;
            var_16ch._0_4_ = fVar36;
            func_0x0001800f6650(0, uVar16);
            func_0x0001800f6650(0x39, uVar21);
            do {
                uVar16 = *(uint32_t *)(iVar15 + 0x14) >> 0x12 & 1;
                if (((fVar29 < fVar33) || (NAN(fVar30))) || ((fVar34 < fVar35 || (fVar37 < fVar36)))) {
                    fVar32 = fVar33;
                    if (fVar33 <= fVar34) {
                        fVar32 = fVar34;
                    }
                    fVar31 = fVar30;
                    if (fVar30 <= fVar37) {
                        fVar31 = fVar37;
                    }
                    iVar14 = aiStack_108[iVar27];
                    iVar20 = *(int32_t *)(iVar14 + 0xa4);
                    piVar1 = (int32_t *)(iVar14 + 0xa0);
                    if (*piVar1 == iVar20) {
                        iVar28 = *piVar1 + 1;
                        if (iVar20 == 0) {
                            iVar20 = 8;
                        } else {
                            iVar20 = iVar20 / 2 + iVar20;
                        }
                        if (iVar28 < iVar20) {
                            iVar28 = iVar20;
                        }
                        func_0x00018011faa0(piVar1, iVar28);
                    }
                    iVar18 = (int64_t)*piVar1;
                    iVar2 = *(int64_t *)(iVar14 + 0xa8);
                    *(float *)(iVar2 + iVar18 * 0x10) = fVar33;
                    *(float *)(iVar2 + 4 + iVar18 * 0x10) = fVar30;
                    *(float *)(iVar2 + 8 + iVar18 * 0x10) = fVar32;
                    *(float *)(iVar2 + 0xc + iVar18 * 0x10) = fVar31;
                    *piVar1 = *piVar1 + 1;
                    *(float *)(iVar14 + 0x60) = fVar33;
                    *(float *)(iVar14 + 100) = fVar30;
                    *(float *)(iVar14 + 0x68) = fVar32;
                    *(float *)(iVar14 + 0x6c) = fVar31;
                    func_0x0001801242c0(iVar14);
                }
                iVar14 = aiStack_108[iVar27];
                func_0x00018014bf10(iVar14, &var_178h, uVar16, uVar25);
                var_1a8h = *(int64_t *)(iVar15 + 8);
                func_0x00018014c270(iVar14, &var_178h, uVar16, *(undefined8 *)(var_160h + 0xddc), var_1a8h, 0, 0, 0, 0, 
                                    0);
                if ((((fVar29 < fVar33) || (NAN(fVar30))) || (fVar34 < fVar35)) || (fVar37 < fVar36)) {
                    piVar1 = (int32_t *)(iVar14 + 0xa0);
                    *piVar1 = *piVar1 + -1;
                    if (*piVar1 == 0) {
                        puVar13 = (undefined4 *)(*(int64_t *)(iVar14 + 0x38) + 0x38);
                    } else {
                        puVar13 = (undefined4 *)
                                  ((int64_t)(*(int32_t *)(iVar14 + 0xa0) + -1) * 0x10 + *(int64_t *)(iVar14 + 0xa8));
                    }
                    uVar11 = puVar13[1];
                    uVar7 = puVar13[2];
                    uVar8 = puVar13[3];
                    *(undefined4 *)(iVar14 + 0x60) = *puVar13;
                    *(undefined4 *)(iVar14 + 100) = uVar11;
                    *(undefined4 *)(iVar14 + 0x68) = uVar7;
                    *(undefined4 *)(iVar14 + 0x6c) = uVar8;
                    func_0x0001801242c0(iVar14);
                }
                iVar27 = iVar27 + 1;
            } while (iVar27 < (int32_t)var_158h);
            fcn.1800f6770(2);
            iVar14 = var_150h;
        }
        fStack_148 = (float)((int32_t)fStack_148 + 1);
        fVar29 = fVar38;
    } while ((int32_t)fStack_148 < (int32_t)fStack_140);
code_r0x00018011abe8:
    uVar16 = 0xffffffff;
    iVar14 = var_160h;
    fVar29 = 3.0;
    if (3.0 <= *(float *)(var_160h + 0xde4)) {
        fVar29 = *(float *)(var_160h + 0xde4);
    }
    do {
        iVar15 = (int64_t)(int32_t)uVar16;
        fVar30 = *(float *)(arg4 + 0x108 + iVar15 * 0x10);
        pfVar24 = (float *)(arg4 + 0x110 + iVar15 * 0x10);
        if ((fVar30 < *pfVar24 || fVar30 == *pfVar24) &&
           (fVar30 = *(float *)(arg4 + 0x10c + iVar15 * 0x10), pfVar24 = (float *)(arg4 + 0x114 + iVar15 * 0x10),
           fVar30 < *pfVar24 || fVar30 == *pfVar24)) {
            pfVar24 = (float *)(arg4 + 0x108 + iVar15 * 0x10);
            fVar37 = *pfVar24 - -2.0;
            fVar34 = pfVar24[1] - -2.0;
            fVar33 = pfVar24[2] - 2.0;
            fStack_f8 = *pfVar24;
            fStack_f4 = pfVar24[1];
            fStack_f0 = pfVar24[2];
            fStack_ec = pfVar24[3];
            fVar30 = pfVar24[3] - 2.0;
            if ((*(uint32_t *)(arg4 + 0xf0) != uVar16) || (uVar11 = uStack_138, *(char *)(arg4 + 0xe3) == '\0')) {
                uVar11 = uStack_134;
            }
            iVar27 = 0;
            uVar25 = var_16ch._4_4_ & 0xff000000;
            fVar32 = (fVar37 + fVar33) * 0.5;
            fVar38 = (fVar34 + fVar30) * 0.5;
            iVar20 = (int32_t)fVar32;
            iVar28 = (int32_t)fVar38;
            do {
                iVar26 = iVar28;
                if ((fVar38 < 0.0) && ((float)iVar28 != fVar38)) {
                    iVar26 = iVar28 + -1;
                }
                iVar22 = iVar20;
                if ((fVar32 < 0.0) && ((float)iVar20 != fVar32)) {
                    iVar22 = iVar20 + -1;
                }
                var_1a8h = CONCAT44(var_1a8h._4_4_, fVar29);
                iVar14 = aiStack_108[iVar27];
                func_0x000180126550(iVar14, &fStack_f8, &fStack_f0, uVar11, var_1a8h, 0);
                if (uVar25 != 0) {
                    if ((*(uint8_t *)(iVar14 + 0x30) & 1) == 0) {
                        fStack_140 = fVar33 - 0.49;
                        fStack_13c = fVar30 - 0.49;
                        pfVar24 = &fStack_140;
                        piVar19 = (int64_t *)&fStack_148;
                        fStack_148 = fVar37 + 0.5;
                        fStack_144 = fVar34 + 0.5;
                    } else {
                        fStack_130 = fVar33 - 0.5;
                        fStack_12c = fVar30 - 0.5;
                        var_150h = CONCAT44(fVar34 + 0.5, fVar37 + 0.5);
                        pfVar24 = &fStack_130;
                        piVar19 = &var_150h;
                    }
                    func_0x000180125f20(iVar14, piVar19, pfVar24, fVar29, 0);
                    var_1a8h = CONCAT44(var_1a8h._4_4_, 1);
                    func_0x0001801248e0(iVar14, *(undefined8 *)(iVar14 + 0x58), *(undefined4 *)(iVar14 + 0x50), 
                                        var_16ch._4_4_, var_1a8h, 0x3f800000);
                    *(undefined4 *)(iVar14 + 0x50) = 0;
                }
                uVar21 = var_16ch._4_4_;
                if (uVar16 < 2) {
                    fStack_118 = (float)iVar22;
                    var_1a8h = CONCAT44(var_1a8h._4_4_, 0x3f800000);
                    fStack_114 = fVar30;
                    fStack_110 = fStack_118;
                    fStack_10c = fVar34;
                    func_0x000180126300(iVar14, &fStack_110, &fStack_118, var_16ch._4_4_, var_1a8h);
                }
                if (uVar16 - 2 < 2) {
                    var_178h._4_4_ = (float)iVar26;
                    var_1a8h = CONCAT44(var_1a8h._4_4_, 0x3f800000);
                    var_178h._0_4_ = fVar37;
                    fStack_128 = fVar33;
                    fStack_124 = var_178h._4_4_;
                    func_0x000180126300(iVar14, &var_178h, &fStack_128, uVar21, var_1a8h);
                }
                iVar27 = iVar27 + 1;
                iVar14 = var_160h;
            } while (iVar27 < (int32_t)var_158h);
        }
    } while ((((arg2 == 0) || ((*(uint8_t *)(arg2 + 0x10) & 0x10) == 0)) && (*(char *)(iVar14 + 0x80) == '\0')) &&
            (uVar16 = uVar16 + 1, (int32_t)uVar16 < 4));
    return;
}

// ============================================================
// Function: FUN_18011af70
// Address: 0x18011af70
// Size: 610 bytes
// ============================================================
void fcn.18011af70(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg_a0h)
{
    undefined8 *puVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    undefined4 *puVar5;
    int64_t iVar6;
    uint32_t uVar7;
    uint32_t uVar8;
    undefined8 *puVar9;
    uint32_t uVar10;
    undefined8 uVar11;
    int64_t var_68h;
    int64_t var_58h;
    
    puVar4 = *(undefined4 **)(arg2 + 0x20);
    puVar5 = *(undefined4 **)(arg2 + 0x28);
    uVar2 = *(undefined4 *)(arg2 + 0x58);
    uVar3 = *(undefined4 *)(arg2 + 0x5c);
    iVar6 = *(int64_t *)(arg3 + 0x20);
    *(int64_t *)(arg2 + 0x20) = iVar6;
    *(undefined8 *)(arg2 + 0x28) = *(undefined8 *)(arg3 + 0x28);
    if (iVar6 != 0) {
        *(int64_t *)(iVar6 + 0x18) = arg2;
    }
    if (*(int64_t *)(arg2 + 0x28) != 0) {
        *(int64_t *)(*(int64_t *)(arg2 + 0x28) + 0x18) = arg2;
    }
    *(undefined4 *)(arg2 + 0x60) = *(undefined4 *)(arg3 + 0x60);
    *(undefined8 *)(arg2 + 0x58) = *(undefined8 *)(arg3 + 0x58);
    *(undefined8 *)(arg3 + 0x28) = 0;
    *(undefined8 *)(arg3 + 0x20) = 0;
    if (puVar4 != (undefined4 *)0x0) {
        func_0x0001801167e0(arg2, puVar4);
        func_0x00018011d570(*puVar4, *(undefined4 *)arg2);
    }
    if (puVar5 != (undefined4 *)0x0) {
        func_0x0001801167e0(arg2, puVar5);
        func_0x00018011d570(*puVar5, *(undefined4 *)arg2);
    }
    puVar9 = *(undefined8 **)(arg2 + 0x38);
    puVar1 = puVar9 + *(int32_t *)(arg2 + 0x30);
    for (; puVar9 != puVar1; puVar9 = puVar9 + 1) {
        uVar11 = func_0x000180106470(*puVar9, arg2 + 0x48, 1);
        func_0x0001801065c0(uVar11, arg2 + 0x50, 1);
    }
    *(uint32_t *)(arg2 + 0xd8) = *(uint32_t *)(arg2 + 0xd8) & 0xfffffe00;
    *(undefined8 *)(arg2 + 0xa0) = *(undefined8 *)(arg3 + 0xa0);
    *(undefined4 *)(arg2 + 0x58) = uVar2;
    *(undefined4 *)(arg2 + 0x5c) = uVar3;
    uVar8 = *(uint32_t *)(arg2 + 8);
    *(uint32_t *)(arg2 + 8) = uVar8 & 0xfffc078f;
    uVar10 = 0;
    uVar7 = uVar10;
    if (puVar4 != (undefined4 *)0x0) {
        uVar7 = puVar4[2];
    }
    uVar7 = (uVar8 ^ uVar7) & 0xfffc078f ^ uVar7;
    *(uint32_t *)(arg2 + 8) = uVar7;
    uVar8 = uVar10;
    if (puVar5 != (undefined4 *)0x0) {
        uVar8 = puVar5[2];
    }
    uVar7 = uVar8 & 0x3f870 | uVar7;
    *(uint32_t *)(arg2 + 8) = uVar7;
    uVar8 = uVar10;
    if (puVar4 != (undefined4 *)0x0) {
        uVar8 = puVar4[3];
    }
    if (puVar5 != (undefined4 *)0x0) {
        uVar10 = puVar5[3];
    }
    *(uint32_t *)(arg2 + 0xc) = uVar10 | uVar8;
    *(uint32_t *)(arg2 + 0x10) = uVar10 | uVar8 | *(uint32_t *)(arg2 + 4) | uVar7;
    if (puVar4 != (undefined4 *)0x0) {
        iVar6 = *(int64_t *)(puVar4 + 0x10);
        if (iVar6 != 0) {
            if (*(int64_t *)(iVar6 + 0xa8) != 0) {
                fcn.180460d90();
            }
            if (*(int64_t *)(iVar6 + 0x10) != 0) {
                fcn.180460d90();
            }
            fcn.180460d90(iVar6);
        }
        *(undefined8 *)(puVar4 + 0x10) = 0;
        func_0x0001800f6220(arg1 + 0x28e8, *puVar4, 0);
        *(undefined8 *)(puVar4 + 10) = 0;
        *(undefined8 *)(puVar4 + 8) = 0;
        if (*(int64_t *)(puVar4 + 0xe) != 0) {
            fcn.180460d90();
        }
        fcn.180460d90(puVar4);
    }
    if (puVar5 != (undefined4 *)0x0) {
        iVar6 = *(int64_t *)(puVar5 + 0x10);
        if (iVar6 != 0) {
            if (*(int64_t *)(iVar6 + 0xa8) != 0) {
                fcn.180460d90();
            }
            if (*(int64_t *)(iVar6 + 0x10) != 0) {
                fcn.180460d90();
            }
            fcn.180460d90(iVar6);
        }
        *(undefined8 *)(puVar5 + 0x10) = 0;
        func_0x0001800f6220(arg1 + 0x28e8, *puVar5, 0);
        *(undefined8 *)(puVar5 + 10) = 0;
        *(undefined8 *)(puVar5 + 8) = 0;
        if (*(int64_t *)(puVar5 + 0xe) != 0) {
            fcn.180460d90();
        }
        fcn.180460d90(puVar5);
    }
    return;
}

// ============================================================
// Function: FUN_18011b1e0
// Address: 0x18011b1e0
// Size: 845 bytes
// ============================================================
void fcn.18011b1e0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    float fVar1;
    float fVar2;
    uint8_t uVar3;
    uint8_t uVar4;
    int64_t arg1_00;
    int64_t iVar5;
    bool bVar6;
    bool bVar7;
    int64_t iVar8;
    int64_t iVar9;
    float *pfVar10;
    uint8_t uVar11;
    uint8_t uVar12;
    float fVar13;
    float fVar14;
    float fVar15;
    float fVar16;
    undefined auVar17 [16];
    int64_t arg2_00;
    undefined auVar18 [16];
    int64_t var_8h;
    int64_t var_20h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    auVar17._8_8_ = 0;
    auVar17._0_8_ = arg3;
    auVar18._8_8_ = 0;
    auVar18._0_8_ = arg2;
    var_80h = arg3;
    if ((arg4 != 0) && (iVar9 = arg1, arg4 != arg1)) goto code_r0x00018011b242;
    do {
        *(int64_t *)(arg1 + 0x48) = auVar18._0_8_;
        *(int64_t *)(arg1 + 0x50) = auVar17._0_8_;
        iVar9 = arg1;
code_r0x00018011b242:
        arg1_00 = *(int64_t *)(iVar9 + 0x20);
        if (arg1_00 == 0) {
            return;
        }
        arg1 = *(int64_t *)(iVar9 + 0x28);
        arg2_00 = auVar18._0_8_;
        var_88h = arg2_00;
        var_20h = auVar17._0_8_;
        var_8h = auVar17._0_8_;
        for (iVar5 = arg4; iVar8 = arg4, iVar5 != 0; iVar5 = *(int64_t *)(iVar5 + 0x18)) {
            if (iVar5 == arg1_00) {
                uVar12 = 1;
                goto code_r0x00018011b290;
            }
        }
        uVar12 = 0;
        for (; iVar8 != 0; iVar8 = *(int64_t *)(iVar8 + 0x18)) {
code_r0x00018011b290:
            if (iVar8 == arg1) {
                uVar11 = 1;
                goto code_r0x00018011b2a1;
            }
        }
        uVar11 = 0;
code_r0x00018011b2a1:
        uVar3 = *(uint8_t *)(arg1_00 + 0xdc);
        if (((uVar3 & 1) == 0) && (uVar12 == 0)) {
            bVar6 = false;
        } else {
            bVar6 = true;
        }
        uVar4 = *(uint8_t *)(arg1 + 0xdc);
        if (((uVar4 & 1) == 0) && (uVar11 == 0)) {
            bVar7 = false;
        } else {
            bVar7 = true;
        }
        if ((bVar6) && (bVar7)) {
            iVar9 = (int64_t)*(int32_t *)(iVar9 + 0x60);
            fVar1 = *(float *)(*(int64_t *)0x180781f28 + 0xebc);
            fVar13 = *(float *)(*(int64_t *)0x180781f28 + 0xdb8 + iVar9 * 4);
            fVar15 = *(float *)((int64_t)&var_80h + iVar9 * 4) - fVar1;
            fVar13 = fVar13 + fVar13;
            if (fVar15 <= 0.0) {
                fVar15 = 0.0;
            }
            fVar16 = fVar15;
            if (fVar13 <= fVar15) {
                fVar16 = fVar13;
            }
            if ((char)uVar3 < '\0') {
                pfVar10 = (float *)((int64_t)&var_20h + iVar9 * 4);
                if ((char)uVar4 < '\0') {
                    fVar14 = (float)(int32_t)((*pfVar10 / (*pfVar10 + *(float *)((int64_t)&var_8h + iVar9 * 4))) *
                                             fVar15);
                } else {
                    fVar13 = *(float *)(arg1_00 + 0x50 + iVar9 * 4);
                    fVar14 = fVar15 - 1.0;
                    if (fVar13 <= fVar15 - 1.0) {
                        fVar14 = fVar13;
                    }
                }
                fVar15 = fVar15 - fVar14;
                *(float *)(arg1_00 + 0x58 + iVar9 * 4) = fVar14;
                *(float *)(arg1 + 0x58 + iVar9 * 4) = fVar15;
code_r0x00018011b46a:
                *(float *)((int64_t)&var_8h + iVar9 * 4) = fVar15;
            } else {
                if (-1 < (char)uVar4) {
                    fVar13 = *(float *)(arg1_00 + 0x58 + iVar9 * 4);
                    fVar16 = (float)(int32_t)(fVar16 * 0.5);
                    if ((fVar13 == 0.0) || ((uVar4 & 0x20) == 0)) {
                        fVar2 = *(float *)(arg1 + 0x58 + iVar9 * 4);
                        if ((fVar2 != 0.0) && ((uVar3 & 0x20) != 0)) {
                            pfVar10 = (float *)((int64_t)&var_20h + iVar9 * 4);
                            fVar14 = fVar15 - fVar16;
                            if (fVar2 <= fVar15 - fVar16) {
                                fVar14 = fVar2;
                            }
                            *(float *)((int64_t)&var_8h + iVar9 * 4) = fVar14;
                            fVar14 = fVar15 - fVar14;
                            goto code_r0x00018011b473;
                        }
                        fVar13 = (float)(int32_t)((fVar13 / (fVar2 + fVar13)) * fVar15 + 0.5);
                        fVar14 = fVar16;
                        if (fVar16 <= fVar13) {
                            fVar14 = fVar13;
                        }
                    } else {
                        fVar14 = fVar15 - fVar16;
                        if (fVar13 <= fVar15 - fVar16) {
                            fVar14 = fVar13;
                        }
                    }
                    pfVar10 = (float *)((int64_t)&var_20h + iVar9 * 4);
                    fVar15 = fVar15 - fVar14;
                    goto code_r0x00018011b46a;
                }
                pfVar10 = (float *)((int64_t)&var_20h + iVar9 * 4);
                fVar13 = *(float *)(arg1 + 0x50 + iVar9 * 4);
                fVar16 = fVar15 - 1.0;
                if (fVar13 <= fVar15 - 1.0) {
                    fVar16 = fVar13;
                }
                fVar14 = fVar15 - fVar16;
                *(float *)(arg1 + 0x58 + iVar9 * 4) = fVar16;
                *(float *)((int64_t)&var_8h + iVar9 * 4) = fVar16;
                *(float *)(arg1_00 + 0x58 + iVar9 * 4) = fVar14;
            }
code_r0x00018011b473:
            *pfVar10 = fVar14;
            auVar17._8_8_ = 0;
            auVar17._0_8_ = var_8h;
            *(float *)((int64_t)&var_88h + iVar9 * 4) = fVar1 + fVar14 + *(float *)((int64_t)&var_88h + iVar9 * 4);
            auVar18._8_8_ = 0;
            auVar18._0_8_ = var_88h;
        }
        if (arg4 == 0) {
            *(uint8_t *)(arg1 + 0xdc) = *(uint8_t *)(arg1 + 0xdc) & 0x7f;
            *(uint8_t *)(arg1_00 + 0xdc) = *(uint8_t *)(arg1_00 + 0xdc) & 0x7f;
            uVar11 = *(uint8_t *)(arg1 + 0xdc) & 1;
            uVar12 = *(uint8_t *)(arg1_00 + 0xdc) & 1;
        }
        if (uVar12 != 0) {
            fcn.18011b1e0(arg1_00, arg2_00, var_20h, 0);
        }
        if (uVar11 == 0) {
            return;
        }
        arg4 = 0;
        var_80h = auVar17._0_8_;
    } while( true );
}

// ============================================================
// Function: FUN_18011b530
// Address: 0x18011b530
// Size: 153 bytes
// ============================================================
void fcn.18011b530(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    
    iVar2 = *(int64_t *)(arg1 + 0x20);
    while( true ) {
        var_8h = arg1;
        if (iVar2 == 0) {
            func_0x00018011ec70(arg4, &var_8h);
            return;
        }
        if (((*(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0xdc) & 1) != 0) &&
           (((*(int32_t *)(arg1 + 0x60) != (int32_t)arg2 || ((int32_t)arg3 == 0)) ||
            ((*(uint8_t *)(*(int64_t *)(arg1 + 0x28) + 0xdc) & 1) == 0)))) {
            fcn.18011b530(*(int64_t *)(arg1 + 0x20), arg2 & 0xffffffff, arg3 & 0xffffffff, arg4);
        }
        iVar1 = *(int64_t *)(arg1 + 0x28);
        if ((*(uint8_t *)(iVar1 + 0xdc) & 1) == 0) break;
        if (((*(int32_t *)(arg1 + 0x60) == (int32_t)arg2) && ((int32_t)arg3 != 1)) &&
           ((*(uint8_t *)(*(int64_t *)(arg1 + 0x20) + 0xdc) & 1) != 0)) {
            return;
        }
        iVar2 = *(int64_t *)(iVar1 + 0x20);
        arg1 = iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_18011b5d0
// Address: 0x18011b5d0
// Size: 2457 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_1a8h
// WARNING: Variable defined which should be unmapped: var_1a0h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_18ch
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_60h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable arg_e1h
// WARNING: [rz-ghidra] Detected overlap for variable var_73h
// WARNING: [rz-ghidra] Detected overlap for variable arg_e3h
// WARNING: [rz-ghidra] Detected overlap for variable var_71h
// WARNING: [rz-ghidra] Detected overlap for variable var_7bh
// WARNING: [rz-ghidra] Detected overlap for variable var_79h
// WARNING: [rz-ghidra] Detected overlap for variable var_34h
// WARNING: [rz-ghidra] Detected overlap for variable var_30h
// WARNING: [rz-ghidra] Detected overlap for variable var_2ch
// WARNING: [rz-ghidra] Detected overlap for variable var_44h
// WARNING: [rz-ghidra] Detected overlap for variable var_3ch

void fcn.18011b5d0(int64_t arg1, int64_t arg_d0h, int64_t arg_d8h, int64_t arg_e0h, int64_t arg_e8h)
{
    uint8_t *puVar1;
    uint32_t uVar2;
    int64_t iVar3;
    int64_t iVar4;
    undefined4 *puVar5;
    float fVar6;
    float fVar7;
    float fVar8;
    float fVar9;
    char cVar10;
    uint32_t uVar11;
    int32_t iVar12;
    undefined4 uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    uint32_t uVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int32_t iVar19;
    undefined4 *puVar20;
    float fVar21;
    float fVar22;
    float fVar23;
    float fVar24;
    float fVar25;
    float fVar26;
    float fVar27;
    undefined4 unaff_XMM15_Da;
    undefined4 unaff_XMM15_Db;
    undefined4 unaff_XMM15_Dc;
    undefined4 unaff_XMM15_Dd;
    char acStackX_8 [8];
    char acStackX_10 [8];
    undefined8 uStackX_18;
    float fStackX_20;
    int64_t var_1a8h;
    int64_t var_1a0h;
    int64_t var_198h;
    undefined8 var_190h;
    float var_188h;
    float var_184h;
    float var_180h;
    float var_17ch;
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    undefined4 uStack_150;
    int64_t var_14ch;
    float fStack_144;
    float fStack_13c;
    float fStack_138;
    float fStack_134;
    float fStack_130;
    float fStack_12c;
    float afStack_128 [2];
    undefined4 *puStack_120;
    int64_t iStack_118;
    float afStack_110 [4];
    float in_stack_ffffffffffffff00;
    float in_stack_ffffffffffffff04;
    float in_stack_ffffffffffffff08;
    float in_stack_ffffffffffffff0c;
    int64_t in_stack_ffffffffffffff10;
    undefined auVar28 [16];
    int64_t var_7ch;
    int64_t var_70h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    
    auVar28._4_4_ = unaff_XMM15_Db;
    auVar28._0_4_ = unaff_XMM15_Da;
    auVar28._8_4_ = unaff_XMM15_Dc;
    auVar28._12_4_ = unaff_XMM15_Dd;
    iVar18 = *(int64_t *)(arg1 + 0x20);
    iVar4 = *(int64_t *)0x180781f28;
    while( true ) {
        if (iVar18 == 0) {
            *(int64_t *)0x180781f28 = iVar4;
            return;
        }
        iVar18 = *(int64_t *)(arg1 + 0x20);
        iStack_118 = iVar18;
        puVar20 = *(undefined4 **)(arg1 + 0x28);
        puStack_120 = puVar20;
        *(int64_t *)0x180781f28 = iVar4;
        if ((*(uint8_t *)(iVar18 + 0xdc) & 1) != 0) {
            if ((*(uint8_t *)(puVar20 + 0x37) & 1) != 0) {
                uVar2 = *(uint32_t *)(arg1 + 0x60);
                uVar17 = (uint64_t)(int32_t)uVar2;
                var_198h._0_4_ = *(float *)(iVar18 + 0x48);
                var_198h._4_4_ = *(float *)(iVar18 + 0x4c);
                var_190h = *(undefined8 *)(puVar20 + 0x12);
                *(float *)((int64_t)&var_198h + uVar17 * 4) =
                     *(float *)(iVar18 + 0x50 + uVar17 * 4) + *(float *)((int64_t)&var_198h + uVar17 * 4);
                uVar14 = uVar17 ^ 1;
                *(float *)((int64_t)&var_190h + uVar14 * 4) =
                     (float)puVar20[uVar14 + 0x14] + *(float *)((int64_t)&var_190h + uVar14 * 4);
                uVar11 = puVar20[4] | *(uint32_t *)(iVar18 + 0x10);
                uVar16 = 0x20000;
                if (uVar2 == 0) {
                    uVar16 = 0x10000;
                }
                if (((uVar11 & 0x20) == 0) && ((uVar11 & uVar16) == 0)) {
                    func_0x000180107620(*(undefined4 *)arg1);
                    func_0x000180459e74(&var_178h, 0x10, 2, 0x18011ed10, 0x18007c9f0);
                    fVar22 = *(float *)(iVar4 + 0xdb8 + uVar17 * 4);
                    fVar24 = fVar22 + *(float *)(*(int64_t *)(arg1 + 0x20) + 0x48 + uVar17 * 4);
                    fVar25 = (*(float *)(*(int64_t *)(arg1 + 0x28) + 0x50 + uVar17 * 4) +
                             *(float *)(*(int64_t *)(arg1 + 0x28) + 0x48 + uVar17 * 4)) - fVar22;
                    iVar12 = func_0x0001800f5a90(0x1806450d8);
                    if (*(int32_t *)(iVar4 + 0x1654) == iVar12) {
                        iVar3 = *(int64_t *)(iVar18 + 0x20);
                        uStackX_18 = (undefined4 *)iVar18;
                        if (iVar3 == 0) {
                            func_0x00018011ec70(&var_178h);
                        } else {
                            if (((*(uint8_t *)(iVar3 + 0xdc) & 1) != 0) &&
                               ((*(uint32_t *)(iVar18 + 0x60) != uVar2 ||
                                ((*(uint8_t *)(*(int64_t *)(iVar18 + 0x28) + 0xdc) & 1) == 0)))) {
                                fcn.18011b530(iVar3, (uint64_t)uVar2, 1, (int64_t)&var_178h);
                            }
                            if ((*(uint8_t *)(*(int64_t *)(iVar18 + 0x28) + 0xdc) & 1) != 0) {
                                fcn.18011b530(*(int64_t *)(iVar18 + 0x28), (uint64_t)uVar2, 1, (int64_t)&var_178h);
                            }
                        }
                        iVar3 = *(int64_t *)(puVar20 + 8);
                        uStackX_18 = puVar20;
                        if (iVar3 == 0) {
                            func_0x00018011ec70(&var_168h);
                        } else {
                            if ((*(uint8_t *)(iVar3 + 0xdc) & 1) != 0) {
                                fcn.18011b530(iVar3, (uint64_t)uVar2, 0, (int64_t)&var_168h);
                            }
                            if (((*(uint8_t *)(*(int64_t *)(puVar20 + 10) + 0xdc) & 1) != 0) &&
                               ((puVar20[0x18] != uVar2 || ((*(uint8_t *)(*(int64_t *)(puVar20 + 8) + 0xdc) & 1) == 0)))
                               ) {
                                fcn.18011b530(*(int64_t *)(puVar20 + 10), (uint64_t)uVar2, 0, (int64_t)&var_168h);
                            }
                        }
                        if (0 < (int32_t)var_178h) {
                            iVar12 = 0;
                            do {
                                iVar3 = *(int64_t *)(var_170h + (int64_t)iVar12 * 8);
                                afStack_110[0] = *(float *)(iVar3 + 0x48);
                                afStack_110[1] = *(float *)(iVar3 + 0x4c);
                                afStack_110[2] = *(float *)(iVar3 + 0x48) + *(float *)(iVar3 + 0x50);
                                afStack_110[3] = *(float *)(iVar3 + 0x4c) + *(float *)(iVar3 + 0x54);
                                if (fVar24 <= fVar22 + afStack_110[uVar17]) {
                                    fVar24 = fVar22 + afStack_110[uVar17];
                                }
                                iVar12 = iVar12 + 1;
                            } while (iVar12 < (int32_t)var_178h);
                        }
                        if (0 < (int32_t)var_168h) {
                            iVar12 = 0;
                            do {
                                iVar3 = *(int64_t *)(var_160h + (int64_t)iVar12 * 8);
                                in_stack_ffffffffffffff04 = *(float *)(iVar3 + 0x4c);
                                in_stack_ffffffffffffff00 = *(float *)(iVar3 + 0x48);
                                in_stack_ffffffffffffff08 = in_stack_ffffffffffffff00 + *(float *)(iVar3 + 0x50);
                                in_stack_ffffffffffffff0c = in_stack_ffffffffffffff04 + *(float *)(iVar3 + 0x54);
                                if (*(float *)(&stack0xffffffffffffff08 + uVar17 * 4) - fVar22 <= fVar25) {
                                    fVar25 = *(float *)(&stack0xffffffffffffff08 + uVar17 * 4) - fVar22;
                                }
                                iVar12 = iVar12 + 1;
                            } while (iVar12 < (int32_t)var_168h);
                        }
                    }
                    iVar3 = *(int64_t *)0x180781f28;
                    fVar22 = *(float *)(iVar18 + 0x50 + uVar17 * 4);
                    fVar26 = (float)puVar20[uVar17 + 0x14];
                    fStackX_20 = *(float *)(iVar18 + 0x48 + uVar17 * 4);
                    fVar23 = (float)puVar20[uVar17 + 0x12];
                    var_158h._0_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef0);
                    var_158h._4_4_ = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef4);
                    uStack_150 = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xef8);
                    var_14ch._0_4_ =
                         *(float *)(*(int64_t *)0x180781f28 + 0xefc) * *(float *)(*(int64_t *)0x180781f28 + 0xd9c);
                    uVar11 = fcn.1800f5fa0(&var_158h);
                    fVar27 = *(float *)(iVar4 + 0x15d4);
                    uStackX_18 = (undefined4 *)CONCAT44(uStackX_18._4_4_, fVar27);
                    iVar12 = func_0x0001800f5a90(0x1806450d8, 0, 
                                                 *(undefined4 *)
                                                  (*(int64_t *)(*(int64_t *)(iVar3 + 0x15e0) + 0x150) + -4 +
                                                  (int64_t)*(int32_t *)(*(int64_t *)(iVar3 + 0x15e0) + 0x148) * 4));
                    iVar4 = *(int64_t *)(iVar3 + 0x15e0);
                    cVar10 = func_0x00018010b530(&var_198h, iVar12, 0, 2);
                    fVar7 = var_198h._4_4_;
                    fVar6 = (float)var_198h;
                    iVar15 = *(int64_t *)0x180781f28;
                    iVar18 = iStack_118;
                    puVar20 = puStack_120;
                    if (cVar10 != '\0') {
                        fVar8 = (float)var_190h;
                        fVar9 = var_190h._4_4_;
                        if (uVar2 == 1) {
                            fStack_144 = SUB84(uStackX_18, 0);
                            fVar27 = 0.0;
                            fStack_12c = fStack_144;
                        } else {
                            fStack_12c = 0.0;
                        }
                        fStack_138 = (float)var_198h - fVar27;
                        fStack_134 = var_198h._4_4_ - fStack_12c;
                        fStack_130 = fVar27 + (float)var_190h;
                        fStack_12c = fStack_12c + var_190h._4_4_;
                        var_1a8h = 0x100001800;
                        func_0x000180139d40(&fStack_138, iVar12, acStackX_10, acStackX_8, 0x100001800);
                        if (acStackX_10[0] != '\0') {
                            *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) | 1;
                        }
                        iVar18 = *(int64_t *)0x180781f28;
                        if ((acStackX_8[0] != '\0') ||
                           (((acStackX_10[0] != '\0' && (*(int32_t *)(iVar3 + 0x1640) == iVar12)) &&
                            (0.04 <= *(float *)(iVar3 + 0x1648))))) {
                            *(uint32_t *)(*(int64_t *)0x180781f28 + 0x2650) = (uVar2 != 1) + 3;
                        }
                        var_188h = fVar6;
                        var_184h = fVar7;
                        var_180h = fVar8;
                        var_17ch = fVar9;
                        if (acStackX_8[0] != '\0') {
                            fVar24 = fVar24 - fStackX_20;
                            fVar25 = (fVar23 + fVar26) - fVar25;
                            afStack_128[0] = (*(float *)(iVar3 + 0x118) - *(float *)(iVar3 + 0x166c)) - fStack_138;
                            afStack_128[1] = (*(float *)(iVar3 + 0x11c) - *(float *)(iVar3 + 0x1670)) - fStack_134;
                            fVar23 = 0.0;
                            if (0.0 <= fVar26 - fVar25) {
                                fVar23 = fVar26 - fVar25;
                            }
                            fVar27 = 0.0;
                            if (0.0 <= fVar22 - fVar24) {
                                fVar27 = fVar22 - fVar24;
                            }
                            fVar21 = (float)((uint32_t)fVar27 ^ 0x80000000);
                            if ((float)((uint32_t)fVar27 ^ 0x80000000) <= afStack_128[uVar17]) {
                                fVar21 = afStack_128[uVar17];
                            }
                            if (fVar21 <= fVar23) {
                                fVar23 = fVar21;
                            }
                            uStackX_18 = (undefined4 *)CONCAT44(uStackX_18._4_4_, fVar23);
                            if (fVar23 != 0.0) {
                                fVar22 = fVar23 + fVar22;
                                if (fVar22 <= fVar24) {
                                    fVar22 = fVar24;
                                }
                                fVar26 = fVar26 - fVar23;
                                if (fVar26 <= fVar25) {
                                    fVar26 = fVar25;
                                }
                                if (uVar2 == 0) {
                                    var_180h = fVar23;
                                    fVar23 = 0.0;
                                } else {
                                    var_180h = 0.0;
                                    fStack_13c = fVar23;
                                }
                                var_188h = var_180h + fVar6;
                                var_184h = fVar23 + fVar7;
                                var_180h = var_180h + fVar8;
                                var_17ch = fVar23 + fVar9;
                                func_0x0001800fa060(iVar12);
                            }
                        }
                        if ((uVar11 & 0xff000000) != 0) {
                            var_1a8h = 0x100000000;
                            func_0x000180126550(*(undefined8 *)(iVar4 + 800), &var_188h, &var_180h, uVar11, 0x100000000
                                                , 0);
                            iVar18 = *(int64_t *)0x180781f28;
                        }
                        if (acStackX_8[0] == '\0') {
                            if ((acStackX_10[0] == '\0') || (iVar15 = 0x300, *(float *)(iVar3 + 0x1648) < 0.04)) {
                                iVar15 = 0x2f0;
                            }
                        } else {
                            iVar15 = 0x310;
                        }
                        puVar20 = (undefined4 *)(iVar18 + 0xd90 + iVar15);
                        var_158h._0_4_ = *puVar20;
                        var_158h._4_4_ = puVar20[1];
                        uStack_150 = puVar20[2];
                        var_14ch._0_4_ = (float)puVar20[3] * *(float *)(iVar18 + 0xd9c);
                        uVar13 = fcn.1800f5fa0(&var_158h);
                        var_1a8h = var_1a8h & 0xffffffff00000000;
                        func_0x000180126550(*(undefined8 *)(iVar4 + 800), &var_188h, &var_180h, uVar13, var_1a8h, 0);
                        iVar18 = iStack_118;
                        puVar20 = puStack_120;
                        iVar15 = *(int64_t *)0x180781f28;
                        if (((acStackX_8[0] != '\0') && (0 < (int32_t)var_178h)) &&
                           (iVar12 = (int32_t)var_168h, 0 < iVar12)) {
                            *(float *)(iStack_118 + 0x58 + uVar17 * 4) = fVar22;
                            *(float *)(iStack_118 + 0x50 + uVar17 * 4) = fVar22;
                            puStack_120[uVar17 + 0x12] =
                                 (float)puStack_120[uVar17 + 0x12] - (fVar26 - (float)puStack_120[uVar17 + 0x14]);
                            puStack_120[uVar17 + 0x16] = fVar26;
                            puStack_120[uVar17 + 0x14] = fVar26;
                            iVar19 = 0;
                            if (0 < (int32_t)var_178h) {
                                do {
                                    iVar4 = *(int64_t *)(var_170h + (int64_t)iVar19 * 8);
                                    puVar5 = *(undefined4 **)(iVar4 + 0x18);
                                    while (puVar5 != (undefined4 *)arg1) {
                                        if (*(uint32_t *)(*(int64_t *)(iVar4 + 0x18) + 0x60) == uVar2) {
                                            puVar1 = (uint8_t *)(*(int64_t *)(*(int64_t *)(iVar4 + 0x18) + 0x20) + 0xdc)
                                            ;
                                            *puVar1 = *puVar1 | 0x80;
                                        }
                                        iVar4 = *(int64_t *)(iVar4 + 0x18);
                                        puVar5 = *(undefined4 **)(iVar4 + 0x18);
                                    }
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 < (int32_t)var_178h);
                            }
                            iVar19 = 0;
                            if (0 < iVar12) {
                                do {
                                    iVar4 = *(int64_t *)(var_160h + (int64_t)iVar19 * 8);
                                    puVar5 = *(undefined4 **)(iVar4 + 0x18);
                                    while (puVar5 != (undefined4 *)arg1) {
                                        if (*(uint32_t *)(*(int64_t *)(iVar4 + 0x18) + 0x60) == uVar2) {
                                            puVar1 = (uint8_t *)(*(int64_t *)(*(int64_t *)(iVar4 + 0x18) + 0x28) + 0xdc)
                                            ;
                                            *puVar1 = *puVar1 | 0x80;
                                        }
                                        iVar4 = *(int64_t *)(iVar4 + 0x18);
                                        puVar5 = *(undefined4 **)(iVar4 + 0x18);
                                    }
                                    iVar19 = iVar19 + 1;
                                } while (iVar19 < iVar12);
                            }
                            fcn.18011b1e0(iStack_118, *(int64_t *)(iStack_118 + 0x48), *(int64_t *)(iStack_118 + 0x50), 
                                          0);
                            fcn.18011b1e0((int64_t)puVar20, *(int64_t *)(puVar20 + 0x12), *(int64_t *)(puVar20 + 0x14), 
                                          0);
                            iVar15 = *(int64_t *)0x180781f28;
                            if (*(float *)(*(int64_t *)0x180781f28 + 0x292c) <= 0.0) {
                                *(undefined4 *)(*(int64_t *)0x180781f28 + 0x292c) =
                                     *(undefined4 *)(*(int64_t *)0x180781f28 + 0x4c);
                            }
                        }
                    }
                    iVar12 = *(int32_t *)(*(int64_t *)(iVar15 + 0x15e0) + 0x148);
                    if (iVar12 < 2) {
                        if (*(code **)(iVar15 + 0x2a40) != (code *)0x0) {
                            (**(code **)(iVar15 + 0x2a40))(iVar15, *(undefined8 *)(iVar15 + 0x2a48), 0x1806445f8);
                        }
                    } else {
                        *(int32_t *)(*(int64_t *)(iVar15 + 0x15e0) + 0x148) = iVar12 + -1;
                    }
                    func_0x000180459d94(&var_178h, 0x10, 2, 0x18007c9f0);
                } else {
                    var_158h._0_4_ = *(undefined4 *)(iVar4 + 0x1080);
                    var_158h._4_4_ = *(undefined4 *)(iVar4 + 0x1084);
                    uStack_150 = *(undefined4 *)(iVar4 + 0x1088);
                    var_14ch._0_4_ = *(float *)(iVar4 + 0x108c) * *(float *)(iVar4 + 0xd9c);
                    uVar13 = fcn.1800f5fa0(&var_158h);
                    var_1a8h = (int64_t)*(uint32_t *)(iVar4 + 0xde4);
                    func_0x000180126550(*(undefined8 *)(*(int64_t *)(iVar4 + 0x15e0) + 800), &var_198h, &var_190h, 
                                        uVar13, var_1a8h, 0);
                }
            }
            if ((*(uint8_t *)(iVar18 + 0xdc) & 1) != 0) {
                fcn.18011b5d0(iVar18, CONCAT44(in_stack_ffffffffffffff04, in_stack_ffffffffffffff00), 
                              CONCAT44(in_stack_ffffffffffffff0c, in_stack_ffffffffffffff08), in_stack_ffffffffffffff10
                              , auVar28._0_8_);
            }
        }
        if ((*(uint8_t *)(puVar20 + 0x37) & 1) == 0) break;
        iVar18 = *(int64_t *)(puVar20 + 8);
        arg1 = (int64_t)puVar20;
        iVar4 = *(int64_t *)0x180781f28;
    }
    return;
}

// ============================================================
// Function: FUN_18011bf70
// Address: 0x18011bf70
// Size: 57 bytes
// ============================================================
int64_t fcn.18011bf70(int64_t arg1)
{
    int64_t iVar1;
    
    while( true ) {
        if (*(int64_t *)(arg1 + 0x20) == 0) {
            return arg1;
        }
        iVar1 = fcn.18011bf70(*(int64_t *)(arg1 + 0x20));
        if (iVar1 != 0) break;
        arg1 = *(int64_t *)(arg1 + 0x28);
    }
    return iVar1;
}

// ============================================================
// Function: FUN_18011bfb0
// Address: 0x18011bfb0
// Size: 181 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

int64_t fcn.18011bfb0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    int64_t var_28h;
    int64_t var_18h;
    
    if ((*(uint8_t *)(arg1 + 0xdc) & 1) != 0) {
        if (*(float *)(arg1 + 0x48) - 0.0 <= (float)arg2) {
            var_28h._4_4_ = (float)((uint64_t)arg2 >> 0x20);
            if (((*(float *)(arg1 + 0x4c) - 0.0 <= var_28h._4_4_) &&
                ((float)arg2 < *(float *)(arg1 + 0x48) + *(float *)(arg1 + 0x50) + 0.0)) &&
               (var_28h._4_4_ < *(float *)(arg1 + 0x4c) + *(float *)(arg1 + 0x54) + 0.0)) {
                if (*(int64_t *)(arg1 + 0x20) == 0) {
                    return arg1;
                }
                iVar1 = fcn.18011bfb0(*(int64_t *)(arg1 + 0x20), arg2);
                if (iVar1 != 0) {
                    return iVar1;
                }
                iVar1 = fcn.18011bfb0(*(int64_t *)(arg1 + 0x28), arg2);
                if (iVar1 == 0) {
                    return arg1;
                }
                return iVar1;
            }
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18011c070
// Address: 0x18011c070
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18011c070(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    int64_t iVar2;
    int32_t iVar3;
    int32_t *piVar4;
    int64_t var_8h;
    
    iVar3 = (int32_t)arg2;
    if ((((uint32_t)arg3 == 0) || (((uint32_t)arg3 & (int32_t)*(char *)(arg1 + 0x134)) != 0)) &&
       (*(uint32_t *)(arg1 + 0x134) = *(uint32_t *)(arg1 + 0x134) & 0xfffffff1, *(int32_t *)(arg1 + 0x4d0) != iVar3)) {
        iVar2 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x28e8);
        if ((iVar2 != 0) && (*(int64_t *)(iVar2 + 0x20) != 0)) {
            iVar1 = *(int64_t *)(iVar2 + 0x18);
            while (iVar1 != 0) {
                iVar2 = *(int64_t *)(iVar2 + 0x18);
                iVar1 = *(int64_t *)(iVar2 + 0x18);
            }
            piVar4 = *(int32_t **)(iVar2 + 0xa8);
            if (piVar4 == (int32_t *)0x0) {
                piVar4 = (int32_t *)(iVar2 + 200);
            }
            iVar3 = *piVar4;
            if (*(int32_t *)(arg1 + 0x4d0) == iVar3) {
                return;
            }
        }
        if (*(int64_t *)(arg1 + 0x4c0) != 0) {
            func_0x000180116490(*(int64_t *)(arg1 + 0x4c0), arg1, 0);
        }
        *(int32_t *)(arg1 + 0x4d0) = iVar3;
    }
    return;
}

// ============================================================
// Function: FUN_18011c130
// Address: 0x18011c130
// Size: 61 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.18011c130(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    undefined auVar6 [16];
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    uint32_t uVar13;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_198h;
    float var_190h;
    int64_t var_18ch;
    float var_184h;
    int64_t var_180h;
    int64_t var_170h;
    undefined uStack_164;
    int64_t var_163h;
    int64_t var_158h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 0x80) != 0) {
        iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        uVar11 = (uint32_t)arg3 | 1;
        if (*(char *)(iVar9 + 0x10e) == '\0') {
            uVar11 = (uint32_t)arg3;
        }
        uVar13 = uVar11 & 1;
        if (uVar13 == 0) {
            *(undefined *)(iVar9 + 0x10b) = 1;
            iVar9 = *(int64_t *)(iVar3 + 0x15e0);
        }
        iVar8 = func_0x0001800f60f0(iVar3 + 0x28e8, arg1 & 0xffffffff);
        iVar12 = iVar3;
        if (iVar8 == 0) {
            iVar8 = func_0x000180115230(iVar3, arg1 & 0xffffffff);
            iVar12 = *(int64_t *)0x180781f28;
            *(undefined4 *)(iVar8 + 8) = 0x800;
            *(uint32_t *)(iVar8 + 0x10) = *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 4) | 0x800;
        }
        *(uint32_t *)(iVar8 + 4) = uVar11;
        _var_170h = SUB1613(ZEXT816(0), 0);
        var_163h._0_1_ = 1;
        var_163h._1_2_ = 0;
        auVar6 = _var_170h;
        _uStack_164 = (uint32_t)SUB142(_var_170h, 0xc);
        _var_180h = ZEXT816(0xffffffff00000000);
        *(undefined4 *)(iVar8 + 0x68) = 0;
        *(undefined4 *)(iVar8 + 0x6c) = 0xffffffff;
        *(undefined4 *)(iVar8 + 0x70) = 0;
        *(undefined4 *)(iVar8 + 0x74) = 0;
        *(undefined4 *)(iVar8 + 0x78) = 0;
        *(undefined4 *)(iVar8 + 0x7c) = 0;
        *(undefined4 *)(iVar8 + 0x80) = 0;
        *(uint32_t *)(iVar8 + 0x84) = _uStack_164;
        *(undefined8 *)(iVar8 + 0x88) = 0;
        _var_170h = auVar6;
        if ((*(int32_t *)(iVar8 + 0xc0) == *(int32_t *)(iVar3 + 4)) && (uVar13 == 0)) {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 8);
        } else {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 0xc);
            if (uVar13 == 0) {
                iVar2 = *(int64_t *)(iVar12 + 0x15e0);
                if ((*(int64_t *)(iVar2 + 0x208) != 0) || (iVar10 = 0x2d0, *(int64_t *)(iVar12 + 0x24d0) != 0)) {
                    iVar10 = 0x2a0;
                }
                var_198h._0_4_ = (float)(int32_t)*(float *)arg2;
                var_198h._4_4_ = (float)(int32_t)*(float *)(arg2 + 4);
                if (((float)var_198h <= 0.0) &&
                   (var_198h._0_4_ = (*(float *)(iVar2 + iVar10) - *(float *)(iVar2 + 0x158)) + (float)var_198h,
                   (float)var_198h <= 4.0)) {
                    var_198h._0_4_ = 4.0;
                }
                fVar4 = (float)var_198h;
                if ((var_198h._4_4_ <= 0.0) &&
                   (var_198h._4_4_ = (*(float *)(iVar2 + 4 + iVar10) - *(float *)(iVar2 + 0x15c)) + var_198h._4_4_,
                   var_198h._4_4_ <= 4.0)) {
                    var_198h._4_4_ = 4.0;
                }
                fVar5 = var_198h._4_4_;
                *(undefined8 *)(iVar8 + 0x48) = *(undefined8 *)(iVar9 + 0x158);
                *(float *)(iVar8 + 0x50) = (float)var_198h;
                *(float *)(iVar8 + 0x54) = var_198h._4_4_;
                *(float *)(iVar8 + 0x58) = (float)var_198h;
                *(float *)(iVar8 + 0x5c) = var_198h._4_4_;
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 1;
                uVar1 = *(undefined8 *)(iVar8 + 0x48);
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 2;
                *(undefined8 *)(iVar12 + 0x201c) = uVar1;
                *(undefined8 *)(iVar12 + 0x2024) = 0;
                *(undefined4 *)(iVar12 + 0x200c) = 1;
                *(undefined *)(iVar12 + 0x204c) = 1;
                *(undefined8 *)(iVar12 + 0x202c) = *(undefined8 *)(iVar8 + 0x50);
                *(undefined4 *)(iVar12 + 0x2010) = 1;
                *(undefined *)(iVar3 + 0x204c) = 0;
                var_1a8h._0_4_ = (int32_t)arg1;
                func_0x0001800f4620(&var_158h, 0x100, 0x1806450e8, *(undefined8 *)(iVar9 + 8));
                func_0x0001800f6810(8);
                func_0x0001801019f0(&var_158h, 0, 0x18001bb);
                fcn.1800f6a20(1);
                iVar12 = *(int64_t *)(iVar8 + 0x98);
                iVar2 = *(int64_t *)(iVar3 + 0x15e0);
                if (((iVar12 != 0) && (iVar12 != iVar2)) && (*(int64_t *)(iVar12 + 0x4c8) == iVar8)) {
                    *(undefined8 *)(iVar12 + 0x4c8) = 0;
                }
                *(int64_t *)(iVar2 + 0x4c8) = iVar8;
                *(int64_t *)(iVar8 + 0x98) = iVar2;
                uVar7 = func_0x0001800f5a90(&var_158h, 0, 
                                            *(undefined4 *)
                                             (*(int64_t *)(iVar9 + 0x150) + -4 +
                                             (int64_t)*(int32_t *)(iVar9 + 0x148) * 4));
                *(undefined4 *)(iVar2 + 0xcc) = uVar7;
                *(undefined8 *)(iVar8 + 0xb0) = 0;
                if ((*(int64_t *)(iVar8 + 0x20) == 0) && ((*(uint32_t *)(iVar8 + 0x10) & 0x800) == 0)) {
                    *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x800;
                    *(uint32_t *)(iVar8 + 0x10) =
                         *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 4) | *(uint32_t *)(iVar8 + 0xc);
                }
                fcn.180116d90(iVar8);
                func_0x000180105c20();
                var_18ch._0_4_ = *(float *)(iVar8 + 0x4c);
                var_190h = *(float *)(iVar8 + 0x48);
                var_184h = fVar5 + (float)var_18ch;
                var_18ch._4_4_ = fVar4 + var_190h;
                func_0x00018010bbf0(&var_198h, 0xbf800000);
                func_0x00018010b530(&var_190h, arg1 & 0xffffffff, 0, 2);
                if ((*(uint32_t *)(iVar3 + 0x1fc0) & 1) != 0) {
                    iVar12 = *(int64_t *)(iVar3 + 0x15e8);
                    iVar8 = iVar12;
                    iVar9 = iVar12;
                    if (iVar12 != 0) {
                        do {
                            iVar9 = *(int64_t *)(*(int64_t *)(iVar8 + 0x418) + 0x428);
                            bVar14 = iVar8 != iVar9;
                            iVar8 = iVar9;
                        } while (bVar14);
                    }
                    if (iVar9 == iVar2) {
code_r0x00018011c538:
                        *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) | 0x80;
                    } else {
                        for (; iVar12 != 0; iVar12 = *(int64_t *)(iVar12 + 0x408)) {
                            if (iVar12 == iVar2) goto code_r0x00018011c538;
                            if (iVar12 == iVar9) break;
                        }
                    }
                }
            } else {
                *(undefined4 *)(iVar8 + 0xbc) = *(undefined4 *)(iVar3 + 4);
            }
        }
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_18011c16d
// Address: 0x18011c16d
// Size: 278 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.18011c130(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    undefined auVar6 [16];
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    uint32_t uVar13;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_198h;
    float var_190h;
    int64_t var_18ch;
    float var_184h;
    int64_t var_180h;
    int64_t var_170h;
    undefined uStack_164;
    int64_t var_163h;
    int64_t var_158h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 0x80) != 0) {
        iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        uVar11 = (uint32_t)arg3 | 1;
        if (*(char *)(iVar9 + 0x10e) == '\0') {
            uVar11 = (uint32_t)arg3;
        }
        uVar13 = uVar11 & 1;
        if (uVar13 == 0) {
            *(undefined *)(iVar9 + 0x10b) = 1;
            iVar9 = *(int64_t *)(iVar3 + 0x15e0);
        }
        iVar8 = func_0x0001800f60f0(iVar3 + 0x28e8, arg1 & 0xffffffff);
        iVar12 = iVar3;
        if (iVar8 == 0) {
            iVar8 = func_0x000180115230(iVar3, arg1 & 0xffffffff);
            iVar12 = *(int64_t *)0x180781f28;
            *(undefined4 *)(iVar8 + 8) = 0x800;
            *(uint32_t *)(iVar8 + 0x10) = *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 4) | 0x800;
        }
        *(uint32_t *)(iVar8 + 4) = uVar11;
        _var_170h = SUB1613(ZEXT816(0), 0);
        var_163h._0_1_ = 1;
        var_163h._1_2_ = 0;
        auVar6 = _var_170h;
        _uStack_164 = (uint32_t)SUB142(_var_170h, 0xc);
        _var_180h = ZEXT816(0xffffffff00000000);
        *(undefined4 *)(iVar8 + 0x68) = 0;
        *(undefined4 *)(iVar8 + 0x6c) = 0xffffffff;
        *(undefined4 *)(iVar8 + 0x70) = 0;
        *(undefined4 *)(iVar8 + 0x74) = 0;
        *(undefined4 *)(iVar8 + 0x78) = 0;
        *(undefined4 *)(iVar8 + 0x7c) = 0;
        *(undefined4 *)(iVar8 + 0x80) = 0;
        *(uint32_t *)(iVar8 + 0x84) = _uStack_164;
        *(undefined8 *)(iVar8 + 0x88) = 0;
        _var_170h = auVar6;
        if ((*(int32_t *)(iVar8 + 0xc0) == *(int32_t *)(iVar3 + 4)) && (uVar13 == 0)) {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 8);
        } else {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 0xc);
            if (uVar13 == 0) {
                iVar2 = *(int64_t *)(iVar12 + 0x15e0);
                if ((*(int64_t *)(iVar2 + 0x208) != 0) || (iVar10 = 0x2d0, *(int64_t *)(iVar12 + 0x24d0) != 0)) {
                    iVar10 = 0x2a0;
                }
                var_198h._0_4_ = (float)(int32_t)*(float *)arg2;
                var_198h._4_4_ = (float)(int32_t)*(float *)(arg2 + 4);
                if (((float)var_198h <= 0.0) &&
                   (var_198h._0_4_ = (*(float *)(iVar2 + iVar10) - *(float *)(iVar2 + 0x158)) + (float)var_198h,
                   (float)var_198h <= 4.0)) {
                    var_198h._0_4_ = 4.0;
                }
                fVar4 = (float)var_198h;
                if ((var_198h._4_4_ <= 0.0) &&
                   (var_198h._4_4_ = (*(float *)(iVar2 + 4 + iVar10) - *(float *)(iVar2 + 0x15c)) + var_198h._4_4_,
                   var_198h._4_4_ <= 4.0)) {
                    var_198h._4_4_ = 4.0;
                }
                fVar5 = var_198h._4_4_;
                *(undefined8 *)(iVar8 + 0x48) = *(undefined8 *)(iVar9 + 0x158);
                *(float *)(iVar8 + 0x50) = (float)var_198h;
                *(float *)(iVar8 + 0x54) = var_198h._4_4_;
                *(float *)(iVar8 + 0x58) = (float)var_198h;
                *(float *)(iVar8 + 0x5c) = var_198h._4_4_;
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 1;
                uVar1 = *(undefined8 *)(iVar8 + 0x48);
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 2;
                *(undefined8 *)(iVar12 + 0x201c) = uVar1;
                *(undefined8 *)(iVar12 + 0x2024) = 0;
                *(undefined4 *)(iVar12 + 0x200c) = 1;
                *(undefined *)(iVar12 + 0x204c) = 1;
                *(undefined8 *)(iVar12 + 0x202c) = *(undefined8 *)(iVar8 + 0x50);
                *(undefined4 *)(iVar12 + 0x2010) = 1;
                *(undefined *)(iVar3 + 0x204c) = 0;
                var_1a8h._0_4_ = (int32_t)arg1;
                func_0x0001800f4620(&var_158h, 0x100, 0x1806450e8, *(undefined8 *)(iVar9 + 8));
                func_0x0001800f6810(8);
                func_0x0001801019f0(&var_158h, 0, 0x18001bb);
                fcn.1800f6a20(1);
                iVar12 = *(int64_t *)(iVar8 + 0x98);
                iVar2 = *(int64_t *)(iVar3 + 0x15e0);
                if (((iVar12 != 0) && (iVar12 != iVar2)) && (*(int64_t *)(iVar12 + 0x4c8) == iVar8)) {
                    *(undefined8 *)(iVar12 + 0x4c8) = 0;
                }
                *(int64_t *)(iVar2 + 0x4c8) = iVar8;
                *(int64_t *)(iVar8 + 0x98) = iVar2;
                uVar7 = func_0x0001800f5a90(&var_158h, 0, 
                                            *(undefined4 *)
                                             (*(int64_t *)(iVar9 + 0x150) + -4 +
                                             (int64_t)*(int32_t *)(iVar9 + 0x148) * 4));
                *(undefined4 *)(iVar2 + 0xcc) = uVar7;
                *(undefined8 *)(iVar8 + 0xb0) = 0;
                if ((*(int64_t *)(iVar8 + 0x20) == 0) && ((*(uint32_t *)(iVar8 + 0x10) & 0x800) == 0)) {
                    *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x800;
                    *(uint32_t *)(iVar8 + 0x10) =
                         *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 4) | *(uint32_t *)(iVar8 + 0xc);
                }
                fcn.180116d90(iVar8);
                func_0x000180105c20();
                var_18ch._0_4_ = *(float *)(iVar8 + 0x4c);
                var_190h = *(float *)(iVar8 + 0x48);
                var_184h = fVar5 + (float)var_18ch;
                var_18ch._4_4_ = fVar4 + var_190h;
                func_0x00018010bbf0(&var_198h, 0xbf800000);
                func_0x00018010b530(&var_190h, arg1 & 0xffffffff, 0, 2);
                if ((*(uint32_t *)(iVar3 + 0x1fc0) & 1) != 0) {
                    iVar12 = *(int64_t *)(iVar3 + 0x15e8);
                    iVar8 = iVar12;
                    iVar9 = iVar12;
                    if (iVar12 != 0) {
                        do {
                            iVar9 = *(int64_t *)(*(int64_t *)(iVar8 + 0x418) + 0x428);
                            bVar14 = iVar8 != iVar9;
                            iVar8 = iVar9;
                        } while (bVar14);
                    }
                    if (iVar9 == iVar2) {
code_r0x00018011c538:
                        *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) | 0x80;
                    } else {
                        for (; iVar12 != 0; iVar12 = *(int64_t *)(iVar12 + 0x408)) {
                            if (iVar12 == iVar2) goto code_r0x00018011c538;
                            if (iVar12 == iVar9) break;
                        }
                    }
                }
            } else {
                *(undefined4 *)(iVar8 + 0xbc) = *(undefined4 *)(iVar3 + 4);
            }
        }
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_18011c283
// Address: 0x18011c283
// Size: 615 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.18011c130(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    undefined auVar6 [16];
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    uint32_t uVar13;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_198h;
    float var_190h;
    int64_t var_18ch;
    float var_184h;
    int64_t var_180h;
    int64_t var_170h;
    undefined uStack_164;
    int64_t var_163h;
    int64_t var_158h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 0x80) != 0) {
        iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        uVar11 = (uint32_t)arg3 | 1;
        if (*(char *)(iVar9 + 0x10e) == '\0') {
            uVar11 = (uint32_t)arg3;
        }
        uVar13 = uVar11 & 1;
        if (uVar13 == 0) {
            *(undefined *)(iVar9 + 0x10b) = 1;
            iVar9 = *(int64_t *)(iVar3 + 0x15e0);
        }
        iVar8 = func_0x0001800f60f0(iVar3 + 0x28e8, arg1 & 0xffffffff);
        iVar12 = iVar3;
        if (iVar8 == 0) {
            iVar8 = func_0x000180115230(iVar3, arg1 & 0xffffffff);
            iVar12 = *(int64_t *)0x180781f28;
            *(undefined4 *)(iVar8 + 8) = 0x800;
            *(uint32_t *)(iVar8 + 0x10) = *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 4) | 0x800;
        }
        *(uint32_t *)(iVar8 + 4) = uVar11;
        _var_170h = SUB1613(ZEXT816(0), 0);
        var_163h._0_1_ = 1;
        var_163h._1_2_ = 0;
        auVar6 = _var_170h;
        _uStack_164 = (uint32_t)SUB142(_var_170h, 0xc);
        _var_180h = ZEXT816(0xffffffff00000000);
        *(undefined4 *)(iVar8 + 0x68) = 0;
        *(undefined4 *)(iVar8 + 0x6c) = 0xffffffff;
        *(undefined4 *)(iVar8 + 0x70) = 0;
        *(undefined4 *)(iVar8 + 0x74) = 0;
        *(undefined4 *)(iVar8 + 0x78) = 0;
        *(undefined4 *)(iVar8 + 0x7c) = 0;
        *(undefined4 *)(iVar8 + 0x80) = 0;
        *(uint32_t *)(iVar8 + 0x84) = _uStack_164;
        *(undefined8 *)(iVar8 + 0x88) = 0;
        _var_170h = auVar6;
        if ((*(int32_t *)(iVar8 + 0xc0) == *(int32_t *)(iVar3 + 4)) && (uVar13 == 0)) {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 8);
        } else {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 0xc);
            if (uVar13 == 0) {
                iVar2 = *(int64_t *)(iVar12 + 0x15e0);
                if ((*(int64_t *)(iVar2 + 0x208) != 0) || (iVar10 = 0x2d0, *(int64_t *)(iVar12 + 0x24d0) != 0)) {
                    iVar10 = 0x2a0;
                }
                var_198h._0_4_ = (float)(int32_t)*(float *)arg2;
                var_198h._4_4_ = (float)(int32_t)*(float *)(arg2 + 4);
                if (((float)var_198h <= 0.0) &&
                   (var_198h._0_4_ = (*(float *)(iVar2 + iVar10) - *(float *)(iVar2 + 0x158)) + (float)var_198h,
                   (float)var_198h <= 4.0)) {
                    var_198h._0_4_ = 4.0;
                }
                fVar4 = (float)var_198h;
                if ((var_198h._4_4_ <= 0.0) &&
                   (var_198h._4_4_ = (*(float *)(iVar2 + 4 + iVar10) - *(float *)(iVar2 + 0x15c)) + var_198h._4_4_,
                   var_198h._4_4_ <= 4.0)) {
                    var_198h._4_4_ = 4.0;
                }
                fVar5 = var_198h._4_4_;
                *(undefined8 *)(iVar8 + 0x48) = *(undefined8 *)(iVar9 + 0x158);
                *(float *)(iVar8 + 0x50) = (float)var_198h;
                *(float *)(iVar8 + 0x54) = var_198h._4_4_;
                *(float *)(iVar8 + 0x58) = (float)var_198h;
                *(float *)(iVar8 + 0x5c) = var_198h._4_4_;
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 1;
                uVar1 = *(undefined8 *)(iVar8 + 0x48);
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 2;
                *(undefined8 *)(iVar12 + 0x201c) = uVar1;
                *(undefined8 *)(iVar12 + 0x2024) = 0;
                *(undefined4 *)(iVar12 + 0x200c) = 1;
                *(undefined *)(iVar12 + 0x204c) = 1;
                *(undefined8 *)(iVar12 + 0x202c) = *(undefined8 *)(iVar8 + 0x50);
                *(undefined4 *)(iVar12 + 0x2010) = 1;
                *(undefined *)(iVar3 + 0x204c) = 0;
                var_1a8h._0_4_ = (int32_t)arg1;
                func_0x0001800f4620(&var_158h, 0x100, 0x1806450e8, *(undefined8 *)(iVar9 + 8));
                func_0x0001800f6810(8);
                func_0x0001801019f0(&var_158h, 0, 0x18001bb);
                fcn.1800f6a20(1);
                iVar12 = *(int64_t *)(iVar8 + 0x98);
                iVar2 = *(int64_t *)(iVar3 + 0x15e0);
                if (((iVar12 != 0) && (iVar12 != iVar2)) && (*(int64_t *)(iVar12 + 0x4c8) == iVar8)) {
                    *(undefined8 *)(iVar12 + 0x4c8) = 0;
                }
                *(int64_t *)(iVar2 + 0x4c8) = iVar8;
                *(int64_t *)(iVar8 + 0x98) = iVar2;
                uVar7 = func_0x0001800f5a90(&var_158h, 0, 
                                            *(undefined4 *)
                                             (*(int64_t *)(iVar9 + 0x150) + -4 +
                                             (int64_t)*(int32_t *)(iVar9 + 0x148) * 4));
                *(undefined4 *)(iVar2 + 0xcc) = uVar7;
                *(undefined8 *)(iVar8 + 0xb0) = 0;
                if ((*(int64_t *)(iVar8 + 0x20) == 0) && ((*(uint32_t *)(iVar8 + 0x10) & 0x800) == 0)) {
                    *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x800;
                    *(uint32_t *)(iVar8 + 0x10) =
                         *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 4) | *(uint32_t *)(iVar8 + 0xc);
                }
                fcn.180116d90(iVar8);
                func_0x000180105c20();
                var_18ch._0_4_ = *(float *)(iVar8 + 0x4c);
                var_190h = *(float *)(iVar8 + 0x48);
                var_184h = fVar5 + (float)var_18ch;
                var_18ch._4_4_ = fVar4 + var_190h;
                func_0x00018010bbf0(&var_198h, 0xbf800000);
                func_0x00018010b530(&var_190h, arg1 & 0xffffffff, 0, 2);
                if ((*(uint32_t *)(iVar3 + 0x1fc0) & 1) != 0) {
                    iVar12 = *(int64_t *)(iVar3 + 0x15e8);
                    iVar8 = iVar12;
                    iVar9 = iVar12;
                    if (iVar12 != 0) {
                        do {
                            iVar9 = *(int64_t *)(*(int64_t *)(iVar8 + 0x418) + 0x428);
                            bVar14 = iVar8 != iVar9;
                            iVar8 = iVar9;
                        } while (bVar14);
                    }
                    if (iVar9 == iVar2) {
code_r0x00018011c538:
                        *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) | 0x80;
                    } else {
                        for (; iVar12 != 0; iVar12 = *(int64_t *)(iVar12 + 0x408)) {
                            if (iVar12 == iVar2) goto code_r0x00018011c538;
                            if (iVar12 == iVar9) break;
                        }
                    }
                }
            } else {
                *(undefined4 *)(iVar8 + 0xbc) = *(undefined4 *)(iVar3 + 4);
            }
        }
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_18011c4ea
// Address: 0x18011c4ea
// Size: 124 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.18011c130(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    undefined auVar6 [16];
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    uint32_t uVar13;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_198h;
    float var_190h;
    int64_t var_18ch;
    float var_184h;
    int64_t var_180h;
    int64_t var_170h;
    undefined uStack_164;
    int64_t var_163h;
    int64_t var_158h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 0x80) != 0) {
        iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        uVar11 = (uint32_t)arg3 | 1;
        if (*(char *)(iVar9 + 0x10e) == '\0') {
            uVar11 = (uint32_t)arg3;
        }
        uVar13 = uVar11 & 1;
        if (uVar13 == 0) {
            *(undefined *)(iVar9 + 0x10b) = 1;
            iVar9 = *(int64_t *)(iVar3 + 0x15e0);
        }
        iVar8 = func_0x0001800f60f0(iVar3 + 0x28e8, arg1 & 0xffffffff);
        iVar12 = iVar3;
        if (iVar8 == 0) {
            iVar8 = func_0x000180115230(iVar3, arg1 & 0xffffffff);
            iVar12 = *(int64_t *)0x180781f28;
            *(undefined4 *)(iVar8 + 8) = 0x800;
            *(uint32_t *)(iVar8 + 0x10) = *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 4) | 0x800;
        }
        *(uint32_t *)(iVar8 + 4) = uVar11;
        _var_170h = SUB1613(ZEXT816(0), 0);
        var_163h._0_1_ = 1;
        var_163h._1_2_ = 0;
        auVar6 = _var_170h;
        _uStack_164 = (uint32_t)SUB142(_var_170h, 0xc);
        _var_180h = ZEXT816(0xffffffff00000000);
        *(undefined4 *)(iVar8 + 0x68) = 0;
        *(undefined4 *)(iVar8 + 0x6c) = 0xffffffff;
        *(undefined4 *)(iVar8 + 0x70) = 0;
        *(undefined4 *)(iVar8 + 0x74) = 0;
        *(undefined4 *)(iVar8 + 0x78) = 0;
        *(undefined4 *)(iVar8 + 0x7c) = 0;
        *(undefined4 *)(iVar8 + 0x80) = 0;
        *(uint32_t *)(iVar8 + 0x84) = _uStack_164;
        *(undefined8 *)(iVar8 + 0x88) = 0;
        _var_170h = auVar6;
        if ((*(int32_t *)(iVar8 + 0xc0) == *(int32_t *)(iVar3 + 4)) && (uVar13 == 0)) {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 8);
        } else {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 0xc);
            if (uVar13 == 0) {
                iVar2 = *(int64_t *)(iVar12 + 0x15e0);
                if ((*(int64_t *)(iVar2 + 0x208) != 0) || (iVar10 = 0x2d0, *(int64_t *)(iVar12 + 0x24d0) != 0)) {
                    iVar10 = 0x2a0;
                }
                var_198h._0_4_ = (float)(int32_t)*(float *)arg2;
                var_198h._4_4_ = (float)(int32_t)*(float *)(arg2 + 4);
                if (((float)var_198h <= 0.0) &&
                   (var_198h._0_4_ = (*(float *)(iVar2 + iVar10) - *(float *)(iVar2 + 0x158)) + (float)var_198h,
                   (float)var_198h <= 4.0)) {
                    var_198h._0_4_ = 4.0;
                }
                fVar4 = (float)var_198h;
                if ((var_198h._4_4_ <= 0.0) &&
                   (var_198h._4_4_ = (*(float *)(iVar2 + 4 + iVar10) - *(float *)(iVar2 + 0x15c)) + var_198h._4_4_,
                   var_198h._4_4_ <= 4.0)) {
                    var_198h._4_4_ = 4.0;
                }
                fVar5 = var_198h._4_4_;
                *(undefined8 *)(iVar8 + 0x48) = *(undefined8 *)(iVar9 + 0x158);
                *(float *)(iVar8 + 0x50) = (float)var_198h;
                *(float *)(iVar8 + 0x54) = var_198h._4_4_;
                *(float *)(iVar8 + 0x58) = (float)var_198h;
                *(float *)(iVar8 + 0x5c) = var_198h._4_4_;
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 1;
                uVar1 = *(undefined8 *)(iVar8 + 0x48);
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 2;
                *(undefined8 *)(iVar12 + 0x201c) = uVar1;
                *(undefined8 *)(iVar12 + 0x2024) = 0;
                *(undefined4 *)(iVar12 + 0x200c) = 1;
                *(undefined *)(iVar12 + 0x204c) = 1;
                *(undefined8 *)(iVar12 + 0x202c) = *(undefined8 *)(iVar8 + 0x50);
                *(undefined4 *)(iVar12 + 0x2010) = 1;
                *(undefined *)(iVar3 + 0x204c) = 0;
                var_1a8h._0_4_ = (int32_t)arg1;
                func_0x0001800f4620(&var_158h, 0x100, 0x1806450e8, *(undefined8 *)(iVar9 + 8));
                func_0x0001800f6810(8);
                func_0x0001801019f0(&var_158h, 0, 0x18001bb);
                fcn.1800f6a20(1);
                iVar12 = *(int64_t *)(iVar8 + 0x98);
                iVar2 = *(int64_t *)(iVar3 + 0x15e0);
                if (((iVar12 != 0) && (iVar12 != iVar2)) && (*(int64_t *)(iVar12 + 0x4c8) == iVar8)) {
                    *(undefined8 *)(iVar12 + 0x4c8) = 0;
                }
                *(int64_t *)(iVar2 + 0x4c8) = iVar8;
                *(int64_t *)(iVar8 + 0x98) = iVar2;
                uVar7 = func_0x0001800f5a90(&var_158h, 0, 
                                            *(undefined4 *)
                                             (*(int64_t *)(iVar9 + 0x150) + -4 +
                                             (int64_t)*(int32_t *)(iVar9 + 0x148) * 4));
                *(undefined4 *)(iVar2 + 0xcc) = uVar7;
                *(undefined8 *)(iVar8 + 0xb0) = 0;
                if ((*(int64_t *)(iVar8 + 0x20) == 0) && ((*(uint32_t *)(iVar8 + 0x10) & 0x800) == 0)) {
                    *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x800;
                    *(uint32_t *)(iVar8 + 0x10) =
                         *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 4) | *(uint32_t *)(iVar8 + 0xc);
                }
                fcn.180116d90(iVar8);
                func_0x000180105c20();
                var_18ch._0_4_ = *(float *)(iVar8 + 0x4c);
                var_190h = *(float *)(iVar8 + 0x48);
                var_184h = fVar5 + (float)var_18ch;
                var_18ch._4_4_ = fVar4 + var_190h;
                func_0x00018010bbf0(&var_198h, 0xbf800000);
                func_0x00018010b530(&var_190h, arg1 & 0xffffffff, 0, 2);
                if ((*(uint32_t *)(iVar3 + 0x1fc0) & 1) != 0) {
                    iVar12 = *(int64_t *)(iVar3 + 0x15e8);
                    iVar8 = iVar12;
                    iVar9 = iVar12;
                    if (iVar12 != 0) {
                        do {
                            iVar9 = *(int64_t *)(*(int64_t *)(iVar8 + 0x418) + 0x428);
                            bVar14 = iVar8 != iVar9;
                            iVar8 = iVar9;
                        } while (bVar14);
                    }
                    if (iVar9 == iVar2) {
code_r0x00018011c538:
                        *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) | 0x80;
                    } else {
                        for (; iVar12 != 0; iVar12 = *(int64_t *)(iVar12 + 0x408)) {
                            if (iVar12 == iVar2) goto code_r0x00018011c538;
                            if (iVar12 == iVar9) break;
                        }
                    }
                }
            } else {
                *(undefined4 *)(iVar8 + 0xbc) = *(undefined4 *)(iVar3 + 4);
            }
        }
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_18011c566
// Address: 0x18011c566
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_84h
// WARNING: [rz-ghidra] Detected overlap for variable var_80h
// WARNING: [rz-ghidra] Detected overlap for variable var_7ch
// WARNING: [rz-ghidra] Detected overlap for variable var_78h
// WARNING: [rz-ghidra] Detected overlap for variable var_74h
// WARNING: [rz-ghidra] Detected overlap for variable var_70h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_90h
// WARNING: [rz-ghidra] Detected overlap for variable var_98h

void fcn.18011c130(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    int64_t iVar2;
    int64_t iVar3;
    float fVar4;
    float fVar5;
    undefined auVar6 [16];
    undefined4 uVar7;
    int64_t iVar8;
    int64_t iVar9;
    int64_t iVar10;
    uint32_t uVar11;
    int64_t iVar12;
    uint32_t uVar13;
    bool bVar14;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStack_1c8 [32];
    int64_t var_1a8h;
    int64_t var_198h;
    float var_190h;
    int64_t var_18ch;
    float var_184h;
    int64_t var_180h;
    int64_t var_170h;
    undefined uStack_164;
    int64_t var_163h;
    int64_t var_158h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    
    iVar3 = *(int64_t *)0x180781f28;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1c8;
    if ((*(uint8_t *)(*(int64_t *)0x180781f28 + 0x30) & 0x80) != 0) {
        iVar9 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
        uVar11 = (uint32_t)arg3 | 1;
        if (*(char *)(iVar9 + 0x10e) == '\0') {
            uVar11 = (uint32_t)arg3;
        }
        uVar13 = uVar11 & 1;
        if (uVar13 == 0) {
            *(undefined *)(iVar9 + 0x10b) = 1;
            iVar9 = *(int64_t *)(iVar3 + 0x15e0);
        }
        iVar8 = func_0x0001800f60f0(iVar3 + 0x28e8, arg1 & 0xffffffff);
        iVar12 = iVar3;
        if (iVar8 == 0) {
            iVar8 = func_0x000180115230(iVar3, arg1 & 0xffffffff);
            iVar12 = *(int64_t *)0x180781f28;
            *(undefined4 *)(iVar8 + 8) = 0x800;
            *(uint32_t *)(iVar8 + 0x10) = *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 4) | 0x800;
        }
        *(uint32_t *)(iVar8 + 4) = uVar11;
        _var_170h = SUB1613(ZEXT816(0), 0);
        var_163h._0_1_ = 1;
        var_163h._1_2_ = 0;
        auVar6 = _var_170h;
        _uStack_164 = (uint32_t)SUB142(_var_170h, 0xc);
        _var_180h = ZEXT816(0xffffffff00000000);
        *(undefined4 *)(iVar8 + 0x68) = 0;
        *(undefined4 *)(iVar8 + 0x6c) = 0xffffffff;
        *(undefined4 *)(iVar8 + 0x70) = 0;
        *(undefined4 *)(iVar8 + 0x74) = 0;
        *(undefined4 *)(iVar8 + 0x78) = 0;
        *(undefined4 *)(iVar8 + 0x7c) = 0;
        *(undefined4 *)(iVar8 + 0x80) = 0;
        *(uint32_t *)(iVar8 + 0x84) = _uStack_164;
        *(undefined8 *)(iVar8 + 0x88) = 0;
        _var_170h = auVar6;
        if ((*(int32_t *)(iVar8 + 0xc0) == *(int32_t *)(iVar3 + 4)) && (uVar13 == 0)) {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 0xc) | *(uint32_t *)(iVar8 + 8);
        } else {
            *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x400;
            *(uint32_t *)(iVar8 + 0x10) = uVar11 | *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 0xc);
            if (uVar13 == 0) {
                iVar2 = *(int64_t *)(iVar12 + 0x15e0);
                if ((*(int64_t *)(iVar2 + 0x208) != 0) || (iVar10 = 0x2d0, *(int64_t *)(iVar12 + 0x24d0) != 0)) {
                    iVar10 = 0x2a0;
                }
                var_198h._0_4_ = (float)(int32_t)*(float *)arg2;
                var_198h._4_4_ = (float)(int32_t)*(float *)(arg2 + 4);
                if (((float)var_198h <= 0.0) &&
                   (var_198h._0_4_ = (*(float *)(iVar2 + iVar10) - *(float *)(iVar2 + 0x158)) + (float)var_198h,
                   (float)var_198h <= 4.0)) {
                    var_198h._0_4_ = 4.0;
                }
                fVar4 = (float)var_198h;
                if ((var_198h._4_4_ <= 0.0) &&
                   (var_198h._4_4_ = (*(float *)(iVar2 + 4 + iVar10) - *(float *)(iVar2 + 0x15c)) + var_198h._4_4_,
                   var_198h._4_4_ <= 4.0)) {
                    var_198h._4_4_ = 4.0;
                }
                fVar5 = var_198h._4_4_;
                *(undefined8 *)(iVar8 + 0x48) = *(undefined8 *)(iVar9 + 0x158);
                *(float *)(iVar8 + 0x50) = (float)var_198h;
                *(float *)(iVar8 + 0x54) = var_198h._4_4_;
                *(float *)(iVar8 + 0x58) = (float)var_198h;
                *(float *)(iVar8 + 0x5c) = var_198h._4_4_;
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 1;
                uVar1 = *(undefined8 *)(iVar8 + 0x48);
                *(uint32_t *)(iVar12 + 0x2008) = *(uint32_t *)(iVar12 + 0x2008) | 2;
                *(undefined8 *)(iVar12 + 0x201c) = uVar1;
                *(undefined8 *)(iVar12 + 0x2024) = 0;
                *(undefined4 *)(iVar12 + 0x200c) = 1;
                *(undefined *)(iVar12 + 0x204c) = 1;
                *(undefined8 *)(iVar12 + 0x202c) = *(undefined8 *)(iVar8 + 0x50);
                *(undefined4 *)(iVar12 + 0x2010) = 1;
                *(undefined *)(iVar3 + 0x204c) = 0;
                var_1a8h._0_4_ = (int32_t)arg1;
                func_0x0001800f4620(&var_158h, 0x100, 0x1806450e8, *(undefined8 *)(iVar9 + 8));
                func_0x0001800f6810(8);
                func_0x0001801019f0(&var_158h, 0, 0x18001bb);
                fcn.1800f6a20(1);
                iVar12 = *(int64_t *)(iVar8 + 0x98);
                iVar2 = *(int64_t *)(iVar3 + 0x15e0);
                if (((iVar12 != 0) && (iVar12 != iVar2)) && (*(int64_t *)(iVar12 + 0x4c8) == iVar8)) {
                    *(undefined8 *)(iVar12 + 0x4c8) = 0;
                }
                *(int64_t *)(iVar2 + 0x4c8) = iVar8;
                *(int64_t *)(iVar8 + 0x98) = iVar2;
                uVar7 = func_0x0001800f5a90(&var_158h, 0, 
                                            *(undefined4 *)
                                             (*(int64_t *)(iVar9 + 0x150) + -4 +
                                             (int64_t)*(int32_t *)(iVar9 + 0x148) * 4));
                *(undefined4 *)(iVar2 + 0xcc) = uVar7;
                *(undefined8 *)(iVar8 + 0xb0) = 0;
                if ((*(int64_t *)(iVar8 + 0x20) == 0) && ((*(uint32_t *)(iVar8 + 0x10) & 0x800) == 0)) {
                    *(uint32_t *)(iVar8 + 8) = *(uint32_t *)(iVar8 + 8) | 0x800;
                    *(uint32_t *)(iVar8 + 0x10) =
                         *(uint32_t *)(iVar8 + 8) | *(uint32_t *)(iVar8 + 4) | *(uint32_t *)(iVar8 + 0xc);
                }
                fcn.180116d90(iVar8);
                func_0x000180105c20();
                var_18ch._0_4_ = *(float *)(iVar8 + 0x4c);
                var_190h = *(float *)(iVar8 + 0x48);
                var_184h = fVar5 + (float)var_18ch;
                var_18ch._4_4_ = fVar4 + var_190h;
                func_0x00018010bbf0(&var_198h, 0xbf800000);
                func_0x00018010b530(&var_190h, arg1 & 0xffffffff, 0, 2);
                if ((*(uint32_t *)(iVar3 + 0x1fc0) & 1) != 0) {
                    iVar12 = *(int64_t *)(iVar3 + 0x15e8);
                    iVar8 = iVar12;
                    iVar9 = iVar12;
                    if (iVar12 != 0) {
                        do {
                            iVar9 = *(int64_t *)(*(int64_t *)(iVar8 + 0x418) + 0x428);
                            bVar14 = iVar8 != iVar9;
                            iVar8 = iVar9;
                        } while (bVar14);
                    }
                    if (iVar9 == iVar2) {
code_r0x00018011c538:
                        *(uint32_t *)(iVar3 + 0x1fc0) = *(uint32_t *)(iVar3 + 0x1fc0) | 0x80;
                    } else {
                        for (; iVar12 != 0; iVar12 = *(int64_t *)(iVar12 + 0x408)) {
                            if (iVar12 == iVar2) goto code_r0x00018011c538;
                            if (iVar12 == iVar9) break;
                        }
                    }
                }
            } else {
                *(undefined4 *)(iVar8 + 0xbc) = *(undefined4 *)(iVar3 + 4);
            }
        }
    }
    func_0x000180459870(var_58h ^ (uint64_t)auStack_1c8);
    return;
}

// ============================================================
// Function: FUN_18011c590
// Address: 0x18011c590
// Size: 229 bytes
// ============================================================
void fcn.18011c590(int64_t arg1)
{
    uint8_t uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    uint8_t *puVar4;
    int64_t iVar5;
    uint32_t uVar6;
    uint64_t uVar7;
    
    uVar3 = *(uint32_t *)0x180782158;
    uVar7 = 0xffffffff;
    uVar6 = 0xffffffff;
    uVar1 = *(uint8_t *)arg1;
    puVar4 = (uint8_t *)(arg1 + 1);
    while (uVar1 != 0) {
        if (((uVar1 == 0x23) && (*puVar4 == 0x23)) && (puVar4[1] == 0x23)) {
            uVar7 = 0xffffffff;
            puVar4 = puVar4 + 2;
        } else {
            uVar7 = (uint64_t)
                    ((uint32_t)(uVar7 >> 8) ^ *(uint32_t *)((uVar7 & 0xff ^ (uint64_t)uVar1) * 4 + 0x180618620));
        }
        uVar6 = (uint32_t)uVar7;
        uVar1 = *puVar4;
        puVar4 = puVar4 + 1;
    }
    iVar5 = func_0x0001800f60f0(*(int64_t *)0x180781f28 + 0x15c0, ~uVar6);
    if (iVar5 == 0) {
        iVar5 = func_0x000180112cf0(~uVar6);
        if (iVar5 == 0) {
            iVar5 = func_0x000180112c00(arg1);
        }
        if (*(uint32_t *)(iVar5 + 0x14) != uVar3) {
            *(undefined2 *)(iVar5 + 0x1c) = 0xffff;
        }
        *(uint32_t *)(iVar5 + 0x14) = uVar3;
    } else {
        iVar2 = *(int32_t *)(iVar5 + 0x4d0);
        fcn.18011c070(iVar5, (uint64_t)uVar3, 1);
        if (*(int32_t *)(iVar5 + 0x4d0) != iVar2) {
            *(undefined2 *)(iVar5 + 0x496) = 0xffff;
            return;
        }
    }
    return;
}

// ============================================================
// Function: FUN_18011c680
// Address: 0x18011c680
// Size: 88 bytes
// ============================================================
// WARNING: [rz-ghidra] Removing arg arg_2ch because it doesn't fit into ProtoModel

void fcn.18011c680(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined4 uVar2;
    int64_t var_18h;
    
    uVar2 = (undefined4)arg2;
    iVar1 = fcn.1800f60f0(*(int64_t *)0x180781f28 + 0x28e8, arg1 & 0xffffffff);
    if (iVar1 != 0) {
        var_18h._4_4_ = (undefined4)((uint64_t)arg2 >> 0x20);
        *(uint32_t *)(iVar1 + 0xd8) = *(uint32_t *)(iVar1 + 0xd8) & 0xffffffcf;
        *(uint32_t *)(iVar1 + 0xd8) = *(uint32_t *)(iVar1 + 0xd8) | 8;
        *(undefined4 *)(iVar1 + 0x5c) = var_18h._4_4_;
        *(undefined4 *)(iVar1 + 0x54) = var_18h._4_4_;
        *(undefined4 *)(iVar1 + 0x58) = uVar2;
        *(undefined4 *)(iVar1 + 0x50) = uVar2;
    }
    return;
}

// ============================================================
// Function: FUN_18011c6e0
// Address: 0x18011c6e0
// Size: 145 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: [rz-ghidra] Detected overlap for variable var_17ch
// WARNING: [rz-ghidra] Detected overlap for variable var_194h
// WARNING: [rz-ghidra] Detected overlap for variable var_190h
// WARNING: [rz-ghidra] Detected overlap for variable var_184h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h

undefined4 fcn.18011c6e0(int64_t arg1, int64_t arg2)
{
    int64_t iVar1;
    undefined4 *puVar2;
    uint32_t uVar3;
    uint64_t arg1_00;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)0x180781f28;
    arg1_00 = arg1 & 0xffffffff;
    if ((int32_t)arg1 != 0) {
        func_0x00018011c780();
    }
    uVar3 = (uint32_t)arg2;
    if ((uVar3 >> 10 & 1) == 0) {
        puVar2 = (undefined4 *)func_0x000180115230(iVar1, arg1_00);
        puVar2[2] = uVar3;
        puVar2[4] = puVar2[3] | puVar2[1] | uVar3;
    } else {
        var_18h = 0;
        fcn.18011c130(arg1_00, (int64_t)&var_18h, (uint64_t)(uVar3 & 0xfffffbff | 1));
        puVar2 = (undefined4 *)fcn.1800f60f0(iVar1 + 0x28e8, arg1_00);
    }
    puVar2[0x2f] = *(undefined4 *)(iVar1 + 4);
    return *puVar2;
}

