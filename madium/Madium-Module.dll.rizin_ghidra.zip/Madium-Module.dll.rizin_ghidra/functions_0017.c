// Chunk 17 - 50 functions

// ============================================================
// Function: FUN_18002f143
// Address: 0x18002f143
// Size: 16 bytes
// ============================================================
void fcn.18002f143(int64_t arg_38h, int64_t arg_40h)
{
    return;
}

// ============================================================
// Function: FUN_18002f160
// Address: 0x18002f160
// Size: 226 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

bool fcn.18002f160(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t iVar1;
    code *pcVar2;
    undefined uVar3;
    char *pcVar4;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    *(int32_t *)(arg1 + 0x6c) = (int32_t)arg3;
    iVar5 = 0x7fffffff;
    do {
        if (9 < (uint8_t)(*(char *)(arg1 + 0x75) - 0x30U)) break;
        iVar1 = *(char *)(arg1 + 0x75) + -0x30;
        if (iVar1 == -1) break;
        if ((0x7fffffff - iVar1) / 10 < *(int32_t *)(arg1 + 0x6c)) {
            func_0x00018002ed40(0x7fffffff - iVar1, arg2 & 0xffffffff);
            pcVar2 = (code *)swi(3);
            uVar3 = (*pcVar2)();
            return (bool)uVar3;
        }
        iVar5 = iVar5 + -1;
        *(int32_t *)(arg1 + 0x6c) = iVar1 + *(int32_t *)(arg1 + 0x6c) * 10;
        pcVar4 = *(char **)arg1;
        if (pcVar4 != *(char **)(arg1 + 8)) {
            if ((((*pcVar4 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                (pcVar4 = pcVar4 + 1, pcVar4 != *(char **)(arg1 + 8))) &&
               ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar4 - 0x28U) < 2)) ||
                (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar4 + 0x85U & 0xfd) == 0)))))) {
                *(char **)arg1 = pcVar4;
            }
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        func_0x00018002b970(arg1);
    } while (iVar5 != 0);
    return iVar5 != 0x7fffffff;
}

// ============================================================
// Function: FUN_18002f250
// Address: 0x18002f250
// Size: 71 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18002f250(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int16_t iVar4;
    char in_DL;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != *(int64_t *)(arg1 + 8)) {
        iVar4 = func_0x00018002c7f0(*(undefined8 *)(arg1 + 0x58), iVar3, iVar3 + 1, 
                                    *(uint32_t *)(arg1 + 0x68) >> 8 & 0xffffff01);
        if (iVar4 != 0) {
            cVar2 = *(char *)(arg1 + 0x75);
            if (cVar2 == 'W') {
                iVar5 = 0x100;
            } else if (cVar2 == 'S') {
                iVar5 = 0x200;
            } else {
                iVar5 = 0;
                if (cVar2 == 'D') {
                    iVar5 = 0x400;
                }
            }
            if (in_DL != '\0') {
                func_0x00018002f8b0(arg1 + 0x38);
                if (iVar5 != 0) {
                    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc);
                    *puVar1 = *puVar1 ^ 1;
                    iVar5 = 0;
                }
            }
            func_0x0001800306f0(arg1 + 0x38, iVar4, iVar5);
            func_0x00018002cd80(arg1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18002f297
// Address: 0x18002f297
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18002f250(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int16_t iVar4;
    char in_DL;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != *(int64_t *)(arg1 + 8)) {
        iVar4 = func_0x00018002c7f0(*(undefined8 *)(arg1 + 0x58), iVar3, iVar3 + 1, 
                                    *(uint32_t *)(arg1 + 0x68) >> 8 & 0xffffff01);
        if (iVar4 != 0) {
            cVar2 = *(char *)(arg1 + 0x75);
            if (cVar2 == 'W') {
                iVar5 = 0x100;
            } else if (cVar2 == 'S') {
                iVar5 = 0x200;
            } else {
                iVar5 = 0;
                if (cVar2 == 'D') {
                    iVar5 = 0x400;
                }
            }
            if (in_DL != '\0') {
                func_0x00018002f8b0(arg1 + 0x38);
                if (iVar5 != 0) {
                    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc);
                    *puVar1 = *puVar1 ^ 1;
                    iVar5 = 0;
                }
            }
            func_0x0001800306f0(arg1 + 0x38, iVar4, iVar5);
            func_0x00018002cd80(arg1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18002f30b
// Address: 0x18002f30b
// Size: 18 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 fcn.18002f250(int64_t arg1)
{
    uint32_t *puVar1;
    char cVar2;
    int64_t iVar3;
    int16_t iVar4;
    char in_DL;
    int32_t iVar5;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    iVar3 = *(int64_t *)arg1;
    if (iVar3 != *(int64_t *)(arg1 + 8)) {
        iVar4 = func_0x00018002c7f0(*(undefined8 *)(arg1 + 0x58), iVar3, iVar3 + 1, 
                                    *(uint32_t *)(arg1 + 0x68) >> 8 & 0xffffff01);
        if (iVar4 != 0) {
            cVar2 = *(char *)(arg1 + 0x75);
            if (cVar2 == 'W') {
                iVar5 = 0x100;
            } else if (cVar2 == 'S') {
                iVar5 = 0x200;
            } else {
                iVar5 = 0;
                if (cVar2 == 'D') {
                    iVar5 = 0x400;
                }
            }
            if (in_DL != '\0') {
                func_0x00018002f8b0(arg1 + 0x38);
                if (iVar5 != 0) {
                    puVar1 = (uint32_t *)(*(int64_t *)(arg1 + 0x40) + 0xc);
                    *puVar1 = *puVar1 ^ 1;
                    iVar5 = 0;
                }
            }
            func_0x0001800306f0(arg1 + 0x38, iVar4, iVar5);
            func_0x00018002cd80(arg1);
            return 1;
        }
    }
    return 0;
}

// ============================================================
// Function: FUN_18002f320
// Address: 0x18002f320
// Size: 30 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18002f320(int64_t arg1)
{
    char cVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint8_t in_DL;
    uint32_t uVar6;
    char *pcVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x70) == -1) {
        func_0x00018002ed40(arg1, 2);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0xf & 1) != 0) {
        cVar1 = *(char *)(arg1 + 0x75);
        if (cVar1 == 'f') {
            *(undefined4 *)(arg1 + 0x6c) = 0xc;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'n') {
            *(undefined4 *)(arg1 + 0x6c) = 10;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'r') {
            *(undefined4 *)(arg1 + 0x6c) = 0xd;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 't') {
            *(undefined4 *)(arg1 + 0x6c) = 9;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'v') {
            *(undefined4 *)(arg1 + 0x6c) = 0xb;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    if ((uVar2 >> 0xe & 1) != 0) {
        if (*(char *)(arg1 + 0x75) == 'a') {
            *(undefined4 *)(arg1 + 0x6c) = 7;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (*(char *)(arg1 + 0x75) == 'b') {
            *(undefined4 *)(arg1 + 0x6c) = 8;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    uVar8 = *(uint8_t *)(arg1 + 0x75);
    uVar6 = (uint32_t)uVar8;
    if (uVar8 == 99) {
        if ((uVar2 >> 0x11 & 1) != 0) {
            pcVar7 = *(char **)arg1;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
            uVar8 = *(uint8_t *)(arg1 + 0x75);
            if ((0x19 < (uint8_t)(uVar8 + 0x9f)) && (0x19 < (uint8_t)(uVar8 + 0xbf))) {
                func_0x00018002ed40(uVar8, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            *(uint32_t *)(arg1 + 0x6c) = uVar8 & 0x1f;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    } else if (uVar8 == 0x78) {
        if ((uVar2 >> 0xb & 1) != 0) {
            func_0x00018002cd80(arg1);
            uVar4 = 2;
code_r0x00018002f4ad:
            func_0x00018002ff40(arg1, uVar4);
            goto code_r0x00018002f4b5;
        }
    } else if ((uVar8 == 0x75) && ((uVar2 >> 10 & 1) != 0)) {
        func_0x00018002cd80(arg1);
        uVar4 = 4;
        goto code_r0x00018002f4ad;
    }
    if ((uVar2 >> 0xc & 1) != 0) {
        iVar9 = 3;
        *(undefined4 *)(arg1 + 0x6c) = 0;
        do {
            uVar6 = (uint32_t)*(char *)(arg1 + 0x75);
            if ((7 < (uint8_t)(*(char *)(arg1 + 0x75) - 0x30U)) || (iVar5 = uVar6 - 0x30, iVar5 == -1)) {
                if (iVar9 == 3) goto code_r0x00018002f5a8;
                break;
            }
            if ((int32_t)((0x7fffffff - iVar5) + (0x7fffffff - iVar5 >> 0x1f & 7U)) >> 3 < *(int32_t *)(arg1 + 0x6c)) {
                func_0x00018002ed40(iVar5, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            iVar9 = iVar9 + -1;
            pcVar7 = *(char **)arg1;
            *(int32_t *)(arg1 + 0x6c) = iVar5 + *(int32_t *)(arg1 + 0x6c) * 8;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
        } while (iVar9 != 0);
        if (*(int32_t *)(arg1 + 0x6c) == 0) {
            func_0x00018002ed40();
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
code_r0x00018002f4b5:
        *(uint8_t *)(arg1 + 0x76) = *(uint8_t *)(arg1 + 0x6c);
        if ((uint32_t)*(uint8_t *)(arg1 + 0x6c) == *(uint32_t *)(arg1 + 0x6c)) {
            return 1;
        }
        func_0x00018002ed40();
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
code_r0x00018002f5a8:
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0x15 & 1) != 0) {
    // switch table (52 cases) at 0x18002f6c8
        switch(uVar6 & 0xff) {
        case 0x44:
        case 0x53:
        case 0x57:
        case 99:
        case 100:
        case 0x73:
        case 0x77:
            goto code_r0x00018002f618;
        }
        goto code_r0x00018002f63d;
    }
    // switch table (92 cases) at 0x18002f704
    switch((uVar6 & 0xff) - 0x22) {
    case 0:
    case 0xd:
        uVar8 = (uint8_t)(uVar2 >> 0x17) & 1;
        break;
    default:
        goto code_r0x00018002f618;
    case 2:
    case 8:
    case 0xc:
    case 0x39:
    case 0x3b:
    case 0x3c:
        uVar8 = in_DL ^ 1;
        break;
    case 6:
    case 7:
    case 9:
    case 0x1d:
    case 0x59:
    case 0x5a:
    case 0x5b:
        if ((uVar2 >> 0x16 & 1) == 0) {
            return 0;
        }
        if (in_DL != 0) {
            return 0;
        }
    case 0x3a:
        goto code_r0x00018002f63d;
    }
    if (uVar8 == 0) {
code_r0x00018002f618:
        return 0;
    }
code_r0x00018002f63d:
    pcVar7 = *(char **)arg1;
    *(char *)(arg1 + 0x76) = (char)uVar6;
    if (pcVar7 != *(char **)(arg1 + 8)) {
        if (((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
           ((pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8) &&
            ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
             (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))))) {
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
    }
    func_0x00018002b970(arg1);
    return 1;
}

// ============================================================
// Function: FUN_18002f33e
// Address: 0x18002f33e
// Size: 751 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18002f320(int64_t arg1)
{
    char cVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint8_t in_DL;
    uint32_t uVar6;
    char *pcVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x70) == -1) {
        func_0x00018002ed40(arg1, 2);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0xf & 1) != 0) {
        cVar1 = *(char *)(arg1 + 0x75);
        if (cVar1 == 'f') {
            *(undefined4 *)(arg1 + 0x6c) = 0xc;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'n') {
            *(undefined4 *)(arg1 + 0x6c) = 10;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'r') {
            *(undefined4 *)(arg1 + 0x6c) = 0xd;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 't') {
            *(undefined4 *)(arg1 + 0x6c) = 9;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'v') {
            *(undefined4 *)(arg1 + 0x6c) = 0xb;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    if ((uVar2 >> 0xe & 1) != 0) {
        if (*(char *)(arg1 + 0x75) == 'a') {
            *(undefined4 *)(arg1 + 0x6c) = 7;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (*(char *)(arg1 + 0x75) == 'b') {
            *(undefined4 *)(arg1 + 0x6c) = 8;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    uVar8 = *(uint8_t *)(arg1 + 0x75);
    uVar6 = (uint32_t)uVar8;
    if (uVar8 == 99) {
        if ((uVar2 >> 0x11 & 1) != 0) {
            pcVar7 = *(char **)arg1;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
            uVar8 = *(uint8_t *)(arg1 + 0x75);
            if ((0x19 < (uint8_t)(uVar8 + 0x9f)) && (0x19 < (uint8_t)(uVar8 + 0xbf))) {
                func_0x00018002ed40(uVar8, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            *(uint32_t *)(arg1 + 0x6c) = uVar8 & 0x1f;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    } else if (uVar8 == 0x78) {
        if ((uVar2 >> 0xb & 1) != 0) {
            func_0x00018002cd80(arg1);
            uVar4 = 2;
code_r0x00018002f4ad:
            func_0x00018002ff40(arg1, uVar4);
            goto code_r0x00018002f4b5;
        }
    } else if ((uVar8 == 0x75) && ((uVar2 >> 10 & 1) != 0)) {
        func_0x00018002cd80(arg1);
        uVar4 = 4;
        goto code_r0x00018002f4ad;
    }
    if ((uVar2 >> 0xc & 1) != 0) {
        iVar9 = 3;
        *(undefined4 *)(arg1 + 0x6c) = 0;
        do {
            uVar6 = (uint32_t)*(char *)(arg1 + 0x75);
            if ((7 < (uint8_t)(*(char *)(arg1 + 0x75) - 0x30U)) || (iVar5 = uVar6 - 0x30, iVar5 == -1)) {
                if (iVar9 == 3) goto code_r0x00018002f5a8;
                break;
            }
            if ((int32_t)((0x7fffffff - iVar5) + (0x7fffffff - iVar5 >> 0x1f & 7U)) >> 3 < *(int32_t *)(arg1 + 0x6c)) {
                func_0x00018002ed40(iVar5, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            iVar9 = iVar9 + -1;
            pcVar7 = *(char **)arg1;
            *(int32_t *)(arg1 + 0x6c) = iVar5 + *(int32_t *)(arg1 + 0x6c) * 8;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
        } while (iVar9 != 0);
        if (*(int32_t *)(arg1 + 0x6c) == 0) {
            func_0x00018002ed40();
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
code_r0x00018002f4b5:
        *(uint8_t *)(arg1 + 0x76) = *(uint8_t *)(arg1 + 0x6c);
        if ((uint32_t)*(uint8_t *)(arg1 + 0x6c) == *(uint32_t *)(arg1 + 0x6c)) {
            return 1;
        }
        func_0x00018002ed40();
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
code_r0x00018002f5a8:
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0x15 & 1) != 0) {
    // switch table (52 cases) at 0x18002f6c8
        switch(uVar6 & 0xff) {
        case 0x44:
        case 0x53:
        case 0x57:
        case 99:
        case 100:
        case 0x73:
        case 0x77:
            goto code_r0x00018002f618;
        }
        goto code_r0x00018002f63d;
    }
    // switch table (92 cases) at 0x18002f704
    switch((uVar6 & 0xff) - 0x22) {
    case 0:
    case 0xd:
        uVar8 = (uint8_t)(uVar2 >> 0x17) & 1;
        break;
    default:
        goto code_r0x00018002f618;
    case 2:
    case 8:
    case 0xc:
    case 0x39:
    case 0x3b:
    case 0x3c:
        uVar8 = in_DL ^ 1;
        break;
    case 6:
    case 7:
    case 9:
    case 0x1d:
    case 0x59:
    case 0x5a:
    case 0x5b:
        if ((uVar2 >> 0x16 & 1) == 0) {
            return 0;
        }
        if (in_DL != 0) {
            return 0;
        }
    case 0x3a:
        goto code_r0x00018002f63d;
    }
    if (uVar8 == 0) {
code_r0x00018002f618:
        return 0;
    }
code_r0x00018002f63d:
    pcVar7 = *(char **)arg1;
    *(char *)(arg1 + 0x76) = (char)uVar6;
    if (pcVar7 != *(char **)(arg1 + 8)) {
        if (((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
           ((pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8) &&
            ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
             (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))))) {
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
    }
    func_0x00018002b970(arg1);
    return 1;
}

// ============================================================
// Function: FUN_18002f62d
// Address: 0x18002f62d
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18002f320(int64_t arg1)
{
    char cVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint8_t in_DL;
    uint32_t uVar6;
    char *pcVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x70) == -1) {
        func_0x00018002ed40(arg1, 2);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0xf & 1) != 0) {
        cVar1 = *(char *)(arg1 + 0x75);
        if (cVar1 == 'f') {
            *(undefined4 *)(arg1 + 0x6c) = 0xc;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'n') {
            *(undefined4 *)(arg1 + 0x6c) = 10;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'r') {
            *(undefined4 *)(arg1 + 0x6c) = 0xd;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 't') {
            *(undefined4 *)(arg1 + 0x6c) = 9;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'v') {
            *(undefined4 *)(arg1 + 0x6c) = 0xb;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    if ((uVar2 >> 0xe & 1) != 0) {
        if (*(char *)(arg1 + 0x75) == 'a') {
            *(undefined4 *)(arg1 + 0x6c) = 7;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (*(char *)(arg1 + 0x75) == 'b') {
            *(undefined4 *)(arg1 + 0x6c) = 8;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    uVar8 = *(uint8_t *)(arg1 + 0x75);
    uVar6 = (uint32_t)uVar8;
    if (uVar8 == 99) {
        if ((uVar2 >> 0x11 & 1) != 0) {
            pcVar7 = *(char **)arg1;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
            uVar8 = *(uint8_t *)(arg1 + 0x75);
            if ((0x19 < (uint8_t)(uVar8 + 0x9f)) && (0x19 < (uint8_t)(uVar8 + 0xbf))) {
                func_0x00018002ed40(uVar8, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            *(uint32_t *)(arg1 + 0x6c) = uVar8 & 0x1f;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    } else if (uVar8 == 0x78) {
        if ((uVar2 >> 0xb & 1) != 0) {
            func_0x00018002cd80(arg1);
            uVar4 = 2;
code_r0x00018002f4ad:
            func_0x00018002ff40(arg1, uVar4);
            goto code_r0x00018002f4b5;
        }
    } else if ((uVar8 == 0x75) && ((uVar2 >> 10 & 1) != 0)) {
        func_0x00018002cd80(arg1);
        uVar4 = 4;
        goto code_r0x00018002f4ad;
    }
    if ((uVar2 >> 0xc & 1) != 0) {
        iVar9 = 3;
        *(undefined4 *)(arg1 + 0x6c) = 0;
        do {
            uVar6 = (uint32_t)*(char *)(arg1 + 0x75);
            if ((7 < (uint8_t)(*(char *)(arg1 + 0x75) - 0x30U)) || (iVar5 = uVar6 - 0x30, iVar5 == -1)) {
                if (iVar9 == 3) goto code_r0x00018002f5a8;
                break;
            }
            if ((int32_t)((0x7fffffff - iVar5) + (0x7fffffff - iVar5 >> 0x1f & 7U)) >> 3 < *(int32_t *)(arg1 + 0x6c)) {
                func_0x00018002ed40(iVar5, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            iVar9 = iVar9 + -1;
            pcVar7 = *(char **)arg1;
            *(int32_t *)(arg1 + 0x6c) = iVar5 + *(int32_t *)(arg1 + 0x6c) * 8;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
        } while (iVar9 != 0);
        if (*(int32_t *)(arg1 + 0x6c) == 0) {
            func_0x00018002ed40();
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
code_r0x00018002f4b5:
        *(uint8_t *)(arg1 + 0x76) = *(uint8_t *)(arg1 + 0x6c);
        if ((uint32_t)*(uint8_t *)(arg1 + 0x6c) == *(uint32_t *)(arg1 + 0x6c)) {
            return 1;
        }
        func_0x00018002ed40();
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
code_r0x00018002f5a8:
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0x15 & 1) != 0) {
    // switch table (52 cases) at 0x18002f6c8
        switch(uVar6 & 0xff) {
        case 0x44:
        case 0x53:
        case 0x57:
        case 99:
        case 100:
        case 0x73:
        case 0x77:
            goto code_r0x00018002f618;
        }
        goto code_r0x00018002f63d;
    }
    // switch table (92 cases) at 0x18002f704
    switch((uVar6 & 0xff) - 0x22) {
    case 0:
    case 0xd:
        uVar8 = (uint8_t)(uVar2 >> 0x17) & 1;
        break;
    default:
        goto code_r0x00018002f618;
    case 2:
    case 8:
    case 0xc:
    case 0x39:
    case 0x3b:
    case 0x3c:
        uVar8 = in_DL ^ 1;
        break;
    case 6:
    case 7:
    case 9:
    case 0x1d:
    case 0x59:
    case 0x5a:
    case 0x5b:
        if ((uVar2 >> 0x16 & 1) == 0) {
            return 0;
        }
        if (in_DL != 0) {
            return 0;
        }
    case 0x3a:
        goto code_r0x00018002f63d;
    }
    if (uVar8 == 0) {
code_r0x00018002f618:
        return 0;
    }
code_r0x00018002f63d:
    pcVar7 = *(char **)arg1;
    *(char *)(arg1 + 0x76) = (char)uVar6;
    if (pcVar7 != *(char **)(arg1 + 8)) {
        if (((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
           ((pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8) &&
            ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
             (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))))) {
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
    }
    func_0x00018002b970(arg1);
    return 1;
}

// ============================================================
// Function: FUN_18002f6b0
// Address: 0x18002f6b0
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18002f320(int64_t arg1)
{
    char cVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint8_t in_DL;
    uint32_t uVar6;
    char *pcVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x70) == -1) {
        func_0x00018002ed40(arg1, 2);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0xf & 1) != 0) {
        cVar1 = *(char *)(arg1 + 0x75);
        if (cVar1 == 'f') {
            *(undefined4 *)(arg1 + 0x6c) = 0xc;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'n') {
            *(undefined4 *)(arg1 + 0x6c) = 10;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'r') {
            *(undefined4 *)(arg1 + 0x6c) = 0xd;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 't') {
            *(undefined4 *)(arg1 + 0x6c) = 9;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'v') {
            *(undefined4 *)(arg1 + 0x6c) = 0xb;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    if ((uVar2 >> 0xe & 1) != 0) {
        if (*(char *)(arg1 + 0x75) == 'a') {
            *(undefined4 *)(arg1 + 0x6c) = 7;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (*(char *)(arg1 + 0x75) == 'b') {
            *(undefined4 *)(arg1 + 0x6c) = 8;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    uVar8 = *(uint8_t *)(arg1 + 0x75);
    uVar6 = (uint32_t)uVar8;
    if (uVar8 == 99) {
        if ((uVar2 >> 0x11 & 1) != 0) {
            pcVar7 = *(char **)arg1;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
            uVar8 = *(uint8_t *)(arg1 + 0x75);
            if ((0x19 < (uint8_t)(uVar8 + 0x9f)) && (0x19 < (uint8_t)(uVar8 + 0xbf))) {
                func_0x00018002ed40(uVar8, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            *(uint32_t *)(arg1 + 0x6c) = uVar8 & 0x1f;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    } else if (uVar8 == 0x78) {
        if ((uVar2 >> 0xb & 1) != 0) {
            func_0x00018002cd80(arg1);
            uVar4 = 2;
code_r0x00018002f4ad:
            func_0x00018002ff40(arg1, uVar4);
            goto code_r0x00018002f4b5;
        }
    } else if ((uVar8 == 0x75) && ((uVar2 >> 10 & 1) != 0)) {
        func_0x00018002cd80(arg1);
        uVar4 = 4;
        goto code_r0x00018002f4ad;
    }
    if ((uVar2 >> 0xc & 1) != 0) {
        iVar9 = 3;
        *(undefined4 *)(arg1 + 0x6c) = 0;
        do {
            uVar6 = (uint32_t)*(char *)(arg1 + 0x75);
            if ((7 < (uint8_t)(*(char *)(arg1 + 0x75) - 0x30U)) || (iVar5 = uVar6 - 0x30, iVar5 == -1)) {
                if (iVar9 == 3) goto code_r0x00018002f5a8;
                break;
            }
            if ((int32_t)((0x7fffffff - iVar5) + (0x7fffffff - iVar5 >> 0x1f & 7U)) >> 3 < *(int32_t *)(arg1 + 0x6c)) {
                func_0x00018002ed40(iVar5, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            iVar9 = iVar9 + -1;
            pcVar7 = *(char **)arg1;
            *(int32_t *)(arg1 + 0x6c) = iVar5 + *(int32_t *)(arg1 + 0x6c) * 8;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
        } while (iVar9 != 0);
        if (*(int32_t *)(arg1 + 0x6c) == 0) {
            func_0x00018002ed40();
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
code_r0x00018002f4b5:
        *(uint8_t *)(arg1 + 0x76) = *(uint8_t *)(arg1 + 0x6c);
        if ((uint32_t)*(uint8_t *)(arg1 + 0x6c) == *(uint32_t *)(arg1 + 0x6c)) {
            return 1;
        }
        func_0x00018002ed40();
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
code_r0x00018002f5a8:
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0x15 & 1) != 0) {
    // switch table (52 cases) at 0x18002f6c8
        switch(uVar6 & 0xff) {
        case 0x44:
        case 0x53:
        case 0x57:
        case 99:
        case 100:
        case 0x73:
        case 0x77:
            goto code_r0x00018002f618;
        }
        goto code_r0x00018002f63d;
    }
    // switch table (92 cases) at 0x18002f704
    switch((uVar6 & 0xff) - 0x22) {
    case 0:
    case 0xd:
        uVar8 = (uint8_t)(uVar2 >> 0x17) & 1;
        break;
    default:
        goto code_r0x00018002f618;
    case 2:
    case 8:
    case 0xc:
    case 0x39:
    case 0x3b:
    case 0x3c:
        uVar8 = in_DL ^ 1;
        break;
    case 6:
    case 7:
    case 9:
    case 0x1d:
    case 0x59:
    case 0x5a:
    case 0x5b:
        if ((uVar2 >> 0x16 & 1) == 0) {
            return 0;
        }
        if (in_DL != 0) {
            return 0;
        }
    case 0x3a:
        goto code_r0x00018002f63d;
    }
    if (uVar8 == 0) {
code_r0x00018002f618:
        return 0;
    }
code_r0x00018002f63d:
    pcVar7 = *(char **)arg1;
    *(char *)(arg1 + 0x76) = (char)uVar6;
    if (pcVar7 != *(char **)(arg1 + 8)) {
        if (((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
           ((pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8) &&
            ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
             (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))))) {
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
    }
    func_0x00018002b970(arg1);
    return 1;
}

// ============================================================
// Function: FUN_18002f6bb
// Address: 0x18002f6bb
// Size: 185 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 fcn.18002f320(int64_t arg1)
{
    char cVar1;
    uint64_t uVar2;
    code *pcVar3;
    undefined8 uVar4;
    int32_t iVar5;
    uint8_t in_DL;
    uint32_t uVar6;
    char *pcVar7;
    uint8_t uVar8;
    int32_t iVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int32_t *)(arg1 + 0x70) == -1) {
        func_0x00018002ed40(arg1, 2);
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0xf & 1) != 0) {
        cVar1 = *(char *)(arg1 + 0x75);
        if (cVar1 == 'f') {
            *(undefined4 *)(arg1 + 0x6c) = 0xc;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'n') {
            *(undefined4 *)(arg1 + 0x6c) = 10;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'r') {
            *(undefined4 *)(arg1 + 0x6c) = 0xd;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 't') {
            *(undefined4 *)(arg1 + 0x6c) = 9;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (cVar1 == 'v') {
            *(undefined4 *)(arg1 + 0x6c) = 0xb;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    if ((uVar2 >> 0xe & 1) != 0) {
        if (*(char *)(arg1 + 0x75) == 'a') {
            *(undefined4 *)(arg1 + 0x6c) = 7;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
        if (*(char *)(arg1 + 0x75) == 'b') {
            *(undefined4 *)(arg1 + 0x6c) = 8;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    }
    uVar8 = *(uint8_t *)(arg1 + 0x75);
    uVar6 = (uint32_t)uVar8;
    if (uVar8 == 99) {
        if ((uVar2 >> 0x11 & 1) != 0) {
            pcVar7 = *(char **)arg1;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
            uVar8 = *(uint8_t *)(arg1 + 0x75);
            if ((0x19 < (uint8_t)(uVar8 + 0x9f)) && (0x19 < (uint8_t)(uVar8 + 0xbf))) {
                func_0x00018002ed40(uVar8, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            *(uint32_t *)(arg1 + 0x6c) = uVar8 & 0x1f;
            func_0x00018002cd80(arg1);
            goto code_r0x00018002f4b5;
        }
    } else if (uVar8 == 0x78) {
        if ((uVar2 >> 0xb & 1) != 0) {
            func_0x00018002cd80(arg1);
            uVar4 = 2;
code_r0x00018002f4ad:
            func_0x00018002ff40(arg1, uVar4);
            goto code_r0x00018002f4b5;
        }
    } else if ((uVar8 == 0x75) && ((uVar2 >> 10 & 1) != 0)) {
        func_0x00018002cd80(arg1);
        uVar4 = 4;
        goto code_r0x00018002f4ad;
    }
    if ((uVar2 >> 0xc & 1) != 0) {
        iVar9 = 3;
        *(undefined4 *)(arg1 + 0x6c) = 0;
        do {
            uVar6 = (uint32_t)*(char *)(arg1 + 0x75);
            if ((7 < (uint8_t)(*(char *)(arg1 + 0x75) - 0x30U)) || (iVar5 = uVar6 - 0x30, iVar5 == -1)) {
                if (iVar9 == 3) goto code_r0x00018002f5a8;
                break;
            }
            if ((int32_t)((0x7fffffff - iVar5) + (0x7fffffff - iVar5 >> 0x1f & 7U)) >> 3 < *(int32_t *)(arg1 + 0x6c)) {
                func_0x00018002ed40(iVar5, 2);
                pcVar3 = (code *)swi(3);
                uVar4 = (*pcVar3)();
                return uVar4;
            }
            iVar9 = iVar9 + -1;
            pcVar7 = *(char **)arg1;
            *(int32_t *)(arg1 + 0x6c) = iVar5 + *(int32_t *)(arg1 + 0x6c) * 8;
            if (pcVar7 != *(char **)(arg1 + 8)) {
                if ((((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                    (pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8))) &&
                   ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
                    (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))) {
                    *(char **)arg1 = pcVar7;
                }
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            func_0x00018002b970(arg1);
        } while (iVar9 != 0);
        if (*(int32_t *)(arg1 + 0x6c) == 0) {
            func_0x00018002ed40();
            pcVar3 = (code *)swi(3);
            uVar4 = (*pcVar3)();
            return uVar4;
        }
code_r0x00018002f4b5:
        *(uint8_t *)(arg1 + 0x76) = *(uint8_t *)(arg1 + 0x6c);
        if ((uint32_t)*(uint8_t *)(arg1 + 0x6c) == *(uint32_t *)(arg1 + 0x6c)) {
            return 1;
        }
        func_0x00018002ed40();
        pcVar3 = (code *)swi(3);
        uVar4 = (*pcVar3)();
        return uVar4;
    }
code_r0x00018002f5a8:
    uVar2 = *(uint64_t *)(arg1 + 0x60);
    if ((uVar2 >> 0x15 & 1) != 0) {
    // switch table (52 cases) at 0x18002f6c8
        switch(uVar6 & 0xff) {
        case 0x44:
        case 0x53:
        case 0x57:
        case 99:
        case 100:
        case 0x73:
        case 0x77:
            goto code_r0x00018002f618;
        }
        goto code_r0x00018002f63d;
    }
    // switch table (92 cases) at 0x18002f704
    switch((uVar6 & 0xff) - 0x22) {
    case 0:
    case 0xd:
        uVar8 = (uint8_t)(uVar2 >> 0x17) & 1;
        break;
    default:
        goto code_r0x00018002f618;
    case 2:
    case 8:
    case 0xc:
    case 0x39:
    case 0x3b:
    case 0x3c:
        uVar8 = in_DL ^ 1;
        break;
    case 6:
    case 7:
    case 9:
    case 0x1d:
    case 0x59:
    case 0x5a:
    case 0x5b:
        if ((uVar2 >> 0x16 & 1) == 0) {
            return 0;
        }
        if (in_DL != 0) {
            return 0;
        }
    case 0x3a:
        goto code_r0x00018002f63d;
    }
    if (uVar8 == 0) {
code_r0x00018002f618:
        return 0;
    }
code_r0x00018002f63d:
    pcVar7 = *(char **)arg1;
    *(char *)(arg1 + 0x76) = (char)uVar6;
    if (pcVar7 != *(char **)(arg1 + 8)) {
        if (((*pcVar7 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
           ((pcVar7 = pcVar7 + 1, pcVar7 != *(char **)(arg1 + 8) &&
            ((((uVar2 & 8) == 0 && ((uint8_t)(*pcVar7 - 0x28U) < 2)) ||
             (((uVar2 & 0x10) == 0 && ((*pcVar7 + 0x85U & 0xfd) == 0)))))))) {
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
    }
    func_0x00018002b970(arg1);
    return 1;
}

// ============================================================
// Function: FUN_18002f780
// Address: 0x18002f780
// Size: 106 bytes
// ============================================================
// WARNING: Possible PIC construction at 0x00018002f7bf: Changing call to branch
// WARNING: Removing unreachable block (ram,0x00018002f7c4)
// WARNING: Removing unreachable block (ram,0x00018002bf70)
// WARNING: Removing unreachable block (ram,0x00018002bf94)
// WARNING: Removing unreachable block (ram,0x00018002bfa4)
// WARNING: Removing unreachable block (ram,0x00018002bf8d)
// WARNING: Removing unreachable block (ram,0x00018002bfa7)
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

undefined8 * fcn.18002f780(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    puVar2 = (undefined8 *)func_0x000180459890(0x20);
    *puVar2 = 0x1806220a0;
    puVar2[2] = 0;
    puVar2[3] = 0;
    puVar2[1] = 8;
    puVar2[3] = *(undefined8 *)(arg1 + 0x40);
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + 0x10);
    if (iVar1 != 0) {
        puVar2[2] = iVar1;
        *(undefined8 **)(*(int64_t *)(*(int64_t *)(arg1 + 0x40) + 0x10) + 0x18) = puVar2;
    }
    *(undefined8 **)(*(int64_t *)(arg1 + 0x40) + 0x10) = puVar2;
    *(undefined8 **)(arg1 + 0x40) = puVar2;
    return puVar2;
}

// ============================================================
// Function: FUN_18002f7f0
// Address: 0x18002f7f0
// Size: 183 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18002f7f0(int64_t arg1)
{
    undefined8 *puVar1;
    undefined8 *puVar2;
    uint32_t in_EDX;
    int64_t unaff_RBX;
    int64_t var_8h;
    int64_t var_18h;
    int64_t var_20h;
    
    puVar1 = (undefined8 *)fcn.180459890(0x28);
    *(uint32_t *)(puVar1 + 1) = (in_EDX & 0xff) + 10;
    *(undefined4 *)((int64_t)puVar1 + 0xc) = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    *puVar1 = 0x180621f08;
    puVar1[4] = 0;
    puVar2 = (undefined8 *)fcn.180459890(0x20);
    *puVar2 = 0x1806220a0;
    puVar2[1] = 1;
    puVar2[2] = 0;
    puVar2[3] = 0;
    fcn.18002e210(arg1 + 0x38, puVar1);
    puVar1[4] = puVar2;
    puVar2[3] = puVar1;
    *(undefined8 **)(arg1 + 0x40) = puVar2;
    fcn.18002bb90(unaff_RBX);
    fcn.18002bf70(arg1 + 0x38, puVar1);
    *(undefined8 **)(arg1 + 0x40) = puVar1;
    return;
}

// ============================================================
// Function: FUN_18002f8b0
// Address: 0x18002f8b0
// Size: 87 bytes
// ============================================================
undefined8 * fcn.18002f8b0(int64_t arg1)
{
    int64_t iVar1;
    undefined8 *puVar2;
    
    puVar2 = (undefined8 *)fcn.180459890(0x50);
    puVar2[2] = 0;
    puVar2[3] = 0;
    *puVar2 = 0x1806220b0;
    puVar2[4] = 0;
    puVar2[5] = 0;
    puVar2[6] = 0;
    puVar2[7] = 0;
    *(undefined2 *)(puVar2 + 8) = 0;
    puVar2[9] = 0;
    puVar2[1] = 7;
    puVar2[3] = *(undefined8 *)(arg1 + 8);
    iVar1 = *(int64_t *)(*(int64_t *)(arg1 + 8) + 0x10);
    if (iVar1 != 0) {
        puVar2[2] = iVar1;
        *(undefined8 **)(*(int64_t *)(*(int64_t *)(arg1 + 8) + 0x10) + 0x18) = puVar2;
    }
    *(undefined8 **)(*(int64_t *)(arg1 + 8) + 0x10) = puVar2;
    *(undefined8 **)(arg1 + 8) = puVar2;
    return puVar2;
}

// ============================================================
// Function: FUN_18002f910
// Address: 0x18002f910
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002f910(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    int64_t iVar3;
    undefined in_DL;
    uint32_t uVar4;
    uint32_t uVar5;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint32_t *)arg1;
    if (*(uint32_t *)(arg1 + 4) < uVar1) {
code_r0x00018002f96e:
        *(undefined *)((uint64_t)*(uint32_t *)(arg1 + 4) + *(int64_t *)(arg1 + 8)) = in_DL;
        *(int32_t *)(arg1 + 4) = *(int32_t *)(arg1 + 4) + 1;
        return;
    }
    uVar5 = 0x10;
    if (0x10 < uVar1 >> 1) {
        uVar5 = uVar1 >> 1;
    }
    uVar4 = uVar1 + uVar5;
    if (~uVar5 <= uVar1) {
        uVar4 = 0xffffffff;
    }
    if (uVar4 != uVar1) {
        iVar3 = func_0x00018046d060(*(undefined8 *)(arg1 + 8), uVar4);
        if (iVar3 != 0) {
            *(int64_t *)(arg1 + 8) = iVar3;
            *(uint32_t *)arg1 = uVar4;
            goto code_r0x00018002f96e;
        }
    }
    func_0x00018045471c(9);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18002f9a0
// Address: 0x18002f9a0
// Size: 17 bytes
// ============================================================
void fcn.18002f9a0(void)
{
    code *pcVar1;
    
    fcn.1804546d4(0x180621ee0);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_18002f9c0
// Address: 0x18002f9c0
// Size: 992 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_38h

int64_t fcn.18002f9c0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    uint32_t *puVar1;
    uint32_t *puVar2;
    uint64_t uVar3;
    uint64_t uVar4;
    undefined4 uVar5;
    undefined4 uVar6;
    undefined4 uVar7;
    uint32_t uVar8;
    uint8_t uVar9;
    uint8_t uVar10;
    uint32_t uVar11;
    uint32_t *puVar12;
    uint8_t *puVar13;
    uint64_t uVar14;
    uint64_t uVar15;
    int8_t iVar16;
    uint32_t uVar17;
    uint32_t uVar18;
    uint64_t uVar19;
    uint32_t *puVar20;
    uint32_t uVar21;
    uint8_t *puVar22;
    uint32_t uVar23;
    char cVar24;
    char cVar25;
    int64_t iVar26;
    uint8_t *puVar27;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    
    puVar1 = *(uint32_t **)arg3;
    puVar2 = *(uint32_t **)arg2;
    if ((puVar2 == puVar1) && (*(int64_t *)(arg2 + 8) == *(int64_t *)(arg3 + 8))) {
        uVar5 = *(undefined4 *)(arg4 + 4);
        uVar6 = *(undefined4 *)(arg4 + 8);
        uVar7 = *(undefined4 *)(arg4 + 0xc);
        *(undefined4 *)arg1 = *(undefined4 *)arg4;
        *(undefined4 *)(arg1 + 4) = uVar5;
        *(undefined4 *)(arg1 + 8) = uVar6;
        *(undefined4 *)(arg1 + 0xc) = uVar7;
        return arg1;
    }
    uVar15 = *(uint64_t *)(arg2 + 8);
    uVar5 = *(undefined4 *)(arg4 + 4);
    uVar6 = *(undefined4 *)(arg4 + 8);
    uVar7 = *(undefined4 *)(arg4 + 0xc);
    uVar3 = *(uint64_t *)(arg3 + 8);
    puVar12 = *(uint32_t **)arg4;
    *(undefined4 *)arg1 = *(undefined4 *)arg4;
    *(undefined4 *)(arg1 + 4) = uVar5;
    *(undefined4 *)(arg1 + 8) = uVar6;
    *(undefined4 *)(arg1 + 0xc) = uVar7;
    fcn.18002ede0();
    uVar4 = *(uint64_t *)(arg4 + 8);
    uVar9 = (uint8_t)uVar15;
    uVar8 = -1 << (uVar9 & 0x1f);
    cVar24 = (char)uVar4;
    if (uVar4 == 0) {
        uVar23 = 0;
    } else {
        uVar23 = 0xffffffff >> (-cVar24 & 0x1fU);
    }
    cVar25 = (char)uVar3;
    if (uVar3 == 0) {
        uVar17 = 0;
    } else {
        uVar17 = 0xffffffff >> (-cVar25 & 0x1fU);
    }
    iVar26 = 0;
    uVar21 = -1 << ((uint8_t)*(int64_t *)(arg1 + 8) & 0x1f);
    if (*(int64_t *)(arg1 + 8) == 0) {
        iVar26 = -4;
    }
    if (puVar2 == puVar1) {
        uVar10 = cVar24 - uVar9;
        if (uVar4 < uVar15) {
            uVar10 = uVar9 - cVar24;
        }
        uVar18 = uVar8 & uVar17 & *puVar2;
        uVar11 = uVar18 >> (uVar10 & 0x1f);
        if (uVar15 <= uVar4) {
            uVar11 = uVar18 << (uVar10 & 0x1f);
        }
        if (puVar12 == (uint32_t *)(*(int64_t *)arg1 + iVar26)) {
            if (*(int64_t *)(arg1 + 8) == 0) {
                uVar21 = 0;
            }
            *puVar12 = (uVar21 | uVar23) & *puVar12 | uVar11;
            return arg1;
        }
        *puVar12 = *puVar12 & uVar23 | uVar11;
        puVar12[1] = (uVar8 & uVar17 & *puVar2) >> (cVar25 - *(char *)(arg1 + 8) & 0x1fU) | uVar21 & puVar12[1];
        return arg1;
    }
    if (puVar12 == (uint32_t *)(*(int64_t *)arg1 + iVar26)) {
        uVar10 = cVar24 - uVar9;
        if (uVar4 < uVar15) {
            uVar10 = uVar9 - cVar24;
        }
        uVar11 = (uVar8 & *puVar2) >> (uVar10 & 0x1f);
        if (uVar15 <= uVar4) {
            uVar11 = (uVar8 & *puVar2) << (uVar10 & 0x1f);
        }
        if (*(int64_t *)(arg1 + 8) == 0) {
            uVar21 = 0;
        }
        uVar8 = (uVar21 | uVar23) & *puVar12;
        if (uVar3 == 0) {
            uVar11 = uVar8 | uVar11;
        } else {
            uVar11 = (*puVar1 & uVar17) << ((char)*(int64_t *)(arg1 + 8) - cVar25 & 0x1fU) | uVar8 | uVar11;
        }
    } else {
        uVar14 = (uint64_t)((uint32_t)uVar4 & 7);
        uVar11 = (uint32_t)uVar15 & 7;
        uVar19 = (uint64_t)uVar11;
        if (uVar19 == uVar14) {
            uVar8 = (uint32_t)uVar3 & 7;
            puVar27 = (uint8_t *)((int64_t)puVar1 + (uVar3 - uVar8 >> 3));
            puVar22 = (uint8_t *)((uVar15 - uVar19 >> 3) + (int64_t)puVar2);
            puVar13 = (uint8_t *)((uVar4 - uVar14 >> 3) + (int64_t)puVar12);
            if (uVar19 != 0) {
                iVar16 = (int8_t)uVar11;
                uVar9 = *puVar22;
                puVar22 = puVar22 + 1;
                *puVar13 = (uint8_t)(0xff >> (8U - iVar16 & 0x1f)) & *puVar13 | -1 << iVar16 & uVar9;
                puVar13 = puVar13 + 1;
            }
            iVar26 = (int64_t)puVar27 - (int64_t)puVar22;
            fcn.180498030(puVar13, puVar22, iVar26);
            if ((uint64_t)uVar8 == 0) {
                return arg1;
            }
            puVar13[iVar26] =
                 (uint8_t)(0xff >> (8U - (int8_t)uVar8 & 0x1f)) & *puVar27 | -1 << (int8_t)uVar8 & puVar13[iVar26];
            return arg1;
        }
        puVar20 = puVar2 + 1;
        if (uVar4 < uVar15) {
            uVar15 = uVar15 - uVar4;
            uVar9 = (uint8_t)uVar15;
            uVar8 = (uVar8 & *puVar2) >> (uVar9 & 0x1f) | uVar23 & *puVar12;
            uVar23 = 0xffffffff >> (uVar9 & 0x1f);
            *puVar12 = uVar8;
            if (puVar20 != puVar1) {
                do {
                    *puVar12 = uVar8 & uVar23 | *puVar20 << (0x20 - uVar9 & 0x1f);
                    puVar12 = puVar12 + 1;
                    uVar8 = *puVar20;
                    puVar20 = puVar20 + 1;
                    uVar8 = *puVar12 & ~uVar23 | uVar8 >> (uVar9 & 0x1f);
                    *puVar12 = uVar8;
                } while (puVar20 != puVar1);
            }
            if (uVar3 == 0) {
                return arg1;
            }
            uVar8 = (*puVar20 & uVar17) << (0x20 - uVar9 & 0x1f);
            if (uVar3 < uVar15) {
                *puVar12 = (uVar23 | uVar21) & *puVar12 | uVar8;
                return arg1;
            }
            *puVar12 = uVar23 & *puVar12 | uVar8;
            if (uVar3 == uVar15) {
                return arg1;
            }
            puVar12[1] = (*puVar20 & uVar17) >> (uVar9 & 0x1f) | uVar21 & puVar12[1];
            return arg1;
        }
        uVar14 = 0x20 - (uVar4 - uVar15);
        uVar9 = (uint8_t)(uVar4 - uVar15);
        *puVar12 = (uVar8 & *puVar2) << (uVar9 & 0x1f) | uVar23 & *puVar12;
        uVar10 = (uint8_t)uVar14;
        uVar11 = *puVar2 >> (uVar10 & 0x1f);
        for (; puVar12 = puVar12 + 1, puVar20 != puVar1; puVar20 = puVar20 + 1) {
            *puVar12 = *puVar20 << (uVar9 & 0x1f) | uVar11;
            uVar11 = *puVar20 >> (uVar10 & 0x1f);
        }
        if (uVar14 <= uVar3) {
            *puVar12 = *puVar20 << (uVar9 & 0x1f) | uVar11;
            if (uVar3 == uVar14) {
                return arg1;
            }
            puVar12[1] = *puVar20 >> (uVar10 & 0x1f) & ~uVar21 | uVar21 & puVar12[1];
            return arg1;
        }
        if (uVar3 != 0) {
            *puVar12 = (*puVar20 & uVar17) << (uVar9 & 0x1f) | uVar11 | uVar21 & *puVar12;
            return arg1;
        }
        uVar11 = uVar11 | uVar21 & *puVar12;
    }
    *puVar12 = uVar11;
    return arg1;
}

// ============================================================
// Function: FUN_18002fda0
// Address: 0x18002fda0
// Size: 116 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002fda0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    puVar7 = auStack_38;
    iVar10 = *(int64_t *)arg1;
    uVar9 = *(int64_t *)(arg1 + 8) - iVar10 >> 2;
    if ((uint64_t)arg2 < uVar9) {
        *(int64_t *)(arg1 + 8) = iVar10 + arg2 * 4;
        return;
    }
    if (uVar9 < (uint64_t)arg2) {
        uVar5 = *(int64_t *)(arg1 + 0x10) - iVar10 >> 2;
        if ((uint64_t)arg2 <= uVar5) {
            uVar4 = fcn.180030950(*(int64_t *)(arg1 + 8), arg2 - uVar9, arg3, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        if ((0x3fffffffffffffff - (uVar5 >> 1) < uVar5) ||
           ((uVar5 = uVar5 + (uVar5 >> 1), uVar8 = arg2, (uint64_t)arg2 <= uVar5 &&
            (uVar8 = uVar5, 0x3fffffffffffffff < uVar5)))) {
code_r0x00018002ff2f:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = uVar8 * 4;
        if (uVar5 == 0) {
            uVar5 = 0;
            puVar7 = auStack_38;
        } else if (uVar5 < 0x1000) {
            uVar5 = fcn.180459890();
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x00018002ff2f;
            iVar10 = fcn.180459890(uVar5 + 0x27);
            if (iVar10 == 0) {
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar6 = auStack_30;
            }
            uVar5 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar10;
            puVar7 = puVar6;
        }
        puVar1 = (undefined4 *)(uVar5 + uVar9 * 4);
        iVar10 = arg2 - uVar9;
        if (*(int32_t *)arg3 == 0) {
            *(undefined8 *)(puVar7 + -8) = 0x18002feb6;
            fcn.1804986e0(puVar1, 0, iVar10 * 4);
        } else {
            for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                *puVar1 = *(undefined4 *)arg3;
                puVar1 = puVar1 + 1;
            }
        }
        iVar10 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar7 + -8) = 0x18002fee1;
        fcn.180498030(uVar5, iVar10, iVar2 - iVar10);
        *(undefined8 *)(puVar7 + -8) = 0x18002fef2;
        fcn.180030d40(arg1, uVar5, arg2, uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_18002fe14
// Address: 0x18002fe14
// Size: 232 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002fda0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    puVar7 = auStack_38;
    iVar10 = *(int64_t *)arg1;
    uVar9 = *(int64_t *)(arg1 + 8) - iVar10 >> 2;
    if ((uint64_t)arg2 < uVar9) {
        *(int64_t *)(arg1 + 8) = iVar10 + arg2 * 4;
        return;
    }
    if (uVar9 < (uint64_t)arg2) {
        uVar5 = *(int64_t *)(arg1 + 0x10) - iVar10 >> 2;
        if ((uint64_t)arg2 <= uVar5) {
            uVar4 = fcn.180030950(*(int64_t *)(arg1 + 8), arg2 - uVar9, arg3, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        if ((0x3fffffffffffffff - (uVar5 >> 1) < uVar5) ||
           ((uVar5 = uVar5 + (uVar5 >> 1), uVar8 = arg2, (uint64_t)arg2 <= uVar5 &&
            (uVar8 = uVar5, 0x3fffffffffffffff < uVar5)))) {
code_r0x00018002ff2f:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = uVar8 * 4;
        if (uVar5 == 0) {
            uVar5 = 0;
            puVar7 = auStack_38;
        } else if (uVar5 < 0x1000) {
            uVar5 = fcn.180459890();
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x00018002ff2f;
            iVar10 = fcn.180459890(uVar5 + 0x27);
            if (iVar10 == 0) {
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar6 = auStack_30;
            }
            uVar5 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar10;
            puVar7 = puVar6;
        }
        puVar1 = (undefined4 *)(uVar5 + uVar9 * 4);
        iVar10 = arg2 - uVar9;
        if (*(int32_t *)arg3 == 0) {
            *(undefined8 *)(puVar7 + -8) = 0x18002feb6;
            fcn.1804986e0(puVar1, 0, iVar10 * 4);
        } else {
            for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                *puVar1 = *(undefined4 *)arg3;
                puVar1 = puVar1 + 1;
            }
        }
        iVar10 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar7 + -8) = 0x18002fee1;
        fcn.180498030(uVar5, iVar10, iVar2 - iVar10);
        *(undefined8 *)(puVar7 + -8) = 0x18002fef2;
        fcn.180030d40(arg1, uVar5, arg2, uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_18002fefc
// Address: 0x18002fefc
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002fda0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    puVar7 = auStack_38;
    iVar10 = *(int64_t *)arg1;
    uVar9 = *(int64_t *)(arg1 + 8) - iVar10 >> 2;
    if ((uint64_t)arg2 < uVar9) {
        *(int64_t *)(arg1 + 8) = iVar10 + arg2 * 4;
        return;
    }
    if (uVar9 < (uint64_t)arg2) {
        uVar5 = *(int64_t *)(arg1 + 0x10) - iVar10 >> 2;
        if ((uint64_t)arg2 <= uVar5) {
            uVar4 = fcn.180030950(*(int64_t *)(arg1 + 8), arg2 - uVar9, arg3, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        if ((0x3fffffffffffffff - (uVar5 >> 1) < uVar5) ||
           ((uVar5 = uVar5 + (uVar5 >> 1), uVar8 = arg2, (uint64_t)arg2 <= uVar5 &&
            (uVar8 = uVar5, 0x3fffffffffffffff < uVar5)))) {
code_r0x00018002ff2f:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = uVar8 * 4;
        if (uVar5 == 0) {
            uVar5 = 0;
            puVar7 = auStack_38;
        } else if (uVar5 < 0x1000) {
            uVar5 = fcn.180459890();
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x00018002ff2f;
            iVar10 = fcn.180459890(uVar5 + 0x27);
            if (iVar10 == 0) {
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar6 = auStack_30;
            }
            uVar5 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar10;
            puVar7 = puVar6;
        }
        puVar1 = (undefined4 *)(uVar5 + uVar9 * 4);
        iVar10 = arg2 - uVar9;
        if (*(int32_t *)arg3 == 0) {
            *(undefined8 *)(puVar7 + -8) = 0x18002feb6;
            fcn.1804986e0(puVar1, 0, iVar10 * 4);
        } else {
            for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                *puVar1 = *(undefined4 *)arg3;
                puVar1 = puVar1 + 1;
            }
        }
        iVar10 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar7 + -8) = 0x18002fee1;
        fcn.180498030(uVar5, iVar10, iVar2 - iVar10);
        *(undefined8 *)(puVar7 + -8) = 0x18002fef2;
        fcn.180030d40(arg1, uVar5, arg2, uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_18002ff2f
// Address: 0x18002ff2f
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002fda0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    puVar7 = auStack_38;
    iVar10 = *(int64_t *)arg1;
    uVar9 = *(int64_t *)(arg1 + 8) - iVar10 >> 2;
    if ((uint64_t)arg2 < uVar9) {
        *(int64_t *)(arg1 + 8) = iVar10 + arg2 * 4;
        return;
    }
    if (uVar9 < (uint64_t)arg2) {
        uVar5 = *(int64_t *)(arg1 + 0x10) - iVar10 >> 2;
        if ((uint64_t)arg2 <= uVar5) {
            uVar4 = fcn.180030950(*(int64_t *)(arg1 + 8), arg2 - uVar9, arg3, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        if ((0x3fffffffffffffff - (uVar5 >> 1) < uVar5) ||
           ((uVar5 = uVar5 + (uVar5 >> 1), uVar8 = arg2, (uint64_t)arg2 <= uVar5 &&
            (uVar8 = uVar5, 0x3fffffffffffffff < uVar5)))) {
code_r0x00018002ff2f:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = uVar8 * 4;
        if (uVar5 == 0) {
            uVar5 = 0;
            puVar7 = auStack_38;
        } else if (uVar5 < 0x1000) {
            uVar5 = fcn.180459890();
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x00018002ff2f;
            iVar10 = fcn.180459890(uVar5 + 0x27);
            if (iVar10 == 0) {
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar6 = auStack_30;
            }
            uVar5 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar10;
            puVar7 = puVar6;
        }
        puVar1 = (undefined4 *)(uVar5 + uVar9 * 4);
        iVar10 = arg2 - uVar9;
        if (*(int32_t *)arg3 == 0) {
            *(undefined8 *)(puVar7 + -8) = 0x18002feb6;
            fcn.1804986e0(puVar1, 0, iVar10 * 4);
        } else {
            for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                *puVar1 = *(undefined4 *)arg3;
                puVar1 = puVar1 + 1;
            }
        }
        iVar10 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar7 + -8) = 0x18002fee1;
        fcn.180498030(uVar5, iVar10, iVar2 - iVar10);
        *(undefined8 *)(puVar7 + -8) = 0x18002fef2;
        fcn.180030d40(arg1, uVar5, arg2, uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_18002ff35
// Address: 0x18002ff35
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18002fda0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined4 *puVar1;
    int64_t iVar2;
    code *pcVar3;
    undefined8 uVar4;
    uint64_t uVar5;
    undefined *puVar6;
    undefined *puVar7;
    uint64_t uVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_38 [8];
    undefined auStack_30 [24];
    
    puVar6 = auStack_38;
    puVar7 = auStack_38;
    iVar10 = *(int64_t *)arg1;
    uVar9 = *(int64_t *)(arg1 + 8) - iVar10 >> 2;
    if ((uint64_t)arg2 < uVar9) {
        *(int64_t *)(arg1 + 8) = iVar10 + arg2 * 4;
        return;
    }
    if (uVar9 < (uint64_t)arg2) {
        uVar5 = *(int64_t *)(arg1 + 0x10) - iVar10 >> 2;
        if ((uint64_t)arg2 <= uVar5) {
            uVar4 = fcn.180030950(*(int64_t *)(arg1 + 8), arg2 - uVar9, arg3, arg1);
            *(undefined8 *)(arg1 + 8) = uVar4;
            return;
        }
        if (0x3fffffffffffffff < (uint64_t)arg2) {
            fcn.180010010();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        if ((0x3fffffffffffffff - (uVar5 >> 1) < uVar5) ||
           ((uVar5 = uVar5 + (uVar5 >> 1), uVar8 = arg2, (uint64_t)arg2 <= uVar5 &&
            (uVar8 = uVar5, 0x3fffffffffffffff < uVar5)))) {
code_r0x00018002ff2f:
            fcn.180004720();
            pcVar3 = (code *)swi(3);
            (*pcVar3)();
            return;
        }
        uVar5 = uVar8 * 4;
        if (uVar5 == 0) {
            uVar5 = 0;
            puVar7 = auStack_38;
        } else if (uVar5 < 0x1000) {
            uVar5 = fcn.180459890();
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x00018002ff2f;
            iVar10 = fcn.180459890(uVar5 + 0x27);
            if (iVar10 == 0) {
                pcVar3 = (code *)swi(0x29);
                iVar10 = (*pcVar3)(5);
                puVar6 = auStack_30;
            }
            uVar5 = iVar10 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar5 - 8) = iVar10;
            puVar7 = puVar6;
        }
        puVar1 = (undefined4 *)(uVar5 + uVar9 * 4);
        iVar10 = arg2 - uVar9;
        if (*(int32_t *)arg3 == 0) {
            *(undefined8 *)(puVar7 + -8) = 0x18002feb6;
            fcn.1804986e0(puVar1, 0, iVar10 * 4);
        } else {
            for (; iVar10 != 0; iVar10 = iVar10 + -1) {
                *puVar1 = *(undefined4 *)arg3;
                puVar1 = puVar1 + 1;
            }
        }
        iVar10 = *(int64_t *)arg1;
        iVar2 = *(int64_t *)(arg1 + 8);
        *(undefined8 *)(puVar7 + -8) = 0x18002fee1;
        fcn.180498030(uVar5, iVar10, iVar2 - iVar10);
        *(undefined8 *)(puVar7 + -8) = 0x18002fef2;
        fcn.180030d40(arg1, uVar5, arg2, uVar8);
    }
    return;
}

// ============================================================
// Function: FUN_18002ff40
// Address: 0x18002ff40
// Size: 243 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18002ff40(int64_t arg1, int64_t arg2)
{
    char cVar1;
    code *pcVar2;
    int32_t iVar3;
    char *pcVar4;
    uint32_t uVar5;
    uint64_t uVar6;
    int64_t var_8h;
    
    *(undefined4 *)(arg1 + 0x6c) = 0;
    uVar5 = (uint32_t)arg2;
    uVar6 = arg2 & 0xffffffff;
    while( true ) {
        if (uVar5 == 0) {
            return;
        }
        cVar1 = *(char *)(arg1 + 0x75);
        iVar3 = (int32_t)cVar1;
        if ((uint8_t)(cVar1 - 0x30U) < 10) {
            iVar3 = iVar3 + -0x30;
        } else if ((uint8_t)(cVar1 + 0x9fU) < 6) {
            iVar3 = iVar3 + -0x57;
        } else {
            if (5 < (uint8_t)(cVar1 + 0xbfU)) break;
            iVar3 = iVar3 + -0x37;
        }
        if (iVar3 == -1) break;
        if ((int32_t)((0x7fffffff - iVar3) + (0x7fffffff - iVar3 >> 0x1f & 0xfU)) >> 4 < *(int32_t *)(arg1 + 0x6c)) {
            func_0x00018002ed40(iVar3, 2);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        uVar5 = (int32_t)uVar6 - 1;
        uVar6 = (uint64_t)uVar5;
        pcVar4 = *(char **)arg1;
        *(int32_t *)(arg1 + 0x6c) = *(int32_t *)(arg1 + 0x6c) * 0x10 + iVar3;
        if (pcVar4 != *(char **)(arg1 + 8)) {
            if ((((*pcVar4 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                (pcVar4 = pcVar4 + 1, pcVar4 != *(char **)(arg1 + 8))) &&
               ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar4 - 0x28U) < 2)) ||
                (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar4 + 0x85U & 0xfd) == 0)))))) {
                *(char **)arg1 = pcVar4;
            }
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        func_0x00018002b970(arg1);
    }
    if ((int32_t)uVar6 == 0) {
        return;
    }
    func_0x00018002ed40(iVar3, 2);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180030040
// Address: 0x180030040
// Size: 1574 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_28h

void fcn.180030040(int64_t arg1)
{
    char *pcVar1;
    int64_t *piVar2;
    undefined uVar3;
    int32_t iVar4;
    int64_t *piVar5;
    code *pcVar6;
    undefined auVar7 [16];
    int64_t *piVar8;
    char cVar9;
    undefined uVar10;
    int16_t iVar11;
    uint32_t *puVar12;
    int64_t iVar13;
    uint32_t uVar14;
    char *pcVar15;
    char in_DL;
    uint64_t uVar16;
    undefined *puVar17;
    uint32_t uVar18;
    int64_t *piVar19;
    char *pcVar20;
    uint32_t **ppuVar21;
    undefined4 uVar22;
    undefined4 extraout_XMM0_Da;
    undefined4 extraout_XMM0_Da_00;
    undefined4 extraout_XMM0_Da_01;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_78 [8];
    undefined auStack_70 [32];
    int64_t var_50h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    var_30h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    iVar4 = *(int32_t *)(arg1 + 0x70);
    if ((iVar4 == 0x5c) && ((*(uint32_t *)(arg1 + 0x60) >> 0x14 & 1) != 0)) {
        func_0x00018002cd80(arg1);
        if (((*(uint64_t *)(arg1 + 0x60) >> 0xd & 1) == 0) || (*(char *)(arg1 + 0x75) != 'b')) {
            if ((*(uint64_t *)(arg1 + 0x60) & 0x80080) != 0) {
                if ((uint8_t)(*(char *)(arg1 + 0x75) - 0x30U) < 10) {
                    iVar4 = *(char *)(arg1 + 0x75) + -0x30;
                    *(int32_t *)(arg1 + 0x6c) = iVar4;
                    if (iVar4 != -1) {
                        uVar22 = func_0x00018002cd80(arg1);
                        if ((((*(uint32_t *)(arg1 + 0x60) >> 0x13 & 1) == 0) || (*(int32_t *)(arg1 + 0x6c) != 0)) ||
                           (((uint8_t)(*(char *)(arg1 + 0x75) - 0x30U) < 10 && (*(char *)(arg1 + 0x75) != '/')))) {
                            func_0x00018002ed40(uVar22, 2);
                            pcVar6 = (code *)swi(3);
                            (*pcVar6)();
                            return;
                        }
                        *(undefined *)(arg1 + 0x76) = 0;
                        puVar17 = auStack_78;
                        goto code_r0x0001800305e9;
                    }
                } else {
                    *(undefined4 *)(arg1 + 0x6c) = 0xffffffff;
                }
            }
            cVar9 = fcn.18002f320(arg1);
            puVar17 = auStack_78;
            if ((cVar9 == '\0') &&
               ((uVar22 = extraout_XMM0_Da, (*(uint32_t *)(arg1 + 0x60) >> 0x10 & 1) == 0 ||
                (cVar9 = fcn.18002f250(arg1), puVar17 = auStack_78, uVar22 = extraout_XMM0_Da_00, cVar9 == '\0')))) {
code_r0x00018003061a:
                func_0x00018002ed40(uVar22, 2);
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
        } else {
            func_0x00018002cd80(arg1);
            *(undefined *)(arg1 + 0x76) = 8;
            puVar17 = auStack_78;
        }
        goto code_r0x0001800305e9;
    }
    if (iVar4 != 0x5b) {
        if (((iVar4 != 0x5d) ||
            ((puVar17 = auStack_78, (*(uint32_t *)(arg1 + 0x60) >> 0x1d & 1) != 0 &&
             (puVar17 = auStack_78, in_DL != '\0')))) && (puVar17 = auStack_78, iVar4 != -1)) {
            *(undefined *)(arg1 + 0x76) = *(undefined *)(arg1 + 0x75);
            func_0x00018002cd80(arg1);
            puVar17 = auStack_78;
        }
        goto code_r0x0001800305e9;
    }
    uVar10 = *(undefined *)(arg1 + 0x75);
    pcVar15 = *(char **)arg1;
    if (pcVar15 != *(char **)(arg1 + 8)) {
        if ((((*pcVar15 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
            (pcVar15 = pcVar15 + 1, pcVar15 != *(char **)(arg1 + 8))) &&
           ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar15 - 0x28U) < 2)) ||
            (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar15 + 0x85U & 0xfd) == 0)))))) {
            *(char **)arg1 = pcVar15;
        }
        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
    }
    func_0x00018002b970(arg1);
    uVar18 = *(uint32_t *)(arg1 + 0x70);
    puVar17 = auStack_78;
    if ((uVar18 < 0x3e) && (puVar17 = auStack_78, (0x2400400000000000U >> ((uint64_t)uVar18 & 0x3f) & 1) != 0)) {
        pcVar15 = *(char **)arg1;
        if (pcVar15 != *(char **)(arg1 + 8)) {
            if ((((*pcVar15 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                (pcVar15 = pcVar15 + 1, pcVar15 != *(char **)(arg1 + 8))) &&
               ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar15 - 0x28U) < 2)) ||
                (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar15 + 0x85U & 0xfd) == 0)))))) {
                *(char **)arg1 = pcVar15;
            }
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        func_0x00018002b970(arg1);
        pcVar15 = *(char **)arg1;
        uVar14 = *(uint32_t *)(arg1 + 0x70);
        if (uVar14 == 0x3a) {
            uVar14 = 0x3a;
        } else {
            do {
                if (((uVar14 == 0x3d) || (uVar14 == 0x2e)) || (uVar14 == 0xffffffff)) break;
                pcVar20 = *(char **)arg1;
                if (pcVar20 != *(char **)(arg1 + 8)) {
                    if ((((*pcVar20 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                        (pcVar20 = pcVar20 + 1, pcVar20 != *(char **)(arg1 + 8))) &&
                       ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar20 - 0x28U) < 2)) ||
                        (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar20 + 0x85U & 0xfd) == 0)))))) {
                        *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                    }
                    *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
                }
                func_0x00018002b970(arg1);
                uVar14 = *(uint32_t *)(arg1 + 0x70);
            } while (uVar14 != 0x3a);
        }
        if (uVar14 != uVar18) {
            func_0x00018002ed40(uVar14, uVar18 == 0x3a);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        pcVar20 = *(char **)arg1;
        if (pcVar20 != *(char **)(arg1 + 8)) {
            if (((*pcVar20 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
               ((pcVar1 = pcVar20 + 1, pcVar1 != *(char **)(arg1 + 8) &&
                ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar1 - 0x28U) < 2)) ||
                 (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar1 + 0x85U & 0xfd) == 0)))))))) {
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        uVar22 = func_0x00018002b970(arg1);
        if (*(int32_t *)(arg1 + 0x70) != 0x5d) {
            func_0x00018002ed40(uVar22, uVar18 == 0x3a);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        pcVar1 = *(char **)arg1;
        if (pcVar1 != *(char **)(arg1 + 8)) {
            if ((((*pcVar1 == '\\') && (*(char *)(arg1 + 0x74) == '\0')) &&
                (pcVar1 = pcVar1 + 1, pcVar1 != *(char **)(arg1 + 8))) &&
               ((((*(uint64_t *)(arg1 + 0x60) & 8) == 0 && ((uint8_t)(*pcVar1 - 0x28U) < 2)) ||
                (((*(uint64_t *)(arg1 + 0x60) & 0x10) == 0 && ((*pcVar1 + 0x85U & 0xfd) == 0)))))) {
                *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
            }
            *(int64_t *)arg1 = *(int64_t *)arg1 + 1;
        }
        func_0x00018002b970(arg1);
        if (uVar18 == 0x3a) {
            iVar11 = func_0x00018002c7f0(*(undefined8 *)(arg1 + 0x58), pcVar15, pcVar20, 
                                         *(uint32_t *)(arg1 + 0x68) >> 8 & 0xffffff01);
            if (iVar11 != 0) {
                func_0x0001800306f0(arg1 + 0x38, iVar11, 0);
                puVar17 = auStack_78;
                goto code_r0x0001800305e9;
            }
            uVar22 = func_0x00018002ed40(extraout_XMM0_Da_01, 1);
code_r0x00018003064d:
            func_0x00018002ed40(uVar22, 0);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        if ((pcVar15 == pcVar20) || (pcVar15 + 1 != pcVar20)) {
            uVar22 = 0;
            var_40h = 0;
            var_38h = 0xf;
            stack0xffffffffffffffb1 = SUB1615(ZEXT816(0), 1);
            auVar7[15] = 0;
            auVar7._0_15_ = stack0xffffffffffffffb1;
            _var_50h = auVar7 << 8;
        } else {
            _var_50h = ZEXT816(0);
            var_40h = 0;
            var_38h = 0;
            pcVar20 = pcVar20 + -(int64_t)pcVar15;
            uVar22 = func_0x000180004830(&var_50h, pcVar15, pcVar20);
        }
        uVar10 = SUB81(pcVar20, 0);
        if (var_40h == 0) goto code_r0x00018003064d;
        if (0xffffffff < (uint64_t)var_40h) {
            func_0x00018002ed40(uVar22, 9);
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        piVar19 = &var_50h;
        if (0xf < (uint64_t)var_38h) {
            piVar19 = (int64_t *)var_50h;
        }
        if ((var_40h != 1) || (uVar18 != 0x2e)) {
            piVar2 = (int64_t *)((int64_t)piVar19 + var_40h);
            piVar8 = piVar19;
            if ((*(uint32_t *)(arg1 + 0x68) & 0x100) != 0) {
                for (; piVar8 != piVar2; piVar8 = (int64_t *)((int64_t)piVar8 + 1)) {
                    piVar5 = *(int64_t **)(*(int64_t *)(arg1 + 0x58) + 8);
                    uVar10 = (**(code **)(*piVar5 + 0x20))(piVar5, *(undefined *)piVar8);
                    *(undefined *)piVar8 = uVar10;
                }
            }
            if (uVar18 == 0x3d) {
                func_0x000180030c60();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            ppuVar21 = (uint32_t **)(*(int64_t *)(arg1 + 0x40) + 0x20);
            uVar18 = (int32_t)piVar2 - (int32_t)piVar19;
            arg1 = (int64_t)*ppuVar21;
            if ((uint32_t *)arg1 == (uint32_t *)0x0) {
code_r0x0001800304cf:
                puVar12 = (uint32_t *)fcn.180459890(0x20);
                *puVar12 = uVar18;
                *(undefined8 *)(puVar12 + 2) = 0;
                *(undefined8 *)(puVar12 + 4) = 0;
                *ppuVar21 = puVar12;
                *(int64_t *)(puVar12 + 6) = arg1;
                arg1 = (int64_t)*ppuVar21;
            } else {
                do {
                    if (*(uint32_t *)arg1 <= uVar18) break;
                    ppuVar21 = (uint32_t **)(*ppuVar21 + 6);
                    arg1 = (int64_t)*ppuVar21;
                } while ((uint32_t *)arg1 != (uint32_t *)0x0);
                arg1 = (int64_t)*ppuVar21;
                if (((uint32_t *)arg1 == (uint32_t *)0x0) || (uVar18 != *(uint32_t *)arg1)) goto code_r0x0001800304cf;
            }
            uVar10 = SUB81(ppuVar21, 0);
            while (piVar19 != piVar2) {
                uVar3 = *(undefined *)piVar19;
                piVar19 = (int64_t *)((int64_t)piVar19 + 1);
                uVar18 = *(uint32_t *)(arg1 + 8);
                if (uVar18 <= *(uint32_t *)(arg1 + 0xc)) {
                    uVar14 = uVar18 >> 1;
                    if (uVar14 < 0x11) {
                        uVar14 = 0x10;
code_r0x000180030523:
                        ppuVar21 = (uint32_t **)(uint64_t)(uVar14 + uVar18);
                        if (~uVar14 <= uVar18) goto code_r0x00018003052e;
                    } else {
                        if (uVar14 != 0xffffffff) goto code_r0x000180030523;
code_r0x00018003052e:
                        ppuVar21 = (uint32_t **)0xffffffff;
                    }
                    if (((uint32_t)ppuVar21 == uVar18) ||
                       (iVar13 = func_0x00018046d060(*(undefined8 *)(arg1 + 0x10), ppuVar21), iVar13 == 0)) {
                        uVar22 = func_0x00018045471c(9);
                        goto code_r0x00018003061a;
                    }
                    *(int64_t *)(arg1 + 0x10) = iVar13;
                    *(uint32_t *)(arg1 + 8) = (uint32_t)ppuVar21;
                }
                uVar10 = SUB81(ppuVar21, 0);
                *(undefined *)((uint64_t)*(uint32_t *)(arg1 + 0xc) + *(int64_t *)(arg1 + 0x10)) = uVar3;
                *(uint32_t *)(arg1 + 0xc) = *(uint32_t *)(arg1 + 0xc) + 1;
            }
            puVar17 = auStack_78;
            if ((uint64_t)var_38h < 0x10) goto code_r0x0001800305e9;
            uVar16 = var_38h + 1;
            iVar13 = var_50h;
            if (0xfff < uVar16) {
                iVar13 = *(int64_t *)(var_50h + -8);
                if (0x1f < (var_50h - iVar13) - 8U) goto code_r0x0001800305ac;
                uVar16 = var_38h + 0x28;
            }
            func_0x000180459c3c(iVar13, uVar16);
            puVar17 = auStack_78;
            goto code_r0x0001800305e9;
        }
        *(undefined *)(arg1 + 0x76) = *(undefined *)piVar19;
        puVar17 = auStack_78;
        if ((uint64_t)var_38h < 0x10) goto code_r0x0001800305e9;
        uVar16 = var_38h + 1;
        iVar13 = var_50h;
        if (uVar16 < 0x1000) {
code_r0x00018003044b:
            func_0x000180459c3c(iVar13, uVar16);
            puVar17 = auStack_78;
            goto code_r0x0001800305e9;
        }
        iVar13 = *(int64_t *)(var_50h + -8);
        if ((var_50h - iVar13) - 8U < 0x20) {
            uVar16 = var_38h + 0x28;
            goto code_r0x00018003044b;
        }
code_r0x0001800305ac:
        pcVar6 = (code *)swi(0x29);
        (*pcVar6)(5);
        puVar17 = auStack_70;
    }
    *(undefined *)(arg1 + 0x76) = uVar10;
code_r0x0001800305e9:
    *(undefined8 *)(puVar17 + -8) = 0x1800305f6;
    func_0x000180459870(*(uint64_t *)(puVar17 + 0x48) ^ (uint64_t)puVar17);
    return;
}

// ============================================================
// Function: FUN_180030670
// Address: 0x180030670
// Size: 117 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180030670(int64_t arg1)
{
    int64_t iVar1;
    undefined (*pauVar2) [16];
    uint8_t in_DL;
    int64_t var_8h;
    
    if ((*(uint32_t *)(arg1 + 0x10) & 0x100) != 0) {
        in_DL = (**(code **)(**(int64_t **)(*(int64_t *)(arg1 + 0x18) + 8) + 0x20))();
    }
    iVar1 = *(int64_t *)(arg1 + 8);
    pauVar2 = *(undefined (**) [16])(iVar1 + 0x28);
    if (pauVar2 == (undefined (*) [16])0x0) {
        pauVar2 = (undefined (*) [16])fcn.180459890(0x20);
        *pauVar2 = ZEXT816(0);
        pauVar2[1] = ZEXT816(0);
        *(undefined (**) [16])(iVar1 + 0x28) = pauVar2;
    }
    (*pauVar2)[in_DL >> 3] = (*pauVar2)[in_DL >> 3] | (uint8_t)(1 << (in_DL & 7));
    return;
}

// ============================================================
// Function: FUN_1800306f0
// Address: 0x1800306f0
// Size: 187 bytes
// ============================================================
void fcn.1800306f0(int64_t arg1, undefined8 placeholder_1, int64_t arg3)
{
    int64_t iVar1;
    undefined (*pauVar2) [16];
    uint32_t uVar3;
    uint64_t uVar4;
    bool bVar5;
    int64_t var_18h;
    
    iVar1 = *(int64_t *)(arg1 + 8);
    uVar4 = 0;
    do {
        if ((uint16_t)placeholder_1 == 0xffff) {
            if (((char)uVar4 == '_') ||
               ((*(uint16_t *)(*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x18) + 8) + 0x18) + (uVar4 & 0xff) * 2) &
                0x107) != 0)) {
                bVar5 = true;
            } else {
                bVar5 = false;
            }
        } else {
            bVar5 = (*(uint16_t *)
                      (*(int64_t *)(*(int64_t *)(*(int64_t *)(arg1 + 0x18) + 8) + 0x18) + (uVar4 & 0xff) * 2) &
                    (uint16_t)placeholder_1) != 0;
        }
        if (bVar5 != ((int32_t)arg3 != 0)) {
            pauVar2 = *(undefined (**) [16])(iVar1 + 0x28);
            if (pauVar2 == (undefined (*) [16])0x0) {
                pauVar2 = (undefined (*) [16])fcn.180459890(0x20);
                *pauVar2 = ZEXT816(0);
                pauVar2[1] = ZEXT816(0);
                *(undefined (**) [16])(iVar1 + 0x28) = pauVar2;
            }
            (*pauVar2)[uVar4 >> 3] = (*pauVar2)[uVar4 >> 3] | (uint8_t)(1 << ((uint32_t)uVar4 & 7));
        }
        uVar3 = (uint32_t)uVar4 + 1;
        uVar4 = (uint64_t)uVar3;
    } while (uVar3 < 0x100);
    return;
}

// ============================================================
// Function: FUN_1800307b0
// Address: 0x1800307b0
// Size: 135 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.1800307b0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t var_8h;
    
    if ((uint64_t)arg2 < 0x1000000000000000) {
        uVar5 = arg2 * 0x10;
        if (uVar5 == 0) {
            uVar3 = 0;
        } else if (uVar5 < 0x1000) {
            uVar3 = fcn.180459890(uVar5);
        } else {
            if (uVar5 + 0x27 <= uVar5) goto code_r0x000180030831;
            iVar2 = fcn.180459890();
            iVar4 = iVar2;
            if (iVar2 == 0) {
                iVar4 = 5;
                pcVar1 = (code *)swi(0x29);
                iVar2 = (*pcVar1)();
            }
            uVar3 = iVar2 + 0x27U & 0xffffffffffffffe0;
            *(int64_t *)(uVar3 - 8) = iVar4;
        }
        *(uint64_t *)arg1 = uVar3;
        *(uint64_t *)(arg1 + 8) = uVar3;
        *(uint64_t *)(arg1 + 0x10) = uVar3 + uVar5;
        return;
    }
code_r0x000180030831:
    fcn.180004720();
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180030840
// Address: 0x180030840
// Size: 190 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180030840(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    if (0x3fffffffffffffff < (uint64_t)arg2) {
        fcn.180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = *(int64_t *)arg1;
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar3 >> 2;
    uVar4 = 0x3fffffffffffffff;
    if ((uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) && (uVar4 = uVar6 + (uVar6 >> 1), uVar4 < (uint64_t)arg2)) {
        uVar4 = arg2;
    }
    if (iVar3 != 0) {
        iVar2 = iVar3;
        puVar5 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 2) * 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar5 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800308d6;
        func_0x000180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    *(undefined8 *)(puVar5 + 0x30) = *(undefined8 *)(puVar5 + 0x30);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(puVar5 + 0x20);
    if (0x3fffffffffffffff < uVar4) {
code_r0x000180030b02:
        *(undefined8 *)(puVar5 + -8) = 0x180030b07;
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar4 = uVar4 * 4;
    if (uVar4 == 0) {
        uVar6 = 0;
    } else if (uVar4 < 0x1000) {
        *(undefined8 *)(puVar5 + -8) = 0x180030ae9;
        uVar6 = fcn.180459890(uVar4);
    } else {
        if (uVar4 + 0x27 <= uVar4) goto code_r0x000180030b02;
        *(undefined8 *)(puVar5 + -8) = 0x180030ac4;
        iVar2 = fcn.180459890();
        iVar3 = iVar2;
        if (iVar2 == 0) {
            iVar3 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar6 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar6 - 8) = iVar3;
    }
    *(uint64_t *)arg1 = uVar6;
    *(uint64_t *)(arg1 + 8) = uVar6;
    *(uint64_t *)(arg1 + 0x10) = uVar6 + uVar4;
    return;
}

// ============================================================
// Function: FUN_180030900
// Address: 0x180030900
// Size: 66 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180030900(int64_t arg1, int64_t arg2)
{
    int64_t var_8h;
    
    fcn.180460d90(*(undefined8 *)(arg1 + 0x28));
    *(undefined8 *)arg1 = 0x1806220a0;
    if ((arg2 & 1U) != 0) {
        fcn.180459c3c(arg1, 0x30);
    }
    return arg1;
}

// ============================================================
// Function: FUN_180030950
// Address: 0x180030950
// Size: 15 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.180030950(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    
    if (*(int32_t *)arg3 != 0) {
        if (arg2 != 0) {
            do {
                *(undefined4 *)arg1 = *(undefined4 *)arg3;
                arg1 = arg1 + 4;
                arg2 = arg2 + -1;
            } while (arg2 != 0);
        }
        return (undefined4 *)arg1;
    }
    fcn.1804986e0(arg1, 0, arg2 * 4);
    return (undefined4 *)(arg2 * 4 + arg1);
}

// ============================================================
// Function: FUN_18003095f
// Address: 0x18003095f
// Size: 38 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.180030950(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    
    if (*(int32_t *)arg3 != 0) {
        if (arg2 != 0) {
            do {
                *(undefined4 *)arg1 = *(undefined4 *)arg3;
                arg1 = arg1 + 4;
                arg2 = arg2 + -1;
            } while (arg2 != 0);
        }
        return (undefined4 *)arg1;
    }
    fcn.1804986e0(arg1, 0, arg2 * 4);
    return (undefined4 *)(arg2 * 4 + arg1);
}

// ============================================================
// Function: FUN_180030985
// Address: 0x180030985
// Size: 35 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined4 * fcn.180030950(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_8h;
    
    if (*(int32_t *)arg3 != 0) {
        if (arg2 != 0) {
            do {
                *(undefined4 *)arg1 = *(undefined4 *)arg3;
                arg1 = arg1 + 4;
                arg2 = arg2 + -1;
            } while (arg2 != 0);
        }
        return (undefined4 *)arg1;
    }
    fcn.1804986e0(arg1, 0, arg2 * 4);
    return (undefined4 *)(arg2 * 4 + arg1);
}

// ============================================================
// Function: FUN_1800309b0
// Address: 0x1800309b0
// Size: 199 bytes
// ============================================================
void fcn.1800309b0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, undefined8 placeholder_4,
                  undefined8 placeholder_5, int64_t arg_38h)
{
    code *pcVar1;
    int64_t iVar2;
    undefined *puVar3;
    int64_t *piVar4;
    undefined auStack_78 [8];
    undefined auStack_70 [24];
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    puVar3 = auStack_78;
    var_28h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_78;
    var_50h = arg2;
    func_0x000180014b30(&var_48h, arg3, arg4, &var_58h);
    piVar4 = (int64_t *)var_48h;
    if ((uint64_t)var_30h < 0x10) {
        piVar4 = &var_48h;
    }
    (**(code **)(**(int64_t **)arg1 + 0x20))(*(int64_t **)arg1, arg2, piVar4, var_38h + (int64_t)piVar4);
    if (0xf < (uint64_t)var_30h) {
        iVar2 = var_48h;
        puVar3 = auStack_78;
        if ((0xfff < var_30h + 1U) &&
           (iVar2 = *(int64_t *)(var_48h + -8), puVar3 = auStack_78, 0x1f < (var_48h - iVar2) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)(5);
            puVar3 = auStack_70;
        }
        *(undefined8 *)(puVar3 + -8) = 0x180030a60;
        fcn.180459c3c(iVar2);
    }
    *(undefined8 *)(puVar3 + -8) = 0x180030a70;
    func_0x000180459870(*(uint64_t *)(puVar3 + 0x50) ^ (uint64_t)puVar3);
    return;
}

// ============================================================
// Function: FUN_180030a80
// Address: 0x180030a80
// Size: 136 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180030840(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    undefined *puVar5;
    uint64_t uVar6;
    int64_t var_8h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar5 = auStack_28;
    if (0x3fffffffffffffff < (uint64_t)arg2) {
        fcn.180010010();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    iVar3 = *(int64_t *)arg1;
    uVar6 = *(int64_t *)(arg1 + 0x10) - iVar3 >> 2;
    uVar4 = 0x3fffffffffffffff;
    if ((uVar6 <= 0x3fffffffffffffff - (uVar6 >> 1)) && (uVar4 = uVar6 + (uVar6 >> 1), uVar4 < (uint64_t)arg2)) {
        uVar4 = arg2;
    }
    if (iVar3 != 0) {
        iVar2 = iVar3;
        puVar5 = auStack_28;
        if ((0xfff < (uint64_t)((*(int64_t *)(arg1 + 0x10) - iVar3 >> 2) * 4)) &&
           (iVar2 = *(int64_t *)(iVar3 + -8), puVar5 = auStack_28, 0x1f < (iVar3 - iVar2) - 8U)) {
            iVar2 = 5;
            pcVar1 = (code *)swi(0x29);
            (*pcVar1)(5);
            puVar5 = auStack_20;
        }
        *(undefined8 *)(puVar5 + -8) = 0x1800308d6;
        fcn.180459c3c(iVar2);
        *(undefined8 *)arg1 = 0;
        *(undefined8 *)(arg1 + 8) = 0;
        *(undefined8 *)(arg1 + 0x10) = 0;
    }
    *(undefined8 *)(puVar5 + 0x30) = *(undefined8 *)(puVar5 + 0x30);
    *(undefined8 *)(puVar5 + 0x20) = *(undefined8 *)(puVar5 + 0x20);
    if (0x3fffffffffffffff < uVar4) {
code_r0x000180030b02:
        *(undefined8 *)(puVar5 + -8) = 0x180030b07;
        fcn.180004720();
        pcVar1 = (code *)swi(3);
        (*pcVar1)();
        return;
    }
    uVar4 = uVar4 * 4;
    if (uVar4 == 0) {
        uVar6 = 0;
    } else if (uVar4 < 0x1000) {
        *(undefined8 *)(puVar5 + -8) = 0x180030ae9;
        uVar6 = fcn.180459890(uVar4);
    } else {
        if (uVar4 + 0x27 <= uVar4) goto code_r0x000180030b02;
        *(undefined8 *)(puVar5 + -8) = 0x180030ac4;
        iVar2 = fcn.180459890();
        iVar3 = iVar2;
        if (iVar2 == 0) {
            iVar3 = 5;
            pcVar1 = (code *)swi(0x29);
            iVar2 = (*pcVar1)();
        }
        uVar6 = iVar2 + 0x27U & 0xffffffffffffffe0;
        *(int64_t *)(uVar6 - 8) = iVar3;
    }
    *(uint64_t *)arg1 = uVar6;
    *(uint64_t *)(arg1 + 8) = uVar6;
    *(uint64_t *)(arg1 + 0x10) = uVar6 + uVar4;
    return;
}

// ============================================================
// Function: FUN_180030b10
// Address: 0x180030b10
// Size: 161 bytes
// ============================================================
void fcn.180030b10(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t iVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t var_8h;
    
    *(undefined8 *)arg2 = *(undefined8 *)arg3;
    fcn.180030dc0(arg2 + 8, arg3 + 8);
    *(undefined8 *)(arg2 + 0x20) = *(undefined8 *)(arg3 + 0x20);
    *(undefined8 *)(arg2 + 0x28) = 0;
    *(undefined8 *)(arg2 + 0x30) = 0;
    *(undefined8 *)(arg2 + 0x38) = 0;
    uVar3 = *(int64_t *)(arg3 + 0x30) - *(int64_t *)(arg3 + 0x28) >> 4;
    if (uVar3 != 0) {
        if (0xfffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        fcn.1800307b0(arg2 + 0x28, uVar3);
        iVar1 = *(int64_t *)(arg2 + 0x28);
        uVar3 = *(int64_t *)(arg3 + 0x30) - *(int64_t *)(arg3 + 0x28);
        fcn.180498030(iVar1, *(int64_t *)(arg3 + 0x28), uVar3);
        *(uint64_t *)(arg2 + 0x30) = (uVar3 & 0xfffffffffffffff0) + iVar1;
    }
    return;
}

// ============================================================
// Function: FUN_180030bc0
// Address: 0x180030bc0
// Size: 17 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180030bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        puVar4 = (undefined8 *)(arg1 + 8);
        puVar5 = (undefined8 *)(arg1 + 0x28);
        do {
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            uVar1 = puVar4[2];
            arg1 = arg1 + 0x40;
            uVar2 = puVar4[1];
            uVar3 = *puVar4;
            puVar4[2] = 0;
            puVar4[1] = 0;
            *puVar4 = 0;
            *(undefined8 *)(arg3 + 8) = uVar3;
            *(undefined8 *)(arg3 + 0x10) = uVar2;
            *(undefined8 *)(arg3 + 0x18) = uVar1;
            uVar1 = puVar4[3];
            puVar4[3] = 0;
            *(undefined8 *)(arg3 + 0x20) = uVar1;
            uVar1 = puVar5[2];
            uVar2 = puVar5[1];
            uVar3 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x28) = uVar3;
            *(undefined8 *)(arg3 + 0x30) = uVar2;
            *(undefined8 *)(arg3 + 0x38) = uVar1;
            arg3 = arg3 + 0x40;
            puVar4 = puVar4 + 8;
            puVar5 = puVar5 + 8;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_180030bd1
// Address: 0x180030bd1
// Size: 131 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180030bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        puVar4 = (undefined8 *)(arg1 + 8);
        puVar5 = (undefined8 *)(arg1 + 0x28);
        do {
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            uVar1 = puVar4[2];
            arg1 = arg1 + 0x40;
            uVar2 = puVar4[1];
            uVar3 = *puVar4;
            puVar4[2] = 0;
            puVar4[1] = 0;
            *puVar4 = 0;
            *(undefined8 *)(arg3 + 8) = uVar3;
            *(undefined8 *)(arg3 + 0x10) = uVar2;
            *(undefined8 *)(arg3 + 0x18) = uVar1;
            uVar1 = puVar4[3];
            puVar4[3] = 0;
            *(undefined8 *)(arg3 + 0x20) = uVar1;
            uVar1 = puVar5[2];
            uVar2 = puVar5[1];
            uVar3 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x28) = uVar3;
            *(undefined8 *)(arg3 + 0x30) = uVar2;
            *(undefined8 *)(arg3 + 0x38) = uVar1;
            arg3 = arg3 + 0x40;
            puVar4 = puVar4 + 8;
            puVar5 = puVar5 + 8;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_180030c54
// Address: 0x180030c54
// Size: 5 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

undefined8 * fcn.180030bc0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    undefined8 uVar1;
    undefined8 uVar2;
    undefined8 uVar3;
    undefined8 *puVar4;
    undefined8 *puVar5;
    int64_t var_8h;
    int64_t var_18h;
    
    if (arg1 != arg2) {
        puVar4 = (undefined8 *)(arg1 + 8);
        puVar5 = (undefined8 *)(arg1 + 0x28);
        do {
            *(undefined8 *)arg3 = *(undefined8 *)arg1;
            uVar1 = puVar4[2];
            arg1 = arg1 + 0x40;
            uVar2 = puVar4[1];
            uVar3 = *puVar4;
            puVar4[2] = 0;
            puVar4[1] = 0;
            *puVar4 = 0;
            *(undefined8 *)(arg3 + 8) = uVar3;
            *(undefined8 *)(arg3 + 0x10) = uVar2;
            *(undefined8 *)(arg3 + 0x18) = uVar1;
            uVar1 = puVar4[3];
            puVar4[3] = 0;
            *(undefined8 *)(arg3 + 0x20) = uVar1;
            uVar1 = puVar5[2];
            uVar2 = puVar5[1];
            uVar3 = *puVar5;
            puVar5[2] = 0;
            puVar5[1] = 0;
            *puVar5 = 0;
            *(undefined8 *)(arg3 + 0x28) = uVar3;
            *(undefined8 *)(arg3 + 0x30) = uVar2;
            *(undefined8 *)(arg3 + 0x38) = uVar1;
            arg3 = arg3 + 0x40;
            puVar4 = puVar4 + 8;
            puVar5 = puVar5 + 8;
        } while (arg1 != arg2);
    }
    return (undefined8 *)arg3;
}

// ============================================================
// Function: FUN_180030c60
// Address: 0x180030c60
// Size: 43 bytes
// ============================================================
void fcn.180030c60(void)
{
    code *pcVar1;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    
    fcn.18045471c(0);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
}

// ============================================================
// Function: FUN_180030c90
// Address: 0x180030c90
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180030c90(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x40) {
        func_0x00018002a260(iVar6 + 0x28);
        func_0x00018002ee50(iVar6 + 8);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x40)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180030ca4
// Address: 0x180030ca4
// Size: 86 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180030c90(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x40) {
        func_0x00018002a260(iVar6 + 0x28);
        func_0x00018002ee50(iVar6 + 8);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x40)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180030cfa
// Address: 0x180030cfa
// Size: 57 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180030c90(int64_t arg1, int64_t arg_38h)
{
    code *pcVar1;
    int32_t iVar2;
    undefined4 uVar3;
    undefined4 *puVar4;
    int64_t iVar5;
    undefined8 unaff_RBX;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_8h;
    int64_t var_10h;
    undefined auStack_28 [8];
    undefined auStack_20 [24];
    
    puVar7 = auStack_28;
    if (*(int64_t *)(arg1 + 8) == 0) {
        return;
    }
    iVar5 = *(int64_t *)(arg1 + 0x20);
    for (iVar6 = *(int64_t *)(arg1 + 0x18); iVar6 != iVar5; iVar6 = iVar6 + 0x40) {
        func_0x00018002a260(iVar6 + 0x28);
        func_0x00018002ee50(iVar6 + 8);
    }
    iVar6 = *(int64_t *)(arg1 + 8);
    if (0xfff < (uint64_t)(*(int64_t *)(arg1 + 0x10) * 0x40)) {
        iVar5 = *(int64_t *)(iVar6 + -8);
        if ((iVar6 - iVar5) - 8U < 0x20) goto code_r0x0001800f4640;
        pcVar1 = (code *)swi(0x29);
        iVar6 = (*pcVar1)(5);
        puVar7 = auStack_20;
    }
    *(undefined **)0x20 = (BADSPACEBASE *)(puVar7 + 0x28);
    iVar5 = iVar6;
code_r0x0001800f4640:
    if (iVar5 != 0) {
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -8) = unaff_RBX;
        *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca3c;
        iVar2 = (*(code *)0x69af72)(*(undefined8 *)0x180781ea8, 0, iVar5);
        if (iVar2 == 0) {
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca46;
            uVar3 = (*(code *)0x699ff6)();
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca4d;
            uVar3 = fcn.18046b63c(uVar3);
            *(undefined8 *)((int64_t)*(undefined **)0x20 + -0x30) = 0x18047ca54;
            puVar4 = (undefined4 *)fcn.18046b77c();
            *puVar4 = uVar3;
        }
    }
    return;
}

// ============================================================
// Function: FUN_180030d40
// Address: 0x180030d40
// Size: 123 bytes
// ============================================================
void fcn.180030d40(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4)
{
    code *pcVar1;
    uint64_t uVar2;
    undefined *puVar3;
    uint64_t uVar4;
    undefined auStack_48 [8];
    undefined auStack_40 [32];
    
    uVar4 = *(uint64_t *)arg1;
    if (uVar4 != 0) {
        uVar2 = uVar4;
        puVar3 = auStack_48;
        if (0xfff < (uint64_t)(((int64_t)(*(int64_t *)(arg1 + 0x10) - uVar4) >> 2) * 4)) {
            uVar2 = *(uint64_t *)(uVar4 - 8);
            uVar4 = (uVar4 - uVar2) - 8;
            puVar3 = auStack_48;
            if (0x1f < uVar4) {
                pcVar1 = (code *)swi(0x29);
                uVar2 = uVar4;
                (*pcVar1)(5);
                puVar3 = auStack_40;
            }
        }
        *(undefined8 *)(puVar3 + -8) = 0x180030d9f;
        fcn.180459c3c(uVar2);
    }
    *(int64_t *)arg1 = arg2;
    *(int64_t *)(arg1 + 8) = arg2 + arg3 * 4;
    *(int64_t *)(arg1 + 0x10) = arg2 + arg4 * 4;
    return;
}

// ============================================================
// Function: FUN_180030dc0
// Address: 0x180030dc0
// Size: 60 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180030dc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    uVar3 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2 >> 2;
    if (uVar3 != 0) {
        if (0x3fffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.180030a80();
        iVar2 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2;
        fcn.180498030(iVar2, *(int64_t *)arg2, iVar4);
        *(int64_t *)(arg1 + 8) = iVar2 + (iVar4 >> 2) * 4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180030dfc
// Address: 0x180030dfc
// Size: 51 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180030dc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    uVar3 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2 >> 2;
    if (uVar3 != 0) {
        if (0x3fffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.180030a80();
        iVar2 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2;
        fcn.180498030(iVar2, *(int64_t *)arg2, iVar4);
        *(int64_t *)(arg1 + 8) = iVar2 + (iVar4 >> 2) * 4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180030e2f
// Address: 0x180030e2f
// Size: 20 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180030dc0(int64_t arg1, int64_t arg2)
{
    code *pcVar1;
    int64_t iVar2;
    uint64_t uVar3;
    int64_t iVar4;
    int64_t var_8h;
    int64_t var_10h;
    
    *(undefined8 *)arg1 = 0;
    *(undefined8 *)(arg1 + 8) = 0;
    *(undefined8 *)(arg1 + 0x10) = 0;
    uVar3 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2 >> 2;
    if (uVar3 != 0) {
        if (0x3fffffffffffffff < uVar3) {
            fcn.180010010();
            pcVar1 = (code *)swi(3);
            iVar2 = (*pcVar1)();
            return iVar2;
        }
        fcn.180030a80();
        iVar2 = *(int64_t *)arg1;
        iVar4 = *(int64_t *)(arg2 + 8) - *(int64_t *)arg2;
        fcn.180498030(iVar2, *(int64_t *)arg2, iVar4);
        *(int64_t *)(arg1 + 8) = iVar2 + (iVar4 >> 2) * 4;
    }
    return arg1;
}

// ============================================================
// Function: FUN_180030e50
// Address: 0x180030e50
// Size: 345 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180030e50(int64_t arg1, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined *puVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar6 = auStack_68;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x000180030f95;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar4 = *piVar5 + 0x18;
    if (iVar4 != 0) {
        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
        func_0x00018007ff90();
        var_48h = iVar4;
        var_40h = (uint64_t)uVar1;
        func_0x000180080600();
        piVar5 = &var_38h;
        if (0xf < (uint64_t)var_20h) {
            piVar5 = (int64_t *)var_38h;
        }
        func_0x0001800867f0(arg1, piVar5, var_28h);
        if (0xf < (uint64_t)var_20h) {
            iVar4 = var_38h;
            puVar6 = auStack_68;
            if ((0xfff < var_20h + 1U) &&
               (iVar4 = *(int64_t *)(var_38h + -8), puVar6 = auStack_68, 0x1f < (var_38h - iVar4) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar4 = (*pcVar2)(5);
                puVar6 = auStack_60;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180030f70;
            fcn.180459c3c(iVar4);
        }
        *(undefined8 *)(puVar6 + -8) = 0x180030f82;
        func_0x000180459870(*(uint64_t *)(puVar6 + 0x50) ^ (uint64_t)puVar6);
        return;
    }
code_r0x000180030f95:
    func_0x000180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180030fb0
// Address: 0x180030fb0
// Size: 345 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180030fb0(int64_t arg1, int64_t arg_38h)
{
    uint32_t uVar1;
    code *pcVar2;
    int32_t iVar3;
    int64_t iVar4;
    int64_t *piVar5;
    undefined *puVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined auStack_68 [8];
    undefined auStack_60 [24];
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    
    puVar6 = auStack_68;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_68;
    piVar5 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar5 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar5 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar3 = func_0x0001800a8360(arg1);
        if (iVar3 == 0) goto code_r0x0001800310f5;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar5 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar5 = *(int64_t **)0x180782430;
        }
    }
    iVar4 = *piVar5 + 0x18;
    if (iVar4 != 0) {
        uVar1 = *(uint32_t *)(*piVar5 + 0x14);
        func_0x00018007ff90();
        var_48h = iVar4;
        var_40h = (uint64_t)uVar1;
        func_0x000180080790();
        piVar5 = &var_38h;
        if (0xf < (uint64_t)var_20h) {
            piVar5 = (int64_t *)var_38h;
        }
        func_0x0001800867f0(arg1, piVar5, var_28h);
        if (0xf < (uint64_t)var_20h) {
            iVar4 = var_38h;
            puVar6 = auStack_68;
            if ((0xfff < var_20h + 1U) &&
               (iVar4 = *(int64_t *)(var_38h + -8), puVar6 = auStack_68, 0x1f < (var_38h - iVar4) - 8U)) {
                pcVar2 = (code *)swi(0x29);
                iVar4 = (*pcVar2)(5);
                puVar6 = auStack_60;
            }
            *(undefined8 *)(puVar6 + -8) = 0x1800310d0;
            fcn.180459c3c(iVar4);
        }
        *(undefined8 *)(puVar6 + -8) = 0x1800310e2;
        func_0x000180459870(*(uint64_t *)(puVar6 + 0x50) ^ (uint64_t)puVar6);
        return;
    }
code_r0x0001800310f5:
    func_0x000180088470(arg1, 1, 6);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180031110
// Address: 0x180031110
// Size: 2975 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ech

void fcn.180031110(int64_t arg1)
{
    uint32_t uVar1;
    code *pcVar2;
    undefined auVar3 [16];
    undefined auVar4 [16];
    bool bVar5;
    undefined auVar6 [16];
    undefined auVar7 [16];
    undefined auVar8 [15];
    int32_t iVar9;
    int64_t *piVar10;
    undefined (*pauVar11) [16];
    uint64_t uVar12;
    int64_t iVar13;
    int64_t iVar14;
    int64_t iVar15;
    int64_t *piVar16;
    int64_t *piVar17;
    uint64_t uVar18;
    undefined *puVar19;
    undefined *puVar20;
    undefined *puVar21;
    uint64_t uVar22;
    undefined8 uVar23;
    undefined8 uStack_190;
    undefined auStack_188 [8];
    undefined auStack_180 [24];
    int64_t var_168h;
    int64_t var_160h;
    int64_t var_158h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    undefined8 uStack_e8;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    puVar19 = auStack_188;
    puVar21 = auStack_188;
    var_50h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    piVar16 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar16 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar16 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar9 = func_0x0001800a8360(arg1);
        puVar20 = auStack_188;
        if (iVar9 == 0) goto code_r0x000180031c5d;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar16 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar16 = *(int64_t **)0x180782430;
        }
    }
    var_138h = *piVar16 + 0x18;
    puVar20 = auStack_188;
    if (var_138h == 0) goto code_r0x000180031c5d;
    uVar18 = (uint64_t)*(uint32_t *)(*piVar16 + 0x14);
    piVar16 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
        piVar16 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar16 + 0xc) == 6) {
code_r0x00018003123c:
        iVar14 = *piVar16 + 0x18;
        if (iVar14 == 0) goto code_r0x000180031c71;
        uVar1 = *(uint32_t *)(*piVar16 + 0x14);
        piVar17 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        piVar16 = *(int64_t **)(arg1 + 0x40);
        piVar10 = piVar17;
        if (piVar16 <= piVar17) {
            piVar10 = *(int64_t **)0x180782430;
        }
        var_118h = uVar18;
        if ((piVar10 == *(int64_t **)0x180782430) ||
           ((*(int32_t *)((int64_t)piVar10 + 0xc) != 6 && (*(int32_t *)((int64_t)piVar10 + 0xc) != 3)))) {
            bVar5 = true;
            iVar13 = 0;
            uVar18 = 0;
        } else {
            if (piVar16 <= piVar17) {
                piVar17 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar17 + 0xc) != 6) {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                iVar9 = func_0x0001800a8360(arg1);
                if (iVar9 == 0) {
                    uVar18 = 0;
                    iVar13 = 0;
                    piVar16 = *(int64_t **)(arg1 + 0x40);
                    bVar5 = false;
                    goto code_r0x00018003132a;
                }
                if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30))
                {
                    (**(code **)0x180782658)(arg1, 1);
                }
                piVar17 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
                piVar16 = *(int64_t **)(arg1 + 0x40);
                if (piVar16 <= piVar17) {
                    piVar17 = *(int64_t **)0x180782430;
                }
            }
            uVar18 = (uint64_t)*(uint32_t *)(*piVar17 + 0x14);
            iVar13 = *piVar17 + 0x18;
            bVar5 = false;
        }
code_r0x00018003132a:
        piVar17 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
        piVar10 = piVar17;
        if (piVar16 <= piVar17) {
            piVar10 = *(int64_t **)0x180782430;
        }
        if ((piVar10 != *(int64_t **)0x180782430) && (0 < *(int32_t *)((int64_t)piVar10 + 0xc))) {
            if (piVar16 <= piVar17) {
                piVar17 = *(int64_t **)0x180782430;
            }
            if (*(int32_t *)((int64_t)piVar17 + 0xc) == 6) {
code_r0x0001800313b2:
                var_128h = *piVar17 + 0x18;
                puVar20 = auStack_188;
                if (var_128h != 0) goto code_r0x0001800313d2;
            } else {
                if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
                    *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
                    *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
                    *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
                }
                iVar9 = func_0x0001800a8360(arg1);
                puVar20 = auStack_188;
                if (iVar9 != 0) {
                    if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <=
                        *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                        (**(code **)0x180782658)(arg1, 1);
                    }
                    piVar17 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
                    if (*(int64_t **)(arg1 + 0x40) <= piVar17) {
                        piVar17 = *(int64_t **)0x180782430;
                    }
                    goto code_r0x0001800313b2;
                }
            }
code_r0x000180031c43:
            *(undefined8 *)(puVar20 + -8) = 0x180031c56;
            func_0x000180088470(arg1, 4, 6);
            puVar21 = puVar20;
code_r0x000180031c57:
            *(undefined8 *)(puVar21 + -8) = 0x180031c5c;
            fcn.180004720();
            puVar20 = puVar21;
code_r0x000180031c5d:
            *(undefined8 *)(puVar20 + -8) = 0x180031c70;
            func_0x000180088470(arg1, 1, 6);
            pcVar2 = (code *)swi(3);
            (*pcVar2)();
            return;
        }
        var_128h = 0x18062220c;
code_r0x0001800313d2:
        uVar23 = func_0x00018007ff90();
        var_148h = iVar14;
        var_140h = (uint64_t)uVar1;
        func_0x000180080790(uVar23, &var_90h, &var_148h);
        if (var_80h != 0) {
            iVar14 = 0;
            var_100h = 0;
            var_f8h = 0xf;
            stack0xfffffffffffffef1 = SUB1615(ZEXT816(0), 1);
            auVar8 = stack0xfffffffffffffef1;
            auVar3[15] = 0;
            auVar3._0_15_ = stack0xfffffffffffffef1;
            _var_110h = auVar3 << 8;
            var_a0h = 0;
            uVar22 = 0xf;
            var_98h = 0xf;
            auVar4[15] = 0;
            auVar4._0_15_ = auVar8;
            _var_b0h = auVar4 << 8;
            uVar23 = func_0x00018007ff90();
            if (!bVar5) {
                var_148h = iVar13;
                var_140h = uVar18;
                pauVar11 = (undefined (*) [16])func_0x000180080790(uVar23, &var_f0h, &var_148h);
                if ((undefined (*) [16])&var_110h != pauVar11) {
                    if (0xf < (uint64_t)var_f8h) {
                        uVar22 = var_f8h + 1;
                        iVar14 = var_110h;
                        if (0xfff < uVar22) {
                            puVar20 = auStack_188;
                            if (0x1f < (var_110h - *(int64_t *)(var_110h + -8)) - 8U) goto code_r0x000180031b17;
                            uVar22 = var_f8h + 0x28;
                            iVar14 = *(int64_t *)(var_110h + -8);
                        }
                        fcn.180459c3c(iVar14, uVar22);
                    }
                    _var_110h = *pauVar11;
                    var_100h = *(int64_t *)pauVar11[1];
                    var_f8h = *(int64_t *)(pauVar11[1] + 8);
                    *(undefined8 *)pauVar11[1] = 0;
                    *(undefined8 *)(pauVar11[1] + 8) = 0xf;
                    (*pauVar11)[0] = 0;
                }
                if (0xf < (uint64_t)var_d8h) {
                    uVar22 = var_d8h + 1;
                    if (0xfff < uVar22) {
                        puVar20 = auStack_188;
                        if (0x1f < (var_f0h - *(int64_t *)(var_f0h + -8)) - 8U) goto code_r0x000180031b17;
                        uVar22 = var_d8h + 0x28;
                        var_f0h = *(int64_t *)(var_f0h + -8);
                    }
                    fcn.180459c3c(var_f0h, uVar22);
                }
                if (var_100h == 0) goto code_r0x000180031c9a;
                _var_f0h = ZEXT816(0);
                if (uVar18 < 0x10) {
                    var_d8h = 0xf;
                    var_e0h = uVar18;
                    fcn.180498030(&var_f0h, iVar13, uVar18);
                    *(undefined *)((int64_t)&var_f0h + uVar18) = 0;
code_r0x000180031778:
                    _var_b0h = _var_f0h;
                    var_a0h = var_e0h;
                    var_98h = var_d8h;
                    uVar22 = var_d8h;
                    iVar14 = var_e0h;
                    goto code_r0x00018003179b;
                }
                uVar22 = uVar18 | 0xf;
                if (0x7fffffffffffffff < uVar22) {
                    uVar12 = 0x8000000000000027;
                    uVar22 = 0x7fffffffffffffff;
code_r0x000180031708:
                    iVar14 = fcn.180459890(uVar12);
                    puVar20 = auStack_188;
                    if (iVar14 == 0) goto code_r0x000180031b17;
                    uVar12 = iVar14 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar12 - 8) = iVar14;
code_r0x00018003175a:
                    var_f0h = uVar12;
                    var_e0h = uVar18;
                    var_d8h = uVar22;
                    fcn.180498030(uVar12, iVar13, uVar18);
                    *(undefined *)(uVar12 + uVar18) = 0;
                    goto code_r0x000180031778;
                }
                if (uVar22 < 0x16) {
                    uVar22 = 0x16;
                }
                if (uVar22 + 1 < 0x1000) {
                    uVar12 = fcn.180459890();
                    goto code_r0x00018003175a;
                }
                uVar12 = uVar22 + 0x28;
                if (uVar22 + 1 < uVar12) goto code_r0x000180031708;
                goto code_r0x000180031c57;
            }
            pauVar11 = (undefined (*) [16])func_0x000180080960(uVar23, &var_f0h, 0x10);
            if ((undefined (*) [16])&var_110h != pauVar11) {
                if (0xf < (uint64_t)var_f8h) {
                    uVar18 = var_f8h + 1;
                    iVar13 = var_110h;
                    if (0xfff < uVar18) {
                        puVar20 = auStack_188;
                        if (0x1f < (var_110h - *(int64_t *)(var_110h + -8)) - 8U) goto code_r0x000180031b17;
                        uVar18 = var_f8h + 0x28;
                        iVar13 = *(int64_t *)(var_110h + -8);
                    }
                    fcn.180459c3c(iVar13, uVar18);
                }
                _var_110h = *pauVar11;
                var_100h = *(int64_t *)pauVar11[1];
                var_f8h = *(int64_t *)(pauVar11[1] + 8);
                *(undefined8 *)pauVar11[1] = 0;
                *(undefined8 *)(pauVar11[1] + 8) = 0xf;
                (*pauVar11)[0] = 0;
            }
            if ((uint64_t)var_d8h < 0x10) {
code_r0x000180031506:
                if (var_100h == 0) {
                    func_0x000180086510(arg1);
                    func_0x000180086510(arg1);
                    goto code_r0x000180031b77;
                }
                func_0x00018007ff90();
                var_148h = (int64_t)&var_110h;
                if (0xf < (uint64_t)var_f8h) {
                    var_148h = var_110h;
                }
                var_140h = var_100h;
                pauVar11 = (undefined (*) [16])func_0x000180080600(var_148h, &var_f0h, &var_148h);
                if ((undefined (*) [16])&var_b0h != pauVar11) {
                    _var_b0h = *pauVar11;
                    iVar14 = *(int64_t *)pauVar11[1];
                    uVar22 = *(uint64_t *)(pauVar11[1] + 8);
                    *(undefined8 *)pauVar11[1] = 0;
                    *(undefined8 *)(pauVar11[1] + 8) = 0xf;
                    (*pauVar11)[0] = 0;
                    var_a0h = iVar14;
                    var_98h = uVar22;
                }
                if (0xf < (uint64_t)var_d8h) {
                    if (var_d8h + 1U < 0x1000) {
                        fcn.180459c3c(var_f0h);
                    } else {
                        puVar20 = auStack_188;
                        if (0x1f < (var_f0h - *(int64_t *)(var_f0h + -8)) - 8U) goto code_r0x000180031b17;
                        fcn.180459c3c(*(int64_t *)(var_f0h + -8), var_d8h + 0x28);
                    }
                }
code_r0x00018003179b:
                func_0x00018007ff90();
                var_e0h = 4;
                var_d8h = 0xf;
                stack0xffffffffffffff15 = SUB1611(ZEXT816(0), 5);
                var_f0h._0_5_ = 0x2d736561;
                uVar23 = func_0x000180498cd0(var_128h);
                pauVar11 = (undefined (*) [16])func_0x00018000d970(&var_f0h, var_128h, uVar23);
                _var_70h = *pauVar11;
                var_60h = *(int64_t *)pauVar11[1];
                var_58h = *(int64_t *)(pauVar11[1] + 8);
                *(undefined8 *)pauVar11[1] = 0;
                *(undefined8 *)(pauVar11[1] + 8) = 0xf;
                (*pauVar11)[0] = 0;
                iVar13 = func_0x000180080a50();
                puVar19 = auStack_188;
                if (0xf < (uint64_t)var_58h) {
                    puVar19 = auStack_188;
                    iVar15 = var_70h;
                    if ((0xfff < var_58h + 1U) &&
                       (iVar15 = *(int64_t *)(var_70h + -8), puVar19 = auStack_188, 0x1f < (var_70h - iVar15) - 8U)) {
                        iVar15 = 5;
                        pcVar2 = (code *)swi(0x29);
                        (*pcVar2)(5);
                        puVar19 = auStack_180;
                    }
                    *(undefined8 *)(puVar19 + -8) = 0x18003185b;
                    fcn.180459c3c(iVar15);
                }
                var_60h = 0;
                var_58h = 0xf;
                auVar6[15] = 0;
                auVar6._0_15_ = stack0xffffffffffffff91;
                _var_70h = auVar6 << 8;
                puVar20 = puVar19;
                if (0xf < (uint64_t)var_d8h) {
                    uVar18 = var_d8h + 1;
                    iVar15 = var_f0h;
                    if (0xfff < uVar18) {
                        if (0x1f < (var_f0h - *(int64_t *)(var_f0h + -8)) - 8U) goto code_r0x000180031b17;
                        uVar18 = var_d8h + 0x28;
                        iVar15 = *(int64_t *)(var_f0h + -8);
                    }
                    *(undefined8 *)(puVar19 + -8) = 0x1800318a8;
                    fcn.180459c3c(iVar15, uVar18);
                }
                var_e0h = 0;
                var_d8h = 0xf;
                auVar7[15] = 0;
                auVar7._0_15_ = stack0xffffffffffffff11;
                _var_f0h = auVar7 << 8;
                if (iVar13 == 0) {
                    *(undefined8 *)(puVar19 + -8) = 0x180031c42;
                    func_0x000180088380(arg1, 4, 0x180622248);
                    goto code_r0x000180031c43;
                }
                *(undefined8 *)(puVar19 + -8) = 0x1800318c6;
                func_0x00018007ff90();
                puVar21 = puVar19 + 0x78;
                if (0xf < (uint64_t)var_f8h) {
                    puVar21 = *(undefined **)(puVar19 + 0x78);
                }
                piVar16 = &var_90h;
                if (0xf < (uint64_t)var_78h) {
                    piVar16 = (int64_t *)var_90h;
                }
                *(undefined **)(puVar19 + 0x40) = puVar21;
                *(int64_t *)(puVar19 + 0x48) = var_100h;
                *(int64_t **)(puVar19 + 0x60) = piVar16;
                *(int64_t *)(puVar19 + 0x68) = var_80h;
                *(undefined8 *)(puVar19 + 0x50) = *(undefined8 *)(puVar19 + 0x50);
                *(undefined8 *)(puVar19 + 0x58) = *(undefined8 *)(puVar19 + 0x70);
                *(undefined4 *)(puVar19 + 0x30) = 1;
                *(int64_t *)(puVar19 + 0x28) = iVar13;
                *(undefined **)(puVar19 + 0x20) = puVar19 + 0x40;
                *(undefined8 *)(puVar19 + -8) = 0x18003193e;
                func_0x000180080150(piVar16, &var_d0h, puVar19 + 0x50, puVar19 + 0x60);
                if (var_c0h != 0) {
                    *(undefined8 *)(puVar19 + -8) = 0x1800319ea;
                    func_0x00018007ff90();
                    piVar16 = &var_d0h;
                    if (0xf < (uint64_t)var_b8h) {
                        piVar16 = (int64_t *)CONCAT71(var_d0h._1_7_, (undefined)var_d0h);
                    }
                    *(int64_t **)(puVar19 + 0x40) = piVar16;
                    *(int64_t *)(puVar19 + 0x48) = var_c0h;
                    *(undefined8 *)(puVar19 + -8) = 0x180031a14;
                    func_0x000180080600(piVar16, &var_f0h, puVar19 + 0x40);
                    if (var_e0h == 0) {
                        *(undefined8 *)(puVar19 + -8) = 0x180031a26;
                        func_0x000180086510();
                        *(undefined8 *)(puVar19 + -8) = 0x180031a2e;
                        func_0x000180086510(arg1);
                        if (0xf < (uint64_t)var_d8h) {
                            if (var_d8h + 1U < 0x1000) {
                                *(undefined8 *)(puVar19 + -8) = 0x180031a74;
                                fcn.180459c3c(var_f0h);
                            } else {
                                iVar14 = *(int64_t *)(var_f0h + -8);
                                if (0x1f < (var_f0h - iVar14) - 8U) goto code_r0x000180031ad6;
                                *(undefined8 *)(puVar19 + -8) = 0x180031a67;
                                fcn.180459c3c(iVar14, var_d8h + 0x28);
                            }
                        }
                        goto code_r0x00018003195b;
                    }
                    piVar16 = &var_f0h;
                    if (0xf < (uint64_t)var_d8h) {
                        piVar16 = (int64_t *)var_f0h;
                    }
                    *(undefined8 *)(puVar19 + -8) = 0x180031a8c;
                    func_0x0001800867f0(arg1, piVar16);
                    piVar16 = &var_b0h;
                    if (0xf < uVar22) {
                        piVar16 = (int64_t *)var_b0h;
                    }
                    *(undefined8 *)(puVar19 + -8) = 0x180031aa4;
                    func_0x0001800867f0(arg1, piVar16, iVar14);
                    if (0xf < (uint64_t)var_d8h) {
                        iVar14 = var_f0h;
                        if ((0xfff < var_d8h + 1U) &&
                           (iVar14 = *(int64_t *)(var_f0h + -8), 0x1f < (var_f0h - iVar14) - 8U)) {
code_r0x000180031ad6:
                            pcVar2 = (code *)swi(0x29);
                            iVar14 = (*pcVar2)(5);
                            puVar19 = puVar19 + 8;
                        }
                        *(undefined8 *)(puVar19 + -8) = 0x180031ae5;
                        fcn.180459c3c(iVar14);
                    }
                    if (0xf < (uint64_t)var_b8h) {
                        iVar14 = CONCAT71(var_d0h._1_7_, (undefined)var_d0h);
                        if ((0xfff < var_b8h + 1U) &&
                           (iVar13 = iVar14 - *(int64_t *)(iVar14 + -8), iVar14 = *(int64_t *)(iVar14 + -8),
                           puVar20 = puVar19, 0x1f < iVar13 - 8U)) goto code_r0x000180031b17;
                        goto code_r0x000180031b21;
                    }
                    goto code_r0x000180031b26;
                }
                *(undefined8 *)(puVar19 + -8) = 0x180031952;
                func_0x000180086510(arg1);
                *(undefined8 *)(puVar19 + -8) = 0x18003195a;
                func_0x000180086510(arg1);
code_r0x00018003195b:
                if (0xf < (uint64_t)var_b8h) {
                    iVar14 = CONCAT71(var_d0h._1_7_, (undefined)var_d0h);
                    uVar18 = var_b8h + 1;
                    if (0xfff < uVar18) {
                        if (0x1f < (iVar14 - *(int64_t *)(iVar14 + -8)) - 8U) goto code_r0x000180031b17;
                        uVar18 = var_b8h + 0x28;
                        iVar14 = *(int64_t *)(iVar14 + -8);
                    }
                    *(undefined8 *)(puVar19 + -8) = 0x180031998;
                    fcn.180459c3c(iVar14, uVar18);
                }
                var_c0h = 0;
                var_b8h = 0xf;
                var_d0h._0_1_ = 0;
                if (uVar22 < 0x10) goto code_r0x000180031b77;
                iVar14 = var_b0h;
                if (0xfff < uVar22 + 1) {
                    iVar14 = *(int64_t *)(var_b0h + -8);
                    iVar13 = var_b0h - iVar14;
                    goto joined_r0x0001800319d6;
                }
            } else {
                uVar18 = var_d8h + 1;
                iVar13 = var_f0h;
                if (uVar18 < 0x1000) {
code_r0x000180031501:
                    fcn.180459c3c(iVar13, uVar18);
                    goto code_r0x000180031506;
                }
                puVar20 = auStack_188;
                if ((var_f0h - *(int64_t *)(var_f0h + -8)) - 8U < 0x20) {
                    uVar18 = var_d8h + 0x28;
                    iVar13 = *(int64_t *)(var_f0h + -8);
                    goto code_r0x000180031501;
                }
code_r0x000180031b17:
                pcVar2 = (code *)swi(0x29);
                iVar14 = (*pcVar2)(5);
                puVar19 = puVar20 + 8;
code_r0x000180031b21:
                *(undefined8 *)(puVar19 + -8) = 0x180031b26;
                fcn.180459c3c(iVar14);
code_r0x000180031b26:
                var_c0h = 0;
                var_b8h = 0xf;
                var_d0h._0_1_ = 0;
                if ((uint64_t)var_98h < 0x10) goto code_r0x000180031b77;
                iVar14 = var_b0h;
                if (0xfff < var_98h + 1U) {
                    iVar14 = *(int64_t *)(var_b0h + -8);
                    iVar13 = var_b0h - iVar14;
joined_r0x0001800319d6:
                    var_d0h._0_1_ = 0;
                    var_b8h = 0xf;
                    var_c0h = 0;
                    if (0x1f < iVar13 - 8U) {
                        var_b8h = 0xf;
                        var_c0h = 0;
                        var_d0h._0_1_ = 0;
                        pcVar2 = (code *)swi(0x29);
                        iVar14 = (*pcVar2)(5);
                        puVar19 = puVar19 + 8;
                    }
                }
            }
            *(undefined8 *)(puVar19 + -8) = 0x180031b76;
            fcn.180459c3c(iVar14);
code_r0x000180031b77:
            if (0xf < (uint64_t)var_f8h) {
                iVar14 = *(int64_t *)(puVar19 + 0x78);
                iVar13 = iVar14;
                if ((0xfff < var_f8h + 1U) && (iVar13 = *(int64_t *)(iVar14 + -8), 0x1f < (iVar14 - iVar13) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar13 = (*pcVar2)(5);
                    puVar19 = puVar19 + 8;
                }
                *(undefined8 *)(puVar19 + -8) = 0x180031bb8;
                fcn.180459c3c(iVar13);
            }
            var_100h = 0;
            var_f8h = 0xf;
            puVar19[0x78] = 0;
            if (0xf < (uint64_t)var_78h) {
                iVar14 = var_90h;
                if ((0xfff < var_78h + 1U) && (iVar14 = *(int64_t *)(var_90h + -8), 0x1f < (var_90h - iVar14) - 8U)) {
                    pcVar2 = (code *)swi(0x29);
                    iVar14 = (*pcVar2)(5);
                    puVar19 = puVar19 + 8;
                }
                *(undefined8 *)(puVar19 + -8) = 0x180031c09;
                fcn.180459c3c(iVar14);
            }
            *(undefined8 *)(puVar19 + -8) = 0x180031c1a;
            func_0x000180459870(var_50h ^ (uint64_t)puVar19);
            return;
        }
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar9 = func_0x0001800a8360(arg1);
        if (iVar9 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar16 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
            if (*(int64_t **)(arg1 + 0x40) <= piVar16) {
                piVar16 = *(int64_t **)0x180782430;
            }
            goto code_r0x00018003123c;
        }
code_r0x000180031c71:
        func_0x000180088470(arg1, 2, 6);
    }
    func_0x000180088380(arg1, 2, 0x1806221f8);
code_r0x000180031c9a:
    func_0x000180088380(arg1, 3, 0x180622218);
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_180031cb0
// Address: 0x180031cb0
// Size: 1650 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.180031cb0(int64_t arg1)
{
    int64_t iVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    code *pcVar4;
    undefined auVar5 [16];
    undefined auVar6 [16];
    int32_t iVar7;
    undefined8 uVar8;
    undefined (*pauVar9) [16];
    int64_t iVar10;
    int64_t iVar11;
    int64_t *piVar12;
    int64_t *piVar13;
    uint64_t uVar14;
    undefined *puVar15;
    int64_t iVar16;
    int64_t *piVar17;
    undefined4 uVar18;
    undefined8 uStack_1a0;
    undefined auStack_198 [8];
    undefined auStack_190 [24];
    int64_t var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_198;
    piVar13 = *(int64_t **)(arg1 + 0x28);
    if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        puVar15 = auStack_198;
        if (iVar7 == 0) goto code_r0x000180032293;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = *(int64_t **)(arg1 + 0x28);
        if (*(int64_t **)(arg1 + 0x40) <= *(int64_t **)(arg1 + 0x28)) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    iVar10 = *piVar13 + 0x18;
    puVar15 = auStack_198;
    if (iVar10 == 0) goto code_r0x000180032293;
    var_158h._0_4_ = *(uint32_t *)(*piVar13 + 0x14);
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800322a7;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x10);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    iVar11 = *piVar13 + 0x18;
    if (iVar11 == 0) {
code_r0x0001800322a7:
        func_0x000180088470(arg1, 2, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar2 = *(uint32_t *)(*piVar13 + 0x14);
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) != 6) {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 == 0) goto code_r0x0001800322bb;
        if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
            (**(code **)0x180782658)(arg1, 1);
        }
        piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x20);
        if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
            piVar13 = *(int64_t **)0x180782430;
        }
    }
    iVar1 = *piVar13 + 0x18;
    if (iVar1 == 0) {
code_r0x0001800322bb:
        func_0x000180088470(arg1, 3, 6);
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar3 = *(uint32_t *)(*piVar13 + 0x14);
    piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
    if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
        piVar13 = *(int64_t **)0x180782430;
    }
    if (*(int32_t *)((int64_t)piVar13 + 0xc) == 6) {
code_r0x000180031ee1:
        iVar16 = *piVar13 + 0x18;
        if (iVar16 == 0) goto code_r0x0001800322cf;
        uVar18 = func_0x00018007ff90();
        var_148h = iVar11;
        var_140h = (uint64_t)uVar2;
        func_0x000180080790(uVar18, &var_98h, &var_148h);
        if (var_88h == 0) goto code_r0x0001800322e3;
        uVar18 = func_0x00018007ff90();
        var_148h = iVar1;
        var_140h = (uint64_t)uVar3;
        func_0x000180080790(uVar18, &var_f8h, &var_148h);
        if (var_e8h != 0) {
            uVar18 = func_0x00018007ff90();
            var_140h = (int64_t)(uint32_t)var_158h;
            var_148h = iVar10;
            func_0x000180080790(uVar18, &var_118h, &var_148h);
            if (var_108h == 0) goto code_r0x00018003230d;
            func_0x00018007ff90();
            var_a8h = 4;
            var_a0h = 0xf;
            stack0xffffffffffffff4d = SUB1611(ZEXT816(0), 5);
            var_b8h._0_5_ = 0x2d736561;
            uVar8 = func_0x000180498cd0(iVar16);
            pauVar9 = (undefined (*) [16])func_0x00018000d970(&var_b8h, iVar16, uVar8);
            uVar18 = *(undefined4 *)*pauVar9;
            _var_d8h = *pauVar9;
            var_c8h = *(int64_t *)pauVar9[1];
            var_c0h = *(int64_t *)(pauVar9[1] + 8);
            *(undefined8 *)pauVar9[1] = 0;
            *(undefined8 *)(pauVar9[1] + 8) = 0xf;
            (*pauVar9)[0] = 0;
            iVar10 = func_0x000180080a50(uVar18, &var_d8h);
            puVar15 = auStack_198;
            if (0xf < (uint64_t)var_c0h) {
                puVar15 = auStack_198;
                iVar11 = var_d8h;
                if ((0xfff < var_c0h + 1U) &&
                   (iVar11 = *(int64_t *)(var_d8h + -8), puVar15 = auStack_198, 0x1f < (var_d8h - iVar11) - 8U)) {
                    iVar11 = 5;
                    pcVar4 = (code *)swi(0x29);
                    (*pcVar4)(5);
                    puVar15 = auStack_190;
                }
                *(undefined8 *)(puVar15 + -8) = 0x18003202b;
                fcn.180459c3c(iVar11);
            }
            var_c8h = 0;
            var_c0h = 0xf;
            auVar5[15] = 0;
            auVar5._0_15_ = stack0xffffffffffffff29;
            _var_d8h = auVar5 << 8;
            if ((uint64_t)var_a0h < 0x10) {
code_r0x000180032078:
                var_a8h = 0;
                var_a0h = 0xf;
                auVar6[15] = 0;
                auVar6._0_15_ = stack0xffffffffffffff49;
                _var_b8h = auVar6 << 8;
                if (iVar10 == 0) {
                    *(undefined8 *)(puVar15 + -8) = 0x180032292;
                    func_0x000180088380(arg1, 4, 0x180622248);
code_r0x000180032293:
                    *(undefined8 *)(puVar15 + -8) = 0x1800322a6;
                    func_0x000180088470(arg1, 1, 6);
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                *(undefined8 *)(puVar15 + -8) = 0x180032096;
                func_0x00018007ff90();
                piVar13 = &var_f8h;
                if (0xf < (uint64_t)var_e0h) {
                    piVar13 = (int64_t *)CONCAT71(var_f8h._1_7_, (undefined)var_f8h);
                }
                piVar17 = &var_98h;
                if (0xf < (uint64_t)var_80h) {
                    piVar17 = (int64_t *)var_98h;
                }
                piVar12 = &var_118h;
                if (0xf < (uint64_t)var_100h) {
                    piVar12 = (int64_t *)CONCAT71(var_118h._1_7_, (undefined)var_118h);
                }
                *(int64_t **)(puVar15 + 0x50) = piVar13;
                *(int64_t *)(puVar15 + 0x58) = var_e8h;
                *(int64_t **)(puVar15 + 0x60) = piVar17;
                *(int64_t *)(puVar15 + 0x68) = var_88h;
                *(int64_t **)(puVar15 + 0x70) = piVar12;
                *(int64_t *)(puVar15 + 0x78) = var_108h;
                *(undefined4 *)(puVar15 + 0x30) = 0;
                *(int64_t *)(puVar15 + 0x28) = iVar10;
                *(undefined **)(puVar15 + 0x20) = puVar15 + 0x50;
                *(undefined8 *)(puVar15 + -8) = 0x180032110;
                func_0x000180080150(piVar12, &var_78h, puVar15 + 0x70, puVar15 + 0x60);
                if (var_68h == 0) {
                    *(undefined8 *)(puVar15 + -8) = 0x180032122;
                    func_0x000180086510();
                } else {
                    piVar13 = &var_78h;
                    if (0xf < (uint64_t)var_60h) {
                        piVar13 = (int64_t *)var_78h;
                    }
                    *(undefined8 *)(puVar15 + -8) = 0x180032137;
                    func_0x0001800867f0(arg1, piVar13);
                }
                if ((uint64_t)var_60h < 0x10) goto code_r0x000180032179;
                if ((0xfff < var_60h + 1U) &&
                   (iVar10 = var_78h - *(int64_t *)(var_78h + -8), var_78h = *(int64_t *)(var_78h + -8),
                   0x1f < iVar10 - 8U)) goto code_r0x000180032169;
            } else {
                uVar14 = var_a0h + 1;
                iVar11 = var_b8h;
                if (uVar14 < 0x1000) {
code_r0x000180032073:
                    *(undefined8 *)(puVar15 + -8) = 0x180032078;
                    fcn.180459c3c(iVar11, uVar14);
                    goto code_r0x000180032078;
                }
                if ((var_b8h - *(int64_t *)(var_b8h + -8)) - 8U < 0x20) {
                    uVar14 = var_a0h + 0x28;
                    iVar11 = *(int64_t *)(var_b8h + -8);
                    goto code_r0x000180032073;
                }
code_r0x000180032169:
                pcVar4 = (code *)swi(0x29);
                var_78h = (*pcVar4)(5);
                puVar15 = puVar15 + 8;
            }
            *(undefined8 *)(puVar15 + -8) = 0x180032178;
            fcn.180459c3c(var_78h);
code_r0x000180032179:
            if (0xf < (uint64_t)var_100h) {
                iVar11 = CONCAT71(var_118h._1_7_, (undefined)var_118h);
                iVar10 = iVar11;
                if ((0xfff < var_100h + 1U) && (iVar10 = *(int64_t *)(iVar11 + -8), 0x1f < (iVar11 - iVar10) - 8U)) {
                    pcVar4 = (code *)swi(0x29);
                    iVar10 = (*pcVar4)(5);
                    puVar15 = puVar15 + 8;
                }
                *(undefined8 *)(puVar15 + -8) = 0x1800321b9;
                fcn.180459c3c(iVar10);
            }
            var_108h = 0;
            var_100h = 0xf;
            var_118h._0_1_ = 0;
            if (0xf < (uint64_t)var_e0h) {
                iVar11 = CONCAT71(var_f8h._1_7_, (undefined)var_f8h);
                iVar10 = iVar11;
                if ((0xfff < var_e0h + 1U) && (iVar10 = *(int64_t *)(iVar11 + -8), 0x1f < (iVar11 - iVar10) - 8U)) {
                    pcVar4 = (code *)swi(0x29);
                    iVar10 = (*pcVar4)(5);
                    puVar15 = puVar15 + 8;
                }
                *(undefined8 *)(puVar15 + -8) = 0x180032209;
                fcn.180459c3c(iVar10);
            }
            var_e8h = 0;
            var_e0h = 0xf;
            var_f8h._0_1_ = 0;
            if (0xf < (uint64_t)var_80h) {
                iVar10 = var_98h;
                if ((0xfff < var_80h + 1U) && (iVar10 = *(int64_t *)(var_98h + -8), 0x1f < (var_98h - iVar10) - 8U)) {
                    pcVar4 = (code *)swi(0x29);
                    iVar10 = (*pcVar4)(5);
                    puVar15 = puVar15 + 8;
                }
                *(undefined8 *)(puVar15 + -8) = 0x180032259;
                fcn.180459c3c(iVar10);
            }
            *(undefined8 *)(puVar15 + -8) = 0x18003226a;
            func_0x000180459870(var_58h ^ (uint64_t)puVar15);
            return;
        }
    } else {
        if ((*(uint8_t *)(arg1 + 1) & 4) != 0) {
            *(uint8_t *)(arg1 + 1) = *(uint8_t *)(arg1 + 1) & 0xfb;
            *(undefined8 *)(arg1 + 0x48) = *(undefined8 *)(*(int64_t *)(arg1 + 0x20) + 0x18);
            *(int64_t *)(*(int64_t *)(arg1 + 0x20) + 0x18) = arg1;
        }
        iVar7 = func_0x0001800a8360(arg1);
        if (iVar7 != 0) {
            if (*(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x28) <= *(uint64_t *)(*(int64_t *)(arg1 + 0x20) + 0x30)) {
                (**(code **)0x180782658)(arg1, 1);
            }
            piVar13 = (int64_t *)(*(int64_t *)(arg1 + 0x28) + 0x30);
            if (*(int64_t **)(arg1 + 0x40) <= piVar13) {
                piVar13 = *(int64_t **)0x180782430;
            }
            goto code_r0x000180031ee1;
        }
code_r0x0001800322cf:
        func_0x000180088470(arg1, 4, 6);
code_r0x0001800322e3:
        func_0x000180088380(arg1, 2, 0x1806221f8);
    }
    func_0x000180088380(arg1, 3, 0x180622218);
code_r0x00018003230d:
    func_0x000180088380(arg1, 1, 0x180622230);
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_180032330
// Address: 0x180032330
// Size: 441 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180032330(int64_t arg1)
{
    code *pcVar1;
    int32_t iVar2;
    int64_t iVar3;
    uint64_t uVar4;
    int64_t *piVar5;
    undefined *puVar6;
    int64_t var_10h;
    int64_t var_18h;
    undefined8 uStack_90;
    undefined auStack_88 [8];
    undefined auStack_80 [24];
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_20h;
    uint64_t uStack_18;
    int64_t var_8h;
    
    puVar6 = auStack_88;
    uStack_18 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_88;
    uVar4 = *(uint64_t *)(arg1 + 0x28);
    if (*(uint64_t *)(arg1 + 0x40) <= *(uint64_t *)(arg1 + 0x28)) {
        uVar4 = *(uint64_t *)0x180782430;
    }
    if ((uVar4 != *(uint64_t *)0x180782430) && (0 < *(int32_t *)(uVar4 + 0xc))) {
        iVar2 = func_0x000180088860(arg1, 1);
        if (iVar2 < 0) {
            func_0x000180088380(arg1, 1, 0x180622280);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
        if (0x400 < iVar2) {
            func_0x000180088380(arg1, 1, 0x180622260);
            pcVar1 = (code *)swi(3);
            (*pcVar1)();
            return;
        }
    }
    func_0x00018007ff90();
    func_0x000180080960();
    if (var_48h == 0) {
        func_0x000180086510(arg1);
        puVar6 = auStack_88;
    } else {
        func_0x00018007ff90();
        var_68h = (int64_t)&var_58h;
        if (0xf < (uint64_t)var_40h) {
            var_68h = var_58h;
        }
        var_60h = var_48h;
        func_0x000180080600(var_68h, &var_38h, &var_68h);
        if (var_28h == 0) {
            func_0x000180086510();
        } else {
            piVar5 = &var_38h;
            if (0xf < (uint64_t)var_20h) {
                piVar5 = (int64_t *)var_38h;
            }
            func_0x0001800867f0(arg1, piVar5);
        }
        if (0xf < (uint64_t)var_20h) {
            iVar3 = var_38h;
            puVar6 = auStack_88;
            if ((0xfff < var_20h + 1U) &&
               (iVar3 = *(int64_t *)(var_38h + -8), puVar6 = auStack_88, 0x1f < (var_38h - iVar3) - 8U)) {
                pcVar1 = (code *)swi(0x29);
                iVar3 = (*pcVar1)(5);
                puVar6 = auStack_80;
            }
            *(undefined8 *)(puVar6 + -8) = 0x180032458;
            fcn.180459c3c(iVar3);
        }
    }
    if (0xf < (uint64_t)var_40h) {
        iVar3 = var_58h;
        if ((0xfff < var_40h + 1U) && (iVar3 = *(int64_t *)(var_58h + -8), 0x1f < (var_58h - iVar3) - 8U)) {
            pcVar1 = (code *)swi(0x29);
            iVar3 = (*pcVar1)(5);
            puVar6 = puVar6 + 8;
        }
        *(undefined8 *)(puVar6 + -8) = 0x180032499;
        fcn.180459c3c(iVar3);
    }
    *(undefined8 *)(puVar6 + -8) = 0x1800324aa;
    func_0x000180459870(uStack_18 ^ (uint64_t)puVar6);
    return;
}

