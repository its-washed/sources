// Chunk 99 - 50 functions

// ============================================================
// Function: FUN_180150850
// Address: 0x180150850
// Size: 13736 bytes
// ============================================================
void fcn.180150850(int64_t arg1, undefined8 placeholder_1, int64_t arg3, undefined8 placeholder_3, int64_t arg_28h,
                  undefined8 placeholder_5, undefined8 placeholder_6, int64_t arg_40h, undefined8 placeholder_8,
                  int64_t arg_50h, int64_t arg_70h)
{
    undefined uVar1;
    int32_t iVar2;
    uint32_t uVar3;
    undefined4 uVar4;
    int64_t iVar5;
    int16_t *piVar6;
    code *pcVar7;
    undefined4 uVar8;
    char cVar9;
    char cVar10;
    undefined uVar11;
    int16_t iVar12;
    int16_t iVar13;
    int32_t iVar14;
    int32_t iVar15;
    undefined4 uVar16;
    float *pfVar17;
    int64_t iVar18;
    undefined8 uVar19;
    uint64_t *puVar20;
    undefined8 *puVar21;
    undefined4 *puVar22;
    int64_t **ppiVar23;
    int32_t *piVar24;
    int32_t iVar25;
    uint64_t uVar26;
    int64_t *piVar27;
    int16_t *piVar28;
    undefined8 *****pppppuVar29;
    uint64_t uVar30;
    int64_t iVar31;
    int32_t **ppiVar32;
    int32_t *piVar33;
    uint64_t uVar34;
    uint32_t uVar35;
    uint64_t *puVar36;
    undefined8 *puVar37;
    undefined8 *puVar38;
    int32_t *piVar39;
    undefined *puVar40;
    undefined *puVar41;
    uint32_t uVar42;
    undefined8 *puVar43;
    uint32_t uVar44;
    uint64_t *puVar45;
    int32_t *piVar46;
    int32_t **ppiVar47;
    undefined8 uVar48;
    int32_t iVar49;
    int64_t **ppiVar50;
    char *pcVar51;
    int16_t **ppiVar53;
    uint64_t uVar54;
    uint64_t uVar55;
    int32_t **ppiVar56;
    bool bVar57;
    bool bVar58;
    bool bVar59;
    float fVar60;
    float fVar61;
    double dVar62;
    float fVar63;
    float fVar64;
    float fVar65;
    float fVar66;
    float fVar67;
    float fVar68;
    int64_t var_4h;
    int64_t var_ch;
    int64_t var_20h;
    undefined auStack_268 [8];
    undefined auStack_260 [24];
    int64_t var_248h;
    int64_t var_240h;
    int64_t var_238h;
    int64_t var_230h;
    int64_t var_228h;
    int64_t var_220h;
    int64_t var_218h;
    int64_t var_210h;
    int64_t var_200h;
    int64_t var_1f8h;
    int64_t var_1f0h;
    undefined8 uStack_1e8;
    undefined8 uStack_1d8;
    undefined8 uStack_1d0;
    undefined auStack_1c8 [8];
    int32_t *piStack_1c0;
    undefined8 uStack_1b8;
    undefined8 uStack_1b0;
    undefined8 uStack_1a8;
    float fStack_1a0;
    float fStack_19c;
    undefined auStack_198 [8];
    uint64_t *puStack_190;
    undefined8 uStack_188;
    int64_t *piStack_180;
    undefined8 uStack_178;
    int32_t **ppiStack_170;
    undefined8 uStack_168;
    int32_t *piStack_160;
    undefined4 uStack_158;
    int32_t *piStack_150;
    int32_t *piStack_148;
    undefined8 *****apppppuStack_140 [3];
    uint64_t uStack_128;
    undefined auStack_118 [12];
    undefined4 uStack_10c;
    char acStack_105 [13];
    uint64_t uStack_f8;
    int64_t var_80h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_18h;
    int64_t var_10h;
    int64_t var_8h;
    char *pcVar52;
    
    puVar40 = auStack_268;
    uStack_f8 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_268;
    piStack_148 = *(int32_t **)(arg1 + 0x108);
    ppiStack_170 = (int32_t **)arg1;
    if (*(float *)(arg1 + 0x5e0) != *(float *)(*(uint64_t *)0x180781f28 + 0xd9c)) {
        func_0x00018015be20(arg1);
    }
    uVar55 = *(uint64_t *)0x180781f28;
    *(undefined8 *)(arg1 + 0x270) = *(undefined8 *)(*(uint64_t *)0x180781f28 + 0x12e8);
    *(undefined4 *)(arg1 + 0x278) = *(undefined4 *)(uVar55 + 0x12f8);
    fVar63 = *(float *)(uVar55 + 0x12f8);
    fVar61 = *(float *)(uVar55 + 0xdf0);
    fVar65 = *(float *)(arg1 + 0x260);
    var_248h._0_4_ = 0xbf800000;
    pfVar17 = (float *)func_0x0001800fe0a0(&piStack_1c0, 0x180641950, 0, 0);
    fVar66 = *pfVar17;
    *(float *)(arg1 + 0x27c) = fVar66;
    *(float *)(arg1 + 0x280) = (fVar63 + fVar61) * fVar65;
    *(float *)(arg1 + 0x28c) = fVar66;
    piVar27 = (int64_t *)(arg1 + 0x40);
    fVar63 = fVar66;
    fVar61 = fVar66;
    piStack_180 = piVar27;
    if (*(char *)(arg1 + 0x268) != '\0') {
        iVar14 = func_0x00018014fb20(piVar27);
        dVar62 = (double)func_0x00018048d7c0((double)(iVar14 + 1));
        fVar63 = (float)(int32_t)(dVar62 + 1.0) * fVar66 + fVar66;
        fVar61 = fVar63 + fVar66;
    }
    *(float *)(arg1 + 0x290) = fVar63;
    *(float *)(arg1 + 0x294) = fVar61;
    fVar63 = *(float *)(arg1 + 0x2d8);
    if (fVar63 <= 0.0) {
        if (0.0 <= fVar63) {
            fVar63 = fVar66 + fVar66;
        } else {
            fVar63 = (1.0 - fVar63) * fVar66;
        }
        fVar63 = fVar63 + fVar61;
    } else {
        fVar63 = fVar61 + fVar63 + fVar66;
    }
    *(float *)(arg1 + 0x298) = fVar63;
    uVar55 = *(uint64_t *)0x180781f28;
    uStack_188 = (int64_t *)
                 CONCAT44(uStack_188._4_4_, *(undefined4 *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x158));
    uStack_1a8 = CONCAT44(uStack_1a8._4_4_, *(undefined4 *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x15c));
    fVar61 = *(float *)(arg1 + 0x280);
    uVar26 = (*(int64_t *)(arg1 + 0x48) - *piVar27 >> 3) * 0x6db6db6db6db6db7;
    if ((int64_t)uVar26 < 0) {
        fVar65 = (float)(uVar26 >> 1 | (uint64_t)((uint32_t)uVar26 & 1));
        fVar65 = fVar65 + fVar65;
    } else {
        fVar65 = (float)uVar26;
    }
    fVar65 = fVar65 * fVar61;
    fVar63 = (float)*(int32_t *)(arg1 + 0x60) * fVar66 + fVar63 + 1.0;
    var_210h = CONCAT44(fVar65, fVar63);
    iVar18 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0);
    if ((*(int64_t *)(iVar18 + 0x208) == 0) &&
       (fVar61 = *(float *)(arg1 + 0x280), *(int64_t *)(*(uint64_t *)0x180781f28 + 0x24d0) == 0)) {
        pfVar17 = (float *)(iVar18 + 0x2d0);
    } else {
        pfVar17 = (float *)(iVar18 + 0x2a0);
    }
    func_0x00018010be90(&uStack_1b0, *(undefined8 *)arg3, *pfVar17 - *(float *)(iVar18 + 0x158), 
                        pfVar17[1] - *(float *)(iVar18 + 0x15c));
    fVar68 = *(float *)(uVar55 + 0xe14);
    fVar67 = uStack_1b0._4_4_;
    fVar60 = fVar68;
    if (fVar65 <= uStack_1b0._4_4_) {
        fVar60 = 0.0;
    }
    *(float *)(arg1 + 700) = fVar60;
    if (fVar63 <= (float)uStack_1b0) {
        fVar68 = 0.0;
    }
    *(float *)(arg1 + 0x2c0) = fVar68;
    fVar60 = ((float)uStack_1b0 - *(float *)(arg1 + 0x298)) - fVar60;
    *(float *)(arg1 + 0x2ac) = fVar60;
    fVar63 = (float)func_0x000180471c90(fVar60 / fVar66);
    iVar14 = (int32_t)fVar63;
    if (iVar14 < 0) {
        iVar14 = 0;
    }
    *(int32_t *)(arg1 + 0x2b0) = iVar14;
    *(float *)(arg1 + 0x29c) = fVar67 - fVar68;
    fVar63 = (float)func_0x000180471c90();
    iVar14 = (int32_t)fVar63;
    if (iVar14 < 0) {
        iVar14 = 0;
    }
    *(int32_t *)(arg1 + 0x2a0) = iVar14;
    fVar68 = -1.0;
    fVar66 = -1.0;
    fVar63 = -1.0;
    fVar65 = -1.0;
    if (*(char *)(arg1 + 0x2c8) != '\0') {
        iVar18 = func_0x00018014ffc0(arg1);
        iVar14 = (int32_t)*(undefined8 *)(iVar18 + 8);
        if (*(int32_t *)(arg1 + 0x2a4) + 1 < iVar14) {
            if (*(int32_t *)(arg1 + 0x2a8) + -1 <= iVar14) {
                fVar66 = ((float)iVar14 + 2.0) * *(float *)(arg1 + 0x280) - *(float *)(arg1 + 0x29c);
                goto code_r0x000180150c62;
            }
        } else {
            fVar66 = ((float)iVar14 - 2.0) * *(float *)(arg1 + 0x280);
code_r0x000180150c62:
            if (fVar66 <= 0.0) {
                fVar66 = 0.0;
            }
        }
        iVar14 = (int32_t)((uint64_t)*(undefined8 *)(iVar18 + 8) >> 0x20);
        if (*(int32_t *)(arg1 + 0x2b4) + 1 < iVar14) {
            if (*(int32_t *)(arg1 + 0x2b8) + -1 <= iVar14) {
                fVar68 = ((float)iVar14 + 2.0) * *(float *)(arg1 + 0x27c) - *(float *)(arg1 + 0x2ac);
                goto code_r0x000180150cbd;
            }
        } else {
            fVar68 = ((float)iVar14 - 2.0) * *(float *)(arg1 + 0x27c);
code_r0x000180150cbd:
            if (fVar68 <= 0.0) {
                fVar68 = 0.0;
            }
        }
        *(undefined *)(arg1 + 0x2c8) = 0;
        fVar61 = *(float *)(arg1 + 0x280);
        uVar55 = *(uint64_t *)0x180781f28;
        fVar63 = fVar66;
        fVar65 = fVar68;
    }
    iVar14 = *(int32_t *)(arg1 + 0x2cc);
    if (iVar14 < 0) {
        if ((0.0 <= fVar65) || (0.0 <= fVar63)) goto code_r0x000180150d5a;
    } else {
        iVar15 = func_0x00018014fb20(piVar27);
        if (iVar15 < iVar14) {
            iVar14 = iVar15;
        }
        fVar65 = 0.0;
        iVar15 = *(int32_t *)(arg1 + 0x2d0);
        if (iVar15 == 0) {
code_r0x000180150d2e:
            fVar63 = (float)iVar14 * fVar61;
            if (fVar63 <= 0.0) {
                fVar63 = 0.0;
            }
        } else {
            if (iVar15 == 1) {
                iVar14 = iVar14 - *(int32_t *)(arg1 + 0x2a0) / 2;
                goto code_r0x000180150d2e;
            }
            if (iVar15 == 2) {
                iVar14 = (iVar14 - *(int32_t *)(arg1 + 0x2a0)) + 1;
                goto code_r0x000180150d2e;
            }
        }
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
code_r0x000180150d5a:
        *(uint32_t *)(uVar55 + 0x2008) = *(uint32_t *)(uVar55 + 0x2008) | 0x80;
        *(float *)(uVar55 + 0x203c) = fVar65;
        *(float *)(uVar55 + 0x2040) = fVar63;
    }
    if (*(char *)(arg1 + 0x429) != '\0') {
        *(uint32_t *)(uVar55 + 0x2008) = *(uint32_t *)(uVar55 + 0x2008) | 0x20;
        *(undefined *)(arg1 + 0x429) = 0;
    }
    func_0x0001801066e0(&var_210h);
    var_210h = 0;
    func_0x0001800f6960(0xe, &var_210h);
    uVar16 = func_0x00018014fb00(arg1 + 0x588, 10);
    uVar19 = func_0x0001800f5f30(&uStack_1d8, uVar16);
    func_0x0001800f6710(3, uVar19);
    func_0x0001800fe660(0x18063cd68, arg3, 0);
    uVar16 = *(undefined4 *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x15c);
    *(undefined4 *)(arg1 + 0x284) = *(undefined4 *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x158);
    *(undefined4 *)(arg1 + 0x288) = uVar16;
    func_0x000180153e20(arg1);
    func_0x000180154c90(arg1);
    cVar9 = func_0x00018015c160(arg1);
    if (cVar9 != '\0') {
        func_0x00018015c410();
    }
    if ((*(char *)(arg1 + 0x2d4) != '\0') || (*(char *)(arg1 + 0x2d5) != '\0')) {
        func_0x00018015f760(arg1 + 0x110, piVar27, *(undefined8 *)(arg1 + 0x5e8));
        func_0x00018015f940(arg1 + 0x118);
    }
    cVar9 = func_0x0001801500a0(piVar27);
    if (*(int64_t *)(arg1 + 0x5e8) != 0) {
        if (cVar9 != '\0') {
            func_0x00018015f7e0(arg1 + 0x110, arg1 + 0x40);
        }
        if ((*(char *)(arg1 + 0x26a) != '\0') &&
           (((cVar9 != '\0' || (*(char *)(arg1 + 0x2d4) != '\0')) || (*(char *)(arg1 + 0x2d5) != '\0')))) {
            func_0x00018015f950(arg1 + 0x118, piVar27);
        }
    }
    *(undefined *)(arg1 + 0x2d4) = 0;
    *(undefined *)(arg1 + 0x2d5) = 0;
    uVar55 = *(uint64_t *)0x180781f28;
    fVar63 = *(float *)(arg1 + 0x27c);
    fVar61 = (float)func_0x000180490aa0(*(float *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0xd4) / fVar63);
    iVar14 = (int32_t)fVar61;
    if (iVar14 < 0) {
        iVar14 = 0;
    }
    *(int32_t *)(arg1 + 0x2b4) = iVar14;
    fVar63 = (float)func_0x000180490aa0((*(float *)(*(int64_t *)(uVar55 + 0x15e0) + 0xd4) + *(float *)(arg1 + 0x2ac)) /
                                        fVar63);
    *(int32_t *)(arg1 + 0x2b8) = (int32_t)fVar63;
    fVar63 = *(float *)(arg1 + 0x280);
    fVar61 = (float)func_0x000180490aa0(*(float *)(*(int64_t *)(uVar55 + 0x15e0) + 0xd8) / fVar63);
    iVar14 = (int32_t)fVar61;
    if (iVar14 < 0) {
        iVar14 = 0;
    }
    *(int32_t *)(arg1 + 0x2a4) = iVar14;
    iVar15 = func_0x00018014fb20(piVar27);
    fVar63 = (float)func_0x000180490aa0((*(float *)(*(int64_t *)(uVar55 + 0x15e0) + 0xd8) + *(float *)(arg1 + 0x29c)) /
                                        fVar63);
    iVar14 = (int32_t)fVar63;
    if (iVar15 + -1 < (int32_t)fVar63) {
        iVar14 = iVar15 + -1;
    }
    *(int32_t *)(arg1 + 0x2a8) = iVar14;
    *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(uVar55 + 0x15e0);
    var_218h = *(int64_t *)(iVar18 + 800);
    fVar63 = *(float *)(iVar18 + 0x158);
    fVar61 = *(float *)(iVar18 + 0x15c);
    puVar36 = *(uint64_t **)arg1;
    puVar45 = *(uint64_t **)(arg1 + 8);
    puStack_190 = puVar45;
    if (puVar36 != puVar45) {
        uStack_1b8 = puVar36 + 1;
        do {
            iVar18 = var_218h;
            iVar14 = *(int32_t *)puVar36;
            iVar15 = *(int32_t *)uStack_1b8;
            bVar57 = SBORROW4(iVar14, iVar15);
            iVar49 = iVar14 - iVar15;
            if (iVar14 == iVar15) {
                iVar25 = *(int32_t *)((int64_t)uStack_1b8 + 4);
                iVar2 = *(int32_t *)((int64_t)puVar36 + 4);
                bVar57 = SBORROW4(iVar2, iVar25);
                iVar49 = iVar2 - iVar25;
                if (iVar2 != iVar25) goto code_r0x000180151049;
            } else {
code_r0x000180151049:
                puVar20 = uStack_1b8;
                if (bVar57 != iVar49 < 0) {
                    puVar20 = puVar36;
                }
                var_200h = *puVar20;
                bVar58 = SBORROW4(iVar14, iVar15);
                iVar49 = iVar14 - iVar15;
                bVar57 = iVar14 == iVar15;
                if (bVar57) {
                    iVar14 = *(int32_t *)((int64_t)uStack_1b8 + 4);
                    iVar15 = *(int32_t *)((int64_t)puVar36 + 4);
                    bVar58 = SBORROW4(iVar15, iVar14);
                    iVar49 = iVar15 - iVar14;
                    bVar57 = iVar15 == iVar14;
                }
                puVar20 = uStack_1b8;
                if (!bVar57 && bVar58 == iVar49 < 0) {
                    puVar20 = puVar36;
                }
                uStack_1e8 = (int32_t *)*puVar20;
                uVar42 = *(uint32_t *)(arg1 + 0x2a4);
                uVar44 = (uint32_t)uStack_1e8;
                if ((int32_t)uVar42 <= (int32_t)uVar44) {
                    uVar35 = *(uint32_t *)(arg1 + 0x2a8);
                    if ((int32_t)var_200h <= (int32_t)uVar35) {
                        uVar55 = var_200h & 0xffffffff;
                        if ((int32_t)var_200h < (int32_t)uVar42) {
                            uVar55 = (uint64_t)uVar42;
                        }
                        if ((int32_t)uVar35 < (int32_t)uVar44) {
                            uVar44 = uVar35;
                        }
                        uVar35 = (uint32_t)uVar55;
                        uVar26 = var_200h;
                        uVar54 = (uint64_t)uStack_1e8;
                        uVar42 = uVar35;
                        while (var_200h = uVar26, uStack_1e8 = (int32_t *)uVar54, (int32_t)uVar42 <= (int32_t)uVar44) {
                            fVar65 = fVar63 + *(float *)(arg1 + 0x298);
                            uVar42 = (uint32_t)uVar55;
                            var_200h._4_4_ = 0;
                            if (uVar42 == uVar35) {
                                var_200h._4_4_ = (int32_t)(uVar26 >> 0x20);
                            }
                            var_1f0h._0_4_ = (float)var_200h._4_4_ * *(float *)(arg1 + 0x27c) + fVar65;
                            if (uVar42 == uVar44) {
                                uStack_1e8._4_4_ = (int32_t)(uVar54 >> 0x20);
                            } else {
                                uStack_1e8._4_4_ =
                                     *(int32_t *)((int64_t)(int32_t)uVar42 * 0x38 + 0x28 + *(int64_t *)(arg1 + 0x40));
                            }
                            var_1f0h._4_4_ = (float)uVar42 * *(float *)(arg1 + 0x280) + fVar61;
                            var_210h = CONCAT44(var_1f0h._4_4_ + *(float *)(arg1 + 0x280), 
                                                (float)uStack_1e8._4_4_ * *(float *)(arg1 + 0x27c) + fVar65);
                            var_240h = var_240h & 0xffffffff00000000;
                            var_248h._0_4_ = 0;
                            func_0x000180126550(iVar18, &var_1f0h, &var_210h);
                            uVar42 = uVar42 + 1;
                            uVar55 = (uint64_t)uVar42;
                            uVar26 = var_200h;
                            uVar54 = (uint64_t)uStack_1e8;
                            puVar45 = puStack_190;
                        }
                    }
                }
            }
            puVar36 = (uint64_t *)((int64_t)puVar36 + 0x14);
            uStack_1b8 = (uint64_t *)((int64_t)uStack_1b8 + 0x14);
        } while (puVar36 != puVar45);
    }
    uVar55 = *(uint64_t *)0x180781f28;
    if (*(int64_t *)(arg1 + 0x30) != *(int64_t *)(arg1 + 0x28)) {
        *(undefined *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
        iVar18 = *(int64_t *)(uVar55 + 0x15e0);
        uVar19 = *(undefined8 *)(iVar18 + 800);
        fVar63 = *(float *)(iVar18 + 0x158);
        fVar61 = *(float *)(iVar18 + 0x15c);
        iVar14 = *(int32_t *)(arg1 + 0x2a4);
        if (iVar14 <= *(int32_t *)(arg1 + 0x2a8)) {
            do {
                if (*(int64_t *)(*(int64_t *)(arg1 + 0x40) + 0x20 + (int64_t)iVar14 * 0x38) != 0) {
                    iVar18 = *(int64_t *)(*(int64_t *)(arg1 + 0x40) + 0x20 + (int64_t)iVar14 * 0x38);
                    iVar5 = *(int64_t *)(arg1 + 0x28);
                    fVar65 = (float)iVar14 * *(float *)(arg1 + 0x280) + fVar61;
                    if (*(char *)(iVar5 + -0x45 + iVar18 * 0x48) != '\0') {
                        fVar66 = fVar63 + *(float *)(arg1 + 0x28c);
                        fVar68 = fVar63 + *(float *)(arg1 + 0x290);
                        fVar67 = fVar65 + *(float *)(arg1 + 0x280);
                        var_210h = CONCAT44(fVar67, fVar68);
                        var_240h = var_240h & 0xffffffff00000000;
                        var_248h._0_4_ = 0;
                        var_1f0h._0_4_ = fVar66;
                        var_1f0h._4_4_ = fVar65;
                        func_0x000180126550(uVar19, &var_1f0h, &var_210h);
                        if (*(int64_t *)(iVar5 + -0x30 + iVar18 * 0x48) != 0) {
                            iVar31 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0);
                            if (fVar66 <= *(float *)(iVar31 + 0x2b8)) {
                                fVar66 = *(float *)(iVar31 + 0x2b8);
                            }
                            if (fVar66 - *(float *)(*(uint64_t *)0x180781f28 + 0xe04) <=
                                *(float *)(*(uint64_t *)0x180781f28 + 0x118)) {
                                fVar60 = fVar65;
                                if (fVar65 <= *(float *)(iVar31 + 700)) {
                                    fVar60 = *(float *)(iVar31 + 700);
                                }
                                if (fVar60 - *(float *)(*(uint64_t *)0x180781f28 + 0xe08) <=
                                    *(float *)(*(uint64_t *)0x180781f28 + 0x11c)) {
                                    if (*(float *)(iVar31 + 0x2c0) <= fVar68) {
                                        fVar68 = *(float *)(iVar31 + 0x2c0);
                                    }
                                    if (*(float *)(*(uint64_t *)0x180781f28 + 0x118) <
                                        fVar68 + *(float *)(*(uint64_t *)0x180781f28 + 0xe04)) {
                                        if (*(float *)(iVar31 + 0x2c4) <= fVar67) {
                                            fVar67 = *(float *)(iVar31 + 0x2c4);
                                        }
                                        if (*(float *)(*(uint64_t *)0x180781f28 + 0x11c) <
                                            fVar67 + *(float *)(*(uint64_t *)0x180781f28 + 0xe08)) {
                                            iVar31 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x2168);
                                            if (((fVar60 < *(float *)(iVar31 + 0xc) + *(float *)(iVar31 + 0x14)) &&
                                                (*(float *)(iVar31 + 0xc) < fVar67)) &&
                                               ((fVar66 < *(float *)(iVar31 + 8) + *(float *)(iVar31 + 0x10) &&
                                                (*(float *)(iVar31 + 8) < fVar68)))) {
                                                func_0x0001800f6650(4, *(undefined4 *)(iVar5 + -0x48 + iVar18 * 0x48));
                                                func_0x00018010ccd0(0);
                                                piVar27 = (int64_t *)(iVar5 + -0x40 + iVar18 * 0x48);
                                                if (0xf < (uint64_t)piVar27[3]) {
                                                    piVar27 = (int64_t *)*piVar27;
                                                }
                                                func_0x000180139280(piVar27, 0);
                                                func_0x000180105c20();
                                                func_0x0001800f6770(1);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (*(char *)(iVar5 + -0x41 + iVar18 * 0x48) != '\0') {
                        fVar66 = fVar63 + *(float *)(arg1 + 0x298);
                        fVar68 = (float)*(int32_t *)(arg1 + 0x2b8) * *(float *)(arg1 + 0x27c) + fVar66;
                        fVar67 = fVar65 + *(float *)(arg1 + 0x280);
                        uStack_1b8 = (uint64_t *)CONCAT44(fVar67, fVar68);
                        var_240h = var_240h & 0xffffffff00000000;
                        var_248h._0_4_ = 0;
                        fStack_1a0 = fVar66;
                        fStack_19c = fVar65;
                        func_0x000180126550(uVar19, &fStack_1a0, &uStack_1b8);
                        if (*(int64_t *)(iVar5 + -0x10 + iVar18 * 0x48) != 0) {
                            iVar31 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0);
                            if (fVar66 <= *(float *)(iVar31 + 0x2b8)) {
                                fVar66 = *(float *)(iVar31 + 0x2b8);
                            }
                            if (fVar66 - *(float *)(*(uint64_t *)0x180781f28 + 0xe04) <=
                                *(float *)(*(uint64_t *)0x180781f28 + 0x118)) {
                                if (fVar65 <= *(float *)(iVar31 + 700)) {
                                    fVar65 = *(float *)(iVar31 + 700);
                                }
                                if (fVar65 - *(float *)(*(uint64_t *)0x180781f28 + 0xe08) <=
                                    *(float *)(*(uint64_t *)0x180781f28 + 0x11c)) {
                                    if (*(float *)(iVar31 + 0x2c0) <= fVar68) {
                                        fVar68 = *(float *)(iVar31 + 0x2c0);
                                    }
                                    if (*(float *)(*(uint64_t *)0x180781f28 + 0x118) <
                                        fVar68 + *(float *)(*(uint64_t *)0x180781f28 + 0xe04)) {
                                        if (*(float *)(iVar31 + 0x2c4) <= fVar67) {
                                            fVar67 = *(float *)(iVar31 + 0x2c4);
                                        }
                                        if (*(float *)(*(uint64_t *)0x180781f28 + 0x11c) <
                                            fVar67 + *(float *)(*(uint64_t *)0x180781f28 + 0xe08)) {
                                            iVar31 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x2168);
                                            if (((fVar65 < *(float *)(iVar31 + 0xc) + *(float *)(iVar31 + 0x14)) &&
                                                (*(float *)(iVar31 + 0xc) < fVar67)) &&
                                               ((fVar66 < *(float *)(iVar31 + 8) + *(float *)(iVar31 + 0x10) &&
                                                (*(float *)(iVar31 + 8) < fVar68)))) {
                                                func_0x0001800f6650(4, *(undefined4 *)(iVar5 + -0x44 + iVar18 * 0x48));
                                                func_0x00018010ccd0(0);
                                                piVar27 = (int64_t *)(iVar5 + -0x20 + iVar18 * 0x48);
                                                if (0xf < (uint64_t)piVar27[3]) {
                                                    piVar27 = (int64_t *)*piVar27;
                                                }
                                                func_0x000180139280(piVar27, 0);
                                                func_0x000180105c20();
                                                func_0x0001800f6770(1);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                iVar14 = iVar14 + 1;
            } while (iVar14 <= *(int32_t *)(arg1 + 0x2a8));
        }
    }
    uVar55 = *(uint64_t *)0x180781f28;
    if ((*(char *)(arg1 + 0x26a) != '\0') && (*(int64_t *)(arg1 + 0x120) != *(int64_t *)(arg1 + 0x118))) {
        *(undefined *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
        iVar18 = *(int64_t *)(uVar55 + 0x15e0);
        uVar19 = *(undefined8 *)(iVar18 + 800);
        fVar63 = *(float *)(iVar18 + 0x158);
        fVar61 = *(float *)(iVar18 + 0x15c);
        iVar5 = *(int64_t *)(arg1 + 0x120);
        for (iVar18 = *(int64_t *)(arg1 + 0x118); iVar18 != iVar5; iVar18 = iVar18 + 0x1c) {
            iVar14 = *(int32_t *)(iVar18 + 0x10);
            iVar15 = *(int32_t *)(iVar18 + 4);
            if (((1 < iVar14 - iVar15) && (iVar15 <= *(int32_t *)(arg1 + 0x2a8))) &&
               (*(int32_t *)(arg1 + 0x2a4) < iVar14)) {
                iVar49 = *(int32_t *)(iVar18 + 8);
                if (*(int32_t *)(iVar18 + 0x14) < iVar49) {
                    iVar49 = *(int32_t *)(iVar18 + 0x14);
                }
                var_1f0h._0_4_ = (float)iVar49 * *(float *)(arg1 + 0x27c) + fVar63 + *(float *)(arg1 + 0x298);
                var_210h = CONCAT44((float)iVar14 * *(float *)(arg1 + 0x280) + fVar61, (float)var_1f0h);
                var_1f0h._4_4_ = (float)(iVar15 + 1) * *(float *)(arg1 + 0x280) + fVar61;
                var_248h._0_4_ = 0x3f800000;
                func_0x000180126300(uVar19, &var_1f0h, &var_210h);
            }
        }
        uVar26 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
        uVar55 = *(uint64_t *)(arg1 + 0x18);
        if ((uVar26 < uVar55 || uVar26 - uVar55 == 0) && (*(undefined8 *)(arg1 + 0x18) = 0, uVar55 = 0, uVar26 == 0))
        goto code_r0x000180153dec;
        iVar18 = *(int64_t *)(*(int64_t *)arg1 + 8 + uVar55 * 0x14);
        uVar55 = *(uint64_t *)(arg1 + 0x120);
        uVar26 = *(uint64_t *)(arg1 + 0x118);
        var_218h._4_4_ = (int32_t)((uint64_t)iVar18 >> 0x20);
        uVar54 = uVar55;
        for (; uVar26 != uVar55; uVar26 = uVar26 + 0x1c) {
            cVar9 = -1;
            if (uVar55 <= uVar26) {
                cVar9 = '\x01';
            }
            if (-1 < cVar9) break;
            iVar14 = *(int32_t *)(uVar26 + 4);
            iVar49 = (int32_t)iVar18;
            bVar58 = SBORROW4(iVar14, iVar49);
            iVar15 = iVar14 - iVar49;
            bVar57 = iVar14 == iVar49;
            if (bVar57) {
                iVar25 = *(int32_t *)(uVar26 + 8);
                bVar58 = SBORROW4(iVar25, var_218h._4_4_);
                iVar15 = iVar25 - var_218h._4_4_;
                bVar57 = iVar25 == var_218h._4_4_;
            }
            if (!bVar57 && bVar58 == iVar15 < 0) break;
            bVar57 = SBORROW4(iVar14, iVar49);
            iVar15 = iVar14 - iVar49;
            if (iVar14 == iVar49) {
                bVar57 = SBORROW4(*(int32_t *)(uVar26 + 8), var_218h._4_4_);
                iVar15 = *(int32_t *)(uVar26 + 8) - var_218h._4_4_;
            }
            if (bVar57 != iVar15 < 0) {
                iVar14 = *(int32_t *)(uVar26 + 0x10);
                if (iVar14 == iVar49) {
                    bVar57 = var_218h._4_4_ <= *(int32_t *)(uVar26 + 0x14);
                } else {
                    bVar57 = iVar14 != iVar49 && iVar49 <= iVar14;
                }
                if (bVar57) {
                    uVar54 = uVar26;
                }
            }
        }
        var_218h = iVar18;
        if (((uVar54 != uVar55) && (*(int32_t *)(uVar54 + 4) <= *(int32_t *)(arg1 + 0x2a8))) &&
           (*(int32_t *)(arg1 + 0x2a4) < *(int32_t *)(uVar54 + 0x10))) {
            fVar66 = (float)*(int32_t *)(uVar54 + 8) * *(float *)(arg1 + 0x27c) + fVar63 + *(float *)(arg1 + 0x298);
            fVar65 = (float)*(int32_t *)(uVar54 + 4) * *(float *)(arg1 + 0x280) + fVar61;
            var_210h = CONCAT44(fVar65 + *(float *)(arg1 + 0x280), fVar66 + *(float *)(arg1 + 0x27c));
            var_240h = var_240h & 0xffffffff00000000;
            var_248h._0_4_ = 0;
            var_1f0h._0_4_ = fVar66;
            var_1f0h._4_4_ = fVar65;
            func_0x000180126550(uVar19, &var_1f0h, &var_210h, *(undefined4 *)(arg1 + 0x5c0));
            fVar63 = (float)*(int32_t *)(uVar54 + 0x14) * *(float *)(arg1 + 0x27c) + fVar63 + *(float *)(arg1 + 0x298);
            fVar61 = (float)*(int32_t *)(uVar54 + 0x10) * *(float *)(arg1 + 0x280) + fVar61;
            var_210h = CONCAT44(fVar61 + *(float *)(arg1 + 0x280), fVar63 + *(float *)(arg1 + 0x27c));
            var_240h = var_240h & 0xffffffff00000000;
            var_248h._0_4_ = 0;
            var_1f0h._0_4_ = fVar63;
            var_1f0h._4_4_ = fVar61;
            func_0x000180126550(uVar19, &var_1f0h, &var_210h);
            if (1 < *(int32_t *)(uVar54 + 0x10) - *(int32_t *)(uVar54 + 4)) {
                var_1f0h._0_4_ = fVar63;
                if (fVar66 <= fVar63) {
                    var_1f0h._0_4_ = fVar66;
                }
                var_210h = CONCAT44(fVar61, (float)var_1f0h);
                var_1f0h._4_4_ = fVar65 + *(float *)(arg1 + 0x280);
                var_248h._0_4_ = 0x3f800000;
                func_0x000180126300(uVar19, &var_1f0h, &var_210h);
            }
        }
    }
    uVar55 = *(uint64_t *)0x180781f28;
    *(undefined *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
    iVar18 = *(int64_t *)(uVar55 + 0x15e0);
    uVar19 = *(undefined8 *)(iVar18 + 800);
    var_1f0h._0_4_ = *(float *)(arg1 + 0x2a4);
    fVar63 = *(float *)(iVar18 + 0x158);
    fVar61 = *(float *)(arg1 + 0x298);
    fVar66 = (float)(int32_t)(float)var_1f0h * *(float *)(arg1 + 0x280) + *(float *)(iVar18 + 0x15c);
    iVar14 = *(int32_t *)(arg1 + 0x58);
    uStack_1b8 = (uint64_t *)CONCAT44(uStack_1b8._4_4_, iVar14);
    fVar65 = (float)(*(int32_t *)(arg1 + 0x2b4) - *(int32_t *)(arg1 + 0x2b4) % iVar14);
    fStack_1a0 = fVar65;
    if ((int32_t)(float)var_1f0h <= *(int32_t *)(arg1 + 0x2a8)) {
        do {
            ppiVar53 = (int16_t **)(*(int32_t **)(arg1 + 0x40) + (int64_t)(int32_t)(float)var_1f0h * 0xe);
            piVar6 = ppiVar53[1];
            uVar55 = 0;
            piVar28 = *ppiVar53;
            if (0 < (int32_t)fVar65) {
                iVar15 = 0;
                iVar49 = 0;
                do {
                    iVar14 = iVar15;
                    iVar15 = iVar14;
                    if (piVar28 == piVar6) break;
                    cVar9 = -1;
                    if (piVar6 <= piVar28) {
                        cVar9 = '\x01';
                    }
                    if (-1 < cVar9) break;
                    if (*piVar28 == 9) {
                        iVar15 = iVar14 + (*(int32_t *)(piStack_180 + 3) - iVar14 % *(int32_t *)(piStack_180 + 3));
                    } else {
                        iVar15 = iVar14 + 1;
                    }
                    uVar55 = uVar55 + 1;
                    piVar28 = piVar28 + 2;
                    iVar49 = iVar14;
                } while (iVar15 < (int32_t)fVar65);
                piVar28 = *ppiVar53;
                arg1 = (int64_t)ppiStack_170;
                iVar14 = (int32_t)uStack_1b8;
                if ((1 < iVar15 - iVar49) && ((int32_t)fVar65 - iVar49 <= iVar15 - (int32_t)fVar65)) {
                    uVar55 = uVar55 - 1;
                }
            }
            fVar68 = fVar65;
            for (; (uVar55 < (uint64_t)((int64_t)piVar6 - (int64_t)piVar28 >> 2) &&
                   (fVar65 = fStack_1a0, (int32_t)fVar68 <= *(int32_t *)(arg1 + 0x2b8)));
                fVar68 = (float)((int32_t)fVar68 + iVar15)) {
                iVar12 = (*ppiVar53)[uVar55 * 2];
                fVar65 = *(float *)(arg1 + 0x27c);
                fVar67 = (float)(int32_t)fVar68 * fVar65 + fVar63 + fVar61;
                var_218h = CONCAT44(fVar66, fVar67);
                if (iVar12 == 9) {
                    if (*(char *)(arg1 + 0x267) != '\0') {
                        fVar64 = *(float *)(arg1 + 0x278) * 0.5 + fVar66;
                        uStack_178 = CONCAT44(fVar64, fVar65 * 0.3 + fVar67);
                        var_210h = CONCAT44(fVar64, fVar67 + fVar65);
                        fVar60 = *(float *)(arg1 + 0x278) * 0.16;
                        fVar65 = (fVar67 + fVar65) - fVar60;
                        puStack_190 = (uint64_t *)CONCAT44(fVar64 - fVar60, fVar65);
                        uStack_1e8 = (int32_t *)CONCAT44(fVar64 + fVar60, fVar65);
                        var_248h._0_4_ = 0x3f800000;
                        func_0x000180126300(uVar19, &uStack_178, &var_210h, *(undefined4 *)(arg1 + 0x5bc));
                        var_248h._0_4_ = 0x3f800000;
                        func_0x000180126300(uVar19, &var_210h, &puStack_190, *(undefined4 *)(arg1 + 0x5bc));
                        var_248h._0_4_ = 0x3f800000;
                        func_0x000180126300(uVar19, &var_210h, &uStack_1e8);
                        iVar14 = (int32_t)uStack_1b8;
                    }
                    iVar15 = iVar14 - (int32_t)fVar68 % iVar14;
                } else {
                    if (iVar12 == 0x20) {
                        if (*(char *)(arg1 + 0x266) != '\0') {
                            uVar42 = *(uint32_t *)(arg1 + 0x5bc);
                            var_200h = CONCAT44(*(float *)(arg1 + 0x278) * 0.5 + fVar66, fVar65 * 0.5 + fVar67);
                            if ((uVar42 & 0xff000000) != 0) {
                                uVar26 = (uint64_t)var_240h >> 0x20;
                                var_240h = CONCAT44((int32_t)uVar26, 3);
                                var_248h._0_4_ = 0x4096cbe4;
                                func_0x000180125a30(uVar19, &var_200h);
                                func_0x0001800f3bc0(uVar19, uVar42);
                            }
                        }
                    } else {
                        uVar26 = (uint64_t)*(char *)(*ppiVar53 + uVar55 * 2 + 1);
                        if (0x15 < uVar26) {
                            func_0x00018014fd00();
                            pcVar7 = (code *)swi(3);
                            (*pcVar7)();
                            return;
                        }
                        var_238h = 0;
                        uVar54 = (uint64_t)var_240h >> 0x10;
                        var_240h = CONCAT62((unkint6)uVar54, iVar12);
                        var_248h._0_4_ = *(uint32_t *)(arg1 + uVar26 * 4 + 0x588);
                        func_0x00018012f6c0(*(int32_t **)(arg1 + 0x270), uVar19);
                    }
                    iVar15 = 1;
                    iVar14 = (int32_t)uStack_1b8;
                }
                uVar55 = uVar55 + 1;
                fVar65 = fStack_1a0;
            }
            fVar66 = fVar66 + *(float *)(arg1 + 0x280);
            var_1f0h._0_4_ = (float)((int32_t)(float)var_1f0h + 1);
        } while ((int32_t)(float)var_1f0h <= *(int32_t *)(arg1 + 0x2a8));
    }
    uVar55 = *(uint64_t *)0x180781f28;
    fVar63 = (float)func_0x000180490df0(*(float *)(*(uint64_t *)0x180781f28 + 0x48) + *(float *)(arg1 + 0x2c4));
    *(float *)(arg1 + 0x2c4) = fVar63;
    if ((*(int64_t *)(uVar55 + 0x21d8) != 0) &&
       (iVar18 = *(int64_t *)(uVar55 + 0x15e0), *(int64_t *)(uVar55 + 0x21d8) == iVar18)) {
        fVar61 = *(float *)(iVar18 + 0x158);
        fVar65 = *(float *)(iVar18 + 0x15c);
        if ((*(char *)(uVar55 + 0x8f) == '\0') || (fVar63 < 0.5)) {
            *(undefined *)(iVar18 + 0x10b) = 1;
            uVar19 = *(undefined8 *)(*(int64_t *)(uVar55 + 0x15e0) + 800);
            piVar24 = *(int32_t **)(arg1 + 8);
            uVar55 = *(uint64_t *)0x180781f28;
            for (piVar39 = *(int32_t **)arg1; *(uint64_t *)0x180781f28 = uVar55, piVar39 != piVar24;
                piVar39 = piVar39 + 5) {
                iVar14 = (int32_t)*(undefined8 *)(piVar39 + 2);
                if ((*(int32_t *)(arg1 + 0x2a4) <= iVar14) && (iVar14 <= *(int32_t *)(arg1 + 0x2a8))) {
                    fVar66 = ((float)(int32_t)((uint64_t)*(undefined8 *)(piVar39 + 2) >> 0x20) *
                              *(float *)(arg1 + 0x27c) + fVar61 + *(float *)(arg1 + 0x298)) - 1.0;
                    fVar63 = (float)iVar14 * *(float *)(arg1 + 0x280) + fVar65;
                    var_218h = CONCAT44(fVar63 + *(float *)(arg1 + 0x280), fVar66 + 1.0);
                    var_200h = CONCAT44(fVar63, fVar66);
                    var_240h = var_240h & 0xffffffff00000000;
                    var_248h._0_4_ = 0;
                    func_0x000180126550(uVar19, &var_200h, &var_218h, *(undefined4 *)(arg1 + 0x5b4));
                }
                uVar55 = *(uint64_t *)0x180781f28;
            }
        }
        if (*(char *)(arg1 + 0x264) == '\0') {
            *(undefined2 *)(uVar55 + 0x28b0) = 0x101;
            *(float *)(uVar55 + 0x28b4) = fVar61 - 1.0;
            *(float *)(uVar55 + 0x28b8) = fVar65 - *(float *)(uVar55 + 0x12f8);
            *(float *)(uVar55 + 0x28bc) = *(float *)(uVar55 + 0x12f8);
            *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
            *(undefined4 *)(uVar55 + 0x28c0) = **(undefined4 **)(*(int64_t *)(uVar55 + 0x15e0) + 0x48);
            uVar55 = *(uint64_t *)0x180781f28;
        }
    }
    if ((((*(float *)(arg1 + 0x2d8) != 0.0) && (*(int32_t **)(arg1 + 0x318) != (int32_t *)0x0)) ||
        (*(char *)(arg1 + 0x268) != '\0')) && (0.0 < *(float *)(*(int64_t *)(uVar55 + 0x15e0) + 0xd4))) {
        *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
        iVar18 = *(int64_t *)(uVar55 + 0x15e0);
        var_218h = CONCAT44(*(float *)(iVar18 + 100) + *(float *)(iVar18 + 0x6c), 
                            *(float *)(iVar18 + 0x60) + *(float *)(arg1 + 0x298));
        var_200h = *(int64_t *)(iVar18 + 0x60);
        var_240h = var_240h & 0xffffffff00000000;
        var_248h._0_4_ = 0;
        func_0x000180126550(*(undefined8 *)(iVar18 + 800), &var_200h, &var_218h, *(undefined4 *)(arg1 + 0x5b0));
        uVar55 = *(uint64_t *)0x180781f28;
    }
    piVar39 = (int32_t *)0x0;
    if (*(char *)(arg1 + 0x268) != '\0') {
        *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
        uVar26 = *(uint64_t *)(*(int64_t *)(uVar55 + 0x15e0) + 800);
        fVar63 = *(float *)(*(int64_t *)(uVar55 + 0x15e0) + 0x15c);
        piVar33 = (int32_t *)
                  (((int64_t)*(int32_t **)(arg1 + 8) - (int64_t)*(int32_t **)arg1 >> 2) * -0x3333333333333333);
        piVar24 = *(int32_t **)(arg1 + 0x20);
        if (piVar33 < piVar24 || (int64_t)piVar33 - (int64_t)piVar24 == 0) {
            piVar24 = *(int32_t **)(arg1 + 0x18);
            if (piVar33 <= *(int32_t **)(arg1 + 0x18)) {
                piVar24 = piVar39;
            }
            *(int32_t **)(arg1 + 0x20) = piVar24;
            if (piVar33 < piVar24 || (int64_t)piVar33 - (int64_t)piVar24 == 0) {
code_r0x000180153dec:
                func_0x000180060370();
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
        }
        uVar42 = (*(int32_t **)arg1)[(int64_t)piVar24 * 5 + 2];
        uVar54 = (uint64_t)uVar42;
        fVar61 = *(float *)(*(int64_t *)(uVar55 + 0x15e0) + 0x60) + *(float *)(arg1 + 0x290);
        uVar44 = *(uint32_t *)(arg1 + 0x2a4);
        uVar55 = *(uint64_t *)0x180781f28;
        if ((int32_t)uVar44 <= *(int32_t *)(arg1 + 0x2a8)) {
            do {
                uVar55 = (uint64_t)uVar44;
                uVar35 = uVar44 + 1;
                dVar62 = (double)func_0x00018048d7c0((double)uVar35);
                fVar65 = (float)(int32_t)(dVar62 + 1.0) * *(float *)(arg1 + 0x27c);
                pcVar51 = acStack_105 + 2;
                if ((int32_t)uVar35 < 0) {
                    uVar35 = -uVar35;
                    do {
                        pcVar52 = pcVar51;
                        pcVar51 = pcVar52 + -1;
                        *pcVar51 = (char)uVar35 + (char)((uint64_t)uVar35 / 10) * -10 + '0';
                        uVar35 = (uint32_t)((uint64_t)uVar35 / 10);
                    } while (uVar35 != 0);
                    pcVar51 = pcVar52 + -2;
                    *pcVar51 = '-';
                    uVar35 = 0;
                } else {
                    do {
                        pcVar51 = pcVar51 + -1;
                        *pcVar51 = (char)uVar35 + (char)((uint64_t)uVar35 / 10) * -10 + '0';
                        uVar35 = (uint32_t)((uint64_t)uVar35 / 10);
                    } while (uVar35 != 0);
                }
                func_0x000180014b30(apppppuStack_140, pcVar51, acStack_105 + 2, &var_1f8h);
                pppppuVar29 = apppppuStack_140;
                if (0xf < uStack_128) {
                    pppppuVar29 = apppppuStack_140[0];
                }
                iVar18 = 0x50;
                if (uVar44 == uVar42) {
                    iVar18 = 0x54;
                }
                uVar3 = *(uint32_t *)(iVar18 + 0x588 + arg1);
                var_218h = CONCAT44((float)uVar44 * *(float *)(arg1 + 0x280) + fVar63, fVar61 - fVar65);
                if ((((uVar3 & 0xff000000) != 0) && (pppppuVar29 != (undefined8 *****)0x0)) &&
                   (*(char *)pppppuVar29 != '\0')) {
                    uStack_1d8 = *(int32_t ***)(uVar26 + 0x60);
                    uStack_1d0 = *(int32_t **)(uVar26 + 0x68);
                    var_220h._0_4_ = 0;
                    var_228h._0_4_ = 0;
                    var_230h = 0;
                    var_240h = (int64_t)&uStack_1d8;
                    var_248h._0_4_ = uVar3;
                    var_238h = (int64_t)pppppuVar29;
                    func_0x00018012f9d0(*(undefined8 *)(*(int64_t *)(uVar26 + 0x38) + 0x18), uVar26, uStack_128, 
                                        &var_218h);
                }
                if (0xf < uStack_128) {
                    uVar34 = uStack_128 + 1;
                    pppppuVar29 = apppppuStack_140[0];
                    if (0xfff < uVar34) {
                        pppppuVar29 = (undefined8 *****)apppppuStack_140[0][-1];
                        if ((char *)0x1f < (char *)((int64_t)apppppuStack_140[0] + (-8 - (int64_t)pppppuVar29))) {
                            pcVar7 = (code *)swi(0x29);
                            (*pcVar7)(5);
                            puVar40 = auStack_260;
                            piVar24 = piVar39;
                            goto code_r0x000180152289;
                        }
                        uVar34 = uStack_128 + 0x28;
                    }
                    func_0x000180459c3c(pppppuVar29, uVar34);
                }
                uVar44 = uVar44 + 1;
                uVar55 = *(uint64_t *)0x180781f28;
            } while ((int32_t)uVar44 <= *(int32_t *)(arg1 + 0x2a8));
        }
    }
    fVar66 = *(float *)(arg1 + 0x2d8);
    puVar41 = auStack_268;
    if ((fVar66 != 0.0) && (puVar41 = auStack_268, *(int32_t **)(arg1 + 0x318) != (int32_t *)0x0)) {
        iVar18 = *(int64_t *)(uVar55 + 0x15e0);
        uVar35 = *(uint32_t *)(iVar18 + 0x158);
        fVar63 = *(float *)(iVar18 + 0x15c);
        uVar42 = *(uint32_t *)(arg1 + 0x2a4);
        fVar61 = *(float *)(arg1 + 0x294) + *(float *)(iVar18 + 0x60);
        fVar65 = (float)uVar42 * *(float *)(arg1 + 0x280) + fVar63;
        if (fVar66 < 0.0) {
            fVar66 = (float)((uint32_t)fVar66 ^ 0x80000000) * *(float *)(arg1 + 0x27c);
        }
        uStack_168 = (int32_t **)((uint64_t)(uint32_t)fVar66 << 0x20);
        piStack_160 = (int32_t *)CONCAT44(*(undefined4 *)(arg1 + 0x27c), *(float *)(arg1 + 0x280));
        uStack_158 = *(undefined4 *)(arg1 + 0x280);
        piStack_150 = (int32_t *)0x0;
        puVar41 = auStack_268;
        if ((int32_t)uVar42 <= *(int32_t *)(arg1 + 0x2a8)) {
            uVar54 = 0x6db6db6db6db6db7;
            do {
                uVar26 = (uint64_t)uVar42;
                uStack_168 = (int32_t **)CONCAT44(uStack_168._4_4_, uVar42);
                piVar24 = piVar39;
                if (-1 < (int32_t)uVar42) {
                    uVar34 = ((int64_t)*(int32_t **)(arg1 + 0x48) - (int64_t)*(int32_t **)(arg1 + 0x40) >> 3) * uVar54;
                    if ((int32_t)uVar42 < (int32_t)uVar34) {
                        uVar30 = (uint64_t)(int32_t)uVar42;
                        if (uVar34 < uVar30 || uVar34 - uVar30 == 0) {
                            *(undefined8 *)(puVar40 + -8) = 0x180153df7;
                            func_0x000180060370();
                            pcVar7 = (code *)swi(3);
                            (*pcVar7)();
                            return;
                        }
                        piVar24 = *(int32_t **)(*(int32_t **)(arg1 + 0x40) + uVar30 * 0xe + 0xc);
                    }
                }
code_r0x000180152289:
                *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
                iVar18 = *(int64_t *)(uVar55 + 0x15e0);
                *(float *)(iVar18 + 0x158) = fVar61;
                *(float *)(iVar18 + 0x15c) = fVar65;
                *(undefined *)(iVar18 + 0x199) = 1;
                *(undefined8 *)(puVar40 + -8) = 0x1801522c0;
                piStack_150 = piVar24;
                func_0x000180107620(uVar26 & 0xffffffff);
                piVar27 = *(int64_t **)(arg1 + 0x318);
                if (piVar27 == (int64_t *)0x0) {
                    *(undefined8 *)(puVar40 + -8) = 0x180153de5;
                    func_0x000180454690();
                    pcVar7 = (code *)swi(3);
                    (*pcVar7)();
                    return;
                }
                pcVar7 = *(code **)(*piVar27 + 0x10);
                *(undefined8 *)(puVar40 + -8) = 0x1801522db;
                (*pcVar7)(piVar27, &uStack_168);
                uVar55 = *(uint64_t *)0x180781f28;
                iVar14 = *(int32_t *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x148);
                if (iVar14 < 2) {
                    pcVar7 = *(code **)(*(uint64_t *)0x180781f28 + 0x2a40);
                    if (pcVar7 != (code *)0x0) {
                        uVar19 = *(undefined8 *)(*(uint64_t *)0x180781f28 + 0x2a48);
                        *(undefined8 *)(puVar40 + -8) = 0x180152313;
                        (*pcVar7)(*(uint64_t *)0x180781f28, uVar19, 0x1806445f8);
                        uVar55 = *(uint64_t *)0x180781f28;
                    }
                } else {
                    *(int32_t *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x148) = iVar14 + -1;
                }
                fVar65 = fVar65 + *(float *)(arg1 + 0x280);
                uVar42 = (int32_t)uVar26 + 1;
                puVar41 = puVar40;
            } while ((int32_t)uVar42 <= *(int32_t *)(arg1 + 0x2a8));
        }
        *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
        iVar18 = *(int64_t *)(uVar55 + 0x15e0);
        *(uint32_t *)(iVar18 + 0x158) = uVar35;
        *(float *)(iVar18 + 0x15c) = fVar63;
        *(undefined *)(iVar18 + 0x199) = 1;
        uVar55 = *(uint64_t *)0x180781f28;
    }
    iVar14 = 8;
    uVar26 = uVar55;
    if (*(char *)(arg1 + 0x269) != '\0') {
        *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
        uVar26 = *(uint64_t *)0x180781f28;
        if (*(char *)(*(int64_t *)(uVar55 + 0x15e0) + 0x105) != '\0') {
            *(undefined *)(*(int64_t *)(uVar55 + 0x15e0) + 0x10b) = 1;
            iVar18 = *(int64_t *)(*(int64_t *)(uVar55 + 0x15e0) + 800);
            uVar42 = 1;
            *(undefined8 *)(puVar41 + -8) = 0x1801523cb;
            func_0x00018013b2f0(&uStack_1d8);
            fVar63 = uStack_1d8._4_4_;
            uVar55 = ((int64_t)*(int32_t **)(arg1 + 0x48) - (int64_t)*(int32_t **)(arg1 + 0x40) >> 3) *
                     0x6db6db6db6db6db7;
            if ((int64_t)uVar55 < 0) {
                fVar61 = (float)(uVar55 >> 1 | (uint64_t)((uint32_t)uVar55 & uVar42));
                fVar61 = fVar61 + fVar61;
            } else {
                fVar61 = (float)uVar55;
            }
            fVar61 = (uStack_1d0._4_4_ - uStack_1d8._4_4_) / fVar61;
            fVar65 = (float)uStack_1d8;
            fVar68 = ((float)uStack_1d0 - (float)uStack_1d8) * 0.3;
            fVar67 = fVar68 + (float)uStack_1d8;
            fVar68 = (float)uStack_1d0 - fVar68;
            fVar66 = (float)uStack_1d8;
            if ((float)uStack_1d8 <= (float)uStack_1d0) {
                fVar66 = (float)uStack_1d0;
            }
            fVar60 = uStack_1d8._4_4_;
            if (uStack_1d8._4_4_ <= uStack_1d0._4_4_) {
                fVar60 = uStack_1d0._4_4_;
            }
            piVar39 = (int32_t *)(iVar18 + 0xa0);
            iVar15 = *(int32_t *)(iVar18 + 0xa4);
            if (*piVar39 == iVar15) {
                iVar25 = *piVar39 + 1;
                iVar49 = iVar14;
                if (iVar15 != 0) {
                    iVar49 = iVar15 / 2 + iVar15;
                }
                if (iVar25 < iVar49) {
                    iVar25 = iVar49;
                }
                *(undefined8 *)(puVar41 + -8) = 0x180152494;
                func_0x00018011faa0(piVar39, iVar25);
            }
            iVar31 = (int64_t)*piVar39;
            iVar5 = *(int64_t *)(iVar18 + 0xa8);
            *(float *)(iVar5 + iVar31 * 0x10) = fVar65;
            *(float *)(iVar5 + 4 + iVar31 * 0x10) = fVar63;
            *(float *)(iVar5 + 8 + iVar31 * 0x10) = fVar66;
            *(float *)(iVar5 + 0xc + iVar31 * 0x10) = fVar60;
            *piVar39 = *piVar39 + 1;
            *(float *)(iVar18 + 0x60) = fVar65;
            *(float *)(iVar18 + 100) = fVar63;
            *(float *)(iVar18 + 0x68) = fVar66;
            *(float *)(iVar18 + 0x6c) = fVar60;
            *(undefined8 *)(puVar41 + -8) = 0x1801524da;
            func_0x0001801242c0(iVar18);
            puVar37 = *(undefined8 **)arg1;
            puVar38 = *(undefined8 **)(arg1 + 8);
            if (puVar37 != puVar38) {
                puVar43 = puVar37 + 1;
                do {
                    iVar15 = *(int32_t *)puVar37;
                    iVar49 = *(int32_t *)puVar43;
                    bVar57 = SBORROW4(iVar15, iVar49);
                    iVar25 = iVar15 - iVar49;
                    if (iVar15 == iVar49) {
                        bVar57 = SBORROW4(*(int32_t *)((int64_t)puVar37 + 4), *(int32_t *)((int64_t)puVar43 + 4));
                        iVar25 = *(int32_t *)((int64_t)puVar37 + 4) - *(int32_t *)((int64_t)puVar43 + 4);
                    }
                    puVar21 = puVar43;
                    if (bVar57 != iVar25 < 0) {
                        puVar21 = puVar37;
                    }
                    uVar19 = *puVar21;
                    bVar58 = SBORROW4(iVar15, iVar49);
                    iVar25 = iVar15 - iVar49;
                    bVar57 = iVar15 == iVar49;
                    if (bVar57) {
                        iVar15 = *(int32_t *)((int64_t)puVar43 + 4);
                        iVar49 = *(int32_t *)((int64_t)puVar37 + 4);
                        bVar58 = SBORROW4(iVar49, iVar15);
                        iVar25 = iVar49 - iVar15;
                        bVar57 = iVar49 == iVar15;
                    }
                    puVar21 = puVar43;
                    if (!bVar57 && bVar58 == iVar25 < 0) {
                        puVar21 = puVar37;
                    }
                    *(float *)(puVar41 + 0x50) = fVar68;
                    iVar15 = *(int32_t *)puVar21;
                    *(undefined8 *)(puVar41 + -8) = 0x180152544;
                    uVar16 = func_0x00018046e060((float)(iVar15 + 1) * fVar61 + fVar63);
                    *(undefined4 *)(puVar41 + 0x54) = uVar16;
                    *(float *)(puVar41 + 0x68) = fVar67;
                    *(undefined8 *)(puVar41 + -8) = 0x180152566;
                    uVar16 = func_0x00018046e060((float)(int32_t)uVar19 * fVar61 + fVar63);
                    *(undefined4 *)(puVar41 + 0x6c) = uVar16;
                    *(undefined4 *)(puVar41 + 0x28) = 0;
                    *(undefined4 *)(puVar41 + 0x20) = 0;
                    uVar16 = *(undefined4 *)(arg1 + 0x5b8);
                    *(undefined8 *)(puVar41 + -8) = 0x180152595;
                    func_0x000180126550(iVar18, puVar41 + 0x68, puVar41 + 0x50, uVar16);
                    puVar37 = (undefined8 *)((int64_t)puVar37 + 0x14);
                    puVar43 = (undefined8 *)((int64_t)puVar43 + 0x14);
                } while (puVar37 != puVar38);
            }
            uVar55 = 0;
            if ((*(int32_t **)(arg1 + 0x30) != *(int32_t **)(arg1 + 0x28)) &&
               (piVar39 = *(int32_t **)(arg1 + 0x40),
               ((int64_t)*(int32_t **)(arg1 + 0x48) - (int64_t)piVar39 >> 3) * 0x6db6db6db6db6db7 != 0)) {
                do {
                    if (*(int64_t *)(piVar39 + uVar55 * 0xe + 8) != 0) {
                        iVar15 = (*(int32_t **)(arg1 + 0x28))[*(int64_t *)(piVar39 + uVar55 * 0xe + 8) * 0x12 + -0x11];
                        if (iVar15 == 0) {
                            iVar15 = (*(int32_t **)(arg1 + 0x28))
                                     [*(int64_t *)(piVar39 + uVar55 * 0xe + 8) * 0x12 + -0x12];
                        }
                        if ((int64_t)uVar55 < 0) {
                            fVar65 = (float)(uVar55 >> 1 | (uint64_t)((uint32_t)uVar55 & 1));
                            fVar65 = fVar65 + fVar65;
                        } else {
                            fVar65 = (float)uVar55;
                        }
                        *(undefined8 *)(puVar41 + -8) = 0x18015264e;
                        fVar65 = (float)func_0x00018046e060(fVar65 * fVar61 + fVar63);
                        *(float *)(puVar41 + 0x50) = fVar68;
                        *(float *)(puVar41 + 0x54) = fVar65 + fVar61;
                        *(float *)(puVar41 + 0x68) = fVar67;
                        *(float *)(puVar41 + 0x6c) = fVar65;
                        *(undefined4 *)(puVar41 + 0x28) = 0;
                        *(undefined4 *)(puVar41 + 0x20) = 0;
                        *(undefined8 *)(puVar41 + -8) = 0x180152690;
                        func_0x000180126550(iVar18, puVar41 + 0x68, puVar41 + 0x50, iVar15);
                    }
                    uVar55 = uVar55 + 1;
                    piVar39 = *(int32_t **)(arg1 + 0x40);
                } while (uVar55 < (uint64_t)
                                  (((int64_t)*(int32_t **)(arg1 + 0x48) - (int64_t)piVar39 >> 3) * 0x6db6db6db6db6db7));
            }
            piVar39 = (int32_t *)(iVar18 + 0xa0);
            *piVar39 = *piVar39 + -1;
            if (*piVar39 == 0) {
                puVar22 = (undefined4 *)(*(int64_t *)(iVar18 + 0x38) + 0x38);
            } else {
                puVar22 = (undefined4 *)
                          ((int64_t)(*(int32_t *)(iVar18 + 0xa0) + -1) * 0x10 + *(int64_t *)(iVar18 + 0xa8));
            }
            uVar16 = puVar22[1];
            uVar4 = puVar22[2];
            uVar8 = puVar22[3];
            *(undefined4 *)(iVar18 + 0x60) = *puVar22;
            *(undefined4 *)(iVar18 + 100) = uVar16;
            *(undefined4 *)(iVar18 + 0x68) = uVar4;
            *(undefined4 *)(iVar18 + 0x6c) = uVar8;
            *(undefined8 *)(puVar41 + -8) = 0x1801526eb;
            func_0x0001801242c0(iVar18);
            uVar26 = *(uint64_t *)0x180781f28;
        }
    }
    piVar39 = (int32_t *)0x0;
    if ((*(char *)(arg1 + 0x490) != '\0') && ((*(char *)(arg1 + 0x485) != '\0' || (*(char *)(arg1 + 0x486) != '\0')))) {
        *(undefined *)(*(int64_t *)(uVar26 + 0x15e0) + 0x10b) = 1;
        iVar18 = *(int64_t *)(uVar26 + 0x15e0);
        iVar5 = *(int64_t *)(iVar18 + 800);
        fVar63 = *(float *)(iVar18 + 0x6c) * 0.5 + *(float *)(iVar18 + 100);
        fVar61 = *(float *)(iVar18 + 0x68) * 0.5 + *(float *)(iVar18 + 0x60);
        *(float *)(puVar41 + 0x58) = fVar61;
        *(float *)(puVar41 + 0x5c) = fVar63;
        *(undefined4 *)(puVar41 + 0x20) = 0x30;
        *(undefined8 *)(puVar41 + -8) = 0x180152790;
        func_0x0001801257a0(iVar5, puVar41 + 0x58);
        *(int32_t *)(iVar5 + 0x50) = *(int32_t *)(iVar5 + 0x50) + -1;
        *(undefined8 *)(puVar41 + -8) = 0x1801527a0;
        func_0x0001800f3bc0(iVar5, 0xa0ffffff);
        *(undefined4 *)(puVar41 + 0x20) = 0x30;
        *(undefined8 *)(puVar41 + -8) = 0x1801527c0;
        func_0x0001801257a0(iVar5, puVar41 + 0x58);
        *(int32_t *)(iVar5 + 0x50) = *(int32_t *)(iVar5 + 0x50) + -1;
        *(undefined4 *)(puVar41 + 0x28) = 0x40000000;
        *(undefined4 *)(puVar41 + 0x20) = 1;
        uVar16 = *(undefined4 *)(iVar5 + 0x50);
        uVar19 = *(undefined8 *)(iVar5 + 0x58);
        *(undefined8 *)(puVar41 + -8) = 0x1801527f2;
        func_0x0001801248e0(iVar5, uVar19, uVar16, 0xa0000000);
        *(undefined4 *)(iVar5 + 0x50) = 0;
        uStack_1e8 = (int32_t *)CONCAT44(fVar63 + 4.0, fVar61 - 8.0);
        *(float *)(puVar41 + 0x68) = fVar61 - 8.0;
        *(float *)(puVar41 + 0x6c) = fVar63 - 4.0;
        *(float *)(puVar41 + 0x50) = fVar61 - 15.0;
        *(float *)(puVar41 + 0x54) = fVar63;
        if (*(int32_t *)(iVar5 + 0x54) == 0) {
            *(undefined8 *)(puVar41 + -8) = 0x180152867;
            func_0x00018011f4f0(iVar5 + 0x50, 8);
        }
        *(undefined8 *)(*(int64_t *)(iVar5 + 0x58) + (int64_t)*(int32_t *)(iVar5 + 0x50) * 8) =
             *(undefined8 *)(puVar41 + 0x50);
        *(int32_t *)(iVar5 + 0x50) = *(int32_t *)(iVar5 + 0x50) + 1;
        iVar15 = *(int32_t *)(iVar5 + 0x54);
        if (*(int32_t *)(iVar5 + 0x50) == iVar15) {
            iVar49 = *(int32_t *)(iVar5 + 0x50) + 1;
            iVar25 = iVar14;
            if (iVar15 != 0) {
                iVar25 = iVar15 / 2 + iVar15;
            }
            if (iVar49 < iVar25) {
                iVar49 = iVar25;
            }
            *(undefined8 *)(puVar41 + -8) = 0x1801528af;
            func_0x00018011f4f0(iVar5 + 0x50, iVar49);
        }
        *(undefined8 *)(*(int64_t *)(iVar5 + 0x58) + (int64_t)*(int32_t *)(iVar5 + 0x50) * 8) =
             *(undefined8 *)(puVar41 + 0x68);
        *(int32_t *)(iVar5 + 0x50) = *(int32_t *)(iVar5 + 0x50) + 1;
        iVar15 = *(int32_t *)(iVar5 + 0x54);
        if (*(int32_t *)(iVar5 + 0x50) == iVar15) {
            iVar49 = *(int32_t *)(iVar5 + 0x50) + 1;
            if (iVar15 != 0) {
                iVar14 = iVar15 + iVar15 / 2;
            }
            if (iVar49 < iVar14) {
                iVar49 = iVar14;
            }
            *(undefined8 *)(puVar41 + -8) = 0x1801528f4;
            func_0x00018011f4f0(iVar5 + 0x50, iVar49);
        }
        *(int32_t **)(*(int64_t *)(iVar5 + 0x58) + (int64_t)*(int32_t *)(iVar5 + 0x50) * 8) = uStack_1e8;
        *(int32_t *)(iVar5 + 0x50) = *(int32_t *)(iVar5 + 0x50) + 1;
        *(undefined4 *)(puVar41 + 0x28) = 0x40000000;
        *(undefined4 *)(puVar41 + 0x20) = 1;
        uVar16 = *(undefined4 *)(iVar5 + 0x50);
        uVar19 = *(undefined8 *)(iVar5 + 0x58);
        *(undefined8 *)(puVar41 + -8) = 0x180152928;
        func_0x0001801248e0(iVar5, uVar19, uVar16, 0xa0000000);
        *(undefined4 *)(iVar5 + 0x50) = 0;
        *(float *)(puVar41 + 0x50) = fVar61 + 8.0;
        *(float *)(puVar41 + 0x54) = fVar63 + 4.0;
        *(float *)(puVar41 + 0x68) = fVar61 + 8.0;
        *(float *)(puVar41 + 0x6c) = fVar63 - 4.0;
        uStack_1e8 = (int32_t *)CONCAT44(fVar63, fVar61 + 15.0);
        *(undefined4 *)(puVar41 + 0x28) = 0x40000000;
        *(undefined4 *)(puVar41 + 0x20) = 0xa0000000;
        *(undefined8 *)(puVar41 + -8) = 0x180152998;
        func_0x0001801266e0(iVar5, &uStack_1e8, puVar41 + 0x68, puVar41 + 0x50);
        *(float *)(puVar41 + 0x50) = fVar61 + 4.0;
        *(float *)(puVar41 + 0x54) = fVar63 - 8.0;
        *(float *)(puVar41 + 0x68) = fVar61 - 4.0;
        *(float *)(puVar41 + 0x6c) = fVar63 - 8.0;
        uStack_1e8 = (int32_t *)CONCAT44(fVar63 - 15.0, fVar61);
        *(undefined4 *)(puVar41 + 0x28) = 0x40000000;
        *(undefined4 *)(puVar41 + 0x20) = 0xa0000000;
        *(undefined8 *)(puVar41 + -8) = 0x180152a04;
        func_0x0001801266e0(iVar5, &uStack_1e8, puVar41 + 0x68, puVar41 + 0x50);
        *(float *)(puVar41 + 0x50) = fVar61 + 4.0;
        *(float *)(puVar41 + 0x54) = fVar63 + 8.0;
        *(float *)(puVar41 + 0x68) = fVar61 - 4.0;
        *(float *)(puVar41 + 0x6c) = fVar63 + 8.0;
        uStack_1e8 = (int32_t *)CONCAT44(fVar63 + 15.0, fVar61);
        *(undefined4 *)(puVar41 + 0x28) = 0x40000000;
        *(undefined4 *)(puVar41 + 0x20) = 0xa0000000;
        *(undefined8 *)(puVar41 + -8) = 0x180152a5b;
        func_0x0001801266e0(iVar5, &uStack_1e8, puVar41 + 0x68, puVar41 + 0x50);
    }
    *(undefined8 *)(puVar41 + -8) = 0x180152a70;
    cVar9 = func_0x00018010d550(0x180645ce8, 0);
    if (cVar9 != '\0') {
        uVar16 = *(undefined4 *)(arg1 + 0x3a0);
        *(undefined8 *)(puVar41 + -8) = 0x180152a89;
        func_0x000180163ae0((int32_t **)(arg1 + 800), uVar16);
        *(undefined8 *)(puVar41 + -8) = 0x180152a8e;
        func_0x00018010d5c0();
    }
    *(undefined8 *)(puVar41 + -8) = 0x180152a9c;
    cVar9 = func_0x00018010d550(0x180645d00, 0);
    if (cVar9 != '\0') {
        uVar16 = *(undefined4 *)(arg1 + 0x3a4);
        uVar4 = *(undefined4 *)(arg1 + 0x3a0);
        *(undefined8 *)(puVar41 + -8) = 0x180152abd;
        func_0x000180163aa0((int32_t **)(arg1 + 0x360), uVar4, uVar16);
        *(undefined8 *)(puVar41 + -8) = 0x180152ac2;
        func_0x00018010d5c0();
    }
    if (*(char *)(arg1 + 0x428) != '\0') {
        fVar63 = (float)uStack_1b0 - *(float *)(arg1 + 700);
        uVar16 = *(undefined4 *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x158);
        uVar4 = *(undefined4 *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x15c);
        *(undefined4 *)(puVar41 + 0x50) = 0x40c00000;
        *(undefined4 *)(puVar41 + 0x54) = 0x40800000;
        *(undefined8 *)(puVar41 + -8) = 0x180152b20;
        func_0x0001800f6960(0xe, puVar41 + 0x50);
        uVar55 = *(uint64_t *)0x180781f28;
        ppiVar32 = (int32_t **)(arg1 + 0x3a8);
        if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x3c0)) {
            ppiVar32 = (int32_t **)*ppiVar32;
        }
        *(undefined4 *)(puVar41 + 0x20) = 0xbf800000;
        *(undefined8 *)(puVar41 + -8) = 0x180152b58;
        pfVar17 = (float *)func_0x0001800fe0a0(&piStack_1c0, ppiVar32, 0, 0);
        fVar61 = *(float *)(uVar55 + 0xdec) + *(float *)(uVar55 + 0xdec) + *pfVar17;
        ppiVar32 = (int32_t **)(arg1 + 0x3c8);
        if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x3e0)) {
            ppiVar32 = (int32_t **)*ppiVar32;
        }
        *(undefined4 *)(puVar41 + 0x20) = 0xbf800000;
        *(undefined8 *)(puVar41 + -8) = 0x180152b90;
        pfVar17 = (float *)func_0x0001800fe0a0(&piStack_1c0, ppiVar32, 0, 0);
        fVar67 = *(float *)(uVar55 + 0xdec) + *(float *)(uVar55 + 0xdec) + *pfVar17;
        *(undefined4 *)(puVar41 + 0x20) = 0xbf800000;
        *(undefined8 *)(puVar41 + -8) = 0x180152bc0;
        pfVar17 = (float *)func_0x0001800fe0a0(&piStack_1c0, 0x180645d10, 0, 0);
        fVar65 = *(float *)(uVar55 + 0xdec);
        fVar60 = fVar65 + fVar65 + *pfVar17;
        fVar66 = fVar61;
        fVar68 = fVar67;
        if (*(char *)(arg1 + 0x264) == '\0') {
            ppiVar32 = (int32_t **)(arg1 + 1000);
            if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x400)) {
                ppiVar32 = (int32_t **)*ppiVar32;
            }
            *(undefined4 *)(puVar41 + 0x20) = 0xbf800000;
            *(undefined8 *)(puVar41 + -8) = 0x180152c0e;
            pfVar17 = (float *)func_0x0001800fe0a0(puVar41 + 0x50, ppiVar32, 0, 0);
            fVar66 = *(float *)(uVar55 + 0xdec) + *(float *)(uVar55 + 0xdec) + *pfVar17;
            if (fVar66 <= fVar61) {
                fVar66 = fVar61;
            }
            ppiVar32 = (int32_t **)(arg1 + 0x408);
            if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x420)) {
                ppiVar32 = (int32_t **)*ppiVar32;
            }
            *(undefined4 *)(puVar41 + 0x20) = 0xbf800000;
            *(undefined8 *)(puVar41 + -8) = 0x180152c4b;
            pfVar17 = (float *)func_0x0001800fe0a0(puVar41 + 0x50, ppiVar32, 0, 0);
            fVar65 = *(float *)(uVar55 + 0xdec);
            fVar68 = fVar65 + fVar65 + *pfVar17;
            if (fVar68 <= fVar67) {
                fVar68 = fVar67;
            }
        }
        uVar26 = *(uint64_t *)0x180781f28;
        if (*(char *)(arg1 + 0x264) == '\0') {
            fVar61 = *(float *)(*(uint64_t *)0x180781f28 + 0xde0) + *(float *)(*(uint64_t *)0x180781f28 + 0xde0) +
                     *(float *)(*(uint64_t *)0x180781f28 + 0x12f8) + *(float *)(uVar55 + 0xdf0);
        } else {
            fVar61 = 0.0;
        }
        fVar67 = *(float *)(uVar55 + 0xdd0) + *(float *)(uVar55 + 0xdd0);
        fVar61 = *(float *)(*(uint64_t *)0x180781f28 + 0xde0) + *(float *)(*(uint64_t *)0x180781f28 + 0xde0) +
                 *(float *)(*(uint64_t *)0x180781f28 + 0x12f8) +
                 *(float *)(uVar55 + 0xda8) + *(float *)(uVar55 + 0xda8) + fVar67 + fVar61;
        fVar64 = *(float *)(uVar55 + 0xda4) + *(float *)(uVar55 + 0xda4) + fVar67 + 250.0 + fVar65 + fVar66 + fVar65 +
                 fVar68 + fVar65 + fVar60 * 3.0 + fVar65 + fVar65;
        fVar67 = *(float *)(uVar55 + 0xdf0);
        *(float *)(*(uint64_t *)0x180781f28 + 0x201c) = (((float)uStack_188 + fVar63) - fVar64) - fVar65;
        *(float *)(uVar26 + 0x2020) = fVar67 + fVar67 + (float)uStack_1a8;
        *(undefined8 *)(uVar26 + 0x2024) = 0;
        *(undefined4 *)(uVar26 + 0x200c) = 1;
        *(undefined *)(uVar26 + 0x204c) = 1;
        *(float *)(uVar26 + 0x202c) = fVar64;
        *(float *)(uVar26 + 0x2030) = fVar61;
        *(undefined4 *)(uVar26 + 0x2010) = 1;
        *(uint32_t *)(uVar26 + 0x2008) = *(uint32_t *)(uVar26 + 0x2008) | 0x43;
        *(undefined4 *)(uVar26 + 0x2070) = 0x3f400000;
        *(float *)(puVar41 + 0x50) = fVar64;
        *(float *)(puVar41 + 0x54) = fVar61;
        *(undefined8 *)(puVar41 + -8) = 0x180152db4;
        func_0x0001800fe660(0x180645d18, puVar41 + 0x50, 1, 0);
        uVar55 = *(uint64_t *)0x180781f28;
        *(uint32_t *)(*(uint64_t *)0x180781f28 + 0x1f80) = *(uint32_t *)(*(uint64_t *)0x180781f28 + 0x1f80) | 1;
        *(undefined4 *)(uVar55 + 0x1f98) = 0x437a0000;
        if (*(char *)(arg1 + 0x42a) == '\0') {
            if (*(char *)(arg1 + 0x42b) != '\0') {
                *(undefined8 *)(puVar41 + -8) = 0x180152df7;
                func_0x000180106a00();
                *(undefined *)(arg1 + 0x42b) = 0;
            }
        } else {
            *(undefined8 *)(puVar41 + -8) = 0x180152ddc;
            func_0x000180106a00();
            *(undefined *)(arg1 + 0x42a) = 0;
        }
        ppiVar23 = (int64_t **)(arg1 + 0x430);
        piVar24 = *(int32_t **)(arg1 + 0x448);
        ppiVar50 = ppiVar23;
        if ((int32_t *)0xf < piVar24) {
            ppiVar50 = (int64_t **)*ppiVar23;
        }
        *(undefined8 *)(puVar41 + 0x50) = 0;
        *(int64_t ***)(puVar41 + 0x38) = ppiVar23;
        *(undefined8 *)(puVar41 + 0x30) = 0x1801604a0;
        *(undefined4 *)(puVar41 + 0x28) = 0x411000;
        *(undefined **)(puVar41 + 0x20) = puVar41 + 0x50;
        *(undefined8 *)(puVar41 + -8) = 0x180152e56;
        cVar9 = func_0x0001801431e0(0x180645cb8, 0, ppiVar50, (int64_t)piVar24 + 1);
        if (cVar9 != '\0') {
            if (*(int32_t **)(arg1 + 0x440) == (int32_t *)0x0) {
                *(undefined8 *)(puVar41 + -8) = 0x180152f1b;
                func_0x00018015c180(arg1);
            } else {
                uVar11 = *(undefined *)(arg1 + 0x471);
                if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x448)) {
                    ppiVar23 = (int64_t **)*ppiVar23;
                }
                uStack_1d0 = *(int32_t **)(arg1 + 0x440);
                *(undefined8 *)(puVar41 + 0x58) = 0;
                uStack_1b0 = 0;
                *(undefined8 *)(puVar41 + 0x50) = 0;
                *(undefined8 **)(puVar41 + 0x30) = &uStack_1b0;
                *(undefined **)(puVar41 + 0x28) = puVar41 + 0x58;
                puVar41[0x20] = uVar11;
                uVar11 = *(undefined *)(arg1 + 0x470);
                *(undefined8 *)(puVar41 + -8) = 0x180152ede;
                uStack_1d8 = (int32_t **)ppiVar23;
                cVar9 = func_0x00018015df90((int32_t **)(arg1 + 0x40), *(undefined8 *)(puVar41 + 0x50), &uStack_1d8, 
                                            uVar11);
                if (cVar9 == '\0') {
                    *(undefined8 *)(puVar41 + -8) = 0x180152f11;
                    func_0x00018015c350(arg1, 1);
                } else {
                    *(undefined8 *)(puVar41 + -8) = 0x180152ef3;
                    func_0x00018015c080(arg1, *(undefined8 *)(puVar41 + 0x58), uStack_1b0);
                    *(undefined *)(arg1 + 0x2c8) = 1;
                    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
                }
            }
        }
        *(undefined8 *)(puVar41 + -8) = 0x180152f20;
        cVar9 = func_0x0001800fe620();
        if (cVar9 != '\0') {
            *(undefined8 *)(puVar41 + -8) = 0x180152f33;
            cVar9 = func_0x000180107dc0(0x20e, 1, 0);
            if (cVar9 == '\0') {
                *(undefined8 *)(puVar41 + -8) = 0x180152f5c;
                cVar9 = func_0x000180107dc0(0x20d, 1, 0);
                if (cVar9 == '\0') {
                    *(undefined8 *)(puVar41 + -8) = 0x180152f6f;
                    cVar9 = func_0x000180107dc0(0x273, 1, 0);
                    if (cVar9 == '\0') goto code_r0x000180152f7e;
                }
                *(undefined2 *)(arg1 + 0x429) = 1;
            } else {
                *(undefined2 *)(arg1 + 0x428) = 0x100;
                *(undefined *)(arg1 + 0x42a) = 0;
            }
        }
code_r0x000180152f7e:
        piVar24 = *(int32_t **)(arg1 + 0x440);
        if (piVar24 == (int32_t *)0x0) {
            *(undefined8 *)(puVar41 + -8) = 0x180152f92;
            func_0x000180106080(1);
        }
        *(undefined8 *)(puVar41 + -8) = 0x180152f9f;
        func_0x00018010bd60();
        *(float *)(puVar41 + 0x50) = fVar66;
        *(undefined4 *)(puVar41 + 0x54) = 0;
        ppiVar32 = (int32_t **)(arg1 + 0x3a8);
        if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x3c0)) {
            ppiVar32 = (int32_t **)*ppiVar32;
        }
        *(undefined8 *)(puVar41 + -8) = 0x180152fcc;
        cVar9 = func_0x00018013a5c0(ppiVar32, puVar41 + 0x50, 0);
        if (cVar9 != '\0') {
            *(undefined8 *)(puVar41 + -8) = 0x180152fd8;
            func_0x000180160f50(arg1);
        }
        *(undefined8 *)(puVar41 + -8) = 0x180152fe5;
        func_0x00018010bd60();
        *(float *)(puVar41 + 0x50) = fVar68;
        *(undefined4 *)(puVar41 + 0x54) = 0;
        ppiVar32 = (int32_t **)(arg1 + 0x3c8);
        if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x3e0)) {
            ppiVar32 = (int32_t **)*ppiVar32;
        }
        *(undefined8 *)(puVar41 + -8) = 0x180153012;
        cVar9 = func_0x00018013a5c0(ppiVar32, puVar41 + 0x50, 0);
        if (cVar9 != '\0') {
            *(undefined8 *)(puVar41 + -8) = 0x18015301e;
            func_0x000180160fb0(arg1);
        }
        if (piVar24 == (int32_t *)0x0) {
            *(undefined8 *)(puVar41 + -8) = 0x180153028;
            func_0x000180106130();
        }
        *(undefined8 *)(puVar41 + -8) = 0x180153035;
        func_0x00018010bd60();
        *(float *)(puVar41 + 0x50) = fVar60;
        *(undefined4 *)(puVar41 + 0x54) = 0;
        *(undefined8 *)(puVar41 + -8) = 0x18015305d;
        cVar9 = func_0x000180160230(0x180645d10, (int32_t **)(arg1 + 0x470), puVar41 + 0x50);
        if (cVar9 != '\0') {
            *(undefined8 *)(puVar41 + -8) = 0x180153069;
            func_0x000180160f50(arg1);
        }
        *(undefined8 *)(puVar41 + -8) = 0x180153076;
        func_0x00018010bd60();
        *(float *)(puVar41 + 0x50) = fVar60;
        *(undefined4 *)(puVar41 + 0x54) = 0;
        *(undefined8 *)(puVar41 + -8) = 0x18015309e;
        cVar9 = func_0x000180160230(0x180645cc0, arg1 + 0x471, puVar41 + 0x50);
        if (cVar9 != '\0') {
            *(undefined8 *)(puVar41 + -8) = 0x1801530aa;
            func_0x000180160f50(arg1);
        }
        *(undefined8 *)(puVar41 + -8) = 0x1801530b7;
        func_0x00018010bd60();
        *(float *)(puVar41 + 0x50) = fVar60;
        *(undefined4 *)(puVar41 + 0x54) = 0;
        *(undefined8 *)(puVar41 + -8) = 0x1801530da;
        cVar9 = func_0x00018013a5c0(0x180640a14, puVar41 + 0x50, 0);
        if (cVar9 != '\0') {
            *(undefined2 *)(arg1 + 0x428) = 0x100;
            *(undefined *)(arg1 + 0x42a) = 0;
        }
        uVar55 = *(uint64_t *)0x180781f28;
        if (*(char *)(arg1 + 0x264) == '\0') {
            *(uint32_t *)(*(uint64_t *)0x180781f28 + 0x1f80) = *(uint32_t *)(*(uint64_t *)0x180781f28 + 0x1f80) | 1;
            *(undefined4 *)(uVar55 + 0x1f98) = 0x437a0000;
            *(undefined8 *)(puVar41 + -8) = 0x180153130;
            func_0x000180160440(0x180645cc8, (int32_t **)(arg1 + 0x450), 0);
            *(undefined8 *)(puVar41 + -8) = 0x18015313d;
            func_0x00018010bd60();
            if ((*(int32_t **)(arg1 + 0x440) == (int32_t *)0x0) || (*(int32_t **)(arg1 + 0x460) == (int32_t *)0x0)) {
                bVar57 = true;
                *(undefined8 *)(puVar41 + -8) = 0x180153164;
                func_0x000180106080(1);
            } else {
                bVar57 = false;
            }
            *(float *)(puVar41 + 0x50) = fVar66;
            *(undefined4 *)(puVar41 + 0x54) = 0;
            ppiVar32 = (int32_t **)(arg1 + 1000);
            if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x400)) {
                ppiVar32 = (int32_t **)*ppiVar32;
            }
            *(undefined8 *)(puVar41 + -8) = 0x180153191;
            cVar9 = func_0x00018013a5c0(ppiVar32, puVar41 + 0x50, 0);
            if ((cVar9 != '\0') && (*(int32_t **)(arg1 + 0x440) != (int32_t *)0x0)) {
                for (piVar24 = *(int32_t **)arg1; piVar24 != *(int32_t **)(arg1 + 8); piVar24 = piVar24 + 5) {
                    cVar9 = -1;
                    if (*(int32_t **)(arg1 + 8) <= piVar24) {
                        cVar9 = '\x01';
                    }
                    if (-1 < cVar9) break;
                    if ((*piVar24 != piVar24[2]) || (piVar24[1] != piVar24[3])) goto code_r0x000180153222;
                }
                if (*(int32_t **)(arg1 + 0x448) < (int32_t *)0x10) {
                    uStack_1d8 = (int32_t **)(arg1 + 0x430);
                } else {
                    uStack_1d8 = *(int32_t ***)(arg1 + 0x430);
                }
                uStack_1d0 = *(int32_t **)(arg1 + 0x440);
                uVar11 = *(undefined *)(arg1 + 0x471);
                uVar1 = *(undefined *)(arg1 + 0x470);
                *(undefined8 *)(puVar41 + -8) = 0x180153222;
                func_0x0001801604f0(arg1, &uStack_1d8, uVar1, uVar11);
code_r0x000180153222:
                if (*(int32_t **)(arg1 + 0x468) < (int32_t *)0x10) {
                    uStack_168 = (int32_t **)(arg1 + 0x450);
                } else {
                    uStack_168 = *(int32_t ***)(arg1 + 0x450);
                }
                piStack_160 = *(int32_t **)(arg1 + 0x460);
                *(undefined8 *)(puVar41 + -8) = 0x18015325e;
                func_0x00018015aea0(arg1, &uStack_1d8, 1);
                puVar37 = (undefined8 *)(*(int32_t **)arg1 + (int64_t)*(int32_t **)(arg1 + 0x20) * 5);
                iVar14 = *(int32_t *)puVar37;
                iVar15 = *(int32_t *)(puVar37 + 1);
                bVar58 = SBORROW4(iVar14, iVar15);
                iVar49 = iVar14 - iVar15;
                if (iVar14 == iVar15) {
                    iVar49 = *(int32_t *)((int64_t)puVar37 + 0xc);
                    bVar58 = SBORROW4(*(int32_t *)((int64_t)puVar37 + 4), iVar49);
                    iVar49 = *(int32_t *)((int64_t)puVar37 + 4) - iVar49;
                }
                puVar38 = puVar37 + 1;
                if (bVar58 != iVar49 < 0) {
                    puVar38 = puVar37;
                }
                uVar19 = *puVar38;
                bVar59 = SBORROW4(iVar14, iVar15);
                iVar49 = iVar14 - iVar15;
                bVar58 = iVar14 == iVar15;
                if (bVar58) {
                    iVar14 = *(int32_t *)((int64_t)puVar37 + 0xc);
                    iVar15 = *(int32_t *)((int64_t)puVar37 + 4);
                    bVar59 = SBORROW4(iVar15, iVar14);
                    iVar49 = iVar15 - iVar14;
                    bVar58 = iVar15 == iVar14;
                }
                puVar38 = puVar37;
                if (bVar58 || bVar59 != iVar49 < 0) {
                    puVar38 = puVar37 + 1;
                }
                uVar48 = *puVar38;
                if (uStack_1d0 != (int32_t *)0x0) {
                    LOCK();
                    uStack_1d0[2] = uStack_1d0[2] + 1;
                    UNLOCK();
                }
                auStack_118._8_4_ = (float)uStack_1d0;
                auStack_118._0_8_ = uStack_1d8;
                uStack_10c = uStack_1d0._4_4_;
                *(undefined8 *)(puVar41 + -8) = 0x1801532df;
                func_0x00018015bca0(arg1, auStack_118, uVar19, uVar48);
                *(undefined8 *)(puVar41 + -8) = 0x1801532f0;
                func_0x00018015c720(arg1, puVar37, uVar19, uVar48);
                if (uStack_1d0 != (int32_t *)0x0) {
                    LOCK();
                    uStack_1d0[2] = uStack_1d0[2] + 1;
                    UNLOCK();
                }
                auStack_118._8_4_ = (float)uStack_1d0;
                auStack_118._0_8_ = uStack_1d8;
                uStack_10c = uStack_1d0._4_4_;
                *(undefined8 **)(puVar41 + 0x20) = &uStack_168;
                *(undefined8 *)(puVar41 + -8) = 0x18015332b;
                func_0x00018015bbd0(arg1, puVar41 + 0x50, auStack_118, uVar19);
                uVar48 = *(undefined8 *)(puVar41 + 0x50);
                *puVar37 = uVar48;
                puVar37[1] = uVar48;
                *(undefined *)((int64_t)puVar37 + 0x12) = 1;
                *(undefined8 *)(puVar41 + -8) = 0x180153349;
                func_0x00018015c690(arg1, puVar37, uVar19);
                if (uStack_1d0 != (int32_t *)0x0) {
                    LOCK();
                    uStack_1d0[2] = uStack_1d0[2] + 1;
                    UNLOCK();
                }
                auStack_118._8_4_ = (float)uStack_1d0;
                auStack_118._0_8_ = uStack_1d8;
                uStack_10c = uStack_1d0._4_4_;
                *(undefined8 *)(puVar41 + -8) = 0x180153373;
                func_0x00018015af60(arg1, auStack_118);
                if (uStack_1d0 != (int32_t *)0x0) {
                    *(undefined8 *)(puVar41 + -8) = 0x180153382;
                    func_0x000180005cf0();
                }
                if (*(int32_t **)(arg1 + 0x448) < (int32_t *)0x10) {
                    uStack_1d8 = (int32_t **)(arg1 + 0x430);
                } else {
                    uStack_1d8 = *(int32_t ***)(arg1 + 0x430);
                }
                uStack_1d0 = *(int32_t **)(arg1 + 0x440);
                uVar11 = *(undefined *)(arg1 + 0x471);
                uVar1 = *(undefined *)(arg1 + 0x470);
                *(undefined8 *)(puVar41 + -8) = 0x1801533cd;
                func_0x0001801604f0(arg1, &uStack_1d8, uVar1, uVar11);
                *(undefined2 *)(arg1 + 0x429) = 1;
            }
            *(undefined8 *)(puVar41 + -8) = 0x1801533ea;
            func_0x00018010bd60();
            *(float *)(puVar41 + 0x50) = fVar68;
            *(undefined4 *)(puVar41 + 0x54) = 0;
            ppiVar32 = (int32_t **)(arg1 + 0x408);
            if ((int32_t *)0xf < *(int32_t **)(arg1 + 0x420)) {
                ppiVar32 = (int32_t **)*ppiVar32;
            }
            *(undefined8 *)(puVar41 + -8) = 0x180153417;
            cVar9 = func_0x00018013a5c0(ppiVar32, puVar41 + 0x50, 0);
            if ((cVar9 != '\0') && (*(int32_t **)(arg1 + 0x440) != (int32_t *)0x0)) {
                if (*(int32_t **)(arg1 + 0x448) < (int32_t *)0x10) {
                    uStack_1d8 = (int32_t **)(arg1 + 0x430);
                } else {
                    uStack_1d8 = *(int32_t ***)(arg1 + 0x430);
                }
                uStack_1d0 = *(int32_t **)(arg1 + 0x440);
                uVar11 = *(undefined *)(arg1 + 0x471);
                uVar1 = *(undefined *)(arg1 + 0x470);
                *(undefined8 *)(puVar41 + -8) = 0x180153479;
                func_0x000180160630(arg1, &uStack_1d8, uVar1, uVar11);
                if (*(int32_t **)(arg1 + 0x468) < (int32_t *)0x10) {
                    uStack_168 = (int32_t **)(arg1 + 0x450);
                } else {
                    uStack_168 = *(int32_t ***)(arg1 + 0x450);
                }
                piStack_160 = *(int32_t **)(arg1 + 0x460);
                *(undefined8 *)(puVar41 + -8) = 0x1801534b5;
                func_0x00018015aea0(arg1, &uStack_1d8, 1);
                if (uStack_1d0 != (int32_t *)0x0) {
                    LOCK();
                    uStack_1d0[2] = uStack_1d0[2] + 1;
                    UNLOCK();
                }
                auStack_118._8_4_ = (float)uStack_1d0;
                auStack_118._0_8_ = uStack_1d8;
                uStack_10c = uStack_1d0._4_4_;
                *(undefined8 *)(puVar41 + -8) = 0x1801534e4;
                func_0x00018015b890(arg1, auStack_118, &uStack_168);
                if (uStack_1d0 != (int32_t *)0x0) {
                    LOCK();
                    uStack_1d0[2] = uStack_1d0[2] + 1;
                    UNLOCK();
                }
                auStack_118._8_4_ = (float)uStack_1d0;
                auStack_118._0_8_ = uStack_1d8;
                uStack_10c = uStack_1d0._4_4_;
                *(undefined8 *)(puVar41 + -8) = 0x18015350e;
                func_0x00018015af60(arg1, auStack_118);
                if (uStack_1d0 != (int32_t *)0x0) {
                    *(undefined8 *)(puVar41 + -8) = 0x18015351d;
                    func_0x000180005cf0();
                }
                *(undefined2 *)(arg1 + 0x429) = 1;
            }
            if (bVar57) {
                *(undefined8 *)(puVar41 + -8) = 0x180153532;
                func_0x000180106130();
            }
        }
        *(undefined8 *)(puVar41 + -8) = 0x180153537;
        func_0x0001800fea60();
        *(undefined8 *)(puVar41 + -8) = 0x18015353e;
        func_0x0001800f6a20(1);
        uVar55 = *(uint64_t *)0x180781f28;
        *(undefined *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x10b) = 1;
        iVar18 = *(int64_t *)(uVar55 + 0x15e0);
        *(undefined4 *)(iVar18 + 0x158) = uVar16;
        *(undefined4 *)(iVar18 + 0x15c) = uVar4;
        *(undefined *)(iVar18 + 0x199) = 1;
    }
    ppiVar32 = (int32_t **)(arg1 + 0x130);
    fVar63 = *(float *)(arg1 + 0x27c);
    fVar61 = *(float *)(arg1 + 0x280);
    fVar65 = *(float *)(arg1 + 0x298);
    piVar24 = *(int32_t **)(arg1 + 0x5e8);
    if (*(char *)(arg1 + 0x132) != '\0') {
        *(undefined8 *)(puVar41 + -8) = 0x1801535bc;
        piVar33 = (int32_t *)func_0x00018045838c();
        if ((piVar33 != *(int32_t **)(arg1 + 0x148)) && ((int64_t)*(int32_t **)(arg1 + 0x148) <= (int64_t)piVar33)) {
            *(undefined *)(arg1 + 0x132) = 0;
            uVar19 = *(undefined8 *)(arg1 + 0x134);
            *(undefined8 *)(puVar41 + -8) = 0x1801535de;
            puVar37 = (undefined8 *)func_0x00018015db90((int32_t **)(arg1 + 0x40), &piStack_1c0, uVar19, 1);
            *(undefined8 *)(arg1 + 0x13c) = *puVar37;
            *(undefined8 *)(puVar41 + -8) = 0x1801535f5;
            func_0x0001801610a0(ppiVar32, (int32_t **)(arg1 + 0x40), piVar24);
            if (((*(char *)(arg1 + 0x21a) != '\0') && (*(char *)(arg1 + 0x152) == '\0')) ||
               ((*(char *)(arg1 + 0x21b) != '\0' && (*(char *)(arg1 + 0x153) == '\0')))) goto code_r0x000180153cea;
            *(undefined8 *)(puVar41 + -8) = 0x180153627;
            func_0x0001801612e0(ppiVar32);
            *(undefined8 *)(puVar41 + -8) = 0x180153633;
            func_0x00018010cff0(0x180645d30);
            *(undefined *)(arg1 + 0x131) = 1;
        }
    }
    if (*(char *)(arg1 + 0x131) == '\0') goto code_r0x000180153cea;
    *(undefined8 *)(puVar41 + -8) = 0x18015364b;
    puVar37 = (undefined8 *)func_0x00018014ff70(arg1);
    iVar15 = *(int32_t *)puVar37;
    iVar14 = *(int32_t *)(puVar37 + 1);
    bVar58 = SBORROW4(iVar15, iVar14);
    iVar49 = iVar15 - iVar14;
    bVar57 = iVar15 == iVar14;
    if (bVar57) {
        iVar14 = *(int32_t *)((int64_t)puVar37 + 0xc);
        iVar15 = *(int32_t *)((int64_t)puVar37 + 4);
        bVar58 = SBORROW4(iVar15, iVar14);
        iVar49 = iVar15 - iVar14;
        bVar57 = iVar15 == iVar14;
    }
    puVar38 = puVar37 + 1;
    if (!bVar57 && bVar58 == iVar49 < 0) {
        puVar38 = puVar37;
    }
    uVar19 = *puVar38;
    if (((int32_t)uVar19 != *(int32_t *)(arg1 + 0x134)) ||
       ((int32_t)((uint64_t)uVar19 >> 0x20) != *(int32_t *)(arg1 + 0x138))) {
        if ((int32_t)uVar19 == *(int32_t *)(arg1 + 0x134)) {
            *(undefined8 *)(puVar41 + -8) = 0x18015369a;
            func_0x00018015db90((int32_t **)(arg1 + 0x40), puVar41 + 0x50, uVar19, 1);
            *(undefined8 *)(puVar41 + -8) = 0x1801536a8;
            cVar9 = func_0x00018014fe60(puVar41 + 0x50, arg1 + 0x13c);
            if (cVar9 != '\0') {
                *(undefined8 *)(arg1 + 0x134) = uVar19;
                *(undefined8 *)(puVar41 + -8) = 0x1801536b9;
                cVar9 = func_0x00018014fe60(arg1 + 0x134);
                if (cVar9 == '\0') {
                    *(undefined8 *)(puVar41 + -8) = 0x1801536cd;
                    func_0x0001801610a0(ppiVar32, (int32_t **)(arg1 + 0x40), piVar24);
                    *(undefined8 *)(puVar41 + -8) = 0x1801536d5;
                    func_0x0001801612e0(ppiVar32);
                    goto code_r0x0001801536dc;
                }
            }
        }
        *(undefined *)(arg1 + 0x133) = 1;
    }
code_r0x0001801536dc:
    uVar55 = *(uint64_t *)0x180781f28;
    cVar9 = '\0';
    puVar41[0x60] = 0;
    iVar14 = *(int32_t *)(arg1 + 0x134);
    fVar66 = *(float *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x15c);
    iVar15 = *(int32_t *)(arg1 + 0x138);
    fVar68 = *(float *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x158);
    *(uint32_t *)(*(uint64_t *)0x180781f28 + 0x2008) = *(uint32_t *)(*(uint64_t *)0x180781f28 + 0x2008) | 1;
    *(float *)(uVar55 + 0x201c) = (float)iVar15 * fVar63 + fVar65 + fVar68;
    *(float *)(uVar55 + 0x2020) = (float)(iVar14 + 1) * fVar61 + fVar66;
    *(undefined8 *)(uVar55 + 0x2024) = 0;
    *(undefined4 *)(uVar55 + 0x200c) = 1;
    *(undefined *)(uVar55 + 0x204c) = 1;
    uVar26 = (int64_t)*(int32_t **)(arg1 + 0x238) - (int64_t)*(int32_t **)(arg1 + 0x230) >> 5;
    if (uVar26 == 0) {
        uVar54 = 1;
    } else {
        uVar54 = 10;
        if (uVar26 < 10) {
            uVar54 = uVar26;
        }
    }
    *(uint32_t *)(uVar55 + 0x2008) = *(uint32_t *)(uVar55 + 0x2008) | 2;
    *(undefined4 *)(uVar55 + 0x202c) = 0x437a0000;
    if ((int64_t)uVar54 < 0) {
        fVar63 = (float)(uVar54 >> 1 | (uint64_t)((uint32_t)uVar54 & 1));
        fVar63 = fVar63 + fVar63;
    } else {
        fVar63 = (float)uVar54;
    }
    *(float *)(uVar55 + 0x2030) =
         (*(float *)(uVar55 + 0xde0) + *(float *)(uVar55 + 0xde0) + *(float *)(uVar55 + 0x12f8) +
         *(float *)(uVar55 + 0xdf0)) * fVar63 + *(float *)(uVar55 + 0xda8) + *(float *)(uVar55 + 0xda8);
    *(undefined4 *)(uVar55 + 0x2010) = 1;
    *(undefined8 *)(puVar41 + -8) = 0x180153808;
    cVar10 = func_0x00018010d550(0x180645d30, 0x31000);
    if (cVar10 == '\0') {
        *(undefined *)(arg1 + 0x133) = 0;
        *(undefined *)(arg1 + 0x131) = 0;
    } else {
        if (*(char *)(*(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0) + 0x110) != '\0') {
            *(undefined8 *)(puVar41 + -8) = 0x18015382c;
            uVar19 = func_0x0001800f4500();
            *(undefined8 *)(puVar41 + -8) = 0x180153834;
            func_0x00018010dfb0(uVar19);
        }
        if (*(char *)(arg1 + 0x133) == '\0') {
            if (uVar26 == 0) {
                *(undefined8 *)(puVar41 + -8) = 0x180153c7c;
                func_0x00018010d400();
            } else {
                piVar24 = *(int32_t **)(arg1 + 0x238);
                piVar33 = *(int32_t **)(arg1 + 0x230);
                piVar46 = (int32_t *)((int64_t)piVar24 - (int64_t)piVar33 >> 5);
                *(undefined8 *)(puVar41 + -8) = 0x180153882;
                piStack_1c0 = piVar46;
                cVar9 = func_0x000180107db0(0x203, 1);
                if (cVar9 == '\0') {
                    *(undefined8 *)(puVar41 + -8) = 0x18015393f;
                    cVar9 = func_0x000180107db0(0x204, 1);
                    if (cVar9 == '\0') {
                        *(undefined8 *)(puVar41 + -8) = 0x18015397e;
                        cVar9 = func_0x000180107db0(0x200, 1);
                        if (cVar9 == '\0') {
                            *(undefined8 *)(puVar41 + -8) = 0x18015398e;
                            cVar9 = func_0x000180107db0(0x20d, 1);
                            if (cVar9 == '\0') {
                                *(undefined8 *)(puVar41 + -8) = 0x18015399e;
                                cVar9 = func_0x000180107db0(0x273, 1);
                                if ((cVar9 == '\0') &&
                                   (((*(char *)(arg1 + 0x158) == '\0' || (*(char *)(arg1 + 0x250) == '\0')) ||
                                    ((int64_t)piVar24 - (int64_t)piVar33 != 0x20)))) goto code_r0x0001801538a5;
                            }
                        }
                        *(undefined *)(arg1 + 0x133) = 1;
                        cVar9 = '\x01';
                        puVar41[0x60] = 1;
                    } else {
                        cVar9 = '\0';
                        if (*(int32_t **)(arg1 + 600) == (int32_t *)((int64_t)piVar46 + -1)) {
                            *(int32_t **)(arg1 + 600) = (int32_t *)0x0;
                            cVar9 = '\0';
                        } else {
                            *(int32_t **)(arg1 + 600) = (int32_t *)((int64_t)*(int32_t **)(arg1 + 600) + 1);
                        }
                    }
                } else {
                    piVar24 = *(int32_t **)(arg1 + 600);
                    if (piVar24 == (int32_t *)0x0) {
                        piVar24 = piVar46;
                    }
                    *(int32_t **)(arg1 + 600) = (int32_t *)((int64_t)piVar24 + -1);
code_r0x0001801538a5:
                    cVar9 = '\0';
                }
                *(undefined8 *)(puVar41 + 0x68) = 0;
                if (piVar46 != (int32_t *)0x0) {
                    ppiVar47 = (int32_t **)(arg1 + 0x1d0);
                    do {
                        *(undefined8 *)(puVar41 + -8) = 0x1801538c7;
                        func_0x000180107620((uint64_t)piVar39 & 0xffffffff);
                        piVar24 = ppiVar32[0x25];
                        if (piVar39 == piVar24) {
                            *(undefined8 *)(puVar41 + -8) = 0x1801538dc;
                            func_0x00018010cc30();
                        }
                        iVar18 = *(int64_t *)(*(uint64_t *)0x180781f28 + 0x15e0);
                        if ((*(int64_t *)(iVar18 + 0x208) != 0) ||
                           (pfVar17 = (float *)(iVar18 + 0x2d0), *(int64_t *)(*(uint64_t *)0x180781f28 + 0x24d0) != 0))
                        {
                            pfVar17 = (float *)(iVar18 + 0x2a0);
                        }
                        fVar63 = *pfVar17;
                        fVar61 = *(float *)(iVar18 + 0x158);
                        ppiVar56 = ppiVar47;
                        if ((int32_t *)0xf < ppiVar47[3]) {
                            ppiVar56 = (int32_t **)*ppiVar47;
                        }
                        uStack_1e8 = ppiVar47[2];
                        ppiVar47 = (int32_t **)(ppiVar32[0x20] + (int64_t)piVar39 * 8);
                        if ((int32_t *)0xf < ppiVar47[3]) {
                            ppiVar47 = (int32_t **)*ppiVar47;
                        }
                        *(undefined8 *)(puVar41 + -8) = 0x180153a03;
                        uVar19 = func_0x000180498cd0(ppiVar47);
                        *(undefined8 *)(puVar41 + 0x50) = uVar19;
                        uStack_1a8 = *(undefined8 *)(iVar18 + 0x158);
                        *(undefined8 *)(puVar41 + -8) = 0x180153a1a;
                        uVar19 = func_0x00018010bf90();
                        uStack_1b0 = CONCAT44((int32_t)uVar19, fVar63 - fVar61);
                        *(undefined8 *)(puVar41 + -8) = 0x180153a2d;
                        uVar11 = func_0x00018013a8a0(uVar19, &uStack_1b0);
                        puVar41[0x70] = uVar11;
                        *(undefined8 *)(puVar41 + -8) = 0x180153a36;
                        puVar36 = (uint64_t *)func_0x000180106720();
                        uStack_178 = *(undefined8 *)(*(uint64_t *)0x180781f28 + 0x12e8);
                        *(undefined4 *)(puVar41 + 0x20) = 0xbf800000;
                        *(undefined8 *)(puVar41 + -8) = 0x180153a74;
                        puStack_190 = puVar36;
                        pfVar17 = (float *)func_0x0001800fe0a0(&uStack_168, 0x180641950, 0, 0);
                        fVar63 = *pfVar17;
                        if (piVar39 == piVar24) {
                            *(undefined8 *)(puVar41 + -8) = 0x180153a8c;
                            func_0x0001800f65c0(0x18);
                            *(undefined8 *)(puVar41 + -8) = 0x180153aa0;
                            uVar19 = func_0x0001800f3ad0(auStack_118, &uStack_1a8, &uStack_1b0);
                            *(undefined4 *)(puVar41 + 0x28) = 0;
                            *(undefined4 *)(puVar41 + 0x20) = 0;
                            *(undefined8 *)(puVar41 + -8) = 0x180153abe;
                            func_0x000180126550(puVar36, &uStack_1a8, uVar19);
                        }
                        *(undefined8 *)(puVar41 + -8) = 0x180153ad5;
                        func_0x0001800f3b00(&uStack_1a8, *(uint64_t *)0x180781f28 + 0xddc);
                        iVar18 = *(int64_t *)(puVar41 + 0x50) + (int64_t)ppiVar47;
                        *(int64_t *)(puVar41 + 0x50) = iVar18;
                        uVar55 = (int64_t)uStack_1e8 + (int64_t)ppiVar56;
                        *(undefined8 *)(puVar41 + -8) = 0x180153afd;
                        uStack_1e8 = (int32_t *)uVar55;
                        func_0x000180161f90(puVar41 + 0x58, ppiVar47, iVar18);
                        *(undefined8 *)(puVar41 + -8) = 0x180153b0c;
                        func_0x000180161f90(&uStack_188, ppiVar56, uVar55);
                        *(undefined8 *)(puVar41 + -8) = 0x180153b1f;
                        pcVar51 = (char *)func_0x00018015ae70(puVar41 + 0x58, auStack_1c8);
                        uVar19 = uStack_178;
                        puVar36 = puStack_190;
                        if (*pcVar51 < '\0') {
                            uVar48 = *(undefined8 *)(puVar41 + 0x58);
                            piVar27 = uStack_188;
                            fVar61 = (float)uStack_1a8;
                            do {
                                *(undefined8 *)(puVar41 + -8) = 0x180153b54;
                                puVar37 = (undefined8 *)func_0x000180161fc0(&uStack_1d8, uVar48, iVar18, &fStack_1a0);
                                uVar48 = *puVar37;
                                *(undefined8 *)(puVar41 + 0x58) = uVar48;
                                *(undefined8 *)(puVar41 + -8) = 0x180153b67;
                                uVar16 = func_0x0001800f65c0(0);
                                *(undefined4 *)(puVar41 + 0x78) = uVar16;
                                *(undefined8 *)(puVar41 + -8) = 0x180153b7c;
                                pcVar51 = (char *)func_0x00018015ae70(&uStack_188, auStack_198, &uStack_1e8);
                                if (*pcVar51 < '\0') {
                                    *(undefined8 *)(puVar41 + -8) = 0x180153b94;
                                    func_0x000180161fc0(&piStack_180, piVar27, uVar55, &uStack_1b8);
                                    *(undefined8 *)(puVar41 + -8) = 0x180153b9d;
                                    iVar12 = func_0x000180162230((uint64_t)uStack_1b8 & 0xffff);
                                    *(undefined8 *)(puVar41 + -8) = 0x180153baa;
                                    iVar13 = func_0x000180162230(fStack_1a0._0_2_);
                                    if (iVar12 == iVar13) {
                                        *(undefined8 *)(puVar41 + -8) = 0x180153bbe;
                                        uVar16 = func_0x0001800f65c0(0x34);
                                        uStack_188 = piStack_180;
                                        piVar27 = piStack_180;
                                    } else {
                                        uVar16 = *(undefined4 *)(puVar41 + 0x78);
                                    }
                                } else {
                                    uVar16 = *(undefined4 *)(puVar41 + 0x78);
                                }
                                *(undefined8 *)(puVar41 + 0x30) = 0;
                                *(undefined2 *)(puVar41 + 0x28) = fStack_1a0._0_2_;
                                *(undefined4 *)(puVar41 + 0x20) = uVar16;
                                *(undefined8 *)(puVar41 + -8) = 0x180153bf9;
                                func_0x00018012f6c0(uVar19, puVar36);
                                fVar61 = fVar61 + fVar63;
                                uStack_1a8 = CONCAT44(uStack_1a8._4_4_, fVar61);
                                *(undefined8 *)(puVar41 + -8) = 0x180153c16;
                                pcVar51 = (char *)func_0x00018015ae70(puVar41 + 0x58, auStack_1c8);
                            } while (*pcVar51 < '\0');
                            ppiVar32 = ppiStack_170 + 0x26;
                            piVar39 = *(int32_t **)(puVar41 + 0x68);
                            arg1 = (int64_t)ppiStack_170;
                        }
                        if (puVar41[0x70] == '\0') {
                            cVar9 = puVar41[0x60];
                        } else {
                            ppiVar32[0x25] = piVar39;
                            *(undefined *)((int64_t)ppiVar32 + 3) = 1;
                            cVar9 = '\x01';
                            puVar41[0x60] = 1;
                        }
                        *(undefined8 *)(puVar41 + -8) = 0x180153c57;
                        func_0x000180107740();
                        piVar39 = (int32_t *)((int64_t)piVar39 + 1);
                        *(int32_t **)(puVar41 + 0x68) = piVar39;
                        ppiVar47 = ppiVar32 + 0x14;
                    } while (piVar39 < piStack_1c0);
                    *(undefined8 *)(puVar41 + -8) = 0x180153c75;
                    func_0x00018010d5c0();
                    goto code_r0x000180153c8b;
                }
            }
            *(undefined8 *)(puVar41 + -8) = 0x180153c81;
            func_0x00018010d5c0();
        } else {
            *(undefined8 *)(puVar41 + -8) = 0x18015383f;
            func_0x00018010d400();
            *(undefined *)(arg1 + 0x133) = 0;
            *(undefined *)(arg1 + 0x131) = 0;
            *(undefined8 *)(puVar41 + -8) = 0x18015384c;
            func_0x00018010d5c0();
        }
    }
code_r0x000180153c8b:
    if (cVar9 != '\0') {
        ppiStack_170 = *(int32_t ***)(arg1 + 0x13c);
        *(undefined8 *)(puVar41 + -8) = 0x180153cad;
        func_0x00018015dd90((int32_t **)(arg1 + 0x40), &piStack_1c0, ppiStack_170, 1);
        *(undefined8 *)(puVar41 + -8) = 0x180153cbe;
        func_0x0001801500b0((int32_t **)(arg1 + 0x130), apppppuStack_140);
        *(undefined8 *)(puVar41 + -8) = 0x180153ccc;
        func_0x000180010690(apppppuStack_140, &uStack_1d8);
        *(undefined8 *)(puVar41 + -8) = 0x180153ce0;
        func_0x000180160a70(arg1, &ppiStack_170, &piStack_1c0, &uStack_1d8);
        *(undefined8 *)(puVar41 + -8) = 0x180153cea;
        func_0x000180004e40(apppppuStack_140);
    }
code_r0x000180153cea:
    if (*(int32_t **)(arg1 + 0x4d0) != (int32_t *)0x0) {
        if (*(char *)(arg1 + 0x4e8) == '\0') {
            if (*(int32_t **)(arg1 + 0x108) != piStack_148) {
                *(undefined *)(arg1 + 0x4e8) = 1;
                *(undefined8 *)(puVar41 + -8) = 0x180153d52;
                iVar18 = func_0x00018045838c();
                *(int32_t **)(arg1 + 0x4e0) = (int32_t *)((int64_t)*(int32_t **)(arg1 + 0x4d8) * 10000 + iVar18);
            }
        } else {
            *(undefined8 *)(puVar41 + -8) = 0x180153d05;
            piStack_1c0 = (int32_t *)func_0x00018045838c();
            *(undefined8 *)(puVar41 + -8) = 0x180153d1a;
            cVar9 = func_0x000180153e00(&piStack_1c0, (int32_t **)(arg1 + 0x4e0));
            if ('\0' < cVar9) {
                *(undefined8 *)(puVar41 + -8) = 0x180153d2b;
                func_0x000180014760((int32_t **)(arg1 + 0x498));
                *(undefined *)(arg1 + 0x4e8) = 0;
            }
        }
    }
    *(undefined8 *)(puVar41 + -8) = 0x180153d6e;
    func_0x0001800fea60();
    *(undefined8 *)(puVar41 + -8) = 0x180153d7a;
    func_0x0001800f6770(1);
    *(undefined8 *)(puVar41 + -8) = 0x180153d81;
    func_0x0001800f6a20(1);
    *(undefined8 *)(puVar41 + -8) = 0x180153d8d;
    func_0x000180459870(uStack_f8 ^ (uint64_t)puVar41);
    return;
}

// ============================================================
// Function: FUN_180153e20
// Address: 0x180153e20
// Size: 3695 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_a4h
// WARNING: [rz-ghidra] Detected overlap for variable var_a8h
// WARNING: [rz-ghidra] Detected overlap for variable var_a7h
// WARNING: [rz-ghidra] Detected overlap for variable var_a5h
// WARNING: [rz-ghidra] Detected overlap for variable var_a2h
// WARNING: [rz-ghidra] Detected overlap for variable var_a3h
// WARNING: [rz-ghidra] Removing arg arg_b50h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b54h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b58h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable arg_72h
// WARNING: [rz-ghidra] Detected overlap for variable var_a0h
// WARNING: [rz-ghidra] Detected overlap for variable var_9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch

void fcn.180153e20(int64_t arg1, int64_t arg_70h)
{
    char *pcVar1;
    int64_t *piVar2;
    uint16_t uVar3;
    undefined8 *puVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    char **ppcVar8;
    code *pcVar9;
    int32_t iVar10;
    bool bVar11;
    bool bVar12;
    bool bVar13;
    char cVar14;
    char cVar15;
    char cVar16;
    undefined8 *puVar17;
    uint64_t uVar18;
    char *pcVar19;
    int32_t *piVar20;
    uint64_t uVar21;
    int32_t iVar22;
    int64_t *piVar23;
    undefined8 *puVar24;
    uint64_t uVar25;
    bool bVar26;
    bool bVar27;
    bool bVar28;
    undefined auStack_c8 [32];
    char var_a8h;
    char var_a7h;
    int64_t var_a6h;
    int32_t var_9ch;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    undefined8 uStack_68;
    int64_t var_60h;
    int64_t var_58h;
    
    iVar6 = *(int64_t *)0x180781f28;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_c8;
    var_88h = *(int64_t *)0x180781f28;
    if ((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == 0) ||
       (*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0)))
    goto code_r0x000180154c5c;
    *(undefined2 *)(*(int64_t *)0x180781f28 + 0xe9) = 0x101;
    if (*(char *)(iVar6 + 0xac0) == '\0') {
        bVar26 = false;
    } else {
        bVar26 = *(char *)(iVar6 + 0x1df4) == '\0';
    }
    if (*(char *)(iVar6 + 0xab0) == '\0') {
        bVar27 = false;
    } else {
        bVar27 = *(char *)(iVar6 + 0x1de8) == '\0';
    }
    if (*(char *)(iVar6 + 0xad0) == '\0') {
        bVar28 = false;
    } else {
        bVar28 = *(char *)(iVar6 + 0x1e00) == '\0';
    }
    if (((bVar27 == false) && (bVar26 == false)) && (bVar28 == false)) {
        bVar13 = true;
code_r0x000180153ed5:
        if ((bVar27 == false) || (bVar26 == false)) {
code_r0x000180153f05:
            bVar12 = false;
            goto code_r0x000180153f08;
        }
        bVar12 = false;
        if (bVar28 != false) goto code_r0x000180153f08;
        var_a6h._0_1_ = '\x01';
code_r0x000180153f1c:
        bVar11 = true;
        var_a6h._2_1_ = '\0';
        var_a8h = '\0';
        var_a7h = '\0';
        var_a6h._1_1_ = '\0';
code_r0x000180153fcb:
        var_a6h._4_1_ = '\0';
    } else {
        bVar13 = false;
        if (bVar27 == false) goto code_r0x000180153f05;
        if ((bVar26 != false) || (bVar28 != false)) goto code_r0x000180153ed5;
        bVar12 = true;
code_r0x000180153f08:
        if ((bVar27 != false) && (var_a6h._0_1_ = '\0', bVar28 == false)) goto code_r0x000180153f1c;
        var_a6h._0_1_ = '\0';
        bVar11 = false;
        if ((bVar27 == false) && ((bVar26 == false && (bVar28 != false)))) {
            var_a6h._2_1_ = '\x01';
            var_a8h = '\0';
            var_a7h = '\0';
            var_a6h._1_1_ = '\x01';
            goto code_r0x000180153fcb;
        }
        var_a6h._2_1_ = '\0';
        if (((bVar27 == false) && (bVar26 != false)) && (bVar28 == false)) {
            var_a8h = '\x01';
            var_a7h = '\x01';
code_r0x000180153fa6:
            if (bVar26 == false) {
                var_a6h._1_1_ = '\x01';
                goto code_r0x000180153fcb;
            }
        } else {
            if ((bVar27 == false) && (var_a8h = '\0', bVar28 == false)) {
                var_a7h = '\x01';
                goto code_r0x000180153fa6;
            }
            var_a8h = '\0';
            var_a7h = '\0';
            if (bVar27 == false) goto code_r0x000180153fa6;
        }
        var_a6h._1_1_ = '\0';
        if (((bVar27 != false) || (bVar26 == false)) || (var_a6h._4_1_ = '\x01', bVar28 == false))
        goto code_r0x000180153fcb;
    }
    var_a6h._3_1_ = *(char *)(arg1 + 0x131);
    if (var_a6h._3_1_ != '\0') {
        var_70h = 0x20d00000200;
        uStack_68 = 0x20300000273;
        var_60h._0_4_ = 0x204;
        piVar23 = &var_70h;
        do {
            cVar14 = func_0x000180107dc0(*(undefined4 *)piVar23, 1, 0);
            if (cVar14 != '\0') {
                if ((*(int64_t *)(arg1 + 0x238) != *(int64_t *)(arg1 + 0x230)) || (*(char *)(arg1 + 0x248) != '\0'))
                goto code_r0x000180154c5c;
                *(undefined *)(arg1 + 0x133) = 1;
                break;
            }
            piVar23 = (int64_t *)((int64_t)piVar23 + 4);
        } while (piVar23 != (int64_t *)((int64_t)&var_60h + 4));
    }
    cVar14 = var_a7h;
    if (var_a7h == '\0') {
code_r0x0001801540a7:
        if (var_a6h._4_1_ == '\0') {
code_r0x0001801540f4:
            if (bVar28 == false) {
                cVar15 = func_0x000180107dc0(0x201, 1, 0);
                if (cVar15 == '\0') {
                    cVar15 = func_0x000180107dc0(0x202, 1, 0);
                    if (cVar15 != '\0') {
                        func_0x0001801573c0(arg1, bVar26, bVar27);
                        goto code_r0x000180154bc1;
                    }
                    goto code_r0x000180154185;
                }
                puVar4 = *(undefined8 **)(arg1 + 8);
                for (puVar24 = *(undefined8 **)arg1; puVar24 != puVar4;
                    puVar24 = (undefined8 *)((int64_t)puVar24 + 0x14)) {
                    puVar17 = (undefined8 *)func_0x00018015d830(arg1 + 0x40, (int64_t)&var_a6h + 6, puVar24[1], bVar27);
                    uVar5 = *puVar17;
                    if (bVar26 == false) {
                        *puVar24 = uVar5;
                    }
                    puVar24[1] = uVar5;
                    *(undefined *)((int64_t)puVar24 + 0x12) = 1;
                }
                goto code_r0x0001801549a1;
            }
code_r0x000180154185:
            if (cVar14 == '\0') {
code_r0x0001801541e9:
                if (bVar11) {
                    cVar15 = func_0x000180107dc0(0x203, 1, 0);
                    if ((cVar15 == '\0') && (cVar15 = func_0x000180107dc0(0x207, 1, 0), cVar15 == '\0')) {
                        cVar15 = func_0x000180107dc0(0x204, 1, 0);
                        if ((cVar15 == '\0') && (cVar15 = func_0x000180107dc0(0x208, 1, 0), cVar15 == '\0'))
                        goto code_r0x000180154268;
                        func_0x000180157520(arg1, bVar26);
                    } else {
                        func_0x000180157460(arg1, bVar26);
                    }
                } else {
code_r0x000180154268:
                    if (cVar14 == '\0') {
code_r0x000180154434:
                        if (bVar12) {
                            cVar14 = func_0x000180107dc0(0x222, 1, 0);
                            if (cVar14 != '\0') {
                                func_0x000180157460(arg1, 0);
                                func_0x000180157520(arg1, 1);
                                goto code_r0x000180154bc1;
                            }
                            cVar14 = func_0x000180107dc0(0x225, 1, 0);
                            if (cVar14 != '\0') {
                                uVar18 = *(uint64_t *)(arg1 + 0x20);
                                uVar21 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
                                if (uVar21 < uVar18 || uVar21 - uVar18 == 0) {
code_r0x000180154c89:
                                    func_0x000180060370();
                                    pcVar9 = (code *)swi(3);
                                    (*pcVar9)();
                                    return;
                                }
                                piVar20 = (int32_t *)(*(int64_t *)arg1 + uVar18 * 0x14);
                                if ((*piVar20 != piVar20[2]) || (piVar20[1] != piVar20[3])) {
                                    func_0x000180160870(arg1);
                                    goto code_r0x000180154bc1;
                                }
                            }
                            cVar14 = func_0x000180107dc0(0x239, 1, 0);
                            if (cVar14 == '\0') goto code_r0x0001801544e5;
                        } else {
code_r0x0001801544e5:
                            cVar14 = var_a8h;
                            if ((var_a8h == '\0') || (cVar15 = func_0x000180107dc0(0x20a, 1, 0), cVar15 == '\0')) {
                                if ((bVar12) &&
                                   ((cVar15 = func_0x000180107dc0(0x224, 1, 0), cVar15 != '\0' ||
                                    (cVar15 = func_0x000180107dc0(0x209, 1, 0), cVar15 != '\0')))) {
                                    func_0x000180156900(arg1);
                                } else {
                                    cVar15 = *(char *)(arg1 + 0x264);
                                    cVar16 = (char)var_a6h;
                                    if (cVar15 == '\0') {
                                        if (((bVar12) && (cVar16 = func_0x000180107dc0(0x237, 1, 0), cVar16 != '\0')) ||
                                           ((cVar14 != '\0' &&
                                            (cVar14 = func_0x000180107dc0(0x209, 1, 0), cVar14 != '\0')))) {
                                            func_0x000180156f20(arg1);
                                        } else if ((bVar12) &&
                                                  (cVar14 = func_0x000180107dc0(0x23b, 1, 0), cVar14 != '\0')) {
                                            if (*(int64_t *)(arg1 + 0x100) != 0) {
                                                uVar18 = *(int64_t *)(arg1 + 0x100) - 1;
                                                *(uint64_t *)(arg1 + 0x100) = uVar18;
                                                iVar6 = *(int64_t *)(arg1 + 0xe8);
                                                if ((uint64_t)(*(int64_t *)(arg1 + 0xf0) - iVar6 >> 4) <= uVar18) {
                                                    func_0x000180060370();
                                                    pcVar9 = (code *)swi(3);
                                                    (*pcVar9)();
                                                    return;
                                                }
                                                iVar7 = *(int64_t *)(iVar6 + 8 + uVar18 * 0x10);
                                                if (iVar7 != 0) {
                                                    LOCK();
                                                    piVar20 = (int32_t *)(iVar7 + 8);
                                                    *piVar20 = *piVar20 + 1;
                                                    UNLOCK();
                                                }
                                                ppcVar8 = *(char ***)(iVar6 + uVar18 * 0x10);
                                                piVar23 = *(int64_t **)(iVar6 + 8 + uVar18 * 0x10);
                                                pcVar19 = ppcVar8[1];
                                                var_80h = (int64_t)ppcVar8;
                                                var_78h = (int64_t)piVar23;
                                                while ((pcVar19 != *ppcVar8 && (*ppcVar8 <= pcVar19))) {
                                                    pcVar1 = pcVar19 + -0x38;
                                                    if (*pcVar1 == '\0') {
                                                        func_0x00018015d110(arg1 + 0x40, 
                                                                            *(undefined8 *)(pcVar19 + -0x34), 
                                                                            *(undefined8 *)(pcVar19 + -0x2c));
                                                        pcVar19 = pcVar1;
                                                    } else {
                                                        var_98h = (int64_t)(pcVar19 + -0x20);
                                                        if (0xf < *(uint64_t *)(pcVar19 + -8)) {
                                                            var_98h = *(int64_t *)var_98h;
                                                        }
                                                        var_90h = *(int64_t *)(pcVar19 + -0x10);
                                                        func_0x00018015c7f0(arg1 + 0x40, (int64_t)&var_a6h + 6, 
                                                                            *(undefined8 *)(pcVar19 + -0x34), &var_98h);
                                                        pcVar19 = pcVar1;
                                                    }
                                                }
                                                func_0x000180150230(arg1, ppcVar8 + 3);
                                                *(int64_t *)(arg1 + 0x108) = *(int64_t *)(arg1 + 0x108) + 1;
                                                if (piVar23 != (int64_t *)0x0) {
                                                    LOCK();
                                                    piVar2 = piVar23 + 1;
                                                    iVar22 = *(int32_t *)piVar2;
                                                    *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                                                    UNLOCK();
                                                    if (iVar22 == 1) {
                                                        (**(code **)*piVar23)(piVar23);
                                                        LOCK();
                                                        piVar20 = (int32_t *)((int64_t)piVar23 + 0xc);
                                                        iVar22 = *piVar20;
                                                        *piVar20 = *piVar20 + -1;
                                                        UNLOCK();
                                                        if (iVar22 == 1) {
                                                            (**(code **)(*piVar23 + 8))(piVar23);
                                                        }
                                                    }
                                                }
                                                goto code_r0x0001801549a1;
                                            }
                                        } else {
                                            cVar16 = (char)var_a6h;
                                            if ((((char)var_a6h != '\0') &&
                                                (cVar14 = func_0x000180107dc0(0x23b, 1, 0), cVar14 != '\0')) ||
                                               ((bVar12 && (cVar14 = func_0x000180107dc0(0x23a, 1, 0), cVar14 != '\0')))
                                               ) {
                                                func_0x000180157080(arg1);
                                            } else if (var_a6h._1_1_ == '\0') {
code_r0x00018015477a:
                                                if ((cVar16 == '\0') ||
                                                   (cVar14 = func_0x000180107dc0(0x22c, 1, 0), cVar14 == '\0')) {
                                                    if (bVar12) {
                                                        cVar14 = func_0x000180107dc0(0x25b, 1, 0);
                                                        if (cVar14 == '\0') {
                                                            cVar14 = func_0x000180107dc0(0x25d, 1, 0);
                                                            if (cVar14 == '\0') goto code_r0x0001801547db;
code_r0x000180154afe:
                                                            func_0x000180159830(arg1);
                                                        } else {
code_r0x000180154af1:
                                                            func_0x000180159b90(arg1);
                                                        }
                                                    } else {
code_r0x0001801547db:
                                                        if (var_a6h._2_1_ == '\0') {
code_r0x000180154828:
                                                            if (*(int64_t *)(arg1 + 0x5e8) == 0)
                                                            goto code_r0x000180154860;
                                                            if (!bVar12) goto code_r0x00018015489d;
                                                            cVar14 = func_0x000180107dc0(600, 1, 0);
                                                            if (cVar14 == '\0') goto code_r0x000180154865;
                                                            func_0x00018015a7d0(arg1);
                                                        } else {
                                                            cVar14 = func_0x000180107dc0(0x203, 1, 0);
                                                            if (cVar14 == '\0') {
                                                                cVar14 = func_0x000180107dc0(0x204, 1, 0);
                                                                if (cVar14 == '\0') goto code_r0x000180154828;
                                                                func_0x00018015a310(arg1);
                                                            } else {
                                                                func_0x000180159ea0(arg1);
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    func_0x000180158f90(arg1);
                                                }
                                            } else {
                                                cVar14 = func_0x000180107dc0(0x20a, 1, 0);
                                                if (cVar14 == '\0') {
                                                    cVar14 = func_0x000180107dc0(0x20b, 1, 0);
                                                    if (cVar14 == '\0') goto code_r0x00018015477a;
                                                    func_0x000180158bb0(arg1, bVar28);
                                                } else {
                                                    func_0x000180158da0(arg1, bVar28);
                                                }
                                            }
                                        }
                                    } else {
code_r0x000180154860:
                                        if (bVar12) {
code_r0x000180154865:
                                            cVar14 = func_0x000180107dc0(0x227, 1, 0);
                                            if (cVar14 != '\0') {
                                                if (var_a6h._3_1_ != '\0') {
                                                    *(undefined *)(arg1 + 0x133) = 1;
                                                    *(undefined *)(arg1 + 0x42b) = 1;
                                                }
                                                func_0x000180160ca0(arg1);
                                                goto code_r0x000180154bc1;
                                            }
                                        }
code_r0x00018015489d:
                                        if ((cVar16 == '\0') ||
                                           (cVar14 = func_0x000180107dc0(0x227, 1, 0), cVar14 == '\0')) {
                                            if ((bVar12) && (cVar14 = func_0x000180107dc0(0x228, 1, 0), cVar14 != '\0'))
                                            {
                                                if (*(int64_t *)(arg1 + 0x440) != 0) {
                                                    var_98h = arg1 + 0x430;
                                                    if (0xf < *(uint64_t *)(arg1 + 0x448)) {
                                                        var_98h = *(int64_t *)var_98h;
                                                    }
                                                    var_90h = *(int64_t *)(arg1 + 0x440);
                                                    func_0x0001801604f0(arg1, &var_98h, *(undefined *)(arg1 + 0x470), 
                                                                        *(undefined *)(arg1 + 0x471));
                                                    *(undefined2 *)(arg1 + 0x429) = 1;
                                                }
                                            } else if ((cVar15 == '\0') &&
                                                      (cVar14 = func_0x000180109ce0(*(undefined4 *)(arg1 + 0x154), 0, 0)
                                                      , cVar14 != '\0')) {
                                                if (((((uint64_t)
                                                       ((*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) *
                                                       -0x3333333333333333) < 2) && (var_a6h._3_1_ == '\0')) &&
                                                    (*(char *)(arg1 + 0x132) == '\0')) &&
                                                   ((*(char *)(arg1 + 0x130) != '\0' &&
                                                    (*(char *)(arg1 + 0x151) != '\0')))) {
                                                    *(undefined *)(arg1 + 0x250) = 1;
                                                    func_0x000180161010((char *)(arg1 + 0x130), arg1);
                                                    goto code_r0x0001801549a1;
                                                }
                                            } else if ((bVar13) &&
                                                      (cVar14 = func_0x000180107dc0(0x209, 1, 0), cVar14 != '\0')) {
                                                *(bool *)(arg1 + 0x26c) = *(char *)(arg1 + 0x26c) == '\0';
                                            } else if (cVar15 == '\0') {
                                                if ((bVar13) &&
                                                   ((cVar14 = func_0x000180107dc0(0x20d, 1, 0), cVar14 != '\0' ||
                                                    (cVar14 = func_0x000180107dc0(0x273, 1, 0), cVar14 != '\0')))) {
                                                    func_0x000180157620(arg1, 10);
                                                } else if ((bVar12) &&
                                                          ((cVar14 = func_0x000180107dc0(0x20d, 1, 0), cVar14 != '\0' ||
                                                           (cVar14 = func_0x000180107dc0(0x273, 1, 0), cVar14 != '\0')))
                                                          ) {
                                                    func_0x0001801594d0(arg1);
                                                } else if ((cVar16 == '\0') ||
                                                          ((cVar14 = func_0x000180107dc0(0x20d, 1, 0), cVar14 == '\0' &&
                                                           (cVar14 = func_0x000180107dc0(0x273, 1, 0), cVar14 == '\0')))
                                                          ) {
                                                    if ((var_a7h == '\0') ||
                                                       (cVar14 = func_0x000180107dc0(0x200, 1, 0), cVar14 == '\0'))
                                                    goto code_r0x000180154b1d;
                                                    for (piVar20 = *(int32_t **)arg1; piVar20 < *(int32_t **)(arg1 + 8);
                                                        piVar20 = piVar20 + 5) {
                                                        if ((*piVar20 != piVar20[2]) || (piVar20[1] != piVar20[3])) {
                                                            if (bVar26 != false) goto code_r0x000180154af1;
                                                            goto code_r0x000180154afe;
                                                        }
                                                    }
                                                    func_0x000180157620(arg1, 9);
                                                } else {
                                                    func_0x000180159210(arg1);
                                                }
                                            } else {
code_r0x000180154b1d:
                                                cVar14 = func_0x000180107dc0(0x20e, 1, 0);
                                                if (cVar14 != '\0') {
                                                    if (var_a6h._3_1_ == '\0') {
                                                        if (*(char *)(arg1 + 0x428) == '\0') {
                                                            uVar21 = *(uint64_t *)(arg1 + 8);
                                                            uVar18 = *(uint64_t *)arg1;
                                                            if (1 < (uint64_t)
                                                                    (((int64_t)(uVar21 - *(uint64_t *)arg1) >> 2) *
                                                                    -0x3333333333333333)) {
                                                                while (uVar25 = uVar18, uVar25 < uVar21) {
                                                                    uVar18 = uVar25 + 0x14;
                                                                    if (*(char *)(uVar25 + 0x10) == '\0') {
                                                                        func_0x000180498030(uVar25, uVar18, 
                                                                                            uVar21 - uVar18);
                                                                        *(int64_t *)(arg1 + 8) =
                                                                             *(int64_t *)(arg1 + 8) + -0x14;
                                                                        uVar21 = *(uint64_t *)(arg1 + 8);
                                                                        uVar18 = uVar25;
                                                                    }
                                                                }
                                                                *(undefined8 *)(arg1 + 0x18) = 0;
                                                                *(undefined8 *)(arg1 + 0x20) = 0;
                                                                *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
                                                            }
                                                        } else {
                                                            *(undefined2 *)(arg1 + 0x428) = 0x100;
                                                            *(undefined *)(arg1 + 0x42a) = 0;
                                                        }
                                                    } else {
                                                        *(undefined *)(arg1 + 0x133) = 1;
                                                    }
                                                }
                                            }
                                        } else {
                                            func_0x000180160fb0(arg1);
                                        }
                                    }
                                }
                                goto code_r0x000180154bc1;
                            }
                        }
                        func_0x000180156730(arg1);
                    } else {
                        cVar14 = func_0x000180107dc0(0x207, 1, 0);
                        if (cVar14 == '\0') {
                            cVar14 = func_0x000180107dc0(0x208, 1, 0);
                            if (cVar14 == '\0') goto code_r0x000180154434;
                            uVar18 = *(uint64_t *)arg1;
                            while (uVar21 = uVar18, uVar21 < *(uint64_t *)(arg1 + 8)) {
                                uVar18 = uVar21 + 0x14;
                                if (*(char *)(uVar21 + 0x10) == '\0') {
                                    func_0x000180498030(uVar21, uVar18, *(uint64_t *)(arg1 + 8) - uVar18);
                                    *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
                                    uVar18 = uVar21;
                                }
                            }
                            *(undefined8 *)(arg1 + 0x18) = 0;
                            *(undefined8 *)(arg1 + 0x20) = 0;
                            *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
                            uVar21 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
                            uVar18 = *(uint64_t *)(arg1 + 0x20);
                            if (uVar21 < uVar18 || uVar21 - uVar18 == 0) {
                                uVar18 = *(uint64_t *)(arg1 + 0x18);
                                if (uVar21 <= *(uint64_t *)(arg1 + 0x18)) {
                                    uVar18 = 0;
                                }
                                *(uint64_t *)(arg1 + 0x20) = uVar18;
                                if (uVar21 < uVar18 || uVar21 - uVar18 == 0) goto code_r0x000180154c89;
                            }
                            piVar20 = (int32_t *)(*(int64_t *)arg1 + uVar18 * 0x14);
                            unique0x0000c180 = piVar20[2];
                            uVar21 = (uint64_t)unique0x0000c180;
                            uVar18 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
                            if (uVar18 < uVar21 || uVar18 - uVar21 == 0) {
                                func_0x000180060370();
                                pcVar9 = (code *)swi(3);
                                (*pcVar9)();
                                return;
                            }
                            var_9ch = *(int32_t *)(uVar21 * 0x38 + 0x28 + *(int64_t *)(arg1 + 0x40));
                            if (bVar26 == false) {
                                *piVar20 = unique0x0000c180;
                                piVar20[1] = var_9ch;
                            }
                            *(uint64_t *)(piVar20 + 2) = CONCAT44(var_9ch, unique0x0000c180);
                            *(undefined *)((int64_t)piVar20 + 0x12) = 1;
                        } else {
                            uVar18 = *(uint64_t *)arg1;
                            while (uVar21 = uVar18, uVar21 < *(uint64_t *)(arg1 + 8)) {
                                uVar18 = uVar21 + 0x14;
                                if (*(char *)(uVar21 + 0x10) == '\0') {
                                    func_0x000180498030(uVar21, uVar18, *(uint64_t *)(arg1 + 8) - uVar18);
                                    *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
                                    uVar18 = uVar21;
                                }
                            }
                            *(undefined8 *)(arg1 + 0x18) = 0;
                            *(undefined8 *)(arg1 + 0x20) = 0;
                            *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
                            iVar6 = *(int64_t *)arg1;
                            uVar21 = (*(int64_t *)(arg1 + 8) - iVar6 >> 2) * -0x3333333333333333;
                            uVar18 = *(uint64_t *)(arg1 + 0x20);
                            if (uVar21 < uVar18 || uVar21 - uVar18 == 0) {
                                uVar18 = *(uint64_t *)(arg1 + 0x18);
                                if (uVar21 <= *(uint64_t *)(arg1 + 0x18)) {
                                    uVar18 = 0;
                                }
                                *(uint64_t *)(arg1 + 0x20) = uVar18;
                                if (uVar21 < uVar18 || uVar21 - uVar18 == 0) goto code_r0x000180154c89;
                            }
                            uVar21 = (uint64_t)*(uint32_t *)(iVar6 + 8 + uVar18 * 0x14);
                            if (bVar26 == false) {
                                *(uint64_t *)(iVar6 + uVar18 * 0x14) = uVar21;
                            }
                            *(uint64_t *)(iVar6 + 8 + uVar18 * 0x14) = uVar21;
                            *(undefined *)(iVar6 + 0x12 + uVar18 * 0x14) = 1;
                        }
code_r0x0001801549a1:
                        *(undefined *)(arg1 + 0x2c8) = 1;
                        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
                    }
                }
            } else {
                cVar15 = func_0x000180107dc0(0x205, 1, 0);
                if (cVar15 == '\0') {
                    cVar15 = func_0x000180107dc0(0x206, 1, 0);
                    if (cVar15 == '\0') goto code_r0x0001801541e9;
                    func_0x000180157300(arg1, *(int32_t *)(arg1 + 0x2a0) + -2, bVar26);
                } else {
                    func_0x000180157240(arg1, *(int32_t *)(arg1 + 0x2a0) + -2, bVar26);
                }
            }
        } else {
            cVar15 = func_0x000180107dc0(0x201, 1, 0);
            if (cVar15 == '\0') {
                cVar15 = func_0x000180107dc0(0x202, 1, 0);
                if (cVar15 == '\0') goto code_r0x0001801540f4;
                func_0x000180155e80(arg1);
            } else {
                func_0x000180156300(arg1);
            }
        }
    } else {
        cVar15 = func_0x000180107dc0(0x203, 1, 0);
        if (cVar15 == '\0') {
            cVar15 = func_0x000180107dc0(0x204, 1, 0);
            if (cVar15 == '\0') goto code_r0x0001801540a7;
            func_0x000180157300(arg1, 1, bVar26);
        } else {
            func_0x000180157240(arg1, 1, bVar26);
        }
    }
code_r0x000180154bc1:
    iVar6 = var_88h;
    if (*(int32_t *)(var_88h + 0xc18) != 0) {
        if ((((*(char *)(var_88h + 0x138) == '\0') || (*(char *)(var_88h + 0x13a) != '\0')) &&
            (*(char *)(arg1 + 0x264) == '\0')) && (iVar22 = 0, 0 < *(int32_t *)(var_88h + 0xc18))) {
            do {
                uVar3 = *(uint16_t *)(*(int64_t *)(iVar6 + 0xc20) + (int64_t)iVar22 * 2);
                if (((uVar3 & 0xffe0) != 0) || (uVar3 == 10)) {
                    func_0x000180157620(arg1);
                }
                iVar22 = iVar22 + 1;
            } while (iVar22 < *(int32_t *)(iVar6 + 0xc18));
        }
        iVar22 = *(int32_t *)(iVar6 + 0xc1c);
        if (iVar22 < 0) {
            iVar22 = iVar22 + iVar22 / 2;
            iVar10 = 0;
            if (0 < iVar22) {
                iVar10 = iVar22;
            }
            func_0x00018011f8d0(iVar6 + 0xc18, iVar10);
        }
        *(undefined4 *)(iVar6 + 0xc18) = 0;
    }
code_r0x000180154c5c:
    func_0x000180459870(var_58h ^ (uint64_t)auStack_c8);
    return;
}

// ============================================================
// Function: FUN_180154c90
// Address: 0x180154c90
// Size: 3015 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: [rz-ghidra] Removing arg arg_b60h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_b30h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Detected overlap for variable var_c9ch
// WARNING: [rz-ghidra] Detected overlap for variable var_ca4h
// WARNING: [rz-ghidra] Detected overlap for variable var_54h

void fcn.180154c90(int64_t arg1)
{
    uint8_t *puVar1;
    float *pfVar2;
    int32_t iVar3;
    undefined8 uVar4;
    code *pcVar5;
    int64_t iVar6;
    char cVar7;
    uint8_t uVar8;
    char cVar9;
    int16_t iVar10;
    undefined4 uVar11;
    undefined8 *puVar12;
    uint64_t uVar13;
    uint64_t uVar14;
    int64_t iVar15;
    int64_t iVar16;
    uint64_t uVar17;
    int64_t iVar18;
    int32_t iVar19;
    int32_t iVar20;
    int32_t iVar21;
    int32_t iVar22;
    uint64_t uVar23;
    int64_t *piVar24;
    uint64_t uVar25;
    float *pfVar26;
    bool bVar27;
    bool bVar28;
    bool bVar29;
    float fVar30;
    float fVar31;
    float fVar32;
    float fVar33;
    float fVar34;
    float fVar35;
    float fVar36;
    float fVar37;
    undefined auStack_cd8 [32];
    int64_t var_cb8h;
    int64_t var_ca8h;
    int64_t var_ca0h;
    int64_t var_c98h;
    float fStack_c2c;
    undefined uStack_be0;
    int64_t iStack_a8;
    uint64_t uStack_78;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_8h;
    
    uStack_78 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_cd8;
    if ((*(char *)(arg1 + 0x484) == '\0') || (cVar7 = func_0x000180107f80(2), cVar7 == '\0')) {
        uVar8 = 0;
    } else {
        uVar8 = 1;
    }
    puVar1 = (uint8_t *)(arg1 + 0x485);
    *puVar1 = *puVar1 & uVar8;
    iVar18 = *(int64_t *)0x180781f28;
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    fVar32 = *(float *)(*(int64_t *)0x180781f28 + 0x118);
    fVar37 = *(float *)(*(int64_t *)0x180781f28 + 0x11c) - *(float *)(iVar15 + 100);
    fVar36 = fVar32 - *(float *)(iVar15 + 0x60);
    if ((*puVar1 != 0) && (*(char *)(*(int64_t *)0x180781f28 + 0x122) != '\0')) {
        fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0xa4) * *(float *)(*(int64_t *)0x180781f28 + 0xa4);
        if (fVar30 <= *(float *)(*(int64_t *)0x180781f28 + 0xc04)) {
            if ((((*(char *)(*(int64_t *)0x180781f28 + 0x122) == '\0') &&
                 (*(char *)(*(int64_t *)0x180781f28 + 0xb70) == '\0')) ||
                (*(float *)(*(int64_t *)0x180781f28 + 0xc04) < fVar30)) ||
               ((fVar32 < -256000.0 || (*(float *)(*(int64_t *)0x180781f28 + 0x11c) < -256000.0)))) {
code_r0x000180154db3:
                fVar32 = 0.0;
                fVar30 = 0.0;
            } else {
                pfVar2 = (float *)(*(int64_t *)0x180781f28 + 0xb0c);
                if (pfVar2 == (float *)0x0) {
                    pfVar26 = (float *)(*(int64_t *)0x180781f28 + 0x118);
                    fVar30 = fVar32;
                } else {
                    pfVar26 = pfVar2;
                    fVar30 = *pfVar2;
                }
                if ((fVar30 < -256000.0) || (pfVar26[1] < -256000.0)) goto code_r0x000180154db3;
                fVar32 = fVar32 - *pfVar2;
                fVar30 = *(float *)(*(int64_t *)0x180781f28 + 0x11c) - *(float *)(*(int64_t *)0x180781f28 + 0xb10);
            }
            fVar33 = *(float *)(*(int64_t *)0x180781f28 + 0x48) * 15.0;
            fVar35 = *(float *)(arg1 + 0x27c) * 4.0;
            fVar34 = *(float *)(arg1 + 0x280) + *(float *)(arg1 + 0x280);
            fVar31 = fVar35 + *(float *)(arg1 + 0x298);
            if ((fVar36 < fVar31) ||
               (fVar31 = (*(float *)(iVar15 + 0x68) - *(float *)(arg1 + 700)) - fVar35, fVar31 < fVar36)) {
                fVar32 = (fVar36 - fVar31) * fVar33;
            }
            if ((fVar37 < fVar34) ||
               (fVar34 = (*(float *)(iVar15 + 0x6c) - *(float *)(arg1 + 0x2c0)) - fVar34, fVar34 < fVar37)) {
                fVar30 = (fVar37 - fVar34) * fVar33;
            }
            *(float *)(iVar15 + 0xe4) = *(float *)(iVar15 + 0xd4) - fVar32;
            *(undefined4 *)(iVar15 + 0xec) = 0;
            *(undefined4 *)(iVar15 + 0xf4) = 0;
            iVar15 = *(int64_t *)(iVar18 + 0x15e0);
            *(float *)(iVar15 + 0xe8) = *(float *)(iVar15 + 0xd8) - fVar30;
            *(undefined4 *)(iVar15 + 0xf0) = 0;
            *(undefined4 *)(iVar15 + 0xf8) = 0;
            *(undefined8 *)(iVar18 + 0xb0c) = *(undefined8 *)(iVar18 + 0x118);
            goto code_r0x00018015581e;
        }
    }
    if (*(char *)(arg1 + 0x486) != '\0') {
        fVar32 = *(float *)(arg1 + 0x27c);
        fVar36 = *(float *)(arg1 + 0x488) - fVar36;
        fVar37 = *(float *)(arg1 + 0x48c) - fVar37;
        fVar30 = 0.0;
        if (0.0 <= fVar36) {
            if (0.0 <= fVar36 - fVar32) {
                fVar30 = fVar36 - fVar32;
            }
        } else if (fVar32 + fVar36 <= 0.0) {
            fVar30 = fVar32 + fVar36;
        }
        fVar36 = 0.0;
        if (0.0 <= fVar37) {
            if (0.0 <= fVar37 - fVar32) {
                fVar36 = fVar37 - fVar32;
            }
        } else if (fVar32 + fVar37 <= 0.0) {
            fVar36 = fVar32 + fVar37;
        }
        fVar32 = *(float *)(*(int64_t *)0x180781f28 + 0x48) * 5.0;
        *(float *)(iVar15 + 0xe4) = *(float *)(iVar15 + 0xd4) - fVar30 * fVar32;
        *(undefined4 *)(iVar15 + 0xec) = 0;
        *(undefined4 *)(iVar15 + 0xf4) = 0;
        iVar15 = *(int64_t *)(iVar18 + 0x15e0);
        *(float *)(iVar15 + 0xe8) = *(float *)(iVar15 + 0xd8) - fVar36 * fVar32;
        *(undefined4 *)(iVar15 + 0xf0) = 0;
        *(undefined4 *)(iVar15 + 0xf8) = 0;
        cVar7 = func_0x000180107ff0(0, 0, 0);
        if (((cVar7 != '\0') || (cVar7 = func_0x000180107ff0(2, 0, 0), cVar7 != '\0')) ||
           (cVar7 = func_0x000180107ff0(1, 0, 0), cVar7 != '\0')) {
            *(undefined *)(arg1 + 0x486) = 0;
        }
        goto code_r0x00018015581e;
    }
    cVar7 = func_0x0001801062b0(0);
    if (cVar7 == '\0') goto code_r0x00018015581e;
    func_0x000180155860(&var_c98h, *(int64_t *)0x180781f28 + 0x30);
    iVar15 = *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0);
    fVar32 = *(float *)(*(int64_t *)0x180781f28 + 0x118) - *(float *)(iVar15 + 0x158);
    if (((*(char *)(arg1 + 0x268) == '\0') || (fVar36 < *(float *)(arg1 + 0x28c) || fVar36 == *(float *)(arg1 + 0x28c)))
       || (*(float *)(arg1 + 0x290) <= fVar36)) {
        bVar28 = false;
    } else {
        bVar28 = true;
    }
    fVar30 = *(float *)(arg1 + 0x298);
    fVar34 = fVar32 - *(float *)(iVar15 + 0xd4);
    var_ca0h = 0;
    var_ca8h = 0;
    var_cb8h = (int64_t)&var_ca8h;
    func_0x00018015e710(arg1 + 0x40, 
                        (*(float *)(*(int64_t *)0x180781f28 + 0x11c) - *(float *)(iVar15 + 0x15c)) /
                        *(float *)(arg1 + 0x280), (fVar32 - fVar30) / *(float *)(arg1 + 0x27c), &var_ca0h);
    iVar15 = *(int64_t *)0x180781f28;
    if (((*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) != 0) &&
        (*(int64_t *)(*(int64_t *)0x180781f28 + 0x21d8) == *(int64_t *)(*(int64_t *)0x180781f28 + 0x15e0))) &&
       (fVar30 < fVar34)) {
        *(undefined4 *)(*(int64_t *)0x180781f28 + 0x2650) = 1;
    }
    if ((*(char *)(iVar15 + 0x120) != '\0') &&
       (*(float *)(iVar15 + 0xa4) * *(float *)(iVar15 + 0xa4) <= *(float *)(iVar15 + 0xbfc))) {
        uStack_be0 = 1;
        if (bVar28) {
            puVar12 = (undefined8 *)func_0x00018014ffc0();
            uVar23 = var_ca8h & 0xffffffff;
            var_ca8h = (int64_t)((int32_t)var_ca8h + 1);
            func_0x00018015e5d0(arg1 + 0x40, &var_ca8h, var_ca8h);
            iVar19 = (int32_t)*puVar12;
            iVar20 = (int32_t)puVar12[1];
            bVar28 = SBORROW4(iVar20, iVar19);
            iVar21 = iVar20 - iVar19;
            if (iVar20 == iVar19) {
                iVar19 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                iVar21 = (int32_t)((uint64_t)puVar12[1] >> 0x20);
                bVar28 = SBORROW4(iVar21, iVar19);
                iVar21 = iVar21 - iVar19;
            }
            if (bVar28 == iVar21 < 0) {
                uVar23 = var_ca8h;
            }
            puVar12[1] = uVar23;
            *(undefined *)((int64_t)puVar12 + 0x12) = 1;
        } else {
            func_0x00018014fed0(arg1, var_ca8h);
        }
        goto code_r0x0001801557f9;
    }
    iVar18 = iVar15;
    cVar7 = func_0x000180107ff0(2, 0, 0);
    if (cVar7 == '\0') {
        cVar7 = func_0x000180107ff0(1, 0, 0);
        if (cVar7 == '\0') {
            cVar7 = func_0x000180107ff0(0, 0, 0);
            if (cVar7 != '\0') {
                cVar7 = func_0x000180107ff0(0, 0, 0);
                cVar9 = func_0x0001801080e0();
                iVar6 = var_ca0h;
                if (cVar7 == '\0') {
code_r0x000180155309:
                    if (cVar9 != '\0') {
code_r0x000180155311:
                        *(float *)(arg1 + 0x474) = (float)*(double *)(iVar15 + 0x18);
                        if (cVar9 == '\0') {
                            if (cVar7 != '\0') {
                                if (*(char *)(iVar18 + 0xac0) == '\0') {
                                    bVar29 = false;
                                } else {
                                    bVar29 = *(char *)(iVar18 + 0x1df4) == '\0';
                                }
                                if (*(char *)(iVar18 + 0xab0) == '\0') {
                                    bVar27 = false;
                                } else {
                                    bVar27 = *(char *)(iVar18 + 0x1de8) == '\0';
                                }
                                if (bVar28) {
                                    uVar23 = var_ca8h & 0xffffffff;
                                    var_ca0h = var_ca8h & 0xffffffff;
                                    var_ca8h = (int64_t)((int32_t)var_ca8h + 1);
                                    func_0x00018015e5d0(arg1 + 0x40, &var_ca8h, var_ca8h);
                                    if (bVar29) {
                                        puVar12 = (undefined8 *)func_0x00018014ffc0();
                                        iVar19 = (int32_t)*puVar12;
                                        iVar20 = (int32_t)puVar12[1];
                                        bVar28 = SBORROW4(iVar20, iVar19);
                                        iVar21 = iVar20 - iVar19;
                                        if (iVar20 == iVar19) {
                                            iVar19 = (int32_t)((uint64_t)*puVar12 >> 0x20);
                                            iVar21 = (int32_t)((uint64_t)puVar12[1] >> 0x20);
                                            bVar28 = SBORROW4(iVar21, iVar19);
                                            iVar21 = iVar21 - iVar19;
                                        }
                                        if (bVar28 == iVar21 < 0) {
                                            uVar23 = var_ca8h;
                                        }
                                        puVar12[1] = uVar23;
                                        *(undefined *)((int64_t)puVar12 + 0x12) = 1;
                                        cVar7 = *(char *)(arg1 + 0x131);
                                    } else {
                                        iVar15 = var_ca0h;
                                        if (!bVar27) {
                                            func_0x00018015c080();
                                            goto code_r0x0001801557f9;
                                        }
code_r0x0001801557dc:
                                        func_0x00018015c0d0(arg1, iVar15, var_ca8h);
code_r0x0001801557e1:
                                        cVar7 = *(char *)(arg1 + 0x131);
                                    }
                                    if (cVar7 != '\0') {
                                        *(undefined *)(arg1 + 0x133) = 1;
                                    }
                                } else {
                                    if (fVar34 <= fVar30) goto code_r0x00018015580c;
                                    if (bVar29) {
                                        func_0x00018014fed0();
                                        goto code_r0x0001801557e1;
                                    }
                                    iVar15 = var_ca8h;
                                    if (bVar27) goto code_r0x0001801557dc;
                                    func_0x00018014fe80(arg1);
                                }
code_r0x0001801557f9:
                                *(undefined *)(arg1 + 0x2c8) = 1;
                                *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
                            }
                        } else if (fVar30 < fVar34) {
                            iVar10 = func_0x00018015d690(arg1 + 0x40, var_ca0h);
                            iVar15 = var_ca0h;
                            iVar21 = (int32_t)var_ca0h;
                            uVar23 = (uint64_t)(int32_t)var_ca0h;
                            if (((iVar10 == 0x7b) || (iVar10 == 0x5b)) || (iVar10 == 0x28)) {
                                iVar18 = *(int64_t *)(arg1 + 0x40);
                                uVar14 = (*(int64_t *)(arg1 + 0x48) - iVar18 >> 3) * 0x6db6db6db6db6db7;
                                if ((uVar14 < uVar23 || uVar14 - uVar23 == 0) ||
                                   (iVar16 = func_0x00018015d7b0(arg1 + 0x40, uVar23 * 0x38 + iVar18, var_ca0h._4_4_),
                                   uVar14 < uVar23 || uVar14 - uVar23 == 0)) goto code_r0x000180155851;
                                if (iVar16 == *(int64_t *)(uVar23 * 0x38 + 8 + iVar18) -
                                              *(int64_t *)(uVar23 * 0x38 + iVar18) >> 2) {
                                    uVar13 = iVar6;
                                    if (iVar21 < (int32_t)uVar14 + -1) {
                                        uVar13 = (uint64_t)(iVar21 + 1);
                                    }
                                } else {
                                    uVar11 = func_0x000180150020(arg1 + 0x40, iVar15 & 0xffffffff, iVar16 + 1);
                                    var_ca8h = CONCAT44(uVar11, iVar21);
                                    uVar13 = var_ca8h;
                                }
                                uVar14 = *(uint64_t *)(arg1 + 0x120);
                                uVar25 = uVar14;
                                for (uVar17 = *(uint64_t *)(arg1 + 0x118); uVar17 < uVar14; uVar17 = uVar17 + 0x1c) {
                                    iVar21 = *(int32_t *)(uVar17 + 4);
                                    iVar20 = (int32_t)uVar13;
                                    bVar29 = SBORROW4(iVar21, iVar20);
                                    iVar19 = iVar21 - iVar20;
                                    bVar28 = iVar21 == iVar20;
                                    iVar22 = (int32_t)(uVar13 >> 0x20);
                                    if (bVar28) {
                                        iVar3 = *(int32_t *)(uVar17 + 8);
                                        bVar29 = SBORROW4(iVar3, iVar22);
                                        iVar19 = iVar3 - iVar22;
                                        bVar28 = iVar3 == iVar22;
                                    }
                                    if (!bVar28 && bVar29 == iVar19 < 0) break;
                                    bVar28 = SBORROW4(iVar21, iVar20);
                                    iVar19 = iVar21 - iVar20;
                                    if (iVar21 == iVar20) {
                                        bVar28 = SBORROW4(*(int32_t *)(uVar17 + 8), iVar22);
                                        iVar19 = *(int32_t *)(uVar17 + 8) - iVar22;
                                    }
                                    if (bVar28 != iVar19 < 0) {
                                        iVar21 = *(int32_t *)(uVar17 + 0x10);
                                        if (iVar21 == iVar20) {
                                            bVar28 = iVar22 <= *(int32_t *)(uVar17 + 0x14);
                                        } else {
                                            bVar28 = iVar21 != iVar20 && iVar20 <= iVar21;
                                        }
                                        if (bVar28) {
                                            uVar25 = uVar17;
                                        }
                                    }
                                }
                                if (uVar25 == uVar14) goto code_r0x00018015564d;
                                if ((*(char *)(*(int64_t *)0x180781f28 + 0xac0) != '\0') &&
                                   (*(char *)(*(int64_t *)0x180781f28 + 0x1df4) == '\0')) goto code_r0x0001801553e8;
                                uVar4 = *(undefined8 *)(uVar25 + 0x10);
                                uVar23 = *(uint64_t *)(uVar25 + 4);
                                iVar21 = (int32_t)uVar23;
                                uVar14 = (uint64_t)iVar21;
                                uVar13 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) *
                                         0x6db6db6db6db6db7;
                                var_ca8h = uVar23;
                                if (uVar13 < uVar14 || uVar13 - uVar14 == 0) goto code_r0x000180155851;
                                piVar24 = (int64_t *)(uVar14 * 0x38 + *(int64_t *)(arg1 + 0x40));
                                var_ca8h._4_4_ = (undefined4)(uVar23 >> 0x20);
                                uVar11 = var_ca8h._4_4_;
                                iVar15 = func_0x00018015d7b0(arg1 + 0x40, piVar24, uVar11);
                                if (iVar15 == piVar24[1] - *piVar24 >> 2) {
                                    if (iVar21 < (int32_t)uVar13 + -1) {
                                        func_0x00018015c080(arg1, iVar21 + 1, uVar4);
                                        goto code_r0x00018015580c;
                                    }
                                } else {
                                    uVar11 = func_0x000180150020(arg1 + 0x40, uVar23 & 0xffffffff, iVar15 + 1);
                                    uVar23 = CONCAT44(uVar11, iVar21);
                                    var_ca8h = uVar23;
                                }
                                func_0x00018015c080(arg1, uVar23, uVar4);
                            } else {
                                if (((iVar10 == 0x7d) || (iVar10 == 0x5d)) || (iVar10 == 0x29)) {
                                    uVar14 = *(uint64_t *)(arg1 + 0x120);
                                    uVar25 = uVar14;
                                    for (uVar13 = *(uint64_t *)(arg1 + 0x118); uVar13 < uVar14; uVar13 = uVar13 + 0x1c)
                                    {
                                        iVar21 = *(int32_t *)(uVar13 + 4);
                                        bVar29 = SBORROW4(iVar21, (int32_t)var_ca0h);
                                        iVar19 = iVar21 - (int32_t)var_ca0h;
                                        bVar28 = iVar21 == (int32_t)var_ca0h;
                                        iVar20 = (int32_t)((uint64_t)iVar6 >> 0x20);
                                        if (bVar28) {
                                            iVar22 = *(int32_t *)(uVar13 + 8);
                                            bVar29 = SBORROW4(iVar22, iVar20);
                                            iVar19 = iVar22 - iVar20;
                                            bVar28 = iVar22 == iVar20;
                                        }
                                        if (!bVar28 && bVar29 == iVar19 < 0) break;
                                        bVar28 = SBORROW4(iVar21, (int32_t)var_ca0h);
                                        iVar19 = iVar21 - (int32_t)var_ca0h;
                                        if (iVar21 == (int32_t)var_ca0h) {
                                            bVar28 = SBORROW4(*(int32_t *)(uVar13 + 8), iVar20);
                                            iVar19 = *(int32_t *)(uVar13 + 8) - iVar20;
                                        }
                                        if (bVar28 != iVar19 < 0) {
                                            iVar21 = *(int32_t *)(uVar13 + 0x10);
                                            if (iVar21 == (int32_t)var_ca0h) {
                                                bVar28 = iVar20 <= *(int32_t *)(uVar13 + 0x14);
                                            } else {
                                                bVar28 = iVar21 != (int32_t)var_ca0h && (int32_t)var_ca0h <= iVar21;
                                            }
                                            if (bVar28) {
                                                uVar25 = uVar13;
                                            }
                                        }
                                    }
                                    if (uVar25 != uVar14) {
code_r0x0001801553e8:
                                        uVar23 = *(uint64_t *)(uVar25 + 0x10);
                                        iVar21 = (int32_t)uVar23;
                                        uVar14 = (uint64_t)iVar21;
                                        uVar13 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) *
                                                 0x6db6db6db6db6db7;
                                        var_ca8h = uVar23;
                                        if (uVar13 < uVar14 || uVar13 - uVar14 == 0) goto code_r0x000180155851;
                                        piVar24 = (int64_t *)(uVar14 * 0x38 + *(int64_t *)(arg1 + 0x40));
                                        var_ca8h._4_4_ = (undefined4)(uVar23 >> 0x20);
                                        uVar11 = var_ca8h._4_4_;
                                        iVar15 = func_0x00018015d7b0(arg1 + 0x40, piVar24, uVar11);
                                        if (iVar15 == piVar24[1] - *piVar24 >> 2) {
                                            if (iVar21 < (int32_t)uVar13 + -1) {
                                                func_0x00018015c080(arg1, *(undefined8 *)(uVar25 + 4), iVar21 + 1);
                                                goto code_r0x00018015580c;
                                            }
                                        } else {
                                            uVar11 = func_0x000180150020(arg1 + 0x40, uVar23 & 0xffffffff, iVar15 + 1);
                                            uVar23 = CONCAT44(uVar11, iVar21);
                                            var_ca8h = uVar23;
                                        }
                                        func_0x00018015c080(arg1, *(undefined8 *)(uVar25 + 4), uVar23);
                                        goto code_r0x00018015580c;
                                    }
code_r0x00018015564d:
                                }
                                iVar15 = *(int64_t *)(arg1 + 0x40);
                                uVar14 = (*(int64_t *)(arg1 + 0x48) - iVar15 >> 3) * 0x6db6db6db6db6db7;
                                if ((uVar14 < uVar23 || uVar14 - uVar23 == 0) ||
                                   (iVar18 = func_0x00018015d7b0(arg1 + 0x40, uVar23 * 0x38 + iVar15, var_ca0h._4_4_),
                                   uVar14 < uVar23 || uVar14 - uVar23 == 0)) {
code_r0x000180155851:
                                    func_0x000180060370();
                                    pcVar5 = (code *)swi(3);
                                    (*pcVar5)();
                                    return;
                                }
                                if (iVar18 != *(int64_t *)(uVar23 * 0x38 + 8 + iVar15) -
                                              *(int64_t *)(uVar23 * 0x38 + iVar15) >> 2) {
                                    func_0x00018015db90(arg1 + 0x40, &var_ca0h, iVar6, 0);
                                    func_0x00018015dd90(arg1 + 0x40, &var_ca8h, iVar6, 0);
                                    goto code_r0x0001801556d9;
                                }
                            }
                        }
                    }
                } else {
                    if (((cVar9 != '\0') || (*(float *)(arg1 + 0x474) == -1.0)) ||
                       (fStack_c2c <= (float)*(double *)(iVar15 + 0x18) - *(float *)(arg1 + 0x474))) {
                        if (cVar7 == '\0') goto code_r0x000180155309;
                        goto code_r0x000180155311;
                    }
                    *(undefined4 *)(arg1 + 0x474) = 0xbf800000;
                    if (fVar34 <= fVar30) goto code_r0x00018015580c;
                    var_ca0h = var_ca8h & 0xffffffff;
                    var_ca8h = (int64_t)((int32_t)var_ca8h + 1);
                    func_0x00018015e5d0(arg1 + 0x40, &var_ca8h, var_ca8h);
code_r0x0001801556d9:
                    func_0x00018014ff20(arg1, var_ca0h, var_ca8h);
                }
            }
        } else if ((bVar28) && (*(int64_t *)(arg1 + 0x358) != 0)) {
            *(int32_t *)(arg1 + 0x3a0) = (int32_t)var_ca0h;
            uVar11 = func_0x0001800f5a90(0x180645ce8, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(iVar15 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(iVar15 + 0x15e0) + 0x148) * 4));
            func_0x00018010d030(uVar11, 0);
        } else if ((fVar30 < fVar34) && (*(int64_t *)(arg1 + 0x398) != 0)) {
            *(int32_t *)(arg1 + 0x3a0) = (int32_t)var_ca0h;
            *(undefined4 *)(arg1 + 0x3a4) = var_ca0h._4_4_;
            uVar11 = func_0x0001800f5a90(0x180645d00, 0, 
                                         *(undefined4 *)
                                          (*(int64_t *)(*(int64_t *)(iVar15 + 0x15e0) + 0x150) + -4 +
                                          (int64_t)*(int32_t *)(*(int64_t *)(iVar15 + 0x15e0) + 0x148) * 4));
            func_0x00018010d030(uVar11, 0);
        }
    } else if (*(char *)(arg1 + 0x484) == '\0') {
        *(undefined *)(arg1 + 0x486) = 1;
        *(float *)(arg1 + 0x488) = fVar36;
        *(float *)(arg1 + 0x48c) = fVar37;
    } else {
        *(undefined *)(arg1 + 0x485) = 1;
    }
code_r0x00018015580c:
    if (iStack_a8 != 0) {
        func_0x000180460d90();
    }
code_r0x00018015581e:
    func_0x000180459870(uStack_78 ^ (uint64_t)auStack_cd8);
    return;
}

// ============================================================
// Function: FUN_180155860
// Address: 0x180155860
// Size: 1558 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

int64_t fcn.180155860(int64_t arg1, int64_t arg2)
{
    undefined4 uVar1;
    undefined4 uVar2;
    undefined4 uVar3;
    int64_t var_8h;
    int64_t in_stack_00000018;
    
    *(undefined4 *)arg1 = *(undefined4 *)arg2;
    *(undefined4 *)(arg1 + 4) = *(undefined4 *)(arg2 + 4);
    *(undefined8 *)(arg1 + 8) = *(undefined8 *)(arg2 + 8);
    *(undefined8 *)(arg1 + 0x10) = *(undefined8 *)(arg2 + 0x10);
    *(undefined4 *)(arg1 + 0x18) = *(undefined4 *)(arg2 + 0x18);
    *(undefined4 *)(arg1 + 0x1c) = *(undefined4 *)(arg2 + 0x1c);
    *(undefined8 *)(arg1 + 0x20) = *(undefined8 *)(arg2 + 0x20);
    *(undefined8 *)(arg1 + 0x28) = *(undefined8 *)(arg2 + 0x28);
    *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg2 + 0x30);
    *(undefined8 *)(arg1 + 0x38) = *(undefined8 *)(arg2 + 0x38);
    *(undefined8 *)(arg1 + 0x40) = *(undefined8 *)(arg2 + 0x40);
    *(undefined *)(arg1 + 0x48) = *(undefined *)(arg2 + 0x48);
    *(undefined *)(arg1 + 0x49) = *(undefined *)(arg2 + 0x49);
    *(undefined *)(arg1 + 0x4a) = *(undefined *)(arg2 + 0x4a);
    *(undefined *)(arg1 + 0x4b) = *(undefined *)(arg2 + 0x4b);
    *(undefined *)(arg1 + 0x4c) = *(undefined *)(arg2 + 0x4c);
    *(undefined *)(arg1 + 0x4d) = *(undefined *)(arg2 + 0x4d);
    *(undefined *)(arg1 + 0x4e) = *(undefined *)(arg2 + 0x4e);
    *(undefined *)(arg1 + 0x4f) = *(undefined *)(arg2 + 0x4f);
    *(undefined *)(arg1 + 0x50) = *(undefined *)(arg2 + 0x50);
    *(undefined *)(arg1 + 0x51) = *(undefined *)(arg2 + 0x51);
    *(undefined *)(arg1 + 0x52) = *(undefined *)(arg2 + 0x52);
    *(undefined *)(arg1 + 0x53) = *(undefined *)(arg2 + 0x53);
    *(undefined *)(arg1 + 0x54) = *(undefined *)(arg2 + 0x54);
    *(undefined *)(arg1 + 0x55) = *(undefined *)(arg2 + 0x55);
    *(undefined *)(arg1 + 0x56) = *(undefined *)(arg2 + 0x56);
    *(undefined *)(arg1 + 0x57) = *(undefined *)(arg2 + 0x57);
    *(undefined *)(arg1 + 0x58) = *(undefined *)(arg2 + 0x58);
    *(undefined *)(arg1 + 0x59) = *(undefined *)(arg2 + 0x59);
    *(undefined *)(arg1 + 0x5a) = *(undefined *)(arg2 + 0x5a);
    *(undefined *)(arg1 + 0x5b) = *(undefined *)(arg2 + 0x5b);
    *(undefined *)(arg1 + 0x5c) = *(undefined *)(arg2 + 0x5c);
    *(undefined *)(arg1 + 0x5d) = *(undefined *)(arg2 + 0x5d);
    *(undefined *)(arg1 + 0x5e) = *(undefined *)(arg2 + 0x5e);
    *(undefined *)(arg1 + 0x5f) = *(undefined *)(arg2 + 0x5f);
    *(undefined *)(arg1 + 0x60) = *(undefined *)(arg2 + 0x60);
    *(undefined *)(arg1 + 0x61) = *(undefined *)(arg2 + 0x61);
    *(undefined *)(arg1 + 0x62) = *(undefined *)(arg2 + 0x62);
    *(undefined *)(arg1 + 99) = *(undefined *)(arg2 + 99);
    *(undefined *)(arg1 + 100) = *(undefined *)(arg2 + 100);
    *(undefined *)(arg1 + 0x65) = *(undefined *)(arg2 + 0x65);
    *(undefined4 *)(arg1 + 0x68) = *(undefined4 *)(arg2 + 0x68);
    *(undefined4 *)(arg1 + 0x6c) = *(undefined4 *)(arg2 + 0x6c);
    *(undefined4 *)(arg1 + 0x70) = *(undefined4 *)(arg2 + 0x70);
    *(undefined4 *)(arg1 + 0x74) = *(undefined4 *)(arg2 + 0x74);
    *(undefined4 *)(arg1 + 0x78) = *(undefined4 *)(arg2 + 0x78);
    *(undefined4 *)(arg1 + 0x7c) = *(undefined4 *)(arg2 + 0x7c);
    *(undefined *)(arg1 + 0x80) = *(undefined *)(arg2 + 0x80);
    *(undefined *)(arg1 + 0x81) = *(undefined *)(arg2 + 0x81);
    *(undefined *)(arg1 + 0x82) = *(undefined *)(arg2 + 0x82);
    *(undefined *)(arg1 + 0x83) = *(undefined *)(arg2 + 0x83);
    *(undefined *)(arg1 + 0x84) = *(undefined *)(arg2 + 0x84);
    *(undefined *)(arg1 + 0x85) = *(undefined *)(arg2 + 0x85);
    *(undefined *)(arg1 + 0x86) = *(undefined *)(arg2 + 0x86);
    *(undefined *)(arg1 + 0x87) = *(undefined *)(arg2 + 0x87);
    *(undefined *)(arg1 + 0x88) = *(undefined *)(arg2 + 0x88);
    *(undefined *)(arg1 + 0x89) = *(undefined *)(arg2 + 0x89);
    *(undefined *)(arg1 + 0x8a) = *(undefined *)(arg2 + 0x8a);
    *(undefined8 *)(arg1 + 0x90) = *(undefined8 *)(arg2 + 0x90);
    *(undefined8 *)(arg1 + 0x98) = *(undefined8 *)(arg2 + 0x98);
    *(undefined8 *)(arg1 + 0xa0) = *(undefined8 *)(arg2 + 0xa0);
    *(undefined8 *)(arg1 + 0xa8) = *(undefined8 *)(arg2 + 0xa8);
    *(undefined8 *)(arg1 + 0xb0) = *(undefined8 *)(arg2 + 0xb0);
    *(undefined *)(arg1 + 0xb8) = *(undefined *)(arg2 + 0xb8);
    *(undefined *)(arg1 + 0xb9) = *(undefined *)(arg2 + 0xb9);
    *(undefined *)(arg1 + 0xba) = *(undefined *)(arg2 + 0xba);
    *(undefined *)(arg1 + 0xbb) = *(undefined *)(arg2 + 0xbb);
    *(undefined *)(arg1 + 0xbc) = *(undefined *)(arg2 + 0xbc);
    *(undefined *)(arg1 + 0xbd) = *(undefined *)(arg2 + 0xbd);
    *(undefined *)(arg1 + 0xbe) = *(undefined *)(arg2 + 0xbe);
    *(undefined4 *)(arg1 + 0xc0) = *(undefined4 *)(arg2 + 0xc0);
    *(undefined4 *)(arg1 + 0xc4) = *(undefined4 *)(arg2 + 0xc4);
    *(undefined4 *)(arg1 + 200) = *(undefined4 *)(arg2 + 200);
    *(undefined4 *)(arg1 + 0xcc) = *(undefined4 *)(arg2 + 0xcc);
    *(undefined4 *)(arg1 + 0xd0) = *(undefined4 *)(arg2 + 0xd0);
    *(undefined8 *)(arg1 + 0xd4) = *(undefined8 *)(arg2 + 0xd4);
    *(undefined8 *)(arg1 + 0xe0) = *(undefined8 *)(arg2 + 0xe0);
    *(undefined8 *)(arg1 + 0xe8) = *(undefined8 *)(arg2 + 0xe8);
    *(undefined4 *)(arg1 + 0xf0) = *(undefined4 *)(arg2 + 0xf0);
    *(undefined *)(arg1 + 0xf4) = *(undefined *)(arg2 + 0xf4);
    *(undefined4 *)(arg1 + 0xf8) = *(undefined4 *)(arg2 + 0xf8);
    *(undefined4 *)(arg1 + 0xfc) = *(undefined4 *)(arg2 + 0xfc);
    *(undefined4 *)(arg1 + 0x100) = *(undefined4 *)(arg2 + 0x100);
    *(undefined4 *)(arg1 + 0x104) = *(undefined4 *)(arg2 + 0x104);
    *(undefined *)(arg1 + 0x108) = *(undefined *)(arg2 + 0x108);
    *(undefined *)(arg1 + 0x109) = *(undefined *)(arg2 + 0x109);
    *(undefined *)(arg1 + 0x10a) = *(undefined *)(arg2 + 0x10a);
    *(undefined *)(arg1 + 0x10b) = *(undefined *)(arg2 + 0x10b);
    *(undefined4 *)(arg1 + 0x10c) = *(undefined4 *)(arg2 + 0x10c);
    fcn.180498030(arg1 + 0x110, arg2 + 0x110, 0x9b0);
    *(undefined *)(arg1 + 0xac0) = *(undefined *)(arg2 + 0xac0);
    *(undefined8 *)(arg1 + 0xac4) = *(undefined8 *)(arg2 + 0xac4);
    uVar1 = *(undefined4 *)(arg2 + 0xad0);
    uVar2 = *(undefined4 *)(arg2 + 0xad4);
    uVar3 = *(undefined4 *)(arg2 + 0xad8);
    *(undefined4 *)(arg1 + 0xacc) = *(undefined4 *)(arg2 + 0xacc);
    *(undefined4 *)(arg1 + 0xad0) = uVar1;
    *(undefined4 *)(arg1 + 0xad4) = uVar2;
    *(undefined4 *)(arg1 + 0xad8) = uVar3;
    uVar1 = *(undefined4 *)(arg2 + 0xae0);
    uVar2 = *(undefined4 *)(arg2 + 0xae4);
    uVar3 = *(undefined4 *)(arg2 + 0xae8);
    *(undefined4 *)(arg1 + 0xadc) = *(undefined4 *)(arg2 + 0xadc);
    *(undefined4 *)(arg1 + 0xae0) = uVar1;
    *(undefined4 *)(arg1 + 0xae4) = uVar2;
    *(undefined4 *)(arg1 + 0xae8) = uVar3;
    *(undefined8 *)(arg1 + 0xaec) = *(undefined8 *)(arg2 + 0xaec);
    uVar1 = *(undefined4 *)(arg2 + 0xafc);
    uVar2 = *(undefined4 *)(arg2 + 0xb00);
    uVar3 = *(undefined4 *)(arg2 + 0xb04);
    *(undefined4 *)(arg1 + 0xaf8) = *(undefined4 *)(arg2 + 0xaf8);
    *(undefined4 *)(arg1 + 0xafc) = uVar1;
    *(undefined4 *)(arg1 + 0xb00) = uVar2;
    *(undefined4 *)(arg1 + 0xb04) = uVar3;
    uVar1 = *(undefined4 *)(arg2 + 0xb0c);
    uVar2 = *(undefined4 *)(arg2 + 0xb10);
    uVar3 = *(undefined4 *)(arg2 + 0xb14);
    *(undefined4 *)(arg1 + 0xb08) = *(undefined4 *)(arg2 + 0xb08);
    *(undefined4 *)(arg1 + 0xb0c) = uVar1;
    *(undefined4 *)(arg1 + 0xb10) = uVar2;
    *(undefined4 *)(arg1 + 0xb14) = uVar3;
    *(undefined8 *)(arg1 + 0xb18) = *(undefined8 *)(arg2 + 0xb18);
    *(undefined4 *)(arg1 + 0xb20) = *(undefined4 *)(arg2 + 0xb20);
    *(undefined *)(arg1 + 0xb24) = *(undefined *)(arg2 + 0xb24);
    *(undefined4 *)(arg1 + 0xb25) = *(undefined4 *)(arg2 + 0xb25);
    *(undefined *)(arg1 + 0xb29) = *(undefined *)(arg2 + 0xb29);
    *(undefined8 *)(arg1 + 0xb2a) = *(undefined8 *)(arg2 + 0xb2a);
    *(undefined2 *)(arg1 + 0xb32) = *(undefined2 *)(arg2 + 0xb32);
    *(undefined8 *)(arg1 + 0xb34) = *(undefined8 *)(arg2 + 0xb34);
    *(undefined2 *)(arg1 + 0xb3c) = *(undefined2 *)(arg2 + 0xb3c);
    *(undefined4 *)(arg1 + 0xb3e) = *(undefined4 *)(arg2 + 0xb3e);
    *(undefined *)(arg1 + 0xb42) = *(undefined *)(arg2 + 0xb42);
    uVar1 = *(undefined4 *)(arg2 + 0xb4c);
    uVar2 = *(undefined4 *)(arg2 + 0xb50);
    uVar3 = *(undefined4 *)(arg2 + 0xb54);
    *(undefined4 *)(arg1 + 0xb48) = *(undefined4 *)(arg2 + 0xb48);
    *(undefined4 *)(arg1 + 0xb4c) = uVar1;
    *(undefined4 *)(arg1 + 0xb50) = uVar2;
    *(undefined4 *)(arg1 + 0xb54) = uVar3;
    uVar1 = *(undefined4 *)(arg2 + 0xb5c);
    uVar2 = *(undefined4 *)(arg2 + 0xb60);
    uVar3 = *(undefined4 *)(arg2 + 0xb64);
    *(undefined4 *)(arg1 + 0xb58) = *(undefined4 *)(arg2 + 0xb58);
    *(undefined4 *)(arg1 + 0xb5c) = uVar1;
    *(undefined4 *)(arg1 + 0xb60) = uVar2;
    *(undefined4 *)(arg1 + 0xb64) = uVar3;
    *(undefined8 *)(arg1 + 0xb68) = *(undefined8 *)(arg2 + 0xb68);
    *(undefined4 *)(arg1 + 0xb70) = *(undefined4 *)(arg2 + 0xb70);
    *(undefined *)(arg1 + 0xb74) = *(undefined *)(arg2 + 0xb74);
    *(undefined4 *)(arg1 + 0xb75) = *(undefined4 *)(arg2 + 0xb75);
    *(undefined *)(arg1 + 0xb79) = *(undefined *)(arg2 + 0xb79);
    *(undefined *)(arg1 + 0xb7a) = *(undefined *)(arg2 + 0xb7a);
    *(undefined *)(arg1 + 0xb7b) = *(undefined *)(arg2 + 0xb7b);
    uVar1 = *(undefined4 *)(arg2 + 0xb80);
    uVar2 = *(undefined4 *)(arg2 + 0xb84);
    uVar3 = *(undefined4 *)(arg2 + 0xb88);
    *(undefined4 *)(arg1 + 0xb7c) = *(undefined4 *)(arg2 + 0xb7c);
    *(undefined4 *)(arg1 + 0xb80) = uVar1;
    *(undefined4 *)(arg1 + 0xb84) = uVar2;
    *(undefined4 *)(arg1 + 0xb88) = uVar3;
    *(undefined4 *)(arg1 + 0xb8c) = *(undefined4 *)(arg2 + 0xb8c);
    uVar1 = *(undefined4 *)(arg2 + 0xb94);
    uVar2 = *(undefined4 *)(arg2 + 0xb98);
    uVar3 = *(undefined4 *)(arg2 + 0xb9c);
    *(undefined4 *)(arg1 + 0xb90) = *(undefined4 *)(arg2 + 0xb90);
    *(undefined4 *)(arg1 + 0xb94) = uVar1;
    *(undefined4 *)(arg1 + 0xb98) = uVar2;
    *(undefined4 *)(arg1 + 0xb9c) = uVar3;
    *(undefined4 *)(arg1 + 0xba0) = *(undefined4 *)(arg2 + 0xba0);
    uVar1 = *(undefined4 *)(arg2 + 0xba8);
    uVar2 = *(undefined4 *)(arg2 + 0xbac);
    uVar3 = *(undefined4 *)(arg2 + 0xbb0);
    *(undefined4 *)(arg1 + 0xba4) = *(undefined4 *)(arg2 + 0xba4);
    *(undefined4 *)(arg1 + 0xba8) = uVar1;
    *(undefined4 *)(arg1 + 0xbac) = uVar2;
    *(undefined4 *)(arg1 + 0xbb0) = uVar3;
    uVar1 = *(undefined4 *)(arg2 + 3000);
    uVar2 = *(undefined4 *)(arg2 + 0xbbc);
    uVar3 = *(undefined4 *)(arg2 + 0xbc0);
    *(undefined4 *)(arg1 + 0xbb4) = *(undefined4 *)(arg2 + 0xbb4);
    *(undefined4 *)(arg1 + 3000) = uVar1;
    *(undefined4 *)(arg1 + 0xbbc) = uVar2;
    *(undefined4 *)(arg1 + 0xbc0) = uVar3;
    *(undefined8 *)(arg1 + 0xbc4) = *(undefined8 *)(arg2 + 0xbc4);
    uVar1 = *(undefined4 *)(arg2 + 0xbd0);
    uVar2 = *(undefined4 *)(arg2 + 0xbd4);
    uVar3 = *(undefined4 *)(arg2 + 0xbd8);
    *(undefined4 *)(arg1 + 0xbcc) = *(undefined4 *)(arg2 + 0xbcc);
    *(undefined4 *)(arg1 + 0xbd0) = uVar1;
    *(undefined4 *)(arg1 + 0xbd4) = uVar2;
    *(undefined4 *)(arg1 + 0xbd8) = uVar3;
    *(undefined4 *)(arg1 + 0xbdc) = *(undefined4 *)(arg2 + 0xbdc);
    *(undefined4 *)(arg1 + 0xbe0) = *(undefined4 *)(arg2 + 0xbe0);
    *(undefined *)(arg1 + 0xbe4) = *(undefined *)(arg2 + 0xbe4);
    *(undefined *)(arg1 + 0xbe5) = *(undefined *)(arg2 + 0xbe5);
    *(undefined2 *)(arg1 + 0xbe6) = *(undefined2 *)(arg2 + 0xbe6);
    *(undefined8 *)(arg1 + 0xbe8) = 0;
    *(undefined8 *)(arg1 + 0xbf0) = 0;
    fcn.1801313a0(in_stack_00000018);
    *(undefined4 *)(arg1 + 0xbf8) = *(undefined4 *)(arg2 + 0xbf8);
    *(undefined8 *)(arg1 + 0xc00) = *(undefined8 *)(arg2 + 0xc00);
    *(undefined8 *)(arg1 + 0xc08) = *(undefined8 *)(arg2 + 0xc08);
    *(undefined8 *)(arg1 + 0xc10) = *(undefined8 *)(arg2 + 0xc10);
    return arg1;
}

// ============================================================
// Function: FUN_180155e80
// Address: 0x180155e80
// Size: 62 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180155e80(int64_t arg1, int64_t arg_68h)
{
    int64_t *piVar1;
    int32_t iVar2;
    uint64_t *puVar3;
    int16_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    code *pcVar7;
    int16_t iVar8;
    undefined4 uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int16_t *piVar15;
    int16_t *piVar16;
    int32_t iVar17;
    uint64_t *puVar18;
    int16_t iVar19;
    int32_t iVar20;
    uint64_t uVar21;
    int64_t *piVar22;
    int32_t iVar23;
    bool bVar24;
    bool bVar25;
    int64_t var_8h;
    int64_t var_10h;
    uint64_t var_18h;
    uint64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    piVar1 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, piVar1);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar3 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar3) {
            return;
        }
        iVar20 = *(int32_t *)(puVar18 + 1);
        iVar23 = *(int32_t *)puVar18;
        bVar24 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        if (iVar23 == iVar20) {
            bVar24 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
            iVar17 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
        }
        puVar10 = puVar18 + 1;
        if (bVar24 != iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar14 = *puVar10;
        bVar25 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        bVar24 = iVar23 == iVar20;
        if (bVar24) {
            iVar20 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar23 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar25 = SBORROW4(iVar23, iVar20);
            iVar17 = iVar23 - iVar20;
            bVar24 = iVar23 == iVar20;
        }
        iVar13 = *piVar1;
        puVar10 = puVar18 + 1;
        if (!bVar24 && bVar25 == iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
        var_18h = *puVar10;
        iVar20 = (int32_t)uVar14;
        uVar11 = (uint64_t)iVar20;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) {
code_r0x0001801562fa:
            func_0x000180060370();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, uVar14 >> 0x20);
        if (iVar12 == 0) {
            var_10h = uVar14;
            if (0 < iVar20) {
                uVar11 = (uint64_t)(iVar20 + -1);
                if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
                var_10h = CONCAT44(*(undefined4 *)(uVar11 * 0x38 + 0x28 + iVar13), iVar20 + -1);
            }
        } else {
            uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
            var_10h = CONCAT44(uVar9, iVar20);
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
        uVar11 = (uint64_t)(int32_t)var_10h;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, (uint64_t)var_10h >> 0x20);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar19 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar19 = -3;
        }
        iVar23 = (int32_t)var_18h;
        uVar11 = (uint64_t)iVar23;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        var_60h._4_4_ = (int32_t)(var_18h >> 0x20);
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, var_60h._4_4_);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar8 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar8 = -3;
        }
        iVar17 = (int32_t)(uVar14 >> 0x20);
        if ((iVar19 == 0x7b) && (iVar8 == 0x7d)) {
            uVar11 = (uint64_t)iVar23;
            iVar13 = func_0x00018015d7b0(piVar1, piVar22);
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            if (iVar13 == *(int64_t *)(uVar11 * 0x38 + 8 + *piVar1) - *(int64_t *)(uVar11 * 0x38 + *piVar1) >> 2) {
                if (iVar23 < (int32_t)uVar21 + -1) {
                    var_18h = (uint64_t)(iVar23 + 1);
                }
            } else {
                uVar9 = func_0x000180150020(piVar1, var_18h & 0xffffffff, iVar13 + 1);
                var_18h = CONCAT44(uVar9, iVar23);
            }
            iVar13 = *piVar1;
            uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
            uVar11 = (uint64_t)iVar20;
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, iVar17);
            if (iVar12 == 0) {
                if (0 < iVar20) {
                    uVar14 = (uint64_t)(iVar20 + -1);
                    if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                    uVar14 = CONCAT44(*(undefined4 *)(uVar14 * 0x38 + 0x28 + iVar13), iVar20 + -1);
                }
                *puVar18 = uVar14;
                puVar18[1] = var_18h;
            } else {
                uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
                var_20h = CONCAT44(uVar9, iVar20);
                *puVar18 = var_20h;
                puVar18[1] = var_18h;
            }
code_r0x0001801562c0:
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
        } else {
            piVar4 = *(int16_t **)(arg1 + 0x120);
            piVar16 = piVar4;
            for (piVar15 = *(int16_t **)(arg1 + 0x118); piVar15 < piVar4; piVar15 = piVar15 + 0xe) {
                iVar2 = *(int32_t *)(piVar15 + 2);
                if (iVar2 == iVar20) {
                    bVar24 = iVar17 < *(int32_t *)(piVar15 + 4);
                } else {
                    bVar24 = iVar2 != iVar20 && iVar20 <= iVar2;
                }
                if (bVar24) break;
                bVar24 = SBORROW4(iVar2, iVar20);
                iVar5 = iVar2 - iVar20;
                if (iVar2 == iVar20) {
                    bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), iVar17);
                    iVar5 = *(int32_t *)(piVar15 + 4) - iVar17;
                }
                if (bVar24 != iVar5 < 0) {
                    iVar5 = *(int32_t *)(piVar15 + 8);
                    if (iVar5 == iVar20) {
                        bVar24 = iVar17 <= *(int32_t *)(piVar15 + 10);
                    } else {
                        bVar24 = iVar5 != iVar20 && iVar20 <= iVar5;
                    }
                    if (bVar24) {
                        bVar24 = SBORROW4(iVar2, iVar23);
                        iVar6 = iVar2 - iVar23;
                        if (iVar2 == iVar23) {
                            bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), var_60h._4_4_);
                            iVar6 = *(int32_t *)(piVar15 + 4) - var_60h._4_4_;
                        }
                        if (bVar24 != iVar6 < 0) {
                            if (iVar5 == iVar23) {
                                bVar24 = var_60h._4_4_ <= *(int32_t *)(piVar15 + 10);
                            } else {
                                bVar24 = iVar5 != iVar23 && iVar23 <= iVar5;
                            }
                            if ((bVar24) && (*piVar15 == 0x7b)) {
                                piVar16 = piVar15;
                            }
                        }
                    }
                }
            }
            if (piVar16 != piVar4) {
                var_68h = *(int64_t *)(piVar16 + 2);
                iVar20 = (int32_t)var_68h;
                uVar14 = (uint64_t)iVar20;
                if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                uVar11 = *(uint64_t *)(piVar16 + 8);
                var_58h._4_4_ = (undefined4)((uint64_t)var_68h >> 0x20);
                piVar22 = (int64_t *)(uVar14 * 0x38 + *piVar1);
                iVar13 = func_0x00018015d7b0(piVar1, piVar22, var_58h._4_4_);
                if (iVar13 == piVar22[1] - *piVar22 >> 2) {
                    if (iVar20 < (int32_t)uVar21 + -1) {
                        var_68h = (int64_t)(iVar20 + 1);
                    }
                } else {
                    uVar9 = func_0x000180150020(piVar1, var_68h & 0xffffffff, iVar13 + 1);
                    var_68h = CONCAT44(uVar9, iVar20);
                }
                *puVar18 = var_68h;
                puVar18[1] = uVar11;
                goto code_r0x0001801562c0;
            }
        }
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_180155ebe
// Address: 0x180155ebe
// Size: 1073 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180155e80(int64_t arg1, int64_t arg_68h)
{
    int64_t *piVar1;
    int32_t iVar2;
    uint64_t *puVar3;
    int16_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    code *pcVar7;
    int16_t iVar8;
    undefined4 uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int16_t *piVar15;
    int16_t *piVar16;
    int32_t iVar17;
    uint64_t *puVar18;
    int16_t iVar19;
    int32_t iVar20;
    uint64_t uVar21;
    int64_t *piVar22;
    int32_t iVar23;
    bool bVar24;
    bool bVar25;
    int64_t var_8h;
    int64_t var_10h;
    uint64_t var_18h;
    uint64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    piVar1 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, piVar1);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar3 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar3) {
            return;
        }
        iVar20 = *(int32_t *)(puVar18 + 1);
        iVar23 = *(int32_t *)puVar18;
        bVar24 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        if (iVar23 == iVar20) {
            bVar24 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
            iVar17 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
        }
        puVar10 = puVar18 + 1;
        if (bVar24 != iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar14 = *puVar10;
        bVar25 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        bVar24 = iVar23 == iVar20;
        if (bVar24) {
            iVar20 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar23 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar25 = SBORROW4(iVar23, iVar20);
            iVar17 = iVar23 - iVar20;
            bVar24 = iVar23 == iVar20;
        }
        iVar13 = *piVar1;
        puVar10 = puVar18 + 1;
        if (!bVar24 && bVar25 == iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
        var_18h = *puVar10;
        iVar20 = (int32_t)uVar14;
        uVar11 = (uint64_t)iVar20;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) {
code_r0x0001801562fa:
            func_0x000180060370();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, uVar14 >> 0x20);
        if (iVar12 == 0) {
            var_10h = uVar14;
            if (0 < iVar20) {
                uVar11 = (uint64_t)(iVar20 + -1);
                if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
                var_10h = CONCAT44(*(undefined4 *)(uVar11 * 0x38 + 0x28 + iVar13), iVar20 + -1);
            }
        } else {
            uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
            var_10h = CONCAT44(uVar9, iVar20);
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
        uVar11 = (uint64_t)(int32_t)var_10h;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, (uint64_t)var_10h >> 0x20);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar19 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar19 = -3;
        }
        iVar23 = (int32_t)var_18h;
        uVar11 = (uint64_t)iVar23;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        var_60h._4_4_ = (int32_t)(var_18h >> 0x20);
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, var_60h._4_4_);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar8 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar8 = -3;
        }
        iVar17 = (int32_t)(uVar14 >> 0x20);
        if ((iVar19 == 0x7b) && (iVar8 == 0x7d)) {
            uVar11 = (uint64_t)iVar23;
            iVar13 = func_0x00018015d7b0(piVar1, piVar22);
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            if (iVar13 == *(int64_t *)(uVar11 * 0x38 + 8 + *piVar1) - *(int64_t *)(uVar11 * 0x38 + *piVar1) >> 2) {
                if (iVar23 < (int32_t)uVar21 + -1) {
                    var_18h = (uint64_t)(iVar23 + 1);
                }
            } else {
                uVar9 = func_0x000180150020(piVar1, var_18h & 0xffffffff, iVar13 + 1);
                var_18h = CONCAT44(uVar9, iVar23);
            }
            iVar13 = *piVar1;
            uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
            uVar11 = (uint64_t)iVar20;
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, iVar17);
            if (iVar12 == 0) {
                if (0 < iVar20) {
                    uVar14 = (uint64_t)(iVar20 + -1);
                    if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                    uVar14 = CONCAT44(*(undefined4 *)(uVar14 * 0x38 + 0x28 + iVar13), iVar20 + -1);
                }
                *puVar18 = uVar14;
                puVar18[1] = var_18h;
            } else {
                uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
                var_20h = CONCAT44(uVar9, iVar20);
                *puVar18 = var_20h;
                puVar18[1] = var_18h;
            }
code_r0x0001801562c0:
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
        } else {
            piVar4 = *(int16_t **)(arg1 + 0x120);
            piVar16 = piVar4;
            for (piVar15 = *(int16_t **)(arg1 + 0x118); piVar15 < piVar4; piVar15 = piVar15 + 0xe) {
                iVar2 = *(int32_t *)(piVar15 + 2);
                if (iVar2 == iVar20) {
                    bVar24 = iVar17 < *(int32_t *)(piVar15 + 4);
                } else {
                    bVar24 = iVar2 != iVar20 && iVar20 <= iVar2;
                }
                if (bVar24) break;
                bVar24 = SBORROW4(iVar2, iVar20);
                iVar5 = iVar2 - iVar20;
                if (iVar2 == iVar20) {
                    bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), iVar17);
                    iVar5 = *(int32_t *)(piVar15 + 4) - iVar17;
                }
                if (bVar24 != iVar5 < 0) {
                    iVar5 = *(int32_t *)(piVar15 + 8);
                    if (iVar5 == iVar20) {
                        bVar24 = iVar17 <= *(int32_t *)(piVar15 + 10);
                    } else {
                        bVar24 = iVar5 != iVar20 && iVar20 <= iVar5;
                    }
                    if (bVar24) {
                        bVar24 = SBORROW4(iVar2, iVar23);
                        iVar6 = iVar2 - iVar23;
                        if (iVar2 == iVar23) {
                            bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), var_60h._4_4_);
                            iVar6 = *(int32_t *)(piVar15 + 4) - var_60h._4_4_;
                        }
                        if (bVar24 != iVar6 < 0) {
                            if (iVar5 == iVar23) {
                                bVar24 = var_60h._4_4_ <= *(int32_t *)(piVar15 + 10);
                            } else {
                                bVar24 = iVar5 != iVar23 && iVar23 <= iVar5;
                            }
                            if ((bVar24) && (*piVar15 == 0x7b)) {
                                piVar16 = piVar15;
                            }
                        }
                    }
                }
            }
            if (piVar16 != piVar4) {
                var_68h = *(int64_t *)(piVar16 + 2);
                iVar20 = (int32_t)var_68h;
                uVar14 = (uint64_t)iVar20;
                if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                uVar11 = *(uint64_t *)(piVar16 + 8);
                var_58h._4_4_ = (undefined4)((uint64_t)var_68h >> 0x20);
                piVar22 = (int64_t *)(uVar14 * 0x38 + *piVar1);
                iVar13 = func_0x00018015d7b0(piVar1, piVar22, var_58h._4_4_);
                if (iVar13 == piVar22[1] - *piVar22 >> 2) {
                    if (iVar20 < (int32_t)uVar21 + -1) {
                        var_68h = (int64_t)(iVar20 + 1);
                    }
                } else {
                    uVar9 = func_0x000180150020(piVar1, var_68h & 0xffffffff, iVar13 + 1);
                    var_68h = CONCAT44(uVar9, iVar20);
                }
                *puVar18 = var_68h;
                puVar18[1] = uVar11;
                goto code_r0x0001801562c0;
            }
        }
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_1801562ef
// Address: 0x1801562ef
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180155e80(int64_t arg1, int64_t arg_68h)
{
    int64_t *piVar1;
    int32_t iVar2;
    uint64_t *puVar3;
    int16_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    code *pcVar7;
    int16_t iVar8;
    undefined4 uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int16_t *piVar15;
    int16_t *piVar16;
    int32_t iVar17;
    uint64_t *puVar18;
    int16_t iVar19;
    int32_t iVar20;
    uint64_t uVar21;
    int64_t *piVar22;
    int32_t iVar23;
    bool bVar24;
    bool bVar25;
    int64_t var_8h;
    int64_t var_10h;
    uint64_t var_18h;
    uint64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    piVar1 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, piVar1);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar3 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar3) {
            return;
        }
        iVar20 = *(int32_t *)(puVar18 + 1);
        iVar23 = *(int32_t *)puVar18;
        bVar24 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        if (iVar23 == iVar20) {
            bVar24 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
            iVar17 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
        }
        puVar10 = puVar18 + 1;
        if (bVar24 != iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar14 = *puVar10;
        bVar25 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        bVar24 = iVar23 == iVar20;
        if (bVar24) {
            iVar20 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar23 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar25 = SBORROW4(iVar23, iVar20);
            iVar17 = iVar23 - iVar20;
            bVar24 = iVar23 == iVar20;
        }
        iVar13 = *piVar1;
        puVar10 = puVar18 + 1;
        if (!bVar24 && bVar25 == iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
        var_18h = *puVar10;
        iVar20 = (int32_t)uVar14;
        uVar11 = (uint64_t)iVar20;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) {
code_r0x0001801562fa:
            func_0x000180060370();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, uVar14 >> 0x20);
        if (iVar12 == 0) {
            var_10h = uVar14;
            if (0 < iVar20) {
                uVar11 = (uint64_t)(iVar20 + -1);
                if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
                var_10h = CONCAT44(*(undefined4 *)(uVar11 * 0x38 + 0x28 + iVar13), iVar20 + -1);
            }
        } else {
            uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
            var_10h = CONCAT44(uVar9, iVar20);
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
        uVar11 = (uint64_t)(int32_t)var_10h;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, (uint64_t)var_10h >> 0x20);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar19 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar19 = -3;
        }
        iVar23 = (int32_t)var_18h;
        uVar11 = (uint64_t)iVar23;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        var_60h._4_4_ = (int32_t)(var_18h >> 0x20);
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, var_60h._4_4_);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar8 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar8 = -3;
        }
        iVar17 = (int32_t)(uVar14 >> 0x20);
        if ((iVar19 == 0x7b) && (iVar8 == 0x7d)) {
            uVar11 = (uint64_t)iVar23;
            iVar13 = func_0x00018015d7b0(piVar1, piVar22);
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            if (iVar13 == *(int64_t *)(uVar11 * 0x38 + 8 + *piVar1) - *(int64_t *)(uVar11 * 0x38 + *piVar1) >> 2) {
                if (iVar23 < (int32_t)uVar21 + -1) {
                    var_18h = (uint64_t)(iVar23 + 1);
                }
            } else {
                uVar9 = func_0x000180150020(piVar1, var_18h & 0xffffffff, iVar13 + 1);
                var_18h = CONCAT44(uVar9, iVar23);
            }
            iVar13 = *piVar1;
            uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
            uVar11 = (uint64_t)iVar20;
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, iVar17);
            if (iVar12 == 0) {
                if (0 < iVar20) {
                    uVar14 = (uint64_t)(iVar20 + -1);
                    if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                    uVar14 = CONCAT44(*(undefined4 *)(uVar14 * 0x38 + 0x28 + iVar13), iVar20 + -1);
                }
                *puVar18 = uVar14;
                puVar18[1] = var_18h;
            } else {
                uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
                var_20h = CONCAT44(uVar9, iVar20);
                *puVar18 = var_20h;
                puVar18[1] = var_18h;
            }
code_r0x0001801562c0:
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
        } else {
            piVar4 = *(int16_t **)(arg1 + 0x120);
            piVar16 = piVar4;
            for (piVar15 = *(int16_t **)(arg1 + 0x118); piVar15 < piVar4; piVar15 = piVar15 + 0xe) {
                iVar2 = *(int32_t *)(piVar15 + 2);
                if (iVar2 == iVar20) {
                    bVar24 = iVar17 < *(int32_t *)(piVar15 + 4);
                } else {
                    bVar24 = iVar2 != iVar20 && iVar20 <= iVar2;
                }
                if (bVar24) break;
                bVar24 = SBORROW4(iVar2, iVar20);
                iVar5 = iVar2 - iVar20;
                if (iVar2 == iVar20) {
                    bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), iVar17);
                    iVar5 = *(int32_t *)(piVar15 + 4) - iVar17;
                }
                if (bVar24 != iVar5 < 0) {
                    iVar5 = *(int32_t *)(piVar15 + 8);
                    if (iVar5 == iVar20) {
                        bVar24 = iVar17 <= *(int32_t *)(piVar15 + 10);
                    } else {
                        bVar24 = iVar5 != iVar20 && iVar20 <= iVar5;
                    }
                    if (bVar24) {
                        bVar24 = SBORROW4(iVar2, iVar23);
                        iVar6 = iVar2 - iVar23;
                        if (iVar2 == iVar23) {
                            bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), var_60h._4_4_);
                            iVar6 = *(int32_t *)(piVar15 + 4) - var_60h._4_4_;
                        }
                        if (bVar24 != iVar6 < 0) {
                            if (iVar5 == iVar23) {
                                bVar24 = var_60h._4_4_ <= *(int32_t *)(piVar15 + 10);
                            } else {
                                bVar24 = iVar5 != iVar23 && iVar23 <= iVar5;
                            }
                            if ((bVar24) && (*piVar15 == 0x7b)) {
                                piVar16 = piVar15;
                            }
                        }
                    }
                }
            }
            if (piVar16 != piVar4) {
                var_68h = *(int64_t *)(piVar16 + 2);
                iVar20 = (int32_t)var_68h;
                uVar14 = (uint64_t)iVar20;
                if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                uVar11 = *(uint64_t *)(piVar16 + 8);
                var_58h._4_4_ = (undefined4)((uint64_t)var_68h >> 0x20);
                piVar22 = (int64_t *)(uVar14 * 0x38 + *piVar1);
                iVar13 = func_0x00018015d7b0(piVar1, piVar22, var_58h._4_4_);
                if (iVar13 == piVar22[1] - *piVar22 >> 2) {
                    if (iVar20 < (int32_t)uVar21 + -1) {
                        var_68h = (int64_t)(iVar20 + 1);
                    }
                } else {
                    uVar9 = func_0x000180150020(piVar1, var_68h & 0xffffffff, iVar13 + 1);
                    var_68h = CONCAT44(uVar9, iVar20);
                }
                *puVar18 = var_68h;
                puVar18[1] = uVar11;
                goto code_r0x0001801562c0;
            }
        }
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_1801562fa
// Address: 0x1801562fa
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_54h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_18h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.180155e80(int64_t arg1, int64_t arg_68h)
{
    int64_t *piVar1;
    int32_t iVar2;
    uint64_t *puVar3;
    int16_t *piVar4;
    int32_t iVar5;
    int32_t iVar6;
    code *pcVar7;
    int16_t iVar8;
    undefined4 uVar9;
    uint64_t *puVar10;
    uint64_t uVar11;
    int64_t iVar12;
    int64_t iVar13;
    uint64_t uVar14;
    int16_t *piVar15;
    int16_t *piVar16;
    int32_t iVar17;
    uint64_t *puVar18;
    int16_t iVar19;
    int32_t iVar20;
    uint64_t uVar21;
    int64_t *piVar22;
    int32_t iVar23;
    bool bVar24;
    bool bVar25;
    int64_t var_8h;
    int64_t var_10h;
    uint64_t var_18h;
    uint64_t var_20h;
    int64_t var_88h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    
    piVar1 = (int64_t *)(arg1 + 0x40);
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, piVar1);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar3 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar3) {
            return;
        }
        iVar20 = *(int32_t *)(puVar18 + 1);
        iVar23 = *(int32_t *)puVar18;
        bVar24 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        if (iVar23 == iVar20) {
            bVar24 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
            iVar17 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
        }
        puVar10 = puVar18 + 1;
        if (bVar24 != iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar14 = *puVar10;
        bVar25 = SBORROW4(iVar23, iVar20);
        iVar17 = iVar23 - iVar20;
        bVar24 = iVar23 == iVar20;
        if (bVar24) {
            iVar20 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar23 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar25 = SBORROW4(iVar23, iVar20);
            iVar17 = iVar23 - iVar20;
            bVar24 = iVar23 == iVar20;
        }
        iVar13 = *piVar1;
        puVar10 = puVar18 + 1;
        if (!bVar24 && bVar25 == iVar17 < 0) {
            puVar10 = puVar18;
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
        var_18h = *puVar10;
        iVar20 = (int32_t)uVar14;
        uVar11 = (uint64_t)iVar20;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) {
code_r0x0001801562fa:
            func_0x000180060370();
            pcVar7 = (code *)swi(3);
            (*pcVar7)();
            return;
        }
        iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, uVar14 >> 0x20);
        if (iVar12 == 0) {
            var_10h = uVar14;
            if (0 < iVar20) {
                uVar11 = (uint64_t)(iVar20 + -1);
                if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
                var_10h = CONCAT44(*(undefined4 *)(uVar11 * 0x38 + 0x28 + iVar13), iVar20 + -1);
            }
        } else {
            uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
            var_10h = CONCAT44(uVar9, iVar20);
        }
        uVar21 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
        uVar11 = (uint64_t)(int32_t)var_10h;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, (uint64_t)var_10h >> 0x20);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar19 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar19 = -3;
        }
        iVar23 = (int32_t)var_18h;
        uVar11 = (uint64_t)iVar23;
        if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
        var_60h._4_4_ = (int32_t)(var_18h >> 0x20);
        piVar22 = (int64_t *)(uVar11 * 0x38 + *piVar1);
        uVar11 = func_0x00018015d7b0(piVar1, piVar22, var_60h._4_4_);
        if (uVar11 < (uint64_t)(piVar22[1] - *piVar22 >> 2)) {
            iVar8 = *(int16_t *)(*piVar22 + uVar11 * 4);
        } else {
            iVar8 = -3;
        }
        iVar17 = (int32_t)(uVar14 >> 0x20);
        if ((iVar19 == 0x7b) && (iVar8 == 0x7d)) {
            uVar11 = (uint64_t)iVar23;
            iVar13 = func_0x00018015d7b0(piVar1, piVar22);
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            if (iVar13 == *(int64_t *)(uVar11 * 0x38 + 8 + *piVar1) - *(int64_t *)(uVar11 * 0x38 + *piVar1) >> 2) {
                if (iVar23 < (int32_t)uVar21 + -1) {
                    var_18h = (uint64_t)(iVar23 + 1);
                }
            } else {
                uVar9 = func_0x000180150020(piVar1, var_18h & 0xffffffff, iVar13 + 1);
                var_18h = CONCAT44(uVar9, iVar23);
            }
            iVar13 = *piVar1;
            uVar21 = (*(int64_t *)(arg1 + 0x48) - iVar13 >> 3) * 0x6db6db6db6db6db7;
            uVar11 = (uint64_t)iVar20;
            if (uVar21 < uVar11 || uVar21 - uVar11 == 0) goto code_r0x0001801562fa;
            iVar12 = func_0x00018015d7b0(piVar1, uVar11 * 0x38 + iVar13, iVar17);
            if (iVar12 == 0) {
                if (0 < iVar20) {
                    uVar14 = (uint64_t)(iVar20 + -1);
                    if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                    uVar14 = CONCAT44(*(undefined4 *)(uVar14 * 0x38 + 0x28 + iVar13), iVar20 + -1);
                }
                *puVar18 = uVar14;
                puVar18[1] = var_18h;
            } else {
                uVar9 = func_0x000180150020(piVar1, uVar14 & 0xffffffff, iVar12 + -1);
                var_20h = CONCAT44(uVar9, iVar20);
                *puVar18 = var_20h;
                puVar18[1] = var_18h;
            }
code_r0x0001801562c0:
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
        } else {
            piVar4 = *(int16_t **)(arg1 + 0x120);
            piVar16 = piVar4;
            for (piVar15 = *(int16_t **)(arg1 + 0x118); piVar15 < piVar4; piVar15 = piVar15 + 0xe) {
                iVar2 = *(int32_t *)(piVar15 + 2);
                if (iVar2 == iVar20) {
                    bVar24 = iVar17 < *(int32_t *)(piVar15 + 4);
                } else {
                    bVar24 = iVar2 != iVar20 && iVar20 <= iVar2;
                }
                if (bVar24) break;
                bVar24 = SBORROW4(iVar2, iVar20);
                iVar5 = iVar2 - iVar20;
                if (iVar2 == iVar20) {
                    bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), iVar17);
                    iVar5 = *(int32_t *)(piVar15 + 4) - iVar17;
                }
                if (bVar24 != iVar5 < 0) {
                    iVar5 = *(int32_t *)(piVar15 + 8);
                    if (iVar5 == iVar20) {
                        bVar24 = iVar17 <= *(int32_t *)(piVar15 + 10);
                    } else {
                        bVar24 = iVar5 != iVar20 && iVar20 <= iVar5;
                    }
                    if (bVar24) {
                        bVar24 = SBORROW4(iVar2, iVar23);
                        iVar6 = iVar2 - iVar23;
                        if (iVar2 == iVar23) {
                            bVar24 = SBORROW4(*(int32_t *)(piVar15 + 4), var_60h._4_4_);
                            iVar6 = *(int32_t *)(piVar15 + 4) - var_60h._4_4_;
                        }
                        if (bVar24 != iVar6 < 0) {
                            if (iVar5 == iVar23) {
                                bVar24 = var_60h._4_4_ <= *(int32_t *)(piVar15 + 10);
                            } else {
                                bVar24 = iVar5 != iVar23 && iVar23 <= iVar5;
                            }
                            if ((bVar24) && (*piVar15 == 0x7b)) {
                                piVar16 = piVar15;
                            }
                        }
                    }
                }
            }
            if (piVar16 != piVar4) {
                var_68h = *(int64_t *)(piVar16 + 2);
                iVar20 = (int32_t)var_68h;
                uVar14 = (uint64_t)iVar20;
                if (uVar21 < uVar14 || uVar21 - uVar14 == 0) goto code_r0x0001801562fa;
                uVar11 = *(uint64_t *)(piVar16 + 8);
                var_58h._4_4_ = (undefined4)((uint64_t)var_68h >> 0x20);
                piVar22 = (int64_t *)(uVar14 * 0x38 + *piVar1);
                iVar13 = func_0x00018015d7b0(piVar1, piVar22, var_58h._4_4_);
                if (iVar13 == piVar22[1] - *piVar22 >> 2) {
                    if (iVar20 < (int32_t)uVar21 + -1) {
                        var_68h = (int64_t)(iVar20 + 1);
                    }
                } else {
                    uVar9 = func_0x000180150020(piVar1, var_68h & 0xffffffff, iVar13 + 1);
                    var_68h = CONCAT44(uVar9, iVar20);
                }
                *puVar18 = var_68h;
                puVar18[1] = uVar11;
                goto code_r0x0001801562c0;
            }
        }
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_180156300
// Address: 0x180156300
// Size: 59 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180156300(int64_t arg1, int64_t arg2, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int32_t iVar5;
    code *pcVar6;
    int16_t iVar7;
    undefined4 uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    uint64_t *puVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, arg1 + 0x40);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar4 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar4) {
            return;
        }
        iVar15 = *(int32_t *)(puVar18 + 1);
        iVar14 = *(int32_t *)puVar18;
        bVar19 = SBORROW4(iVar14, iVar15);
        iVar5 = iVar14 - iVar15;
        if (iVar14 == iVar15) {
            iVar2 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar3 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar5 = iVar3 - iVar2;
            if (iVar3 != iVar2) goto code_r0x000180156378;
        } else {
code_r0x000180156378:
            puVar9 = puVar18 + 1;
            if (bVar19 != iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar13 = *puVar9;
            bVar20 = SBORROW4(iVar14, iVar15);
            iVar5 = iVar14 - iVar15;
            bVar19 = iVar14 == iVar15;
            if (bVar19) {
                iVar15 = *(int32_t *)((int64_t)puVar18 + 0xc);
                iVar14 = *(int32_t *)((int64_t)puVar18 + 4);
                bVar20 = SBORROW4(iVar14, iVar15);
                iVar5 = iVar14 - iVar15;
                bVar19 = iVar14 == iVar15;
            }
            piVar1 = (int64_t *)(arg1 + 0x40);
            iVar15 = (int32_t)uVar13;
            puVar9 = puVar18 + 1;
            if (!bVar19 && bVar20 == iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar16 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
            iStackX_20 = *puVar9;
            if (uVar16 < (uint64_t)(int64_t)iVar15 || uVar16 - (int64_t)iVar15 == 0) {
code_r0x000180156721:
                func_0x000180060370();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            uVar10 = func_0x00018015d7b0(piVar1, (int64_t)iVar15 * 0x38 + *(int64_t *)(arg1 + 0x40), uVar13 >> 0x20);
            iVar12 = *piVar1;
            iVar11 = *(int64_t *)((int64_t)iVar15 * 0x38 + iVar12);
            if (uVar10 < (uint64_t)(*(int64_t *)((int64_t)iVar15 * 0x38 + 8 + iVar12) - iVar11 >> 2)) {
                var_10h._0_2_ = *(int16_t *)(iVar11 + uVar10 * 4);
            } else {
                var_10h._0_2_ = -3;
            }
            iVar14 = (int32_t)iStackX_20;
            uVar10 = (uint64_t)iVar14;
            if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
            iVar11 = func_0x00018015d7b0(piVar1, uVar10 * 0x38 + iVar12, (uint64_t)iStackX_20 >> 0x20);
            if (iVar11 == 0) {
                var_18h = iStackX_20;
                if (0 < iVar14) {
                    uVar10 = (uint64_t)(iVar14 + -1);
                    if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
                    var_18h = CONCAT44(*(undefined4 *)(uVar10 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                }
            } else {
                uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                var_18h = CONCAT44(uVar8, iVar14);
            }
            iVar12 = *piVar1;
            uVar10 = (*(int64_t *)(arg1 + 0x48) - iVar12 >> 3) * 0x6db6db6db6db6db7;
            uVar16 = (uint64_t)(int32_t)var_18h;
            if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
            piVar17 = (int64_t *)(uVar16 * 0x38 + iVar12);
            uVar16 = func_0x00018015d7b0(piVar1, piVar17, (uint64_t)var_18h >> 0x20);
            if (uVar16 < (uint64_t)(piVar17[1] - *piVar17 >> 2)) {
                iVar7 = *(int16_t *)(*piVar17 + uVar16 * 4);
            } else {
                iVar7 = -3;
            }
            if (((int16_t)var_10h == 0x7b) && (iVar7 == 0x7d)) {
                uVar16 = (uint64_t)iVar14;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_68h._4_4_ = (undefined4)((uint64_t)iStackX_20 >> 0x20);
                iVar11 = func_0x00018015d7b0(piVar1, uVar16 * 0x38 + iVar12, var_68h._4_4_);
                if (iVar11 == 0) {
                    if (0 < iVar14) {
                        uVar16 = (uint64_t)(iVar14 + -1);
                        if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                        iStackX_20 = CONCAT44(*(undefined4 *)(uVar16 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                    iStackX_20 = CONCAT44(uVar8, iVar14);
                }
                uVar10 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
                uVar16 = (uint64_t)iVar15;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_60h._4_4_ = (undefined4)(uVar13 >> 0x20);
                piVar17 = (int64_t *)(uVar16 * 0x38 + *piVar1);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_60h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        uVar13 = (uint64_t)(iVar15 + 1);
                    }
                    *puVar18 = uVar13;
                } else {
                    uVar8 = func_0x000180150020(piVar1, uVar13 & 0xffffffff, iVar12 + 1);
                    var_78h = CONCAT44(uVar8, iVar15);
                    *puVar18 = var_78h;
                }
            } else {
                func_0x0001801600f0(arg1 + 0x118, &var_58h, uVar13, iStackX_20);
                iVar11 = var_58h;
                if (var_58h == *(int64_t *)(arg1 + 0x120)) goto code_r0x0001801566f0;
                var_70h = *(uint64_t *)(var_58h + 0x10);
                iVar15 = (int32_t)var_70h;
                uVar13 = (uint64_t)iVar15;
                if (uVar10 < uVar13 || uVar10 - uVar13 == 0) goto code_r0x000180156721;
                var_10h._4_4_ = (undefined4)((uint64_t)var_70h >> 0x20);
                piVar17 = (int64_t *)(uVar13 * 0x38 + iVar12);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_10h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        var_70h = (int64_t)(iVar15 + 1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, var_70h & 0xffffffff, iVar12 + 1);
                    var_70h = CONCAT44(uVar8, iVar15);
                }
                *puVar18 = *(uint64_t *)(iVar11 + 4);
                iStackX_20 = var_70h;
            }
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
            puVar18[1] = iStackX_20;
        }
code_r0x0001801566f0:
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_18015633b
// Address: 0x18015633b
// Size: 987 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180156300(int64_t arg1, int64_t arg2, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int32_t iVar5;
    code *pcVar6;
    int16_t iVar7;
    undefined4 uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    uint64_t *puVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, arg1 + 0x40);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar4 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar4) {
            return;
        }
        iVar15 = *(int32_t *)(puVar18 + 1);
        iVar14 = *(int32_t *)puVar18;
        bVar19 = SBORROW4(iVar14, iVar15);
        iVar5 = iVar14 - iVar15;
        if (iVar14 == iVar15) {
            iVar2 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar3 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar5 = iVar3 - iVar2;
            if (iVar3 != iVar2) goto code_r0x000180156378;
        } else {
code_r0x000180156378:
            puVar9 = puVar18 + 1;
            if (bVar19 != iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar13 = *puVar9;
            bVar20 = SBORROW4(iVar14, iVar15);
            iVar5 = iVar14 - iVar15;
            bVar19 = iVar14 == iVar15;
            if (bVar19) {
                iVar15 = *(int32_t *)((int64_t)puVar18 + 0xc);
                iVar14 = *(int32_t *)((int64_t)puVar18 + 4);
                bVar20 = SBORROW4(iVar14, iVar15);
                iVar5 = iVar14 - iVar15;
                bVar19 = iVar14 == iVar15;
            }
            piVar1 = (int64_t *)(arg1 + 0x40);
            iVar15 = (int32_t)uVar13;
            puVar9 = puVar18 + 1;
            if (!bVar19 && bVar20 == iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar16 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
            iStackX_20 = *puVar9;
            if (uVar16 < (uint64_t)(int64_t)iVar15 || uVar16 - (int64_t)iVar15 == 0) {
code_r0x000180156721:
                func_0x000180060370();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            uVar10 = func_0x00018015d7b0(piVar1, (int64_t)iVar15 * 0x38 + *(int64_t *)(arg1 + 0x40), uVar13 >> 0x20);
            iVar12 = *piVar1;
            iVar11 = *(int64_t *)((int64_t)iVar15 * 0x38 + iVar12);
            if (uVar10 < (uint64_t)(*(int64_t *)((int64_t)iVar15 * 0x38 + 8 + iVar12) - iVar11 >> 2)) {
                var_10h._0_2_ = *(int16_t *)(iVar11 + uVar10 * 4);
            } else {
                var_10h._0_2_ = -3;
            }
            iVar14 = (int32_t)iStackX_20;
            uVar10 = (uint64_t)iVar14;
            if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
            iVar11 = func_0x00018015d7b0(piVar1, uVar10 * 0x38 + iVar12, (uint64_t)iStackX_20 >> 0x20);
            if (iVar11 == 0) {
                var_18h = iStackX_20;
                if (0 < iVar14) {
                    uVar10 = (uint64_t)(iVar14 + -1);
                    if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
                    var_18h = CONCAT44(*(undefined4 *)(uVar10 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                }
            } else {
                uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                var_18h = CONCAT44(uVar8, iVar14);
            }
            iVar12 = *piVar1;
            uVar10 = (*(int64_t *)(arg1 + 0x48) - iVar12 >> 3) * 0x6db6db6db6db6db7;
            uVar16 = (uint64_t)(int32_t)var_18h;
            if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
            piVar17 = (int64_t *)(uVar16 * 0x38 + iVar12);
            uVar16 = func_0x00018015d7b0(piVar1, piVar17, (uint64_t)var_18h >> 0x20);
            if (uVar16 < (uint64_t)(piVar17[1] - *piVar17 >> 2)) {
                iVar7 = *(int16_t *)(*piVar17 + uVar16 * 4);
            } else {
                iVar7 = -3;
            }
            if (((int16_t)var_10h == 0x7b) && (iVar7 == 0x7d)) {
                uVar16 = (uint64_t)iVar14;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_68h._4_4_ = (undefined4)((uint64_t)iStackX_20 >> 0x20);
                iVar11 = func_0x00018015d7b0(piVar1, uVar16 * 0x38 + iVar12, var_68h._4_4_);
                if (iVar11 == 0) {
                    if (0 < iVar14) {
                        uVar16 = (uint64_t)(iVar14 + -1);
                        if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                        iStackX_20 = CONCAT44(*(undefined4 *)(uVar16 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                    iStackX_20 = CONCAT44(uVar8, iVar14);
                }
                uVar10 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
                uVar16 = (uint64_t)iVar15;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_60h._4_4_ = (undefined4)(uVar13 >> 0x20);
                piVar17 = (int64_t *)(uVar16 * 0x38 + *piVar1);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_60h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        uVar13 = (uint64_t)(iVar15 + 1);
                    }
                    *puVar18 = uVar13;
                } else {
                    uVar8 = func_0x000180150020(piVar1, uVar13 & 0xffffffff, iVar12 + 1);
                    var_78h = CONCAT44(uVar8, iVar15);
                    *puVar18 = var_78h;
                }
            } else {
                func_0x0001801600f0(arg1 + 0x118, &var_58h, uVar13, iStackX_20);
                iVar11 = var_58h;
                if (var_58h == *(int64_t *)(arg1 + 0x120)) goto code_r0x0001801566f0;
                var_70h = *(uint64_t *)(var_58h + 0x10);
                iVar15 = (int32_t)var_70h;
                uVar13 = (uint64_t)iVar15;
                if (uVar10 < uVar13 || uVar10 - uVar13 == 0) goto code_r0x000180156721;
                var_10h._4_4_ = (undefined4)((uint64_t)var_70h >> 0x20);
                piVar17 = (int64_t *)(uVar13 * 0x38 + iVar12);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_10h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        var_70h = (int64_t)(iVar15 + 1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, var_70h & 0xffffffff, iVar12 + 1);
                    var_70h = CONCAT44(uVar8, iVar15);
                }
                *puVar18 = *(uint64_t *)(iVar11 + 4);
                iStackX_20 = var_70h;
            }
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
            puVar18[1] = iStackX_20;
        }
code_r0x0001801566f0:
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_180156716
// Address: 0x180156716
// Size: 11 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180156300(int64_t arg1, int64_t arg2, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int32_t iVar5;
    code *pcVar6;
    int16_t iVar7;
    undefined4 uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    uint64_t *puVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, arg1 + 0x40);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar4 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar4) {
            return;
        }
        iVar15 = *(int32_t *)(puVar18 + 1);
        iVar14 = *(int32_t *)puVar18;
        bVar19 = SBORROW4(iVar14, iVar15);
        iVar5 = iVar14 - iVar15;
        if (iVar14 == iVar15) {
            iVar2 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar3 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar5 = iVar3 - iVar2;
            if (iVar3 != iVar2) goto code_r0x000180156378;
        } else {
code_r0x000180156378:
            puVar9 = puVar18 + 1;
            if (bVar19 != iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar13 = *puVar9;
            bVar20 = SBORROW4(iVar14, iVar15);
            iVar5 = iVar14 - iVar15;
            bVar19 = iVar14 == iVar15;
            if (bVar19) {
                iVar15 = *(int32_t *)((int64_t)puVar18 + 0xc);
                iVar14 = *(int32_t *)((int64_t)puVar18 + 4);
                bVar20 = SBORROW4(iVar14, iVar15);
                iVar5 = iVar14 - iVar15;
                bVar19 = iVar14 == iVar15;
            }
            piVar1 = (int64_t *)(arg1 + 0x40);
            iVar15 = (int32_t)uVar13;
            puVar9 = puVar18 + 1;
            if (!bVar19 && bVar20 == iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar16 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
            iStackX_20 = *puVar9;
            if (uVar16 < (uint64_t)(int64_t)iVar15 || uVar16 - (int64_t)iVar15 == 0) {
code_r0x000180156721:
                func_0x000180060370();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            uVar10 = func_0x00018015d7b0(piVar1, (int64_t)iVar15 * 0x38 + *(int64_t *)(arg1 + 0x40), uVar13 >> 0x20);
            iVar12 = *piVar1;
            iVar11 = *(int64_t *)((int64_t)iVar15 * 0x38 + iVar12);
            if (uVar10 < (uint64_t)(*(int64_t *)((int64_t)iVar15 * 0x38 + 8 + iVar12) - iVar11 >> 2)) {
                var_10h._0_2_ = *(int16_t *)(iVar11 + uVar10 * 4);
            } else {
                var_10h._0_2_ = -3;
            }
            iVar14 = (int32_t)iStackX_20;
            uVar10 = (uint64_t)iVar14;
            if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
            iVar11 = func_0x00018015d7b0(piVar1, uVar10 * 0x38 + iVar12, (uint64_t)iStackX_20 >> 0x20);
            if (iVar11 == 0) {
                var_18h = iStackX_20;
                if (0 < iVar14) {
                    uVar10 = (uint64_t)(iVar14 + -1);
                    if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
                    var_18h = CONCAT44(*(undefined4 *)(uVar10 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                }
            } else {
                uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                var_18h = CONCAT44(uVar8, iVar14);
            }
            iVar12 = *piVar1;
            uVar10 = (*(int64_t *)(arg1 + 0x48) - iVar12 >> 3) * 0x6db6db6db6db6db7;
            uVar16 = (uint64_t)(int32_t)var_18h;
            if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
            piVar17 = (int64_t *)(uVar16 * 0x38 + iVar12);
            uVar16 = func_0x00018015d7b0(piVar1, piVar17, (uint64_t)var_18h >> 0x20);
            if (uVar16 < (uint64_t)(piVar17[1] - *piVar17 >> 2)) {
                iVar7 = *(int16_t *)(*piVar17 + uVar16 * 4);
            } else {
                iVar7 = -3;
            }
            if (((int16_t)var_10h == 0x7b) && (iVar7 == 0x7d)) {
                uVar16 = (uint64_t)iVar14;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_68h._4_4_ = (undefined4)((uint64_t)iStackX_20 >> 0x20);
                iVar11 = func_0x00018015d7b0(piVar1, uVar16 * 0x38 + iVar12, var_68h._4_4_);
                if (iVar11 == 0) {
                    if (0 < iVar14) {
                        uVar16 = (uint64_t)(iVar14 + -1);
                        if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                        iStackX_20 = CONCAT44(*(undefined4 *)(uVar16 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                    iStackX_20 = CONCAT44(uVar8, iVar14);
                }
                uVar10 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
                uVar16 = (uint64_t)iVar15;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_60h._4_4_ = (undefined4)(uVar13 >> 0x20);
                piVar17 = (int64_t *)(uVar16 * 0x38 + *piVar1);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_60h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        uVar13 = (uint64_t)(iVar15 + 1);
                    }
                    *puVar18 = uVar13;
                } else {
                    uVar8 = func_0x000180150020(piVar1, uVar13 & 0xffffffff, iVar12 + 1);
                    var_78h = CONCAT44(uVar8, iVar15);
                    *puVar18 = var_78h;
                }
            } else {
                func_0x0001801600f0(arg1 + 0x118, &var_58h, uVar13, iStackX_20);
                iVar11 = var_58h;
                if (var_58h == *(int64_t *)(arg1 + 0x120)) goto code_r0x0001801566f0;
                var_70h = *(uint64_t *)(var_58h + 0x10);
                iVar15 = (int32_t)var_70h;
                uVar13 = (uint64_t)iVar15;
                if (uVar10 < uVar13 || uVar10 - uVar13 == 0) goto code_r0x000180156721;
                var_10h._4_4_ = (undefined4)((uint64_t)var_70h >> 0x20);
                piVar17 = (int64_t *)(uVar13 * 0x38 + iVar12);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_10h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        var_70h = (int64_t)(iVar15 + 1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, var_70h & 0xffffffff, iVar12 + 1);
                    var_70h = CONCAT44(uVar8, iVar15);
                }
                *puVar18 = *(uint64_t *)(iVar11 + 4);
                iStackX_20 = var_70h;
            }
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
            puVar18[1] = iStackX_20;
        }
code_r0x0001801566f0:
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_180156721
// Address: 0x180156721
// Size: 6 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: Variable defined which should be unmapped: var_28h
// WARNING: Variable defined which should be unmapped: var_30h
// WARNING: Variable defined which should be unmapped: var_38h
// WARNING: Variable defined which should be unmapped: var_40h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_5ch
// WARNING: [rz-ghidra] Detected overlap for variable var_74h

void fcn.180156300(int64_t arg1, int64_t arg2, int64_t arg_78h)
{
    int64_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t *puVar4;
    int32_t iVar5;
    code *pcVar6;
    int16_t iVar7;
    undefined4 uVar8;
    uint64_t *puVar9;
    uint64_t uVar10;
    int64_t iVar11;
    int64_t iVar12;
    uint64_t uVar13;
    int32_t iVar14;
    int32_t iVar15;
    uint64_t uVar16;
    int64_t *piVar17;
    uint64_t *puVar18;
    bool bVar19;
    bool bVar20;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t iStackX_20;
    int64_t var_24h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(char *)(arg1 + 0x26a) == '\0') {
        func_0x00018015f950(arg1 + 0x118, arg1 + 0x40);
    }
    puVar18 = *(uint64_t **)arg1;
    puVar4 = *(uint64_t **)(arg1 + 8);
    do {
        if (puVar18 == puVar4) {
            return;
        }
        iVar15 = *(int32_t *)(puVar18 + 1);
        iVar14 = *(int32_t *)puVar18;
        bVar19 = SBORROW4(iVar14, iVar15);
        iVar5 = iVar14 - iVar15;
        if (iVar14 == iVar15) {
            iVar2 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar3 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar19 = SBORROW4(iVar3, iVar2);
            iVar5 = iVar3 - iVar2;
            if (iVar3 != iVar2) goto code_r0x000180156378;
        } else {
code_r0x000180156378:
            puVar9 = puVar18 + 1;
            if (bVar19 != iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar13 = *puVar9;
            bVar20 = SBORROW4(iVar14, iVar15);
            iVar5 = iVar14 - iVar15;
            bVar19 = iVar14 == iVar15;
            if (bVar19) {
                iVar15 = *(int32_t *)((int64_t)puVar18 + 0xc);
                iVar14 = *(int32_t *)((int64_t)puVar18 + 4);
                bVar20 = SBORROW4(iVar14, iVar15);
                iVar5 = iVar14 - iVar15;
                bVar19 = iVar14 == iVar15;
            }
            piVar1 = (int64_t *)(arg1 + 0x40);
            iVar15 = (int32_t)uVar13;
            puVar9 = puVar18 + 1;
            if (!bVar19 && bVar20 == iVar5 < 0) {
                puVar9 = puVar18;
            }
            uVar16 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
            iStackX_20 = *puVar9;
            if (uVar16 < (uint64_t)(int64_t)iVar15 || uVar16 - (int64_t)iVar15 == 0) {
code_r0x000180156721:
                func_0x000180060370();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            uVar10 = func_0x00018015d7b0(piVar1, (int64_t)iVar15 * 0x38 + *(int64_t *)(arg1 + 0x40), uVar13 >> 0x20);
            iVar12 = *piVar1;
            iVar11 = *(int64_t *)((int64_t)iVar15 * 0x38 + iVar12);
            if (uVar10 < (uint64_t)(*(int64_t *)((int64_t)iVar15 * 0x38 + 8 + iVar12) - iVar11 >> 2)) {
                var_10h._0_2_ = *(int16_t *)(iVar11 + uVar10 * 4);
            } else {
                var_10h._0_2_ = -3;
            }
            iVar14 = (int32_t)iStackX_20;
            uVar10 = (uint64_t)iVar14;
            if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
            iVar11 = func_0x00018015d7b0(piVar1, uVar10 * 0x38 + iVar12, (uint64_t)iStackX_20 >> 0x20);
            if (iVar11 == 0) {
                var_18h = iStackX_20;
                if (0 < iVar14) {
                    uVar10 = (uint64_t)(iVar14 + -1);
                    if (uVar16 < uVar10 || uVar16 - uVar10 == 0) goto code_r0x000180156721;
                    var_18h = CONCAT44(*(undefined4 *)(uVar10 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                }
            } else {
                uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                var_18h = CONCAT44(uVar8, iVar14);
            }
            iVar12 = *piVar1;
            uVar10 = (*(int64_t *)(arg1 + 0x48) - iVar12 >> 3) * 0x6db6db6db6db6db7;
            uVar16 = (uint64_t)(int32_t)var_18h;
            if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
            piVar17 = (int64_t *)(uVar16 * 0x38 + iVar12);
            uVar16 = func_0x00018015d7b0(piVar1, piVar17, (uint64_t)var_18h >> 0x20);
            if (uVar16 < (uint64_t)(piVar17[1] - *piVar17 >> 2)) {
                iVar7 = *(int16_t *)(*piVar17 + uVar16 * 4);
            } else {
                iVar7 = -3;
            }
            if (((int16_t)var_10h == 0x7b) && (iVar7 == 0x7d)) {
                uVar16 = (uint64_t)iVar14;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_68h._4_4_ = (undefined4)((uint64_t)iStackX_20 >> 0x20);
                iVar11 = func_0x00018015d7b0(piVar1, uVar16 * 0x38 + iVar12, var_68h._4_4_);
                if (iVar11 == 0) {
                    if (0 < iVar14) {
                        uVar16 = (uint64_t)(iVar14 + -1);
                        if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                        iStackX_20 = CONCAT44(*(undefined4 *)(uVar16 * 0x38 + 0x28 + iVar12), iVar14 + -1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, iStackX_20 & 0xffffffff, iVar11 + -1);
                    iStackX_20 = CONCAT44(uVar8, iVar14);
                }
                uVar10 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
                uVar16 = (uint64_t)iVar15;
                if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156721;
                var_60h._4_4_ = (undefined4)(uVar13 >> 0x20);
                piVar17 = (int64_t *)(uVar16 * 0x38 + *piVar1);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_60h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        uVar13 = (uint64_t)(iVar15 + 1);
                    }
                    *puVar18 = uVar13;
                } else {
                    uVar8 = func_0x000180150020(piVar1, uVar13 & 0xffffffff, iVar12 + 1);
                    var_78h = CONCAT44(uVar8, iVar15);
                    *puVar18 = var_78h;
                }
            } else {
                func_0x0001801600f0(arg1 + 0x118, &var_58h, uVar13, iStackX_20);
                iVar11 = var_58h;
                if (var_58h == *(int64_t *)(arg1 + 0x120)) goto code_r0x0001801566f0;
                var_70h = *(uint64_t *)(var_58h + 0x10);
                iVar15 = (int32_t)var_70h;
                uVar13 = (uint64_t)iVar15;
                if (uVar10 < uVar13 || uVar10 - uVar13 == 0) goto code_r0x000180156721;
                var_10h._4_4_ = (undefined4)((uint64_t)var_70h >> 0x20);
                piVar17 = (int64_t *)(uVar13 * 0x38 + iVar12);
                iVar12 = func_0x00018015d7b0(piVar1, piVar17, var_10h._4_4_);
                if (iVar12 == piVar17[1] - *piVar17 >> 2) {
                    if (iVar15 < (int32_t)uVar10 + -1) {
                        var_70h = (int64_t)(iVar15 + 1);
                    }
                } else {
                    uVar8 = func_0x000180150020(piVar1, var_70h & 0xffffffff, iVar12 + 1);
                    var_70h = CONCAT44(uVar8, iVar15);
                }
                *puVar18 = *(uint64_t *)(iVar11 + 4);
                iStackX_20 = var_70h;
            }
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
            puVar18[1] = iStackX_20;
        }
code_r0x0001801566f0:
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_180156730
// Address: 0x180156730
// Size: 449 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180156730(int64_t arg1, int64_t arg_30h, int64_t arg_40h, int64_t arg_50h, int64_t arg_60h)
{
    undefined (*pauVar1) [16];
    undefined8 *puVar2;
    int32_t *piVar3;
    undefined8 *puVar4;
    int32_t iVar5;
    int32_t iVar6;
    undefined8 uVar7;
    int32_t iVar8;
    code *pcVar9;
    undefined (*pauVar10) [16];
    undefined8 *puVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    undefined (*pauStack_20) [16];
    
    func_0x000180156900();
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar10 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar10 = ZEXT816(0);
    *(undefined4 *)(*pauVar10 + 8) = 1;
    *(undefined4 *)(*pauVar10 + 0xc) = 1;
    *(undefined8 *)*pauVar10 = 0x180645d88;
    pauVar1 = pauVar10 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar10[2] = ZEXT816(0);
    pauVar10[3] = ZEXT816(0);
    pauVar10[4] = ZEXT816(0);
    pauVar10[5] = ZEXT816(0);
    pauVar10[6] = ZEXT816(0);
    *(undefined8 *)pauVar10[7] = 0;
    func_0x0001801655b0(pauVar1);
    var_28h = (int64_t)pauVar1;
    pauStack_20 = pauVar10;
    func_0x000180150230(pauVar10[2] + 8, arg1);
    LOCK();
    *(int32_t *)(*pauVar10 + 8) = *(int32_t *)(*pauVar10 + 8) + 1;
    UNLOCK();
    var_30h = (int64_t)pauVar10;
    var_38h = (int64_t)pauVar1;
    func_0x00018015bab0(arg1, &var_38h);
    uVar13 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    uVar12 = *(uint64_t *)(arg1 + 0x20);
    if (uVar13 < uVar12 || uVar13 - uVar12 == 0) {
        uVar12 = *(uint64_t *)(arg1 + 0x18);
        if (uVar13 <= *(uint64_t *)(arg1 + 0x18)) {
            uVar12 = 0;
        }
        *(uint64_t *)(arg1 + 0x20) = uVar12;
        if (uVar13 < uVar12 || uVar13 - uVar12 == 0) {
            func_0x000180060370();
            pcVar9 = (code *)swi(3);
            (*pcVar9)();
            return;
        }
    }
    puVar4 = (undefined8 *)(*(int64_t *)arg1 + uVar12 * 0x14);
    puVar2 = puVar4 + 1;
    iVar5 = *(int32_t *)puVar4;
    iVar6 = *(int32_t *)puVar2;
    bVar14 = SBORROW4(iVar5, iVar6);
    iVar8 = iVar5 - iVar6;
    if (iVar5 == iVar6) {
        bVar14 = SBORROW4(*(int32_t *)((int64_t)puVar4 + 4), *(int32_t *)((int64_t)puVar4 + 0xc));
        iVar8 = *(int32_t *)((int64_t)puVar4 + 4) - *(int32_t *)((int64_t)puVar4 + 0xc);
    }
    puVar11 = puVar4;
    if (bVar14 == iVar8 < 0) {
        puVar11 = puVar2;
    }
    uVar7 = *puVar11;
    bVar14 = SBORROW4(iVar5, iVar6);
    iVar8 = iVar5 - iVar6;
    if (iVar5 == iVar6) {
        bVar14 = SBORROW4(*(int32_t *)((int64_t)puVar4 + 4), *(int32_t *)((int64_t)puVar4 + 0xc));
        iVar8 = *(int32_t *)((int64_t)puVar4 + 4) - *(int32_t *)((int64_t)puVar4 + 0xc);
    }
    puVar11 = puVar4;
    if (bVar14 == iVar8 < 0) {
        puVar11 = puVar2;
    }
    *puVar4 = *puVar11;
    *puVar2 = uVar7;
    *(undefined *)((int64_t)puVar4 + 0x12) = 1;
    LOCK();
    *(int32_t *)(*pauVar10 + 8) = *(int32_t *)(*pauVar10 + 8) + 1;
    UNLOCK();
    func_0x00018015af60(arg1, &var_38h);
    LOCK();
    piVar3 = (int32_t *)(*pauVar10 + 8);
    iVar5 = *piVar3;
    *piVar3 = *piVar3 + -1;
    UNLOCK();
    if (iVar5 == 1) {
        (***(code ***)*pauVar10)(pauVar10);
        LOCK();
        piVar3 = (int32_t *)(*pauVar10 + 0xc);
        iVar5 = *piVar3;
        *piVar3 = *piVar3 + -1;
        UNLOCK();
        if (iVar5 == 1) {
            (**(code **)(*(int64_t *)*pauVar10 + 8))(pauVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180156900
// Address: 0x180156900
// Size: 1555 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_fch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h

void fcn.180156900(int64_t arg1)
{
    uint32_t uVar1;
    uint32_t uVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    undefined8 *puVar5;
    code *pcVar6;
    int32_t iVar7;
    undefined auVar8 [16];
    undefined8 *puVar9;
    uint64_t uVar10;
    int64_t **ppiVar11;
    int64_t iVar12;
    char cVar13;
    int64_t *piVar14;
    int64_t iVar15;
    uint64_t uVar16;
    undefined8 *puVar17;
    undefined *puVar18;
    undefined *puVar19;
    undefined8 *puVar20;
    int64_t *piVar21;
    int64_t *piVar22;
    int64_t *piVar23;
    int64_t *piVar24;
    bool bVar25;
    bool bVar26;
    undefined8 uStack_140;
    undefined auStack_138 [8];
    undefined auStack_130 [24];
    int64_t var_118h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t *piStack_b0;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar18 = auStack_138;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_138;
    var_c8h = 0;
    var_c0h = 0xf;
    stack0xffffffffffffff29 = SUB1615(ZEXT816(0), 1);
    auVar8[15] = 0;
    auVar8._0_15_ = stack0xffffffffffffff29;
    _var_d8h = auVar8 << 8;
    puVar5 = *(undefined8 **)(arg1 + 8);
    puVar17 = *(undefined8 **)arg1;
    for (puVar9 = puVar17; var_f8h = arg1, puVar9 != puVar5; puVar9 = (undefined8 *)((int64_t)puVar9 + 0x14)) {
        cVar13 = -1;
        if (puVar5 <= puVar9) {
            cVar13 = '\x01';
        }
        if (-1 < cVar13) break;
        if ((*(uint32_t *)puVar9 != *(uint32_t *)(puVar9 + 1)) ||
           (*(uint32_t *)((int64_t)puVar9 + 4) != *(uint32_t *)((int64_t)puVar9 + 0xc))) {
            puVar19 = auStack_138;
            if (puVar17 == puVar5) goto code_r0x000180156e80;
            var_100h = arg1 + 0x40;
            goto code_r0x0001801569c0;
        }
    }
    puVar19 = auStack_138;
    if (puVar17 != puVar5) {
        var_e8h = arg1 + 0x40;
code_r0x000180156caa:
        uVar2 = *(uint32_t *)puVar17;
        uVar1 = *(uint32_t *)(puVar17 + 1);
        bVar25 = SBORROW4(uVar2, uVar1);
        iVar7 = uVar2 - uVar1;
        if (uVar2 == uVar1) {
            bVar25 = SBORROW4(*(uint32_t *)((int64_t)puVar17 + 4), *(uint32_t *)((int64_t)puVar17 + 0xc));
            iVar7 = *(uint32_t *)((int64_t)puVar17 + 4) - *(uint32_t *)((int64_t)puVar17 + 0xc);
        }
        puVar9 = puVar17 + 1;
        if (bVar25 != iVar7 < 0) {
            puVar9 = puVar17;
        }
        uVar1 = *(uint32_t *)puVar9;
        uVar16 = (uint64_t)(int32_t)uVar1;
        uVar10 = (*(int64_t *)(var_e8h + 8) - *(int64_t *)var_e8h >> 3) * 0x6db6db6db6db6db7;
        if (uVar10 < uVar16 || uVar10 - uVar16 == 0) {
            func_0x000180060370();
code_r0x000180156f0d:
            func_0x000180060370();
            pcVar6 = (code *)swi(3);
            (*pcVar6)();
            return;
        }
        var_f8h = CONCAT44(*(undefined4 *)(uVar16 * 0x38 + 0x28 + *(int64_t *)var_e8h), uVar1);
        var_100h = (int64_t)uVar1;
        func_0x00018015d450(var_e8h, &var_78h, var_100h, var_f8h);
        ppiVar11 = (int64_t **)func_0x00018000d970(&var_78h, 0x1805ab2a0, 1);
        piVar24 = *ppiVar11;
        piStack_b0 = ppiVar11[1];
        piVar14 = ppiVar11[2];
        piVar22 = ppiVar11[3];
        ppiVar11[2] = (int64_t *)0x0;
        ppiVar11[3] = (int64_t *)0xf;
        *(undefined *)ppiVar11 = 0;
        piVar21 = &var_b8h;
        if ((int64_t *)0xf < piVar22) {
            piVar21 = piVar24;
        }
        var_f0h = var_c8h;
        var_b8h = (int64_t)piVar24;
        var_a8h = (int64_t)piVar14;
        var_a0h = (int64_t)piVar22;
        if ((int64_t *)(var_c0h - var_c8h) < piVar14) {
            var_118h = (int64_t)piVar14;
            func_0x00018000ee80(&var_d8h, piVar14, (undefined)var_108h);
            piVar22 = (int64_t *)var_a0h;
            piVar24 = (int64_t *)var_b8h;
        } else {
            piVar23 = &var_d8h;
            if (0xf < (uint64_t)var_c0h) {
                piVar23 = (int64_t *)var_d8h;
            }
            iVar12 = var_c8h + (int64_t)piVar23;
            var_c8h = (int64_t)piVar14 + var_c8h;
            fcn.180498030(iVar12, piVar21, piVar14);
            *(undefined *)((int64_t)piVar23 + (int64_t)piVar14 + var_f0h) = 0;
        }
        if ((int64_t *)0xf < piVar22) {
            piVar14 = (int64_t *)((int64_t)piVar22 + 1);
            piVar21 = piVar24;
            if ((int64_t *)0xfff < piVar14) {
                piVar21 = (int64_t *)piVar24[-1];
                if (0x1f < (uint64_t)((int64_t)piVar24 + (-8 - (int64_t)piVar21))) {
                    pcVar6 = (code *)swi(0x29);
                    (*pcVar6)(5);
                    puVar18 = auStack_130;
code_r0x000180156e75:
                    pcVar6 = (code *)swi(0x29);
                    (*pcVar6)(5);
                    puVar19 = puVar18 + 8;
                    goto code_r0x000180156e80;
                }
                piVar14 = piVar22 + 5;
            }
            func_0x000180459c3c(piVar21, piVar14);
        }
        if (0xf < (uint64_t)var_60h) {
            uVar10 = var_60h + 1;
            iVar15 = CONCAT71(var_78h._1_7_, (undefined)var_78h);
            iVar12 = iVar15;
            if (0xfff < uVar10) {
                iVar12 = *(int64_t *)(iVar15 + -8);
                if (0x1f < (iVar15 - iVar12) - 8U) goto code_r0x000180156e75;
                uVar10 = var_60h + 0x28;
            }
            func_0x000180459c3c(iVar12, uVar10);
        }
        var_68h = 0;
        var_60h = 0xf;
        var_78h._0_1_ = 0;
        puVar17 = (undefined8 *)((int64_t)puVar17 + 0x14);
        puVar19 = auStack_138;
        if (puVar17 == puVar5) goto code_r0x000180156e80;
        goto code_r0x000180156caa;
    }
    goto code_r0x000180156e80;
code_r0x0001801569c0:
    do {
        iVar12 = var_c8h;
        if (var_c8h != 0) {
            if (var_c0h == var_c8h) {
                var_118h = 1;
                func_0x00018000ee80(&var_d8h, 1, (undefined)var_108h, 0x1805ab2a0);
            } else {
                piVar14 = &var_d8h;
                if (0xf < (uint64_t)var_c0h) {
                    piVar14 = (int64_t *)var_d8h;
                }
                puVar18 = (undefined *)((int64_t)piVar14 + var_c8h);
                var_c8h = var_c8h + 1;
                *puVar18 = 10;
                *(undefined *)((int64_t)piVar14 + iVar12 + 1) = 0;
            }
        }
        puVar9 = puVar17 + 1;
        uVar1 = *(uint32_t *)puVar17;
        uVar2 = *(uint32_t *)puVar9;
        if ((uVar1 == uVar2) && (*(uint32_t *)((int64_t)puVar17 + 4) == *(uint32_t *)((int64_t)puVar17 + 0xc))) {
            uVar16 = (uint64_t)(int32_t)uVar2;
            uVar10 = (*(int64_t *)(var_100h + 8) - *(int64_t *)var_100h >> 3) * 0x6db6db6db6db6db7;
            if (uVar10 < uVar16 || uVar10 - uVar16 == 0) goto code_r0x000180156f0d;
            var_e0h._4_4_ = *(undefined4 *)(uVar16 * 0x38 + 0x28 + *(int64_t *)var_100h);
            var_e8h = (int64_t)uVar2;
            var_e0h._0_4_ = uVar2;
            func_0x00018015d450(var_100h, &var_98h, var_e8h, CONCAT44(var_e0h._4_4_, uVar2));
            iVar12 = var_88h;
            piVar14 = &var_98h;
            if (0xf < (uint64_t)var_80h) {
                piVar14 = (int64_t *)CONCAT71(var_98h._1_7_, (undefined)var_98h);
            }
            var_f0h = var_c8h;
            if ((uint64_t)(var_c0h - var_c8h) < (uint64_t)var_88h) {
                var_118h = var_88h;
                func_0x00018000ee80(&var_d8h, var_88h, (undefined)var_108h);
            } else {
                piVar22 = &var_d8h;
                if (0xf < (uint64_t)var_c0h) {
                    piVar22 = (int64_t *)var_d8h;
                }
                iVar15 = var_c8h + (int64_t)piVar22;
                var_c8h = var_c8h + var_88h;
                fcn.180498030(iVar15, piVar14, var_88h);
                *(undefined *)((int64_t)piVar22 + var_f0h + iVar12) = 0;
            }
            if (0xf < (uint64_t)var_80h) {
                uVar10 = var_80h + 1;
                iVar15 = CONCAT71(var_98h._1_7_, (undefined)var_98h);
                iVar12 = iVar15;
                if (0xfff < uVar10) {
                    iVar12 = *(int64_t *)(iVar15 + -8);
                    puVar18 = auStack_138;
                    if (0x1f < (iVar15 - iVar12) - 8U) goto code_r0x000180156e75;
                    uVar10 = var_80h + 0x28;
                }
                func_0x000180459c3c(iVar12, uVar10);
            }
            var_88h = 0;
            var_80h = 0xf;
            var_98h._0_1_ = 0;
        } else {
            bVar26 = SBORROW4(uVar1, uVar2);
            iVar7 = uVar1 - uVar2;
            bVar25 = uVar1 == uVar2;
            if (bVar25) {
                uVar3 = *(uint32_t *)((int64_t)puVar17 + 0xc);
                uVar4 = *(uint32_t *)((int64_t)puVar17 + 4);
                bVar26 = SBORROW4(uVar4, uVar3);
                iVar7 = uVar4 - uVar3;
                bVar25 = uVar4 == uVar3;
            }
            puVar20 = puVar9;
            if (!bVar25 && bVar26 == iVar7 < 0) {
                puVar20 = puVar17;
            }
            bVar25 = SBORROW4(uVar1, uVar2);
            iVar7 = uVar1 - uVar2;
            if (uVar1 == uVar2) {
                bVar25 = SBORROW4(*(uint32_t *)((int64_t)puVar17 + 4), *(uint32_t *)((int64_t)puVar17 + 0xc));
                iVar7 = *(uint32_t *)((int64_t)puVar17 + 4) - *(uint32_t *)((int64_t)puVar17 + 0xc);
            }
            if (bVar25 != iVar7 < 0) {
                puVar9 = puVar17;
            }
            puVar9 = (undefined8 *)func_0x00018015d450(var_f8h + 0x40, &var_b8h, *puVar9, *puVar20);
            uVar10 = puVar9[2];
            if (0xf < (uint64_t)puVar9[3]) {
                puVar9 = (undefined8 *)*puVar9;
            }
            var_f0h = var_c8h;
            if ((uint64_t)(var_c0h - var_c8h) < uVar10) {
                var_118h = uVar10;
                func_0x00018000ee80(&var_d8h, uVar10, (undefined)var_108h);
            } else {
                piVar14 = &var_d8h;
                if (0xf < (uint64_t)var_c0h) {
                    piVar14 = (int64_t *)var_d8h;
                }
                iVar12 = var_c8h + (int64_t)piVar14;
                var_c8h = var_c8h + uVar10;
                fcn.180498030(iVar12, puVar9, uVar10);
                *(undefined *)((int64_t)piVar14 + var_f0h + uVar10) = 0;
            }
            if (0xf < (uint64_t)var_a0h) {
                uVar10 = var_a0h + 1;
                iVar12 = var_b8h;
                if (0xfff < uVar10) {
                    iVar12 = *(int64_t *)(var_b8h + -8);
                    puVar18 = auStack_138;
                    if (0x1f < (var_b8h - iVar12) - 8U) goto code_r0x000180156e75;
                    uVar10 = var_a0h + 0x28;
                }
                func_0x000180459c3c(iVar12, uVar10);
            }
            var_a8h = 0;
            var_a0h = 0xf;
            var_b8h = var_b8h & 0xffffffffffffff00;
        }
        puVar17 = (undefined8 *)((int64_t)puVar17 + 0x14);
        puVar19 = auStack_138;
    } while (puVar17 != puVar5);
code_r0x000180156e80:
    piVar14 = &var_d8h;
    if (0xf < (uint64_t)var_c0h) {
        piVar14 = (int64_t *)var_d8h;
    }
    pcVar6 = *(code **)(*(int64_t *)0x180781f28 + 0xc50);
    if (pcVar6 != (code *)0x0) {
        *(undefined8 *)(puVar19 + -8) = 0x180156ea6;
        (*pcVar6)(*(int64_t *)0x180781f28, piVar14);
    }
    if (0xf < (uint64_t)var_c0h) {
        iVar12 = var_d8h;
        if ((0xfff < var_c0h + 1U) && (iVar12 = *(int64_t *)(var_d8h + -8), 0x1f < (var_d8h - iVar12) - 8U)) {
            pcVar6 = (code *)swi(0x29);
            iVar12 = (*pcVar6)(5);
            puVar19 = puVar19 + 8;
        }
        *(undefined8 *)(puVar19 + -8) = 0x180156ee7;
        func_0x000180459c3c(iVar12);
    }
    *(undefined8 *)(puVar19 + -8) = 0x180156ef3;
    func_0x000180459870(var_58h ^ (uint64_t)puVar19);
    return;
}

// ============================================================
// Function: FUN_180156f20
// Address: 0x180156f20
// Size: 352 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.180156f20(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int32_t iVar3;
    undefined (*pauVar4) [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    if (*(code **)(*(int64_t *)0x180781f28 + 0xc48) != (code *)0x0) {
        var_38h = (**(code **)(*(int64_t *)0x180781f28 + 0xc48))();
        if (var_38h != 0) {
            if (*(char *)(arg1 + 0x131) != '\0') {
                *(undefined *)(arg1 + 0x133) = 1;
            }
            pauVar4 = (undefined (*) [16])func_0x000180459890(0x78);
            *pauVar4 = ZEXT816(0);
            *(undefined4 *)(*pauVar4 + 8) = 1;
            *(undefined4 *)(*pauVar4 + 0xc) = 1;
            *(undefined8 *)*pauVar4 = 0x180645d88;
            pauVar1 = pauVar4 + 1;
            *pauVar1 = ZEXT816(0);
            pauVar4[2] = ZEXT816(0);
            pauVar4[3] = ZEXT816(0);
            pauVar4[4] = ZEXT816(0);
            pauVar4[5] = ZEXT816(0);
            pauVar4[6] = ZEXT816(0);
            *(undefined8 *)pauVar4[7] = 0;
            func_0x0001801655b0(pauVar1);
            var_28h = (int64_t)pauVar1;
            var_20h = (int64_t)pauVar4;
            func_0x000180150230(pauVar4[2] + 8, arg1);
            var_30h = func_0x000180498cd0(var_38h);
            LOCK();
            *(int32_t *)(*pauVar4 + 8) = *(int32_t *)(*pauVar4 + 8) + 1;
            UNLOCK();
            var_40h = (int64_t)pauVar4;
            var_48h = (int64_t)pauVar1;
            func_0x00018015b890(arg1, &var_48h, &var_38h);
            LOCK();
            *(int32_t *)(*pauVar4 + 8) = *(int32_t *)(*pauVar4 + 8) + 1;
            UNLOCK();
            func_0x00018015af60(arg1, &var_48h);
            LOCK();
            piVar2 = (int32_t *)(*pauVar4 + 8);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (***(code ***)*pauVar4)(pauVar4);
                LOCK();
                piVar2 = (int32_t *)(*pauVar4 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*(int64_t *)*pauVar4 + 8))(pauVar4);
                }
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_180157080
// Address: 0x180157080
// Size: 310 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h

void fcn.180157080(int64_t arg1)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int64_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    char **ppcVar7;
    int64_t *piVar8;
    char *pcVar9;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_38h;
    int64_t var_30h;
    int64_t var_28h;
    int64_t var_20h;
    
    iVar4 = *(int64_t *)(arg1 + 0xe8);
    uVar5 = *(uint64_t *)(arg1 + 0x100);
    if (uVar5 < (uint64_t)(*(int64_t *)(arg1 + 0xf0) - iVar4 >> 4)) {
        *(uint64_t *)(arg1 + 0x100) = uVar5 + 1;
        iVar6 = *(int64_t *)(iVar4 + 8 + uVar5 * 0x10);
        if (iVar6 != 0) {
            LOCK();
            piVar1 = (int32_t *)(iVar6 + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        ppcVar7 = *(char ***)(iVar4 + uVar5 * 0x10);
        piVar8 = *(int64_t **)(iVar4 + 8 + uVar5 * 0x10);
        pcVar9 = *ppcVar7;
        var_28h = (int64_t)ppcVar7;
        var_20h = (int64_t)piVar8;
        while (pcVar9 < ppcVar7[1]) {
            if (*pcVar9 == '\0') {
                var_38h = (int64_t)(pcVar9 + 0x18);
                if (0xf < *(uint64_t *)(pcVar9 + 0x30)) {
                    var_38h = *(int64_t *)var_38h;
                }
                var_30h = *(int64_t *)(pcVar9 + 0x28);
                func_0x00018015c7f0(arg1 + 0x40, &var_8h, *(undefined8 *)(pcVar9 + 4), &var_38h);
                pcVar9 = pcVar9 + 0x38;
            } else {
                func_0x00018015d110(arg1 + 0x40, *(undefined8 *)(pcVar9 + 4), *(undefined8 *)(pcVar9 + 0xc));
                pcVar9 = pcVar9 + 0x38;
            }
        }
        func_0x000180150230(arg1, ppcVar7 + 8);
        *(int64_t *)(arg1 + 0x108) = *(int64_t *)(arg1 + 0x108) + 1;
        if (piVar8 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar8 + 1;
            iVar3 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)*piVar8)(piVar8);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar8 + 0xc);
                iVar3 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*piVar8 + 8))(piVar8);
                }
            }
        }
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    }
    return;
}

// ============================================================
// Function: FUN_1801571c0
// Address: 0x1801571c0
// Size: 115 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.1801571c0(int64_t arg1)
{
    int64_t iVar1;
    int64_t iVar2;
    int64_t var_8h;
    int64_t var_10h;
    
    iVar2 = *(int64_t *)(arg1 + 0x48);
    for (iVar1 = *(int64_t *)(arg1 + 0x40); iVar1 != iVar2; iVar1 = iVar1 + 0x38) {
        *(undefined8 *)(iVar1 + 0x20) = 0;
    }
    iVar1 = *(int64_t *)(arg1 + 0x30);
    iVar2 = *(int64_t *)(arg1 + 0x28);
    if (iVar2 != iVar1) {
        do {
            func_0x000180004e40(iVar2 + 0x28);
            func_0x000180004e40(iVar2 + 8);
            iVar2 = iVar2 + 0x48;
        } while (iVar2 != iVar1);
        *(undefined8 *)(arg1 + 0x30) = *(undefined8 *)(arg1 + 0x28);
    }
    return;
}

// ============================================================
// Function: FUN_180157240
// Address: 0x180157240
// Size: 34 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180157240(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    char in_R8B;
    int64_t var_8h;
    int64_t var_20h;
    
    piVar2 = *(int64_t **)arg1;
    piVar1 = *(int64_t **)(arg1 + 8);
    if (piVar2 == piVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        return;
    }
    do {
        func_0x00018015e5d0(arg1 + 0x40, &var_20h, 
                            CONCAT44((int32_t)((uint64_t)piVar2[1] >> 0x20), (int32_t)piVar2[1] - (int32_t)arg2));
        if (in_R8B == '\0') {
            *piVar2 = var_20h;
        }
        piVar2[1] = var_20h;
        *(undefined *)((int64_t)piVar2 + 0x12) = 1;
        piVar2 = (int64_t *)((int64_t)piVar2 + 0x14);
    } while (piVar2 != piVar1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180157262
// Address: 0x180157262
// Size: 120 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180157240(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    char in_R8B;
    int64_t var_8h;
    int64_t var_20h;
    
    piVar2 = *(int64_t **)arg1;
    piVar1 = *(int64_t **)(arg1 + 8);
    if (piVar2 == piVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        return;
    }
    do {
        func_0x00018015e5d0(arg1 + 0x40, &var_20h, 
                            CONCAT44((int32_t)((uint64_t)piVar2[1] >> 0x20), (int32_t)piVar2[1] - (int32_t)arg2));
        if (in_R8B == '\0') {
            *piVar2 = var_20h;
        }
        piVar2[1] = var_20h;
        *(undefined *)((int64_t)piVar2 + 0x12) = 1;
        piVar2 = (int64_t *)((int64_t)piVar2 + 0x14);
    } while (piVar2 != piVar1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_1801572da
// Address: 0x1801572da
// Size: 29 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180157240(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    char in_R8B;
    int64_t var_8h;
    int64_t var_20h;
    
    piVar2 = *(int64_t **)arg1;
    piVar1 = *(int64_t **)(arg1 + 8);
    if (piVar2 == piVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        return;
    }
    do {
        func_0x00018015e5d0(arg1 + 0x40, &var_20h, 
                            CONCAT44((int32_t)((uint64_t)piVar2[1] >> 0x20), (int32_t)piVar2[1] - (int32_t)arg2));
        if (in_R8B == '\0') {
            *piVar2 = var_20h;
        }
        piVar2[1] = var_20h;
        *(undefined *)((int64_t)piVar2 + 0x12) = 1;
        piVar2 = (int64_t *)((int64_t)piVar2 + 0x14);
    } while (piVar2 != piVar1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180157300
// Address: 0x180157300
// Size: 34 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180157300(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    char in_R8B;
    int64_t var_ch;
    int64_t var_20h;
    
    piVar2 = *(int64_t **)arg1;
    piVar1 = *(int64_t **)(arg1 + 8);
    if (piVar2 == piVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        return;
    }
    do {
        func_0x00018015e5d0(arg1 + 0x40, &var_20h, 
                            CONCAT44((int32_t)((uint64_t)piVar2[1] >> 0x20), (int32_t)piVar2[1] + (int32_t)arg2));
        if (in_R8B == '\0') {
            *piVar2 = var_20h;
        }
        piVar2[1] = var_20h;
        *(undefined *)((int64_t)piVar2 + 0x12) = 1;
        piVar2 = (int64_t *)((int64_t)piVar2 + 0x14);
    } while (piVar2 != piVar1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180157322
// Address: 0x180157322
// Size: 118 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180157300(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    char in_R8B;
    int64_t var_ch;
    int64_t var_20h;
    
    piVar2 = *(int64_t **)arg1;
    piVar1 = *(int64_t **)(arg1 + 8);
    if (piVar2 == piVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        return;
    }
    do {
        func_0x00018015e5d0(arg1 + 0x40, &var_20h, 
                            CONCAT44((int32_t)((uint64_t)piVar2[1] >> 0x20), (int32_t)piVar2[1] + (int32_t)arg2));
        if (in_R8B == '\0') {
            *piVar2 = var_20h;
        }
        piVar2[1] = var_20h;
        *(undefined *)((int64_t)piVar2 + 0x12) = 1;
        piVar2 = (int64_t *)((int64_t)piVar2 + 0x14);
    } while (piVar2 != piVar1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180157398
// Address: 0x180157398
// Size: 29 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_ch
// WARNING: [rz-ghidra] Detected overlap for variable var_8h
// WARNING: [rz-ghidra] Detected overlap for variable var_10h

void fcn.180157300(int64_t arg1, int64_t arg2, int64_t arg_60h)
{
    int64_t *piVar1;
    int64_t *piVar2;
    char in_R8B;
    int64_t var_ch;
    int64_t var_20h;
    
    piVar2 = *(int64_t **)arg1;
    piVar1 = *(int64_t **)(arg1 + 8);
    if (piVar2 == piVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        return;
    }
    do {
        func_0x00018015e5d0(arg1 + 0x40, &var_20h, 
                            CONCAT44((int32_t)((uint64_t)piVar2[1] >> 0x20), (int32_t)piVar2[1] + (int32_t)arg2));
        if (in_R8B == '\0') {
            *piVar2 = var_20h;
        }
        piVar2[1] = var_20h;
        *(undefined *)((int64_t)piVar2 + 0x12) = 1;
        piVar2 = (int64_t *)((int64_t)piVar2 + 0x14);
    } while (piVar2 != piVar1);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_1801573c0
// Address: 0x1801573c0
// Size: 42 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801573c0(int64_t arg1, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    char in_DL;
    undefined8 *puVar4;
    undefined in_R8B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    puVar4 = *(undefined8 **)arg1;
    puVar1 = *(undefined8 **)(arg1 + 8);
    if (puVar4 == puVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    } else {
        do {
            puVar3 = (undefined8 *)func_0x00018015d9c0(arg1 + 0x40, &var_8h, puVar4[1], in_R8B);
            uVar2 = *puVar3;
            if (in_DL == '\0') {
                *puVar4 = uVar2;
            }
            puVar4[1] = uVar2;
            *(undefined *)((int64_t)puVar4 + 0x12) = 1;
            puVar4 = (undefined8 *)((int64_t)puVar4 + 0x14);
        } while (puVar4 != puVar1);
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    }
    return;
}

// ============================================================
// Function: FUN_1801573ea
// Address: 0x1801573ea
// Size: 80 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801573c0(int64_t arg1, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    char in_DL;
    undefined8 *puVar4;
    undefined in_R8B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    puVar4 = *(undefined8 **)arg1;
    puVar1 = *(undefined8 **)(arg1 + 8);
    if (puVar4 == puVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    } else {
        do {
            puVar3 = (undefined8 *)func_0x00018015d9c0(arg1 + 0x40, &var_8h, puVar4[1], in_R8B);
            uVar2 = *puVar3;
            if (in_DL == '\0') {
                *puVar4 = uVar2;
            }
            puVar4[1] = uVar2;
            *(undefined *)((int64_t)puVar4 + 0x12) = 1;
            puVar4 = (undefined8 *)((int64_t)puVar4 + 0x14);
        } while (puVar4 != puVar1);
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    }
    return;
}

// ============================================================
// Function: FUN_18015743a
// Address: 0x18015743a
// Size: 37 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.1801573c0(int64_t arg1, int64_t arg_50h)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    char in_DL;
    undefined8 *puVar4;
    undefined in_R8B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    
    puVar4 = *(undefined8 **)arg1;
    puVar1 = *(undefined8 **)(arg1 + 8);
    if (puVar4 == puVar1) {
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    } else {
        do {
            puVar3 = (undefined8 *)func_0x00018015d9c0(arg1 + 0x40, &var_8h, puVar4[1], in_R8B);
            uVar2 = *puVar3;
            if (in_DL == '\0') {
                *puVar4 = uVar2;
            }
            puVar4[1] = uVar2;
            *(undefined *)((int64_t)puVar4 + 0x12) = 1;
            puVar4 = (undefined8 *)((int64_t)puVar4 + 0x14);
        } while (puVar4 != puVar1);
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    }
    return;
}

// ============================================================
// Function: FUN_180157460
// Address: 0x180157460
// Size: 191 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180157460(int64_t arg1)
{
    uint64_t uVar1;
    int64_t iVar2;
    code *pcVar3;
    uint64_t uVar4;
    char in_DL;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)arg1;
    while (uVar4 = uVar1, uVar4 < *(uint64_t *)(arg1 + 8)) {
        uVar1 = uVar4 + 0x14;
        if (*(char *)(uVar4 + 0x10) == '\0') {
            fcn.180498030(uVar4, uVar1, *(uint64_t *)(arg1 + 8) - uVar1);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
            uVar1 = uVar4;
        }
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    iVar2 = *(int64_t *)arg1;
    uVar1 = *(uint64_t *)(arg1 + 0x20);
    uVar4 = (*(int64_t *)(arg1 + 8) - iVar2 >> 2) * -0x3333333333333333;
    if (uVar4 < uVar1 || uVar4 - uVar1 == 0) {
        func_0x000180060370();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    if (in_DL == '\0') {
        *(undefined8 *)(iVar2 + uVar1 * 0x14) = 0;
    }
    *(undefined8 *)(iVar2 + 8 + uVar1 * 0x14) = 0;
    *(undefined *)(iVar2 + 0x12 + uVar1 * 0x14) = 1;
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180157520
// Address: 0x180157520
// Size: 254 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180157520(int64_t arg1)
{
    int64_t iVar1;
    uint64_t uVar2;
    code *pcVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    char in_DL;
    undefined8 uVar6;
    uint64_t uVar7;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar5 = *(uint64_t *)arg1;
    while (uVar7 = uVar5, uVar7 < *(uint64_t *)(arg1 + 8)) {
        uVar5 = uVar7 + 0x14;
        if (*(char *)(uVar7 + 0x10) == '\0') {
            fcn.180498030(uVar7, uVar5, *(uint64_t *)(arg1 + 8) - uVar5);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
            uVar5 = uVar7;
        }
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    uVar5 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
    uVar7 = (int64_t)(int32_t)uVar5 - 1;
    if (uVar5 < uVar7 || uVar5 - uVar7 == 0) {
        func_0x000180060370();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    iVar1 = *(int64_t *)arg1;
    uVar2 = *(uint64_t *)(arg1 + 0x20);
    uVar4 = (*(int64_t *)(arg1 + 8) - iVar1 >> 2) * -0x3333333333333333;
    if (uVar4 < uVar2 || uVar4 - uVar2 == 0) {
        func_0x000180060370();
        pcVar3 = (code *)swi(3);
        (*pcVar3)();
        return;
    }
    uVar6 = CONCAT44(*(undefined4 *)(uVar7 * 0x38 + 0x28 + *(int64_t *)(arg1 + 0x40)), (int32_t)uVar5 + -1);
    if (in_DL == '\0') {
        *(undefined8 *)(iVar1 + uVar2 * 0x14) = uVar6;
    }
    *(undefined8 *)(iVar1 + 8 + uVar2 * 0x14) = uVar6;
    *(undefined *)(iVar1 + 0x12 + uVar2 * 0x14) = 1;
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    return;
}

// ============================================================
// Function: FUN_180157620
// Address: 0x180157620
// Size: 5520 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_180h
// WARNING: [rz-ghidra] Detected overlap for variable var_17fh
// WARNING: [rz-ghidra] Detected overlap for variable var_17eh
// WARNING: [rz-ghidra] Detected overlap for variable var_134h
// WARNING: [rz-ghidra] Detected overlap for variable var_164h
// WARNING: [rz-ghidra] Detected overlap for variable var_188h
// WARNING: [rz-ghidra] Detected overlap for variable var_d4h
// WARNING: [rz-ghidra] Detected overlap for variable var_178h
// WARNING: [rz-ghidra] Detected overlap for variable var_dch
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_67h
// WARNING: [rz-ghidra] Detected overlap for variable var_66h
// WARNING: [rz-ghidra] Detected overlap for variable var_65h
// WARNING: [rz-ghidra] Detected overlap for variable var_104h
// WARNING: [rz-ghidra] Detected overlap for variable var_16ch
// WARNING: [rz-ghidra] Detected overlap for variable var_174h
// WARNING: [rz-ghidra] Detected overlap for variable var_183h
// WARNING: [rz-ghidra] Detected overlap for variable var_182h

void fcn.180157620(int64_t arg1)
{
    int32_t *piVar1;
    int16_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    code *pcVar5;
    int32_t iVar6;
    uint8_t uVar7;
    int16_t iVar8;
    unkuint3 Var9;
    undefined auVar10 [16];
    undefined4 uVar11;
    int64_t iVar12;
    undefined uVar13;
    char cVar14;
    undefined4 uVar15;
    undefined8 *puVar16;
    uint64_t uVar17;
    int64_t iVar18;
    uint64_t *puVar19;
    int64_t iVar20;
    int64_t *piVar21;
    uint64_t uVar22;
    int64_t *piVar23;
    uint8_t uVar24;
    undefined uVar25;
    uint64_t uVar26;
    undefined8 *puVar27;
    int16_t *piVar28;
    uint16_t in_DX;
    undefined uVar29;
    uint16_t uVar30;
    uint64_t *puVar31;
    int64_t iVar32;
    undefined *puVar33;
    undefined *puVar34;
    undefined *puVar35;
    int32_t iVar36;
    int64_t *piVar37;
    uint64_t *puVar38;
    int32_t iVar39;
    uint8_t uVar40;
    undefined uVar41;
    uint32_t uVar42;
    int64_t *piVar43;
    uint8_t uVar44;
    undefined uVar45;
    uint32_t uVar46;
    bool bVar47;
    bool bVar48;
    bool bVar49;
    undefined4 extraout_XMM0_Da;
    undefined auVar50 [16];
    undefined8 uStack_1c0;
    undefined auStack_1b8 [8];
    undefined auStack_1b0 [24];
    int64_t var_198h;
    undefined var_188h [4];
    int64_t var_184h;
    undefined8 var_178h;
    int64_t var_170h;
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    undefined8 uStack_c0;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    undefined8 uStack_80;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar33 = auStack_1b8;
    puVar35 = auStack_1b8;
    puVar34 = auStack_1b8;
    var_60h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_1b8;
    var_184h._0_2_ = in_DX;
    var_168h = arg1;
    func_0x00018015aea0(arg1, &var_f8h, 0);
    if (((*(char *)(arg1 + 0x26c) == '\0') && (*(char *)(arg1 + 0x26b) != '\0')) &&
       ((in_DX == 0x7b ||
        (((uint16_t)(in_DX - 0x22) < 0x3a && ((0x200000000000061U >> ((uint64_t)(in_DX - 0x22) & 0x3f) & 1) != 0)))))) {
        bVar49 = true;
    } else {
        bVar49 = false;
    }
    if (in_DX == 0x7b) {
        uVar46 = 0x7d;
    } else if (in_DX == 0x5b) {
        uVar46 = 0x5d;
    } else {
        uVar46 = (uint32_t)in_DX;
        if (in_DX == 0x28) {
            uVar46 = 0x29;
        }
    }
    var_184h._4_4_ = uVar46;
    if (*(uint16_t *)(arg1 + 0x478) == 0) {
code_r0x0001801578aa:
        puVar38 = *(uint64_t **)arg1;
        puVar19 = puVar38;
        while( true ) {
            uVar40 = (uint8_t)in_DX;
            uVar30 = (uint16_t)uVar46;
            uVar7 = (uint8_t)(in_DX >> 8);
            if (puVar19 == *(uint64_t **)(arg1 + 8)) break;
            cVar14 = -1;
            if (*(uint64_t **)(arg1 + 8) <= puVar19) {
                cVar14 = '\x01';
            }
            if (-1 < cVar14) break;
            if ((*(int32_t *)puVar19 != *(int32_t *)(puVar19 + 1)) ||
               (*(int32_t *)((int64_t)puVar19 + 4) != *(int32_t *)((int64_t)puVar19 + 0xc))) {
                if (!bVar49) goto code_r0x000180157ea4;
                puVar19 = puVar38 + 1;
                goto code_r0x000180157910;
            }
            puVar19 = (uint64_t *)((int64_t)puVar19 + 0x14);
        }
        if (bVar49) {
            if (in_DX < 0x80) {
                var_68h = CONCAT71(var_68h._1_7_, uVar40);
                iVar32 = (int64_t)&var_68h + 1;
            } else {
                uVar25 = (undefined)(in_DX >> 6);
                if (in_DX < 0x800) {
                    uVar22 = CONCAT71(var_68h._1_7_, uVar25) & 0xffffffffffffff1f;
                    var_68h._2_6_ = (unkbyte6)(uVar22 >> 0x10);
                    var_68h = CONCAT62(var_68h._2_6_, CONCAT11(uVar40, (char)uVar22)) & 0xffffffffffff3fff | 0x80c0;
                    iVar32 = (int64_t)&var_68h + 2;
                } else {
                    uVar22 = CONCAT62(var_68h._2_6_, CONCAT11(uVar25, uVar7 >> 4)) & 0xffffffffffff3fff;
                    var_68h._3_5_ = (unkbyte5)(uVar22 >> 0x18);
                    var_68h = CONCAT53(var_68h._3_5_, CONCAT12(uVar40, (int16_t)uVar22)) & 0xffffffffff3fffff | 0x8080e0
                    ;
                    iVar32 = (int64_t)&var_68h + 3;
                }
            }
            var_158h = (int64_t)&var_68h;
            iVar20 = func_0x0001801620a0(iVar32, uVar46);
            iVar20 = iVar20 + (iVar32 - (int64_t)&var_68h);
            iVar32 = var_158h;
            var_150h = iVar20;
            auVar50 = _var_158h;
            piVar37 = *(int64_t **)arg1;
            piVar43 = piVar37 + 1;
            var_150h._0_4_ = (undefined4)iVar20;
            uVar15 = (undefined4)var_150h;
            var_150h._4_4_ = (undefined4)((uint64_t)iVar20 >> 0x20);
            uVar11 = var_150h._4_4_;
            _var_158h = auVar50;
            while( true ) {
                piVar23 = *(int64_t **)(arg1 + 8);
                if (piVar37 == piVar23) break;
                cVar14 = -1;
                if (piVar23 <= piVar37) {
                    cVar14 = '\x01';
                }
                if (-1 < cVar14) break;
                iVar39 = *(int32_t *)piVar37;
                iVar36 = *(int32_t *)piVar43;
                bVar49 = SBORROW4(iVar39, iVar36);
                iVar6 = iVar39 - iVar36;
                if (iVar39 == iVar36) {
                    bVar49 = SBORROW4(*(int32_t *)((int64_t)piVar37 + 4), *(int32_t *)((int64_t)piVar43 + 4));
                    iVar6 = *(int32_t *)((int64_t)piVar37 + 4) - *(int32_t *)((int64_t)piVar43 + 4);
                }
                piVar23 = piVar43;
                if (bVar49 != iVar6 < 0) {
                    piVar23 = piVar37;
                }
                iVar20 = *piVar23;
                uVar46 = (uint32_t)((uint64_t)iVar20 >> 0x20);
                var_140h = CONCAT44(var_140h._4_4_, uVar46);
                var_178h = (int64_t *)CONCAT44(var_178h._4_4_, uVar46);
                if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
                    *piVar1 = *piVar1 + 1;
                    UNLOCK();
                }
                var_118h = CONCAT44(var_f8h._4_4_, (undefined4)var_f8h);
                var_110h._0_4_ = (undefined4)var_f0h;
                var_110h._4_4_ = var_f0h._4_4_;
                var_d8h = (int64_t)&var_118h;
                var_170h = iVar20;
                var_148h._0_4_ = uVar46;
                var_e8h = iVar20;
                func_0x00018015c7f0((int64_t *)(arg1 + 0x40), &var_108h, iVar20, &var_158h);
                iVar12 = var_108h;
                var_120h._0_4_ = uVar15;
                var_128h = iVar32;
                var_120h._4_4_ = uVar11;
                var_138h = var_108h;
                var_188h[0] = 0;
                var_198h = (int64_t)&var_128h;
                var_e0h = iVar20;
                func_0x0001801633e0(var_118h, var_188h, &var_e0h, &var_138h);
                *(undefined *)(arg1 + 0x2c8) = 1;
                *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
                iVar18 = var_110h;
                if (var_110h == 0) {
                    uVar42 = (uint32_t)var_178h;
                } else {
                    LOCK();
                    piVar1 = (int32_t *)(var_110h + 8);
                    iVar36 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar36 == 1) {
                        (***(code ***)var_110h)(var_110h);
                        LOCK();
                        piVar1 = (int32_t *)(iVar18 + 0xc);
                        iVar36 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        uVar42 = (uint32_t)var_148h;
                        if (iVar36 == 1) {
                            (**(code **)(*(int64_t *)iVar18 + 8))(iVar18);
                            uVar42 = uVar46;
                        }
                    } else {
                        uVar42 = (uint32_t)var_140h;
                    }
                }
                piVar23 = piVar37;
                while( true ) {
                    piVar21 = (int64_t *)((int64_t)piVar23 + 0x14);
                    if (piVar21 == *(int64_t **)(var_168h + 8)) break;
                    cVar14 = -1;
                    if (*(int64_t **)(var_168h + 8) <= piVar21) {
                        cVar14 = '\x01';
                    }
                    if (-1 < cVar14) break;
                    var_178h = (int64_t *)*piVar21;
                    iVar36 = (int32_t)iVar20;
                    if ((int32_t)var_178h == iVar36) {
                        var_178h = (int64_t *)
                                   CONCAT44(((int32_t)((uint64_t)var_178h >> 0x20) - uVar42) + var_108h._4_4_, 
                                            (int32_t)var_178h);
                    }
                    var_178h = (int64_t *)CONCAT44(var_178h._4_4_, (uint32_t)var_178h + ((int32_t)iVar12 - iVar36));
                    *piVar21 = (int64_t)var_178h;
                    var_178h = *(int64_t **)((int64_t)piVar23 + 0x1c);
                    if ((int32_t)var_178h == iVar36) {
                        var_178h = (int64_t *)
                                   CONCAT44(((int32_t)((uint64_t)var_178h >> 0x20) - uVar42) + var_108h._4_4_, 
                                            (int32_t)var_178h);
                    }
                    var_178h = (int64_t *)CONCAT44(var_178h._4_4_, (uint32_t)var_178h + ((int32_t)iVar12 - iVar36));
                    *(int64_t **)((int64_t)piVar23 + 0x1c) = var_178h;
                    piVar23 = piVar21;
                }
                *(int32_t *)piVar37 = (int32_t)var_e8h;
                *(int32_t *)((int64_t)piVar37 + 4) = var_170h._4_4_ + 1;
                *(int32_t *)piVar43 = (int32_t)var_e8h;
                *(int32_t *)((int64_t)piVar43 + 4) = var_170h._4_4_ + 1;
                *(undefined *)((int64_t)piVar37 + 0x12) = 1;
                piVar37 = (int64_t *)((int64_t)piVar37 + 0x14);
                piVar43 = (int64_t *)((int64_t)piVar43 + 0x14);
                arg1 = var_168h;
            }
            *(int16_t *)(arg1 + 0x478) = (int16_t)var_184h._4_4_;
            uVar17 = ((int64_t)piVar23 - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
            uVar22 = *(uint64_t *)(arg1 + 0x20);
            if (uVar17 < uVar22 || uVar17 - uVar22 == 0) {
                uVar22 = *(uint64_t *)(arg1 + 0x18);
                if (uVar17 <= *(uint64_t *)(arg1 + 0x18)) {
                    uVar22 = 0;
                }
                *(uint64_t *)(arg1 + 0x20) = uVar22;
                if (uVar17 < uVar22 || uVar17 - uVar22 == 0) {
                    func_0x000180060370();
code_r0x000180158b8c:
                    func_0x000180004720();
code_r0x000180158b92:
                    func_0x000180004720();
                    pcVar5 = (code *)swi(3);
                    (*pcVar5)();
                    return;
                }
            }
            puVar16 = (undefined8 *)(*(int64_t *)arg1 + uVar22 * 0x14);
            iVar39 = *(int32_t *)puVar16;
            iVar36 = *(int32_t *)(puVar16 + 1);
            bVar47 = SBORROW4(iVar39, iVar36);
            iVar6 = iVar39 - iVar36;
            bVar49 = iVar39 == iVar36;
            if (bVar49) {
                iVar36 = *(int32_t *)((int64_t)puVar16 + 0xc);
                iVar39 = *(int32_t *)((int64_t)puVar16 + 4);
                bVar47 = SBORROW4(iVar39, iVar36);
                iVar6 = iVar39 - iVar36;
                bVar49 = iVar39 == iVar36;
            }
            puVar27 = puVar16 + 1;
            if (!bVar49 && bVar47 == iVar6 < 0) {
                puVar27 = puVar16;
            }
            *(undefined8 *)(arg1 + 0x47c) = *puVar27;
            in_DX = (uint16_t)var_184h;
        } else {
code_r0x000180157ea4:
            if (*(char *)(arg1 + 0x26c) == '\0') {
                if ((*(char *)(arg1 + 0x265) != '\0') && (in_DX == 10)) {
                    if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
                        *piVar1 = *piVar1 + 1;
                        UNLOCK();
                    }
                    var_118h._4_4_ = var_f8h._4_4_;
                    var_118h._0_4_ = (undefined4)var_f8h;
                    var_110h._0_4_ = (undefined4)var_f0h;
                    var_110h._4_4_ = var_f0h._4_4_;
                    var_d0h = (int64_t)&var_118h;
                    piVar43 = *(int64_t **)arg1;
                    uVar45 = var_188h[0];
                    uVar41 = var_188h[0];
                    uVar25 = var_188h[0];
code_r0x000180157f10:
                    iVar32 = var_168h;
                    if (piVar43 == *(int64_t **)(var_168h + 8)) {
                        cVar14 = '\0';
                    } else {
                        cVar14 = -1;
                        if (*(int64_t **)(var_168h + 8) <= piVar43) {
                            cVar14 = '\x01';
                        }
                    }
                    if (-1 < cVar14) goto code_r0x0001801588dd;
                    iVar36 = *(int32_t *)piVar43;
                    iVar39 = *(int32_t *)(piVar43 + 1);
                    var_138h = (int64_t)piVar43 + 0xc;
                    bVar49 = SBORROW4(iVar36, iVar39);
                    iVar6 = iVar36 - iVar39;
                    if (iVar36 == iVar39) {
                        bVar49 = SBORROW4(*(int32_t *)((int64_t)piVar43 + 4), *(int32_t *)var_138h);
                        iVar6 = *(int32_t *)((int64_t)piVar43 + 4) - *(int32_t *)var_138h;
                    }
                    piVar37 = piVar43 + 1;
                    if (bVar49 != iVar6 < 0) {
                        piVar37 = piVar43;
                    }
                    iVar20 = *piVar37;
                    bVar47 = SBORROW4(iVar36, iVar39);
                    iVar6 = iVar36 - iVar39;
                    bVar49 = iVar36 == iVar39;
                    var_d8h = iVar20;
                    if (bVar49) {
                        iVar36 = *(int32_t *)var_138h;
                        iVar39 = *(int32_t *)((int64_t)piVar43 + 4);
                        bVar47 = SBORROW4(iVar39, iVar36);
                        iVar6 = iVar39 - iVar36;
                        bVar49 = iVar39 == iVar36;
                        if (!bVar49) goto code_r0x000180157f6b;
                    } else {
code_r0x000180157f6b:
                        piVar37 = piVar43 + 1;
                        if (!bVar49 && bVar47 == iVar6 < 0) {
                            piVar37 = piVar43;
                        }
                        iVar18 = *piVar37;
                        if (SUB168(_var_118h, 8) != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(SUB168(_var_118h, 8) + 8);
                            *piVar1 = *piVar1 + 1;
                            UNLOCK();
                        }
                        _var_158h = _var_118h;
                        func_0x00018015bca0(var_168h, &var_158h, iVar20, iVar18);
                        func_0x00018015c720(iVar32, piVar43, iVar20, iVar18);
                    }
                    var_108h = iVar32 + 0x40;
                    iVar36 = (int32_t)iVar20;
                    uVar17 = (uint64_t)iVar36;
                    iVar18 = *(int64_t *)var_108h;
                    uVar22 = (*(int64_t *)(iVar32 + 0x48) - iVar18 >> 3) * 0x6db6db6db6db6db7;
                    if (uVar22 < uVar17 || uVar22 - uVar17 == 0) goto code_r0x000180158baa;
                    auVar50 = _var_118h;
                    uVar22 = func_0x00018015d7b0(var_108h, uVar17 * 0x38 + iVar18);
                    var_140h = (int64_t)iVar36 * 0x38 + iVar18;
                    if (uVar22 == 0) {
                        var_178h = (int64_t *)((uint64_t)var_178h._4_4_ << 0x20);
                    } else {
                        var_178h = (int64_t *)
                                   CONCAT44(var_178h._4_4_, 
                                            (uint32_t)*(uint16_t *)(uVar22 * 4 + -4 + *(int64_t *)var_140h));
                    }
                    var_170h = *(int64_t *)var_140h;
                    uVar17 = *(int64_t *)(var_140h + 8) - var_170h >> 2;
                    if (uVar22 < uVar17) {
                        var_148h._0_4_ = (uint32_t)*(uint16_t *)(uVar22 * 4 + var_170h);
                    } else {
                        var_148h._0_4_ = 0;
                    }
                    cVar14 = func_0x000180162130((uint32_t)var_148h);
                    iVar32 = var_170h;
                    if (cVar14 != '\0') {
                        while ((uVar22 < uVar17 &&
                               (cVar14 = func_0x000180162130(*(undefined2 *)(iVar32 + uVar22 * 4)), uVar25 = var_188h[0]
                               , cVar14 != '\0'))) {
                            uVar22 = uVar22 + 1;
                        }
                        uVar45 = var_188h[0];
                        piVar28 = *(int16_t **)var_140h;
                        piVar2 = piVar28 + uVar22 * 2;
                        iVar39 = 0;
                        while (piVar28 != piVar2) {
                            cVar14 = -1;
                            if (piVar2 <= piVar28) {
                                cVar14 = '\x01';
                            }
                            if (-1 < cVar14) break;
                            if (*piVar28 == 9) {
                                iVar39 = iVar39 + (*(int32_t *)(var_108h + 0x18) -
                                                  iVar39 % *(int32_t *)(var_108h + 0x18));
                                piVar28 = piVar28 + 2;
                            } else {
                                iVar39 = iVar39 + 1;
                                piVar28 = piVar28 + 2;
                            }
                        }
                        var_e8h = CONCAT44(iVar39, iVar36);
                        _var_158h = auVar50;
                        if (auVar50._8_8_ != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(auVar50._8_8_ + 8);
                            *piVar1 = *piVar1 + 1;
                            UNLOCK();
                            _var_158h = _var_118h;
                        }
                        func_0x00018015bca0(var_168h, &var_158h, iVar20, var_e8h);
                        func_0x00018015c720(var_168h, piVar43, iVar20, var_e8h);
                    }
                    var_68h = 0;
                    var_98h = 0;
                    var_90h = 0xf;
                    stack0xffffffffffffff59 = SUB1615(ZEXT816(0), 1);
                    auVar50[15] = 0;
                    auVar50._0_15_ = stack0xffffffffffffff59;
                    _var_a8h = auVar50 << 8;
                    var_170h = 0;
                    iVar32 = *(int64_t *)var_140h;
                    iVar18 = 0;
                    if (*(int64_t *)(var_140h + 8) - iVar32 >> 2 != 0) {
                        do {
                            iVar18 = var_68h;
                            uVar30 = *(uint16_t *)(iVar32 + var_170h * 4);
                            var_98h = var_68h;
                            cVar14 = func_0x000180162130(uVar30);
                            if (cVar14 == '\0') break;
                            if (uVar30 < 0x80) {
                                uVar22 = 1;
code_r0x000180158210:
                                var_184h._4_4_ = CONCAT31(var_184h._5_3_, (char)uVar30);
                            } else {
                                uVar29 = (undefined)uVar30;
                                uVar13 = (undefined)(uVar30 >> 6);
                                if (0x7ff < uVar30) {
                                    uVar30 = (uint16_t)(uint8_t)((uint8_t)(uVar30 >> 0xc) | 0xe0);
                                    Var9 = CONCAT21(var_184h._6_2_, uVar13) & 0xffff3f;
                                    var_184h._4_2_ = ((uint16_t)Var9 | 0x80) << 8;
                                    var_184h._7_1_ = (undefined)(Var9 >> 0x10);
                                    var_184h._4_4_ =
                                         CONCAT13(var_184h._7_1_, CONCAT12(uVar29, var_184h._4_2_)) & 0xff3fffff |
                                         0x800000;
                                    uVar22 = 3;
                                    goto code_r0x000180158210;
                                }
                                uVar46 = CONCAT31(var_184h._5_3_, uVar13) & 0xffffff1f;
                                var_184h._6_2_ = (undefined2)(uVar46 >> 0x10);
                                var_184h._4_4_ =
                                     CONCAT22(var_184h._6_2_, CONCAT11(uVar29, (char)uVar46)) & 0xffff3fff | 0x80c0;
                                uVar22 = 2;
                            }
                            if ((uint64_t)(var_90h - var_68h) < uVar22) {
                                var_198h = uVar22;
                                func_0x00018000ee80(&var_a8h, uVar22, uVar41, (int64_t)&var_184h + 4);
                            } else {
                                var_98h = var_68h + uVar22;
                                piVar37 = &var_a8h;
                                if (0xf < (uint64_t)var_90h) {
                                    piVar37 = (int64_t *)var_a8h;
                                }
                                iVar32 = (int64_t)piVar37 + var_68h;
                                fcn.180498030(iVar32, (int64_t)&var_184h + 4, uVar22);
                                *(undefined *)(iVar32 + uVar22) = 0;
                            }
                            var_170h = var_170h + 1;
                            iVar32 = *(int64_t *)var_140h;
                            var_68h = var_98h;
                            iVar18 = var_98h;
                        } while ((uint64_t)var_170h < (uint64_t)(*(int64_t *)(var_140h + 8) - iVar32 >> 2));
                    }
                    if (iVar18 == 0x7fffffffffffffff) {
code_r0x000180158ba4:
                        func_0x0001800047c0();
code_r0x000180158baa:
                        func_0x000180060370();
                        pcVar5 = (code *)swi(3);
                        (*pcVar5)();
                        return;
                    }
                    var_170h = (int64_t)&var_a8h;
                    if (0xf < (uint64_t)var_90h) {
                        var_170h = var_a8h;
                    }
                    _var_c8h = ZEXT816(0);
                    var_b8h = 0;
                    var_b0h = 0;
                    var_140h = iVar18 + 1;
                    if ((uint64_t)var_140h < 0x10) {
                        uVar22 = 0xf;
                        piVar37 = &var_c8h;
code_r0x000180158399:
                        var_b8h = var_140h;
                        var_b0h = uVar22;
                        *(undefined *)piVar37 = 10;
                        fcn.180498030((undefined *)((int64_t)piVar37 + 1), var_170h, var_68h);
                        *(undefined *)(var_140h + (int64_t)piVar37) = 0;
                        iVar32 = var_b8h;
                        iVar39 = (int32_t)var_98h;
                        var_140h = CONCAT44(var_140h._4_4_, (int32_t)var_98h);
                        iVar8 = (int16_t)var_178h;
                        if ((iVar8 - 0x5bU & 0xffdf) == 0) {
                            if (var_b0h == var_b8h) {
                                var_198h = 1;
                                func_0x00018000ee80(&var_c8h, 1, uVar45, 0x18063dad4);
                            } else {
                                piVar37 = &var_c8h;
                                if (0xf < (uint64_t)var_b0h) {
                                    piVar37 = (int64_t *)var_c8h;
                                }
                                puVar33 = (undefined *)((int64_t)piVar37 + var_b8h);
                                var_b8h = var_b8h + 1;
                                *puVar33 = 9;
                                *(undefined *)((int64_t)piVar37 + iVar32 + 1) = 0;
                            }
                            var_140h = CONCAT44(var_140h._4_4_, iVar39 + 1);
                            if (iVar8 == 0x7b) {
                                if ((int16_t)var_148h == 0x7d) {
code_r0x00018015846b:
                                    var_68h = var_98h;
                                    if (var_98h == 0x7fffffffffffffff) {
                                        func_0x0001800047c0();
                                        pcVar5 = (code *)swi(3);
                                        (*pcVar5)();
                                        return;
                                    }
                                    var_178h = &var_a8h;
                                    if (0xf < (uint64_t)var_90h) {
                                        var_178h = (int64_t *)var_a8h;
                                    }
                                    _var_88h = ZEXT816(0);
                                    piVar37 = (int64_t *)0x0;
                                    var_78h = 0;
                                    var_70h = 0;
                                    var_170h = var_98h + 1;
                                    if (0xf < (uint64_t)var_170h) {
                                        uVar22 = var_170h | 0xf;
                                        if (0x7fffffffffffffff < uVar22) {
                                            uVar22 = 0x7fffffffffffffff;
                                            uVar17 = 0x8000000000000027;
code_r0x000180158515:
                                            iVar32 = func_0x000180459890(uVar17);
                                            if (iVar32 != 0) {
                                                piVar37 = (int64_t *)(iVar32 + 0x27U & 0xffffffffffffffe0);
                                                piVar37[-1] = iVar32;
code_r0x00018015853c:
                                                var_88h = (int64_t)piVar37;
                                                goto code_r0x000180158559;
                                            }
code_r0x0001801588c8:
                                            pcVar5 = (code *)swi(0x29);
                                            (*pcVar5)(5);
                                            puVar33 = auStack_1b0;
                                            goto code_r0x0001801588cf;
                                        }
                                        if (uVar22 < 0x16) {
                                            uVar22 = 0x16;
                                        }
                                        if (uVar22 == 0xffffffffffffffff) {
                                            _var_88h = ZEXT816(0);
                                            goto code_r0x000180158559;
                                        }
                                        if (uVar22 + 1 < 0x1000) {
                                            piVar37 = (int64_t *)func_0x000180459890();
                                            goto code_r0x00018015853c;
                                        }
                                        uVar17 = uVar22 + 0x28;
                                        if (uVar22 + 1 < uVar17) goto code_r0x000180158515;
                                        goto code_r0x000180158b92;
                                    }
                                    uVar22 = 0xf;
                                    piVar37 = &var_88h;
code_r0x000180158559:
                                    iVar32 = var_68h;
                                    var_78h = var_170h;
                                    var_70h = uVar22;
                                    *(undefined *)piVar37 = 10;
                                    fcn.180498030((undefined *)((int64_t)piVar37 + 1), var_178h, iVar32);
                                    *(undefined *)(var_68h + 1 + (int64_t)piVar37) = 0;
                                    iVar32 = var_88h;
                                    piVar37 = &var_88h;
                                    if (0xf < (uint64_t)var_70h) {
                                        piVar37 = (int64_t *)var_88h;
                                    }
                                    if ((uint64_t)(var_b0h - var_b8h) < (uint64_t)var_78h) {
                                        var_198h = var_78h;
                                        func_0x00018000ee80(&var_c8h, var_78h, uVar25);
                                        iVar32 = var_88h;
                                    } else {
                                        piVar23 = &var_c8h;
                                        if (0xf < (uint64_t)var_b0h) {
                                            piVar23 = (int64_t *)var_c8h;
                                        }
                                        iVar18 = (int64_t)piVar23 + var_b8h;
                                        var_b8h = var_b8h + var_78h;
                                        fcn.180498030(iVar18, piVar37, var_78h);
                                        *(undefined *)(iVar18 + var_78h) = 0;
                                    }
                                    if (0xf < (uint64_t)var_70h) {
                                        uVar22 = var_70h + 1;
                                        iVar18 = iVar32;
                                        if (0xfff < uVar22) {
                                            iVar18 = *(int64_t *)(iVar32 + -8);
                                            if (0x1f < (iVar32 - iVar18) - 8U) goto code_r0x0001801588c8;
                                            uVar22 = var_70h + 0x28;
                                        }
                                        func_0x000180459c3c(iVar18, uVar22);
                                    }
                                }
                            } else if ((iVar8 == 0x5b) && ((int16_t)var_148h == 0x5d)) goto code_r0x00018015846b;
                        }
                        var_128h = (int64_t)&var_c8h;
                        if (0xf < (uint64_t)var_b0h) {
                            var_128h = var_c8h;
                        }
                        var_120h = var_b8h;
                        if (var_110h != 0) {
                            LOCK();
                            *(int32_t *)(var_110h + 8) = *(int32_t *)(var_110h + 8) + 1;
                            UNLOCK();
                        }
                        _var_158h = _var_118h;
                        var_178h = &var_158h;
                        func_0x00018015c7f0(var_108h, &var_e0h, iVar20, &var_128h);
                        iVar18 = var_e0h;
                        _var_88h = _var_128h;
                        var_170h = var_e0h;
                        var_188h[0] = 0;
                        var_198h = (int64_t)&var_88h;
                        var_68h = iVar20;
                        func_0x0001801633e0(var_158h, var_188h, &var_68h, &var_170h);
                        *(undefined *)(var_168h + 0x2c8) = 1;
                        *(undefined4 *)(var_168h + 0x2cc) = 0xffffffff;
                        iVar32 = var_150h;
                        if (var_150h != 0) {
                            LOCK();
                            piVar1 = (int32_t *)(var_150h + 8);
                            iVar39 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar39 == 1) {
                                (***(code ***)var_150h)(var_150h);
                                LOCK();
                                piVar1 = (int32_t *)(iVar32 + 0xc);
                                iVar39 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar39 == 1) {
                                    (**(code **)(*(int64_t *)iVar32 + 8))(iVar32);
                                }
                            }
                        }
                        uVar41 = var_188h[0];
                        piVar37 = piVar43;
                        while( true ) {
                            piVar23 = (int64_t *)((int64_t)piVar37 + 0x14);
                            if (piVar23 == *(int64_t **)(var_168h + 8)) break;
                            cVar14 = -1;
                            if (*(int64_t **)(var_168h + 8) <= piVar23) {
                                cVar14 = '\x01';
                            }
                            if (-1 < cVar14) break;
                            var_68h = *piVar23;
                            if ((int32_t)var_68h == iVar36) {
                                var_68h = CONCAT44(((int32_t)((uint64_t)var_68h >> 0x20) - var_d8h._4_4_) +
                                                   var_e0h._4_4_, (int32_t)var_68h);
                            }
                            var_68h = CONCAT44(var_68h._4_4_, (int32_t)var_68h + ((int32_t)iVar18 - iVar36));
                            *piVar23 = var_68h;
                            var_68h = *(int64_t *)((int64_t)piVar37 + 0x1c);
                            if ((int32_t)var_68h == iVar36) {
                                var_68h = CONCAT44(((int32_t)((uint64_t)var_68h >> 0x20) - var_d8h._4_4_) +
                                                   var_e0h._4_4_, (int32_t)var_68h);
                            }
                            var_68h = CONCAT44(var_68h._4_4_, (int32_t)var_68h + ((int32_t)iVar18 - iVar36));
                            *(int64_t *)((int64_t)piVar37 + 0x1c) = var_68h;
                            piVar37 = piVar23;
                        }
                        iVar36 = iVar36 + 1;
                        uVar17 = (uint64_t)iVar36;
                        uVar22 = (*(int64_t *)(var_108h + 8) - *(int64_t *)var_108h >> 3) * 0x6db6db6db6db6db7;
                        if (uVar22 < uVar17 || uVar22 - uVar17 == 0) {
                            func_0x000180060370();
                            goto code_r0x000180158ba4;
                        }
                        piVar28 = *(int16_t **)(uVar17 * 0x38 + *(int64_t *)var_108h);
                        piVar2 = piVar28 + (int64_t)(int32_t)(uint32_t)var_140h * 2;
                        iVar39 = 0;
                        while (piVar28 != piVar2) {
                            cVar14 = -1;
                            if (piVar2 <= piVar28) {
                                cVar14 = '\x01';
                            }
                            if (-1 < cVar14) break;
                            if (*piVar28 == 9) {
                                iVar39 = iVar39 + (*(int32_t *)(var_108h + 0x18) -
                                                  iVar39 % *(int32_t *)(var_108h + 0x18));
                                piVar28 = piVar28 + 2;
                            } else {
                                iVar39 = iVar39 + 1;
                                piVar28 = piVar28 + 2;
                            }
                        }
                        *(int32_t *)piVar43 = iVar36;
                        *(int32_t *)((int64_t)piVar43 + 4) = iVar39;
                        *(int32_t *)(piVar43 + 1) = iVar36;
                        *(int32_t *)var_138h = iVar39;
                        *(undefined *)((int64_t)piVar43 + 0x12) = 1;
                        if (0xf < (uint64_t)var_b0h) {
                            uVar22 = var_b0h + 1;
                            iVar32 = var_c8h;
                            if (0xfff < uVar22) {
                                iVar32 = *(int64_t *)(var_c8h + -8);
                                puVar33 = auStack_1b8;
                                if (0x1f < (var_c8h - iVar32) - 8U) goto code_r0x0001801588cf;
                                uVar22 = var_b0h + 0x28;
                            }
                            func_0x000180459c3c(iVar32, uVar22);
                        }
                        var_b8h = 0;
                        var_b0h = 0xf;
                        auVar10[15] = 0;
                        auVar10._0_15_ = stack0xffffffffffffff39;
                        _var_c8h = auVar10 << 8;
                        if (0xf < (uint64_t)var_90h) {
                            uVar22 = var_90h + 1;
                            iVar32 = var_a8h;
                            if (0xfff < uVar22) {
                                iVar32 = *(int64_t *)(var_a8h + -8);
                                if (0x1f < (var_a8h - iVar32) - 8U) goto code_r0x0001801588d6;
                                uVar22 = var_90h + 0x28;
                            }
                            func_0x000180459c3c(iVar32, uVar22);
                        }
                        piVar43 = (int64_t *)((int64_t)piVar43 + 0x14);
                        goto code_r0x000180157f10;
                    }
                    uVar22 = var_140h | 0xf;
                    if (uVar22 < 0x8000000000000000) {
                        if (uVar22 < 0x16) {
                            uVar22 = 0x16;
                        }
                        if (uVar22 != 0xffffffffffffffff) {
                            if (uVar22 + 1 < 0x1000) {
                                piVar37 = (int64_t *)func_0x000180459890();
                                var_c8h = (int64_t)piVar37;
                                goto code_r0x000180158399;
                            }
                            uVar17 = uVar22 + 0x28;
                            if (uVar22 + 1 < uVar17) goto code_r0x00018015834b;
                            goto code_r0x000180158b8c;
                        }
                        piVar37 = (int64_t *)0x0;
                        _var_c8h = ZEXT816(0);
                        goto code_r0x000180158399;
                    }
                    uVar22 = 0x7fffffffffffffff;
                    uVar17 = 0x8000000000000027;
code_r0x00018015834b:
                    iVar32 = func_0x000180459890(uVar17);
                    puVar33 = auStack_1b8;
                    if (iVar32 != 0) {
                        piVar37 = (int64_t *)(iVar32 + 0x27U & 0xffffffffffffffe0);
                        piVar37[-1] = iVar32;
                        var_c8h = (int64_t)piVar37;
                        goto code_r0x000180158399;
                    }
code_r0x0001801588cf:
                    pcVar5 = (code *)swi(0x29);
                    (*pcVar5)(5);
                    puVar34 = puVar33 + 8;
code_r0x0001801588d6:
                    pcVar5 = (code *)swi(0x29);
                    (*pcVar5)(5);
                    puVar35 = puVar34 + 8;
code_r0x0001801588dd:
                    iVar32 = var_110h;
                    if (var_110h != 0) {
                        LOCK();
                        piVar1 = (int32_t *)(var_110h + 8);
                        iVar36 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar36 == 1) {
                            pcVar5 = **(code ***)var_110h;
                            *(undefined8 *)(puVar35 + -8) = 0x1801588ff;
                            (*pcVar5)(var_110h);
                            LOCK();
                            piVar1 = (int32_t *)(iVar32 + 0xc);
                            iVar36 = *piVar1;
                            *piVar1 = *piVar1 + -1;
                            UNLOCK();
                            if (iVar36 == 1) {
                                pcVar5 = *(code **)(*(int64_t *)iVar32 + 8);
                                *(undefined8 *)(puVar35 + -8) = 0x180158914;
                                (*pcVar5)(iVar32);
                            }
                        }
                    }
                    arg1 = *(int64_t *)(puVar35 + 0x50);
                    in_DX = *(uint16_t *)(puVar35 + 0x34);
                    puVar33 = puVar35;
                    goto code_r0x000180157e3e;
                }
            } else {
                for (; puVar38 != *(uint64_t **)(arg1 + 8); puVar38 = (uint64_t *)((int64_t)puVar38 + 0x14)) {
                    cVar14 = -1;
                    if (*(uint64_t **)(arg1 + 8) <= puVar38) {
                        cVar14 = '\x01';
                    }
                    if (-1 < cVar14) break;
                    if (*(int32_t *)puVar38 == *(int32_t *)(puVar38 + 1)) {
                        if (*(int32_t *)((int64_t)puVar38 + 4) == *(int32_t *)((int64_t)puVar38 + 0xc)) {
                            puVar19 = puVar38 + 1;
                            if (*(int32_t *)((int64_t)puVar38 + 4) < *(int32_t *)((int64_t)puVar38 + 0xc)) {
                                puVar19 = puVar38;
                            }
                            uVar22 = *puVar19;
                            iVar36 = (int32_t)uVar22;
                            uVar17 = (uint64_t)iVar36;
                            iVar32 = *(int64_t *)(arg1 + 0x40);
                            uVar26 = (*(int64_t *)(arg1 + 0x48) - iVar32 >> 3) * 0x6db6db6db6db6db7;
                            var_138h = uVar22;
                            if (uVar26 < uVar17 || uVar26 - uVar17 == 0) {
                                func_0x000180060370();
                                pcVar5 = (code *)swi(3);
                                (*pcVar5)();
                                return;
                            }
                            iVar39 = (int32_t)(uVar22 >> 0x20);
                            if (iVar39 != *(int32_t *)(uVar17 * 0x38 + 0x28 + iVar32)) {
                                piVar43 = (int64_t *)((int64_t)iVar36 * 0x38 + iVar32);
                                iVar32 = func_0x00018015d7b0(arg1 + 0x40, piVar43, iVar39);
                                if (iVar32 == piVar43[1] - *piVar43 >> 2) {
                                    if (iVar36 < (int32_t)uVar26 + -1) {
                                        iVar39 = 0;
                                        var_168h = (int64_t)(iVar36 + 1);
                                    } else {
                                        var_168h = uVar22 & 0xffffffff;
                                    }
                                } else {
                                    var_168h = CONCAT44(var_168h._4_4_, iVar36);
                                    iVar39 = func_0x000180150020(arg1 + 0x40, uVar22 & 0xffffffff, iVar32 + 1);
                                }
                                var_168h = CONCAT44(iVar39, (undefined4)var_168h);
                                if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
                                    LOCK();
                                    piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
                                    *piVar1 = *piVar1 + 1;
                                    UNLOCK();
                                }
                                func_0x00018015bca0(arg1, &var_128h, uVar22, var_168h);
                                func_0x00018015c720(arg1, puVar38, uVar22, var_168h);
                            }
                        }
                    }
                }
            }
            var_150h = 1;
            if (in_DX < 0x80) {
                var_184h._4_4_ = CONCAT31(var_184h._5_3_, uVar40);
            } else {
                uVar25 = (undefined)(in_DX >> 6);
                if (in_DX < 0x800) {
                    uVar46 = CONCAT31(var_184h._5_3_, uVar25) & 0xffffff1f;
                    var_184h._6_2_ = (undefined2)(uVar46 >> 0x10);
                    var_184h._4_4_ = CONCAT22(var_184h._6_2_, CONCAT11(uVar40, (char)uVar46)) & 0xffff3fff | 0x80c0;
                    var_150h = 2;
                } else {
                    uVar46 = CONCAT22(var_184h._6_2_, CONCAT11(uVar25, uVar7 >> 4)) & 0xffff3fff;
                    var_184h._7_1_ = (undefined)(uVar46 >> 0x18);
                    var_184h._4_4_ = CONCAT13(var_184h._7_1_, CONCAT12(uVar40, (int16_t)uVar46)) & 0xff3fffff | 0x8080e0
                    ;
                    var_150h = 3;
                }
            }
            var_158h = (int64_t)&var_184h + 4;
            if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
                LOCK();
                piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            func_0x00018015b890(arg1, &var_128h, &var_158h);
            puVar33 = auStack_1b8;
        }
code_r0x000180157e3e:
        if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
            LOCK();
            piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        *(undefined8 *)(puVar33 + -8) = 0x180157e68;
        uVar15 = func_0x00018015af60(arg1, &var_128h);
        if (in_DX < 0x7f) {
            if (((0x19 < (in_DX | 0x20) - 0x61) && (9 < in_DX - 0x30)) && (in_DX != 0x5f)) goto code_r0x000180157847;
        } else {
            *(undefined8 *)(puVar33 + -8) = 0x180158b22;
            cVar14 = func_0x000180163840(uVar15, in_DX);
            if (cVar14 == '\0') {
                *(undefined8 *)(puVar33 + -8) = 0x180158b2f;
                cVar14 = func_0x0001801638d0(extraout_XMM0_Da, in_DX);
                if (cVar14 == '\0') goto code_r0x000180157847;
            }
        }
        if (((*(char *)(arg1 + 0x131) != '\0') || (*(char *)(arg1 + 0x132) != '\0')) ||
           ((*(char *)(int64_t *)(arg1 + 0x130) == '\0' || (*(char *)(arg1 + 0x150) == '\0'))))
        goto code_r0x000180157847;
        *(undefined *)(arg1 + 0x250) = 0;
        *(undefined8 *)(puVar33 + -8) = 0x180158b75;
        func_0x000180161010((int64_t *)(arg1 + 0x130), arg1);
        piVar43 = (int64_t *)arg1;
    } else {
        if (*(uint16_t *)(arg1 + 0x478) != in_DX) {
code_r0x00018015789f:
            *(undefined2 *)(arg1 + 0x478) = 0;
            goto code_r0x0001801578aa;
        }
        puVar16 = (undefined8 *)func_0x00018014ffc0(arg1);
        iVar39 = *(int32_t *)puVar16;
        iVar36 = *(int32_t *)(puVar16 + 1);
        bVar48 = SBORROW4(iVar39, iVar36);
        iVar6 = iVar39 - iVar36;
        bVar47 = iVar39 == iVar36;
        if (bVar47) {
            iVar36 = *(int32_t *)((int64_t)puVar16 + 0xc);
            iVar39 = *(int32_t *)((int64_t)puVar16 + 4);
            bVar48 = SBORROW4(iVar39, iVar36);
            iVar6 = iVar39 - iVar36;
            bVar47 = iVar39 == iVar36;
        }
        puVar27 = puVar16 + 1;
        if (!bVar47 && bVar48 == iVar6 < 0) {
            puVar27 = puVar16;
        }
        if ((*(int32_t *)(arg1 + 0x47c) != (int32_t)*puVar27) ||
           (*(int32_t *)(arg1 + 0x480) != (int32_t)((uint64_t)*puVar27 >> 0x20))) goto code_r0x00018015789f;
        *(undefined2 *)(arg1 + 0x478) = 0;
        piVar23 = *(int64_t **)(arg1 + 8);
        piVar43 = (int64_t *)arg1;
        for (piVar37 = *(int64_t **)arg1; puVar33 = auStack_1b8, piVar37 != piVar23;
            piVar37 = (int64_t *)((int64_t)piVar37 + 0x14)) {
            uVar22 = piVar37[1];
            iVar36 = (int32_t)uVar22;
            uVar26 = (uint64_t)iVar36;
            iVar32 = *(int64_t *)(arg1 + 0x48);
            iVar20 = *(int64_t *)(arg1 + 0x40);
            uVar17 = (iVar32 - iVar20 >> 3) * 0x6db6db6db6db6db7;
            var_138h = uVar22;
            if (uVar17 < uVar26 || uVar17 - uVar26 == 0) {
                func_0x000180060370();
                pcVar5 = (code *)swi(3);
                (*pcVar5)();
                return;
            }
            piVar43 = (int64_t *)(uVar26 * 0x38 + iVar20);
            var_138h._4_4_ = (undefined4)(uVar22 >> 0x20);
            uVar15 = var_138h._4_4_;
            iVar18 = func_0x00018015d7b0(arg1 + 0x40, piVar43, uVar15);
            if (iVar18 == piVar43[1] - *piVar43 >> 2) {
                if (iVar36 < (int32_t)(iVar32 - iVar20 >> 3) * -0x49249249 + -1) {
                    uVar22 = (uint64_t)(iVar36 + 1);
                    uVar15 = 0;
                }
            } else {
                uVar15 = func_0x000180150020(arg1 + 0x40, uVar22 & 0xffffffff, iVar18 + 1);
            }
            var_68h = CONCAT44(uVar15, (int32_t)uVar22);
            *piVar37 = var_68h;
            piVar37[1] = var_68h;
            *(undefined *)((int64_t)piVar37 + 0x12) = 1;
            piVar43 = (int64_t *)var_168h;
        }
    }
    *(undefined *)(piVar43 + 0x59) = 1;
    *(undefined4 *)((int64_t)piVar43 + 0x2cc) = 0xffffffff;
code_r0x000180157847:
    piVar43 = (int64_t *)CONCAT44(var_f0h._4_4_, (undefined4)var_f0h);
    if (piVar43 != (int64_t *)0x0) {
        LOCK();
        piVar37 = piVar43 + 1;
        iVar36 = *(int32_t *)piVar37;
        *(int32_t *)piVar37 = *(int32_t *)piVar37 + -1;
        UNLOCK();
        if (iVar36 == 1) {
            pcVar5 = *(code **)*piVar43;
            *(undefined8 *)(puVar33 + -8) = 0x180157864;
            (*pcVar5)(piVar43);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar43 + 0xc);
            iVar36 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar36 == 1) {
                pcVar5 = *(code **)(*piVar43 + 8);
                *(undefined8 *)(puVar33 + -8) = 0x180157877;
                (*pcVar5)(piVar43);
            }
        }
    }
    *(undefined8 *)(puVar33 + -8) = 0x180157883;
    func_0x000180459870(var_60h ^ (uint64_t)puVar33);
    return;
code_r0x000180157910:
    puVar33 = auStack_1b8;
    if (puVar38 == *(uint64_t **)(arg1 + 8)) goto code_r0x000180157e3e;
    cVar14 = -1;
    if (*(uint64_t **)(arg1 + 8) <= puVar38) {
        cVar14 = '\x01';
    }
    puVar33 = auStack_1b8;
    if (-1 < cVar14) goto code_r0x000180157e3e;
    iVar36 = *(int32_t *)puVar38;
    iVar39 = *(int32_t *)puVar19;
    bVar49 = SBORROW4(iVar36, iVar39);
    iVar6 = iVar36 - iVar39;
    if (iVar36 == iVar39) {
        iVar3 = *(int32_t *)((int64_t)puVar19 + 4);
        iVar4 = *(int32_t *)((int64_t)puVar38 + 4);
        bVar49 = SBORROW4(iVar4, iVar3);
        iVar6 = iVar4 - iVar3;
        if (iVar4 != iVar3) goto code_r0x000180157942;
    } else {
code_r0x000180157942:
        puVar31 = puVar19;
        if (bVar49 != iVar6 < 0) {
            puVar31 = puVar38;
        }
        uVar22 = *puVar31;
        bVar47 = SBORROW4(iVar36, iVar39);
        iVar6 = iVar36 - iVar39;
        bVar49 = iVar36 == iVar39;
        if (bVar49) {
            iVar36 = *(int32_t *)((int64_t)puVar19 + 4);
            iVar39 = *(int32_t *)((int64_t)puVar38 + 4);
            bVar47 = SBORROW4(iVar39, iVar36);
            iVar6 = iVar39 - iVar36;
            bVar49 = iVar39 == iVar36;
        }
        puVar31 = puVar19;
        if (!bVar49 && bVar47 == iVar6 < 0) {
            puVar31 = puVar38;
        }
        uVar17 = *puVar31;
        uVar44 = (uint8_t)uVar46;
        if (uVar30 < 0x80) {
            var_120h = 1;
            var_184h._0_1_ = uVar44;
        } else {
            uVar24 = (uint8_t)(uVar30 >> 6);
            if (uVar30 < 0x800) {
                var_184h._0_1_ = uVar24 & 0x1f | 0xc0;
                var_184h._1_1_ = uVar44 & 0x3f | 0x80;
                var_120h = 2;
            } else {
                var_184h._0_1_ = (uint8_t)(uVar46 >> 8) >> 4 | 0xe0;
                var_184h._1_1_ = uVar24 & 0x3f | 0x80;
                var_120h = 3;
                var_184h._2_1_ = uVar44 & 0x3f | 0x80;
            }
        }
        var_128h = (int64_t)&var_184h;
        if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
            LOCK();
            piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_198h = (int64_t)&var_128h;
        var_170h = uVar22;
        var_e8h = uVar17;
        func_0x00018015bbd0(arg1, &var_138h, &var_158h, uVar17);
        func_0x00018015c690(arg1, puVar38, uVar22, var_138h);
        if (in_DX < 0x80) {
            var_184h._0_2_ = CONCAT11(var_184h._1_1_, uVar40);
            var_110h = 1;
        } else {
            uVar25 = (undefined)(in_DX >> 6);
            if (in_DX < 0x800) {
                var_184h._0_2_ = CONCAT11(uVar40, uVar25) & 0x3f1f | 0x80c0;
                var_110h = 2;
            } else {
                var_184h._0_2_ = CONCAT11(uVar25, uVar7 >> 4) & 0x3fff | 0x80e0;
                var_110h = 3;
                var_184h._2_1_ = uVar40 & 0x3f | 0x80;
            }
        }
        var_118h = (int64_t)&var_184h;
        if (CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) != 0) {
            LOCK();
            piVar1 = (int32_t *)(CONCAT44(var_f0h._4_4_, (undefined4)var_f0h) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_158h = CONCAT44(var_f8h._4_4_, (undefined4)var_f8h);
        var_150h._0_4_ = (undefined4)var_f0h;
        var_150h._4_4_ = var_f0h._4_4_;
        var_198h = (int64_t)&var_118h;
        func_0x00018015bbd0(arg1, &var_e0h, &var_158h, uVar22);
        func_0x00018015c690(arg1, puVar38, uVar22, var_e0h);
        *(int32_t *)puVar38 = (int32_t)uVar22;
        *(int32_t *)((int64_t)puVar38 + 4) = var_170h._4_4_ + 1;
        *(int32_t *)puVar19 = (int32_t)uVar17;
        *(int32_t *)((int64_t)puVar19 + 4) = var_e8h._4_4_ + 1;
        *(undefined *)((int64_t)puVar38 + 0x12) = 1;
    }
    puVar38 = (uint64_t *)((int64_t)puVar38 + 0x14);
    puVar19 = (uint64_t *)((int64_t)puVar19 + 0x14);
    goto code_r0x000180157910;
}

// ============================================================
// Function: FUN_180158bb0
// Address: 0x180158bb0
// Size: 496 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180158bb0(int64_t arg1, int64_t arg_40h)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char cVar7;
    undefined (*pauVar8) [16];
    int64_t *piVar9;
    undefined in_DL;
    int64_t iVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    bool bVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    pauVar8 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar8 = ZEXT816(0);
    *(undefined4 *)(*pauVar8 + 8) = 1;
    *(undefined4 *)(*pauVar8 + 0xc) = 1;
    *(undefined8 *)*pauVar8 = 0x180645d88;
    pauVar1 = pauVar8 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar8[2] = ZEXT816(0);
    pauVar8[3] = ZEXT816(0);
    pauVar8[4] = ZEXT816(0);
    pauVar8[5] = ZEXT816(0);
    pauVar8[6] = ZEXT816(0);
    *(undefined8 *)pauVar8[7] = 0;
    var_18h = (int64_t)pauVar8;
    func_0x0001801655b0(pauVar1);
    var_48h = (int64_t)pauVar1;
    var_40h = (int64_t)pauVar8;
    func_0x000180150230(pauVar8[2] + 8, arg1);
    piVar11 = *(int64_t **)arg1;
    piVar12 = piVar11 + 1;
    for (; piVar11 != *(int64_t **)(arg1 + 8); piVar11 = (int64_t *)((int64_t)piVar11 + 0x14)) {
        cVar7 = -1;
        if (*(int64_t **)(arg1 + 8) <= piVar11) {
            cVar7 = '\x01';
        }
        if (-1 < cVar7) break;
        iVar4 = *(int32_t *)piVar11;
        iVar3 = *(int32_t *)piVar12;
        bVar13 = SBORROW4(iVar4, iVar3);
        iVar6 = iVar4 - iVar3;
        if (iVar4 == iVar3) {
            iVar3 = *(int32_t *)((int64_t)piVar12 + 4);
            iVar4 = *(int32_t *)((int64_t)piVar11 + 4);
            bVar13 = SBORROW4(iVar4, iVar3);
            iVar6 = iVar4 - iVar3;
            if (iVar4 != iVar3) goto code_r0x000180158ca9;
            piVar9 = (int64_t *)func_0x00018015d830(arg1 + 0x40, &var_18h, *piVar12, in_DL);
            iVar10 = *piVar9;
        } else {
code_r0x000180158ca9:
            piVar9 = piVar12;
            if (bVar13 != iVar6 < 0) {
                piVar9 = piVar11;
            }
            iVar10 = *piVar9;
            var_20h = iVar10;
        }
        iVar4 = *(int32_t *)piVar11;
        iVar3 = *(int32_t *)piVar12;
        bVar14 = SBORROW4(iVar4, iVar3);
        iVar6 = iVar4 - iVar3;
        bVar13 = iVar4 == iVar3;
        if (bVar13) {
            iVar3 = *(int32_t *)((int64_t)piVar12 + 4);
            iVar4 = *(int32_t *)((int64_t)piVar11 + 4);
            bVar14 = SBORROW4(iVar4, iVar3);
            iVar6 = iVar4 - iVar3;
            bVar13 = iVar4 == iVar3;
        }
        piVar9 = piVar12;
        if (!bVar13 && bVar14 == iVar6 < 0) {
            piVar9 = piVar11;
        }
        iVar5 = *piVar9;
        LOCK();
        *(int32_t *)(*pauVar8 + 8) = *(int32_t *)(*pauVar8 + 8) + 1;
        UNLOCK();
        var_50h = (int64_t)pauVar8;
        var_58h = (int64_t)pauVar1;
        func_0x00018015bca0(arg1, &var_58h, iVar10, iVar5);
        *piVar11 = iVar10;
        piVar11[1] = iVar10;
        *(undefined *)((int64_t)piVar11 + 0x12) = 1;
        func_0x00018015c720(arg1, piVar11, iVar10, iVar5);
        piVar12 = (int64_t *)((int64_t)piVar12 + 0x14);
    }
    LOCK();
    *(int32_t *)(*pauVar8 + 8) = *(int32_t *)(*pauVar8 + 8) + 1;
    UNLOCK();
    var_50h = (int64_t)pauVar8;
    var_58h = (int64_t)pauVar1;
    func_0x00018015af60(arg1, &var_58h);
    LOCK();
    piVar2 = (int32_t *)(*pauVar8 + 8);
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
        (***(code ***)*pauVar8)(pauVar8);
        LOCK();
        piVar2 = (int32_t *)(*pauVar8 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*(int64_t *)*pauVar8 + 8))(pauVar8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180158da0
// Address: 0x180158da0
// Size: 495 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.180158da0(int64_t arg1, int64_t arg_40h)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    int64_t iVar5;
    int32_t iVar6;
    char cVar7;
    undefined (*pauVar8) [16];
    int64_t *piVar9;
    undefined in_DL;
    int64_t *piVar10;
    int64_t iVar11;
    int64_t *piVar12;
    bool bVar13;
    bool bVar14;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    
    pauVar8 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar8 = ZEXT816(0);
    *(undefined4 *)(*pauVar8 + 8) = 1;
    *(undefined4 *)(*pauVar8 + 0xc) = 1;
    *(undefined8 *)*pauVar8 = 0x180645d88;
    pauVar1 = pauVar8 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar8[2] = ZEXT816(0);
    pauVar8[3] = ZEXT816(0);
    pauVar8[4] = ZEXT816(0);
    pauVar8[5] = ZEXT816(0);
    pauVar8[6] = ZEXT816(0);
    *(undefined8 *)pauVar8[7] = 0;
    var_18h = (int64_t)pauVar8;
    func_0x0001801655b0(pauVar1);
    var_48h = (int64_t)pauVar1;
    var_40h = (int64_t)pauVar8;
    func_0x000180150230(pauVar8[2] + 8, arg1);
    piVar10 = *(int64_t **)arg1;
    piVar12 = piVar10 + 1;
    for (; piVar10 != *(int64_t **)(arg1 + 8); piVar10 = (int64_t *)((int64_t)piVar10 + 0x14)) {
        cVar7 = -1;
        if (*(int64_t **)(arg1 + 8) <= piVar10) {
            cVar7 = '\x01';
        }
        if (-1 < cVar7) break;
        iVar3 = *(int32_t *)piVar10;
        iVar4 = *(int32_t *)piVar12;
        bVar13 = SBORROW4(iVar3, iVar4);
        iVar6 = iVar3 - iVar4;
        if (iVar3 == iVar4) {
            bVar13 = SBORROW4(*(int32_t *)((int64_t)piVar10 + 4), *(int32_t *)((int64_t)piVar12 + 4));
            iVar6 = *(int32_t *)((int64_t)piVar10 + 4) - *(int32_t *)((int64_t)piVar12 + 4);
        }
        piVar9 = piVar12;
        if (bVar13 != iVar6 < 0) {
            piVar9 = piVar10;
        }
        iVar5 = *piVar9;
        bVar14 = SBORROW4(iVar3, iVar4);
        iVar6 = iVar3 - iVar4;
        bVar13 = iVar3 == iVar4;
        if (bVar13) {
            iVar3 = *(int32_t *)((int64_t)piVar12 + 4);
            iVar4 = *(int32_t *)((int64_t)piVar10 + 4);
            bVar14 = SBORROW4(iVar4, iVar3);
            iVar6 = iVar4 - iVar3;
            bVar13 = iVar4 == iVar3;
            if (!bVar13) goto code_r0x000180158eb3;
            piVar9 = (int64_t *)func_0x00018015d9c0(arg1 + 0x40, &var_18h, *piVar12, in_DL);
            iVar11 = *piVar9;
        } else {
code_r0x000180158eb3:
            piVar9 = piVar12;
            if (!bVar13 && bVar14 == iVar6 < 0) {
                piVar9 = piVar10;
            }
            iVar11 = *piVar9;
            var_20h = iVar11;
        }
        LOCK();
        *(int32_t *)(*pauVar8 + 8) = *(int32_t *)(*pauVar8 + 8) + 1;
        UNLOCK();
        var_50h = (int64_t)pauVar8;
        var_58h = (int64_t)pauVar1;
        func_0x00018015bca0(arg1, &var_58h, iVar5, iVar11);
        *piVar10 = iVar5;
        piVar10[1] = iVar5;
        *(undefined *)((int64_t)piVar10 + 0x12) = 1;
        func_0x00018015c720(arg1, piVar10, iVar5, iVar11);
        piVar12 = (int64_t *)((int64_t)piVar12 + 0x14);
    }
    LOCK();
    *(int32_t *)(*pauVar8 + 8) = *(int32_t *)(*pauVar8 + 8) + 1;
    UNLOCK();
    var_50h = (int64_t)pauVar8;
    var_58h = (int64_t)pauVar1;
    func_0x00018015af60(arg1, &var_58h);
    LOCK();
    piVar2 = (int32_t *)(*pauVar8 + 8);
    iVar3 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar3 == 1) {
        (***(code ***)*pauVar8)(pauVar8);
        LOCK();
        piVar2 = (int32_t *)(*pauVar8 + 0xc);
        iVar3 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)(*(int64_t *)*pauVar8 + 8))(pauVar8);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180158f90
// Address: 0x180158f90
// Size: 629 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_14h
// WARNING: [rz-ghidra] Variable var_1h extends beyond the stackframe. Try changing its type to something smaller.

void fcn.180158f90(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    uint32_t uVar3;
    uint32_t uVar4;
    int32_t iVar5;
    code *pcVar6;
    undefined8 uVar7;
    char cVar8;
    uint32_t uVar9;
    int32_t iVar10;
    undefined (*pauVar11) [16];
    uint64_t uVar12;
    int64_t iVar13;
    int32_t iVar14;
    uint64_t *puVar15;
    uint64_t uVar16;
    uint64_t uVar17;
    uint64_t *puVar18;
    int64_t *piVar19;
    bool bVar20;
    bool bVar21;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    int64_t var_50h;
    
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar11 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar11 = ZEXT816(0);
    *(undefined4 *)(*pauVar11 + 8) = 1;
    *(undefined4 *)(*pauVar11 + 0xc) = 1;
    *(undefined8 *)*pauVar11 = 0x180645d88;
    pauVar1 = pauVar11 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar11[2] = ZEXT816(0);
    pauVar11[3] = ZEXT816(0);
    pauVar11[4] = ZEXT816(0);
    pauVar11[5] = ZEXT816(0);
    pauVar11[6] = ZEXT816(0);
    *(undefined8 *)pauVar11[7] = 0;
    func_0x0001801655b0(pauVar1);
    var_58h = (int64_t)pauVar1;
    var_50h = (int64_t)pauVar11;
    func_0x000180150230(pauVar11[2] + 8, arg1);
    puVar18 = *(uint64_t **)arg1;
    while( true ) {
        if (puVar18 == *(uint64_t **)(arg1 + 8)) break;
        cVar8 = -1;
        if (*(uint64_t **)(arg1 + 8) <= puVar18) {
            cVar8 = '\x01';
        }
        if (-1 < cVar8) break;
        uVar3 = *(uint32_t *)puVar18;
        uVar4 = *(uint32_t *)(puVar18 + 1);
        bVar20 = SBORROW4(uVar3, uVar4);
        iVar10 = uVar3 - uVar4;
        if (uVar3 == uVar4) {
            bVar20 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)((int64_t)puVar18 + 0xc));
            iVar10 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)((int64_t)puVar18 + 0xc);
        }
        uVar9 = uVar4;
        if (bVar20 != iVar10 < 0) {
            uVar9 = uVar3;
        }
        bVar21 = SBORROW4(uVar3, uVar4);
        iVar10 = uVar3 - uVar4;
        bVar20 = uVar3 == uVar4;
        if (bVar20) {
            iVar14 = *(int32_t *)((int64_t)puVar18 + 0xc);
            iVar5 = *(int32_t *)((int64_t)puVar18 + 4);
            bVar21 = SBORROW4(iVar5, iVar14);
            iVar10 = iVar5 - iVar14;
            bVar20 = iVar5 == iVar14;
        }
        puVar15 = puVar18 + 1;
        if (!bVar20 && bVar21 == iVar10 < 0) {
            puVar15 = puVar18;
        }
        uVar16 = *puVar15;
        iVar10 = (int32_t)(uVar16 >> 0x20);
        if (iVar10 != 0) {
            iVar14 = (int32_t)uVar16;
            uVar12 = (uint64_t)iVar14;
            uVar17 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
            if (uVar17 < uVar12 || uVar17 - uVar12 == 0) {
                func_0x000180060370();
                pcVar6 = (code *)swi(3);
                (*pcVar6)();
                return;
            }
            piVar19 = (int64_t *)(uVar12 * 0x38 + *(int64_t *)(arg1 + 0x40));
            iVar10 = *(int32_t *)(piVar19 + 5);
            iVar13 = func_0x00018015d7b0(arg1 + 0x40, piVar19);
            if (iVar13 == piVar19[1] - *piVar19 >> 2) {
                if (iVar14 < (int32_t)uVar17 + -1) {
                    uVar16 = (uint64_t)(iVar14 + 1);
                    iVar10 = 0;
                }
            } else {
                iVar10 = func_0x000180150020(arg1 + 0x40, uVar16 & 0xffffffff, iVar13 + 1);
            }
        }
        uVar7 = CONCAT44(iVar10, (int32_t)uVar16);
        LOCK();
        *(int32_t *)(*pauVar11 + 8) = *(int32_t *)(*pauVar11 + 8) + 1;
        UNLOCK();
        var_60h = (int64_t)pauVar11;
        var_68h = (int64_t)(pauVar11 + 1);
        uVar16 = (uint64_t)uVar9;
        func_0x00018015bca0(arg1, &var_68h, uVar16, uVar7);
        *puVar18 = uVar16;
        puVar18[1] = uVar16;
        *(undefined *)((int64_t)puVar18 + 0x12) = 1;
        func_0x00018015c720(arg1, puVar18, uVar16, uVar7);
        puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
    }
    LOCK();
    *(int32_t *)(*pauVar11 + 8) = *(int32_t *)(*pauVar11 + 8) + 1;
    UNLOCK();
    var_60h = (int64_t)pauVar11;
    var_68h = (int64_t)(pauVar11 + 1);
    func_0x00018015af60(arg1, &var_68h);
    LOCK();
    piVar2 = (int32_t *)(*pauVar11 + 8);
    iVar10 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar10 == 1) {
        (***(code ***)*pauVar11)(pauVar11);
        LOCK();
        piVar2 = (int32_t *)(*pauVar11 + 0xc);
        iVar10 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar10 == 1) {
            (**(code **)(*(int64_t *)*pauVar11 + 8))(pauVar11);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180159210
// Address: 0x180159210
// Size: 699 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180159210(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    uint32_t uVar3;
    int32_t iVar4;
    uint32_t uVar5;
    int32_t iVar6;
    int64_t iVar7;
    char cVar8;
    undefined (*pauVar9) [16];
    int64_t *piVar10;
    int64_t *piVar11;
    int64_t *piVar12;
    bool bVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int32_t var_20h;
    int32_t var_24h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    
    var_10h._0_4_ = 0;
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar9 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar9 = ZEXT816(0);
    *(undefined4 *)(*pauVar9 + 8) = 1;
    *(undefined4 *)(*pauVar9 + 0xc) = 1;
    *(undefined8 *)*pauVar9 = 0x180645d88;
    pauVar1 = pauVar9 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar9[2] = ZEXT816(0);
    pauVar9[3] = ZEXT816(0);
    pauVar9[4] = ZEXT816(0);
    pauVar9[5] = ZEXT816(0);
    pauVar9[6] = ZEXT816(0);
    *(undefined8 *)pauVar9[7] = 0;
    var_8h = (int64_t)pauVar9;
    func_0x0001801655b0(pauVar1);
    var_10h._0_4_ = 7;
    var_68h = (int64_t)pauVar1;
    var_60h = (int64_t)pauVar9;
    func_0x000180150230(pauVar9[2] + 8, arg1);
    piVar11 = *(int64_t **)arg1;
    piVar12 = piVar11 + 1;
    while( true ) {
        var_90h = (int64_t)(pauVar9 + 1);
        if (piVar11 == *(int64_t **)(arg1 + 8)) break;
        cVar8 = -1;
        if (*(int64_t **)(arg1 + 8) <= piVar11) {
            cVar8 = '\x01';
        }
        if (-1 < cVar8) break;
        uVar5 = *(uint32_t *)piVar11;
        uVar3 = *(uint32_t *)piVar12;
        bVar13 = SBORROW4(uVar5, uVar3);
        iVar6 = uVar5 - uVar3;
        if (uVar5 == uVar3) {
            bVar13 = SBORROW4(*(uint32_t *)((int64_t)piVar11 + 4), *(uint32_t *)((int64_t)piVar12 + 4));
            iVar6 = *(uint32_t *)((int64_t)piVar11 + 4) - *(uint32_t *)((int64_t)piVar12 + 4);
        }
        piVar10 = piVar12;
        if (bVar13 != iVar6 < 0) {
            piVar10 = piVar11;
        }
        uVar3 = *(uint32_t *)piVar10;
        var_78h = 0x1805ab2a0;
        var_70h = 1;
        var_18h._4_4_ = 0;
        LOCK();
        *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
        UNLOCK();
        var_98h = (int64_t)&var_90h;
        var_18h._0_4_ = uVar3;
        var_88h = (int64_t)pauVar9;
        func_0x00018015c7f0(arg1 + 0x40, &var_20h, (uint64_t)uVar3, &var_78h);
        iVar6 = var_20h;
        var_58h._0_4_ = (undefined4)var_78h;
        var_58h._4_4_ = var_78h._4_4_;
        uStack_50 = (undefined4)var_70h;
        uStack_4c = var_70h._4_4_;
        var_8h = var_8h & 0xffffffffffffff00;
        var_a0h = (uint64_t)uVar3;
        func_0x0001801633e0(var_90h, &var_8h, &var_a0h, &var_a8h, &var_58h);
        iVar7 = var_88h;
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        if (var_88h != 0) {
            LOCK();
            piVar2 = (int32_t *)(var_88h + 8);
            iVar4 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                (***(code ***)var_88h)(var_88h);
                LOCK();
                piVar2 = (int32_t *)(iVar7 + 0xc);
                iVar4 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                    (**(code **)(*(int64_t *)iVar7 + 8))(iVar7);
                }
            }
        }
        *(uint32_t *)piVar11 = uVar3;
        *(uint32_t *)((int64_t)piVar11 + 4) = 0;
        *(uint32_t *)piVar12 = uVar3;
        *(uint32_t *)((int64_t)piVar12 + 4) = 0;
        *(undefined *)((int64_t)piVar11 + 0x12) = 1;
        piVar11 = (int64_t *)((int64_t)piVar11 + 0x14);
        for (piVar10 = piVar11; piVar10 != *(int64_t **)(arg1 + 8); piVar10 = (int64_t *)((int64_t)piVar10 + 0x14)) {
            cVar8 = -1;
            if (*(int64_t **)(arg1 + 8) <= piVar10) {
                cVar8 = '\x01';
            }
            if (-1 < cVar8) break;
            var_8h = *piVar10;
            if ((uint32_t)var_8h == uVar3) {
                var_8h = CONCAT44((int32_t)((uint64_t)var_8h >> 0x20) + var_24h, (uint32_t)var_8h);
            }
            var_8h = CONCAT44(var_8h._4_4_, (int32_t)var_8h + (iVar6 - uVar3));
            *piVar10 = var_8h;
            var_8h = piVar10[1];
            if ((uint32_t)var_8h == uVar3) {
                var_8h = CONCAT44((int32_t)((uint64_t)var_8h >> 0x20) + var_24h, (uint32_t)var_8h);
            }
            var_8h = CONCAT44(var_8h._4_4_, (int32_t)var_8h + (iVar6 - uVar3));
            piVar10[1] = var_8h;
        }
        piVar12 = (int64_t *)((int64_t)piVar12 + 0x14);
    }
    LOCK();
    *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
    UNLOCK();
    var_88h = (int64_t)pauVar9;
    func_0x00018015af60(arg1, &var_90h);
    LOCK();
    piVar2 = (int32_t *)(*pauVar9 + 8);
    iVar6 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar6 == 1) {
        (***(code ***)*pauVar9)(pauVar9);
        LOCK();
        piVar2 = (int32_t *)(*pauVar9 + 0xc);
        iVar6 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar6 == 1) {
            (**(code **)(*(int64_t *)*pauVar9 + 8))(pauVar9);
        }
    }
    return;
}

// ============================================================
// Function: FUN_1801594d0
// Address: 0x1801594d0
// Size: 853 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_c8h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_20h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.1801594d0(int64_t arg1)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    code *pcVar4;
    char cVar5;
    int32_t iVar6;
    undefined (*pauVar7) [16];
    uint64_t uVar8;
    int64_t iVar9;
    uint64_t *puVar10;
    uint64_t *puVar11;
    undefined (*pauVar12) [16];
    uint64_t uVar13;
    int64_t *piVar14;
    int32_t iVar15;
    int32_t iVar16;
    uint64_t uVar17;
    bool bVar18;
    bool bVar19;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int32_t var_20h;
    int32_t var_24h;
    int64_t var_c8h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    
    var_10h._0_4_ = 0;
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar7 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar7 = ZEXT816(0);
    *(undefined4 *)(*pauVar7 + 8) = 1;
    *(undefined4 *)(*pauVar7 + 0xc) = 1;
    *(undefined8 *)*pauVar7 = 0x180645d88;
    pauVar12 = pauVar7 + 1;
    *pauVar12 = ZEXT816(0);
    pauVar7[2] = ZEXT816(0);
    pauVar7[3] = ZEXT816(0);
    pauVar7[4] = ZEXT816(0);
    pauVar7[5] = ZEXT816(0);
    pauVar7[6] = ZEXT816(0);
    *(undefined8 *)pauVar7[7] = 0;
    var_a8h = (int64_t)pauVar7;
    var_a0h = (int64_t)pauVar12;
    func_0x0001801655b0(pauVar12);
    var_10h._0_4_ = 7;
    var_70h = (int64_t)pauVar12;
    var_68h = (int64_t)pauVar7;
    func_0x000180150230(pauVar7[2] + 8, arg1);
    puVar11 = *(uint64_t **)arg1;
    do {
        if (puVar11 == *(uint64_t **)(arg1 + 8)) {
code_r0x0001801597be:
            LOCK();
            *(int32_t *)(*pauVar7 + 8) = *(int32_t *)(*pauVar7 + 8) + 1;
            UNLOCK();
            var_b0h = (int64_t)pauVar7;
            var_b8h = (int64_t)pauVar12;
            func_0x00018015af60(arg1, &var_b8h);
            LOCK();
            piVar2 = (int32_t *)(*pauVar7 + 8);
            iVar6 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar6 == 1) {
                (***(code ***)*pauVar7)(pauVar7);
                LOCK();
                piVar2 = (int32_t *)(*pauVar7 + 0xc);
                iVar6 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar6 == 1) {
                    (**(code **)(*(int64_t *)*pauVar7 + 8))(pauVar7);
                }
            }
            return;
        }
        cVar5 = -1;
        if (*(uint64_t **)(arg1 + 8) <= puVar11) {
            cVar5 = '\x01';
        }
        if (-1 < cVar5) goto code_r0x0001801597be;
        iVar15 = *(int32_t *)puVar11;
        iVar6 = *(int32_t *)(puVar11 + 1);
        bVar19 = SBORROW4(iVar15, iVar6);
        iVar16 = iVar15 - iVar6;
        bVar18 = iVar15 == iVar6;
        if (bVar18) {
            iVar6 = *(int32_t *)((int64_t)puVar11 + 0xc);
            iVar15 = *(int32_t *)((int64_t)puVar11 + 4);
            bVar19 = SBORROW4(iVar15, iVar6);
            iVar16 = iVar15 - iVar6;
            bVar18 = iVar15 == iVar6;
        }
        puVar10 = puVar11 + 1;
        if (!bVar18 && bVar19 == iVar16 < 0) {
            puVar10 = puVar11;
        }
        uVar17 = *puVar10;
        piVar1 = (int64_t *)(arg1 + 0x40);
        iVar6 = (int32_t)(uVar17 >> 0x20);
        if (iVar6 != 0) {
            iVar15 = (int32_t)uVar17;
            uVar8 = (uint64_t)iVar15;
            uVar13 = (*(int64_t *)(arg1 + 0x48) - *piVar1 >> 3) * 0x6db6db6db6db6db7;
            if (uVar13 < uVar8 || uVar13 - uVar8 == 0) {
                func_0x000180060370();
                pcVar4 = (code *)swi(3);
                (*pcVar4)();
                return;
            }
            piVar14 = (int64_t *)(uVar8 * 0x38 + *piVar1);
            iVar6 = *(int32_t *)(piVar14 + 5);
            iVar9 = func_0x00018015d7b0(piVar1, piVar14);
            if (iVar9 == piVar14[1] - *piVar14 >> 2) {
                pauVar12 = (undefined (*) [16])var_a0h;
                pauVar7 = (undefined (*) [16])var_a8h;
                if (iVar15 < (int32_t)uVar13 + -1) {
                    uVar17 = (uint64_t)(iVar15 + 1);
                    iVar6 = 0;
                }
            } else {
                iVar6 = func_0x000180150020(piVar1, uVar17 & 0xffffffff, iVar9 + 1);
                pauVar12 = (undefined (*) [16])var_a0h;
                pauVar7 = (undefined (*) [16])var_a8h;
            }
        }
        iVar16 = (int32_t)uVar17;
        var_88h = 0x1805ab2a0;
        var_80h = 1;
        LOCK();
        *(int32_t *)(*pauVar7 + 8) = *(int32_t *)(*pauVar7 + 8) + 1;
        UNLOCK();
        var_b0h = (int64_t)pauVar7;
        var_b8h = (int64_t)pauVar12;
        var_78h = (int64_t)&var_b8h;
        uVar17 = CONCAT44(iVar6, iVar16);
        var_18h._0_4_ = iVar16;
        var_18h._4_4_ = iVar6;
        func_0x00018015c7f0(piVar1, &var_20h, uVar17, &var_88h);
        iVar15 = var_20h;
        var_58h._0_4_ = (undefined4)var_88h;
        var_58h._4_4_ = var_88h._4_4_;
        uStack_50 = (undefined4)var_80h;
        uStack_4c = var_80h._4_4_;
        var_8h = var_8h & 0xffffffffffffff00;
        var_90h = uVar17;
        func_0x0001801633e0(var_b8h, &var_8h, &var_90h, &var_98h, &var_58h);
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        iVar9 = var_b0h;
        if (var_b0h != 0) {
            LOCK();
            piVar2 = (int32_t *)(var_b0h + 8);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (***(code ***)var_b0h)(var_b0h);
                LOCK();
                piVar2 = (int32_t *)(iVar9 + 0xc);
                iVar3 = *piVar2;
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)(*(int64_t *)iVar9 + 8))(iVar9);
                }
            }
        }
        *puVar11 = uVar17;
        puVar11[1] = uVar17;
        *(undefined *)((int64_t)puVar11 + 0x12) = 1;
        puVar11 = (uint64_t *)((int64_t)puVar11 + 0x14);
        for (puVar10 = puVar11; pauVar12 = (undefined (*) [16])var_a0h, pauVar7 = (undefined (*) [16])var_a8h,
            puVar10 != *(uint64_t **)(arg1 + 8); puVar10 = (uint64_t *)((int64_t)puVar10 + 0x14)) {
            cVar5 = -1;
            if (*(uint64_t **)(arg1 + 8) <= puVar10) {
                cVar5 = '\x01';
            }
            if (-1 < cVar5) break;
            var_8h = *puVar10;
            if ((int32_t)var_8h == iVar16) {
                var_8h = CONCAT44(((int32_t)((uint64_t)var_8h >> 0x20) - iVar6) + var_24h, (int32_t)var_8h);
            }
            var_8h = CONCAT44(var_8h._4_4_, (int32_t)var_8h + (iVar15 - iVar16));
            *puVar10 = var_8h;
            var_8h = puVar10[1];
            if ((int32_t)var_8h == iVar16) {
                var_8h = CONCAT44(((int32_t)((uint64_t)var_8h >> 0x20) - iVar6) + var_24h, (int32_t)var_8h);
            }
            var_8h = CONCAT44(var_8h._4_4_, (int32_t)var_8h + (iVar15 - iVar16));
            puVar10[1] = var_8h;
        }
    } while( true );
}

// ============================================================
// Function: FUN_180159830
// Address: 0x180159830
// Size: 852 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_e8h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_c0h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch
// WARNING: [rz-ghidra] Detected overlap for variable var_ch

void fcn.180159830(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    uint64_t uVar4;
    uint64_t uVar5;
    int64_t iVar6;
    char cVar7;
    int32_t iVar8;
    undefined (*pauVar9) [16];
    uint64_t *puVar10;
    uint64_t *puVar11;
    uint32_t uVar12;
    uint64_t *puVar13;
    undefined (*pauVar14) [16];
    uint32_t uVar15;
    bool bVar17;
    bool bVar18;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_e8h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int32_t var_c0h;
    int32_t var_bch;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    uint64_t uVar16;
    
    var_10h._0_4_ = 0;
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar9 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar9 = ZEXT816(0);
    *(undefined4 *)(*pauVar9 + 8) = 1;
    *(undefined4 *)(*pauVar9 + 0xc) = 1;
    *(undefined8 *)*pauVar9 = 0x180645d88;
    pauVar14 = pauVar9 + 1;
    *pauVar14 = ZEXT816(0);
    pauVar9[2] = ZEXT816(0);
    pauVar9[3] = ZEXT816(0);
    pauVar9[4] = ZEXT816(0);
    pauVar9[5] = ZEXT816(0);
    pauVar9[6] = ZEXT816(0);
    *(undefined8 *)pauVar9[7] = 0;
    var_a0h = (int64_t)pauVar9;
    var_98h = (int64_t)pauVar14;
    func_0x0001801655b0(pauVar14);
    var_10h._0_4_ = 7;
    var_70h = (int64_t)pauVar14;
    var_68h = (int64_t)pauVar9;
    func_0x000180150230(pauVar9[2] + 8, arg1);
    puVar13 = *(uint64_t **)arg1;
    var_b8h = (int64_t)(puVar13 + 1);
    for (; puVar13 != *(uint64_t **)(arg1 + 8); puVar13 = (uint64_t *)((int64_t)puVar13 + 0x14)) {
        cVar7 = -1;
        if (*(uint64_t **)(arg1 + 8) <= puVar13) {
            cVar7 = '\x01';
        }
        if (-1 < cVar7) break;
        iVar8 = *(int32_t *)puVar13;
        iVar2 = *(int32_t *)var_b8h;
        bVar17 = SBORROW4(iVar8, iVar2);
        iVar3 = iVar8 - iVar2;
        if (iVar8 == iVar2) {
            bVar17 = SBORROW4(*(int32_t *)((int64_t)puVar13 + 4), *(int32_t *)(var_b8h + 4));
            iVar3 = *(int32_t *)((int64_t)puVar13 + 4) - *(int32_t *)(var_b8h + 4);
        }
        puVar10 = (uint64_t *)var_b8h;
        if (bVar17 != iVar3 < 0) {
            puVar10 = puVar13;
        }
        uVar16 = *puVar10;
        bVar18 = SBORROW4(iVar8, iVar2);
        iVar3 = iVar8 - iVar2;
        bVar17 = iVar8 == iVar2;
        if (bVar17) {
            iVar8 = *(int32_t *)(var_b8h + 4);
            iVar2 = *(int32_t *)((int64_t)puVar13 + 4);
            bVar18 = SBORROW4(iVar2, iVar8);
            iVar3 = iVar2 - iVar8;
            bVar17 = iVar2 == iVar8;
        }
        puVar10 = (uint64_t *)var_b8h;
        if (!bVar17 && bVar18 == iVar3 < 0) {
            puVar10 = puVar13;
        }
        uVar12 = (uint32_t)*puVar10;
        uVar15 = (uint32_t)uVar16;
        uVar4 = uVar16;
        uVar5 = *puVar10;
        while (var_18h._4_4_ = (int32_t)(uVar5 >> 0x20), (int32_t)uVar15 <= (int32_t)uVar12) {
            iVar8 = (int32_t)uVar16;
            var_18h = uVar5;
            var_20h = uVar4;
            if (((uVar15 != uVar12) || (bVar17 = var_18h._4_4_ != 0, bVar17)) &&
               (*(int64_t *)((int64_t)iVar8 * 0x38 + 8 + *(int64_t *)(arg1 + 0x40)) !=
                *(int64_t *)((int64_t)iVar8 * 0x38 + *(int64_t *)(arg1 + 0x40)))) {
                var_88h = 0x18063dad4;
                var_80h = 1;
                var_c8h._4_4_ = 0;
                LOCK();
                *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
                UNLOCK();
                var_78h = (int64_t)&var_d8h;
                var_c8h._0_4_ = iVar8;
                var_d8h = (int64_t)pauVar14;
                var_d0h = (int64_t)pauVar9;
                func_0x00018015c7f0(arg1 + 0x40, &var_c0h, uVar16 & 0xffffffff, &var_88h);
                iVar2 = var_c0h;
                var_58h._0_4_ = (undefined4)var_88h;
                var_58h._4_4_ = var_88h._4_4_;
                uStack_50 = (undefined4)var_80h;
                uStack_4c = var_80h._4_4_;
                var_8h = var_8h & 0xffffffffffffff00;
                var_a8h = uVar16 & 0xffffffff;
                func_0x0001801633e0(var_d8h, &var_8h, &var_a8h, &var_b0h, &var_58h);
                iVar6 = var_d0h;
                *(undefined *)(arg1 + 0x2c8) = 1;
                *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
                puVar10 = puVar13;
                if (var_d0h != 0) {
                    LOCK();
                    piVar1 = (int32_t *)(var_d0h + 8);
                    iVar3 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (***(code ***)var_d0h)();
                        LOCK();
                        piVar1 = (int32_t *)(iVar6 + 0xc);
                        iVar3 = *piVar1;
                        *piVar1 = *piVar1 + -1;
                        UNLOCK();
                        if (iVar3 == 1) {
                            (**(code **)(*(int64_t *)iVar6 + 8))();
                        }
                    }
                }
                while( true ) {
                    puVar11 = (uint64_t *)((int64_t)puVar10 + 0x14);
                    pauVar9 = (undefined (*) [16])var_a0h;
                    pauVar14 = (undefined (*) [16])var_98h;
                    if (puVar11 == *(uint64_t **)(arg1 + 8)) break;
                    cVar7 = -1;
                    if (*(uint64_t **)(arg1 + 8) <= puVar11) {
                        cVar7 = '\x01';
                    }
                    if (-1 < cVar7) break;
                    var_8h = *puVar11;
                    if ((int32_t)var_8h == iVar8) {
                        var_8h = CONCAT44((int32_t)((uint64_t)var_8h >> 0x20) + var_bch, (int32_t)var_8h);
                    }
                    var_8h = CONCAT44(var_8h._4_4_, (int32_t)var_8h + (iVar2 - iVar8));
                    *puVar11 = var_8h;
                    var_8h = *(int64_t *)((int64_t)puVar10 + 0x1c);
                    if ((int32_t)var_8h == iVar8) {
                        var_8h = CONCAT44((int32_t)((uint64_t)var_8h >> 0x20) + var_bch, (int32_t)var_8h);
                    }
                    var_8h = CONCAT44(var_8h._4_4_, (int32_t)var_8h + (iVar2 - iVar8));
                    *(int64_t *)((int64_t)puVar10 + 0x1c) = var_8h;
                    puVar10 = puVar11;
                }
            }
            uVar15 = iVar8 + 1;
            uVar16 = (uint64_t)uVar15;
            uVar4 = var_20h;
            uVar5 = var_18h;
        }
        var_20h._4_4_ = (int32_t)(uVar4 >> 0x20);
        iVar8 = 0;
        if (var_20h._4_4_ != 0) {
            iVar8 = *(int32_t *)(arg1 + 0x58);
        }
        var_20h = CONCAT44(var_20h._4_4_ + iVar8, (int32_t)uVar4);
        iVar8 = 0;
        if (var_18h._4_4_ != 0) {
            iVar8 = *(int32_t *)(arg1 + 0x58);
        }
        var_18h = CONCAT44(var_18h._4_4_ + iVar8, (int32_t)uVar5);
        *puVar13 = var_20h;
        puVar13[1] = var_18h;
        *(undefined *)((int64_t)puVar13 + 0x12) = 1;
        var_b8h = var_b8h + 0x14;
    }
    LOCK();
    *(int32_t *)(*pauVar9 + 8) = *(int32_t *)(*pauVar9 + 8) + 1;
    UNLOCK();
    var_d0h = (int64_t)pauVar9;
    var_d8h = (int64_t)pauVar14;
    func_0x00018015af60(arg1, &var_d8h);
    LOCK();
    piVar1 = (int32_t *)(*pauVar9 + 8);
    iVar8 = *piVar1;
    *piVar1 = *piVar1 + -1;
    UNLOCK();
    if (iVar8 == 1) {
        (***(code ***)*pauVar9)(pauVar9);
        LOCK();
        piVar1 = (int32_t *)(*pauVar9 + 0xc);
        iVar8 = *piVar1;
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (iVar8 == 1) {
            (**(code **)(*(int64_t *)*pauVar9 + 8))(pauVar9);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180159b90
// Address: 0x180159b90
// Size: 776 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_24h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_4h

void fcn.180159b90(int64_t arg1)
{
    undefined (*pauVar1) [16];
    int32_t *piVar2;
    int16_t *piVar3;
    int32_t iVar4;
    uint64_t uVar5;
    int64_t iVar6;
    code *pcVar7;
    char cVar8;
    int32_t iVar9;
    undefined (*pauVar10) [16];
    uint64_t *puVar11;
    uint64_t uVar12;
    int16_t *piVar13;
    uint64_t uVar14;
    uint64_t *puVar15;
    uint64_t *puVar16;
    int32_t iVar17;
    uint64_t uVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t iVar22;
    bool bVar23;
    bool bVar24;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    uint64_t uVar21;
    
    if (*(char *)(arg1 + 0x131) != '\0') {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar10 = (undefined (*) [16])func_0x000180459890(0x78);
    *pauVar10 = ZEXT816(0);
    *(undefined4 *)(*pauVar10 + 8) = 1;
    *(undefined4 *)(*pauVar10 + 0xc) = 1;
    *(undefined8 *)*pauVar10 = 0x180645d88;
    pauVar1 = pauVar10 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar10[2] = ZEXT816(0);
    pauVar10[3] = ZEXT816(0);
    pauVar10[4] = ZEXT816(0);
    pauVar10[5] = ZEXT816(0);
    pauVar10[6] = ZEXT816(0);
    *(undefined8 *)pauVar10[7] = 0;
    func_0x0001801655b0(pauVar1);
    var_60h = (int64_t)pauVar1;
    var_58h = (int64_t)pauVar10;
    func_0x000180150230(pauVar10[2] + 8, arg1);
    for (puVar16 = *(uint64_t **)arg1; puVar16 != *(uint64_t **)(arg1 + 8);
        puVar16 = (uint64_t *)((int64_t)puVar16 + 0x14)) {
        cVar8 = -1;
        if (*(uint64_t **)(arg1 + 8) <= puVar16) {
            cVar8 = '\x01';
        }
        if (-1 < cVar8) break;
        puVar15 = puVar16 + 1;
        iVar4 = *(int32_t *)puVar16;
        iVar17 = *(int32_t *)puVar15;
        bVar23 = SBORROW4(iVar4, iVar17);
        iVar19 = iVar4 - iVar17;
        if (iVar4 == iVar17) {
            bVar23 = SBORROW4(*(int32_t *)((int64_t)puVar16 + 4), *(int32_t *)((int64_t)puVar16 + 0xc));
            iVar19 = *(int32_t *)((int64_t)puVar16 + 4) - *(int32_t *)((int64_t)puVar16 + 0xc);
        }
        puVar11 = puVar15;
        if (bVar23 != iVar19 < 0) {
            puVar11 = puVar16;
        }
        uVar21 = *puVar11;
        bVar24 = SBORROW4(iVar4, iVar17);
        iVar19 = iVar4 - iVar17;
        bVar23 = iVar4 == iVar17;
        if (bVar23) {
            iVar4 = *(int32_t *)((int64_t)puVar16 + 0xc);
            iVar17 = *(int32_t *)((int64_t)puVar16 + 4);
            bVar24 = SBORROW4(iVar17, iVar4);
            iVar19 = iVar17 - iVar4;
            bVar23 = iVar17 == iVar4;
        }
        if (!bVar23 && bVar24 == iVar19 < 0) {
            puVar15 = puVar16;
        }
        uVar5 = *puVar15;
        iVar4 = *(int32_t *)(arg1 + 0x58);
        uVar20 = (uint32_t)uVar21;
        while ((int32_t)uVar20 <= (int32_t)uVar5) {
            iVar17 = 0;
            uVar14 = 0;
            iVar19 = (int32_t)uVar21;
            uVar18 = (uint64_t)iVar19;
            iVar22 = uVar18 * 0x38;
            do {
                iVar6 = *(int64_t *)(arg1 + 0x40);
                if (((uint64_t)(*(int64_t *)(iVar6 + 8 + iVar22) - *(int64_t *)(iVar6 + iVar22) >> 2) <= uVar14) ||
                   (iVar9 = func_0x00018046ca10(*(undefined2 *)(*(int64_t *)(iVar6 + iVar22) + uVar14 * 4)), iVar9 == 0)
                   ) break;
                if (*(int16_t *)(*(int64_t *)(iVar22 + *(int64_t *)(arg1 + 0x40)) + uVar14 * 4) == 9) {
                    iVar9 = iVar4 - iVar17 % iVar4;
                } else {
                    iVar9 = 1;
                }
                iVar17 = iVar17 + iVar9;
                uVar14 = uVar14 + 1;
            } while (iVar17 < 4);
            uVar12 = (*(int64_t *)(arg1 + 0x48) - *(int64_t *)(arg1 + 0x40) >> 3) * 0x6db6db6db6db6db7;
            if (uVar12 < uVar18 || uVar12 - uVar18 == 0) {
                func_0x000180060370();
                pcVar7 = (code *)swi(3);
                (*pcVar7)();
                return;
            }
            piVar13 = *(int16_t **)(iVar22 + *(int64_t *)(arg1 + 0x40));
            piVar3 = piVar13 + uVar14 * 2;
            iVar17 = 0;
            while (piVar13 != piVar3) {
                cVar8 = -1;
                if (piVar3 <= piVar13) {
                    cVar8 = '\x01';
                }
                if (-1 < cVar8) break;
                if (*piVar13 == 9) {
                    iVar17 = iVar17 + (*(int32_t *)(arg1 + 0x58) - iVar17 % *(int32_t *)(arg1 + 0x58));
                    piVar13 = piVar13 + 2;
                } else {
                    iVar17 = iVar17 + 1;
                    piVar13 = piVar13 + 2;
                }
            }
            if (iVar17 != 0) {
                LOCK();
                *(int32_t *)(*pauVar10 + 8) = *(int32_t *)(*pauVar10 + 8) + 1;
                UNLOCK();
                var_68h = (int64_t)pauVar10;
                var_70h = (int64_t)(pauVar10 + 1);
                func_0x00018015bca0(arg1, &var_70h, uVar21 & 0xffffffff, CONCAT44(iVar17, iVar19));
                func_0x00018015c720(arg1, puVar16, uVar21 & 0xffffffff);
            }
            uVar20 = iVar19 + 1;
            uVar21 = (uint64_t)uVar20;
        }
    }
    LOCK();
    *(int32_t *)(*pauVar10 + 8) = *(int32_t *)(*pauVar10 + 8) + 1;
    UNLOCK();
    var_68h = (int64_t)pauVar10;
    var_70h = (int64_t)(pauVar10 + 1);
    func_0x00018015af60(arg1, &var_70h);
    LOCK();
    piVar2 = (int32_t *)(*pauVar10 + 8);
    iVar4 = *piVar2;
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (iVar4 == 1) {
        (***(code ***)*pauVar10)(pauVar10);
        LOCK();
        piVar2 = (int32_t *)(*pauVar10 + 0xc);
        iVar4 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar4 == 1) {
            (**(code **)(*(int64_t *)*pauVar10 + 8))(pauVar10);
        }
    }
    return;
}

// ============================================================
// Function: FUN_180159ea0
// Address: 0x180159ea0
// Size: 1134 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.180159ea0(int64_t arg1)
{
    undefined (*pauVar1) [16];
    uint64_t *puVar2;
    int64_t *piVar3;
    code *pcVar4;
    undefined8 uVar5;
    int64_t iVar6;
    int64_t iVar7;
    char cVar8;
    undefined (*pauVar9) [16];
    uint64_t uVar10;
    int64_t iVar11;
    int32_t iVar12;
    int32_t *piVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    undefined *puVar16;
    undefined *puVar17;
    int32_t iVar18;
    uint64_t *puVar19;
    uint64_t *puVar20;
    undefined4 uVar21;
    int32_t iVar22;
    uint64_t uVar23;
    bool bVar24;
    bool bVar25;
    undefined auStack_168 [8];
    undefined auStack_160 [24];
    int64_t var_148h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int32_t var_f0h;
    undefined4 var_ech;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar16 = auStack_168;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    var_110h._0_4_ = 0;
    piVar13 = *(int32_t **)arg1;
    iVar22 = *piVar13;
    iVar18 = piVar13[2];
    bVar24 = SBORROW4(iVar22, iVar18);
    iVar12 = iVar22 - iVar18;
    if (iVar22 == iVar18) {
        bVar24 = SBORROW4(piVar13[1], piVar13[3]);
        iVar12 = piVar13[1] - piVar13[3];
    }
    if (bVar24 == iVar12 < 0) {
        piVar13 = piVar13 + 2;
    }
    puVar17 = auStack_168;
    var_118h = arg1;
    if (*piVar13 != 0) {
        if (*(char *)(arg1 + 0x131) != '\0') {
            *(undefined *)(arg1 + 0x133) = 1;
        }
        pauVar9 = (undefined (*) [16])func_0x000180459890(0x78);
        *pauVar9 = ZEXT816(0);
        *(undefined4 *)(*pauVar9 + 8) = 1;
        *(undefined4 *)(*pauVar9 + 0xc) = 1;
        *(undefined8 *)*pauVar9 = 0x180645d88;
        pauVar1 = pauVar9 + 1;
        *pauVar1 = ZEXT816(0);
        pauVar9[2] = ZEXT816(0);
        pauVar9[3] = ZEXT816(0);
        pauVar9[4] = ZEXT816(0);
        pauVar9[5] = ZEXT816(0);
        pauVar9[6] = ZEXT816(0);
        *(undefined8 *)pauVar9[7] = 0;
        var_108h = (int64_t)pauVar9;
        func_0x0001801655b0(pauVar1);
        var_110h._0_4_ = 7;
        var_98h = (int64_t)pauVar1;
        var_90h = (int64_t)pauVar9;
        func_0x000180150230(pauVar9[2] + 8, arg1);
        puVar20 = *(uint64_t **)arg1;
        do {
            if (puVar20 == *(uint64_t **)(arg1 + 8)) {
                cVar8 = '\0';
            } else {
                cVar8 = -1;
                if (*(uint64_t **)(arg1 + 8) <= puVar20) {
                    cVar8 = '\x01';
                }
            }
            if (-1 < cVar8) goto code_r0x00018015a28a;
            puVar2 = puVar20 + 1;
            iVar18 = *(int32_t *)puVar20;
            iVar22 = *(int32_t *)puVar2;
            var_e8h = (int64_t)puVar20 + 0xc;
            bVar24 = SBORROW4(iVar18, iVar22);
            iVar12 = iVar18 - iVar22;
            if (iVar18 == iVar22) {
                bVar24 = SBORROW4(*(int32_t *)((int64_t)puVar20 + 4), *(int32_t *)var_e8h);
                iVar12 = *(int32_t *)((int64_t)puVar20 + 4) - *(int32_t *)var_e8h;
            }
            puVar19 = puVar20;
            if (bVar24 == iVar12 < 0) {
                puVar19 = puVar2;
            }
            var_c0h = *puVar19;
            bVar25 = SBORROW4(iVar18, iVar22);
            iVar12 = iVar18 - iVar22;
            bVar24 = iVar18 == iVar22;
            if (bVar24) {
                iVar18 = *(int32_t *)var_e8h;
                iVar22 = *(int32_t *)((int64_t)puVar20 + 4);
                bVar25 = SBORROW4(iVar22, iVar18);
                iVar12 = iVar22 - iVar18;
                bVar24 = iVar22 == iVar18;
            }
            puVar19 = puVar20;
            if (bVar24 || bVar25 != iVar12 < 0) {
                puVar19 = puVar2;
            }
            uVar14 = *puVar19;
            iVar22 = (int32_t)var_c0h;
            var_f8h._4_4_ = 0;
            piVar3 = (int64_t *)(arg1 + 0x40);
            iVar18 = (int32_t)uVar14;
            var_f8h._0_4_ = iVar22;
            var_c8h = uVar14;
            if ((int32_t)(uVar14 >> 0x20) != 0) {
                uVar10 = (uint64_t)iVar18;
                uVar23 = (*(int64_t *)(arg1 + 0x48) - *piVar3 >> 3) * 0x6db6db6db6db6db7;
                if (uVar23 < uVar10 || uVar23 - uVar10 == 0) {
                    func_0x000180060370();
                    pcVar4 = (code *)swi(3);
                    (*pcVar4)();
                    return;
                }
                piVar15 = (int64_t *)(uVar10 * 0x38 + *piVar3);
                uVar21 = *(undefined4 *)(piVar15 + 5);
                iVar11 = func_0x00018015d7b0(piVar3, piVar15);
                if (iVar11 == piVar15[1] - *piVar15 >> 2) {
                    iVar12 = (int32_t)uVar23 + -1;
                    var_120h._0_4_ = iVar18 + 1;
                    if (iVar12 <= iVar18) {
                        var_120h._0_4_ = iVar18;
                    }
                    var_120h._4_4_ = 0;
                    if (iVar12 <= iVar18) {
                        var_120h._4_4_ = uVar21;
                    }
                } else {
                    var_120h._4_4_ = func_0x000180150020(piVar3, uVar14 & 0xffffffff, iVar11 + 1);
                    var_120h._0_4_ = iVar18;
                }
                uVar14 = CONCAT44(var_120h._4_4_, (int32_t)var_120h);
            }
            uVar5 = CONCAT44(var_f8h._4_4_, (int32_t)var_f8h);
            func_0x00018015d450(piVar3, &var_78h, uVar5, uVar14);
            LOCK();
            *(int32_t *)(var_108h + 8) = *(int32_t *)(var_108h + 8) + 1;
            UNLOCK();
            var_128h = var_108h;
            var_130h = var_108h + 0x10;
            func_0x00018015bca0(var_118h, &var_130h, uVar5, uVar14);
            func_0x00018015c720(var_118h, puVar20, uVar5, uVar14);
            var_f0h = iVar22 + -1;
            var_ech = 0;
            func_0x00018015e5d0(piVar3, &var_e0h, var_f0h);
            iVar11 = var_e0h;
            var_a8h = (int64_t)&var_78h;
            if (0xf < (uint64_t)var_60h) {
                var_a8h = var_78h;
            }
            var_a0h = var_68h;
            LOCK();
            *(int32_t *)(var_108h + 8) = *(int32_t *)(var_108h + 8) + 1;
            UNLOCK();
            var_128h = var_108h;
            var_130h = var_108h + 0x10;
            var_b8h = (int64_t)&var_130h;
            func_0x00018015c7f0(piVar3, &var_d8h, var_e0h, &var_a8h);
            iVar7 = var_d8h;
            var_88h._0_4_ = (undefined4)var_a8h;
            var_88h._4_4_ = var_a8h._4_4_;
            uStack_80 = (undefined4)var_a0h;
            uStack_7c = var_a0h._4_4_;
            var_d0h = var_d8h;
            var_100h = iVar11;
            var_138h._0_1_ = 0;
            var_148h = (int64_t)&var_88h;
            func_0x0001801633e0(var_130h, &var_138h, &var_100h, &var_d0h);
            *(undefined *)(var_118h + 0x2c8) = 1;
            *(undefined4 *)(var_118h + 0x2cc) = 0xffffffff;
            iVar6 = var_128h;
            if (var_128h != 0) {
                LOCK();
                piVar13 = (int32_t *)(var_128h + 8);
                iVar12 = *piVar13;
                *piVar13 = *piVar13 + -1;
                UNLOCK();
                if (iVar12 == 1) {
                    (***(code ***)var_128h)(var_128h);
                    LOCK();
                    piVar13 = (int32_t *)(iVar6 + 0xc);
                    iVar12 = *piVar13;
                    *piVar13 = *piVar13 + -1;
                    UNLOCK();
                    if (iVar12 == 1) {
                        (**(code **)(*(int64_t *)iVar6 + 8))(iVar6);
                    }
                }
            }
            arg1 = var_118h;
            func_0x00018015c690(var_118h, puVar20, iVar11, iVar7);
            *(int32_t *)puVar20 = iVar22 + -1;
            *(int32_t *)((int64_t)puVar20 + 4) = var_c0h._4_4_;
            *(int32_t *)puVar2 = iVar18 + -1;
            *(undefined4 *)var_e8h = var_c8h._4_4_;
            *(undefined *)((int64_t)puVar20 + 0x12) = 1;
            if (0xf < (uint64_t)var_60h) {
                uVar14 = var_60h + 1;
                iVar11 = var_78h;
                if (0xfff < uVar14) {
                    iVar11 = *(int64_t *)(var_78h + -8);
                    if (0x1f < (var_78h - iVar11) - 8U) goto code_r0x00018015a283;
                    uVar14 = var_60h + 0x28;
                }
                func_0x000180459c3c(iVar11, uVar14);
            }
            puVar20 = (uint64_t *)((int64_t)puVar20 + 0x14);
        } while( true );
    }
code_r0x00018015a2e8:
    *(undefined8 *)(puVar17 + -8) = 0x18015a2f4;
    func_0x000180459870(var_58h ^ (uint64_t)puVar17);
    return;
code_r0x00018015a283:
    pcVar4 = (code *)swi(0x29);
    (*pcVar4)(5);
    puVar16 = auStack_160;
code_r0x00018015a28a:
    *(undefined (*) [16])(puVar16 + 0x38) = ZEXT816(0);
    piVar15 = *(int64_t **)(puVar16 + 0x60);
    LOCK();
    *(int32_t *)(piVar15 + 1) = *(int32_t *)(piVar15 + 1) + 1;
    UNLOCK();
    *(int64_t **)(puVar16 + 0x38) = piVar15 + 2;
    *(int64_t **)(puVar16 + 0x40) = piVar15;
    *(undefined8 *)(puVar16 + -8) = 0x18015a2b7;
    func_0x00018015af60(arg1, puVar16 + 0x38);
    LOCK();
    piVar3 = piVar15 + 1;
    iVar18 = *(int32_t *)piVar3;
    *(int32_t *)piVar3 = *(int32_t *)piVar3 + -1;
    UNLOCK();
    puVar17 = puVar16;
    if (iVar18 == 1) {
        pcVar4 = *(code **)*piVar15;
        *(undefined8 *)(puVar16 + -8) = 0x18015a2d3;
        (*pcVar4)(piVar15);
        LOCK();
        piVar13 = (int32_t *)((int64_t)piVar15 + 0xc);
        iVar18 = *piVar13;
        *piVar13 = *piVar13 + -1;
        UNLOCK();
        if (iVar18 == 1) {
            pcVar4 = *(code **)(*piVar15 + 8);
            *(undefined8 *)(puVar16 + -8) = 0x18015a2e8;
            (*pcVar4)(piVar15);
        }
    }
    goto code_r0x00018015a2e8;
}

// ============================================================
// Function: FUN_18015a310
// Address: 0x18015a310
// Size: 1214 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_11ch
// WARNING: [rz-ghidra] Detected overlap for variable var_f0h
// WARNING: [rz-ghidra] Detected overlap for variable var_ech
// WARNING: [rz-ghidra] Detected overlap for variable var_c4h
// WARNING: [rz-ghidra] Detected overlap for variable var_bch

void fcn.18015a310(int64_t arg1)
{
    uint64_t *puVar1;
    undefined (*pauVar2) [16];
    code *pcVar3;
    undefined8 uVar4;
    int64_t iVar5;
    char cVar6;
    undefined (*pauVar7) [16];
    uint64_t uVar8;
    int64_t iVar9;
    int32_t iVar10;
    int32_t *piVar11;
    uint64_t uVar12;
    int64_t *piVar13;
    undefined *puVar14;
    undefined *puVar15;
    int32_t iVar16;
    uint64_t *puVar17;
    uint64_t *puVar18;
    undefined4 uVar19;
    int32_t iVar20;
    uint64_t uVar21;
    bool bVar22;
    bool bVar23;
    undefined auStack_168 [8];
    undefined auStack_160 [24];
    int64_t var_148h;
    int64_t var_138h;
    int64_t var_130h;
    int64_t var_128h;
    int64_t var_120h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int32_t var_f0h;
    undefined4 var_ech;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    int64_t var_d0h;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    undefined4 uStack_80;
    undefined4 uStack_7c;
    int64_t var_78h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar14 = auStack_168;
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_168;
    var_108h._0_4_ = 0;
    piVar13 = (int64_t *)(arg1 + 0x40);
    piVar11 = (int32_t *)
              (*(int64_t *)arg1 + ((*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333 + -1) * 0x14);
    iVar20 = *piVar11;
    iVar16 = piVar11[2];
    bVar22 = SBORROW4(iVar20, iVar16);
    iVar10 = iVar20 - iVar16;
    if (iVar20 == iVar16) {
        bVar22 = SBORROW4(piVar11[1], piVar11[3]);
        iVar10 = piVar11[1] - piVar11[3];
    }
    if (bVar22 == iVar10 < 0) {
        piVar11 = piVar11 + 2;
    }
    puVar15 = auStack_168;
    var_118h = (int64_t)piVar13;
    var_110h = arg1;
    if (*piVar11 != (int32_t)(*(int64_t *)(arg1 + 0x48) - *piVar13 >> 3) * -0x49249249 + -1) {
        if (*(char *)(arg1 + 0x131) != '\0') {
            *(undefined *)(arg1 + 0x133) = 1;
        }
        pauVar7 = (undefined (*) [16])func_0x000180459890(0x78);
        *pauVar7 = ZEXT816(0);
        *(undefined4 *)(*pauVar7 + 8) = 1;
        *(undefined4 *)(*pauVar7 + 0xc) = 1;
        *(undefined8 *)*pauVar7 = 0x180645d88;
        pauVar2 = pauVar7 + 1;
        *pauVar2 = ZEXT816(0);
        pauVar7[2] = ZEXT816(0);
        pauVar7[3] = ZEXT816(0);
        pauVar7[4] = ZEXT816(0);
        pauVar7[5] = ZEXT816(0);
        pauVar7[6] = ZEXT816(0);
        *(undefined8 *)pauVar7[7] = 0;
        var_b8h = (int64_t)pauVar7;
        func_0x0001801655b0(pauVar2);
        var_108h._0_4_ = 7;
        var_98h = (int64_t)pauVar2;
        var_90h = (int64_t)pauVar7;
        func_0x000180150230(pauVar7[2] + 8, arg1);
        puVar18 = *(uint64_t **)arg1;
        do {
            if (puVar18 == *(uint64_t **)(arg1 + 8)) {
                cVar6 = '\0';
            } else {
                cVar6 = -1;
                if (*(uint64_t **)(arg1 + 8) <= puVar18) {
                    cVar6 = '\x01';
                }
            }
            if (-1 < cVar6) goto code_r0x00018015a74a;
            puVar1 = puVar18 + 1;
            iVar16 = *(int32_t *)puVar18;
            iVar20 = *(int32_t *)puVar1;
            var_e8h = (int64_t)puVar18 + 0xc;
            bVar22 = SBORROW4(iVar16, iVar20);
            iVar10 = iVar16 - iVar20;
            if (iVar16 == iVar20) {
                bVar22 = SBORROW4(*(int32_t *)((int64_t)puVar18 + 4), *(int32_t *)var_e8h);
                iVar10 = *(int32_t *)((int64_t)puVar18 + 4) - *(int32_t *)var_e8h;
            }
            puVar17 = puVar18;
            if (bVar22 == iVar10 < 0) {
                puVar17 = puVar1;
            }
            var_c0h = *puVar17;
            bVar23 = SBORROW4(iVar16, iVar20);
            iVar10 = iVar16 - iVar20;
            bVar22 = iVar16 == iVar20;
            if (bVar22) {
                iVar16 = *(int32_t *)var_e8h;
                iVar20 = *(int32_t *)((int64_t)puVar18 + 4);
                bVar23 = SBORROW4(iVar20, iVar16);
                iVar10 = iVar20 - iVar16;
                bVar22 = iVar20 == iVar16;
            }
            puVar17 = puVar18;
            if (bVar22 || bVar23 != iVar10 < 0) {
                puVar17 = puVar1;
            }
            uVar12 = *puVar17;
            iVar20 = (int32_t)var_c0h;
            var_f8h._4_4_ = 0;
            iVar16 = (int32_t)uVar12;
            var_f8h._0_4_ = iVar20;
            var_c8h = uVar12;
            if ((int32_t)(uVar12 >> 0x20) != 0) {
                uVar8 = (uint64_t)iVar16;
                uVar21 = (piVar13[1] - *piVar13 >> 3) * 0x6db6db6db6db6db7;
                if (uVar21 < uVar8 || uVar21 - uVar8 == 0) {
                    func_0x000180060370();
                    pcVar3 = (code *)swi(3);
                    (*pcVar3)();
                    return;
                }
                piVar13 = (int64_t *)(uVar8 * 0x38 + *piVar13);
                uVar19 = *(undefined4 *)(piVar13 + 5);
                iVar9 = func_0x00018015d7b0(var_118h, piVar13);
                if (iVar9 == piVar13[1] - *piVar13 >> 2) {
                    iVar10 = (int32_t)uVar21 + -1;
                    var_120h._0_4_ = iVar16 + 1;
                    if (iVar10 <= iVar16) {
                        var_120h._0_4_ = iVar16;
                    }
                    var_120h._4_4_ = 0;
                    if (iVar10 <= iVar16) {
                        var_120h._4_4_ = uVar19;
                    }
                } else {
                    var_120h._4_4_ = func_0x000180150020(var_118h, uVar12 & 0xffffffff, iVar9 + 1);
                    var_120h._0_4_ = iVar16;
                }
                uVar12 = CONCAT44(var_120h._4_4_, (int32_t)var_120h);
            }
            uVar4 = CONCAT44(var_f8h._4_4_, (int32_t)var_f8h);
            func_0x00018015d450(var_118h, &var_78h, uVar4, uVar12);
            LOCK();
            *(int32_t *)(*pauVar7 + 8) = *(int32_t *)(*pauVar7 + 8) + 1;
            UNLOCK();
            var_128h = (int64_t)pauVar7;
            var_130h = (int64_t)(pauVar7 + 1);
            func_0x00018015bca0(var_110h, &var_130h, uVar4, uVar12);
            func_0x00018015c720(var_110h, puVar18, uVar4, uVar12);
            var_f0h = iVar20 + 1;
            var_ech = 0;
            func_0x00018015e5d0(var_118h, &var_e0h, var_f0h);
            iVar9 = var_e0h;
            var_a8h = (int64_t)&var_78h;
            if (0xf < (uint64_t)var_60h) {
                var_a8h = var_78h;
            }
            var_a0h = var_68h;
            LOCK();
            *(int32_t *)(*pauVar7 + 8) = *(int32_t *)(*pauVar7 + 8) + 1;
            UNLOCK();
            var_130h = (int64_t)(pauVar7 + 1);
            var_b0h = (int64_t)&var_130h;
            func_0x00018015c7f0(var_118h, &var_d8h, var_e0h, &var_a8h);
            iVar5 = var_d8h;
            var_88h._0_4_ = (undefined4)var_a8h;
            var_88h._4_4_ = var_a8h._4_4_;
            uStack_80 = (undefined4)var_a0h;
            uStack_7c = var_a0h._4_4_;
            var_d0h = var_d8h;
            var_100h = iVar9;
            var_138h._0_1_ = 0;
            var_148h = (int64_t)&var_88h;
            func_0x0001801633e0(var_130h, &var_138h, &var_100h, &var_d0h);
            *(undefined *)(var_110h + 0x2c8) = 1;
            *(undefined4 *)(var_110h + 0x2cc) = 0xffffffff;
            pauVar7 = (undefined (*) [16])var_128h;
            if (var_128h != 0) {
                LOCK();
                piVar11 = (int32_t *)(var_128h + 8);
                iVar10 = *piVar11;
                *piVar11 = *piVar11 + -1;
                UNLOCK();
                if (iVar10 == 1) {
                    (***(code ***)var_128h)(var_128h);
                    LOCK();
                    piVar11 = (int32_t *)((int64_t)pauVar7 + 0xc);
                    iVar10 = *piVar11;
                    *piVar11 = *piVar11 + -1;
                    UNLOCK();
                    if (iVar10 == 1) {
                        (**(code **)(*(int64_t *)pauVar7 + 8))(pauVar7);
                    }
                }
            }
            arg1 = var_110h;
            func_0x00018015c690(var_110h, puVar18, iVar9, iVar5);
            *(int32_t *)puVar18 = iVar20 + 1;
            *(int32_t *)((int64_t)puVar18 + 4) = var_c0h._4_4_;
            *(int32_t *)puVar1 = iVar16 + 1;
            *(undefined4 *)var_e8h = var_c8h._4_4_;
            *(undefined *)((int64_t)puVar18 + 0x12) = 1;
            if (0xf < (uint64_t)var_60h) {
                uVar12 = var_60h + 1;
                iVar9 = var_78h;
                if (0xfff < uVar12) {
                    iVar9 = *(int64_t *)(var_78h + -8);
                    if (0x1f < (var_78h - iVar9) - 8U) goto code_r0x00018015a743;
                    uVar12 = var_60h + 0x28;
                }
                func_0x000180459c3c(iVar9, uVar12);
            }
            puVar18 = (uint64_t *)((int64_t)puVar18 + 0x14);
            piVar13 = (int64_t *)(arg1 + 0x40);
            pauVar7 = (undefined (*) [16])var_b8h;
        } while( true );
    }
code_r0x00018015a7a8:
    *(undefined8 *)(puVar15 + -8) = 0x18015a7b4;
    func_0x000180459870(var_58h ^ (uint64_t)puVar15);
    return;
code_r0x00018015a743:
    pcVar3 = (code *)swi(0x29);
    (*pcVar3)(5);
    puVar14 = auStack_160;
code_r0x00018015a74a:
    *(undefined (*) [16])(puVar14 + 0x38) = ZEXT816(0);
    LOCK();
    *(int32_t *)(*pauVar7 + 8) = *(int32_t *)(*pauVar7 + 8) + 1;
    UNLOCK();
    *(undefined (**) [16])(puVar14 + 0x38) = pauVar7 + 1;
    *(undefined (**) [16])(puVar14 + 0x40) = pauVar7;
    *(undefined8 *)(puVar14 + -8) = 0x18015a775;
    func_0x00018015af60(arg1, puVar14 + 0x38);
    LOCK();
    piVar11 = (int32_t *)(*pauVar7 + 8);
    iVar16 = *piVar11;
    *piVar11 = *piVar11 + -1;
    UNLOCK();
    puVar15 = puVar14;
    if (iVar16 == 1) {
        pcVar3 = **(code ***)*pauVar7;
        *(undefined8 *)(puVar14 + -8) = 0x18015a792;
        (*pcVar3)(pauVar7);
        LOCK();
        piVar11 = (int32_t *)(*pauVar7 + 0xc);
        iVar16 = *piVar11;
        *piVar11 = *piVar11 + -1;
        UNLOCK();
        if (iVar16 == 1) {
            pcVar3 = *(code **)(*(int64_t *)*pauVar7 + 8);
            *(undefined8 *)(puVar14 + -8) = 0x18015a7a8;
            (*pcVar3)(pauVar7);
        }
    }
    goto code_r0x00018015a7a8;
}

// ============================================================
// Function: FUN_18015a7d0
// Address: 0x18015a7d0
// Size: 1691 bytes
// ============================================================
// WARNING: [rz-ghidra] Detected overlap for variable var_e4h
// WARNING: [rz-ghidra] Detected overlap for variable var_12ch
// WARNING: [rz-ghidra] Detected overlap for variable var_130h
// WARNING: [rz-ghidra] Detected overlap for variable var_f4h
// WARNING: [rz-ghidra] Detected overlap for variable var_b4h

void fcn.18015a7d0(int64_t arg1)
{
    int32_t *piVar1;
    int32_t iVar2;
    int32_t iVar3;
    code *pcVar4;
    undefined auVar5 [16];
    int64_t iVar6;
    char cVar7;
    uint64_t *puVar8;
    uint64_t uVar9;
    int64_t iVar10;
    int16_t *piVar11;
    int64_t iVar12;
    int64_t iVar13;
    int16_t *piVar14;
    undefined *puVar15;
    uint64_t *puVar16;
    uint64_t uVar17;
    int64_t *piVar18;
    int32_t iVar19;
    uint32_t uVar20;
    int64_t *piVar21;
    undefined4 uVar22;
    uint64_t uVar23;
    uint64_t uVar24;
    uint64_t *puVar25;
    uint64_t uVar26;
    bool bVar27;
    bool bVar28;
    undefined8 uStack_190;
    undefined auStack_188 [8];
    undefined auStack_180 [24];
    int64_t var_168h;
    int64_t var_158h;
    int64_t var_150h;
    int64_t var_148h;
    int64_t var_140h;
    int64_t var_138h;
    undefined4 var_130h;
    int32_t var_12ch;
    int64_t var_128h;
    int64_t var_118h;
    int64_t var_110h;
    int64_t var_108h;
    int64_t var_100h;
    int64_t var_f8h;
    int64_t var_f0h;
    int64_t var_e8h;
    int64_t var_e0h;
    int64_t var_d8h;
    undefined8 uStack_d0;
    int64_t var_c8h;
    int64_t var_c0h;
    int64_t var_b8h;
    int64_t var_b0h;
    int64_t var_a8h;
    undefined4 uStack_a0;
    undefined4 uStack_9c;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    undefined8 uStack_70;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    var_58h = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStack_188;
    var_140h._0_4_ = 0;
    var_128h = arg1;
    func_0x00018015aea0(arg1, &var_118h, 1);
    func_0x00018000b4d0(&var_98h, *(int64_t *)(arg1 + 0x5e8) + 0x28);
    puVar16 = *(uint64_t **)arg1;
    while( true ) {
        iVar19 = -1;
        puVar15 = auStack_188;
        var_e0h = (int64_t)puVar16;
        if (puVar16 == *(uint64_t **)(arg1 + 8)) break;
        cVar7 = -1;
        if (*(uint64_t **)(arg1 + 8) <= puVar16) {
            cVar7 = '\x01';
        }
        puVar15 = auStack_188;
        if (-1 < cVar7) break;
        puVar25 = puVar16 + 1;
        iVar19 = *(int32_t *)puVar16;
        iVar2 = *(int32_t *)puVar25;
        bVar27 = SBORROW4(iVar19, iVar2);
        iVar3 = iVar19 - iVar2;
        if (iVar19 == iVar2) {
            bVar27 = SBORROW4(*(int32_t *)((int64_t)puVar16 + 4), *(int32_t *)((int64_t)puVar16 + 0xc));
            iVar3 = *(int32_t *)((int64_t)puVar16 + 4) - *(int32_t *)((int64_t)puVar16 + 0xc);
        }
        puVar8 = puVar25;
        if (bVar27 != iVar3 < 0) {
            puVar8 = puVar16;
        }
        var_150h = *puVar8;
        bVar28 = SBORROW4(iVar19, iVar2);
        iVar3 = iVar19 - iVar2;
        bVar27 = iVar19 == iVar2;
        if (bVar27) {
            iVar19 = *(int32_t *)((int64_t)puVar16 + 0xc);
            iVar2 = *(int32_t *)((int64_t)puVar16 + 4);
            bVar28 = SBORROW4(iVar2, iVar19);
            iVar3 = iVar2 - iVar19;
            bVar27 = iVar2 == iVar19;
        }
        if (!bVar27 && bVar28 == iVar3 < 0) {
            puVar25 = puVar16;
        }
        uVar9 = *puVar25;
        bVar27 = (int32_t)var_150h == (int32_t)uVar9;
        var_f0h = uVar9;
        var_b8h = uVar9;
        if ((int32_t)var_150h <= (int32_t)uVar9) {
            do {
                iVar19 = (int32_t)var_150h;
                if ((!bVar27) || (var_b8h._4_4_ != 0)) {
                    var_148h = arg1 + 0x40;
                    uVar24 = (uint64_t)iVar19;
                    var_138h = uVar24 * 0x38;
                    piVar14 = *(int16_t **)(*(int64_t *)var_148h + var_138h);
                    uVar23 = *(int64_t *)(*(int64_t *)var_148h + 8 + var_138h) - (int64_t)piVar14 >> 2;
                    arg1 = var_128h;
                    if (uVar23 != 0) {
                        uVar26 = 0;
                        uVar17 = 0;
                        if (uVar23 != 0) {
                            do {
                                cVar7 = func_0x000180162130(piVar14[uVar26 * 2]);
                                if (cVar7 == '\0') goto code_r0x00018015a927;
                                uVar26 = uVar26 + 1;
                            } while (uVar26 < uVar23);
                        }
                        if (uVar26 < uVar23) {
code_r0x00018015a927:
                            do {
                                puVar16 = (uint64_t *)var_e0h;
                                uVar9 = var_f0h;
                                if ((uint64_t)var_88h <= uVar17) break;
                                piVar18 = &var_98h;
                                if (0xf < (uint64_t)var_80h) {
                                    piVar18 = (int64_t *)var_98h;
                                }
                                if (((uint32_t)(uint16_t)piVar14[(uVar17 + uVar26) * 2] !=
                                     (int32_t)*(char *)((int64_t)piVar18 + uVar17)) ||
                                   (uVar17 = uVar17 + 1, uVar23 <= uVar17 + uVar26)) break;
                            } while( true );
                        }
                        iVar13 = var_f0h;
                        arg1 = var_128h;
                        uVar22 = (undefined4)var_150h;
                        if (uVar17 == var_88h) {
                            uVar23 = (*(int64_t *)(var_148h + 8) - *(int64_t *)var_148h >> 3) * 0x6db6db6db6db6db7;
                            if (uVar23 < uVar24 || uVar23 - uVar24 == 0) {
code_r0x00018015ae59:
                                func_0x000180060370();
code_r0x00018015ae5f:
                                func_0x000180004720();
                                pcVar4 = (code *)swi(3);
                                (*pcVar4)();
                                return;
                            }
                            var_12ch = 0;
                            piVar11 = piVar14;
                            while (piVar11 != piVar14 + uVar26 * 2) {
                                cVar7 = -1;
                                if (piVar14 + uVar26 * 2 <= piVar11) {
                                    cVar7 = '\x01';
                                }
                                if (-1 < cVar7) break;
                                if (*piVar11 == 9) {
                                    var_12ch = var_12ch +
                                               (*(int32_t *)(var_148h + 0x18) - var_12ch % *(int32_t *)(var_148h + 0x18)
                                               );
                                    piVar11 = piVar11 + 2;
                                } else {
                                    var_12ch = var_12ch + 1;
                                    piVar11 = piVar11 + 2;
                                }
                            }
                            piVar11 = piVar14 + ((int64_t)(int32_t)var_88h + 1 + uVar26) * 2;
                            var_f8h._4_4_ = 0;
                            while (piVar14 != piVar11) {
                                cVar7 = -1;
                                if (piVar11 <= piVar14) {
                                    cVar7 = '\x01';
                                }
                                if (-1 < cVar7) break;
                                if (*piVar14 == 9) {
                                    var_f8h._4_4_ =
                                         var_f8h._4_4_ +
                                         (*(int32_t *)(var_148h + 0x18) - var_f8h._4_4_ % *(int32_t *)(var_148h + 0x18))
                                    ;
                                    piVar14 = piVar14 + 2;
                                } else {
                                    var_f8h._4_4_ = var_f8h._4_4_ + 1;
                                    piVar14 = piVar14 + 2;
                                }
                            }
                            if (CONCAT44(var_110h._4_4_, (undefined4)var_110h) != 0) {
                                LOCK();
                                piVar1 = (int32_t *)(CONCAT44(var_110h._4_4_, (undefined4)var_110h) + 8);
                                *piVar1 = *piVar1 + 1;
                                UNLOCK();
                            }
                            var_d8h = CONCAT44(var_118h._4_4_, (undefined4)var_118h);
                            uStack_d0._0_4_ = (undefined4)var_110h;
                            uStack_d0._4_4_ = var_110h._4_4_;
                            var_130h = uVar22;
                            var_f8h._0_4_ = uVar22;
                            func_0x00018015bca0(var_128h, &var_d8h, CONCAT44(var_12ch, uVar22), 
                                                CONCAT44(var_f8h._4_4_, uVar22));
                            func_0x00018015c720(arg1, puVar16, CONCAT44(var_12ch, var_130h), 
                                                CONCAT44(var_f8h._4_4_, (undefined4)var_f8h));
                            iVar19 = (int32_t)var_150h;
                        } else {
                            uVar9 = (*(int64_t *)(var_148h + 8) - *(int64_t *)var_148h >> 3) * 0x6db6db6db6db6db7;
                            if (uVar9 < uVar24 || uVar9 - uVar24 == 0) goto code_r0x00018015ae59;
                            piVar11 = *(int16_t **)(var_138h + *(int64_t *)var_148h);
                            piVar14 = piVar11 + uVar26 * 2;
                            piVar18 = (int64_t *)0x0;
                            piVar21 = piVar18;
                            while( true ) {
                                var_e8h._4_4_ = (int32_t)piVar21;
                                if (piVar11 == piVar14) break;
                                cVar7 = -1;
                                if (piVar14 <= piVar11) {
                                    cVar7 = '\x01';
                                }
                                if (-1 < cVar7) break;
                                if (*piVar11 == 9) {
                                    piVar21 = (int64_t *)
                                              (uint64_t)
                                              (uint32_t)
                                              (var_e8h._4_4_ +
                                              (*(int32_t *)(var_148h + 0x18) -
                                              var_e8h._4_4_ % *(int32_t *)(var_148h + 0x18)));
                                    piVar11 = piVar11 + 2;
                                } else {
                                    piVar21 = (int64_t *)(uint64_t)(var_e8h._4_4_ + 1);
                                    piVar11 = piVar11 + 2;
                                }
                            }
                            var_e8h._0_4_ = uVar22;
                            if (var_88h == 0x7fffffffffffffff) {
                                func_0x0001800047c0();
                                pcVar4 = (code *)swi(3);
                                (*pcVar4)();
                                return;
                            }
                            arg1 = (int64_t)&var_98h;
                            if (0xf < (uint64_t)var_80h) {
                                arg1 = var_98h;
                            }
                            auVar5 = ZEXT816(0);
                            uStack_70 = 0;
                            var_68h = 0;
                            var_60h = 0;
                            uVar9 = var_88h + 1;
                            _var_78h = auVar5;
                            if (0xf < uVar9) {
                                uVar23 = uVar9 | 0xf;
                                if (uVar23 < 0x8000000000000000) {
                                    if (uVar23 < 0x16) {
                                        uVar23 = 0x16;
                                    }
                                    if (uVar23 != 0xffffffffffffffff) {
                                        if (0xfff < uVar23 + 1) {
                                            uVar24 = uVar23 + 0x28;
                                            if (uVar24 <= uVar23 + 1) goto code_r0x00018015ae5f;
                                            goto code_r0x00018015abbf;
                                        }
                                        piVar18 = (int64_t *)func_0x000180459890();
                                    }
                                    var_78h = (int64_t)piVar18;
                                    goto code_r0x00018015ac01;
                                }
                                uVar23 = 0x7fffffffffffffff;
                                uVar24 = 0x8000000000000027;
code_r0x00018015abbf:
                                iVar10 = func_0x000180459890(uVar24);
                                if (iVar10 != 0) {
                                    piVar18 = (int64_t *)(iVar10 + 0x27U & 0xffffffffffffffe0);
                                    piVar18[-1] = iVar10;
                                    var_78h = (int64_t)piVar18;
                                    goto code_r0x00018015ac01;
                                }
code_r0x00018015ad8e:
                                pcVar4 = (code *)swi(0x29);
                                (*pcVar4)(5);
                                puVar15 = auStack_180;
                                goto code_r0x00018015ad95;
                            }
                            uVar23 = 0xf;
                            piVar18 = &var_78h;
code_r0x00018015ac01:
                            var_68h = uVar9;
                            var_60h = uVar23;
                            fcn.180498030(piVar18, arg1, var_88h);
                            *(undefined *)((int64_t)piVar18 + var_88h) = 0x20;
                            *(undefined *)(uVar9 + (int64_t)piVar18) = 0;
                            var_108h = (int64_t)&var_78h;
                            if (0xf < (uint64_t)var_60h) {
                                var_108h = var_78h;
                            }
                            var_100h = var_68h;
                            if (CONCAT44(var_110h._4_4_, (undefined4)var_110h) != 0) {
                                LOCK();
                                piVar1 = (int32_t *)(CONCAT44(var_110h._4_4_, (undefined4)var_110h) + 8);
                                *piVar1 = *piVar1 + 1;
                                UNLOCK();
                            }
                            var_c8h = CONCAT44(var_118h._4_4_, (undefined4)var_118h);
                            var_c0h._0_4_ = (undefined4)var_110h;
                            var_c0h._4_4_ = var_110h._4_4_;
                            var_d8h = (int64_t)&var_c8h;
                            iVar10 = CONCAT44(var_e8h._4_4_, (undefined4)var_e8h);
                            func_0x00018015c7f0(var_148h, &var_b0h, iVar10, &var_108h);
                            iVar6 = var_b0h;
                            var_a8h._0_4_ = (undefined4)var_108h;
                            var_a8h._4_4_ = var_108h._4_4_;
                            uStack_a0 = (undefined4)var_100h;
                            uStack_9c = var_100h._4_4_;
                            var_138h = var_b0h;
                            var_158h._0_1_ = 0;
                            var_168h = (int64_t)&var_a8h;
                            var_148h = iVar10;
                            func_0x0001801633e0(var_c8h, &var_158h, &var_148h, &var_138h);
                            arg1 = var_128h;
                            *(undefined *)(var_128h + 0x2c8) = 1;
                            iVar19 = -1;
                            *(undefined4 *)(var_128h + 0x2cc) = 0xffffffff;
                            if (var_c0h != 0) {
                                LOCK();
                                piVar1 = (int32_t *)(var_c0h + 8);
                                iVar2 = *piVar1;
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (iVar2 == 1) {
                                    (***(code ***)var_c0h)(var_c0h);
                                    LOCK();
                                    piVar1 = (int32_t *)(var_c0h + 0xc);
                                    iVar2 = *piVar1;
                                    *piVar1 = *piVar1 + -1;
                                    UNLOCK();
                                    if (iVar2 == 1) {
                                        (**(code **)(*(int64_t *)var_c0h + 8))(var_c0h);
                                    }
                                }
                            }
                            if (0xf < (uint64_t)var_60h) {
                                uVar9 = var_60h + 1;
                                iVar12 = var_78h;
                                if (0xfff < uVar9) {
                                    iVar12 = *(int64_t *)(var_78h + -8);
                                    if (0x1f < (var_78h - iVar12) - 8U) goto code_r0x00018015ad8e;
                                    uVar9 = var_60h + 0x28;
                                }
                                func_0x000180459c3c(iVar12, uVar9);
                            }
                            var_140h._0_4_ = (uint32_t)var_140h | 1;
                            func_0x00018015c690(arg1, puVar16, iVar10, iVar6);
                            iVar19 = (int32_t)var_150h;
                            uVar9 = iVar13;
                        }
                    }
                }
                uVar20 = iVar19 + 1;
                var_150h = (int64_t)uVar20;
                bVar27 = uVar20 == (uint32_t)uVar9;
            } while ((int32_t)uVar20 <= (int32_t)(uint32_t)uVar9);
        }
        puVar16 = (uint64_t *)((int64_t)puVar16 + 0x14);
    }
code_r0x00018015ad95:
    _var_108h = ZEXT816(0);
    if (*(int64_t *)(puVar15 + 0x78) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(puVar15 + 0x78) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    _var_108h = *(undefined (*) [16])(puVar15 + 0x70);
    *(undefined8 *)(puVar15 + -8) = 0x18015adc1;
    func_0x00018015af60(arg1, &var_108h);
    if (0xf < (uint64_t)var_80h) {
        iVar13 = var_98h;
        if ((0xfff < var_80h + 1U) && (iVar13 = *(int64_t *)(var_98h + -8), 0x1f < (var_98h - iVar13) - 8U)) {
            pcVar4 = (code *)swi(0x29);
            (*pcVar4)(5);
            puVar15 = puVar15 + 8;
            iVar13 = var_98h;
        }
        *(undefined8 *)(puVar15 + -8) = 0x18015ae04;
        func_0x000180459c3c(iVar13);
    }
    piVar18 = *(int64_t **)(puVar15 + 0x78);
    if (piVar18 != (int64_t *)0x0) {
        LOCK();
        piVar21 = piVar18 + 1;
        iVar2 = *(int32_t *)piVar21;
        *(int32_t *)piVar21 = *(int32_t *)piVar21 + iVar19;
        UNLOCK();
        if (iVar2 == 1) {
            pcVar4 = *(code **)*piVar18;
            *(undefined8 *)(puVar15 + -8) = 0x18015ae24;
            (*pcVar4)(piVar18);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar18 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + iVar19;
            UNLOCK();
            if (iVar2 == 1) {
                pcVar4 = *(code **)(*piVar18 + 8);
                *(undefined8 *)(puVar15 + -8) = 0x18015ae39;
                (*pcVar4)(piVar18);
            }
        }
    }
    *(undefined8 *)(puVar15 + -8) = 0x18015ae45;
    func_0x000180459870(var_58h ^ (uint64_t)puVar15);
    return;
}

// ============================================================
// Function: FUN_18015aea0
// Address: 0x18015aea0
// Size: 188 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h

int64_t fcn.18015aea0(int64_t arg1, int64_t arg2)
{
    undefined (*pauVar1) [16];
    undefined (*pauVar2) [16];
    char in_R8B;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_28h;
    
    if ((in_R8B != '\0') && (*(char *)(arg1 + 0x131) != '\0')) {
        *(undefined *)(arg1 + 0x133) = 1;
    }
    pauVar2 = (undefined (*) [16])fcn.180459890(0x78);
    *pauVar2 = ZEXT816(0);
    *(undefined4 *)(*pauVar2 + 8) = 1;
    *(undefined4 *)(*pauVar2 + 0xc) = 1;
    *(undefined8 *)*pauVar2 = 0x180645d88;
    pauVar1 = pauVar2 + 1;
    *pauVar1 = ZEXT816(0);
    pauVar2[2] = ZEXT816(0);
    pauVar2[3] = ZEXT816(0);
    pauVar2[4] = ZEXT816(0);
    pauVar2[5] = ZEXT816(0);
    pauVar2[6] = ZEXT816(0);
    *(undefined8 *)pauVar2[7] = 0;
    fcn.1801655b0(pauVar1);
    *(undefined (**) [16])arg2 = pauVar1;
    *(undefined (**) [16])(arg2 + 8) = pauVar2;
    fcn.180150230(pauVar2[2] + 8, arg1);
    return arg2;
}

// ============================================================
// Function: FUN_18015af60
// Address: 0x18015af60
// Size: 2350 bytes
// ============================================================
undefined8 fcn.18015af60(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int64_t **ppiVar3;
    int32_t iVar4;
    int64_t *piVar5;
    char *pcVar6;
    code *pcVar7;
    undefined4 uVar8;
    undefined4 uVar9;
    undefined4 uVar10;
    int64_t *piVar11;
    uint64_t uVar12;
    undefined8 uVar13;
    uint64_t uVar14;
    int64_t *piVar15;
    int64_t *piVar16;
    undefined (*pauVar17) [16];
    undefined8 *puVar18;
    char *pcVar19;
    int64_t iVar20;
    undefined *puVar21;
    undefined *puVar22;
    int64_t iVar23;
    undefined *puVar24;
    undefined *puVar25;
    int64_t *piVar26;
    undefined4 *puVar27;
    uint64_t uVar28;
    undefined8 *puVar29;
    undefined *puVar30;
    uint64_t uVar31;
    undefined *puVar32;
    uint64_t uVar33;
    undefined auVar34 [16];
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    undefined8 uStack_d0;
    undefined auStack_c8 [8];
    undefined auStack_c0 [24];
    int64_t var_a8h;
    int64_t var_a0h;
    int64_t var_98h;
    int64_t var_90h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    
    puVar21 = auStack_c8;
    puVar32 = auStack_c8;
    var_20h = arg2;
    if ((int32_t)((*(int64_t **)arg2)[1] - **(int64_t **)arg2 >> 3) * -0x49249249 < 1) {
        func_0x000180008300(arg2);
        uVar13 = 0;
    } else {
        func_0x00018015c410();
        fcn.180150230(*(int64_t *)arg2 + 0x40, arg1);
        ppiVar3 = (int64_t **)(arg1 + 0xe8);
        if (*(int64_t *)(arg2 + 8) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_a0h = *(int64_t *)arg2;
        var_98h = *(int64_t *)(arg2 + 8);
        var_a8h = (int64_t)&var_a0h;
        uVar33 = *(uint64_t *)(arg1 + 0x100);
        iVar23 = *(int64_t *)(arg1 + 0xf0);
        piVar5 = *ppiVar3;
        uVar31 = iVar23 - (int64_t)piVar5 >> 4;
        uVar12 = 0;
        if (uVar33 < uVar31) {
            func_0x00018000d5d0(piVar5 + uVar33 * 2, iVar23);
            *(int64_t **)(arg1 + 0xf0) = piVar5 + uVar33 * 2;
            puVar22 = auStack_c8;
        } else {
            puVar22 = auStack_c8;
            if (uVar31 < uVar33) {
                uVar14 = *(int64_t *)(arg1 + 0xf8) - (int64_t)piVar5 >> 4;
                if (uVar14 < uVar33) {
                    puVar22 = auStack_c8;
                    if (0xfffffffffffffff < uVar33) goto code_r0x00018015b876;
                    puVar22 = auStack_c8;
                    if ((0xfffffffffffffff - (uVar14 >> 1) < uVar14) ||
                       ((uVar14 = uVar14 + (uVar14 >> 1), uVar28 = uVar33, uVar33 <= uVar14 &&
                        (puVar22 = auStack_c8, uVar28 = uVar14, 0xfffffffffffffff < uVar14))))
                    goto code_r0x00018015b870;
                    uVar14 = uVar28 * 0x10;
                    if (uVar14 != 0) {
                        if (uVar14 < 0x1000) {
                            uVar12 = fcn.180459890();
                            puVar32 = auStack_c8;
                        } else {
                            puVar22 = auStack_c8;
                            if (uVar14 + 0x27 <= uVar14) goto code_r0x00018015b870;
                            iVar23 = fcn.180459890(uVar14 + 0x27);
                            if (iVar23 == 0) {
                                pcVar7 = (code *)swi(0x29);
                                iVar23 = (*pcVar7)(5);
                                puVar21 = auStack_c0;
                            }
                            uVar12 = iVar23 + 0x27U & 0xffffffffffffffe0;
                            *(int64_t *)(uVar12 - 8) = iVar23;
                            puVar32 = puVar21;
                        }
                    }
                    var_60h = uVar31 * 0x10 + uVar12;
                    puVar29 = (undefined8 *)var_60h;
                    for (iVar23 = uVar33 - uVar31; iVar23 != 0; iVar23 = iVar23 + -1) {
                        *puVar29 = 0;
                        puVar29[1] = 0;
                        puVar29 = puVar29 + 2;
                    }
                    *(undefined8 *)(puVar32 + -8) = 0x18015b11c;
                    var_78h = (int64_t)ppiVar3;
                    var_68h = uVar28;
                    func_0x00018000d5d0(puVar29, puVar29);
                    uVar13 = *(undefined8 *)(arg1 + 0xf0);
                    piVar5 = *ppiVar3;
                    *(undefined8 *)(puVar32 + -8) = 0x18015b12f;
                    var_58h = (int64_t)puVar29;
                    func_0x0001801658a0(piVar5, uVar13, uVar12);
                    var_70h = 0;
                    *(undefined8 *)(puVar32 + -8) = 0x18015b148;
                    func_0x000180165a00(ppiVar3, uVar12, uVar33);
                    *(undefined8 *)(puVar32 + -8) = 0x18015b151;
                    func_0x000180165990(&var_78h);
                    puVar22 = puVar32;
                    arg2 = var_20h;
                } else {
                    uVar13 = func_0x000180165520(iVar23, uVar33 - uVar31);
                    *(undefined8 *)(arg1 + 0xf0) = uVar13;
                    puVar22 = auStack_c8;
                }
            }
        }
        piVar5 = *(int64_t **)(arg1 + 0xf0);
        if (piVar5 == *(int64_t **)(arg1 + 0xf8)) {
            iVar23 = (int64_t)piVar5 - (int64_t)*ppiVar3 >> 4;
            if (iVar23 == 0xfffffffffffffff) {
code_r0x00018015b876:
                *(undefined8 *)(puVar22 + -8) = 0x18015b87b;
                func_0x000180010010();
code_r0x00018015b87c:
                *(undefined8 *)(puVar22 + -8) = 0x18015b881;
                func_0x000180060370();
                pcVar7 = (code *)swi(3);
                uVar13 = (*pcVar7)();
                return uVar13;
            }
            uVar33 = iVar23 + 1;
            uVar12 = (int64_t)*(int64_t **)(arg1 + 0xf8) - (int64_t)*ppiVar3 >> 4;
            var_18h = 0xfffffffffffffff;
            if ((uVar12 <= 0xfffffffffffffff - (uVar12 >> 1)) &&
               (var_18h = (uVar12 >> 1) + uVar12, (uint64_t)var_18h < uVar33)) {
                var_18h = uVar33;
            }
            *(undefined8 *)(puVar22 + -8) = 0x18015b1f0;
            piVar11 = (int64_t *)func_0x000180047650(uVar12, &var_18h);
            var_60h = (int64_t)(piVar11 + iVar23 * 2);
            piVar2 = (int64_t *)(var_60h + 0x10);
            var_68h = var_18h;
            *(int64_t *)var_60h = 0;
            *(int64_t *)(var_60h + 8) = 0;
            if (var_98h != 0) {
                LOCK();
                *(int32_t *)(var_98h + 8) = *(int32_t *)(var_98h + 8) + 1;
                UNLOCK();
            }
            *(int64_t *)var_60h = var_a0h;
            *(int64_t *)(var_60h + 8) = var_98h;
            piVar16 = *(int64_t **)(arg1 + 0xf0);
            piVar15 = *ppiVar3;
            piVar26 = piVar11;
            var_78h = (int64_t)ppiVar3;
            var_58h = (int64_t)piVar2;
            if (piVar5 != piVar16) {
                *(undefined8 *)(puVar22 + -8) = 0x18015b24e;
                func_0x0001801658a0(piVar15, piVar5, piVar11);
                piVar16 = *(int64_t **)(arg1 + 0xf0);
                piVar15 = piVar5;
                piVar26 = piVar2;
                var_60h = (int64_t)piVar11;
            }
            *(undefined8 *)(puVar22 + -8) = 0x18015b261;
            func_0x0001801658a0(piVar15, piVar16, piVar26);
            var_70h = 0;
            *(undefined8 *)(puVar22 + -8) = 0x18015b27a;
            func_0x000180165a00(ppiVar3, piVar11, uVar33);
            *(undefined8 *)(puVar22 + -8) = 0x18015b283;
            func_0x000180165990(&var_78h);
        } else {
            *piVar5 = 0;
            piVar5[1] = 0;
            if (var_98h != 0) {
                LOCK();
                *(int32_t *)(var_98h + 8) = *(int32_t *)(var_98h + 8) + 1;
                UNLOCK();
            }
            *piVar5 = var_a0h;
            piVar5[1] = var_98h;
            *(int64_t *)(arg1 + 0xf0) = *(int64_t *)(arg1 + 0xf0) + 0x10;
        }
        auVar34._0_8_ = *(int64_t *)(arg1 + 0x100) + 1;
        auVar34._8_8_ = *(int64_t *)(arg1 + 0x108) + 1;
        *(undefined (*) [16])(arg1 + 0x100) = auVar34;
        *(undefined8 *)(puVar22 + -8) = 0x18015b2a2;
        func_0x000180008300(&var_a0h);
        _var_90h = ZEXT816(0);
        var_80h = 0;
        if (*(int64_t *)(arg1 + 0x528) != 0) {
            pcVar6 = (*(char ***)arg2)[1];
            for (pcVar19 = **(char ***)arg2; uVar33 = arg1, pcVar19 != pcVar6; pcVar19 = pcVar19 + 0x38) {
                puVar30 = (undefined *)0x0;
                puVar32 = (undefined *)var_88h;
                if (var_88h == var_80h) {
                    iVar23 = var_88h - var_90h >> 6;
                    if (iVar23 == 0x3ffffffffffffff) {
                        *(undefined8 *)(puVar22 + -8) = 0x18015b88d;
                        func_0x000180010010();
                        pcVar7 = (code *)swi(3);
                        uVar13 = (*pcVar7)();
                        return uVar13;
                    }
                    var_a8h = iVar23 + 1;
                    uVar12 = var_80h - var_90h >> 6;
                    if (0x3ffffffffffffff - (uVar12 >> 1) < uVar12) {
                        var_18h = -0x40;
                        uVar12 = 0xffffffffffffffe7;
code_r0x00018015b3ad:
                        *(undefined8 *)(puVar22 + -8) = 0x18015b3b2;
                        iVar20 = fcn.180459890(uVar12);
                        if (iVar20 != 0) {
                            puVar30 = (undefined *)(iVar20 + 0x27U & 0xffffffffffffffe0);
                            *(int64_t *)(puVar30 + -8) = iVar20;
                            goto code_r0x00018015b3d7;
                        }
code_r0x00018015b778:
                        pcVar7 = (code *)swi(0x29);
                        (*pcVar7)(5);
                        puVar22 = puVar22 + 8;
                        arg2 = var_20h;
                        break;
                    }
                    uVar12 = (uVar12 >> 1) + uVar12;
                    uVar33 = var_a8h;
                    if ((uint64_t)var_a8h <= uVar12) {
                        uVar33 = uVar12;
                    }
                    if (0x3ffffffffffffff < uVar33) {
code_r0x00018015b882:
                        *(undefined8 *)(puVar22 + -8) = 0x18015b887;
                        fcn.180004720();
                        pcVar7 = (code *)swi(3);
                        uVar13 = (*pcVar7)();
                        return uVar13;
                    }
                    uVar33 = uVar33 * 0x40;
                    var_18h = uVar33;
                    if (uVar33 != 0) {
                        if (0xfff < uVar33) {
                            uVar12 = uVar33 + 0x27;
                            if (uVar12 <= uVar33) goto code_r0x00018015b882;
                            goto code_r0x00018015b3ad;
                        }
                        *(undefined8 *)(puVar22 + -8) = 0x18015b3d1;
                        puVar30 = (undefined *)fcn.180459890(uVar33);
                    }
code_r0x00018015b3d7:
                    puVar29 = (undefined8 *)(puVar30 + iVar23 * 0x40);
                    *puVar29 = 0;
                    puVar29[1] = 0;
                    puVar29[2] = 0;
                    puVar29[3] = 0;
                    *(undefined (*) [16])(puVar29 + 4) = ZEXT816(0);
                    puVar29[6] = 0;
                    puVar29[7] = 0xf;
                    *(undefined *)(puVar29 + 4) = 0;
                    uVar33 = var_88h;
                    if (puVar32 == (undefined *)var_88h) {
                        if (var_90h != var_88h) {
                            pauVar17 = (undefined (*) [16])(puVar30 + 0x20);
                            puVar27 = (undefined4 *)(var_90h + 0x20);
                            puVar32 = puVar30;
                            puVar24 = (undefined *)var_90h;
                            do {
                                *puVar32 = *puVar24;
                                *(undefined4 *)(puVar32 + 4) = *(undefined4 *)(puVar24 + 4);
                                *(undefined4 *)(puVar32 + 8) = *(undefined4 *)(puVar24 + 8);
                                *(undefined4 *)(puVar32 + 0xc) = *(undefined4 *)(puVar24 + 0xc);
                                *(undefined4 *)(puVar32 + 0x10) = *(undefined4 *)(puVar24 + 0x10);
                                *(undefined4 *)(puVar32 + 0x14) = *(undefined4 *)(puVar24 + 0x14);
                                *(undefined4 *)(puVar32 + 0x18) = *(undefined4 *)(puVar24 + 0x18);
                                *pauVar17 = ZEXT816(0);
                                *(undefined8 *)pauVar17[1] = 0;
                                *(undefined8 *)(pauVar17[1] + 8) = 0;
                                uVar10 = puVar27[1];
                                uVar8 = puVar27[2];
                                uVar9 = puVar27[3];
                                *(undefined4 *)*pauVar17 = *puVar27;
                                *(undefined4 *)(*pauVar17 + 4) = uVar10;
                                *(undefined4 *)(*pauVar17 + 8) = uVar8;
                                *(undefined4 *)(*pauVar17 + 0xc) = uVar9;
                                pauVar17[1] = *(undefined (*) [16])(puVar27 + 4);
                                *(undefined8 *)(puVar27 + 4) = 0;
                                *(undefined8 *)(puVar27 + 6) = 0xf;
                                *(undefined *)puVar27 = 0;
                                puVar32 = puVar32 + 0x40;
                                puVar24 = puVar24 + 0x40;
                                pauVar17 = pauVar17 + 4;
                                puVar27 = puVar27 + 0x10;
                            } while (puVar24 != (undefined *)var_88h);
                        }
                    } else {
                        if ((undefined *)var_90h != puVar32) {
                            pauVar17 = (undefined (*) [16])(puVar30 + 0x20);
                            puVar27 = (undefined4 *)(var_90h + 0x20);
                            puVar24 = puVar30;
                            puVar25 = (undefined *)var_90h;
                            do {
                                *puVar24 = *puVar25;
                                *(undefined4 *)(puVar24 + 4) = *(undefined4 *)(puVar25 + 4);
                                *(undefined4 *)(puVar24 + 8) = *(undefined4 *)(puVar25 + 8);
                                *(undefined4 *)(puVar24 + 0xc) = *(undefined4 *)(puVar25 + 0xc);
                                *(undefined4 *)(puVar24 + 0x10) = *(undefined4 *)(puVar25 + 0x10);
                                *(undefined4 *)(puVar24 + 0x14) = *(undefined4 *)(puVar25 + 0x14);
                                *(undefined4 *)(puVar24 + 0x18) = *(undefined4 *)(puVar25 + 0x18);
                                *pauVar17 = ZEXT816(0);
                                *(undefined8 *)pauVar17[1] = 0;
                                *(undefined8 *)(pauVar17[1] + 8) = 0;
                                uVar10 = puVar27[1];
                                uVar8 = puVar27[2];
                                uVar9 = puVar27[3];
                                *(undefined4 *)*pauVar17 = *puVar27;
                                *(undefined4 *)(*pauVar17 + 4) = uVar10;
                                *(undefined4 *)(*pauVar17 + 8) = uVar8;
                                *(undefined4 *)(*pauVar17 + 0xc) = uVar9;
                                pauVar17[1] = *(undefined (*) [16])(puVar27 + 4);
                                *(undefined8 *)(puVar27 + 4) = 0;
                                *(undefined8 *)(puVar27 + 6) = 0xf;
                                *(undefined *)puVar27 = 0;
                                puVar24 = puVar24 + 0x40;
                                puVar25 = puVar25 + 0x40;
                                pauVar17 = pauVar17 + 4;
                                puVar27 = puVar27 + 0x10;
                            } while (puVar25 != puVar32);
                        }
                        if (puVar32 != (undefined *)var_88h) {
                            pauVar17 = (undefined (*) [16])(puVar29 + 0xc);
                            puVar27 = (undefined4 *)((int64_t)puVar32 + 0x20);
                            puVar18 = puVar29;
                            do {
                                *(undefined *)(puVar18 + 8) = *puVar32;
                                *(undefined4 *)((int64_t)puVar18 + 0x44) = *(undefined4 *)(puVar32 + 4);
                                *(undefined4 *)(puVar18 + 9) = *(undefined4 *)(puVar32 + 8);
                                *(undefined4 *)((int64_t)puVar18 + 0x4c) = *(undefined4 *)(puVar32 + 0xc);
                                *(undefined4 *)(puVar18 + 10) = *(undefined4 *)(puVar32 + 0x10);
                                *(undefined4 *)((int64_t)puVar18 + 0x54) = *(undefined4 *)(puVar32 + 0x14);
                                *(undefined4 *)(puVar18 + 0xb) = *(undefined4 *)(puVar32 + 0x18);
                                *pauVar17 = ZEXT816(0);
                                *(undefined8 *)pauVar17[1] = 0;
                                *(undefined8 *)((int64_t)pauVar17[1] + 8) = 0;
                                uVar10 = puVar27[1];
                                uVar8 = puVar27[2];
                                uVar9 = puVar27[3];
                                *(undefined4 *)*pauVar17 = *puVar27;
                                *(undefined4 *)((int64_t)*pauVar17 + 4) = uVar10;
                                *(undefined4 *)((int64_t)*pauVar17 + 8) = uVar8;
                                *(undefined4 *)((int64_t)*pauVar17 + 0xc) = uVar9;
                                pauVar17[1] = *(undefined (*) [16])(puVar27 + 4);
                                *(undefined8 *)(puVar27 + 4) = 0;
                                *(undefined8 *)(puVar27 + 6) = 0xf;
                                *(undefined *)puVar27 = 0;
                                puVar32 = puVar32 + 0x40;
                                pauVar17 = pauVar17 + 4;
                                puVar27 = puVar27 + 0x10;
                                puVar18 = puVar18 + 8;
                            } while (puVar32 != (undefined *)var_88h);
                        }
                    }
                    if (var_90h != 0) {
                        iVar23 = var_90h;
                        if (var_90h != var_88h) {
                            do {
                                uVar12 = *(uint64_t *)(iVar23 + 0x38);
                                if (0xf < uVar12) {
                                    iVar20 = *(int64_t *)(iVar23 + 0x20);
                                    uVar31 = uVar12 + 1;
                                    if (0xfff < uVar31) {
                                        if (0x1f < (iVar20 - *(int64_t *)(iVar20 + -8)) - 8U) goto code_r0x00018015b778;
                                        uVar31 = uVar12 + 0x28;
                                        iVar20 = *(int64_t *)(iVar20 + -8);
                                    }
                                    *(undefined8 *)(puVar22 + -8) = 0x18015b61d;
                                    func_0x000180459c3c(iVar20, uVar31);
                                }
                                *(undefined8 *)(iVar23 + 0x30) = 0;
                                *(undefined8 *)(iVar23 + 0x38) = 0xf;
                                *(undefined *)(iVar23 + 0x20) = 0;
                                iVar23 = iVar23 + 0x40;
                            } while (iVar23 != uVar33);
                            iVar23 = var_90h;
                        }
                        uVar12 = var_80h - iVar23 & 0xffffffffffffffc0;
                        if (0xfff < uVar12) {
                            if (0x1f < (iVar23 - *(int64_t *)(iVar23 + -8)) - 8U) goto code_r0x00018015b778;
                            uVar12 = uVar12 + 0x27;
                            iVar23 = *(int64_t *)(iVar23 + -8);
                        }
                        *(undefined8 *)(puVar22 + -8) = 0x18015b674;
                        func_0x000180459c3c(iVar23, uVar12);
                    }
                    var_88h = (int64_t)(puVar30 + var_a8h * 0x40);
                    var_90h = (int64_t)puVar30;
                    var_80h = (int64_t)(puVar30 + var_18h);
                } else {
                    *(undefined8 *)var_88h = 0;
                    *(undefined8 *)(var_88h + 8) = 0;
                    *(undefined8 *)(var_88h + 0x10) = 0;
                    *(undefined8 *)(var_88h + 0x18) = 0;
                    *(undefined (*) [16])(var_88h + 0x20) = ZEXT816(0);
                    *(undefined8 *)(var_88h + 0x30) = 0;
                    *(undefined8 *)(var_88h + 0x38) = 0xf;
                    *(undefined *)(var_88h + 0x20) = 0;
                    var_88h = var_88h + 0x40;
                    puVar29 = (undefined8 *)puVar32;
                }
                *(bool *)puVar29 = *pcVar19 == '\0';
                *(undefined4 *)((int64_t)puVar29 + 4) = *(undefined4 *)(pcVar19 + 4);
                *(undefined4 *)(puVar29 + 1) = *(undefined4 *)(pcVar19 + 8);
                uVar33 = *(uint64_t *)(pcVar19 + 4);
                uVar31 = (uint64_t)(int32_t)uVar33;
                iVar23 = *(int64_t *)(arg1 + 0x40);
                uVar12 = (*(int64_t *)(arg1 + 0x48) - iVar23 >> 3) * 0x6db6db6db6db6db7;
                if (uVar12 < uVar31 || uVar12 - uVar31 == 0) goto code_r0x00018015b87c;
                *(undefined8 *)(puVar22 + -8) = 0x18015b6f1;
                uVar10 = func_0x00018015d7b0(arg1 + 0x40, uVar31 * 0x38 + iVar23, uVar33 >> 0x20);
                *(undefined4 *)((int64_t)puVar29 + 0xc) = uVar10;
                *(undefined4 *)(puVar29 + 2) = *(undefined4 *)(pcVar19 + 0xc);
                *(undefined4 *)((int64_t)puVar29 + 0x14) = *(undefined4 *)(pcVar19 + 0x10);
                uVar33 = *(uint64_t *)(pcVar19 + 0xc);
                uVar31 = (uint64_t)(int32_t)uVar33;
                iVar23 = *(int64_t *)(arg1 + 0x40);
                uVar12 = (*(int64_t *)(arg1 + 0x48) - iVar23 >> 3) * 0x6db6db6db6db6db7;
                if (uVar12 < uVar31 || uVar12 - uVar31 == 0) goto code_r0x00018015b87c;
                *(undefined8 *)(puVar22 + -8) = 0x18015b73d;
                uVar10 = func_0x00018015d7b0(arg1 + 0x40, uVar31 * 0x38 + iVar23, uVar33 >> 0x20);
                *(undefined4 *)(puVar29 + 3) = uVar10;
                puVar18 = (undefined8 *)(pcVar19 + 0x18);
                if (puVar29 + 4 != puVar18) {
                    uVar13 = *(undefined8 *)(pcVar19 + 0x28);
                    if (0xf < *(uint64_t *)(pcVar19 + 0x30)) {
                        puVar18 = (undefined8 *)*puVar18;
                    }
                    *(undefined8 *)(puVar22 + -8) = 0x18015b763;
                    func_0x00018000f180(puVar29 + 4, puVar18, uVar13);
                }
                arg2 = var_20h;
            }
            piVar5 = *(int64_t **)(uVar33 + 0x528);
            if (piVar5 == (int64_t *)0x0) {
                *(undefined8 *)(puVar22 + -8) = 0x18015b86f;
                func_0x000180454690();
code_r0x00018015b870:
                *(undefined8 *)(puVar22 + -8) = 0x18015b875;
                fcn.180004720();
                pcVar7 = (code *)swi(3);
                uVar13 = (*pcVar7)();
                return uVar13;
            }
            pcVar7 = *(code **)(*piVar5 + 0x10);
            *(undefined8 *)(puVar22 + -8) = 0x18015b79d;
            (*pcVar7)(piVar5, &var_90h);
        }
        if (var_90h != 0) {
            iVar23 = var_88h;
            iVar20 = var_90h;
            if (var_90h != var_88h) {
                do {
                    *(undefined8 *)(puVar22 + -8) = 0x18015b7bc;
                    func_0x000180004e40(iVar20 + 0x20);
                    iVar20 = iVar20 + 0x40;
                } while (iVar20 != iVar23);
            }
            uVar33 = var_90h;
            if (0xfff < (var_80h - var_90h & 0xffffffffffffffc0U)) {
                uVar33 = *(uint64_t *)(var_90h - 8);
                uVar12 = (var_90h - uVar33) - 8;
                if (0x1f < uVar12) {
                    pcVar7 = (code *)swi(0x29);
                    (*pcVar7)(5);
                    puVar22 = puVar22 + 8;
                    uVar33 = uVar12;
                }
            }
            *(undefined8 *)(puVar22 + -8) = 0x18015b803;
            func_0x000180459c3c(uVar33);
            _var_90h = ZEXT816(0);
            var_80h = 0;
        }
        piVar5 = *(int64_t **)(arg2 + 8);
        if (piVar5 != (int64_t *)0x0) {
            LOCK();
            piVar2 = piVar5 + 1;
            iVar4 = *(int32_t *)piVar2;
            *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
            UNLOCK();
            if (iVar4 == 1) {
                pcVar7 = *(code **)*piVar5;
                *(undefined8 *)(puVar22 + -8) = 0x18015b835;
                (*pcVar7)(piVar5);
                LOCK();
                piVar1 = (int32_t *)((int64_t)piVar5 + 0xc);
                iVar4 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar4 == 1) {
                    pcVar7 = *(code **)(*piVar5 + 8);
                    *(undefined8 *)(puVar22 + -8) = 0x18015b848;
                    (*pcVar7)(piVar5);
                }
            }
        }
        uVar13 = 1;
    }
    return uVar13;
}

// ============================================================
// Function: FUN_18015b890
// Address: 0x18015b890
// Size: 542 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_98h
// WARNING: [rz-ghidra] Detected overlap for variable var_24h

void fcn.18015b890(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int32_t *piVar1;
    int32_t iVar2;
    int64_t iVar3;
    int64_t iVar4;
    int64_t iVar5;
    int64_t *piVar6;
    int32_t iVar7;
    int32_t iVar8;
    int64_t *piVar9;
    int64_t *piVar10;
    int32_t iVar11;
    int32_t iVar12;
    bool bVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_98h;
    int64_t var_88h;
    int64_t var_80h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_60h;
    int64_t var_58h;
    undefined4 uStack_50;
    undefined4 uStack_4c;
    
    if (*(int64_t *)(arg2 + 8) != 0) {
        LOCK();
        piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
        *piVar1 = *piVar1 + 1;
        UNLOCK();
    }
    var_68h = *(int64_t *)arg2;
    var_60h = *(int64_t *)(arg2 + 8);
    var_10h = arg2;
    var_18h = arg3;
    var_78h = arg2;
    func_0x00018015bab0(0, &var_68h);
    piVar10 = *(int64_t **)arg1;
    while (iVar4 = var_18h, piVar10 < *(int64_t **)(arg1 + 8)) {
        piVar6 = piVar10 + 1;
        iVar2 = *(int32_t *)piVar6;
        iVar7 = *(int32_t *)piVar10;
        bVar13 = SBORROW4(iVar7, iVar2);
        iVar8 = iVar7 - iVar2;
        if (iVar7 == iVar2) {
            bVar13 = SBORROW4(*(int32_t *)((int64_t)piVar10 + 4), *(int32_t *)((int64_t)piVar10 + 0xc));
            iVar8 = *(int32_t *)((int64_t)piVar10 + 4) - *(int32_t *)((int64_t)piVar10 + 0xc);
        }
        piVar9 = piVar10;
        if (bVar13 == iVar8 < 0) {
            piVar9 = piVar6;
        }
        iVar3 = *piVar9;
        if (*(int64_t *)(arg2 + 8) != 0) {
            LOCK();
            piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
            *piVar1 = *piVar1 + 1;
            UNLOCK();
        }
        var_68h = *(int64_t *)arg2;
        var_60h = *(int64_t *)(arg2 + 8);
        var_70h = (int64_t)&var_68h;
        func_0x00018015c7f0(arg1 + 0x40, &var_20h, iVar3, var_18h);
        iVar2 = (int32_t)var_20h;
        var_58h._0_4_ = *(undefined4 *)iVar4;
        var_58h._4_4_ = *(undefined4 *)(iVar4 + 4);
        uStack_50 = *(undefined4 *)(iVar4 + 8);
        uStack_4c = *(undefined4 *)(iVar4 + 0xc);
        iVar4 = CONCAT44(var_20h._4_4_, (int32_t)var_20h);
        var_8h._0_1_ = 0;
        var_80h = iVar3;
        func_0x0001801633e0(var_68h, &var_8h, &var_80h, &var_88h, &var_58h);
        iVar5 = var_60h;
        *(undefined *)(arg1 + 0x2c8) = 1;
        *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
        if (var_60h != 0) {
            LOCK();
            piVar1 = (int32_t *)(var_60h + 8);
            iVar7 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar7 == 1) {
                (***(code ***)var_60h)(var_60h);
                LOCK();
                piVar1 = (int32_t *)(iVar5 + 0xc);
                iVar7 = *piVar1;
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (iVar7 == 1) {
                    (**(code **)(*(int64_t *)iVar5 + 8))(iVar5);
                }
            }
        }
        *piVar10 = iVar4;
        *piVar6 = iVar4;
        *(undefined *)((int64_t)piVar10 + 0x12) = 1;
        piVar10 = (int64_t *)((int64_t)piVar10 + 0x14);
        for (piVar6 = piVar10; arg2 = var_78h, piVar6 < *(int64_t **)(arg1 + 8);
            piVar6 = (int64_t *)((int64_t)piVar6 + 0x14)) {
            iVar7 = (int32_t)((uint64_t)*piVar6 >> 0x20);
            iVar12 = (int32_t)((uint64_t)iVar3 >> 0x20);
            iVar8 = (int32_t)iVar3;
            iVar11 = (int32_t)*piVar6;
            if (iVar11 == iVar8) {
                iVar7 = (iVar7 - iVar12) + var_20h._4_4_;
            }
            *(int32_t *)piVar6 = (iVar2 - iVar8) + iVar11;
            *(int32_t *)((int64_t)piVar6 + 4) = iVar7;
            iVar7 = (int32_t)((uint64_t)piVar6[1] >> 0x20);
            iVar11 = (int32_t)piVar6[1];
            if (iVar11 == iVar8) {
                iVar7 = (iVar7 - iVar12) + var_20h._4_4_;
            }
            *(int32_t *)(piVar6 + 1) = (iVar11 - iVar8) + iVar2;
            *(int32_t *)((int64_t)piVar6 + 0xc) = iVar7;
        }
    }
    piVar10 = *(int64_t **)(arg2 + 8);
    if (piVar10 != (int64_t *)0x0) {
        LOCK();
        piVar6 = piVar10 + 1;
        iVar2 = *(int32_t *)piVar6;
        *(int32_t *)piVar6 = *(int32_t *)piVar6 + -1;
        UNLOCK();
        if (iVar2 == 1) {
            (**(code **)*piVar10)(piVar10);
            LOCK();
            piVar1 = (int32_t *)((int64_t)piVar10 + 0xc);
            iVar2 = *piVar1;
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (iVar2 == 1) {
                (**(code **)(*piVar10 + 8))(piVar10);
            }
        }
    }
    return;
}

// ============================================================
// Function: FUN_18015bab0
// Address: 0x18015bab0
// Size: 277 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015bab0(int64_t arg1, int64_t arg2)
{
    int32_t *piVar1;
    int64_t *piVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 uVar5;
    undefined8 uVar6;
    int64_t *piVar7;
    int32_t iVar8;
    undefined8 *puVar9;
    undefined8 *puVar10;
    undefined8 *puVar11;
    bool bVar12;
    bool bVar13;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_28h;
    
    puVar9 = *(undefined8 **)arg1;
    do {
        if (*(undefined8 **)(arg1 + 8) <= puVar9) {
            piVar7 = *(int64_t **)(arg2 + 8);
            if (piVar7 != (int64_t *)0x0) {
                LOCK();
                piVar2 = piVar7 + 1;
                iVar3 = *(int32_t *)piVar2;
                *(int32_t *)piVar2 = *(int32_t *)piVar2 + -1;
                UNLOCK();
                if (iVar3 == 1) {
                    (**(code **)*piVar7)(piVar7);
                    LOCK();
                    piVar1 = (int32_t *)((int64_t)piVar7 + 0xc);
                    iVar3 = *piVar1;
                    *piVar1 = *piVar1 + -1;
                    UNLOCK();
                    if (iVar3 == 1) {
                        (**(code **)(*piVar7 + 8))(piVar7);
                    }
                }
            }
            return;
        }
        puVar11 = puVar9 + 1;
        iVar3 = *(int32_t *)puVar11;
        iVar4 = *(int32_t *)puVar9;
        bVar12 = SBORROW4(iVar4, iVar3);
        iVar8 = iVar4 - iVar3;
        if (iVar4 == iVar3) {
            if (*(int32_t *)((int64_t)puVar9 + 4) != *(int32_t *)((int64_t)puVar9 + 0xc)) {
                bVar12 = SBORROW4(*(int32_t *)((int64_t)puVar9 + 4), *(int32_t *)((int64_t)puVar9 + 0xc));
                iVar8 = *(int32_t *)((int64_t)puVar9 + 4) - *(int32_t *)((int64_t)puVar9 + 0xc);
                goto code_r0x00018015bb03;
            }
        } else {
code_r0x00018015bb03:
            puVar10 = puVar11;
            if (bVar12 != iVar8 < 0) {
                puVar10 = puVar9;
            }
            uVar5 = *puVar10;
            bVar13 = SBORROW4(iVar4, iVar3);
            iVar8 = iVar4 - iVar3;
            bVar12 = iVar4 == iVar3;
            if (bVar12) {
                iVar3 = *(int32_t *)((int64_t)puVar9 + 0xc);
                iVar4 = *(int32_t *)((int64_t)puVar9 + 4);
                bVar13 = SBORROW4(iVar4, iVar3);
                iVar8 = iVar4 - iVar3;
                bVar12 = iVar4 == iVar3;
            }
            if (!bVar12 && bVar13 == iVar8 < 0) {
                puVar11 = puVar9;
            }
            uVar6 = *puVar11;
            if (*(int64_t *)(arg2 + 8) != 0) {
                LOCK();
                piVar1 = (int32_t *)(*(int64_t *)(arg2 + 8) + 8);
                *piVar1 = *piVar1 + 1;
                UNLOCK();
            }
            _var_28h = *(undefined (*) [16])arg2;
            func_0x00018015bca0(arg1, &var_28h, uVar5, uVar6);
            func_0x00018015c720(arg1, puVar9, uVar5, uVar6);
        }
        puVar9 = (undefined8 *)((int64_t)puVar9 + 0x14);
    } while( true );
}

// ============================================================
// Function: FUN_18015bbd0
// Address: 0x18015bbd0
// Size: 197 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_48h
// WARNING: [rz-ghidra] Detected overlap for variable var_1ch
// WARNING: [rz-ghidra] Detected overlap for variable var_b2h
// WARNING: [rz-ghidra] Detected overlap for variable var_b8h
// WARNING: [rz-ghidra] Detected overlap for variable var_b6h
// WARNING: [rz-ghidra] Detected overlap for variable var_6ch
// WARNING: [rz-ghidra] Detected overlap for variable var_68h
// WARNING: [rz-ghidra] Detected overlap for variable var_b0h
// WARNING: [rz-ghidra] Detected overlap for variable var_64h
// WARNING: [rz-ghidra] Detected overlap for variable var_60h

int64_t fcn.18015bbd0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_28h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_48h;
    int64_t var_38h;
    undefined4 uStack_30;
    undefined4 uStack_2c;
    
    fcn.18015c7f0(arg1 + 0x40, arg2, arg4, arg_28h);
    var_38h._0_4_ = *(undefined4 *)arg_28h;
    var_38h._4_4_ = *(undefined4 *)(arg_28h + 4);
    uStack_30 = *(undefined4 *)(arg_28h + 8);
    uStack_2c = *(undefined4 *)(arg_28h + 0xc);
    fcn.1801633e0((int64_t)&var_38h);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    piVar4 = *(int64_t **)(arg3 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            (**(code **)*piVar4)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                (**(code **)(*piVar4 + 8))(piVar4);
            }
        }
    }
    return arg2;
}

// ============================================================
// Function: FUN_18015bca0
// Address: 0x18015bca0
// Size: 370 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_88h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h
// WARNING: [rz-ghidra] Removing arg arg_2c8h because it doesn't fit into ProtoModel
// WARNING: [rz-ghidra] Removing arg arg_2cch because it doesn't fit into ProtoModel

void fcn.18015bca0(int64_t arg1, int64_t arg2, int64_t arg3, int64_t arg4, int64_t arg_40h)
{
    int64_t *piVar1;
    int32_t *piVar2;
    int32_t iVar3;
    int64_t *piVar4;
    code *pcVar5;
    int64_t iVar6;
    undefined *puVar7;
    int64_t var_18h;
    int64_t var_20h;
    undefined auStackY_a8 [8];
    undefined auStackY_a0 [24];
    int64_t var_88h;
    int64_t var_78h;
    int64_t var_70h;
    int64_t var_68h;
    int64_t var_58h;
    int64_t var_50h;
    int64_t var_48h;
    int64_t var_40h;
    int64_t var_30h;
    int64_t var_28h;
    uint64_t uStack_20;
    
    puVar7 = auStackY_a8;
    uStack_20 = *(uint64_t *)0x1806a3940 ^ (uint64_t)auStackY_a8;
    var_48h = arg2;
    func_0x00018015d450(arg1 + 0x40, &var_40h);
    func_0x00018015d110(arg1 + 0x40, arg3, arg4);
    var_58h = (int64_t)&var_40h;
    if (0xf < (uint64_t)var_28h) {
        var_58h = var_40h;
    }
    var_50h = var_30h;
    var_78h._0_1_ = 1;
    var_88h = (int64_t)&var_58h;
    var_70h = arg4;
    var_68h = arg3;
    fcn.1801633e0(var_88h);
    *(undefined *)(arg1 + 0x2c8) = 1;
    *(undefined4 *)(arg1 + 0x2cc) = 0xffffffff;
    if (0xf < (uint64_t)var_28h) {
        iVar6 = var_40h;
        puVar7 = auStackY_a8;
        if ((0xfff < var_28h + 1U) &&
           (iVar6 = *(int64_t *)(var_40h + -8), puVar7 = auStackY_a8, 0x1f < (var_40h - iVar6) - 8U)) {
            pcVar5 = (code *)swi(0x29);
            iVar6 = (*pcVar5)(5);
            puVar7 = auStackY_a0;
        }
        *(undefined8 *)(puVar7 + -8) = 0x18015bda0;
        func_0x000180459c3c(iVar6);
    }
    *(undefined8 *)(puVar7 + 0x78) = 0;
    *(undefined8 *)(puVar7 + 0x80) = 0xf;
    puVar7[0x68] = 0;
    piVar4 = *(int64_t **)(arg2 + 8);
    if (piVar4 != (int64_t *)0x0) {
        LOCK();
        piVar1 = piVar4 + 1;
        iVar3 = *(int32_t *)piVar1;
        *(int32_t *)piVar1 = *(int32_t *)piVar1 + -1;
        UNLOCK();
        if (iVar3 == 1) {
            pcVar5 = *(code **)*piVar4;
            *(undefined8 *)(puVar7 + -8) = 0x18015bdd7;
            (*pcVar5)(piVar4);
            LOCK();
            piVar2 = (int32_t *)((int64_t)piVar4 + 0xc);
            iVar3 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar3 == 1) {
                pcVar5 = *(code **)(*piVar4 + 8);
                *(undefined8 *)(puVar7 + -8) = 0x18015bdea;
                (*pcVar5)(piVar4);
            }
        }
    }
    *(undefined8 *)(puVar7 + -8) = 0x18015bdfa;
    func_0x000180459870(*(uint64_t *)(puVar7 + 0x88) ^ (uint64_t)puVar7);
    return;
}

// ============================================================
// Function: FUN_18015be20
// Address: 0x18015be20
// Size: 606 bytes
// ============================================================
void fcn.18015be20(int64_t arg1)
{
    uint32_t uVar1;
    uint64_t uVar2;
    float fVar3;
    float fVar4;
    float fVar5;
    float fVar6;
    float fVar7;
    int64_t var_48h;
    int64_t var_38h;
    int64_t var_28h;
    int64_t var_18h;
    
    uVar2 = 0;
    *(undefined4 *)(arg1 + 0x5e0) = *(undefined4 *)(*(int64_t *)0x180781f28 + 0xd9c);
    do {
        uVar1 = *(uint32_t *)(arg1 + 0x530 + uVar2 * 4);
        fVar3 = (float)(uint64_t)(uVar1 & 0xff) * 0.003921569;
        fVar6 = (float)(uint64_t)(uVar1 >> 8 & 0xff) * 0.003921569;
        fVar7 = (float)(uint64_t)(uVar1 >> 0x10 & 0xff) * 0.003921569;
        fVar5 = (float)(uint64_t)(uVar1 >> 0x18) * 0.003921569 * *(float *)(arg1 + 0x5e0);
        if (0.0 <= fVar3) {
            fVar4 = 1.0;
            if (fVar3 <= 1.0) {
                fVar4 = fVar3;
            }
        } else {
            fVar4 = 0.0;
        }
        if (0.0 <= fVar6) {
            fVar3 = 1.0;
            if (fVar6 <= 1.0) {
                fVar3 = fVar6;
            }
        } else {
            fVar3 = 0.0;
        }
        if (0.0 <= fVar7) {
            fVar6 = 1.0;
            if (fVar7 <= 1.0) {
                fVar6 = fVar7;
            }
        } else {
            fVar6 = 0.0;
        }
        if (0.0 <= fVar5) {
            fVar7 = 1.0;
            if (fVar5 <= 1.0) {
                fVar7 = fVar5;
            }
        } else {
            fVar7 = 0.0;
        }
        *(int32_t *)(arg1 + 0x588 + uVar2 * 4) =
             (int32_t)(fVar7 * 255.0 + 0.5) << 0x18 |
             (int32_t)(fVar6 * 255.0 + 0.5) << 0x10 |
             (int32_t)(fVar3 * 255.0 + 0.5) << 8 | (int32_t)(fVar4 * 255.0 + 0.5);
        uVar1 = *(uint32_t *)(arg1 + 0x534 + uVar2 * 4);
        fVar3 = (float)(uint64_t)(uVar1 & 0xff) * 0.003921569;
        fVar5 = (float)(uint64_t)(uVar1 >> 8 & 0xff) * 0.003921569;
        fVar7 = (float)(uint64_t)(uVar1 >> 0x10 & 0xff) * 0.003921569;
        fVar6 = (float)(uint64_t)(uVar1 >> 0x18) * 0.003921569 * *(float *)(arg1 + 0x5e0);
        if (0.0 <= fVar3) {
            fVar4 = 1.0;
            if (fVar3 <= 1.0) {
                fVar4 = fVar3;
            }
        } else {
            fVar4 = 0.0;
        }
        if (0.0 <= fVar5) {
            fVar3 = 1.0;
            if (fVar5 <= 1.0) {
                fVar3 = fVar5;
            }
        } else {
            fVar3 = 0.0;
        }
        if (0.0 <= fVar7) {
            fVar5 = 1.0;
            if (fVar7 <= 1.0) {
                fVar5 = fVar7;
            }
        } else {
            fVar5 = 0.0;
        }
        if (0.0 <= fVar6) {
            fVar7 = 1.0;
            if (fVar6 <= 1.0) {
                fVar7 = fVar6;
            }
        } else {
            fVar7 = 0.0;
        }
        *(int32_t *)(arg1 + 0x58c + uVar2 * 4) =
             (int32_t)(fVar7 * 255.0 + 0.5) << 0x18 |
             (int32_t)(fVar5 * 255.0 + 0.5) << 0x10 |
             (int32_t)(fVar3 * 255.0 + 0.5) << 8 | (int32_t)(fVar4 * 255.0 + 0.5);
        uVar2 = uVar2 + 2;
    } while (uVar2 < 0x16);
    return;
}

// ============================================================
// Function: FUN_18015c080
// Address: 0x18015c080
// Size: 76 bytes
// ============================================================
void fcn.18015c080(int64_t arg1, int64_t arg2, int64_t arg3)
{
    int64_t var_10h;
    int64_t var_18h;
    
    if (*(int64_t *)arg1 != *(int64_t *)(arg1 + 8)) {
        *(int64_t *)(arg1 + 8) = *(int64_t *)arg1;
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    var_10h = arg2;
    var_18h = arg3;
    fcn.180163690(arg1, &var_10h, &var_18h);
    *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    return;
}

// ============================================================
// Function: FUN_18015c0d0
// Address: 0x18015c0d0
// Size: 134 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h

void fcn.18015c0d0(int64_t arg1, int64_t arg2, int64_t arg3)
{
    uint64_t uVar1;
    code *pcVar2;
    uint64_t uVar3;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    
    uVar1 = *(uint64_t *)(arg1 + 0x20);
    uVar3 = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333;
    var_10h = arg2;
    var_18h = arg3;
    if (uVar1 <= uVar3 && uVar3 - uVar1 != 0) {
        *(undefined *)(*(int64_t *)arg1 + 0x11 + uVar1 * 0x14) = 0;
        fcn.180163690(arg1, &var_10h, &var_18h);
        *(undefined *)(*(int64_t *)(arg1 + 8) + -3) = 1;
        *(int64_t *)(arg1 + 0x20) = (*(int64_t *)(arg1 + 8) - *(int64_t *)arg1 >> 2) * -0x3333333333333333 + -1;
        return;
    }
    fcn.180060370();
    pcVar2 = (code *)swi(3);
    (*pcVar2)();
    return;
}

// ============================================================
// Function: FUN_18015c180
// Address: 0x18015c180
// Size: 451 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_10h
// WARNING: Variable defined which should be unmapped: var_18h
// WARNING: Variable defined which should be unmapped: var_20h

void fcn.18015c180(int64_t arg1, int64_t arg2)
{
    undefined8 *puVar1;
    undefined8 uVar2;
    undefined8 *puVar3;
    code *pcVar4;
    uint64_t uVar5;
    int64_t iVar6;
    undefined8 *puVar7;
    int64_t *piVar8;
    int64_t *piVar9;
    uint64_t uVar10;
    int64_t iVar11;
    uint64_t uVar12;
    uint64_t uVar13;
    int64_t var_8h;
    int64_t var_10h;
    int64_t var_18h;
    int64_t var_20h;
    int64_t var_38h;
    undefined auStack_30 [24];
    
    piVar8 = &var_38h;
    puVar1 = *(undefined8 **)arg1;
    puVar7 = *(undefined8 **)(arg1 + 8);
    if (puVar1 != *(undefined8 **)(arg1 + 8)) {
        *(undefined8 **)(arg1 + 8) = puVar1;
        puVar7 = puVar1;
    }
    uVar10 = 0;
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    if (puVar7 != *(undefined8 **)(arg1 + 0x10)) {
        *(undefined2 *)(puVar7 + 2) = 0x100;
        *puVar7 = 0;
        puVar7[1] = 0;
        *(undefined *)((int64_t)puVar7 + 0x12) = 1;
        *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + 0x14;
code_r0x00018015c312:
        *(undefined *)(*(int64_t *)arg1 + 0x10) = 1;
        *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
        return;
    }
    iVar11 = ((int64_t)puVar7 - (int64_t)puVar1) / 0x14;
    if (iVar11 == 0xccccccccccccccc) {
        func_0x000180010010();
        pcVar4 = (code *)swi(3);
        (*pcVar4)();
        return;
    }
    uVar12 = ((int64_t)*(undefined8 **)(arg1 + 0x10) - (int64_t)puVar1 >> 2) * -0x3333333333333333;
    uVar5 = 0xccccccccccccccc - (uVar12 >> 1);
    if (uVar12 < uVar5 || uVar12 - uVar5 == 0) {
        uVar5 = iVar11 + 1;
        uVar12 = uVar12 + (uVar12 >> 1);
        uVar13 = uVar5;
        if (uVar5 <= uVar12) {
            uVar13 = uVar12;
        }
        if (uVar13 < 0xccccccccccccccd) {
            uVar12 = uVar13 * 0x14;
            piVar9 = &var_38h;
            if (uVar12 != 0) {
                if (uVar12 < 0x1000) {
                    uVar10 = fcn.180459890();
                    piVar9 = &var_38h;
                } else {
                    if (uVar12 + 0x27 <= uVar12) goto code_r0x00018015c33d;
                    iVar6 = fcn.180459890(uVar12 + 0x27);
                    if (iVar6 == 0) {
                        pcVar4 = (code *)swi(0x29);
                        iVar6 = (*pcVar4)(5);
                        piVar8 = (int64_t *)auStack_30;
                    }
                    uVar10 = iVar6 + 0x27U & 0xffffffffffffffe0;
                    *(int64_t *)(uVar10 - 8) = iVar6;
                    piVar9 = piVar8;
                }
            }
            puVar1 = (undefined8 *)(uVar10 + iVar11 * 0x14);
            uVar2 = *(undefined8 *)((int64_t)piVar9 + 0x40);
            *(undefined2 *)(puVar1 + 2) = 0x100;
            *puVar1 = uVar2;
            puVar1[1] = uVar2;
            *(undefined *)((int64_t)puVar1 + 0x12) = 1;
            puVar3 = *(undefined8 **)arg1;
            if (puVar7 == *(undefined8 **)(arg1 + 8)) {
                iVar11 = (int64_t)*(undefined8 **)(arg1 + 8) - (int64_t)puVar3;
                uVar12 = uVar10;
                puVar7 = puVar3;
            } else {
                *(undefined8 *)((int64_t)piVar9 + -8) = 0x18015c2ee;
                fcn.180498030(uVar10, puVar3, (int64_t)puVar7 - (int64_t)puVar3);
                uVar12 = (int64_t)puVar1 + 0x14;
                iVar11 = *(int64_t *)(arg1 + 8) - (int64_t)puVar7;
            }
            *(undefined8 *)((int64_t)piVar9 + -8) = 0x18015c301;
            fcn.180498030(uVar12, puVar7, iVar11);
            *(undefined8 *)((int64_t)piVar9 + -8) = 0x18015c312;
            func_0x000180165b20(arg1, uVar10, uVar5, uVar13);
            goto code_r0x00018015c312;
        }
    }
code_r0x00018015c33d:
    fcn.180004720();
    pcVar4 = (code *)swi(3);
    (*pcVar4)();
    return;
}

// ============================================================
// Function: FUN_18015c350
// Address: 0x18015c350
// Size: 192 bytes
// ============================================================
// WARNING: Variable defined which should be unmapped: var_8h
// WARNING: Variable defined which should be unmapped: var_10h

void fcn.18015c350(int64_t arg1)
{
    uint64_t uVar1;
    undefined8 *puVar2;
    int32_t iVar3;
    int32_t iVar4;
    undefined8 *puVar5;
    bool bVar6;
    undefined8 *puVar7;
    undefined8 uVar8;
    char in_DL;
    uint64_t uVar9;
    int64_t var_8h;
    int64_t var_10h;
    
    uVar1 = *(uint64_t *)arg1;
    while (uVar9 = uVar1, uVar9 < *(uint64_t *)(arg1 + 8)) {
        uVar1 = uVar9 + 0x14;
        if (*(char *)(uVar9 + 0x10) == '\0') {
            fcn.180498030(uVar9, uVar1, *(uint64_t *)(arg1 + 8) - uVar1);
            *(int64_t *)(arg1 + 8) = *(int64_t *)(arg1 + 8) + -0x14;
            uVar1 = uVar9;
        }
    }
    *(undefined8 *)(arg1 + 0x18) = 0;
    *(undefined8 *)(arg1 + 0x20) = 0;
    *(undefined *)(*(int64_t *)arg1 + 0x11) = 1;
    if (in_DL != '\0') {
        puVar5 = *(undefined8 **)arg1;
        iVar3 = *(int32_t *)(puVar5 + 1);
        puVar2 = puVar5 + 1;
        iVar4 = *(int32_t *)puVar5;
        if (iVar4 == iVar3) {
            bVar6 = *(int32_t *)((int64_t)puVar5 + 0xc) < *(int32_t *)((int64_t)puVar5 + 4);
            puVar7 = puVar5;
            if (*(int32_t *)((int64_t)puVar5 + 4) <= *(int32_t *)((int64_t)puVar5 + 0xc)) {
                puVar7 = puVar2;
            }
            uVar8 = *puVar7;
        } else {
            bVar6 = iVar4 != iVar3 && iVar3 <= iVar4;
            puVar7 = puVar5;
            if (iVar4 <= iVar3) {
                puVar7 = puVar2;
            }
            uVar8 = *puVar7;
        }
        puVar7 = puVar5;
        if (!bVar6) {
            puVar7 = puVar2;
        }
        *puVar5 = *puVar7;
        *puVar2 = uVar8;
        *(undefined *)((int64_t)puVar5 + 0x12) = 1;
    }
    return;
}

